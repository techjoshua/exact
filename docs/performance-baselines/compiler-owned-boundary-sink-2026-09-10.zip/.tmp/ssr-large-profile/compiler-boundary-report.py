import pathlib, json, hashlib, zipfile
root=pathlib.Path.cwd(); d=root/'.tmp/ssr-large-profile'
rows=json.loads((d/'compiler-boundary-results.json').read_text()); assert len(rows)==48
lines=['# Compiler-owned boundary sink experiment, 2026-09-10', '',
'Synchronous component references whose marker boundary is explicitly omitted by compiler ownership now keep the enclosing writer sink. Scheduled components and standalone resumption publication still capture local output. The shared renderer and string sink policy are unchanged.', '',
'Hypothesis: avoiding unnecessary component-wide local string capture may improve render time by 1-3%. The results support no consistent string improvement. The change is retained because it removes capture work for an explicitly omitted boundary without weakening publication or retry guarantees.', '',
'Production Node 26.8.1, Bun 1.4.2, React 19.2.0. Each cell averages two fresh processes in reversed order, with 5,000 warmups and 12,000 measured renders per process. Both frameworks render complete application-owned documents with four asset tags. Streams are consumed completely. These are in-process timings, not HTTP throughput. Small documents contain three incidents and large documents 96. eXact complete-document hashes match the saved single-join control.', '',
'| Runtime | Mode | Document | Previous (µs) | Direct boundary (µs) | React (µs) |',
'| --- | --- | --- | ---: | ---: | ---: |']
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['assets','large']:
   means=[sum(r['usPerRender'] for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['variant']==v)/2 for v in ['previous','direct','react']]
   lines.append(f'| {runtime} | {mode} | {scenario} | '+' | '.join(f'{x:.2f}' for x in means)+' |')
lines += ['', 'Two reversed samples on a shared workstation are insufficient to establish small gains. Node streaming leads React; string rendering still trails React on both runtimes, and Bun large-document streaming remains behind.', '',
'A separate untimed capture audit found that the control entered two marker captures and one component capture for the large document. The narrowed condition instead entered four marker captures. Removing the enclosing component capture exposes descendant marker captures, which still collect strings locally. This explains why the condition alone does not eliminate intermediate construction. The next experiment should examine direct marker publication with backpressure and retry isolation.', '',
'Validation: package build and 315 SSR tests passed, including an added synchronous stateful document fixture compared against local collection with markers enabled and disabled. The fixture compares complete HTML, hydration records, host cleanup, and disposal. Repository test typecheck, focused ESLint, and source architecture passed.', '',
'Raw samples, measured bundles, capture audit, harnesses, and relevant source are in the accompanying archive. No GC reduction was measured. Native writer ABI migration and progressive public tree-to-transport integration remain unfinished.']
report=root/'docs/performance-baselines/compiler-owned-boundary-sink-2026-09-10.md';report.write_text('\n'.join(lines)+'\n',encoding='utf8')
files=[d/n for n in ['compiler-boundary-run.mjs','compiler-boundary-results.json','compiler-boundary-captures.mjs','compiler-boundary-captures.json','compiler-boundary-report.py','production-refresh-worker.mjs']]
files += [root/r['entry'] for r in rows]
files += [root/p for p in ['packages/ssr/src/render/component.ts','packages/ssr/src/render/program-sink-components.test.ts','packages/ssr/src/render/program-sink.fixtures.test.tsx']]
with zipfile.ZipFile(report.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 hashes={}
 for p in dict.fromkeys(files):
  content=p.read_bytes(); name=p.relative_to(root).as_posix();hashes[name]=hashlib.sha256(content).hexdigest();z.writestr(name,content)
 z.writestr('sha256.json',json.dumps(hashes,indent=2))
print('\n'.join(lines[8:18]))
