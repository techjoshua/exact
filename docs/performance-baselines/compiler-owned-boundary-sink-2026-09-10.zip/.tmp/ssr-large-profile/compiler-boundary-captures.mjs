import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const d='.tmp/ssr-large-profile/';
const observations=[];
for(const variant of ['request-joined-sink','compiler-boundary-sink']) {
 let source=fs.readFileSync(d+variant+'/server-entry.js','utf8');
 source=source.replace('function captureSsrProgramOutput(context, render) {', `function captureSsrProgramOutput(context, render) {
 if(context.writerSink){const caller=new Error().stack.split('\\n')[2].trim();globalThis.__captures[caller]=(globalThis.__captures[caller]??0)+1;}`);
 const path=d+variant+'-capture-count.mjs';fs.writeFileSync(path,source);
 const mod=await import(pathToFileURL(resolve(path)));
 const data=JSON.parse(fs.readFileSync('.tmp/positional-leaves/data.json','utf8'));
 data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
 globalThis.__captures={};
 const html=await mod.renderParticipant(data,'/incidents/inc-101',{clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'});
 observations.push({variant,bytes:Buffer.byteLength(html),captures:globalThis.__captures});
}
fs.writeFileSync(d+'compiler-boundary-captures.json',JSON.stringify(observations,null,2));
console.log(JSON.stringify(observations,null,2));
