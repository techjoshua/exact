import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';
const worker=root+'leaf-output-shape-worker.mjs';
let source=fs.readFileSync(root+'ready-props-stable-timing-worker.mjs','utf8');
source=source.replace('const started=performance.now();','const cpuStart=process.cpuUsage();\nconst started=performance.now();');
source=source.replace('const elapsed=performance.now()-started;', 'const elapsed=performance.now()-started;\nconst cpu=process.cpuUsage(cpuStart);');
source=source.replace('processPriority:os.getPriority()','processPriority:os.getPriority(),cpuMicrosPerRender:(cpu.user+cpu.system)/count');
fs.writeFileSync(worker,source);
const rows=[];
for(const [runtime,scenario] of [['node','assets'],['bun','assets']])for(let round=0;round<2;round++)for(const variant of round?['split','candidate','current']:['current','candidate','split']){
 const entry=root+(variant==='split'?'leaf-output-aligned':variant==='candidate'?'leaf-output-unfrozen':'leaf-output-flag')+'/server-entry.js';
 const artifactSha256=createHash('sha256').update(fs.readFileSync(entry)).digest('hex');
 assert.equal(artifactSha256,variant==='split'?'2cb70d345cee3bdc68587c67d631df818974a168d4f8aaff50bc2c375aabb0fd':variant==='candidate'?'0f0963fcb02906181a388af003e9bd2267fb07172ef6bf2ea0a85de9a625a9ab':'4bcbd9b946316fc32a70891d102f9f543d07b8eba20ba58cf2dc8569ecf5fa07');
 const run=spawnSync(runtime,[worker,entry,'encoded',scenario,'20000'],{windowsHide:true,encoding:'utf8',env:{...process.env,NODE_ENV:'production'}});
 assert.equal(run.status,0,run.stderr+run.stdout);
 const row={runtimeId:runtime,variant,round,artifactSha256,...JSON.parse(run.stdout)};
 const peer=rows.find(r=>r.scenario===scenario);if(peer)assert.equal(row.hash,peer.hash);
 rows.push(row);fs.writeFileSync(root+'leaf-output-shape.json',JSON.stringify(rows,null,2));
 console.log(runtime,variant,round,'wall',row.usPerRender.toFixed(2),'CPU',row.cpuMicrosPerRender.toFixed(2),'us/render');
}

assert.equal(rows.length,12);
