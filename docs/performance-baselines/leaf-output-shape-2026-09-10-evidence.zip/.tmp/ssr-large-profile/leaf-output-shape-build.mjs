import fs from 'node:fs';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';const source=fs.readFileSync(root+'leaf-output-flag/server-entry.js','utf8');
assert.equal(createHash('sha256').update(source).digest('hex'),'4bcbd9b946316fc32a70891d102f9f543d07b8eba20ba58cf2dc8569ecf5fa07');
const old='Object.freeze({context,sink:context.writerSink})';assert.equal(source.split(old).length,2);
const variants={unfrozen:'{context,sink:context.writerSink}',aligned:'{context,sink:context.writerSink,target:undefined,render:renderWriterTargetSegment,prepareReferences:prepareWriterTargetReferences}'};
const hashes={};
for(const [name,value] of Object.entries(variants)){
 const folder='leaf-output-'+name;const code=source.replace(old,value);fs.mkdirSync(root+folder,{recursive:true});fs.writeFileSync(root+folder+'/server-entry.js',code);hashes[name]=createHash('sha256').update(code).digest('hex');
 fs.writeFileSync(root+folder+'-pressure.mjs',fs.readFileSync(root+'leaf-output-flag-pressure.mjs','utf8').replaceAll('leaf-output-flag',folder));
}
fs.writeFileSync(root+'leaf-output-shape-hashes.json',JSON.stringify(hashes,null,2));console.log(hashes);
let driver=fs.readFileSync(root+'leaf-output-flag-timing.mjs','utf8');
driver=driver.replace("['split','current']:['current','split']","['split','candidate','current']:['current','candidate','split']");
driver=driver.replace("variant==='split'?'leaf-output-flag':variant==='candidate'?'ready-props-split':'direct-execution-integrated'","variant==='split'?'leaf-output-aligned':variant==='candidate'?'leaf-output-unfrozen':'leaf-output-flag'");
driver=driver.replaceAll('4bcbd9b946316fc32a70891d102f9f543d07b8eba20ba58cf2dc8569ecf5fa07',hashes.aligned).replaceAll('a454621b5c878a28cbf574f54bc8b73d1cb026809ef24f421be9e61c6f13000d',hashes.unfrozen).replaceAll('2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18','4bcbd9b946316fc32a70891d102f9f543d07b8eba20ba58cf2dc8569ecf5fa07');
driver=driver.replaceAll('leaf-output-flag-remaining','leaf-output-shape').replace('rows.length,8','rows.length,12');fs.writeFileSync(root+'leaf-output-shape-timing.mjs',driver);
