import fs from 'node:fs';import {spawnSync} from 'node:child_process';import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';const rows=[];
for(const variant of ['flag','unfrozen','aligned']){
 let code=fs.readFileSync(root+'leaf-output-'+variant+'/server-entry.js','utf8');code='let auditNormal, auditLeaf;\n'+code;
 const start=code.indexOf('function renderProgramWriter('),at=code.indexOf('\n\tif (host &&',start);assert.ok(at>start);
 code=code.slice(0,at)+'\n if(invocation?.program.auditLeafOutput) auditLeaf ??= output; else auditNormal ??= output;'+code.slice(at);
 code+='\nexport function auditOutputs(){return [auditNormal,auditLeaf];}';
 const entry=root+'leaf-output-'+variant+'-map-entry.mjs';fs.writeFileSync(entry,code);
 const worker=root+'leaf-output-'+variant+'-map-worker.mjs';fs.writeFileSync(worker,`import os from 'node:os';os.setPriority(0,10);import fs from 'node:fs';import {renderParticipant,auditOutputs} from './leaf-output-${variant}-map-entry.mjs';\nconst data=JSON.parse(fs.readFileSync('.tmp/positional-leaves/data.json','utf8'));await renderParticipant(data,'/incidents/inc-101',{clientTags:'<script type="module" src="/assets/app.js"></script>'});const [normal,leaf]=auditOutputs();console.log(JSON.stringify({variant:'${variant}',sameMap:%HaveSameMap(normal,leaf),normalKeys:Object.keys(normal),leafKeys:Object.keys(leaf),frozen:Object.isFrozen(leaf)}));`);
 const result=spawnSync(process.execPath,['--allow-natives-syntax',worker],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});assert.equal(result.status,0,result.stderr);rows.push(JSON.parse(result.stdout));
}
fs.writeFileSync(root+'leaf-output-shape-maps.json',JSON.stringify(rows,null,2));console.log(rows);
