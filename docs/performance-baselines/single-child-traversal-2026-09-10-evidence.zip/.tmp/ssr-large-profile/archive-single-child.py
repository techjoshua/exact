from pathlib import Path
import json,hashlib,zipfile
root=Path.cwd();base=root/'.tmp/ssr-large-profile';folder=base/'single-child-traversal'
s=json.loads((folder/'summary.json').read_text());rows=json.loads((folder/'http.json').read_text());assert len(rows)==72 and s['errors']==0
for runtime in ('node','bun'):
 for mode in ('string','stream'):
  exact=[r for r in rows if r['runtime']==runtime and r['mode']==mode and r['variant']!='react'];assert len({r['identity']['hash'] for r in exact})==1
for r in rows:assert hashlib.sha256(Path(r['entry']).read_bytes()).hexdigest()==r['artifactSha256']
table='\n'.join(f"| {r['runtime'].title()} {r['mode']} | {r['rps']['baseline']:,.0f} | {r['rps']['compiled']:,.0f} | {r['rps']['react']:,.0f} | {r['changePercent']:+.1f}% | {r['improvedBlocks']}/6 |" for r in s['summary'])
report=root/'docs/performance-baselines/single-child-traversal-2026-09-10.md'
decision=json.loads((folder/'decision.json').read_text())
report.write_text("""# Single-child traversal experiment, September 10, 2026

An initial candidate forwarded prepared programs directly through the existing execution target.
It passed 372 SSR tests, 56 browser checks and type checking, but its trace bypassed only one of
21 generic child groups. Most programs already arrived inside arrays. That narrow branch was
removed without a throughput claim. Its source and artifacts are retained for comparison.

The subsequent candidate handles one-child arrays in the shared child entrypoint without allocating
a multi-child ChildrenOutput object. It retains the same execution target, node/depth accounting,
pending-child flush, captured-output rules and final writer readiness. The hypothesis was a gain
of a few percent from reducing objects and forwarding work, not a second rendering engine.

Traces show ChildrenOutput.render falling from 21 calls to five in both modes, with eight component
executions, 24 render programs, 89 sink writes and one hydration serialization unchanged. Both traced
outputs match the uninstrumented controls byte-for-byte. Trace duration is not benchmark timing.

## Paired HTTP comparison

| Runtime/output | Prior eXact requests/s | Candidate eXact requests/s | React requests/s | Change | Positive blocks |
| --- | ---: | ---: | ---: | ---: | ---: |
"""+table+f"\n{s['valid']:,} valid responses, zero errors.\n\n"+decision['reason']+"""

Each of four cells uses all six variant orders, 72 blocks total. Workers warm for ten seconds;
measured blocks last 1.5 seconds, with two drivers at concurrency 16 each. Node 26.8.1 and Bun 1.4.2
use production mode, native adapters, full application-owned documents and below-normal priority.
The PC remains available for user workloads. No builds, tests or profilers run during timing.
React is unchanged, and eXact responses are byte-identical within every cell. Short local rates
remain sensitive to workload and runtime state.

The final candidate passes 372 SSR tests, all 56 browser checks, test type checking and focused
ESLint. Existing marker/capture/async fixture comparisons now also assert equal node accounting and
balanced traversal depth. These checks preserve the same HTML, hydration and lifecycle contracts.
The production decision is recorded in decision.json in the archive; candidate test results do not
imply adoption or React parity.

[Evidence archive](single-child-traversal-2026-09-10-evidence.zip) preserves both prototypes, sources,
traces, paired results, scripts and validation logs. Larger shell/hydration integration remains open.
""",encoding='utf-8')
files={report,Path(__file__).resolve(),root/'docs/ssr-hydration.md'}
for name in ('direct-program-child','direct-program-child-trace','single-child-traversal','single-child-traversal-trace','single-child-isolated'):
 files.update(f for f in (base/name).rglob('*') if f.is_file())
 files.update(f for f in base.glob(name+'-*') if f.is_file())
for name in ('server-entry.js','bun-server-entry.js'):files.add(base/'conditional-emission'/name)
for rel in ('render/children.ts','render/program-sink-components.test.ts'):files.add(root/'packages/ssr/src'/rel)
for sub in ('dist-server/server-entry.js','dist-bun-server/bun-server-entry.js'):files.add(root/'framework-comparison/participants/react'/sub)
archive=report.with_name('single-child-traversal-2026-09-10-evidence.zip');assert not archive.exists()
manifest={str(f.relative_to(root)).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(files)}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(files):z.write(f,str(f.relative_to(root)).replace('\\','/'))
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print('Verified',len(files),'files')
