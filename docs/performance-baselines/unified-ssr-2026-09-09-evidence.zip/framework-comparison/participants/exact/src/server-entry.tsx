import { renderToHydratableString, renderToHydratableProgressiveHtmlStream } from '@exactjs/ssr';
import { Document, type DocumentOptions } from './Document.jsx';
import type { InitialData } from './types.js';

/** Uses the public progressive HTML API with the same authored document and root props. */
export function renderParticipantStream(
	initialData: InitialData,
	path: string,
	options?: DocumentOptions,
	signal?: AbortSignal
) {
	return renderToHydratableProgressiveHtmlStream(
		<Document initialData={initialData} path={path} clientTags={options?.clientTags} />,
		{ publishRootProps: true, signal }
	);
}

/** Renders the authored document through eXact's normalization and hydration publication. */
export async function renderParticipant(
	initialData: InitialData,
	path: string,
	options?: DocumentOptions
) {
	return (await renderToHydratableString(
		<Document initialData={initialData} path={path} clientTags={options?.clientTags} />,
		{ publishRootProps: true }
	)).htmlWithHydration;
}

/** Publishes the framework-normalized document through the Node response owner. */
export async function renderParticipantToSink(
	initialData: InitialData,
	path: string,
	write: (value: string) => void | Promise<void>,
	encodedByteLength?: (value: string) => number,
	options?: DocumentOptions
): Promise<number> {
	const html = await renderParticipant(initialData, path, options);
	const written = write(html);
	if (written instanceof Promise) await written;
	return encodedByteLength ? encodedByteLength(html) : new TextEncoder().encode(html).byteLength;
}
