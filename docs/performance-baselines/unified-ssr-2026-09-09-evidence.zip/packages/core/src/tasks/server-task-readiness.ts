/** Task-system-owned settlement state read by consumers without awaiting completed work. */
export class ServerTaskReadiness {
	private readonly pending = new Set<Promise<unknown>>();
	private failure?: { error: unknown };
	private revision = 0;

	/** Counts completed blocking activations so consumers can detect changes during publication. */
	get version(): number {
		return this.revision;
	}

	/** Observes already-started work; this boundary never invokes or schedules a task. */
	observe(settlement: Promise<unknown>): void {
		this.pending.add(settlement);
		void settlement.then(
			() => {
				this.pending.delete(settlement);
				this.revision++;
			},
			(error) => {
				this.pending.delete(settlement);
				this.revision++;
				this.failure ??= { error };
			}
		);
	}

	/** Returns no wait for settled work, or a promise for currently pending blocking activations. */
	wait(): Promise<void> | undefined {
		if (this.failure) throw this.failure.error;
		if (!this.pending.size) return undefined;
		return Promise.all(this.pending).then(() => undefined);
	}
}
