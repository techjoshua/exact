import { expect, it } from 'vitest';
import { ServerTaskReadiness } from './server-task-readiness.js';

it('does not allocate a wait for absent or already completed task work', async () => {
	const state = new ServerTaskReadiness();
	expect(state.wait()).toBeUndefined();
	let resolve!: () => void;
	const gate = {
		promise: new Promise<void>((accept) => {
			resolve = accept;
		}),
		resolve: () => resolve()
	};
	state.observe(gate.promise);
	expect(state.wait()).toBeInstanceOf(Promise);
	gate.resolve();
	await gate.promise;
	expect(state.wait()).toBeUndefined();
	expect(state.version).toBe(1);
});

it('retains task failure even after the pending work is removed', async () => {
	const state = new ServerTaskReadiness();
	const error = new Error('task failed');
	state.observe(Promise.reject(error));
	await Promise.resolve();
	expect(() => state.wait()).toThrow(error);
	expect(state.version).toBe(1);
});
