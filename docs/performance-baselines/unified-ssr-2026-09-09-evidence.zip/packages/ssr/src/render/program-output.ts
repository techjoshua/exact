import type { SsrContext } from '../types.js';
import type { RenderValue } from './execution.js';
import { appendBoundedHtml } from './limits.js';
import { captureNestedEnhancementStringPrefix } from './operation-enhancement-routes.js';

/** Serializes ordered program segments directly, continuing only when a segment has pending work. */
export function renderProgramOutput<T>(
	context: SsrContext,
	segments: readonly T[],
	render: (segment: T) => RenderValue<string>
): RenderValue<string> {
	let output = '';
	const append = (html: string) => {
		output = captureNestedEnhancementStringPrefix(context, output);
		output = appendBoundedHtml(context, output, html);
	};
	const next = (start: number): RenderValue<string> => {
		for (let index = start; index < segments.length; index++) {
			const value = render(segments[index]!);
			if (value instanceof Promise)
				return value.then((html) => {
					append(html);
					return next(index + 1);
				});
			append(value);
		}
		return output;
	};
	return next(0);
}
