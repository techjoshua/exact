import {readFile,writeFile} from 'node:fs/promises';
const path='packages/ssr/src/render/direct-component.ts';let source=await readFile(path,'utf8');
const start=source.indexOf('/** Executes one synchronous artifact'),end=source.indexOf('\nfunction performanceNow');
if(start<0||end<0)throw Error('Direct execution source mismatch');
source=source.slice(0,start)+await readFile('.tmp/unified-ssr/direct-execution-fragment.ts','utf8')+source.slice(end);
source=source.replace("import { attachSuppressedCleanupFailure, type AnyComponentInstance }", "import { type AnyComponentInstance }")
.replace("import { disposeAsyncPreservingPrimary, noPrimaryFailure } from './ownership.js';", "import { mapRenderValue, withRenderCleanup, type RenderValue } from './execution.js';")
.replace('\tdisposeDirectSsrLifetimeSync,\n','');
await writeFile(path,source);
