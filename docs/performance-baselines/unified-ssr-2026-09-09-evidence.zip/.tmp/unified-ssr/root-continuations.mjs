import ts from 'typescript';
import{readFile,writeFile}from'node:fs/promises';
const p='packages/ssr/src/render/render-output.ts';let s=await readFile(p,'utf8');await writeFile('.tmp/unified-ssr/render-output-before-root-continuations.ts',s);
const sf=ts.createSourceFile(p,s,ts.ScriptTarget.Latest,true),ed=[];
for(const n of sf.statements)if(ts.isFunctionDeclaration(n)){
 if(n.name?.text==='renderTreeOutput')ed.push([n.getFullStart(),n.end,'']);
 if(n.name?.text==='renderStringOutput')ed.push([n.getFullStart(),n.end,`
/** Returns asynchronous public completion while available internal work runs directly. */
export async function renderStringOutput(operation: Child, options: RenderToStringOptions = {}, omitRootBoundary = false, outputKind: 'html' | 'stream' = 'html'): Promise<RenderToStringResult> {
 return renderOwnedOutput(operation, options, omitRootBoundary, outputKind);
}

/** Retains one render owner across actual suspension and releases it before public completion. */
function renderOwnedOutput(operation: Child, options: RenderToStringOptions, omitRootBoundary: boolean, outputKind: 'html' | 'stream' = 'html'): RenderValue<RenderToStringResult> {
 const started = options.onProfile ? performance.now() : undefined;
 const owner = createSsrOwner();
 return withRenderCleanup(
  () => withTaskObserver(owner.observer, () => renderTreeOutput(operation, options, omitRootBoundary, outputKind)),
  () => { try { owner.dispose('ssr render complete'); } finally {
   if (started !== undefined) publishExactProfile(options.onProfile, Object.freeze({subsystem:'ssr',phase:'render-to-string',elapsedMs:performance.now()-started}));
  }}
 );
}
`]);
}
for(const[a,b,v]of ed.reverse())s=s.slice(0,a)+v+s.slice(b);
s="import { renderTreeOutput } from './tree-output.js';\nimport { withRenderCleanup, type RenderValue } from './execution.js';\n"+s;
s=s.replace('export async function renderToString(', 'export function renderToString(').replace('export async function renderToHydratableString(', 'export function renderToHydratableString(');
s=s.replace('const result = await renderStringOutput(operation, capture.options, omitRootBoundary);','const rendered = renderOwnedOutput(operation, capture.options, omitRootBoundary);\n\tconst result = rendered instanceof Promise ? await rendered : rendered;');
await writeFile(p,s);
