import ts from 'typescript';
import {readFileSync, writeFileSync, readdirSync} from 'node:fs';
function remove(path, names) {
 let source=readFileSync(path,'utf8'); const sf=ts.createSourceFile(path,source,99,true);
 const edits=sf.statements.filter(n=>ts.isFunctionDeclaration(n)&&names.includes(n.name?.text)).map(n=>[n.getFullStart(),n.end]);
 for(const [start,end] of edits.reverse())source=source.slice(0,start)+source.slice(end);
 writeFileSync(path,source);
}
remove('packages/ssr/src/render/limits.ts',['withSsrTreeDepth','withSsrTreeDepthAsync']);
remove('packages/ssr/src/render/operation-enhancement-routes.ts',['captureNestedEnhancementPrefix']);
for(const [path,from,to] of [
 ['packages/ssr/src/render/intrinsic-receipt.ts','Async counterpart preserving the same host-stack ownership.','Serializes an intrinsic while retaining host ownership through pending descendants.'],
 ['packages/ssr/src/render/children.ts','Serializes opaque native operations and scalar children asynchronously.','Serializes native operations and scalar children, suspending only for pending output.'],
 ['packages/ssr/src/render/operation-target.ts','Async SSR target selected directly by each opaque compiler-issued operation.','Shared SSR target selected directly by each opaque compiler-issued operation.'],
 ['packages/ssr/src/render/direct-component.ts','Sink selected by the asynchronous renderer after direct child preparation.','Shared output sink selected after direct child preparation.'],
 ['packages/ssr/src/render/render-output.ts','Transforms to string async into its required representation.','Renders a tree to a promised string result, waiting for required component work.']
])writeFileSync(path,readFileSync(path,'utf8').replace(from,to));
const test='packages/ssr/src/resumption-capture.test.ts';
let source=readFileSync(test,'utf8').replace("it.each([true])('does not invoke published root accessors (direct: %s)', (direct) => {","it('does not invoke published root accessors', () => {")
 .replace('(direct ? createSsrResumptionCapture : createSsrResumptionCapture)(', 'createSsrResumptionCapture(')
 .replace("it('omits the generic instance bridge for compiler-closed artifact roots'", "it('preserves application lifecycle observers'")
 .replace('\n\t\tconst generic = createSsrResumptionCapture(options);','')
 .replace(/\n\t\texpect\(generic\.options[^\n]+/g,'')
 .replace('it.each([createSsrResumptionCapture])(', 'it(')
 .replace('(createCapture) => {','() => {')
 .replace('const capture = createCapture(', 'const capture = createSsrResumptionCapture(');
writeFileSync(test,source);
const files=[];
function walk(dir){for(const e of readdirSync(dir,{withFileTypes:true})){const p=dir+'/'+e.name;if(e.isDirectory())walk(p);else if(/\.tsx?$/.test(p))files.push(p);}}
walk('packages/ssr/src');
for(const file of files){
 const text=readFileSync(file,'utf8');
 const host={getScriptFileNames:()=>[file],getScriptVersion:()=> '0',getScriptSnapshot:p=>ts.sys.fileExists(p)?ts.ScriptSnapshot.fromString(ts.sys.readFile(p)):undefined,getCurrentDirectory:()=>process.cwd(),getCompilationSettings:()=>({target:99,module:199,jsx:1}),getDefaultLibFileName:o=>ts.getDefaultLibFilePath(o),fileExists:ts.sys.fileExists,readFile:ts.sys.readFile,readDirectory:ts.sys.readDirectory};
 const service=ts.createLanguageService(host);
 const changes=service.organizeImports({type:'file',fileName:file},{},{});
 let next=text;
 for(const change of changes)if(change.fileName===file)for(const edit of [...change.textChanges].sort((a,b)=>b.span.start-a.span.start))next=next.slice(0,edit.span.start)+edit.newText+next.slice(edit.span.start+edit.span.length);
 if(next!==text)writeFileSync(file,next);
 service.dispose();
}
