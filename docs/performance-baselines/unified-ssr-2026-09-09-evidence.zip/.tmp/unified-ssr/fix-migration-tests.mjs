import ts from 'typescript';
import {readFile,writeFile,readdir} from 'node:fs/promises';
async function walk(dir){for(const e of await readdir(dir,{withFileTypes:true})){if(['node_modules','.git','.tmp','dist','dist-server','dist-bun','dist-client'].includes(e.name))continue;const p=dir+'/'+e.name;if(e.isDirectory()){await walk(p);continue;}if(!/\.test\.tsx?$/.test(p))continue;let s=await readFile(p,'utf8');const sf=ts.createSourceFile(p,s,ts.ScriptTarget.Latest,true),ed=[];
function visit(n){if(ts.isPropertyAccessExpression(n)&&['rejects','resolves'].includes(n.name.text)&&ts.isCallExpression(n.expression)&&n.expression.expression.getText(sf)==='expect'){
const arg=n.expression.arguments[0];if(arg&&ts.isAwaitExpression(arg))ed.push([arg.getStart(sf),arg.expression.getStart(sf),'']);
}ts.forEachChild(n,visit);}visit(sf);for(const [a,b,v]of ed.reverse())s=s.slice(0,a)+v+s.slice(b);if(ed.length)await writeFile(p,s);
}}await walk('.');
let p='packages/ssr/src/hydration.test.tsx',s=await readFile(p,'utf8');
s=s.replace("[renderPublishedRoot('sync'),", "[await renderPublishedRoot('sync'),").replace(/const result = (render\w*PublishedRoot\()/g,'const result = await $1');
for(const name of ['publishes compiler-proven nested root props positionally','retains named root props when runtime values exceed the finite schema','reads compiler-declared positional root fields once into getter-free output','retains named root props when a runtime object substitutes another own field'])s=s.replace("'"+name+"', () =>", "'"+name+"', async () =>");await writeFile(p,s);
p='packages/ssr/src/rendering.test.ts';s=await readFile(p,'utf8');
s=s.replace(/\s*expect\(\(await renderToString\(vnode, \{ markers: false \}\)\).html\).toBe\('<span>loading<\/span>'\);/,'')
 .replace(/\s*expect\(\(await renderToString\(render\(\), \{ markers: false \}\)\).html\).toBe\(\s*'<span class="owned">loading<\/span>'\s*\);/,'')
 .replace(/\s*expect\(\(await renderToString\(render\(\), options\)\).html\).toBe\('<strong><span>loading<\/span><\/strong>'\);/,'')
 .replace('renders native Suspense fallback synchronously and settled content asynchronously','waits for native Suspense content when collecting a string')
 .replace('selected by each SSR mode','after blocking work settles');
await writeFile(p,s);
