# Unified renderer migration

User explicitly authorizes changing unreleased APIs and artifacts rather than preserving compatibility
paths. Do not retain synchronous traversal or Async-named aliases solely for old repository callers.

Target: one traversal and component execution engine; async public completion; ordinary available
work runs synchronously; actual tasks/output backpressure suspend; string/stream are output sinks.
Migrate compiler, callers, tests, docs, release guidance and initial unreleased ABI assumptions together.

Preserved starting source and Node/Bun benchmark artifacts in baseline/ before edits.

Implementation sequence:
1. Shared suspension/continuation primitive and hybrid traversal; protect throw/finally/cancellation.
2. Consolidate entrypoints/compiler lowering; remove duplicate traversal and sync boundary handling.
3. Migrate all repository callers and tests to awaited string results; remove redundant API aliases.
4. Build, framework/task/hydration/ABI tests, actual application browser checks.
5. Focused renderer/HTTP and browser benchmarks, then documentation with measured evidence.

Hypothesis before experiments: eliminating unconditional async boundaries should materially reduce
streaming promise/microtask work (target 5-15% renderer time). Generator/continuation allocation can
offset that improvement, so compare against the frozen build before settling on the execution shape.
Public async string completion should cost much less than making every internal operation async.
No minimum gain threshold governs acceptance; shared correctness and maintainability also matter.

## Current migration, 2026-09-09

- Rejected generator traversal: passed tests but roughly doubled Node renderer time and slowed Bun ~43%. Code retained in rejected-generator/ and generator-probe.json.
- Direct value-or-promise traversal initially improved streaming ~10% Node/~13% Bun. direct-probe.json.
- Removed separate sync walkers and Async-named APIs. Shared modules now children.ts, operation-target.ts, component.ts, render-output.ts, tree-output.ts. Native compiler helper exports collapsed to three proof-preserving wrappers, all promised results.
- Migrated repository callers/tests/docs. Native compiler Go tests and full workspace build passed. check:compiled-abi, check:release-abi, test typecheck, docs typecheck, source architecture, JSDoc checks passed at recorded intermediate revisions. Full final verification still needed after experiments.
- Core task frames own pending readiness and completion revision. Renderer asks blockingWork and only awaits actual pending work. Added core tests for absent/completed/failed work.
- Hydration caught a real timing regression hidden by old awaits: nonblocking shared-context producer had published value but not completed identity. Compiler-selected captured context writers now become publication dependencies in the core task owner. Existing provider/consumer hydration test now passes without browser replay.
- All 258 SSR tests passed after root continuation changes. Core focused 10 tests passed. Full hydration initially found missing awaits in local helpers and a mistakenly awaited pending test render; fixed. Focused adoption/resumption 38 now pass across subsequent runs, rerun full 240 required.
- unified-modes.json caught string regression despite streaming gains. Compared against frozen baseline with both wrappers awaited, full document bytes checked. Hash differs due marker numbering, output remains 3966 bytes.
- Consolidated capture to direct indexed class, restored stateless frame reuse: unified-capture.json. Minimal string gain; stream remains faster. Generic instance bridge removed, class activation projection remains bound through closure.
- Adjacent completed program spans merged: unified-merged-program.json. Small/noisy improvements, fewer deferred segments; common engine retained. program-before-merge.ts saved.
- Shared text/attribute escaping now skips replacement when no escape chars: unified-escaping.json. Node string modestly improved, Bun string still ~50% slower than old sync engine.
- CPU profiles baseline-string.cpuprofile / unified-string.cpuprofile identify extra escaping, continuation dispatch and allocation. No claim that full HTTP or browser benchmarks have been run yet for this migration.
- Eliminated unconditional outer promise hops, public APIs still always promise: unified-root-continuations.json. Preserves desired semantics; no clear gain. Previous render-output source retained.
- Cleanup continuations now allocated only when pending/error: unified-cleanup-continuations.json. Bun string ~55-57us vs old ~36us, Node ~57us vs ~47us. Streaming remains ~15-22% faster. This gap is unresolved and must not be hidden.
- Current experiment: ChildrenOutput retains one sibling-group state, creates callbacks only when a child is pending; no per-child cleanup closures for completed work. Hypothesis 5-10% lower renderer time from allocation removal. children-before-continuations.ts retained. Tests running; focused comparison not yet run.

Remaining: finish experiments to recover string wins on shared engine, clean stale dist outputs/imports/comments/duplicate migrated tests, full SSR/hydration/corpus checks, actual Node/Bun apps in both modes, focused HTTP and browser benchmarks, publish honest evidence artifact and update docs. No compatibility aliases or duplicate traversal allowed. Do not declare experiments exhausted while the string regression remains unexplained.

## Validated migration

- ChildrenOutput experiment retained: Bun string about 10% faster than the earlier candidate, stream about 25% faster than frozen baseline.
- Intrinsic cleanup experiment rejected; archived as intrinsic-rejected.ts and restored the simpler shared cleanup implementation.
- String accumulation in program output retained: removes second output array and join pass; unified-program-string.json.
- Task scheduler allocated on first task, removed obsolete asyncFrame state and dead sync marker rejection. No duplicate sync walker or Async API alias remains.
- Cleaned generated SSR output by moving the previous dist to stale-ssr-dist before forcing a rebuild. Full workspace build passed.
- Import cleanup incorrectly removed two enhancement namespace imports in test fixtures. Restored both. Do not rerun cleanup.mjs over enhancement imports without preserving compiler-owned bindings.
- Replaced duplicate migrated sync/async test calls with string/stream parity and removed redundant identical assertions. Final SSR 258 tests pass, including the parity checks.
- Core readiness 10, hydration 240, composition 59, build scripts 112, comparison 83 tests pass. Test/docs typechecks, architecture, JSDoc, ABI fixtures/release policy and platform boundaries pass.
- Production apps: 56 eXact/React browser checks pass across Node/Bun and string/stream. Owned server processes closed; only pre-existing user docs processes remain.
- Final renderer: final-renderer.json. Node median string 52.86 -> 66.33 us; stream 111.24 -> 94.96. Bun string 36.17 -> 48.49; stream 97.34 -> 72.66. String regression remains an explicit optimization opportunity.
- Final HTTP: 16 populations, zero measured errors. Node string eXact/React 6761/9884 rps; stream 5903/3910. Bun string 8231/11044; stream 6797/8429.
- Browser: 120 measured streaming sessions, no semantic/interaction errors. All approximate paired 95% timing intervals include zero. Local FCP 45.20 -> 45.40ms; constrained 259.00 -> 258.60ms.
- Output comparison verifies exact equality after normalizing only runtime marker ordinals. Both server documents are 3966 bytes without client assets.
- Publishing docs/performance-baselines/unified-ssr-2026-09-09.md/.json/evidence.zip. Historical baselines and public full-suite charts remain unchanged and are explicitly identified as predating this migration.

The API/task-readiness migration is validated. Recovery of the old direct string writer's advantages remains performance work; no claim that reasonable experiments are exhausted or React parity has been reached.
