import ts from 'typescript';
import {readFile,writeFile,readdir} from 'node:fs/promises';
async function removeDeclarations(path,names){
 let source=await readFile(path,'utf8');const sf=ts.createSourceFile(path,source,ts.ScriptTarget.Latest,true);const edits=[];
 for(const node of sf.statements){
  const name=ts.isFunctionDeclaration(node)?node.name?.text:ts.isVariableStatement(node)?node.declarationList.declarations[0]?.name.getText(sf):undefined;
  if(names.includes(name))edits.push([node.getFullStart(),node.end]);
 }
 for(const [start,end] of edits.reverse())source=source.slice(0,start)+source.slice(end);
 await writeFile(path,source);
}
await removeDeclarations('packages/ssr/src/render/entrypoints.ts',['renderToString','renderToStringOwned','renderToHydratableString','renderToStream']);
await removeDeclarations('packages/ssr/src/enhanced.ts',['renderToString','renderToHydratableString']);
await writeFile('packages/ssr/src/compiler-closed.ts',`import type { Child } from '@exactjs/core';
import type { RenderToStringOptions, HydrationScriptOptions } from './types.js';
import { renderStringOutput, renderHydratableOutput } from './render/async-rendering.js';

/** Compiler-proven roots use the shared engine, retaining only their root-boundary proof. */
export function renderCompilerClosedToString(operation: Child, options: RenderToStringOptions = {}) {
 return renderStringOutput(operation, options, false);
}

/** Unmarked compiler roots use the shared engine with their established marker policy. */
export function renderCompilerClosedUnmarkedToString(operation: Child, options: RenderToStringOptions = {}) {
 return renderStringOutput(operation, {...options, markers:false}, true);
}

/** Hydration shares capture and execution with ordinary roots while omitting the proven root marker. */
export function renderCompilerClosedToHydratableString(operation: Child, options: RenderToStringOptions & HydrationScriptOptions = {}) {
 return renderHydratableOutput(operation, options, true);
}
`);
async function walk(directory){
 for(const ent of await readdir(directory,{withFileTypes:true})){
  if(['.git','.tmp','node_modules','dist','dist-server','dist-bun-server','dist-client','history','performance-baselines'].includes(ent.name)||ent.name.startsWith('dist-'))continue;
  const path=directory+'/'+ent.name;if(path.includes('fixtures/release-abi'))continue;
  if(ent.isDirectory()){await walk(path);continue;}
  if(!/\.(ts|tsx|mjs|go|md)$/.test(path))continue;
  const source=await readFile(path,'utf8');
  const output=source.replace(/\brenderToHydratableStringAsync\b/g,'renderToHydratableString').replace(/\brenderToStringAsync\b/g,'renderToString')
   .replace(/\brenderCompilerClosedToHydratableStringAsync\b/g,'renderCompilerClosedToHydratableString').replace(/\brenderCompilerClosedUnmarkedToStringAsync\b/g,'renderCompilerClosedUnmarkedToString').replace(/\brenderCompilerClosedToStringAsync\b/g,'renderCompilerClosedToString');
  if(output!==source)await writeFile(path,output);
 }
}
await walk('.');
let pub=await readFile('packages/ssr/src/public.ts','utf8');
pub=pub.replace('\n\trenderToHydratableString,','').replace('\n\trenderToString\n','\n');
await writeFile('packages/ssr/src/public.ts',pub);
let entry=await readFile('packages/ssr/src/render/entrypoints.ts','utf8');
entry="export { renderToString, renderToHydratableString } from './async-rendering.js';\nexport { renderToStream } from './output-stream.js';\n"+entry;
await writeFile('packages/ssr/src/render/entrypoints.ts',entry);
