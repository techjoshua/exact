import ts from 'typescript';
import { readFile, writeFile, readdir } from 'node:fs/promises';
const names=new Set(['renderToString','renderToHydratableString','renderKeyedListSnapshot','renderCompilerClosedToString','renderCompilerClosedUnmarkedToString','renderCompilerClosedToHydratableString','renderCompilerClosedToHydratableSink']);
const skip=new Set(['.git','.tmp','node_modules','dist','dist-server','dist-bun','dist-client','dist-types','history','performance-baselines']);
async function walk(dir){for(const e of await readdir(dir,{withFileTypes:true})){
 if(skip.has(e.name))continue;
 const path=dir+'/'+e.name;
 if(path.includes('fixtures/release-abi'))continue;
 if(e.isDirectory()){await walk(path);continue;}
 if(!/\.(?:tsx?|mjs)$/.test(path))continue;
 let source=await readFile(path,'utf8');
 if(!/renderToString|renderToHydratableString|renderKeyedListSnapshot|renderCompilerClosed/.test(source))continue;
 if(path.startsWith('./packages/ssr/src/render/')&&!path.includes('.test.'))continue;
 if(path.endsWith('/compiler-closed.ts')||path.endsWith('/enhanced.ts'))continue;
 const sf=ts.createSourceFile(path,source,ts.ScriptTarget.Latest,true,path.endsWith('tsx')?ts.ScriptKind.TSX:ts.ScriptKind.TS);
 const local=new Set();
 for(const st of sf.statements)if(ts.isImportDeclaration(st)){
  const mod=st.moduleSpecifier.text;
  if(!mod.includes('@exactjs/ssr')&&!(path.startsWith('./packages/ssr/')&&/^\.\//.test(mod)))continue;
  for(const el of st.importClause?.namedBindings?.elements??[])if(names.has(el.propertyName?.text??el.name.text))local.add(el.name.text);
 }
 if(!local.size)continue;
 const edits=[],asyncFns=new Set(),handled=new Set();
 const addAsync=node=>{let p=node.parent;while(p&&!ts.isFunctionLike(p))p=p.parent;if(p&&!p.modifiers?.some(m=>m.kind===ts.SyntaxKind.AsyncKeyword))asyncFns.add(p);};
 // Promise rejection assertions consume the call directly instead of a synchronous throw callback.
 const pre=node=>{
  if(ts.isCallExpression(node)&&ts.isPropertyAccessExpression(node.expression)&&/^toThrow/.test(node.expression.name.text)){
   const expectCall=node.expression.expression;
   if(ts.isCallExpression(expectCall)&&expectCall.expression.getText(sf)==='expect'){
    const cb=expectCall.arguments[0];
    if(cb&&ts.isArrowFunction(cb)&&!ts.isBlock(cb.body)&&ts.isCallExpression(cb.body)&&local.has(cb.body.expression.getText(sf))){
     edits.push([cb.getStart(sf),cb.body.getStart(sf),''],[node.expression.name.getStart(sf),node.expression.name.getStart(sf),'rejects.']);
     if(!ts.isAwaitExpression(node.parent))edits.push([node.getStart(sf),node.getStart(sf),'await ']);
     handled.add(cb.body);addAsync(node);
    }
   }
  }
  ts.forEachChild(node,pre);
 };pre(sf);
 const visit=node=>{
  if(ts.isCallExpression(node)&&local.has(node.expression.getText(sf))&&!handled.has(node)&&!ts.isAwaitExpression(node.parent)){
   let parent=node.parent;
   const name=ts.isVariableDeclaration(parent)?parent.name.getText(sf):'';
   // These calls intentionally start rendering so a test can release pending work or cancel it.
   if(/rendering|pending|promise|settlement|renderPromise/i.test(name)){ts.forEachChild(node,visit);return;}
   const wrapped=ts.isPropertyAccessExpression(parent)||ts.isElementAccessExpression(parent);
   edits.push([node.getStart(sf),node.getStart(sf),wrapped?'(await ':'await ']);
   if(wrapped)edits.push([node.end,node.end,')']);
   addAsync(node);
  }
  ts.forEachChild(node,visit);
 };visit(sf);
 for(const fn of asyncFns){
  if(ts.isArrowFunction(fn))edits.push([fn.getStart(sf),fn.getStart(sf),'async ']);
  else {const mods=fn.modifiers??[];const at=mods.length?mods.at(-1).end:fn.getStart(sf);edits.push([at,at,mods.length?' async':'async ']);}
  if(fn.type&&!fn.type.getText(sf).startsWith('Promise<'))edits.push([fn.type.getStart(sf),fn.type.end,'Promise<'+fn.type.getText(sf)+'>']);
 }
 for(const [s,e,v] of edits.sort((a,b)=>b[0]-a[0]||b[1]-a[1]))source=source.slice(0,s)+v+source.slice(e);
 // Deduplicate named imports after the public Async spellings were removed.
 const parsed=ts.createSourceFile(path,source,ts.ScriptTarget.Latest,true);const imports=[];
 for(const st of parsed.statements)if(ts.isImportDeclaration(st)&&st.importClause?.namedBindings&&ts.isNamedImports(st.importClause.namedBindings)){
  const els=st.importClause.namedBindings.elements,seen=new Set(),kept=[];
  for(const el of els){const key=el.getText(parsed);if(!seen.has(key)){seen.add(key);kept.push(key);}}
  if(kept.length!==els.length)imports.push([st.importClause.namedBindings.getStart(parsed),st.importClause.namedBindings.end,'{ '+kept.join(', ')+' }']);
 }
 for(const [s,e,v] of imports.reverse())source=source.slice(0,s)+v+source.slice(e);
 if(edits.length||imports.length){await writeFile(path,source);process.stdout.write(path+'\n');}
}}await walk('.');
