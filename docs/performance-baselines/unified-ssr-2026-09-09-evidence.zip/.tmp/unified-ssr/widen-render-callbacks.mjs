import ts from 'typescript';
import {readFile,writeFile,readdir} from 'node:fs/promises';
const directory='packages/ssr/src/render';
for(const name of await readdir(directory)){
 if(!name.endsWith('.ts')||name.includes('.test.')||name==='execution.ts')continue;
 const path=directory+'/'+name,source=await readFile(path,'utf8');
 const sf=ts.createSourceFile(path,source,ts.ScriptTarget.Latest,true);const edits=[];
 function visit(node){
  if((ts.isFunctionTypeNode(node)||ts.isMethodSignature(node)||((ts.isFunctionDeclaration(node)||ts.isMethodDeclaration(node))&&!node.modifiers?.some(m=>m.kind===ts.SyntaxKind.AsyncKeyword)))&&node.type&&ts.isTypeReferenceNode(node.type)&&node.type.typeName.getText(sf)==='Promise'&&node.type.typeArguments?.[0]?.kind===ts.SyntaxKind.StringKeyword)
   edits.push({start:node.type.typeName.getStart(sf),end:node.type.typeName.end});
  ts.forEachChild(node,visit);
 }visit(sf);
 if(!edits.length)continue;
 let output=source;for(const e of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,e.start)+'RenderValue'+output.slice(e.end);
 if(!/import[^;]*\bRenderValue\b[^;]*from ['"]\.\/execution\.js['"]/.test(output))output="import type { RenderValue } from './execution.js';\n"+output;
 await writeFile(path,output);
}
