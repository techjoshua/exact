import {readFileSync,writeFileSync} from 'node:fs';
let http=readFileSync('.tmp/early-document/http.mjs','utf8');
http=http.replace("const root='.tmp/early-document'","const root='.tmp/unified-ssr'")
 .replace("for(const mode of ['stream'])","for(const mode of ['string','stream'])")
 .replace("population?['candidate','baseline']:['baseline','candidate']","population?['react','candidate']:['candidate','react']")
 .replace("'first-three'","'final'");
writeFileSync('.tmp/unified-ssr/http.mjs',http);
let browser=readFileSync('.tmp/early-document/browser-benchmark.mjs','utf8');
browser=browser.replace('.tmp/post-shell-final/current-exact-node.mjs','.tmp/unified-ssr/baseline/exact-node.mjs')
 .replace('.tmp/early-document/current-node.mjs','framework-comparison/participants/exact/dist-server/server-entry.js')
 .replace("if(p.id==='candidate')assert.deepEqual(html,expectedExact);",'')
 .replaceAll('.tmp/early-document/browser-performance.json','.tmp/unified-ssr/browser-performance.json');
writeFileSync('.tmp/unified-ssr/browser.mjs',browser);
