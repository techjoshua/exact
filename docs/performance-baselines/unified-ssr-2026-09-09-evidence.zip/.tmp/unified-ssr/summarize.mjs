import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const root='.tmp/unified-ssr';
const read=async name=>JSON.parse(await readFile(`${root}/${name}.json`,'utf8'));
const renderer=await read('final-renderer'),http=await read('final-http'),browser=await read('browser-performance');
const mean=a=>a.reduce((sum,v)=>sum+v,0)/a.length;
const median=a=>[...a].sort((a,b)=>a-b)[Math.floor(a.length/2)];
const rendererSummary=[];
for(const runtime of ['v26.8.1','1.4.2'])for(const mode of ['string','stream']){
 const rows=renderer.filter(r=>r.runtime===runtime&&r.mode===mode);
 const before=rows.filter(r=>r.variant==='baseline'),after=rows.filter(r=>r.variant==='candidate');
 assert.equal(before.length,3);assert.equal(after.length,3);
 rendererSummary.push({runtime,mode,baselineUs:median(before.map(r=>r.usPerRender)),candidateUs:median(after.map(r=>r.usPerRender)),pairedTimeRatios:after.map(r=>r.usPerRender/before.find(b=>b.round===r.round).usPerRender)});
}
assert.equal(http.length,16);assert.ok(http.every(r=>r.errors===0));
const httpSummary=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream']){
 const rows=http.filter(r=>r.runtime===runtime&&r.mode===mode);
 const exact=rows.filter(r=>r.variant==='candidate').map(r=>r.rps),react=rows.filter(r=>r.variant==='react').map(r=>r.rps);
 assert.equal(exact.length,2);assert.equal(react.length,2);
 httpSummary.push({runtime,mode,exactRps:mean(exact),reactRps:mean(react),exactSamples:exact,reactSamples:react});
}
const metrics={FCP:r=>r.navigation.firstContentfulPaintMs,readiness:r=>r.readyMs,navigation:r=>r.navigation.durationMs};
const browserSummary=[];
for(const profile of ['local','constrained'])for(const [metric,readMetric] of Object.entries(metrics)){
 const groups=Object.fromEntries(['baseline','candidate','react'].map(id=>[id,browser.rows.filter(r=>r.profile===profile&&r.id===id).sort((a,b)=>a.round-b.round)]));
 for(const rows of Object.values(groups)){assert.equal(rows.length,20);assert.ok(rows.every(r=>Number.isFinite(readMetric(r))));}
 const differences=groups.candidate.map((r,i)=>readMetric(r)-readMetric(groups.baseline[i]));const delta=mean(differences);
 const sd=Math.sqrt(differences.reduce((sum,d)=>sum+(d-delta)**2,0)/(differences.length-1));const margin=1.96*sd/Math.sqrt(differences.length);
 browserSummary.push({profile,metric,...Object.fromEntries(Object.entries(groups).map(([id,rows])=>[id,mean(rows.map(readMetric))])),candidateMinusBaselineMs:delta,approximate95PercentInterval:[delta-margin,delta+margin]});
}
assert.equal(new Set(browser.rows.map(r=>r.responseHash)).size,1);
assert.deepEqual(browser.evidence[0].assets,browser.evidence[1].assets);
for(const evidence of browser.evidence)assert.equal(evidence.requests.length,42);
const summary={rendererSummary,httpSummary,browserSummary};
await writeFile(`${root}/summary.json`,JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify(summary,null,2));
