import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const data=JSON.parse(await readFile('.tmp/positional-leaves/data.json','utf8'));
const entries=['.tmp/unified-ssr/baseline/exact-node.mjs','framework-comparison/participants/exact/dist-server/server-entry.js'];
const html=[];
for(const [index,path] of entries.entries()) {
 const mod=await import(pathToFileURL(resolve(path)));
 html.push(await mod.renderParticipant(data,'/incidents/inc-101',{clientTags:''}));
 await writeFile(`.tmp/unified-ssr/${index?'current':'baseline'}.html`,html[index]);
}
let at=0;while(at<html[0].length&&html[0][at]===html[1][at])at++;
const normalize=s=>s.replace(/(<!--\/?exact:[^:<>]+:)\d+/g,'$1#');
const comparison={firstDifference:at,before:html[0].slice(at-70,at+220),after:html[1].slice(at-70,at+220),equalWithoutRuntimeMarkerOrdinals:normalize(html[0])===normalize(html[1])};
await writeFile('.tmp/unified-ssr/output-comparison.json',JSON.stringify(comparison,null,2)+'\n');
console.log(JSON.stringify(comparison,null,2));
