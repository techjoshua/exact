/** Executes available component work directly, suspending only preparation, descendants, or cleanup. */
export function executeDirectSsrComponent<Result>(
	context: SsrContext,
	contract: ExactServerExecutableComponentContract,
	rawProps: Record<string, unknown>,
	parent: AnyComponentInstance | undefined,
	options: SsrRenderOptions,
	sink: DirectSsrAsyncSink<Result>
): RenderValue<Result | undefined> {
	const artifact = contract.artifact;
	const server = artifact.execution;
	if (server?.lane !== 'direct' || server.classification !== 'synchronous' || !server.render)
		return undefined;
	return mapRenderValue(prepareComponentProps(rawProps, server.deferredTaskProps, options.signal), props => {
		const frame = createSelectedDirectSsrFrame(context, contract, parent);
		const owner = selectedDirectSsrOwner(contract, frame, parent);
		const lifecycle = server.lifecycle as DirectSsrLifecycleCapability | undefined;
		let preparation: DirectIssuedRender['preparation'];
		let checkpoint: unknown;
		let resumptionCheckpoint: number | undefined;
		let attempted = false;
		let published = false;
		return withRenderCleanup(() => {
			let render: unknown;
			if (server.mode !== 'direct' && server.mode !== 'stateless') {
				render = inComponentDomain(context, () => server.render!.call(frame, props));
				if (typeof render !== 'function')
					throw new TypeError('Compiled synchronous server component did not return its render function');
			}
			const started = lifecycle ? performanceNow() : 0;
			const issued = renderIssuedServerComponentChildren(context, options, () =>
				inComponentDomain(context, () => server.mode === 'direct' || server.mode === 'stateless'
					? server.render!.call(frame, props) : (render as () => unknown)()), owner);
			return mapRenderValue(issued, content => {
				lifecycle?.rendered(frame, performanceNow() - started);
				preparation = content.preparation;
				const snapshot = { componentId: artifact.id, contract, host: frame, state: frame.state, props };
				checkpoint = context.onComponentAttemptCheckpoint?.();
				resumptionCheckpoint = context.resumptionCapture?.checkpoint();
				attempted = true;
				const token = context.resumptionCapture?.reserveDirect(artifact.id, contract);
				context.onDirectComponentCreated?.(snapshot);
				return mapRenderValue(sink(content.content, owner, props, snapshot), output => {
					if (token !== undefined) context.resumptionCapture?.publishDirect(token, frame, frame.state, props);
					context.onDirectComponentRendered?.(snapshot);
					published = true;
					return output;
				});
			});
		}, () => {
			if (attempted && !published) {
				if (resumptionCheckpoint !== undefined) context.resumptionCapture?.rollback(resumptionCheckpoint);
				context.onComponentAttemptRollback?.(checkpoint);
			}
			return withRenderCleanup(
				() => preparation?.[Symbol.asyncDispose](),
				() => lifecycle?.dispose(frame, 'ssr render complete')
			);
		});
	});
}
