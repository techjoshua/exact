import ts from 'typescript';
import { readFile, writeFile, unlink, readdir } from 'node:fs/promises';
const base='packages/ssr/src/render/';
const removals={
 'intrinsic-receipt.ts':['renderIntrinsicReceipt'],
 'structural-receipts.ts':['renderKeyedChildReceipt','renderFragmentReceipt','renderTargetReceipt','renderActivityReceipt','renderSuspenseReceipt'],
 'operation-enhancements.ts':['SyncChildren','renderOperationEnhancements','renderEnhancementComponent','renderEnhancementOperation','renderEnhancementOperationChain'],
 'boundaries.ts':['renderServerBoundary','renderServerBoundaryChildren'],
 'native-boundaries.ts':['RenderChildren','renderNativeSuspenseSyncCapability'],
 'server-boundary-capability.ts':['renderServerBoundary'],
 'structural-boundary-capability.ts':['RenderChildrenSync','renderNativeSuspenseSync'],
 'direct-component-scheduling.ts':['disposeDirectSsrLifetimeSync']
};
for(const [file,names] of Object.entries(removals)){
 let source=await readFile(base+file,'utf8');
 const sf=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true);
 const ranges=sf.statements.filter(n=>names.includes(n.name?.text)).map(n=>[n.getFullStart(),n.end]);
 for(const [s,e] of ranges.reverse())source=source.slice(0,s)+source.slice(e);
 if(file==='server-boundary-capability.ts')source=source.replace(/\s*render\(context: SsrContext, boundary: ExactServerBoundaryReceiptData, finite\?: boolean\): string;/,'');
 if(file==='structural-boundary-capability.ts')source=source.replace(/\s*renderSuspenseSync\([\s\S]*?\): SsrSuspenseResult;/,'');
 await writeFile(base+file,source);
}
await writeFile('packages/ssr/src/runtime/structural-boundaries.ts',`import { renderNativeSuspenseAsyncCapability } from '../render/native-boundaries.js';
import { renderServerBoundaryAsync } from '../render/boundaries.js';
import { registerServerBoundaryCapability } from '../render/server-boundary-capability.js';
import { registerSsrStructuralBoundaryCapability } from '../render/structural-boundary-capability.js';

registerSsrStructuralBoundaryCapability({ renderSuspenseAsync: renderNativeSuspenseAsyncCapability });
registerServerBoundaryCapability({ renderAsync: renderServerBoundaryAsync });
`);
for(const file of ['sync-children.ts','sync-operation-target.ts','sync-render-program.ts','sync-component.ts','sync-child-chunks.ts','client-boundary-chunks.ts','server-boundary-chunk-capability.ts'])await unlink(base+file);
let file=base+'server-handlers.ts',s=await readFile(file,'utf8');
s=s.replace("import { renderChildren } from './sync-children.js';","import { renderChildrenAsync } from './async-children.js';")
 .replace(/export function renderKeyedListSnapshot/g,'export async function renderKeyedListSnapshot')
 .replace(/\): KeyedListSnapshot \{/g,'): Promise<KeyedListSnapshot> {')
 .replace('return withTaskObserver(owner.observer, () => renderKeyedListSnapshotOwned(options));','return await withTaskObserver(owner.observer, () => renderKeyedListSnapshotOwned(options));')
 .replace('const itemHtml = markerPair','const itemHtml = await markerPair')
 .replace('renderChildren(context, [child], undefined)','renderChildrenAsync(context, [child], undefined, options)')
 .replace('const next = renderKeyedListSnapshot','const next = await renderKeyedListSnapshot');
await writeFile(file,s);
file='native/typescript-go/overlay/internal/exactcompiler/server_render_entry_lowering.go';s=await readFile(file,'utf8');
s=s.replace(/\n\t*if exportName == "[^"]+" \{\s*return lowering.names.renderClosedSync\w+, true\s*\}/g,'')
 .replace('"renderToString", "renderToHydratableString", "renderToString", "renderToHydratableString"','"renderToString", "renderToHydratableString"');
await writeFile(file,s);
file='native/typescript-go/overlay/internal/exactcompiler/runtime_capability_imports.go';s=await readFile(file,'utf8');
s=s.split('\n').filter(l=>!l.includes('renderClosedSync')).join('\n');await writeFile(file,s);
// Remove imports made obsolete by deleted declarations using TypeScript's own import organizer.
async function walk(dir){for(const ent of await readdir(dir,{withFileTypes:true})){const p=dir+'/'+ent.name;if(ent.isDirectory())await walk(p);else if(p.endsWith('.ts')&&!p.endsWith('.test.ts')){
 let source=await readFile(p,'utf8');
 const host={getScriptFileNames:()=>[p],getScriptVersion:()=> '1',getScriptSnapshot:f=>f===p?ts.ScriptSnapshot.fromString(source):undefined,getCurrentDirectory:()=>process.cwd(),getCompilationSettings:()=>({}),getDefaultLibFileName:()=>'',fileExists:ts.sys.fileExists,readFile:ts.sys.readFile};
 const service=ts.createLanguageService(host);
 for(const change of service.organizeImports({type:'file',fileName:p},{},{}))for(const e of [...change.textChanges].reverse())source=source.slice(0,e.span.start)+e.newText+source.slice(e.span.start+e.span.length);
 service.dispose();await writeFile(p,source);
}}}await walk('packages/ssr/src');
