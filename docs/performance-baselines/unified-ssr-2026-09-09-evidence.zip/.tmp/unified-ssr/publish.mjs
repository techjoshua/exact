import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import os from 'node:os';
const root='.tmp/unified-ssr',output='docs/performance-baselines/unified-ssr-2026-09-09.json';
const read=async name=>JSON.parse(await readFile(`${root}/${name}.json`,'utf8'));
const artifacts=[];
for(const path of ['.tmp/unified-ssr/baseline/exact-node.mjs','.tmp/unified-ssr/baseline/exact-bun.mjs','framework-comparison/participants/exact/dist-server/server-entry.js','framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js','framework-comparison/participants/react/dist-server/server-entry.js','framework-comparison/participants/react/dist-bun-server/bun-server-entry.js']){
 const body=await readFile(path);artifacts.push({path,bytes:body.length,sha256:createHash('sha256').update(body).digest('hex')});
}
const capture={title:'Shared SSR execution',date:'2026-09-09',environment:{node:process.version,bun:'1.4.2',platform:os.platform(),release:os.release(),cpu:os.cpus()[0].model,availableParallelism:os.availableParallelism(),nodeEnv:'production',localWorkload:'Uncontrolled shared Windows workstation'},artifacts,summary:await read('summary'),renderer:await read('final-renderer'),http:await read('final-http'),browser:await read('browser-performance'),outputComparison:await read('output-comparison'),validation:{ssrTests:258,hydrationTests:240,compositionTests:59,taskTests:10,productionBrowserChecks:56,buildScriptTests:112,comparisonTests:83,focusedBrowserSessions:120,checks:['clean workspace build','test typecheck','docs typecheck','source architecture','JSDoc','preserved compiled artifacts','release ABI','platform boundaries']},limitations:['Short local measurements, not a new full capacity benchmark','The isolated string-rendering regression remains unresolved','No head flush during tree traversal','Approximate browser timing intervals include zero']};
await writeFile(output,JSON.stringify(capture,null,2)+'\n');
console.log(output);
