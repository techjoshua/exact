import ts from 'typescript';
import {readFileSync,writeFileSync} from 'node:fs';
function edit(path,fn){writeFileSync(path,fn(readFileSync(path,'utf8')));}
for(const path of ['packages/ssr/src/limits.test.ts','packages/ssr/src/streams.test.tsx'])edit(path,source=>{
 const sf=ts.createSourceFile(path,source,99,true);const edits=[];
 function walk(n){if(ts.isBlock(n)){let previous;for(const statement of n.statements){if(ts.isExpressionStatement(statement)&&previous?.getText(sf)===statement.getText(sf))edits.push([statement.getFullStart(),statement.end]);previous=statement;}}ts.forEachChild(n,walk);}
 walk(sf);for(const [a,b] of edits.sort((a,b)=>b[0]-a[0]))source=source.slice(0,a)+source.slice(b);
 return source.replace('over-deep sync and async operation trees','over-deep operation trees').replace('sync, async, and streaming renders','string and streaming renders');
});
edit('packages/ssr/src/dynamic-component.test.ts',s=>s.replace("import { renderToString }", "import { renderToStream, renderToString }")
 .replace("import { createOperation }", "import { readStreamText } from './test-support/streams.js';\nimport { createOperation }")
 .replace('const sync =','const result =').replace('const async = await renderToString(vnode);','const streamed = await readStreamText(renderToStream(vnode));').replaceAll('sync.html','result.html').replace('expect(async.html)','expect(streamed)'));
edit('packages/ssr/src/rendering.test.ts',s=>s.replace('diffBoundaryHtml, renderToString','diffBoundaryHtml, renderToStream, renderToString')
 .replace("import { createOperation }", "import { readStreamText } from './test-support/streams.js';\nimport { createOperation }")
 .replace('sync and async output','string and streaming output')
 .replace('const asyncResult = await renderToString(vnode, { markers: false });','const streamed = await readStreamText(renderToStream(vnode, { markers: false }));')
 .replace('const asyncResult = await renderToString(render(), options);','const streamed = await readStreamText(renderToStream(render(), options));')
 .replace(/const asyncOutput = await renderToString\(vnode, \{([\s\S]*?)\n\t\t\}\);/,'const streamed = await readStreamText(renderToStream(vnode, {$1\n\t\t}));')
 .replaceAll('const sync =','const result =').replaceAll('sync.html','result.html')
 .replaceAll('expect(asyncResult.html)','expect(streamed)').replaceAll('expect(asyncOutput.html)','expect(streamed)'));
edit('packages/ssr/src/hydration.test.tsx',s=>s.replace(',\n\trenderPublishedRootAsync','')
 .replace('const sync = (await renderToHydratableString(vnode, options)).hydrationScript;','const buffered = (await renderToHydratableString(vnode, options)).hydrationScript;')
 .replace('\n\t\tconst async = (await renderToHydratableString(vnode, options)).hydrationScript;','')
 .replace('[sync, async, progressive]','[buffered, progressive]')
 .replace(/it\('publishes root props from compiler-closed synchronous and asynchronous roots',[\s\S]*?\n\t\}\);/,`it('publishes root props from a compiler-closed root', async () => {
 const result = await renderPublishedRoot('published');
 expect(directHydrationField(result.hydrationScript, 8)).toEqual({label:'published'});
 });`));
edit('packages/ssr/src/hydration.fixtures.test.tsx',s=>s.replace(/\/\*\* Exercises compiler-closed asynchronous SSR[\s\S]*?\n\}\n/,'').replace('compiler-closed synchronous SSR','compiler-closed SSR'));
edit('packages/ssr/src/component-rendering.test.ts',s=>s.replace('waits for async tasks before rendering a component in async mode','waits for pending tasks before rendering a component'));
