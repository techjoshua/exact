import{readFile,writeFile}from'node:fs/promises';
const p='packages/ssr/src/render/intrinsic-receipt.ts';let s=await readFile(p,'utf8');await writeFile('.tmp/unified-ssr/intrinsic-before-continuations.ts',s);
const a=s.indexOf('\tconst host = enterHostTag'),b=s.indexOf('\n/** Normalizes',a);
s="import { attachSuppressedCleanupFailure } from '@exactjs/core';\nimport { noPrimaryFailure } from './ownership.js';\n"+s.slice(0,a)+` const host = enterHostTag(context, receipt.tag);
 const tag = host.tag;
 const previousSelect = context.selectValue;
 let pending = false;
 let primary: unknown = noPrimaryFailure;
 try {
  const hostProps = intrinsicHostProps(context, receipt);
  const attrs = renderAttrs(consumeTargetReceiptLayers(context, hostProps), false, tag, context);
  if (voidElements.has(tag)) return \`\${host.prefix}<\${tag}\${attrs}>\`;
  let content: RenderValue<string>;
  if (tag === 'script' || tag === 'style') content = primitiveText(receipt.children);
  else {
   if (tag === 'select') context.selectValue = unwrap(receipt.props.value ?? receipt.props.defaultValue);
   content = renderChildren(context, tag === 'html' ? normalizeDocumentChildren(receipt.children) : receipt.children, parent, hasComponentAncestor);
  }
  if (content instanceof Promise) {
   pending = true;
   return withRenderCleanup(
    () => content.then(html => \`\${host.prefix}<\${tag}\${attrs}>\${html}</\${tag}>\`),
    () => { context.selectValue = previousSelect; leaveHost(context, tag); }
   );
  }
  return \`\${host.prefix}<\${tag}\${attrs}>\${content}</\${tag}>\`;
 } catch (error) { primary = error; throw error; }
 finally {
  if (!pending) {
   context.selectValue = previousSelect;
   try { leaveHost(context, tag); }
   catch (cleanup) {
    if (primary === noPrimaryFailure) throw cleanup;
    attachSuppressedCleanupFailure(primary, cleanup);
   }
  }
 }
}
`+s.slice(b);
await writeFile(p,s);
