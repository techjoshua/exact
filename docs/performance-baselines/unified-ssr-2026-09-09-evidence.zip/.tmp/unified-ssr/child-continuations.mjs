import{readFile,writeFile}from'node:fs/promises';
const p='packages/ssr/src/render/children.ts';let s=await readFile(p,'utf8');await writeFile('.tmp/unified-ssr/children-before-continuations.ts',s);
const first=s.indexOf('\tlet html =');const end=s.indexOf('\n/** Serializes one opaque',first);
s=s.slice(0,first)+` return new ChildrenOutput(context, children, new SsrOperationTarget(context, parent, options, hasComponentAncestor, renderChildren)).render();
}

/** Ordered child traversal retains continuation state only once per sibling group. */
class ChildrenOutput {
 private html = '';
 private previousWasText = false;
 private index = 0;
 constructor(private readonly context: SsrContext, private readonly children: readonly Child[], private readonly target: SsrOperationTarget) {}
 render(): RenderValue<string> {
  while (this.index < this.children.length) {
   const value = renderChildWithTarget(this.context, this.children[this.index++], this.target);
   if (value instanceof Promise) return value.then(result => { this.append(result); return this.render(); });
   this.append(value);
  }
  return this.html;
 }
 private append(result: { html: string; text: boolean }): void {
  this.html = captureNestedEnhancementStringPrefix(this.context, this.html);
  if (this.context.textSeparators && result.text && this.previousWasText) this.html = appendBoundedHtml(this.context, this.html, '<!-- -->');
  if (result.html !== '') this.html = appendBoundedHtml(this.context, this.html, result.html);
  this.previousWasText = result.text;
 }
}
`+s.slice(end);
const bodyStart=s.indexOf('\tcountSsrNode(context);'),closure=s.indexOf('\t\t() => {',bodyStart),bodyEnd=s.indexOf('\n\t\t},\n\t\t() => leaveSsrTreeDepth',closure);
const body=s.slice(closure+'\t\t() => {'.length,bodyEnd);
const fnEnd=s.indexOf('\nfunction operationResult',bodyEnd);
s=s.slice(0,bodyStart)+` return renderChildWithTarget(context, child, target);
}

/** Holds tree depth until an actually pending child settles, without closures for completed work. */
function renderChildWithTarget(context: SsrContext, child: Child, target: SsrOperationTarget): RenderValue<{ html: string; text: boolean }> {
 countSsrNode(context);
 enterSsrTreeDepth(context);
 let output: RenderValue<{ html: string; text: boolean }>;
 try { output = renderChildValue(context, child, target); }
 catch (error) { leaveSsrTreeDepth(context); throw error; }
 if (output instanceof Promise) return output.finally(() => leaveSsrTreeDepth(context));
 leaveSsrTreeDepth(context);
 return output;
}

function renderChildValue(context: SsrContext, child: Child, target: SsrOperationTarget): RenderValue<{ html: string; text: boolean }> {
${body}
}
`+s.slice(fnEnd);
await writeFile(p,s);
