import ts from 'typescript';import {readFileSync,writeFileSync} from 'node:fs';
const path='packages/ssr/src/rendering.test.ts';let text=readFileSync(path,'utf8');const sf=ts.createSourceFile(path,text,99,true);const edits=[];
function visit(n){if(ts.isVariableDeclaration(n)&&n.name.getText(sf)==='asyncOutput'){
 const call=n.initializer.expression;
 edits.push([n.getStart(sf),n.end,`streamed = await readStreamText(renderToStream(${call.arguments.map(a=>a.getText(sf)).join(', ')}))`]);
}ts.forEachChild(n,visit);}visit(sf);
for(const [a,b,value] of edits.sort((a,b)=>b[0]-a[0]))text=text.slice(0,a)+value+text.slice(b);writeFileSync(path,text);
