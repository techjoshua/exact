import ts from 'typescript';
import {readFile,writeFile} from 'node:fs/promises';
const files=process.argv.slice(2);
for(const file of files){
 const source=await readFile(file,'utf8');
 if(source.includes("from './execution.js'"))continue;
 const sf=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
 const result=ts.transform(sf,[context=>{
  const f=context.factory;
  const asyncModifier=m=>m.kind===ts.SyntaxKind.AsyncKeyword;
  function visit(node){
   if(ts.isAwaitExpression(node))return f.createYieldExpression(f.createToken(ts.SyntaxKind.AsteriskToken),f.createCallExpression(f.createIdentifier('resolveRenderValue'),undefined,[ts.visitNode(node.expression,visit)]));
   if(ts.isTypeReferenceNode(node)&&ts.isIdentifier(node.typeName)&&node.typeName.text==='Promise')return f.updateTypeReferenceNode(node,f.createIdentifier('RenderValue'),ts.visitNodes(node.typeArguments,visit));
   if((ts.isFunctionDeclaration(node)||ts.isMethodDeclaration(node)||ts.isArrowFunction(node)||ts.isFunctionExpression(node))&&node.modifiers?.some(asyncModifier)){
    const modifiers=node.modifiers.filter(m=>!asyncModifier(m));
    const original=ts.isBlock(node.body)?node.body:f.createBlock([f.createReturnStatement(node.body)],true);
    let body=ts.visitNode(original,visit);
    const capture=ts.isMethodDeclaration(node);
    if(capture){function replaceThis(n){return n.kind===ts.SyntaxKind.ThisKeyword?f.createIdentifier('renderReceiver'):ts.visitEachChild(n,replaceThis,context);}body=ts.visitNode(body,replaceThis);}
    const generator=f.createFunctionExpression(undefined,f.createToken(ts.SyntaxKind.AsteriskToken),undefined,undefined,[],undefined,body);
    const run=f.createReturnStatement(f.createCallExpression(f.createIdentifier('executeRender'),undefined,[f.createCallExpression(f.createParenthesizedExpression(generator),undefined,[])]));
    const statements=capture?[f.createVariableStatement(undefined,f.createVariableDeclarationList([f.createVariableDeclaration('renderReceiver',undefined,undefined,f.createThis())],ts.NodeFlags.Const)),run]:[run];
    const wrapped=f.createBlock(statements,true);const type=ts.visitNode(node.type,visit);
    const parameters=ts.visitNodes(node.parameters,visit);
    if(ts.isFunctionDeclaration(node))return f.updateFunctionDeclaration(node,modifiers,node.asteriskToken,node.name,node.typeParameters,parameters,type,wrapped);
    if(ts.isMethodDeclaration(node))return f.updateMethodDeclaration(node,modifiers,node.asteriskToken,node.name,node.questionToken,node.typeParameters,parameters,type,wrapped);
    if(ts.isArrowFunction(node))return f.updateArrowFunction(node,modifiers,node.typeParameters,parameters,type,node.equalsGreaterThanToken,wrapped);
    return f.updateFunctionExpression(node,modifiers,node.asteriskToken,node.name,node.typeParameters,parameters,type,wrapped);
   }
   return ts.visitEachChild(node,visit,context);
  }
  return root=>ts.visitNode(root,visit);
 }]);
 const printed=ts.createPrinter({newLine:ts.NewLineKind.LineFeed}).printFile(result.transformed[0]);result.dispose();
 await writeFile(file,"import { executeRender, resolveRenderValue, type RenderValue } from './execution.js';\n"+printed);
}
