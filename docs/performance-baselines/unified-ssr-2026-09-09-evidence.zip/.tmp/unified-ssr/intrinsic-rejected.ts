import { attachSuppressedCleanupFailure } from '@exactjs/core';
import { noPrimaryFailure } from './ownership.js';
import {
	createCompiledIntrinsicReceipt,
	readCompiledIntrinsicReceipt,
	type ExactIntrinsicReceiptData
} from '@exactjs/core/runtime/component-abi';
import { unwrap } from '@exactjs/reactive/framework/values';
import { voidElements } from '../html.js';
import { renderAttrs } from '../markup.js';
import type { AnyComponentInstance, Child, SsrContext } from '../types.js';
import type { RenderValue } from './execution.js';
import { mapRenderValue, withRenderCleanup } from './execution.js';
import { enterHostTag, leaveHost, primitiveText } from './host.js';
import { consumeTargetReceiptLayers } from './receipt-target-contributions.js';

function intrinsicHostProps(
	context: SsrContext,
	receipt: ExactIntrinsicReceiptData
): Readonly<Record<string, unknown>> {
	if (receipt.tag !== 'option' || context.selectValue === undefined) return receipt.props;
	const value = String(unwrap(receipt.props.value) ?? primitiveText(receipt.children));
	const selected = Array.isArray(context.selectValue)
		? context.selectValue.some((item) => String(unwrap(item)) === value)
		: String(unwrap(context.selectValue)) === value;
	return { ...receipt.props, selected };
}

/** Async counterpart preserving the same host-stack ownership. */
export function renderIntrinsicReceipt(
	context: SsrContext,
	receipt: ExactIntrinsicReceiptData,
	parent: AnyComponentInstance | undefined,
	hasComponentAncestor: boolean,
	renderChildren: (
		context: SsrContext,
		children: readonly Child[],
		parent: AnyComponentInstance | undefined,
		hasComponentAncestor: boolean
	) => RenderValue<string>
): RenderValue<string> {
 const host = enterHostTag(context, receipt.tag);
 const tag = host.tag;
 const previousSelect = context.selectValue;
 let pending = false;
 let primary: unknown = noPrimaryFailure;
 try {
  const hostProps = intrinsicHostProps(context, receipt);
  const attrs = renderAttrs(consumeTargetReceiptLayers(context, hostProps), false, tag, context);
  if (voidElements.has(tag)) return `${host.prefix}<${tag}${attrs}>`;
  let content: RenderValue<string>;
  if (tag === 'script' || tag === 'style') content = primitiveText(receipt.children);
  else {
   if (tag === 'select') context.selectValue = unwrap(receipt.props.value ?? receipt.props.defaultValue);
   content = renderChildren(context, tag === 'html' ? normalizeDocumentChildren(receipt.children) : receipt.children, parent, hasComponentAncestor);
  }
  if (content instanceof Promise) {
   pending = true;
   return withRenderCleanup(
    () => content.then(html => `${host.prefix}<${tag}${attrs}>${html}</${tag}>`),
    () => { context.selectValue = previousSelect; leaveHost(context, tag); }
   );
  }
  return `${host.prefix}<${tag}${attrs}>${content}</${tag}>`;
 } catch (error) { primary = error; throw error; }
 finally {
  if (!pending) {
   context.selectValue = previousSelect;
   try { leaveHost(context, tag); }
   catch (cleanup) {
    if (primary === noPrimaryFailure) throw cleanup;
    attachSuppressedCleanupFailure(primary, cleanup);
   }
  }
 }
}

/** Normalizes a compiler-issued document operation tree without reconstructing topology. */
function normalizeDocumentChildren(children: readonly Child[]): readonly Child[] {
	if (
		children.length === 2 &&
		readCompiledIntrinsicReceipt(children[0])?.tag === 'head' &&
		readCompiledIntrinsicReceipt(children[1])?.tag === 'body'
	)
		return children;
	const classified = children.map((child) => ({
		child,
		tag: readCompiledIntrinsicReceipt(child)?.tag
	}));
	if (classified.some((entry) => entry.tag === undefined)) return children;
	const heads = classified.filter((entry) => entry.tag === 'head');
	const bodies = classified.filter((entry) => entry.tag === 'body');
	if (heads.length > 1) throw new Error('A root document may contain at most one <head> element.');
	if (bodies.length > 1) throw new Error('A root document may contain at most one <body> element.');
	const loose = classified.filter((entry) => entry.tag !== 'head' && entry.tag !== 'body');
	if (bodies.length && loose.length)
		throw new Error(
			'A root document with an authored <body> cannot also contain ambiguous loose content.'
		);
	return [
		heads[0]?.child ?? createCompiledIntrinsicReceipt('head', null),
		bodies[0]?.child ??
			createCompiledIntrinsicReceipt('body', null, ...loose.map((entry) => entry.child))
	];
}
