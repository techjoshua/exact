import { type AnyComponentInstance } from '@exactjs/core';
import {
	readPreparedServerChildRange,
	readPreparedServerKeyedChild,
	readPreparedServerRenderProgram
} from '@exactjs/core/framework/server-render-structure';
import { executeOpaqueOperation } from '@exactjs/core/runtime/component-operations';
import { unwrap } from '@exactjs/reactive/framework/values';
import { escapeText } from '../html.js';
import type { Child, RenderToStringOptions, SsrContext } from '../types.js';
import { SsrOperationTarget } from './operation-target.js';
import { mapRenderValue, withRenderCleanup, type RenderValue } from './execution.js';
import { claimRootText } from './host.js';
import { appendBoundedHtml, countSsrNode, enterSsrTreeDepth, leaveSsrTreeDepth } from './limits.js';
import { captureNestedEnhancementStringPrefix } from './operation-enhancement-routes.js';
import { readServerComponentReference } from './server-component-reference.js';

/** Serializes opaque native operations and scalar children asynchronously. */
export function renderChildren(
	context: SsrContext,
	children: readonly Child[],
	parent: AnyComponentInstance | undefined,
	options: RenderToStringOptions,
	hasComponentAncestor = false
): RenderValue<string> {
	let html = '';
	let previousWasText = false;
	const target = new SsrOperationTarget(
		context,
		parent,
		options,
		hasComponentAncestor,
		renderChildren
	);
	const append = (result: { html: string; text: boolean }) => {
		html = captureNestedEnhancementStringPrefix(context, html);
		if (context.textSeparators && result.text && previousWasText)
			html = appendBoundedHtml(context, html, '<!-- -->');
		if (result.html !== '') html = appendBoundedHtml(context, html, result.html);
		previousWasText = result.text;
	};
	const next = (start: number): RenderValue<string> => {
		for (let index = start; index < children.length; index++) {
			const result = renderChild(
				context,
				children[index],
				parent,
				options,
				hasComponentAncestor,
				target
			);
			if (result instanceof Promise)
				return result.then((value) => {
					append(value);
					return next(index + 1);
				});
			append(result);
		}
		return html;
	};
	return next(0);
}

/** Serializes one opaque native operation or scalar child. */
export function renderChild(
	context: SsrContext,
	child: Child,
	parent: AnyComponentInstance | undefined,
	options: RenderToStringOptions,
	hasComponentAncestor = false,
	target = new SsrOperationTarget(context, parent, options, hasComponentAncestor, renderChildren)
): RenderValue<{ html: string; text: boolean }> {
	countSsrNode(context);
	enterSsrTreeDepth(context);
	return withRenderCleanup(
		() => {
			const program = readPreparedServerRenderProgram(child);
			if (program)
				return mapRenderValue(target.renderPreparedServerProgram(program), operationResult);
			const component = readServerComponentReference(child);
			if (component)
				return mapRenderValue(target.renderDirectServerComponent(component), operationResult);
			const range = readPreparedServerChildRange(child);
			if (range) return mapRenderValue(target.renderDirectServerChildRange(range), operationResult);
			const keyed = readPreparedServerKeyedChild(child);
			if (keyed) return mapRenderValue(target.renderDirectServerKeyedChild(keyed), operationResult);
			const executed = executeOpaqueOperation<string | Promise<string>>(child, target);
			if (executed) return mapRenderValue(executed.value, operationResult);
			const value = unwrap(child);
			if (value === null || value === undefined || value === false || value === true)
				return { html: '', text: false };
			if (typeof value === 'object' || typeof value === 'function')
				throw new TypeError(
					'Native SSR children require compiler-issued operations or scalar values'
				);
			claimRootText(context);
			return { html: escapeText(String(value)), text: true };
		},
		() => leaveSsrTreeDepth(context)
	);
}

function operationResult(html: string): { html: string; text: boolean } {
	return { html, text: false };
}
