import ts from 'typescript';
import { readFile,writeFile,rename } from 'node:fs/promises';
let path='packages/ssr/src/component-rendering.test.ts',s=await readFile(path,'utf8');
const sf=ts.createSourceFile(path,s,ts.ScriptTarget.Latest,true),edits=[];
function visit(n){if(ts.isExpressionStatement(n)&&ts.isCallExpression(n.expression)){
 const name=n.expression.arguments[0]?.text;
 if(['publishes a compiler-closed hydratable root through an ordered string sink','defers a compiler-closed root until an adapter consumes its response body','publishes complete UTF-8 body length after the final compiler-closed span'].includes(name))edits.push([n.getFullStart(),n.end,'']);
}ts.forEachChild(n,visit);}visit(sf);
for(const [a,b,v] of edits.reverse())s=s.slice(0,a)+v+s.slice(b);
s=s.replace(/\s*renderCompilerClosedToHydratableSink,\s*renderCompilerClosedToHydratableResponse,/,'');
s=s.replace("const reference: string[] = [];\n\t\tawait renderCompilerClosedToHydratableSink(operation, (chunk) => reference.push(chunk), { markers });\n\t\tconst expected = reference.join('');", "const reference = await renderCompilerClosedToHydratableString(operation, { markers });\n\t\tconst expected = reference.htmlWithHydration;");
s=s.replace(/const maxOutputBytes = encoder.encode\([\s\S]*?\)\.length;/,'const maxOutputBytes = encoder.encode(reference.html).length;');
s=s.replace(/const chunks: string\[\] = \[\];\s*const bytes = await renderCompilerClosedToHydratableSink\(operation, \(chunk\) => chunks.push\(chunk\), \{\s*markers,\s*maxOutputBytes\s*\}\);\s*expect\(chunks.join\(''\)\).toBe\(expected\);\s*expect\(bytes\).toBe\(encoder.encode\(chunks.join\(''\)\).length\);/, 'const result = await renderCompilerClosedToHydratableString(operation, { markers, maxOutputBytes });\n\t\texpect(result.htmlWithHydration).toBe(expected);');
s=s.replace('renderCompilerClosedToHydratableSink(operation, () => {}, {','renderCompilerClosedToHydratableString(operation, {');
await writeFile(path,s);
path='packages/ssr/src/render/sync-operation-target.test.ts';s=await readFile(path,'utf8');
s=s.replaceAll('SyncSsrOperationTarget','AsyncSsrOperationTarget').replaceAll('./sync-operation-target.js','./async-operation-target.js').replace('synchronous SSR operation target','shared SSR operation target').replaceAll('context, undefined, false,','context, undefined, {}, false,');
await writeFile(path,s);await rename(path,'packages/ssr/src/render/operation-target.test.ts');
