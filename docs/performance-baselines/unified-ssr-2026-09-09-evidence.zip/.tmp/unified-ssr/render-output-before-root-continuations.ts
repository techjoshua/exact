import { withTaskObserver, type Child } from '@exactjs/core';
import { componentDomainUsesWallClock } from '@exactjs/core/framework/component-domains';
import { processExactOutput } from '@exactjs/plugin-host/runtime';
import { publishExactProfile } from '@exactjs/instrumentation';
import { isExactDocumentHtml } from '../document.js';
import { renderHydrationScript } from '../hydration.js';
import { assertOutputWithinLimit, withTaskDeadline } from '../render/limits.js';
import { createSsrResumptionCapture } from '../resumption.js';
import type {
	ExactDocumentStreamEvent,
	HydratableStringResult,
	HydrationScriptOptions,
	RenderToDocumentStreamOptions,
	RenderToStringOptions,
	RenderToStringResult
} from '../types.js';
import { renderChildren } from './children.js';
import { SsrOperationTarget } from './operation-target.js';
import { createSsrContext, drainTasks } from './context.js';
import type { DirectScheduledSsrComponent } from './direct-component-contracts.js';
import { shouldEmitDocumentHydration } from './document-hydration.js';
import type { SsrRenderOptions } from './entrypoints.js';
import { hydrationScriptOptions } from './hydration-options.js';
import { countSsrNode } from './limits.js';
import { SsrOutputBuffer } from './output-buffer.js';
import { createChunkedHydratableResult, createChunkedStringResult } from './output-result.js';
import { createSsrOwner, disposePreservingPrimary, noPrimaryFailure } from './ownership.js';
import { attachSsrRootExecutionBlueprint } from './root-execution-cache.js';
import { rootComponentIdentity, rootPropsForCapture, rootPropsOptions } from './root-props.js';
import { readServerComponentReference } from './server-component-reference.js';
import { planSuspenseStreamReplacements } from './suspense-streaming.js';

/** Transforms to string async into its required representation. */
export async function renderToString(
	operation: Child,
	options: RenderToStringOptions = {}
): Promise<RenderToStringResult> {
	return renderStringOutput(operation, options);
}

/** Owns one complete render independently of whether the result will be accumulated or streamed. */
export async function renderStringOutput(
	operation: Child,
	options: RenderToStringOptions = {},
	omitRootBoundary = false,
	outputKind: 'html' | 'stream' = 'html'
): Promise<RenderToStringResult> {
	const started = options.onProfile ? performance.now() : undefined;
	const owner = createSsrOwner();
	let primary: unknown = noPrimaryFailure;
	try {
		return await withTaskObserver(owner.observer, () =>
			renderTreeOutput(operation, options, omitRootBoundary, outputKind)
		);
	} catch (error) {
		primary = error;
		throw error;
	} finally {
		disposePreservingPrimary(() => owner.dispose('ssr render complete'), primary);
		if (started !== undefined)
			publishExactProfile(
				options.onProfile,
				Object.freeze({
					subsystem: 'ssr',
					phase: 'render-to-string',
					elapsedMs: performance.now() - started
				})
			);
	}
}

async function renderTreeOutput(
	operation: Child,
	options: RenderToStringOptions,
	omitRootBoundary: boolean,
	outputKind: 'html' | 'stream' = 'html'
): Promise<RenderToStringResult> {
	const renderOptions = withTaskDeadline(options);
	const validatedOperation = options.outputExtensions?.length
		? ((await processExactOutput(
				operation,
				{ kind: 'operation', signal: options.signal },
				options.outputExtensions ?? []
			)) as Child)
		: operation;
	const context = createSsrContext(renderOptions);
	attachSsrRootExecutionBlueprint(context, validatedOperation);
	const output = new SsrOutputBuffer(context.maxOutputBytes);
	if (omitRootBoundary) {
		const component = readServerComponentReference(validatedOperation);
		if (!component) throw new TypeError('Compiler root proof requires a component operation');
		countSsrNode(context);
		const rendered = new SsrOperationTarget(
			context,
			undefined,
			renderOptions,
			false,
			renderChildren
		).renderCompilerClosedRootComponent(component);
		output.append(rendered instanceof Promise ? await rendered : rendered);
	} else {
		const rendered = renderChildren(context, [validatedOperation], undefined, renderOptions);
		output.append(rendered instanceof Promise ? await rendered : rendered);
	}
	output.prepend(context.reactResourceHints ?? []);
	let chunks = output.finish();
	if (options.outputExtensions?.length) {
		const html = (await processExactOutput(
			chunks.length === 1 ? chunks[0]! : chunks.join(''),
			{ kind: outputKind, signal: options.signal },
			options.outputExtensions
		)) as string;
		assertOutputWithinLimit(context, html);
		chunks = [html];
	}
	const hydrationTable = context.hydrationTable?.value();
	return createChunkedStringResult(
		chunks,
		options.state,
		hydrationTable,
		context.resourceLinkHeaders ?? [],
		context.componentDomain && componentDomainUsesWallClock(context.componentDomain)
			? context.wallClockSnapshot
			: undefined
	);
}

/** Transforms to hydratable string async into its required representation. */
export async function renderToHydratableString(
	operation: Child,
	options: RenderToStringOptions & HydrationScriptOptions = {}
): Promise<HydratableStringResult> {
	return renderHydratableOutput(operation, options);
}

/** Captures component state once through the shared renderer and creates its hydration publication. */
export async function renderHydratableOutput(
	operation: Child,
	options: RenderToStringOptions & HydrationScriptOptions = {},
	omitRootBoundary = false
): Promise<HydratableStringResult> {
	const prepared = rootPropsOptions(operation, options);
	const capture = createSsrResumptionCapture(
		prepared,
		rootPropsForCapture(operation, prepared),
		rootComponentIdentity(operation)
	);
	const result = await renderStringOutput(operation, capture.options, omitRootBoundary);
	const resumptions = capture.serializedRecords();
	const emittedResumptions = resumptions.length ? () => capture.activations() : prepared.resumptions;
	const hydrationScript = renderHydrationScript(
		{
			...hydrationScriptOptions(
				prepared,
				result,
				resumptions.length && prepared.outputExtensions?.length
					? capture.activations()
					: prepared.resumptions
			),
			...(omitRootBoundary ? { markerlessRoot: true } : {})
		},
		undefined,
		resumptions
	);
	return createChunkedHydratableResult(result, emittedResumptions, hydrationScript);
}

/**
 * Produces shell, settlement, and hydration events with request-owned task cleanup.
 * HTML consumers set settleDocumentShell because a published full document cannot
 * use the fragment replacement protocol. Event-stream consumers retain replacements.
 */
export async function streamDocumentRender(
	operation: Child,
	options: RenderToDocumentStreamOptions & { taskDeadline?: number },
	emit: (event: ExactDocumentStreamEvent) => Promise<void>,
	settleDocumentShell = false
): Promise<void> {
	options = withTaskDeadline(rootPropsOptions(operation, options));
	const owner = createSsrOwner();
	const scheduledShellComponents: DirectScheduledSsrComponent[] = [];
	const disposedShellComponents = new Set<DirectScheduledSsrComponent>();
	let primary: unknown = noPrimaryFailure;
	try {
		await emit({ event: 'start', version: 1 });
		let capture = createSsrResumptionCapture(
			options,
			rootPropsForCapture(operation, options),
			rootComponentIdentity(operation)
		);
		const shellOptions: SsrRenderOptions = {
			...capture.options,
			streamingScheduledComponents: scheduledShellComponents
		};
		const shell = await withTaskObserver(owner.observer, () =>
			renderTreeOutput(operation, shellOptions, false)
		);
		// HTML already sent cannot be replaced as an entire document. Event consumers
		// retain their replacement protocol; HTML consumers publish the settled shell.
		const deferShell =
			settleDocumentShell &&
			isExactDocumentHtml(shell.html) &&
			(owner.pending.size > 0 || scheduledShellComponents.length > 0);
		if (!deferShell) await emit({ event: 'shell', version: 1, html: shell.html });

		let final = shell;
		if (owner.pending.size || scheduledShellComponents.length) {
			// Initial streaming sends an early shell, drains observed tasks, then emits a
			// root replacement only if the settled tree differs from the shell.
			await drainTasks(
				owner.pending,
				options.maxTaskPasses ?? 10,
				options.signal,
				options.taskDeadline
			);
			for (const component of scheduledShellComponents) await component.drain();
			for (const component of scheduledShellComponents) {
				await component[Symbol.asyncDispose]();
				disposedShellComponents.add(component);
			}
			capture = createSsrResumptionCapture(
				options,
				rootPropsForCapture(operation, options),
				rootComponentIdentity(operation)
			);
			final = await withTaskObserver(owner.observer, () =>
				renderTreeOutput(operation, capture.options, false)
			);
			if (!deferShell && final.html !== shell.html) {
				const replacements = planSuspenseStreamReplacements(shell.html, final.html);
				if (replacements) {
					for (const replacement of replacements)
						await emit({ event: 'replace', version: 1, ...replacement });
				} else {
					await emit({
						event: 'replace',
						version: 1,
						id: options.rootId ?? 'document',
						html: final.html
					});
				}
			}
		}

		if (deferShell) await emit({ event: 'shell', version: 1, html: final.html });

		if (shouldEmitDocumentHydration(options)) {
			const resumptions = capture.serializedRecords();
			await emit({
				event: 'hydration',
				version: 1,
				html: renderHydrationScript(
					hydrationScriptOptions(
						options,
						final,
						resumptions.length > 0 && options.outputExtensions?.length
							? capture.activations()
							: options.resumptions
					),
					undefined,
					resumptions
				)
			});
		}

		await emit({ event: 'complete', version: 1 });
	} catch (error) {
		primary = error;
		throw error;
	} finally {
		for (const component of scheduledShellComponents) {
			if (disposedShellComponents.has(component)) continue;
			try {
				await component[Symbol.asyncDispose]();
			} catch (cleanup) {
				if (primary === noPrimaryFailure) throw cleanup;
			}
		}
		disposePreservingPrimary(
			() => owner.dispose(options.signal?.reason ?? 'ssr stream complete'),
			primary
		);
	}
}
