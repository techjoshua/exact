import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const rows=[];
for(const runtime of ['node','bun'])for(let round=0;round<3;round++)for(const variant of round%2?['candidate','baseline']:['baseline','candidate']){
 const entry=variant==='baseline'?'.tmp/unified-ssr/baseline/exact-node.mjs':'framework-comparison/participants/exact/dist-server/server-entry.js';
 const result=spawnSync(runtime,['.tmp/post-shell-optimization/render-worker.mjs',entry,'stream','small','8000'],{env:{...process.env,NODE_ENV:'production'},encoding:'utf8',windowsHide:true});
 if(result.status!==0)throw Error(result.stderr||result.stdout);
 const row={variant,round,...JSON.parse(result.stdout)};rows.push(row);console.log(runtime,round,variant,row.usPerRender);
 writeFileSync('.tmp/unified-ssr/'+(process.argv[2]??'direct-probe')+'.json',JSON.stringify(rows,null,2));
}
