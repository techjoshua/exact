/** An internal render operation finishes immediately unless work actually needs to suspend. */
export type RenderValue<T> = T | Promise<T>;

/** A renderer continuation yields only pending work, preserving ordinary synchronous execution. */
export type RenderContinuation<T> = Generator<PromiseLike<unknown>, T, unknown>;

/**
 * Resolves an internal operation without introducing a promise for available values.
 * The execution driver resumes this continuation with the yielded promise's resolved value.
 */
export function* resolveRenderValue<T>(value: T | PromiseLike<T>): RenderContinuation<T> {
	if (value !== null && (typeof value === 'object' || typeof value === 'function') &&
		typeof (value as PromiseLike<T>).then === 'function')
		return (yield value as PromiseLike<T>) as T;
	return value as T;
}

/**
 * Runs available work on the current stack and resumes only after a yielded promise settles.
 * Rejections enter the generator's catch/finally blocks, including asynchronous cleanup.
 */
export function executeRender<T>(continuation: RenderContinuation<RenderValue<T>>): RenderValue<T> {
	function resume(value: unknown, failed: boolean): RenderValue<T> {
		const next = failed ? continuation.throw(value) : continuation.next(value);
		if (next.done) return next.value;
		return Promise.resolve(next.value).then(
			(result) => resume(result, false),
			(error) => resume(error, true)
		);
	}
	return resume(undefined, false);
}
