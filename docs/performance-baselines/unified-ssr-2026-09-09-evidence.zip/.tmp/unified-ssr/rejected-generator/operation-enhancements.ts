import { executeRender, resolveRenderValue, type RenderValue } from './execution.js';
import { beginRoutes, endRoutes, directRootRoute, markNestedRootRoute } from './operation-enhancement-routes.js';
import { isExactEnhancementPassThrough, logFrameworkEvent, type AnyComponentInstance, type Child, type CompiledEnhancementNode } from '@exactjs/core';
import { createCompiledComponentReceipt } from '@exactjs/core/runtime/component-operations';
import { readPreparedExactServerExecutableComponentContract } from '@exactjs/core/framework/component-contracts';
import type { RenderToStringOptions, SsrContext } from '../types.js';
import { createDeferredSerializedSsrHtmlOperation, createSerializedSsrHtmlOperation } from './serialized-html-operation.js';
type SyncChildren = (context: SsrContext, children: readonly Child[], parent?: AnyComponentInstance, hasComponentAncestor?: boolean) => string;
type AsyncChildren = (context: SsrContext, children: readonly Child[], parent: AnyComponentInstance | undefined, options: RenderToStringOptions, hasComponentAncestor?: boolean) => RenderValue<string>;
/** Applies one operation's enhancement declaration without exposing or rebuilding its topology. */
export function renderOperationEnhancements(context: SsrContext, enhancement: CompiledEnhancementNode | undefined, renderPlain: () => string, parent: AnyComponentInstance | undefined, renderChildren: SyncChildren, plainOperation?: Child): string {
    if (!enhancement)
        return renderPlain();
    if (enhancementUsesTargetReceipt(context, enhancement))
        return renderEnhancementOperationChain(context, enhancement, createDeferredSerializedSsrHtmlOperation(renderPlain), parent, renderChildren);
    const routed = beginRoutes(context, enhancement);
    let output: string;
    try {
        const directRoot = directRootRoute(context, enhancement);
        if (directRoot && plainOperation !== undefined) {
            directRoot.consumed = true;
            return renderEnhancementOperation(context, directRoot.identity, directRoot.props, plainOperation, parent, renderChildren);
        }
        markNestedRootRoute(context, enhancement);
        output =
            plainOperation === undefined
                ? renderPlain()
                : renderEnhancementOperationChain(context, enhancement, plainOperation, parent, renderChildren);
    }
    finally {
        endRoutes(context, routed.length);
    }
    if (plainOperation !== undefined)
        return output;
    for (const entry of [...enhancement.entries].reverse()) {
        if (entry.root !== undefined)
            continue;
        const route = routed.find((candidate) => candidate.identity === entry.identity);
        if (route?.consumed)
            continue;
        if (route?.nested) {
            output = `${renderEnhancementComponent(context, entry.identity, entry.props, route.nestedBefore ?? '', parent, renderChildren)}${output}`;
            route.consumed = true;
        }
        else {
            output = renderEnhancementComponent(context, entry.identity, entry.props, output, parent, renderChildren);
        }
    }
    return output;
}
/** Async enhancement counterpart preserving request-local component ownership. */
export function renderOperationEnhancementsAsync(context: SsrContext, enhancement: CompiledEnhancementNode | undefined, renderPlain: () => RenderValue<string>, parent: AnyComponentInstance | undefined, options: RenderToStringOptions, renderChildren: AsyncChildren, plainOperation?: Child): RenderValue<string> {
    if (!enhancement) {
        try {
            return renderPlain();
        }
        catch (error) {
            return Promise.reject(error);
        }
    }
    return renderEnhancementRoutesAsync(context, enhancement, renderPlain, parent, options, renderChildren, plainOperation);
}
/** Owns and restores routing scope for operations carrying enhancements. */
function renderEnhancementRoutesAsync(context: SsrContext, enhancement: CompiledEnhancementNode, renderPlain: () => RenderValue<string>, parent: AnyComponentInstance | undefined, options: RenderToStringOptions, renderChildren: AsyncChildren, plainOperation?: Child): RenderValue<string> {
    return executeRender((function* () {
        if (enhancementUsesTargetReceipt(context, enhancement))
            return renderEnhancementOperationChainAsync(context, enhancement, createDeferredSerializedSsrHtmlOperation(renderPlain), parent, options, renderChildren);
        const routed = beginRoutes(context, enhancement);
        let output: string;
        try {
            const directRoot = directRootRoute(context, enhancement);
            if (directRoot && plainOperation !== undefined) {
                directRoot.consumed = true;
                return renderEnhancementOperationAsync(context, directRoot.identity, directRoot.props, plainOperation, parent, options, renderChildren);
            }
            markNestedRootRoute(context, enhancement);
            output =
                plainOperation === undefined
                    ? yield* resolveRenderValue(renderPlain()) : yield* resolveRenderValue(renderEnhancementOperationChainAsync(context, enhancement, plainOperation, parent, options, renderChildren));
        }
        finally {
            endRoutes(context, routed.length);
        }
        if (plainOperation !== undefined)
            return output;
        for (const entry of [...enhancement.entries].reverse()) {
            if (entry.root !== undefined)
                continue;
            const route = routed.find((candidate) => candidate.identity === entry.identity);
            if (route?.consumed)
                continue;
            if (route?.nested) {
                output = `${yield* resolveRenderValue(renderEnhancementComponentAsync(context, entry.identity, entry.props, route.nestedBefore ?? '', parent, options, renderChildren))}${output}`;
                route.consumed = true;
            }
            else
                output = yield* resolveRenderValue(renderEnhancementComponentAsync(context, entry.identity, entry.props, output, parent, options, renderChildren));
        }
        return output;
    })());
}
function renderEnhancementComponent(context: SsrContext, identity: string, props: Readonly<Record<string, unknown>>, html: string, parent: AnyComponentInstance | undefined, renderChildren: SyncChildren): string {
    const component = enhancementComponent(context, identity);
    if (!component || isExactEnhancementPassThrough(component))
        return html;
    return renderChildren(context, [
        createCompiledComponentReceipt(component, { ...props }, createSerializedSsrHtmlOperation(html))
    ], parent, true);
}
function renderEnhancementOperation(context: SsrContext, identity: string, props: Readonly<Record<string, unknown>>, operation: Child, parent: AnyComponentInstance | undefined, renderChildren: SyncChildren): string {
    const component = enhancementComponent(context, identity);
    if (!component || isExactEnhancementPassThrough(component))
        return renderChildren(context, [operation], parent, true);
    return renderChildren(context, [createCompiledComponentReceipt(component, { ...props }, operation)], parent, true);
}
function renderEnhancementOperationAsync(context: SsrContext, identity: string, props: Readonly<Record<string, unknown>>, operation: Child, parent: AnyComponentInstance | undefined, options: RenderToStringOptions, renderChildren: AsyncChildren): RenderValue<string> {
    return executeRender((function* () {
        const component = enhancementComponent(context, identity);
        const child = !component || isExactEnhancementPassThrough(component)
            ? operation
            : createCompiledComponentReceipt(component, { ...props }, operation);
        return renderChildren(context, [child], parent, options, true);
    })());
}
function renderEnhancementOperationChain(context: SsrContext, enhancement: CompiledEnhancementNode, leaf: Child, parent: AnyComponentInstance | undefined, renderChildren: SyncChildren): string {
    let chain = leaf;
    for (const entry of [...enhancement.entries].reverse()) {
        if (entry.root !== undefined)
            continue;
        const component = enhancementComponent(context, entry.identity);
        if (!component || isExactEnhancementPassThrough(component))
            continue;
        chain = createCompiledComponentReceipt(component, { ...entry.props }, chain);
    }
    return renderChildren(context, [chain], parent, true);
}
function renderEnhancementOperationChainAsync(context: SsrContext, enhancement: CompiledEnhancementNode, leaf: Child, parent: AnyComponentInstance | undefined, options: RenderToStringOptions, renderChildren: AsyncChildren): RenderValue<string> {
    return executeRender((function* () {
        let chain = leaf;
        for (const entry of [...enhancement.entries].reverse()) {
            if (entry.root !== undefined)
                continue;
            const component = enhancementComponent(context, entry.identity);
            if (!component || isExactEnhancementPassThrough(component))
                continue;
            chain = createCompiledComponentReceipt(component, { ...entry.props }, chain);
        }
        return renderChildren(context, [chain], parent, options, true);
    })());
}
function renderEnhancementComponentAsync(context: SsrContext, identity: string, props: Readonly<Record<string, unknown>>, html: string, parent: AnyComponentInstance | undefined, options: RenderToStringOptions, renderChildren: AsyncChildren): RenderValue<string> {
    return executeRender((function* () {
        const component = enhancementComponent(context, identity);
        if (!component || isExactEnhancementPassThrough(component))
            return html;
        return renderChildren(context, [
            createCompiledComponentReceipt(component, { ...props }, createSerializedSsrHtmlOperation(html))
        ], parent, options, true);
    })());
}
function enhancementComponent(context: SsrContext, identity: string) {
    const component = context.enhancementCatalog?.get(identity);
    if (component)
        return component;
    context.unavailableEnhancements ??= new Set();
    if (!context.unavailableEnhancements.has(identity)) {
        context.unavailableEnhancements.add(identity);
        logFrameworkEvent('warn', 'ssr', 'enhancement', `Optional renderer enhancement "${identity}" is unavailable`, undefined, context.logger);
    }
    return undefined;
}
function enhancementUsesTargetReceipt(context: SsrContext, enhancement: CompiledEnhancementNode): boolean {
    return enhancement.entries.some((entry) => {
        const component = context.enhancementCatalog?.get(entry.identity);
        return (!!component &&
            !isExactEnhancementPassThrough(component) &&
            readPreparedExactServerExecutableComponentContract(component).artifact.capabilities.includes('targets'));
    });
}
