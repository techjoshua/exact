import { expect, it } from 'vitest';
import { executeRender, resolveRenderValue } from './execution.js';

it('completes available nested work without a promise', () => {
	const value = executeRender((function* () {
		return (yield* resolveRenderValue(20)) + (yield* resolveRenderValue(22));
	})());
	expect(value).toBe(42);
});

it('suspends pending work and resumes in order', async () => {
	const gate = Promise.withResolvers<number>();
	const steps: number[] = [];
	const value = executeRender((function* () {
		steps.push(1);
		const result = yield* resolveRenderValue(gate.promise);
		steps.push(result);
		return result;
	})());
	expect(steps).toEqual([1]);
	gate.resolve(2);
	expect(await value).toBe(2);
	expect(steps).toEqual([1, 2]);
});

it('runs asynchronous cleanup when pending work rejects', async () => {
	const failure = new Error('render failed');
	const cleanup = Promise.withResolvers<void>();
	const steps: string[] = [];
	const value = executeRender((function* () {
		try { yield* resolveRenderValue(Promise.reject(failure)); }
		finally {
			steps.push('disposing');
			yield* resolveRenderValue(cleanup.promise);
			steps.push('disposed');
		}
	})());
	await Promise.resolve();
	expect(steps).toEqual(['disposing']);
	cleanup.resolve();
	await expect(value).rejects.toBe(failure);
	expect(steps).toEqual(['disposing', 'disposed']);
});
