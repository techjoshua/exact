import { executeRender, resolveRenderValue, type RenderValue } from './execution.js';
import type { AnyComponentInstance, Child } from '@exactjs/core';
import { readPreparedExactServerExecutableComponentContract } from '@exactjs/core/framework/component-contracts';
import { exactServerDispose, exactServerIssue, exactServerWrite, type ExactHtmlWriter, type ExactRequestExecution, type ExactServerComponentArtifact, type ExactServerFrame } from '@exactjs/core/runtime/component-abi';
import type { SsrContext } from '../types.js';
import { renderDirectSsrContent } from './direct-component-content.js';
import type { DirectIssuedRender, DirectScheduledSsrComponent, DirectSsrComponentPublisher } from './direct-component-contracts.js';
import { executeDirectSsrComponent } from './direct-component.js';
import { createDirectScheduledSsrComponent, takePreparedDirectScheduledSsrComponent } from './direct-component-scheduling.js';
import type { SsrRenderOptions } from './entrypoints.js';
import { disposeAsyncPreservingPrimary, noPrimaryFailure } from './ownership.js';
import type { SsrComponentExecutionBlueprint } from './root-execution-cache.js';
import { receiptExecutionBlueprint, receiptExecutionContract, serverComponentProps, type ServerComponentReference } from './server-component-reference.js';
import { renderOperationEnhancementsAsync } from './operation-enhancements.js';
import { checkpointDocumentHost, restoreDocumentHost } from './host.js';
import { checkpointTargetReceiptLayers, restoreTargetReceiptLayers } from './receipt-target-contributions.js';
type IssuedScheduledServerComponent = ExactServerFrame & {
    readonly artifact: ExactServerComponentArtifact;
    readonly checkpoint: unknown;
    readonly parent: AnyComponentInstance | undefined;
    readonly props: Record<string, unknown>;
    resumptionCheckpoint?: number;
    resumptionToken?: number;
    readonly scheduled: DirectScheduledSsrComponent;
    readonly reference: ServerComponentReference;
    disposed: boolean;
    deferredScheduledDisposal?: boolean;
    preparation?: DirectIssuedRender['preparation'];
};
type ServerArtifactExecution<Publication> = Readonly<{
    context: SsrContext;
    options: SsrRenderOptions;
    publication: Publication;
    publish: DirectSsrComponentPublisher<Publication>;
    renderChildren(children: readonly Child[], parent: AnyComponentInstance | undefined): RenderValue<string>;
    renderOwnedComponent(component: ServerComponentReference, parent: AnyComponentInstance | undefined): RenderValue<string>;
}>;
/**
 * Executes one native server component exclusively through its target-local artifact methods.
 * Issuance owns request state before serialization begins; disposal is attempted exactly once and
 * cleanup failure never replaces the primary render failure.
 */
export function renderServerComponentArtifactOutput<Publication>(context: SsrContext, reference: ServerComponentReference, parent: AnyComponentInstance | undefined, options: SsrRenderOptions, renderChildren: ServerArtifactExecution<Publication>['renderChildren'], renderOwnedComponent: ServerArtifactExecution<Publication>['renderOwnedComponent'], publish: DirectSsrComponentPublisher<Publication>, publication: Publication): RenderValue<string | undefined> {
    return executeRender((function* () {
        const contract = receiptExecutionContract(reference);
        const artifact = contract.artifact;
        const props = serverComponentProps(reference);
        if (artifact.selection) {
            const selected = yield* resolveRenderValue(artifact.selection.resolve());
            return renderServerComponentArtifactOutput(context, {
                ...reference,
                contract: readPreparedExactServerExecutableComponentContract(selected)
            }, parent, options, renderChildren, renderOwnedComponent, publish, publication);
        }
        if (artifact.execution.lane !== 'direct')
            return undefined;
        const execution = {
            context,
            options,
            publication,
            publish,
            renderChildren,
            renderOwnedComponent
        } satisfies ServerArtifactExecution<Publication>;
        if (artifact.execution.classification === 'synchronous')
            return executeSynchronousArtifact(execution, contract, reference, parent, props);
        const blueprint = receiptExecutionBlueprint(reference);
        const frame = (yield* resolveRenderValue(artifact.issue.call(artifact, createRequestExecution(execution, blueprint, reference), parent, props))) as IssuedScheduledServerComponent;
        const output = createHtmlWriter(execution);
        let primary: unknown = noPrimaryFailure;
        try {
            yield* resolveRenderValue(artifact.write.call(artifact, frame, output.writer));
            return output.read();
        }
        catch (error) {
            primary = error;
            if (frame.resumptionCheckpoint !== undefined)
                context.resumptionCapture?.rollback(frame.resumptionCheckpoint);
            context.onComponentAttemptRollback?.(frame.checkpoint);
            throw error;
        }
        finally {
            yield* resolveRenderValue(disposeAsyncPreservingPrimary(() => Promise.resolve(artifact.dispose.call(artifact, frame, primary === noPrimaryFailure ? 'ssr render complete' : primary)), primary));
        }
    })());
}
function createRequestExecution<Publication>(execution: ServerArtifactExecution<Publication>, blueprint: SsrComponentExecutionBlueprint, reference: ServerComponentReference): ExactRequestExecution {
    return {
        [exactServerIssue](artifact, parent, props) {
            const renderReceiver = this;
            return executeRender((function* () {
                assertArtifact(artifact, blueprint.contract.artifact);
                const owner = parent as AnyComponentInstance | undefined;
                const scheduled = yield* resolveRenderValue((takePreparedDirectScheduledSsrComponent(execution.context, reference) ??
                    createDirectScheduledSsrComponent(execution.context, blueprint, props, owner, execution.options)));
                if (!scheduled)
                    throw new TypeError('Scheduled server artifact did not issue a request-local frame');
                const checkpoint = execution.context.onComponentAttemptCheckpoint?.();
                execution.context.onDirectComponentCreated?.(scheduled.snapshot);
                return createIssuedFrame({
                    artifact,
                    checkpoint,
                    parent: owner,
                    props: scheduled.props,
                    scheduled,
                    reference
                });
            })());
        }
    };
}
function createIssuedFrame(frame: Omit<IssuedScheduledServerComponent, keyof ExactServerFrame | 'disposed'>): IssuedScheduledServerComponent {
    const issued: IssuedScheduledServerComponent = {
        ...frame,
        disposed: false,
        [exactServerDispose](artifact: ExactServerComponentArtifact) {
            const renderReceiver = this;
            return executeRender((function* () {
                assertArtifact(artifact, frame.artifact);
                if (issued.disposed)
                    return;
                issued.disposed = true;
                if (issued.preparation) {
                    const preparation = issued.preparation;
                    issued.preparation = undefined;
                    yield* resolveRenderValue(preparation[Symbol.asyncDispose]());
                }
                if (!issued.deferredScheduledDisposal)
                    yield* resolveRenderValue(frame.scheduled[Symbol.asyncDispose]());
            })());
        }
    };
    return issued;
}
function createHtmlWriter<Publication>(execution: ServerArtifactExecution<Publication>): Readonly<{
    writer: ExactHtmlWriter;
    read(): string;
}> {
    let output: string | undefined;
    return {
        writer: {
            [exactServerWrite](artifact, candidate) {
                const renderReceiver = this;
                return executeRender((function* () {
                    const frame = candidate as IssuedScheduledServerComponent;
                    assertArtifact(artifact, frame.artifact);
                    if (frame.disposed)
                        throw new Error('Cannot write a disposed server component frame');
                    output = yield* resolveRenderValue(writeScheduledFrame(execution, frame));
                })());
            }
        },
        read() {
            if (output === undefined)
                throw new Error('Server component artifact completed without output');
            return output;
        }
    };
}
function writeScheduledFrame<Publication>(execution: ServerArtifactExecution<Publication>, frame: IssuedScheduledServerComponent): RenderValue<string> {
    return executeRender((function* () {
        frame.resumptionCheckpoint = execution.context.resumptionCapture?.checkpoint();
        frame.resumptionToken = execution.context.resumptionCapture?.reserveDirect(frame.scheduled.snapshot.componentId, frame.scheduled.snapshot.contract);
        const scheduled = frame.scheduled;
        if (!execution.options.streamingScheduledComponents)
            yield* resolveRenderValue(scheduled.drain());
        for (let pass = 0; pass < execution.context.maxTaskPasses; pass++) {
            const renderCheckpoint = execution.context.onComponentAttemptCheckpoint?.();
            const resumptionCheckpoint = execution.context.resumptionCapture?.checkpoint();
            const targetCheckpoint = checkpointTargetReceiptLayers(execution.context);
            const documentCheckpoint = checkpointDocumentHost(execution.context);
            const issued = yield* resolveRenderValue(scheduled.render());
            frame.preparation = issued.preparation;
            let primary: unknown = noPrimaryFailure;
            try {
                const html = yield* resolveRenderValue(renderOperationEnhancementsAsync(execution.context, frame.reference.enhancement, () => renderDirectSsrContent(execution.context, issued.content, scheduled.owner, execution.renderChildren, execution.renderOwnedComponent), scheduled.owner, execution.options, (_context, children, parent) => execution.renderChildren(children, parent)));
                if (execution.options.streamingScheduledComponents) {
                    frame.deferredScheduledDisposal = true;
                    execution.options.streamingScheduledComponents.push(scheduled);
                    return publishFrame(execution, frame, html, scheduled.snapshot);
                }
                if (yield* resolveRenderValue(scheduled.drain())) {
                    if (resumptionCheckpoint !== undefined)
                        execution.context.resumptionCapture?.rollback(resumptionCheckpoint);
                    execution.context.onComponentAttemptRollback?.(renderCheckpoint);
                    restoreTargetReceiptLayers(execution.context, targetCheckpoint);
                    restoreDocumentHost(execution.context, documentCheckpoint);
                    continue;
                }
                return publishFrame(execution, frame, html, scheduled.snapshot);
            }
            catch (error) {
                primary = error;
                if (resumptionCheckpoint !== undefined)
                    execution.context.resumptionCapture?.rollback(resumptionCheckpoint);
                execution.context.onComponentAttemptRollback?.(renderCheckpoint);
                restoreTargetReceiptLayers(execution.context, targetCheckpoint);
                restoreDocumentHost(execution.context, documentCheckpoint);
                throw error;
            }
            finally {
                yield* resolveRenderValue(disposeFramePreparation(frame, primary));
            }
        }
        throw new Error(`eXact direct scheduled SSR component did not stabilize after ${execution.context.maxTaskPasses} render passes`);
    })());
}
function executeSynchronousArtifact<Publication>(execution: ServerArtifactExecution<Publication>, contract: import('@exactjs/core/framework/component-contracts').ExactServerExecutableComponentContract, reference: ServerComponentReference, parent: AnyComponentInstance | undefined, props: Record<string, unknown>): RenderValue<string> {
    return executeRender((function* () {
        const output = yield* resolveRenderValue(executeDirectSsrComponent(execution.context, contract, props, parent, execution.options, (content, owner, preparedProps, snapshot) => {
            return executeRender((function* () {
                const html = yield* resolveRenderValue(renderOperationEnhancementsAsync(execution.context, reference.enhancement, () => renderDirectSsrContent(execution.context, content, owner, execution.renderChildren, execution.renderOwnedComponent), owner, execution.options, (_context, children, childParent) => execution.renderChildren(children, childParent)));
                return execution.publish(execution.context, reference, parent, html, preparedProps, snapshot, execution.publication);
            })());
        }));
        if (output === undefined)
            throw new TypeError('Synchronous server artifact did not execute its request-owned sink');
        return output;
    })());
}
function publishFrame<Publication>(execution: ServerArtifactExecution<Publication>, frame: IssuedScheduledServerComponent, html: string, snapshot: DirectScheduledSsrComponent['snapshot']): string {
    const output = execution.publish(execution.context, frame.reference, frame.parent, html, frame.props, snapshot, execution.publication);
    if (frame.resumptionToken !== undefined)
        execution.context.resumptionCapture?.publishDirect(frame.resumptionToken, snapshot.host, snapshot.state, frame.props);
    execution.context.onDirectComponentRendered?.(snapshot);
    return output;
}
function disposeFramePreparation(frame: IssuedScheduledServerComponent, primary: unknown): RenderValue<void> {
    return executeRender((function* () {
        if (!frame.preparation)
            return;
        const preparation = frame.preparation;
        frame.preparation = undefined;
        yield* resolveRenderValue(disposeAsyncPreservingPrimary(() => Promise.resolve(preparation[Symbol.asyncDispose]()), primary));
    })());
}
function assertArtifact(actual: ExactServerComponentArtifact, expected: ExactServerComponentArtifact): void {
    if (actual !== expected)
        throw new TypeError('Server component ABI received a frame owned by another artifact');
}
