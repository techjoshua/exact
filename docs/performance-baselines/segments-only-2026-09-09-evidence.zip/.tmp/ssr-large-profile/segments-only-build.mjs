import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
let source=readFileSync(dir+'callback-current.mjs','utf8');
function replace(before,after,count){
 if(source.split(before).length-1!==count)throw Error('Unexpected occurrences: '+before);
 source=source.replaceAll(before,after);
}
replace('return { segments: output };','return output;',1);
replace('renderPreparedSsrProgram(context, content.program, parent).segments','renderPreparedSsrProgram(context, content.program, parent)',1);
replace('planned.segments','planned',2);
writeFileSync(dir+'segments-only.mjs',source);
