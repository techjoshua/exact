import {spawn} from 'node:child_process';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import os from 'node:os';
os.setPriority(0,10);
const root='.tmp/ssr-large-profile/',rows=[];
for(const runtime of ['node','bun'])for(const order of [['normal','sampled','cached'],['cached','sampled','normal']])for(const variant of order){
 const entry=variant==='normal'?root+'direct-execution-integrated/server-entry.js':root+'assembly-phase-'+(variant==='cached'?'cached':'normal')+'/server-entry.js';
 const result=await new Promise((resolve,reject)=>{
  const child=spawn(runtime,[root+'hydration-phase-worker.mjs',entry,'encoded','small','20000'],{env:{...process.env,NODE_ENV:'production'},windowsHide:true});
  let out='',err='';child.stdout.on('data',d=>out+=d);child.stderr.on('data',d=>err+=d);child.on('error',reject);child.on('exit',code=>code===0?resolve(JSON.parse(out)):reject(Error(err||String(code))));
 });
 assert.equal(result.processPriority,10);
 if(rows.length)assert.equal(result.hash,rows[0].hash);
 rows.push({variant,...result});await fs.writeFile(root+'assembly-phase-results.json',JSON.stringify(rows,null,2));
 console.log(runtime,variant,result.usPerRender.toFixed(2),result.cpuMicrosPerRender.toFixed(2),result.phases?.counts??0);
}
