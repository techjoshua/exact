import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
for(const variant of ['normal','cached']){
 let source=await fs.readFile(root+(variant==='normal'?'direct-execution-integrated/server-entry.js':'stage-hydration-node/server-entry.js'),'utf8');
 const phases=[['publication','function renderHydrationScript(options = {}, resumptionLayouts, capturedResumptions) {','\n}'],['assembly','function createChunkedHydratableResult(result, resumptions, hydrationScript) {','\n}']];
 for(let index=0;index<phases.length;index++){
  const [,signature,endToken]=phases[index];const start=source.indexOf(signature);assert.ok(start>=0);
  const end=source.indexOf(endToken,start)+endToken.length;
  const body=source.slice(start+signature.length,end-endToken.length);
  // A try/finally retains the original return expression and records successful or failed calls.
  const replacement=signature+`\n const auditSample=auditEnabled&&((auditCalls[${index}]++&31)===0);const auditStart=auditSample?performance.now():0;\n try {`+body+`\n } finally {if(auditSample)auditSamples[${index}][auditCounts[${index}]++]=performance.now()-auditStart;}\n}`;
  source=source.slice(0,start)+replacement+source.slice(end);
 }
 const getter='return data.materialized ??= data.chunks.length === 1 ? data.chunks[0] : data.chunks.join("");';
 assert.equal(source.split(getter).length,2);
 source=source.replace(getter,`const auditSample=auditEnabled&&((auditCalls[2]++&31)===0);const auditStart=auditSample?performance.now():0;try {${getter}}finally{if(auditSample)auditSamples[2][auditCounts[2]++]=performance.now()-auditStart;}`);
 source+=`\nlet auditEnabled=false;const auditCalls=[0,0,0],auditCounts=[0,0,0],auditSamples=[new Float64Array(2000),new Float64Array(2000),new Float64Array(2000)];\nexport function auditReset(){auditEnabled=true;auditCalls.fill(0);auditCounts.fill(0);}\nexport function auditRead(){return {names:['publication','assembly','finalJoin'],calls:auditCalls,counts:auditCounts,samples:auditSamples.map((a,i)=>Array.from(a.subarray(0,auditCounts[i])))};}\n`;
 await fs.mkdir(root+'assembly-phase-'+variant,{recursive:true});await fs.writeFile(root+'assembly-phase-'+variant+'/server-entry.js',source);
}
let runner=await fs.readFile(root+'hydration-phase-run.mjs','utf8');
runner=runner.replace("[['normal','sampled'],['sampled','normal']]","[['normal','sampled','cached'],['cached','sampled','normal']]");
runner=runner.replace("root+'hydration-phase/server-entry.js'","root+'assembly-phase-'+(variant==='cached'?'cached':'normal')+'/server-entry.js'").replaceAll('hydration-phase-results.json','assembly-phase-results.json');
runner=runner.replace('result.phases?.count??0','result.phases?.counts??0');
await fs.writeFile(root+'assembly-phase-run.mjs',runner);
console.log('Built sampled publication, result assembly, and final join diagnostics.');
