import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
const rows=JSON.parse(await fs.readFile(root+'assembly-phase-results.json','utf8'));assert.equal(rows.length,12);
const output=[];
for(const runtime of ['v26.8.1','1.4.2'])for(const variant of ['normal','sampled','cached']){
 const group=rows.filter(r=>r.runtime===runtime&&r.variant===variant);
 const phases=group[0].phases?.names.map((name,i)=>{
  const values=group.flatMap(r=>r.phases.samples[i].map(ms=>ms*1000)).sort((a,b)=>a-b);
  return {name,meanUs:values.reduce((s,v)=>s+v,0)/values.length,medianUs:values[Math.floor(values.length/2)],p90Us:values[Math.floor(values.length*.9)]};
 });
 output.push({runtime,variant,elapsedUs:group.reduce((s,r)=>s+r.usPerRender,0)/group.length,phases});
}
await fs.writeFile(root+'assembly-phase-summary.json',JSON.stringify(output,null,2));console.log(JSON.stringify(output,null,2));
