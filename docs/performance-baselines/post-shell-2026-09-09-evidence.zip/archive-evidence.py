"""Archive local benchmark evidence without duplicating the separately published raw captures."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

repo = Path.cwd().resolve()
destination = repo / 'docs/performance-baselines'
for folder, stem, entire in [
    ('.tmp/post-shell-final', 'post-shell-2026-09-09', False),
    ('.tmp/post-shell-optimization', 'post-shell-optimization-2026-09-09', True),
]:
    root = (repo / folder).resolve()
    files = []
    for path in root.rglob('*'):
        if not path.is_file():
            continue
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise RuntimeError(f'Unexpected linked evidence: {path}')
        if entire or path.suffix in ('.log', '.mjs', '.png', '.py') or path.name in (
            'execution.json', 'publication-validation.json', 'process-cleanup.json',
            'docs-verification.json', 'current-build-verification.json',
            'final-artifact-verification.json', 'capacity-summary.json',
            'multi-plan.json', 'normal-plan.json', 'arrivals-plan.json',
        ):
            files.append(path)
    archive_path = destination / (stem + '-evidence.zip')
    with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(files):
            archive.write(path, path.relative_to(root).as_posix())
    digest = hashlib.file_digest(archive_path.open('rb'), 'sha256').hexdigest()
    metadata_path = destination / (stem + '.json')
    metadata = json.loads(metadata_path.read_text(encoding='utf-8'))
    metadata['evidenceBundle'] = {
        'path': archive_path.relative_to(repo).as_posix(),
        'sha256': digest,
        'bytes': archive_path.stat().st_size,
        'files': len(files),
    }
    metadata_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    markdown_path = destination / (stem + '.md')
    markdown = markdown_path.read_text(encoding='utf-8')
    markdown = re.sub(r'\nEvidence bundle SHA-256: `[^`]+`\.\n?', '\n', markdown)
    markdown_path.write_text(markdown.rstrip() + f'\n\nEvidence bundle SHA-256: `{digest}`.\n', encoding='utf-8')
    with zipfile.ZipFile(archive_path) as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f'Corrupt evidence entry: {bad}')
    print(json.dumps({'archive': str(archive_path), 'files': len(files), 'bytes': archive_path.stat().st_size, 'sha256': digest}))
