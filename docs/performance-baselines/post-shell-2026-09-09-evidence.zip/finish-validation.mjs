import {spawnSync} from 'node:child_process';
import {openSync,closeSync,writeFileSync,copyFileSync} from 'node:fs';
import {resolve} from 'node:path';
const root='.tmp/post-shell-final';
copyFileSync(root+'/docs-build.log',root+'/docs-build-root-cwd-attempt.log');
const checks=[];
for(const [name,args] of [
 ['docs-build',['apps/docs/scripts/build.mjs']],
 ['docs-browser',[root+'/verify-docs.mjs']],
 ['evidence-validation',[root+'/verify-evidence.mjs']]
]){
 const fd=openSync(root+'/'+name+'.log','w');
 let result;
 try{result=spawnSync(process.execPath,args.map(arg=>resolve(arg)),{cwd:name==='docs-build'?resolve('apps/docs'):process.cwd(),stdio:['ignore',fd,fd],windowsHide:true});}
 finally{closeSync(fd);}
 checks.push({name,args,code:result.status,signal:result.signal,at:new Date().toISOString()});
 writeFileSync(root+'/publication-validation.json',JSON.stringify(checks,null,2));
 console.log(name,result.status);
 if(result.status!==0)process.exit(result.status??1);
}
