import {readFile,writeFile} from 'node:fs/promises';
const prefix='docs/performance-baselines/post-shell-2026-09-09';
const archive=JSON.parse(await readFile(`${prefix}.json`,'utf8'));
const baseline=JSON.parse(await readFile('docs/performance-baselines/render-modes-2026-09-09.json','utf8'));
const rows=[];
for(const mode of ['string','stream'])for(const runtime of ['node','bun'])for(const concurrency of [16,32,64,128]){
 const capacity=(mode==='string'?archive.capacities:archive.capacitiesStream)[runtime];
 const pick=name=>capacity.preloaded.find(r=>r.name===name&&r.concurrency===concurrency).rps;
 const previous=(mode==='string'?baseline.capacities:baseline.capacitiesStream)[runtime].preloaded.find(r=>r.name==='eXact'&&r.concurrency===concurrency).rps;
 rows.push({mode,runtime,concurrency,baselineExactRps:previous,exactRps:pick('eXact'),reactRps:pick('React'),ratio:pick('eXact')/pick('React')});
}
archive.relativeComparison={throughput:rows};
await writeFile(`${prefix}.json`,JSON.stringify(archive,null,2)+'\n');
const lines=['## Relative performance against React','','Ratios divide eXact valid RPS by React valid RPS within the same runtime and rendering API. Above 1 means higher eXact throughput. The frozen baseline uses the same full-document APIs and workload plans. Historical changes still include host variation; the focused alternating-build investigation provides stronger evidence of optimization effects.','','| Runtime | API | Concurrency | Baseline eXact RPS | Current eXact RPS | Current React RPS | eXact / React |','| --- | --- | ---: | ---: | ---: | ---: | ---: |',...rows.map(r=>`| ${r.runtime} | ${r.mode} | ${r.concurrency} | ${r.baselineExactRps.toFixed(0)} | ${r.exactRps.toFixed(0)} | ${r.reactRps.toFixed(0)} | ${r.ratio.toFixed(3)} |`),''];
const markdown=await readFile(`${prefix}.md`,'utf8');
await writeFile(`${prefix}.md`,markdown.replace('## Browser results',lines.join('\n')+'\n## Browser results'));
console.log('Added within-lane relative throughput for both APIs.');
