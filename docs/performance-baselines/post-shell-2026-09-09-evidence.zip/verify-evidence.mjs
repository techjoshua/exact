import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
const path = 'docs/performance-baselines/post-shell-2026-09-09.json';
const archive = JSON.parse(await readFile(path, 'utf8'));
for (const source of Object.values(archive.sources)) {
  assert.equal(createHash('sha256').update(await readFile(source.path)).digest('hex'), source.sha256);
}
const report = JSON.parse(await readFile('apps/docs/src/data/performance-report.json', 'utf8'));
assert.deepEqual(report.metadata.browserSource, archive.sources.browser);
assert.equal(report.metadata.browserCommit, archive.harness.browser.commit);
assert.deepEqual(report.browserCharts, archive.report.browserCharts);
for (const runtime of ['node', 'bun']) {
  const published = JSON.parse(await readFile(`apps/docs/src/data/ssr-${runtime === 'bun' ? 'bun-' : ''}capacity-report.json`, 'utf8'));
  assert.deepEqual(published, archive.capacities[runtime]);
}
for (const runtime of ['node','bun']) assert.deepEqual(JSON.parse(await readFile('apps/docs/src/data/ssr-'+runtime+'-stream-capacity-report.json','utf8')),archive.capacitiesStream[runtime]);
const stream = JSON.parse(await readFile('apps/docs/src/data/ssr-stream-report.json','utf8'));assert.deepEqual(stream.server,archive.streamReport.server);
archive.validation = {
  rawCaptureHashesVerified: Object.keys(archive.sources).length,
  browserArtifactIdentity: 'Matched browser, heap, and startup captures for all five participants',
  capacityAdmission: Object.values(archive.capacities).map(capacity => capacity.validation).join('; '),
  correctness: 'Per runtime: 35 string-mode and 21 streaming-mode browser contracts passed',
  docs: 'Typecheck, ten tests, standalone build, desktop/mobile table-data and overflow checks passed',
  sourceChecks: 'Source architecture, JSDoc, changed-file formatting, and diff whitespace checks passed',
  hostLimit: 'Ordinary desktop processes remained running; their background activity was not measured',
  cleanup: 'No task-owned benchmark server, driver, browser, or compiler process remained'
};
await writeFile(path, JSON.stringify(archive, null, 2) + '\n');
console.log(`Verified ${Object.keys(archive.sources).length} raw capture hashes and all public report projections.`);
