
import fs from 'node:fs';import assert from 'node:assert/strict';import {setTimeout as pause} from 'node:timers/promises';import {createHash} from 'node:crypto';
const root='.tmp/post-shell-final/';
while(true){const steps=JSON.parse(fs.readFileSync(root+'execution.json'));if(steps.some(s=>s.code!==undefined&&s.code!==0))throw Error('Prerequisite failed');if(steps.some(s=>s.name==='bun-preparation'&&s.code===0))break;await pause(250);}
const checks={};for(const [id,path] of Object.entries({node:'framework-comparison/participants/exact/dist-server/server-entry.js',bun:'framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js'})){
 const source=fs.readFileSync(path,'utf8');for(const text of ['participants/exact/src/Document.tsx','renderCompilerClosedToHydratableString','normalizeDocumentChildren'])assert.ok(source.includes(text),id+': '+text);
 checks[id]={path,sha256:createHash('sha256').update(source).digest('hex'),applicationDocument:true,publicHydratableDocumentPath:true};
}
const adapter=fs.readFileSync('framework-adapters/node-adapter/dist/handler.js','utf8');assert.ok(adapter.includes('setBodyByteLength(bytes)'));assert.ok(adapter.includes("response.hasHeader('content-length')"));
const server=fs.readFileSync('packages/ssr/dist/compiler-closed.js','utf8');assert.ok(server.includes('setBodyByteLength'));
checks.responseBytePublication=true;
const snapshots={};for(const packageName of ['react','react-dom']){const walk=path=>{for(const entry of fs.readdirSync(path,{withFileTypes:true})){const file=path+'/'+entry.name;if(entry.isDirectory())walk(file);else if(/\.(js|json)$/.test(file))snapshots[file]=createHash('sha256').update(fs.readFileSync(file)).digest('hex');}};walk('framework-comparison/node_modules/'+packageName);}
fs.writeFileSync(root+'current-build-verification.json',JSON.stringify({createdAt:new Date().toISOString(),checks,externalReactRuntime:snapshots},null,2));console.log('Current production Node/Bun document builds and external React runtime fingerprinted.');
