import re
from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'fused-json';root.mkdir(exist_ok=True)
s=Path('framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js').read_text();(root/'current.mjs').write_text(s)
start=s.index('function validatePositionalValue(');end=s.index('\nfunction pushValidationPath',start);v=s[start:end]
v=v.replace('? value : positionalUnsafe','? JSON.stringify(value) : positionalUnsafe')
v=v.replace('return validateValue(value, depth, state) ? JSON.stringify(value) : positionalUnsafe;', "throw Error('Fused diagnostic requires primitive schema-zero cells');")
v=v.replace('const output = new Array(value.length);','let output = "[";').replace('const output = new Array(fieldCount);','let output = "[";')
v=v.replace('output[index] = encoded;','output += (index ? "," : "") + encoded;').replace('output[outputIndex++] = encoded;','output += (outputIndex++ ? "," : "") + encoded;').replace('return output;','return output + "]";')
c=s[:start]+v+s[end:]
def projector(m):
 body=m[2];raw=set(re.findall(r'const (cell\d+) = state\.project',body))
 body=re.sub(r'if \(!state\.validate\((cell\d+),', lambda x: 'if ('+x[1]+" !== null && typeof "+x[1]+" === 'object') throw Error('Fused diagnostic requires primitive projector cells');\nif (!state.validate("+x[1]+',',body)
 body=re.sub(r'const output = new Array\(\d+\);','let output = "[";',body)
 def field(x):
  prefix='", "' # replaced below with exact JSON comma
  value=x[2] if x[2] in raw else 'JSON.stringify('+x[2]+')'
  return 'output += '+ ('"," + ' if int(x[1]) else '')+value+';'
 body=re.sub(r'output\[(\d+)\] = (cell\d+);',field,body).replace('return output;','return output + "]";')
 return m[1]+body+m[3]
c,n=re.subn(r'(\], 1, \(value, depth, state, schema, Object, Array\) => \{)(.*?)(\n\t+\}\))',projector,c,flags=re.S);assert n==7,n
c=c.replace('[publication.componentId, encoded]','new FusedPositionalJson("["+JSON.stringify(publication.componentId)+","+encoded+"]")')
helper='''class FusedPositionalJson { constructor(json){this.json=json;} }
function stringifyFusedEnvelope(payload,replacer){
 if(Array.isArray(payload)&&payload.some(value=>value instanceof FusedPositionalJson)){
  if(replacer)throw Error('Fused diagnostic does not support reactive collection replacers');
  let json='[';for(let i=0;i<payload.length;i++){if(i)json+=',';const value=payload[i];json+=value instanceof FusedPositionalJson?value.json:JSON.stringify(value);}
  return json+']';
 }
 return JSON.stringify(payload,replacer);
}
'''
needle='return JSON.stringify(payload, replacer).replace';assert c.count(needle)==1;c=c.replace(needle,'return stringifyFusedEnvelope(payload, replacer).replace')
c=helper+c;(root/'candidate.mjs').write_text(c)
(root/'worker.mjs').write_bytes((base/'prefix-native/worker.mjs').read_bytes())
r=(base/'prefix-native-run.mjs').read_text().replace('prefix-native/','fused-json/').replace('large96-bun-native-prefix-experiment','large96-bun-fused-positional-json')
(base/'fused-json-run.mjs').write_text(r)
