import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'render-entry-batch',{recursive:true});
let source=(await fs.readFile(root+'component-forwarding-integrated/server-entry.js','utf8')).replaceAll('\r\n','\n');
const ast=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const target=ast.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text==='renderHydratableOutput');
if(!target)throw Error('Missing render entry');
const at=target.body.getStart(ast)+1;
source=source.slice(0,at)+"if(auditStage==='batch'&&!auditLoopMode){options.signal?.throwIfAborted();await auditRenderQueue();options.signal?.throwIfAborted();}"+source.slice(at);
source=`let auditStage='none',auditLoopMode=false,auditPendingBatch,auditCounts={batches:0,requests:0,max:0};
function auditRenderQueue(){return new Promise(resolve=>{
 if(auditPendingBatch){auditPendingBatch.push(resolve);return;}
 auditPendingBatch=[resolve];setImmediate(()=>{const batch=auditPendingBatch;auditPendingBatch=undefined;++auditCounts.batches;auditCounts.requests+=batch.length;auditCounts.max=Math.max(auditCounts.max,batch.length);for(const resolve of batch)resolve();});
});}
`+source+`
export function auditClearCounts(){auditCounts={batches:0,requests:0,max:0};}
export function auditReset(){auditStage='none';auditClearCounts();}
export function auditSelect(stage){if(!['none','batch'].includes(stage))throw Error('Invalid stage');auditStage=stage;}
export function auditRead(){return {stage:auditStage,counts:{...auditCounts},ready:true};}
export function auditSetLoopMode(value){auditLoopMode=value;}
`;
await fs.writeFile(root+'render-entry-batch/server-entry.js',source);
let worker=(await fs.readFile(root+'hydration-ablation/worker.mjs','utf8')).replaceAll('\r\n','\n');
const start="if(pathname==='/__exact-benchmark/audit-loop'){";
if(!worker.includes(start))throw Error('Missing loop control');
worker=worker.replace(start,start+'auditModule.auditSetLoopMode(true);');
const end='auditModule.auditReset();writeJson(response,snapshot);return;';
if(!worker.includes(end))throw Error('Missing loop reset');
worker=worker.replace(end,'auditModule.auditReset();auditModule.auditSetLoopMode(false);writeJson(response,snapshot);return;');
await fs.writeFile(root+'render-entry-batch/worker.mjs',worker);
let runner=(await fs.readFile(root+'tree-ablation-run.mjs','utf8')).replaceAll('tree-ablation/','render-entry-batch/').replaceAll('within-worker-tree-substitution','within-worker-framework-entry-batch').replaceAll("'none','tree','none'","'none','batch','none'");
await fs.writeFile(root+'render-entry-batch-run.mjs',runner);
let check=(await fs.readFile(root+'tree-ablation-check.mjs','utf8')).replaceAll('tree-ablation/','render-entry-batch/').replace("['none','tree']","['none','batch']").replace("assert.equal(snapshot.counts.tree,stage==='tree'?0:1);","assert.equal(snapshot.counts.requests,stage==='batch'?1:0);");
await fs.writeFile(root+'render-entry-batch-check.mjs',check);
console.log('Built queue inside framework hydration entry; no HTTP worker deferral');
