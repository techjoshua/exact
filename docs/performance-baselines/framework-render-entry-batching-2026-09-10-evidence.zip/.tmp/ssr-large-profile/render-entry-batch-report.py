import hashlib,json,zipfile
from pathlib import Path
from statistics import mean
base=Path('.tmp/ssr-large-profile');folder=base/'render-entry-batch'
data=json.loads((folder/'capture.json').read_text());assert data['complete']
extra=json.loads((folder/'extra-checks.json').read_text());assert extra['distinctConcurrentDocuments']==16 and extra['queuedAbort']
rows=[]
for population in (0,1):
    blocks=[b for b in data['blocks'] if b['population']==population]
    assert [b['phase'] for b in blocks]==['none','batch','none']
    b=blocks[1];normal=mean(c['rps'] for c in (blocks[0],blocks[2]));counts=b['after']['ablation']['counts']
    assert counts['requests']==b['after']['telemetry']['statistics']['renderMs']['count']
    for c in blocks:
        for k in ('loopBefore','loopAfter'):assert c[k]['ablation']['counts']['requests']==0
    rows.append(dict(population=population+1,normalRps=normal,batchRps=b['rps'],gainPct=(b['rps']/normal-1)*100,meanBatchSize=counts['requests']/counts['batches']))
valid=sum(b['valid'] for b in data['blocks']);errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages']);assert errors==0
(folder/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid,errors=errors),indent=2))
report=Path('docs/performance-baselines/framework-render-entry-batching-2026-09-10.md')
lines=['# Batching at the framework render entry, 2026-09-10','',
'Hypothesis: the large worker-level batching gain survives moving the wait into renderHydratableOutput, before root props preparation, hydration capture and render-owner creation. This locates a possible framework-owned boundary without changing the engine or sink API.', '',
'The prototype transforms the frozen compiled artifact at that function boundary. It does not modify production package source or establish a public scheduling API. The HTTP worker performs no scheduling delay. A shared setImmediate resolves the waiting Promise batch; every render then continues through the existing implementation. AbortSignal is checked before queueing and after release, before render resources are created. Queued cancellation settles at batch release, not synchronously when the signal aborts.', '',
'Two fresh production Node 26.8.1 workers each run normal/batch/normal, ten seconds warmup and five-second blocks with two load drivers holding 16 requests each. Controls are averaged within each worker. Before/after isolated loops warm and measure 10,000 renders with queueing bypassed, verified by counters. Workstation load can vary.', '',
'| Worker | Normal RPS | Framework-entry batch RPS | Gain | Mean batch size |','| --- | ---: | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['population']} | {r['normalRps']:,.0f} | {r['batchRps']:,.0f} | {r['gainPct']:+.2f}% | {r['meanBatchSize']:.2f} |")
lines+=['',f'All {valid:,} measured responses matched the complete 4,672-byte document, with zero errors. Four ordinary/escaped output parity checks pass. Sixteen concurrent distinct documents match sequential retained-renderer results in one shared batch. Pre-aborted and queued-aborted renders reject with the original reason; a subsequent render succeeds. These are focused prototype checks, not comprehensive cancellation/lifecycle or browser validation.', '',
'The extra-check fixture explicitly supplies an empty clientTags string. Omitting it also failed the unmodified participant because its root hydration props contain undefined clientTags. That existing fixture/API issue is independent of this scheduling experiment.', '',
'Unlike earlier worker-level scheduling, queue wait is now inside the outer render timer. Its elapsed duration includes waiting and interleaving, and must not be compared as exclusive CPU work with the previous timer. Complete-response throughput remains comparable within each paired run.', '',
'The result supports the framework entry as a viable experimental boundary. Production work still needs platform/configuration policy, bounded queue fairness and retention, low-concurrency validation, streaming head timing, browser tests and full integration checks. No production or React baseline changes are claimed. The adjacent archive preserves raw data and verified SHA-256 inventory.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[report]+[base/n for n in ('render-entry-batch-build.mjs','render-entry-batch-run.mjs','render-entry-batch-check.mjs','render-entry-batch-extra-check.mjs','render-entry-batch-report.py','tree-ablation-run.mjs','tree-ablation-check.mjs','hydration-ablation/worker.mjs','component-forwarding-integrated/server-entry.js')]
files=sorted(set(p for p in files if p.is_file()));archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(rows);print(valid,'valid',len(files),'verified files')
