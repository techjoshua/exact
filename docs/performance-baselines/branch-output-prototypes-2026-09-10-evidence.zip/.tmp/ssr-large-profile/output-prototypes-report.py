import hashlib
import json
import zipfile
from pathlib import Path
from statistics import mean

base=Path('.tmp/ssr-large-profile');summaries={}
for name in ('branch-output','merged-output'):
    data=json.loads((base/name/'capture.json').read_text());assert data['complete']
    rows=[]
    for population in (0,1):
        blocks=[b for b in data['blocks'] if b['population']==population]
        assert [b['phase'] for b in blocks]==['none','reuse','none']
        controls=[blocks[0],blocks[2]];b=blocks[1]
        assert b['after']['ablation']['counts']['reused']>0
        def render(x):
            s=x['after']['telemetry']['statistics']['renderMs'];return s['sum']/s['count']*1000
        def loop(x):return mean(x[k]['meanMs'] for k in ('loopBefore','loopAfter'))*1000
        normal=mean(c['rps'] for c in controls)
        rows.append(dict(population=population+1,normalRps=normal,candidateRps=b['rps'],gainPct=(b['rps']/normal-1)*100,
                         normalHttpUs=mean(render(c) for c in controls),candidateHttpUs=render(b),normalLoopUs=mean(loop(c) for c in controls),candidateLoopUs=loop(b)))
    valid=sum(b['valid'] for b in data['blocks']);errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages']);assert errors==0
    summaries[name]=dict(rows=rows,valid=valid,errors=errors)
    (base/name/'summary.json').write_text(json.dumps(summaries[name],indent=2))
allocations=[]
for file in sorted((base/'merged-output').glob('allocation-*.heapprofile')):
    profile=json.loads(file.read_text())
    allocations.append(dict(file=str(file),mode=file.stem.split('-')[-1],sampledBytesPerRender=sum(s['size'] for s in profile['samples'])/10000))
assert len(allocations)==4
(base/'merged-output/allocations.json').write_text(json.dumps(allocations,indent=2))
report=Path('docs/performance-baselines/branch-output-prototypes-2026-09-10.md')
lines=['# Branching output ownership prototypes, 2026-09-10','','## Design','',
'Extend the earlier leaf-only facade experiment to branching programs that do',
'not own prepared siblings. An AST proof excludes generated functions accessing',
'output members other than sink. Runtime source review confirms ordinary child',
'writing forwards through the target without mutating output preparation.',
'This marks 21 writer definitions eligible and four ineligible.', '',
'The first prototype caches an output wrapper on its traversal target while its',
'sink is unchanged. It reduces fixture output-wrapper creation from 24 to 20.',
'Most nested programs use different targets, limiting reuse. The second prototype',
'lets the existing target represent output directly by supplying sink/render/',
'prepareReferences members. It reduces separate output-wrapper creation to six,',
'using the target directly for 18 invocations. It rejects member collisions,',
'unexpected preparation and sink changes. Capture/function-target paths retain',
'ordinary output objects. These guards are diagnostic restrictions, not a complete',
'production capability design.', '',
'Both execute the actual component tree and all generated writer operations.',
'Document-host entry/exit and preparation-owning programs retain the original',
'flow. No HTML, hydration, component state or result is precalculated. A production',
'design would require compiler-owned capability metadata, explicit target fields',
'and complete capture/ownership coverage; source inspection is not a public ABI.', '',
'## Validation and measurement','',
'Four ordinary/escaped document parity checks pass for each prototype. The merged',
'prototype also passes twelve forced-pressure/failure comparisons on Node and',
'twelve on Bun using the portable artifact: small/large string renders, selected',
'drain failures and complete stream output. These are not native Bun HTTP results.', '',
'Two fresh Node string workers per prototype run normal/candidate/normal after',
'ten seconds of HTTP warmup. Blocks last five seconds, with two fresh drivers each',
'holding 16 requests in flight. Controls average adjacent normal blocks in the',
'same worker. Separate isolated loops before/after each block warm and measure',
'10,000 renders. Artifact and adapter hashes remain unchanged.', '',
'| Prototype | Worker | Normal RPS | Candidate RPS | Change |',
'| --- | ---: | ---: | ---: | ---: |']
for name,summary in summaries.items():
    for r in summary['rows']:lines.append(f"| {name} | {r['population']} | {r['normalRps']:,.0f} | {r['candidateRps']:,.0f} | {r['gainPct']:+.2f}% |")
lines+=['','All measured responses match the complete 4,672-byte document, zero errors.',
'Raw render timings and per-worker blocks are preserved in the archive.', '',
'## Allocation follow-up','',
'After HTTP completed, four separate Node workers compare normal/merged in both',
'orders. Each warms 50,000 renders and samples 10,000 at a 16 KiB interval,',
'including objects collected by minor and major GC. These estimate allocation',
'volume, not retained heap, exact counts or GC pause time.', '',
'| Sample | Mode | Sampled bytes/render |','| --- | --- | ---: |']
for i,r in enumerate(allocations):lines.append(f"| {i+1} | {r['mode']} | {r['sampledBytesPerRender']:,.0f} |")
lines+=['','Eliminating wrapper constructions does not remove all their fields: the merged',
'prototype adds output fields to existing objects. Shape changes and property',
'storage can offset object savings. The data do not isolate those costs, and',
'constructor count is not an allocation-byte measurement.', '',
'## Decision','',
'Do not adopt these dynamic target-mutation prototypes as a performance win.',
'Any follow-up must explain what a fixed-layout combined target/output removes',
'that these implementations retain, then test that specific hypothesis. Preserve',
'preparation ownership and sink identity. The broader Node/Bun string/stream goal',
'remains open. No production source was changed for these prototypes.', '',
'## Evidence','']
for name,s in summaries.items():lines.append(f"- {name}: {s['valid']:,} validated measured responses.")
lines+=['','The adjacent archive contains builders, checks, runners, raw HTTP and allocation',
'captures, summaries, current/diagnostic artifacts, fixture and verified SHA-256',
'inventory. Workspace dependencies are not a standalone distribution.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=[report,Path('.tmp/positional-leaves/data.json'),base/'component-forwarding-integrated/server-entry.js',base/'hydration-ablation/worker.mjs',base/'tree-ablation-run.mjs',base/'tree-ablation-check.mjs',base/'output-prototypes-report.py',base/'merged-output-build.mjs',base/'merged-output-generated-build.mjs',base/'merged-output-pressure.mjs',base/'merged-output-allocation-worker.mjs']
for name in summaries:
    files+=list((base/name).glob('*'))+[base/(name+s) for s in ('-build.mjs','-run.mjs','-check.mjs')]
files=sorted(set(f for f in files if f.is_file()));archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={f.as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in files:z.write(f,f.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps(summaries,indent=2));print(json.dumps(allocations,indent=2));print(len(files),'verified files')
