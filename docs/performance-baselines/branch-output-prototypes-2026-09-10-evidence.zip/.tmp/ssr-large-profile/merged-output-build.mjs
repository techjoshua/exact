import fs from 'node:fs/promises';
let builder=await fs.readFile('.tmp/ssr-large-profile/branch-output-build.mjs','utf8');
builder=builder.replaceAll('branch-output','merged-output').replaceAll('within-worker-branch-output-reuse','within-worker-merged-output');
const start=builder.indexOf('function auditOutput(context,target){');
const end=builder.indexOf('\nexport function auditClearCounts()',start);
if(start<0||end<0)throw Error('Missing factory');
builder=builder.slice(0,start)+`function auditOutput(context,target){
 if(target.context!==context||target.preparation!==undefined)throw Error('Target cannot represent output');
 if(target.sink!==undefined&&target.sink!==context.writerSink)throw Error('Sink changed during merged output');
 if(target.sink===undefined){
  if(target.render!==undefined||target.prepareReferences!==undefined)throw Error('Output member collision');
  target.sink=context.writerSink;target.render=auditMergedRender;target.prepareReferences=auditMergedPrepare;
 }
 ++auditCounts.reused;return target;
}
function auditMergedRender(value){return this.renderProgramSegment(value);}
function auditMergedPrepare(values){return this.prepareProgramReferences(values);}
`+builder.slice(end);
await fs.writeFile('.tmp/ssr-large-profile/merged-output-generated-build.mjs',builder);
await import('./merged-output-generated-build.mjs');
