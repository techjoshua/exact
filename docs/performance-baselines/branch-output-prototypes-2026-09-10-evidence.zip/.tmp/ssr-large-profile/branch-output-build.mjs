import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'branch-output',{recursive:true});
const source=(await fs.readFile(root+'component-forwarding-integrated/server-entry.js','utf8')).replaceAll('\r\n','\n');
const ast=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const edits=[];let eligible=0,ineligible=0,hook=0;
function visit(n){
 if(ts.isPropertyAssignment(n)&&n.name.getText(ast)==='ssr'&&(ts.isFunctionExpression(n.initializer)||ts.isArrowFunction(n.initializer))){
  let safe=true;
  function inspect(c){
   if(ts.isPropertyAccessExpression(c)&&c.expression.getText(ast)==='__exactOutput'&&c.name.text!=='sink')safe=false;
   if(ts.isElementAccessExpression(c)&&c.expression.getText(ast)==='__exactOutput')safe=false;
   ts.forEachChild(c,inspect);
  }inspect(n.initializer);
  if(safe){eligible++;edits.push({start:n.initializer.getStart(ast),end:n.initializer.getStart(ast),text:'Object.assign('},{start:n.initializer.end,end:n.initializer.end,text:',{auditOutputShareable:true})'});}else ineligible++;
 }
 if(ts.isFunctionDeclaration(n)&&n.name?.text==='renderProgramWriter'){
  function inspect(c){
   if(ts.isVariableDeclaration(c)&&c.name.getText(ast)==='output'){
    const original=c.initializer.getText(ast);
    edits.push({start:c.initializer.getStart(ast),end:c.initializer.end,text:`auditStage==='reuse'&&context.writerSink&&typeof render!=='function'&&invocation.program.ssr.auditOutputShareable?auditOutput(context,render):(auditCounts.created++,${original})`});hook++;
   }
   ts.forEachChild(c,inspect);
  }inspect(n.body);
 }
 ts.forEachChild(n,visit);
}
visit(ast);if(hook!==1||!eligible)throw Error('Missing output boundaries');
let output=source;for(const e of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,e.start)+e.text+output.slice(e.end);
output=`let auditStage='none',auditCounts={created:0,reused:0};\n`+output+`
function auditOutput(context,target){
 const previous=target.auditSharedOutput;
 if(previous&&previous.sink===context.writerSink){++auditCounts.reused;return previous;}
 ++auditCounts.created;
 return target.auditSharedOutput={context,sink:context.writerSink,target,render:renderWriterTargetSegment,prepareReferences:prepareWriterTargetReferences};
}
export function auditClearCounts(){auditCounts={created:0,reused:0};}
export function auditReset(){auditStage='none';auditClearCounts();}
export function auditSelect(stage){if(!['none','reuse'].includes(stage))throw Error('Invalid stage');auditStage=stage;}
export function auditRead(){return {stage:auditStage,counts:{...auditCounts},ready:true};}
`;
await fs.writeFile(root+'branch-output/server-entry.js',output);
await fs.writeFile(root+'branch-output/sites.json',JSON.stringify({eligible,ineligible,hook}));
await fs.copyFile(root+'hydration-ablation/worker.mjs',root+'branch-output/worker.mjs');
let runner=(await fs.readFile(root+'tree-ablation-run.mjs','utf8')).replaceAll('tree-ablation/','branch-output/').replaceAll('within-worker-tree-substitution','within-worker-branch-output-reuse').replaceAll("'none','tree','none'","'none','reuse','none'");
await fs.writeFile(root+'branch-output-run.mjs',runner);
let check=(await fs.readFile(root+'tree-ablation-check.mjs','utf8')).replaceAll('tree-ablation/','branch-output/').replace("['none','tree']","['none','reuse']").replace("assert.equal(snapshot.counts.tree,stage==='tree'?0:1);","assert.ok(snapshot.counts.created>0);if(stage==='none')assert.equal(snapshot.counts.reused,0);");
await fs.writeFile(root+'branch-output-check.mjs',check);
console.log({eligible,ineligible,hook});
