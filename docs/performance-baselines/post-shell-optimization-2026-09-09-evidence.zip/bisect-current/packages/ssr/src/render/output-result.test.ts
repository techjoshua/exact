import { describe, expect, it } from 'vitest';
import { hydratableChunksOf } from './output-buffer.js';
import { createChunkedHydratableResult, createChunkedStringResult } from './output-result.js';

describe('chunked SSR results', () => {
	it('places hydration before the final body close regardless of chunk boundaries or tag case', () => {
		const html = '<!doctype html><html><body><template></body></template>Ready</BoDy></html>';
		const expected = html.replace(
			'Ready</BoDy>',
			'Ready<!--exact:framework-body:start-->hydrate<!--exact:framework-body:end--></BoDy>'
		);
		for (let split = 0; split <= html.length; split++) {
			const result = createChunkedStringResult(
				[html.slice(0, split), '', html.slice(split)],
				undefined
			);
			expect(createChunkedHydratableResult(result, [], 'hydrate').htmlWithHydration).toBe(expected);
		}
		const characters = createChunkedStringResult([...html], undefined);
		expect(createChunkedHydratableResult(characters, [], 'hydrate').htmlWithHydration).toBe(
			expected
		);
	});

	it('rejects a normalized document without its body close', () => {
		const result = createChunkedStringResult(
			['<!doctype html><html><body>Ready</html>'],
			undefined
		);
		expect(() => createChunkedHydratableResult(result, [], 'hydrate')).toThrow(
			'missing its closing </body>'
		);
	});

	it('inserts document hydration across a split body-close token without joining', () => {
		const result = createChunkedStringResult(
			['<!doctype html><html><body>Ready</bo', 'dy></html>'],
			undefined
		);
		const hydrated = createChunkedHydratableResult(result, [], '<script>hydrate()</script>');
		const chunks = hydratableChunksOf(hydrated)!;

		expect(chunks.length).toBeGreaterThan(2);
		expect(chunks.join('')).toBe(
			'<!doctype html><html><body>Ready<!--exact:framework-body:start--><script>hydrate()</script><!--exact:framework-body:end--></body></html>'
		);
	});
});
