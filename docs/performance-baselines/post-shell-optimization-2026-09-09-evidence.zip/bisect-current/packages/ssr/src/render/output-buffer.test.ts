import { describe, expect, it, vi } from 'vitest';
import { SsrOutputBuffer, utf8ByteLength } from './output-buffer.js';

describe('SSR output buffering', () => {
	it('matches native UTF-8 length and limits at every split in mixed text', () => {
		const value = `${'a'.repeat(64)}\ud800x\ud83d\ude80\udc00\u00e9\u65e5\ud800`;
		const expected = new TextEncoder().encode(value).byteLength;
		for (let split = 0; split <= value.length; split++) {
			const output = new SsrOutputBuffer(expected);
			output.append(value.slice(0, split));
			output.append(value.slice(split));
			expect(output.encodedBytes()).toBe(expected);
			const bounded = new SsrOutputBuffer(expected - 1);
			expect(() => {
				bounded.append(value.slice(0, split));
				bounded.append(value.slice(split));
				bounded.finish();
			}).toThrow('output exceeds');
		}
	});

	it('counts UTF-8 without allocating an encoded copy', () => {
		expect(utf8ByteLength('plain')).toBe(5);
		expect(utf8ByteLength('café')).toBe(5);
		expect(utf8ByteLength('\ud83d\ude80')).toBe(4);
		expect(utf8ByteLength('\ud800')).toBe(3);
	});

	it('accounts for surrogate pairs split across renderer chunks', () => {
		const output = new SsrOutputBuffer(4);
		output.append('\ud83d');
		output.append('\ude80');

		expect(output.finish()).toEqual(['\ud83d', '\ude80']);
	});

	it('uses an environment byte-length operation without weakening split-surrogate accounting', () => {
		const encodedByteLength = vi.fn(utf8ByteLength);
		const output = new SsrOutputBuffer(9, undefined, encodedByteLength);
		output.append('caf\u00e9');
		output.append('\ud83d');
		output.append('\ude80');

		expect(output.encodedBytes()).toBe(9);
		expect(encodedByteLength).toHaveBeenCalledOnce();
		expect(encodedByteLength).toHaveBeenCalledWith('caf\u00e9');
	});

	it('joins compiler-known byte facts across surrogate boundaries', () => {
		const output = new SsrOutputBuffer(4);
		output.accountKnown('\ud83d', 3);
		output.accountKnown('\ude80', 3);
		output.appendAccounted('\ud83d\ude80');

		expect(output.finish()).toEqual(['\ud83d\ude80']);
	});

	it('charges a compiler-proven byte-closed program as one span', () => {
		const output = new SsrOutputBuffer(8);
		output.accountKnown('\ud800', 3);
		output.accountClosedBytes(4);
		output.appendAccounted('\ud800caf\u00e9');

		expect(output.finish()).toEqual(['\ud800caf\u00e9']);
	});

	it('restores byte provenance after a failed component attempt', () => {
		const output = new SsrOutputBuffer(4);
		output.accountKnown('ab', 2);
		const checkpoint = output.checkpoint();
		output.accountKnown('cd', 2);
		output.rollback(checkpoint);
		output.accountKnown('Ã©', 2);
		output.appendAccounted('abÃ©');

		expect(output.finish()).toEqual(['abÃ©']);
	});

	it('rescans the completed root after foreign output invalidates provenance', () => {
		const output = new SsrOutputBuffer(4);
		output.accountKnown('ignored', 1);
		output.invalidateAccounting();

		expect(() => output.appendAccounted('abcÃ©')).toThrow(
			'eXact SSR output exceeds the configured maximum of 4 bytes'
		);
	});

	it('rejects output incrementally before constructing a final string', () => {
		const output = new SsrOutputBuffer(4);
		output.append('abc');

		expect(() => output.append('é')).toThrow(
			'eXact SSR output exceeds the configured maximum of 4 bytes'
		);
	});

	it('commits a recoverable range against its outer byte checkpoint', () => {
		const published: string[] = [];
		const output = new SsrOutputBuffer(20, (value) => published.push(value));
		const checkpoint = output.beginBufferedRange();
		output.accountKnown('discarded', 9);
		output.publishAccounted('discarded');

		const rendered = output.commitBufferedRange(checkpoint, 'okay');
		output.publishAccounted(rendered);

		expect(output.encodedBytes()).toBe(4);
		expect(published).toEqual(['okay']);
	});

	it('restores direct publication after a recoverable range fails', () => {
		const published: string[] = [];
		const output = new SsrOutputBuffer(20, (value) => published.push(value));
		const checkpoint = output.beginBufferedRange();
		output.accountKnown('discarded', 9);
		output.publishAccounted('discarded');
		output.rollbackBufferedRange(checkpoint);
		output.accountKnown('ok', 2);
		output.publishAccounted('ok');

		expect(output.encodedBytes()).toBe(2);
		expect(published).toEqual(['ok']);
	});

	it('retains fully accounted range bytes without encoding the completed string again', () => {
		const encode = vi.fn(utf8ByteLength);
		const published: string[] = [];
		const output = new SsrOutputBuffer(5, (value) => published.push(value), encode);
		const checkpoint = output.beginBufferedRange();
		output.accountKnown('caf\u00e9', 5);
		output.publishAccounted('caf\u00e9');
		output.publishAccounted(output.commitBufferedRange(checkpoint, 'caf\u00e9', true));
		expect(output.encodedBytes()).toBe(5);
		expect(published).toEqual(['caf\u00e9']);
		expect(encode).not.toHaveBeenCalled();
		expect(() => output.account('!')).toThrow('maximum of 5 bytes');
	});

	it('rescans a fully accounted range if foreign output invalidated its byte provenance', () => {
		const output = new SsrOutputBuffer(4, () => {});
		const checkpoint = output.beginBufferedRange();
		output.accountKnown('ab', 2);
		output.invalidateAccounting();
		expect(() => output.commitBufferedRange(checkpoint, 'abc\u00e9', true)).toThrow(
			'maximum of 4 bytes'
		);
		expect(output.encodedBytes()).toBe(0);
		expect(output.publishesDirectly()).toBe(true);
	});

	it('rescans late-delimited surrogate output even after the pending surrogate was flushed', () => {
		const output = new SsrOutputBuffer(100, () => {});
		output.accountKnown('\ud83d', 3);
		const checkpoint = output.beginBufferedRange();
		output.accountKnown('\ude80', 3);
		output.accountKnown('<b>', 3);
		output.accountKnown('</b>', 4);
		output.commitBufferedRange(checkpoint, '<b>\ude80</b>', true);
		expect(output.encodedBytes()).toBe(13);

		const next = output.beginBufferedRange();
		output.accountKnown('\ud83d', 3);
		output.accountKnown('</b>', 4);
		output.commitBufferedRange(next, '\ud83d</b>', true);
		expect(output.encodedBytes()).toBe(20);
	});
});
