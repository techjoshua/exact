import { attachSuppressedCleanupFailure, type AnyComponentInstance } from '@exactjs/core';
import type { DirectSsrComponentSnapshot, SsrContext } from '../types.js';
import type { ExactServerExecutableComponentContract } from '@exactjs/core/framework/component-contracts';
import type { SsrRenderOptions } from './entrypoints.js';
import { prepareComponentProps } from './component-props.js';
import type { DirectSsrComponentContent } from './direct-component-content.js';
import {
	inComponentDomain,
	type DirectSsrLifecycleCapability
} from './direct-component-support.js';
import { createSelectedDirectSsrFrame, selectedDirectSsrOwner } from './direct-frame-selection.js';
import type { DirectIssuedRender } from './direct-component-contracts.js';
import {
	disposeDirectSsrLifetimeSync,
	renderIssuedServerComponentChildren
} from './direct-component-scheduling.js';
import { disposeAsyncPreservingPrimary, noPrimaryFailure } from './ownership.js';

export type { DirectSsrComponentContent } from './direct-component-content.js';
export type {
	DirectIssuedRender,
	DirectScheduledPreparation,
	DirectScheduledSsrComponent,
	DirectSsrComponentPublisher,
	PreparedDirectScheduledSsrComponent
} from './direct-component-contracts.js';
export {
	createDirectScheduledSsrComponent,
	disposeDirectSsrLifetime,
	disposeDirectSsrLifetimeSync,
	renderIssuedServerComponentChildren,
	takePreparedDirectScheduledSsrComponent
} from './direct-component-scheduling.js';

/** Sink selected by the asynchronous renderer after direct child preparation. */
export type DirectSsrAsyncSink<Result> = (
	content: DirectSsrComponentContent,
	owner: AnyComponentInstance | undefined,
	props: Record<string, unknown>,
	snapshot: DirectSsrComponentSnapshot
) => Result | Promise<Result>;

/** Executes one synchronous artifact directly into a request-owned asynchronous sink. */
export async function executeDirectSsrComponent<Result>(
	context: SsrContext,
	contract: ExactServerExecutableComponentContract,
	rawProps: Record<string, unknown>,
	parent: AnyComponentInstance | undefined,
	options: SsrRenderOptions,
	sink: DirectSsrAsyncSink<Result>
): Promise<Result | undefined> {
	const artifact = contract.artifact;
	const server = artifact.execution;
	if (server?.lane !== 'direct' || server.classification !== 'synchronous' || !server.render)
		return undefined;
	const preparedProps = prepareComponentProps(rawProps, server.deferredTaskProps, options.signal);
	const props = preparedProps instanceof Promise ? await preparedProps : preparedProps;
	const frame = createSelectedDirectSsrFrame(context, contract, parent);
	const owner = selectedDirectSsrOwner(contract, frame, parent);
	const lifecycle = server.lifecycle as DirectSsrLifecycleCapability | undefined;
	let render: unknown;
	if (server.mode !== 'direct' && server.mode !== 'stateless') {
		try {
			render = inComponentDomain(context, () => server.render!.call(frame, props));
			if (typeof render !== 'function')
				throw new TypeError(
					'Compiled synchronous server component did not return its render function'
				);
		} catch (error) {
			if (lifecycle) {
				try {
					disposeDirectSsrLifetimeSync({ frame, lifecycle }, 'ssr construction failed');
				} catch (cleanup) {
					attachSuppressedCleanupFailure(error, cleanup);
				}
			}
			throw error;
		}
	}
	let preparation: DirectIssuedRender['preparation'];
	let primary: unknown = noPrimaryFailure;
	try {
		const started = lifecycle ? performanceNow() : 0;
		const pendingIssued = renderIssuedServerComponentChildren(
			context,
			options,
			() =>
				inComponentDomain(context, () =>
					server.mode === 'direct' || server.mode === 'stateless'
						? server.render!.call(frame, props)
						: (render as () => unknown)()
				),
			owner
		);
		const issued = pendingIssued instanceof Promise ? await pendingIssued : pendingIssued;
		lifecycle?.rendered(frame, performanceNow() - started);
		preparation = issued.preparation;
		const snapshot = {
			componentId: artifact.id,
			contract,
			host: frame,
			state: frame.state,
			props
		};
		const checkpoint = context.onComponentAttemptCheckpoint?.();
		const resumptionCheckpoint = context.resumptionCapture?.checkpoint();
		const resumptionToken = context.resumptionCapture?.reserveDirect(artifact.id, contract);
		context.onDirectComponentCreated?.(snapshot);
		try {
			const output = await sink(issued.content, owner, props, snapshot);
			if (resumptionToken !== undefined)
				context.resumptionCapture?.publishDirect(resumptionToken, frame, frame.state, props);
			context.onDirectComponentRendered?.(snapshot);
			return output;
		} catch (error) {
			if (resumptionCheckpoint !== undefined)
				context.resumptionCapture?.rollback(resumptionCheckpoint);
			context.onComponentAttemptRollback?.(checkpoint);
			throw error;
		}
	} catch (error) {
		primary = error;
		throw error;
	} finally {
		if (preparation)
			await disposeAsyncPreservingPrimary(
				() => Promise.resolve(preparation![Symbol.asyncDispose]()),
				primary
			);
		if (lifecycle)
			await disposeAsyncPreservingPrimary(
				() => Promise.resolve(lifecycle.dispose(frame, 'ssr render complete')),
				primary
			);
	}
}

function performanceNow(): number {
	return typeof globalThis.performance?.now === 'function'
		? globalThis.performance.now()
		: Date.now();
}
