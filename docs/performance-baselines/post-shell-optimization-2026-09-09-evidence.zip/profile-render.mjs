﻿import {Session} from 'node:inspector';
import {readFile,writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const [id,mode]=process.argv.slice(2);
const entry=resolve(`framework-comparison/participants/${id}/dist-server/server-entry.js`);
const mod=await import(pathToFileURL(entry));const data=JSON.parse(await readFile('.tmp/positional-leaves/data.json','utf8'));
const render=mode==='string'?()=>mod.renderParticipant(data,'/incidents/inc-101',{clientTags:''}):async()=>new Response(await mod.renderParticipantStream(data,'/incidents/inc-101',{clientTags:''})).text();
for(let i=0;i<5000;i++){const v=render();if(mode==='stream')await v;}
const session=new Session();session.connect();const post=(method,params={})=>new Promise((yes,no)=>session.post(method,params,(e,r)=>e?no(e):yes(r)));
await post('Profiler.enable');await post('Profiler.setSamplingInterval',{interval:250});await post('Profiler.start');
const started=performance.now();for(let i=0;i<30000;i++){const v=render();if(mode==='stream')await v;}const elapsed=performance.now()-started;
const {profile}=await post('Profiler.stop');session.disconnect();const filename=`.tmp/post-shell-optimization/current-${id}-${mode}.cpuprofile`;await writeFile(filename,JSON.stringify(profile));
const nodes=new Map(profile.nodes.map(n=>[n.id,n]));const totals=new Map();for(let i=1;i<profile.samples.length;i++){const n=nodes.get(profile.samples[i]);const key=n.callFrame.functionName+' '+n.callFrame.url+':'+(n.callFrame.lineNumber+1);totals.set(key,(totals.get(key)||0)+profile.timeDeltas[i]/1000);}
const summary={id,mode,iterations:30000,elapsedMs:elapsed,sites:[...totals].sort((a,b)=>b[1]-a[1]).slice(0,45)};await writeFile(filename+'.json',JSON.stringify(summary,null,2));console.log(JSON.stringify(summary));
