import {readFileSync,writeFileSync,appendFileSync} from 'node:fs';
const root='.tmp/post-shell-optimization';
appendFileSync(root+'/WORK_PLAN.md','\nExperiment 24 renderer outcome: Node changes mostly within 1%, large stream -1.81%, Unicode slightly slower; Bun string small/large/Unicode -3.02%/-2.17%/-1.42%, stream -2.07%/+0.37%/-1.90%. This warrants a paired HTTP check. Hypothesis: roughly 0-1% end-to-end throughput benefit because serialization is only part of request cost. Compare identical complete documents in both API/runtime lanes before deciding whether shared mutable regex state is justified.\n');
const constants='\nconst __probeTextEscape=/[&<>]/g, __probeAttrEscape=/[&<>\"]/g, __probeAttrName=/^[A-Za-z_:][A-Za-z0-9_:.-]*$/, __probeScriptLt=/</g, __probeScriptLine=/\\u2028/g, __probeScriptParagraph=/\\u2029/g;\n';
for(const runtime of ['node','bun']){
 const base=readFileSync(`framework-comparison/participants/exact/${runtime==='bun'?'dist-bun-server/bun-server-entry.js':'dist-server/server-entry.js'}`,'utf8');
 writeFileSync(`${root}/regex-http-${runtime}-baseline.mjs`,base);
 let code=base.replace('value.replace(/[&<>]/g, escapeHtmlCharacter)','value.replace(__probeTextEscape, escapeHtmlCharacter)').replace('value.replace(/[&<>\"]/g, escapeHtmlCharacter)','value.replace(__probeAttrEscape, escapeHtmlCharacter)').replace('/^[A-Za-z_:][A-Za-z0-9_:.-]*$/.test(value)','__probeAttrName.test(value)');
 const start=code.indexOf('function serializeJson('),end=code.indexOf('\n}',start)+2;
 const section=code.slice(start,end).replace('.replace(/</g,','.replace(__probeScriptLt,').replace('.replace(/\\u2028/g,','.replace(__probeScriptLine,').replace('.replace(/\\u2029/g,','.replace(__probeScriptParagraph,');
 code=constants+code.slice(0,start)+section+code.slice(end);
 for(const name of ['__probeTextEscape','__probeAttrEscape','__probeAttrName','__probeScriptLt','__probeScriptLine','__probeScriptParagraph'])if(code.split(name).length!==3)throw Error('Missing replacement '+name);
 writeFileSync(`${root}/regex-http-${runtime}-candidate.mjs`,code);
}
let runner=readFileSync(root+'/http-round.mjs','utf8');runner=runner.replace("['react','candidate','baseline']:['baseline','candidate','react']","['candidate','baseline']:['baseline','candidate']");runner=runner.replace("resolve(variant==='baseline'?root+'/baseline/'+relative:relative)",'resolve(`${root}/regex-http-${runtime.id}-${variant}.mjs`)');runner=runner.replace('durationMs:4000','durationMs:6000');writeFileSync(root+'/regex-http-round.mjs',runner);
