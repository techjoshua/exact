import {readFile,writeFile,readdir} from 'node:fs/promises';import {resolve,extname} from 'node:path';import {pathToFileURL} from 'node:url';import {createHash} from 'node:crypto';import {chromium} from 'playwright';
import {startComparisonServer} from '../../framework-comparison/src/server.mjs';import {startClientPageReplay} from '../../framework-comparison/src/client-page-replay.mjs';
import {measureRetainedMemory} from '../../framework-comparison/src/browser-memory.mjs';import {waitForFirstContentfulPaint} from '../../framework-comparison/src/paint-timing.mjs';import {installBrowserVitals,readBrowserVitals} from '../../framework-comparison/src/browser-vitals.mjs';import {hashSemanticResponse} from '../../framework-comparison/src/artifact-integrity.mjs';
const base='.tmp/post-shell-optimization';const label=process.argv[2]??'navigation';const samples=Number(process.argv[3]??30);
const participants=[{id:'baseline',port:4401,root:base+'/baseline/framework-comparison/participants/exact'},{id:'candidate',port:4406,root:'framework-comparison/participants/exact'},{id:'react',port:4402,root:'framework-comparison/participants/react'}];
let service,browser;const replays=[],rows=[];
async function resetService(body){const response=await fetch('http://127.0.0.1:4310/__benchmark/reset',{method:'POST',headers:{'content-type':'application/json','x-benchmark-control':'fixture-reset'},body:JSON.stringify(body)});if(!response.ok)throw Error('Reset failed');}
function installReadinessTiming(){globalThis.__focusedReadyMs=null;new MutationObserver(()=>{if(globalThis.__focusedReadyMs===null&&document.querySelector('.connection')?.textContent.includes('Live service'))globalThis.__focusedReadyMs=performance.now();}).observe(document,{childList:true,characterData:true,subtree:true});}
try{
 service=await startComparisonServer();const snapshot=service.service.store.snapshot();const data={incidents:snapshot.incidents,users:snapshot.users,sessionUserId:snapshot.sessionUserId};
 for(const p of participants){p.url='http://127.0.0.1:'+p.port;const dir=resolve(p.root,'dist');const index=await readFile(dir+'/index.html','utf8');const clientTags=index.match(/(?:<script[^>]+src="[^"]+"[^>]*><\/script>|<link[^>]+href="[^"]+"[^>]*>)/g)?.join('\n')??'';const mod=await import(pathToFileURL(resolve(p.root,'dist-server/server-entry.js')));const html=mod.renderParticipant(data,'/incidents/inc-100',{clientTags});const resources=new Map();
 async function visit(path,prefix=''){for(const entry of await readdir(path,{withFileTypes:true})){if(entry.name.startsWith('.')||/\.(?:map|gz|br)$/.test(entry.name))continue;const key=prefix+'/'+entry.name;if(entry.isDirectory())await visit(path+'/'+entry.name,key);else resources.set(key,{body:await readFile(path+'/'+entry.name),headers:{'content-type':({'.js':'text/javascript','.css':'text/css','.html':'text/html','.svg':'image/svg+xml'})[extname(key)]??'application/octet-stream'}});}}
 await visit(dir);resources.set('/incidents/inc-100',{body:Buffer.from(html),headers:{'content-type':'text/html'}});const manifest=[...resources].map(([path,r])=>({path,bytes:r.body.length,sha256:createHash('sha256').update(r.body).digest('hex')}));replays.push(await startClientPageReplay({id:p.id,url:p.url,resources,manifest}));
 }
 browser=await chromium.launch();for(let round=-1;round<samples;round++){const order=[...participants.slice((round+3)%3),...participants.slice(0,(round+3)%3)];for(const p of order){const row={id:p.id,round,...await measureBrowserSample(browser,p)};if(round>=0)rows.push(row);}if(round>=0){console.log('round',round+1);await writeFile(base+'/'+label+'-client.json',JSON.stringify({rows,evidence:replays.map(r=>r.evidence())},null,2));}}
}finally{try{await browser?.close();}finally{try{await Promise.all(replays.map(r=>r.close()));}finally{await service?.close();}}}

async function measureBrowserSample(browserInstance, participant) {
	await resetService({});
	const context = await browserInstance.newContext();
	try {
		const page = await context.newPage();
		const browserErrors = [];
		const failedRequests = [];
		page.on('console', (message) => {
			if (message.type() === 'error') browserErrors.push(message.text());
		});
		page.on('pageerror', (error) => browserErrors.push(error.message));
		page.on('requestfailed', (request) =>
			failedRequests.push(`${request.method()} ${request.url()}: ${request.failure()?.errorText}`)
		);
		await page.addInitScript(installInteractionTiming);
await page.addInitScript(installReadinessTiming);
		await page.addInitScript(installBrowserVitals);
		const session = await context.newCDPSession(page);
		await session.send('Network.enable');
		await session.send('Network.setCacheDisabled', { cacheDisabled: true });
		await session.send('Performance.enable');
		// EventSource intentionally keeps the network active, so semantic readiness gates the sample.
		await page.goto(`${participant.url}/incidents/inc-100`, { waitUntil: 'domcontentloaded' });
		await page.getByRole('heading', { name: 'Checkout authorization failures' }).waitFor();
		const firstContentfulPaintMs = await page.evaluate(waitForFirstContentfulPaint);
		await page.waitForLoadState('load');
		const navigation = await page.evaluate(() => {
			const entry = performance.getEntriesByType('navigation')[0];
			const scripts = performance
				.getEntriesByType('resource')
				.filter(
					(resource) => resource.initiatorType === 'script' || /\.m?js(?:$|\?)/.test(resource.name)
				)
				.reduce((sum, resource) => sum + (resource.transferSize || 0), 0);
			return {
				durationMs: entry?.duration ?? null,
				domContentLoadedMs: entry?.domContentLoadedEventEnd ?? null,
				loadEventMs: entry?.loadEventEnd ?? null,
				transferredScriptBytes: scripts
			};
		});
		navigation.firstContentfulPaintMs = firstContentfulPaintMs;
		try {
			await page.locator('.connection').getByText('Live service', { exact: true }).waitFor();
		} catch (error) {
			throw new Error(
				`Live service readiness failed for ${participant.id}. ` +
					`Requests: ${failedRequests.join(' | ') || '<none>'}. ` +
					`Browser: ${browserErrors.join(' | ') || '<none>'}.`,
				{ cause: error }
			);
		}
		await page.getByRole('button', { name: 'Claim incident' }).click();
		await page.getByText('Alex Chen', { exact: true }).waitFor();
		await page.getByText('Version 2', { exact: true }).waitFor();
		const timing = await page.evaluate(() => globalThis.__frameworkComparisonTiming);
		if (timing?.optimisticFeedbackMs == null || timing.settlementMs == null)
			throw new Error(`Missing browser interaction timing for ${participant.id}`);
		// Collect retained memory after interaction timing. A forced collection immediately before the
		// click would turn optimistic feedback into a cold-allocation recovery measurement.
		const memory = await measureRetainedMemory(session);
		const vitals = await page.evaluate(readBrowserVitals);
		const semanticResponse = await page.evaluate(() => ({
			heading: document.querySelector('h1, h2')?.textContent?.trim() ?? null,
			owner: document.querySelector('.facts > div:first-child strong')?.textContent?.trim() ?? null,
			version: document.querySelector('.version')?.textContent?.trim() ?? null
		}));
		if (browserErrors.length || failedRequests.length)
			throw new Error(`${participant.id}: ${[...browserErrors, ...failedRequests].join(' | ')}`);
		return {
			navigation,
readyMs: await page.evaluate(() => globalThis.__focusedReadyMs),
			vitals,
			heapBytes: memory.jsHeapUsedBytes,
			memory,
			optimisticFeedbackMs: timing.optimisticFeedbackMs,
			settlementMs: timing.settlementMs,
			phasesMs: timing.phasesMs,
			responseHash: hashSemanticResponse(semanticResponse)
		};
	} finally {
		await context.close();
	}
}

/** Installs a participant-neutral click-to-visible-mutation clock in the page's own time domain. */
function installInteractionTiming() {
	const timing = {
		startedAt: null,
		optimisticFeedbackMs: null,
		settlementMs: null,
		phasesMs: {}
	};
	globalThis.__frameworkComparisonTiming = timing;
	const mark = (phase) => {
		if (timing.startedAt === null || timing.phasesMs[phase] !== undefined) return;
		timing.phasesMs[phase] = performance.now() - timing.startedAt;
	};

	const nativeFetch = globalThis.fetch;
	globalThis.fetch = (...args) => {
		const input = args[0];
		const url = typeof input === 'string' ? input : input instanceof Request ? input.url : '';
		if (url.endsWith('/claim')) mark('request-dispatched');
		return nativeFetch(...args).then((response) => {
			if (url.endsWith('/claim')) mark('http-headers-received');
			return response;
		});
	};
	const nativeResponseJson = Response.prototype.json;
	Response.prototype.json = function () {
		return nativeResponseJson.call(this).then((value) => {
			if (this.url.endsWith('/claim')) mark('http-json-decoded');
			return value;
		});
	};
	const observedEventSources = new WeakSet();
	const nativeAddEventListener = EventSource.prototype.addEventListener;
	EventSource.prototype.addEventListener = function (type, listener, options) {
		if (type === 'incident' && !observedEventSources.has(this)) {
			observedEventSources.add(this);
			nativeAddEventListener.call(this, type, () => mark('sse-incident-received'));
		}
		return nativeAddEventListener.call(this, type, listener, options);
	};
	document.addEventListener(
		'click',
		(event) => {
			const button = event.target instanceof Element ? event.target.closest('button') : null;
			if (button?.textContent?.trim() !== 'Claim incident' || timing.startedAt !== null) return;
			timing.startedAt = performance.now();
		},
		true
	);
	new MutationObserver(() => {
		if (timing.startedAt === null) return;
		const now = performance.now();
		const owner = document.querySelector('.facts > div:first-child strong')?.textContent?.trim();
		const version = document.querySelector('.version')?.textContent?.trim();
		if (timing.optimisticFeedbackMs === null && owner === 'Alex Chen') {
			timing.optimisticFeedbackMs = now - timing.startedAt;
			timing.phasesMs['optimistic-dom-visible'] ??= timing.optimisticFeedbackMs;
		}
		if (timing.settlementMs === null && version === 'Version 2') {
			timing.settlementMs = now - timing.startedAt;
			timing.phasesMs['authoritative-dom-visible'] ??= timing.settlementMs;
		}
	}).observe(document, { childList: true, characterData: true, subtree: true });
}

