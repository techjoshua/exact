﻿# Authorized overnight continuation

Finish and publish render-modes-2026-09-09 as the immutable new baseline first. Do not modify the measured framework artifacts before final artifact verification and archival. Two incomplete SSR diagnostic attempts failed because the render-only harness omitted documentOptions; HTTP paths were correct. Preserve those logs. Diagnostic-only input forwarding is now fixed.

After baseline publication, iteratively profile, hypothesize, experiment, and retain improvements until reasonable evidence-backed experiments are exhausted. User explicitly rejects arbitrary minimum improvement percentages. Preserve quality, hydration integrity, lifecycle cleanup, shell ownership, ABI compatibility, and real application functionality. Do not optimize scores by omitting work or mixing string and streaming APIs. Use focused measurements for incremental work; full reruns only at useful milestones. Investigate navigation regression as well as SSR throughput. No subagent delegation authorized.

Candidate hypotheses to refine against new profiles BEFORE each experiment:

1. Full-document bootstrap moved hydration onto the navigation critical path (prior deferred hydration was replaced with immediate hydrate(document)). It may explain roughly 8-12 ms of navigation growth. Test semantic-ready timing, FCP, and first interaction alongside navigation; scheduling must not merely move hidden work outside a metric.
2. Root Document ownership may prevent prior single-copy root-prop hydration savings for nested IncidentApp. Audit actual payload and projection CPU. If duplicated state exists, expect savings proportional to measured duplicated encoding/projection work; no schema or ABI shortcuts.
3. Full-document string publication takes a different path from the prior direct sink. Profile document normalization, direct capture versus wrapper capture, repeated joins/scans, byte counting, and resource-hint ordering. Estimate savings from measured per-request work before changes.
4. Progressive full documents use the generic async renderer and retain the shell until hydration. Reuse proven compiler-native fast paths where semantically valid, aiming to eliminate unnecessary promises/traversals and provide actual incremental document delivery. Initial upper-bound hypothesis: recover some or most of the observed string/stream gap (Node ~20%, Bun ~35% of streaming request cost); refine with profiles.
5. Revisit prior buffer size/flush/cork/overflow lessons under correctly matched APIs. Preserve full document, hydration placement, head-before-await flushing, cancellation, and backpressure. Compare render-only and HTTP effects separately.
6. Profile client full-document adoption, head asset lists, hydration projection, native receipt handling, module/bootstrap costs. Prioritize the largest measured work rather than speculative micro-optimizations.
7. Check whether improvements to hydration, capture, byte accounting, and output assembly benefit both APIs and both runtimes. Preserve public behavior and frozen ABI fixtures.

Record each hypothesis, expected impact, comparison builds, balanced measurements, correctness checks, retained/rejected outcome, and next decision. Rebuild correctly: raw tsc dist is not enough for conditional client/server exports; compile package outputs before application builds. Do not run suites/builds during timing.

## Experiment 1: reverse hydration placement search
Hypothesis before implementation: remove the 18 ms / 1,000-render body scan, expecting about 10-20% less small-fixture string-rendering time and smaller HTTP gains. Results: four alternating fresh processes per variant/runtime/scenario; Node small -19.44%, large -25.49%, Unicode -21.59%; Bun small -13.13%, large -16.13%, Unicode -23.79%. Identical output hashes. Retain, with split/case/missing-close tests.

## Experiment 2: aggregate byte-ledger charging
Hypothesis from baseline charge profile (11 ms / 1,000 renders): replacing per-character property updates/limit checks with the existing UTF-8 counter should save roughly 5-15% of remaining small-fixture string time, potentially more on large ASCII output. Native encoder environments retain their path; split-surrogate and rollback guarantees must hold. Compare incrementally against experiment 1, then check both streaming and HTTP before final adoption.

## Experiment 3: reuse direct capture for compiler-closed synchronous strings
Hypothesis: the generic bridge allocates a WeakMap, observer closures and checkpoint pairs that direct artifacts do not need. Reuse the already-shipped direct sink capture with a bound lazy activation accessor. Expect roughly 2-8% lower remaining render time, with fewer allocations. Preserve observation callbacks, resumption order, rollback and public lazy activations. Compare against experiment 2, not the original baseline.

## Experiment 4: avoid awaiting already-rendered string segments
The async program path awaits every static string and even an absent cleanup owner. Hypothesis: eliminating these unnecessary microtask boundaries should reduce streaming render time about 1-5%, possibly more for larger trees, without changing preparation order or awaiting actual async work. Compare against experiment 3's preserved artifact, with identical full-document output and async lifecycle/parallel-task tests.

## Experiment 5: document-capable deferred hydration
Source audit: the full-shell update replaced hydrateAfterNavigation(element) with immediate hydrate(document), because the deferred API only accepted Element. Hypothesis: extending the existing scheduler to Document restores roughly 5-10 ms of navigation/FCP opportunity, without increasing semantic-ready time by more than a frame or delaying the first interaction (capture-phase activation already exists). Keep full-document adoption. Measure preserved immediate baseline, deferred candidate, React in rotating cold contexts, recording semantic-ready, navigation, FCP, optimistic feedback, settlement and errors. Do not infer a win from navigation alone.

## Experiment 6: transfer unpublished render results in place
All four production callers create an unpublished request-owned string result and immediately wrap it in another object solely to add hydration fields. Hypothesis: transferring that object in place removes one object, one HTML forwarding getter, repeated field copying and one symbol definition, saving roughly 2-5% of remaining string-render time. Public values, lazy HTML, resumptions, preload links and wall-clock fields must remain intact. Compare against experiment 4's artifact; stream API does not use this wrapper.
Experiment 6 outcome: reject. Node differences below 1% and mixed Bun results (small/Unicode slower, larger tree faster). The in-place mutation introduces an additional internal ownership constraint without a consistent performance benefit; preserve independent public result construction. This is not a percentage admission threshold.

## Experiment 7: inline ownership of async traversal depth
Hypothesis: renderChildAsync currently creates an additional async closure and wrapper promise for each node solely to restore tree depth. An explicit enter/try/finally/leave removes that allocation while preserving restoration across await and failure. Expect approximately 2-8% lower streaming render time, especially on larger trees. Compare against experiment 4, with experiment 6 reverted.

## Experiment 8: carry compact native boundaries into async rendering
Audit found 387 extra bytes in the baseline streaming document: named compiler-owned structural ranges and keyed-item pairs around compiler-prepared single-element roots. The synchronous renderer and current client already support anonymous ranges and element-owned keyed boundaries. Port those existing proven rules and route keyed programs through the existing prepared-program renderer (also avoiding its duplicate async loop). Expect about 5-9% fewer bytes in the small streamed fixture and 2-8% less renderer work, with larger-list potential. Preserve generic keyed/multinode markers, dynamic component preload identity, hydration node adoption and later keyed updates. Existing released clients already accept these forms; no new ABI shape is introduced.

Experiment 8 outcome: retain. Node small/large/Unicode -4.77%/-7.51%/-3.03%; Bun -4.31%/-5.89%/-4.06%. SSR and hydration suites and Node stream application contracts pass.

## Experiment 9: share request capture machinery across async and sync
Audit found the generic instance callback bridge has no production renderer callers; all native renderers reserve/publish directly and already own capture checkpoint/rollback. Reuse the class-backed capture for generic/async entries, preserving their accessor-safe root reads (unlike the compiler-closed direct-storage optimization). Preserve authored observer and checkpoint callbacks and bind lazy activation accessors. Hypothesis: fewer closure, WeakMap and redundant checkpoint allocations save 2-6% of async renderer time.

Experiment 9 outcome: reject and restore the original capture. Preserving generic accessor guarantees prevented sharing the faster direct read path. The remaining class change regressed Node small by 3.14% and Unicode by 0.88%, with mixed Bun results. Fewer allocations were an unfounded predictor here. Keep the generic root-accessor and rollback regression coverage.

## Experiment 10: prepared-child dispatch first
The synchronous renderer recognizes prepared compiler values before opaque-operation lookup, while async rendering does that lookup first for every compiler value. Port the same priority while retaining depth ownership for all async children. Hypothesis: avoiding an unnecessary opaque lookup saves 1-3% of async renderer time.

Experiment 10 outcome: retain for parity with synchronous dispatch. Small fixture improved 0.85% Node and 0.66% Bun, with mixed sub-1.2% changes elsewhere. Treat the measured magnitude as uncertain, not a demonstrated universal gain.

## Experiment 11: single-pass generic HTML escaping
Fresh 30,000-render Node profiles attribute 195.9 ms of 2,613 ms streaming work to escapeText, compared with 24 ms in strings. The generic helper performs three replacements even for safe text and four for attributes. Use one character-class replacement for each context, preserving all existing entities. Expect 3-7% lower stream rendering time and a smaller string benefit; the fused accounted string escape stays intact.

Fixture correction: inspection found that the original focused runner's scenario named Unicode contained mojibake plus question marks, not the intended emoji/Japanese text. Those balanced captures are still comparisons of the same larger text workload, but are not Unicode coverage. Preserve them as such; subsequent captures use explicit Unicode escapes. The independent byte-accounting tests use actual escaped surrogate code units.

Experiment 11 outcome: retain single-pass escaping. Incremental stream gains on both runtimes and large fixture (full numbers in escaping-render.json). All 246 SSR tests passed before timing.

## Experiment 12: count non-ASCII runs rather than scanning the whole suffix
Fresh profiles attributed 177 ms/1,236 ms string work and 187 ms/2,613 ms stream work to utf8ByteLength. After the first non-ASCII code unit, the old loop scans the entire remainder, including long ASCII spans. For long values, start with code-unit length and use native scanning to visit only non-ASCII runs, adjusting for exact UTF-8 expansion and surrogate pairs. Short strings retain the simple loop. Expect 5-12% string and 2-6% streaming improvements for sparse-Unicode documents, with dense-Unicode regressions a possibility to measure.

Experiment 12 first variant: reject unbounded run scanning. String Node small -4.39%, large -14.88%, dense Unicode +79.69%; Bun small -0.52%, large -1.39%, dense Unicode +113.24%. Hypothesis for refinement before measuring: inspect eight runs at a time and fall back to the original suffix loop when at least one quarter of the inspected span is non-ASCII. Expect to retain sparse-text wins while bounding dense-text overhead to a few matches. Measure against the escaping build, not the rejected unbounded variant.

Experiment 12 bounded-run string results: Node small -6.69%, large -13.96%, dense Unicode +4.32%; Bun small +0.19%, large -5.34%, dense Unicode +3.01%. Final refinement hypothesis: RegExp.test with lastIndex avoids match arrays entirely; inspect eight non-ASCII code points at a time to reach the dense-text fallback sooner. Expect comparable sparse gains and a smaller dense penalty. Compare against the same escaping build.

Experiment 12 final outcome: retain bounded, allocation-free native searching. String Node small -5.88%, large -13.70%, dense Unicode +5.50%; Bun -1.11%, -3.96%, -0.75%. Stream Node -3.00%, -6.37%, +0.09%; Bun +0.74%, -0.49%, -0.54%. The dense Node string tradeoff remains explicit. It is not a universal gain, and the rejected unbounded versions are not shipped. Exact encoding and limit tests passed.

## Experiment 13: avoid awaiting synchronous preparation results
Both prepareComponentProps and renderIssuedServerComponentChildren already return synchronous values on the normal path and native promises only for pending props or error cleanup. executeDirectSsrComponent nevertheless awaits both for every component. Await only actual promises, preserving real dependency and cleanup awaits. Hypothesis: save 2-5% of small streamed rendering through fewer microtask boundaries; smaller proportional effect for large static-heavy trees.

## Opaque-operation construction probe
Hypothesis: cached descriptors might reduce immutable operation allocation by 10-25% (about 7% upper-bound renderer CPU). Preserve own nonenumerable symbols, freezing and prototype. A six-round fresh-runtime microbenchmark rejected the candidate before changing core: Object.create with cached descriptors was 2.2-2.8x slower on Node and 1.7-1.8x slower on Bun than the existing defineProperty construction. Evidence: opaque-construction-micro.json.

Experiment 13 outcome: retain. Stream small/large Node -2.14%/-3.74%, Bun -1.08%/-2.69%; dense-Unicode Node +0.39%, Bun +4.86%. The helper return contracts prove the skipped awaits unnecessary; async dependency and lifecycle tests pass. Keep workload-specific regressions visible rather than implying all scenarios improved.

## Experiment 14: preserve an already-normalized document's child array
An authored html with exactly head then body currently allocates a classification array, entry objects, three filtered arrays and a replacement pair on each render. Recognize that canonical two-child case before the normalization fallback. Preserve missing-shell insertion, reversed order, duplicate and ambiguous-content checks in the fallback. Hypothesis: remove about 0.3-1 microsecond per request, roughly 1-3% small string renderer time, with less proportional impact on larger documents.

Experiment 14 outcome: retain. Small string Node -0.75%, Bun -2.31%, with all six measured runtime/scenario means improved. It removes allocation in a provably normalized case and leaves the fallback contract intact.

## Experiment 15: buffer encoding and chunk sizes under the real streaming API
The full-document stream currently owns one encoded document chunk. Buffer.concat or a pool cannot combine multiple chunks here without first changing the traversal; adding them now would add copying or retain an extra allocation. Test actual output encoding (TextEncoder versus native Buffer.from) and 2/4/8 KiB views of the encoded document, preserving every byte and backpressure. Hypothesis: native encoding may save up to 1-2% of renderer time; smaller chunks probably add 1-5% renderer overhead but could change HTTP batching. Test HTTP separately. Node 26's installed _http_outgoing already corks socket writes until nextTick, but message-level corking can additionally combine HTTP chunk framing, so consider a separate 2 KiB corked transport variant.

## Experiment 16: return the existing plain-render promise without another async wrapper
Generic intrinsic and structural operations pass through async enhancement routing even when no enhancement exists. Return the underlying renderer promise directly for that case, preserving rejection semantics for a synchronously throwing callback; the actual enhancement routing keeps its async ownership scope. Hypothesis: 1-3% less small stream rendering time and fewer promise allocations. Compare against the canonical-document artifact.

Corking experiment admission: first attempt failed before timing its corked variant because only the first 2 KiB reached the client. A standalone Node 26.8.1 HTTP/ReadableStream reproduction also truncated both Uint8Array and Buffer output when end() ran with an outstanding message cork. Explicitly uncorking before end restored exact bytes. The experimental adapter now owns that final uncork, and the initial failed logs remain in output-http-attempt1.*. Do not weaken the full-document or byte-identity checks.
Experiment 16 outcome: retain. Node small/large/Unicode -1.03%/-2.05%/-1.42%; Bun -2.86%/-1.86%/-2.54%, with the full SSR suite passing.

## Experiment 17: use an available native UTF-8 byte counter
The public string/progressive entry points currently use the portable JavaScript byte counter even on Node and Bun, while the Node response adapter already offers Buffer.byteLength to the produced-response path. Prototype native counting in the frozen renderer on both runtimes. Hypothesis: save 3-10% of rendering time, particularly dense Unicode where the JavaScript fallback struggled. Production adoption would require optional host-capability selection with an explicitly tested portable fallback, without importing Node modules into the neutral SSR graph or weakening split-surrogate accounting.

## Experiment 18: native Bun Response from buffered text
Bun currently wraps an already-complete buffered string in Blob before constructing Response. Buffered bodies already expose a claiming toText() API, so this can be tested without adding a public capability or inspecting private chunks. Hypothesis: avoid Blob allocation/encoding overhead and improve Bun string HTTP throughput 3-10%. Preserve produced streams, ownership, complete documents and exact bytes.

Experiment 15 HTTP outcome: preserve whole-document chunking and reject corking. All 44 corrected blocks had zero errors and identical full-document bytes. Native Buffer encoding was neutral on Node small, -1.04% Node large, +2.04% Bun small and +2.29% Bun large RPS. 2 KiB reduced large-fixture RPS 7.29% Node and 2.14% Bun; message corking reduced Node RPS 20.05% small and 29.46% large. No buffer-size or cork API is added. Native encoding is adopted through an optional host capability, alongside experiment 17, with a portable TextEncoder fallback.
Experiment 17 prototype string outcome: native byte counting improved Node small/large/Unicode 3.84%/8.56%/25.38%; Bun 8.28%/11.45%/19.90%. Retain optional native counting and explicitly test both portable counting and native encoding.
Experiment 18 outcome: native Bun buffered text improved small RPS about 3.2% and large about 2.9%, with zero errors and identical documents. Retain the existing toText() ownership API; produced streams retain their streaming path. A split-surrogate regression also protects the joined text's UTF-8 meaning.

## Experiment 19: skip empty retained-instance cleanup
Native direct components own their own lifetimes, so the generic SSR owner's retained-instance set is commonly empty. Its dispose() still allocates a cleanup-failure record and a reversed empty array. Return immediately for the empty set. Hypothesis: roughly 0.1-0.5 microsecond per stream request, likely below 1% renderer time. Preserve retained-instance reverse teardown and failure aggregation. Probe the frozen artifact before changing source.

Experiment 19 outcome: retain the empty cleanup return. Stream small/large Node improved 1.36%/1.20%, Bun 1.23%/0.60%; Unicode Node +0.55%, Bun -1.43%. No teardown order, callback or failure path changes when retained instances exist.

## Experiment 20: compile literal meta attributes into static markup
Full-shell source audit found three meta tags still allocate attribute objects and execute runtime attribute handling because charSet/content are missing from the static attribute allowlist. HTML meta string literals have equivalent template and native attribute semantics. Add only meta-specific charSet/charset/content support; custom elements, dynamic expressions, URLs and document-root ownership remain on their existing paths. Hypothesis: save 1-3 microseconds per shell render, approximately 2-6% small string and 1-4% stream time, plus fewer client attribute slots. Rebuild the actual compiler and both target artifacts, and check full-document hydration.

Experiment 20 emission audit: compiler selection was current. Server programs deliberately retain the root attribute bag for enhancement overrides. The changed ssrRootStatic plan now contains literal charset/content HTML and an empty runtime attribute-operation list; client templates also contain the literals. The original prediction of removing every server prop object was too broad. The actual optimization is precomputed attribute rendering and fewer client slots. Preserve those root bags and their override contract.

## Experiment 21: revisit the short-text cutoff after native byte counting
The fused string text writer only takes its native no-escape scan at 32 characters or longer, a cutoff from the portable byte-counting path. Native counting is now available for short strings too. Use the same no-escape path for all lengths and preserve the fused loop for escaped text. Hypothesis: 1-3% string renderer improvement, without a streaming-path change. Verify output and split-surrogate byte accounting.

Experiment 20 outcome: retain the equivalent static meta plan. String Node small +0.15%, large -1.41%, Unicode -2.78%; Bun -2.01%, -1.27%, -0.94%. Stream Node -2.05%, -1.20%, -1.02%; Bun -1.70%, -0.53%, -1.17%. Go compiler tests pass, and before/after ssrRootStatic plans verify the actual change.
Experiment 21 outcome: reject the universal cutoff removal. Node string improved 1.75% small and 4.03% large, but Bun regressed 1.11% small and 3.18% large. Avoid adding engine-specific tuning solely to retain this mixed result; keep the established fused short-text path.

## Experiment 22: Node completed-string encoding and header batching
The matched HTTP profile spends substantial time in writeUtf8String for eXact versus writev for React. Test Buffer.from before end, and separately letting end prepare known-length headers instead of explicit writeHead. Hypothesis: 1-5% HTTP improvement through native batching, with identical headers/body semantics and unchanged render work. Test small and 96-row documents, reversed populations, without production edits.

## Experiment 23: one hydration script-escape scan
serializeJson remains a sampled hydration hotspot. Replace its three native replacement passes with one character-class replacement, preserving exact escapes and JSON.stringify validation. Hypothesis: 1-3% renderer improvement for ordinary payloads, potentially larger for long state. Test both runtimes and modes, including real Unicode.

Experiment 22 outcome: reject both variants. Pre-encoding Node complete strings reduced small RPS about 4%, large about 1.4%; implicit header preparation was neutral to slightly slower. All twelve blocks had zero errors and identical complete documents.
Experiment 23 outcome: reject. Small string Node -0.27%, Bun -1.67%, but large string +0.72%/+1.21% and Unicode +3.58%/+2.96%. Stream small improved about 1%, while Bun Unicode regressed 3.73%. Preserve the three native replacements.

Final full-suite diagnosis: removing the plain enhancement promise wrapper exposed a resumption fixture that declared a nonblocking task while asserting SSR had waited for it. Restoring that wrapper or all baseline SSR sources made the test pass accidentally. Compiler metadata confirmed nonblocking readiness. The fixture now explicitly uses TaskContext.latest().blocking() and a test-controlled external promise, preserving the existing no-repeat-on-adoption and rerun-on-dependency-change assertions. No production waiting policy was changed. Failed full and focused diagnostic logs are retained.

Direct capture boundary review: compiler-owned direct state/props may use direct reads; published input comparison is now descriptor-safe even in the direct capture. Both capture modes have regression coverage showing a published getter is not invoked and the state value remains captured.

The strengthened fixture blocks on a test-controlled external promise. The test waits a timer turn and asserts no publication, then releases the operation and verifies adoption skips settled work. A discarded timer-inside-task variant was rejected by compiler resource-escape diagnostics; those attempt logs remain archived.

Final maintainability review: extracted request-local enhancement route ownership into operation-enhancement-routes.ts and render-program attribute lowering into jsx_render_program_attributes.go. Existing algorithms and call order are unchanged. Go compiler tests, architecture and JSDoc checks pass. A fresh full build and admission run follows the split; earlier preflight attempts remain under post-shell-final/preflight-before-domain-split.

## Experiment 24: reuse escaping RegExp instances
Final source review found per-call regex literals in HTML text/attribute escaping, attribute-name validation, and hydration script escaping. Hoist the same expressions to private module constants, preserving every replacement and validation rule. Hypothesis: 1-3% renderer improvement from fewer short-lived objects; engines may already eliminate this allocation or optimize local literals better. Test frozen actual final artifacts on both runtimes, APIs and all three fixtures after the full suite, with exact output identity. Do not edit production source before evidence.

Experiment 24 renderer outcome: Node changes mostly within 1%, large stream -1.81%, Unicode slightly slower; Bun string small/large/Unicode -3.02%/-2.17%/-1.42%, stream -2.07%/+0.37%/-1.90%. This warrants a paired HTTP check. Hypothesis: roughly 0-1% end-to-end throughput benefit because serialization is only part of request cost. Compare identical complete documents in both API/runtime lanes before deciding whether shared mutable regex state is justified.

Experiment 24 final outcome: reject shared regex instances. Every renderer and HTTP variant preserved exact output. HTTP throughput changes: node string 0.06%; node stream 0.11%; bun string 0.68%; bun stream -0.80%. All sixteen HTTP blocks had zero errors. Node was effectively neutral; a small Bun string gain traded against Bun stream regression, without a quality benefit to justify new shared mutable regex state. Production remains identical to the full capture.
