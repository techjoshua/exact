import {readFile,writeFile} from 'node:fs/promises';import {resolve} from 'node:path';import {createHash} from 'node:crypto';import assert from 'node:assert/strict';
import {startSsrLoadProcess} from '../../framework-comparison/src/ssr-load-process-owner.mjs';
import {startSsrWorker,stopSsrWorker,controlSsrWorker} from '../../framework-comparison/src/ssr-worker-controller.mjs';
import {availableSsrRuntimes} from '../../framework-comparison/src/ssr-run-environment.mjs';
import {installDevelopmentProcessLifecycle} from '../../scripts/development-process-lifecycle.mjs';
const label='bun-text';const root='.tmp/post-shell-optimization';const rows=[];const identities=new Map(); const documents=new Map();
let service,worker,drivers=[];
async function close(){const current=drivers;drivers=[];const results=await Promise.allSettled(current.map(d=>d.close()));try{if(worker){const w=worker;worker=undefined;await stopSsrWorker(w);}}finally{if(service){const s=service;service=undefined;await s.close();}}const errors=results.filter(r=>r.status==='rejected');if(errors.length)throw new AggregateError(errors.map(r=>r.reason));}
const lifecycle=installDevelopmentProcessLifecycle({label:'Focused document SSR comparison',close});
try{for(const runtime of availableSsrRuntimes('bun'))for(const scenario of ['small','large'])for(let population=0;population<2;population++)for(const variant of population?['text','plain']:['plain','text']){
 const id='exact',mode='string';const entry=resolve(`${root}/http-text-${scenario}-${variant}.mjs`);
 service=await startSsrLoadProcess('service');worker=await startSsrWorker({runtime,participantId:id,transport:runtime.id==='bun'?'bun-fetch':'node-http',workerPath:resolve(root+'/output-worker.mjs'),workingDirectory:resolve('framework-comparison'),serviceUrl:service.url,environment:{COMPARISON_SSR_RENDER_MODE:mode,EXACT_OUTPUT_CORK:variant==='cork-2048'?'1':'0',COMPARISON_SSR_BOUNDED_TELEMETRY:'1',...(id==='exact'?{COMPARISON_EXACT_SERVER_ENTRY:entry}:{})}});
 assert.equal(worker.renderMode,mode);const url=worker.url+'?__benchmarkPreloaded=true';const response=await fetch(url);assert.equal(response.status,200);const html=Buffer.from(await response.arrayBuffer());await writeFile(root+`/text-${runtime.id}-${scenario}-${population}-${variant}-admission.json`,JSON.stringify({headers:[...response.headers],body:html.toString(),workerStderr:worker.stderr()},null,2));assert.match(html.toString(),/^<!doctype html>/i);assert.match(html.toString(),/<\/body><\/html>$/i);const identity={bytes:html.length,hash:createHash('sha256').update(html).digest('hex')};
 const key=runtime.id+'/'+scenario;if(identities.has(key))assert.deepEqual(identity,identities.get(key));else identities.set(key,identity);
 await controlSsrWorker(worker,'reset');for(let i=0;i<2;i++)drivers.push(await startSsrLoadProcess('driver'));
 const stages=[{name:'warmup',mode:'concurrency',concurrency:16,durationMs:5000,discard:true},{name:'c32',mode:'concurrency',concurrency:16,durationMs:8000}];
 for(const d of drivers)d.run({url,contains:'Delayed fulfillment events',expectedIdentity:identity,maxInFlight:256,maxLagMs:50,timeoutMs:10000,stages});
 const results=await Promise.race([Promise.all(drivers.map(d=>d.result)),service.result]);const measured=results.map(r=>r.stages[1]);for(const s of measured){assert.equal(s.started,s.completed);assert.equal(s.completed,s.valid+s.errors);}
 const start=Math.min(...measured.map(s=>Date.parse(s.startedAt))),end=Math.max(...measured.map(s=>Date.parse(s.startedAt)+s.elapsedMs));const row={runtime:runtime.id,mode,scenario,population,variant,entry,artifactSha256:createHash('sha256').update(await readFile(entry)).digest('hex'),identity,results,rps:measured.reduce((n,s)=>n+s.valid,0)/(end-start)*1000,errors:measured.reduce((n,s)=>n+s.errors,0)};
 rows.push(row);console.log(runtime.id,scenario,population,variant,row.rps.toFixed(0),row.errors);await close();await writeFile(root+'/'+label+'-http.json',JSON.stringify(rows,null,2));
}}finally{await close();lifecycle.dispose();}
