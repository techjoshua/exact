/* eslint-disable @typescript-eslint/no-explicit-any -- This test intentionally models external, private, or invalid values that production contracts reject. */
/**
 * @vitest-environment jsdom
 */
import { flushSync, registerReactiveListKey } from '@exactjs/reactive';
import { renderHydrationScript, renderToHydratableString } from '@exactjs/ssr';
import { expect, it } from 'vitest';
import { defineExactHydrationRegistration, hydrate, readExactHydrationConfig } from './index.js';
import { resolveHydrateOptions } from './config.js';
import {
	documentRoot as serverDocumentRoot,
	documentWithAssets as serverDocumentWithAssets,
	profiledRoot as serverProfiledRoot
} from './test-support/bootstrap.fixtures.js?exact-target=server';
import {
	documentRoot as clientDocumentRoot,
	documentWithAssets as clientDocumentWithAssets,
	profiledRoot as clientProfiledRoot
} from './test-support/bootstrap.fixtures.js';

it('reports aggregate hydration timing without retaining diagnostic phase timers', () => {
	const container = document.createElement('div');
	container.innerHTML = renderToHydratableString(serverProfiledRoot).htmlWithHydration;
	const events: Array<{ subsystem: string; phase: string }> = [];

	hydrate(clientProfiledRoot, container, { onProfile: (event) => events.push(event) });

	expect(events).toContainEqual(
		expect.objectContaining({
			subsystem: 'hydrate',
			phase: 'hydrate'
		})
	);
	expect(events.map((event) => event.phase)).toEqual(['hydrate']);
});

it('adopts a complete authored document while retaining framework-owned body augmentation', () => {
	const rendered = renderToHydratableString(serverDocumentRoot, {
		endpoint: '/__exact'
	});
	document.open();
	document.write(rendered.htmlWithHydration);
	document.close();
	const originalHtml = document.documentElement;
	const frameworkScript = document.getElementById('__exact_hydration');
	const client = hydrate(clientDocumentRoot, document, { onMismatch: 'throw' });

	expect(document.documentElement).toBe(originalHtml);
	expect(document.getElementById('__exact_hydration')).toBe(frameworkScript);
	const button = document.querySelector('button')!;
	button.click();
	flushSync();
	expect(button.textContent).toBe('Count 2');
	expect(document.title).toBe('Count 2');
	expect(frameworkScript?.previousSibling).toBeInstanceOf(Comment);
	expect((frameworkScript?.previousSibling as Comment).data).toBe('exact:framework-body:start');
	client.dispose();
	document.open();
	document.write('<!doctype html><html><head></head><body></body></html>');
	document.close();
});

it.each(['string', 'stream'])(
	'adopts native head lists and nested resumable components in an authored document (%s)',
	async (mode) => {
		const { renderToHydratableStringAsync, renderToHydratableProgressiveHtmlStream } = await import(
			'@exactjs/ssr'
		);
		const options = { publishRootProps: true };
		let html = '';
		if (mode === 'stream') {
			const reader = renderToHydratableProgressiveHtmlStream(
				serverDocumentWithAssets,
				options
			).getReader();
			const decoder = new TextDecoder();
			try {
				while (true) {
					const next = await reader.read();
					if (next.done) break;
					html += decoder.decode(next.value, { stream: true });
				}
				html += decoder.decode();
			} finally {
				reader.releaseLock();
			}
		} else
			html = (await renderToHydratableStringAsync(serverDocumentWithAssets, options))
				.htmlWithHydration;
		document.open();
		document.write(html);
		document.close();
		const links = [...document.querySelectorAll('link')];
		const button = document.querySelector('button')!;
		let client: ReturnType<typeof hydrate> | undefined;
		try {
			expect(button.textContent).toBe('Nested 4');
			expect(document.querySelector('[data-exact-client-resumption]')).toBeNull();
			client = hydrate(clientDocumentWithAssets, document, { onMismatch: 'throw' });
			expect([...document.querySelectorAll('link')]).toEqual(links);
			expect(document.querySelector('button')).toBe(button);
			button.click();
			flushSync();
			expect(button.textContent).toBe('Nested 5');
		} finally {
			client?.dispose();
			document.open();
			document.write('<!doctype html><html><head></head><body></body></html>');
			document.close();
		}
	}
);

it('decodes keyed hydration collection envelopes into ordinary arrays', () => {
	const records = [
		{ id: 'a', title: 'A' },
		{ id: 'b', title: 'B' }
	];
	registerReactiveListKey(
		records,
		(item) => (item as { id: string }).id,
		'hydrate config test',
		'member:id'
	);
	const root = document.createElement('div');
	root.innerHTML = renderHydrationScript({ state: { records } });
	const config = readExactHydrationConfig(root);
	expect((config.state as any).records).toEqual(records);
	expect(Array.isArray((config.state as any).records)).toBe(true);
	expect(Object.keys((config.state as any).records)).toEqual(['0', '1']);
});

it('retains generated action invocation metadata from serialized hydration config', () => {
	const continuation = {
		kind: 'task' as const,
		id: 'action:quote',
		componentId: 'component:Workspace',
		readiness: 'nonblocking' as const,
		dependencies: [{ source: 'argument' as const }],
		invocation: {
			arguments: [{ source: 'argument' as const }],
			concurrency: 'parallel' as const
		},
		stateReads: [],
		stateWrites: [],
		publicContexts: [],
		serverContexts: [],
		contextWrites: [],
		serverContextWrites: [],
		boundaries: []
	};
	const root = document.createElement('div');
	root.innerHTML = renderHydrationScript({
		continuations: { [continuation.id]: continuation }
	});
	const { serverContextWrites: _, ...browserContinuation } = continuation;

	expect(readExactHydrationConfig(root).continuations?.[continuation.id]).toEqual(
		browserContinuation
	);
});

it('uses the core continuation contract for collection state paths', () => {
	const root = document.createElement('div');
	root.innerHTML = renderHydrationScript({
		continuations: {
			'action:collection': {
				kind: 'task',
				id: 'action:collection',
				componentId: 'component:Workspace',
				readiness: 'nonblocking',
				dependencies: [],
				stateReads: [{ path: 'records', kind: 'read', confidence: 'exact', operation: 'map' }],
				stateWrites: [],
				publicContexts: [],
				serverContexts: [],
				contextWrites: [],
				serverContextWrites: [],
				boundaries: []
			}
		}
	});

	expect(readExactHydrationConfig(root).continuations?.['action:collection']?.stateReads).toEqual([
		{ path: 'records', kind: 'read', confidence: 'exact', operation: 'map' }
	]);
});

it('normalizes omitted hydration metadata to shared immutable defaults', () => {
	const sparse = {
		kind: 'task' as const,
		id: 'action:sparse',
		componentId: 'component:Workspace',
		readiness: 'nonblocking' as const
	};
	const registration = defineExactHydrationRegistration({
		continuations: {
			[sparse.id]: sparse,
			'action:other': { ...sparse, id: 'action:other' }
		},
		resumptions: [{ componentId: 'component:Workspace' }]
	});
	const first = registration.continuations![sparse.id]!;
	const second = registration.continuations!['action:other']!;
	const resumption = registration.resumptions![0]!;

	for (const value of [
		first.dependencies,
		first.stateReads,
		first.stateWrites,
		first.publicContexts,
		first.serverContexts,
		first.contextWrites,
		first.boundaries
	]) {
		expect(value).toEqual([]);
		expect(Object.isFrozen(value)).toBe(true);
	}
	expect(first.dependencies).toBe(second.dependencies);
	expect(first.serverContextWrites).toBeUndefined();
	expect(resumption.values).toBe(resumption.contexts);
	expect(resumption.values).toEqual({});
	expect(Object.isFrozen(resumption.values)).toBe(true);
	expect(resumption.settledContinuations).toBe(first.dependencies);
});

it('checks paired component authorization and sends only its fingerprint', () => {
	const root = document.createElement('div');
	root.innerHTML = renderHydrationScript({
		componentAuthorization: {
			protocol: 1,
			buildKey: 'build-one',
			fingerprint: 'authorization-one'
		}
	});

	expect(() =>
		resolveHydrateOptions(root, {
			componentAuthorization: {
				protocol: 1,
				buildKey: 'build-one',
				fingerprint: 'authorization-two'
			}
		})
	).toThrow('authorization fingerprints do not match');
	expect(resolveHydrateOptions(root, {}).headers).toEqual({
		'X-Exact-Component-Authorization': 'authorization-one'
	});
	expect(() => resolveHydrateOptions(root, { buildKey: 'another-build' })).toThrow(
		'does not match the hydration build key'
	);
});
