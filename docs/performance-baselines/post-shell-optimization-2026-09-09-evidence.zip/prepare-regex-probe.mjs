import {readFileSync,writeFileSync,appendFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
const root='.tmp/post-shell-optimization';
if(!readFileSync(root+'/WORK_PLAN.md','utf8').includes('## Experiment 24:'))appendFileSync(root+'/WORK_PLAN.md','\n## Experiment 24: reuse escaping RegExp instances\nFinal source review found per-call regex literals in HTML text/attribute escaping, attribute-name validation, and hydration script escaping. Hoist the same expressions to private module constants, preserving every replacement and validation rule. Hypothesis: 1-3% renderer improvement from fewer short-lived objects; engines may already eliminate this allocation or optimize local literals better. Test frozen actual final artifacts on both runtimes, APIs and all three fixtures after the full suite, with exact output identity. Do not edit production source before evidence.\n');
const base=readFileSync('framework-comparison/participants/exact/dist-server/server-entry.js','utf8');
writeFileSync(root+'/pre-regex.mjs',base);
let code=base;
const replacements=[
 ['value.replace(/[&<>]/g, escapeHtmlCharacter)','value.replace(__probeTextEscape, escapeHtmlCharacter)'],
 ['value.replace(/[&<>\"]/g, escapeHtmlCharacter)','value.replace(__probeAttrEscape, escapeHtmlCharacter)'],
 ['/^[A-Za-z_:][A-Za-z0-9_:.-]*$/.test(value)','__probeAttrName.test(value)'],
 ['.replace(/</g, "\\\\u003C")','.replace(__probeScriptLt, "\\\\u003C")'],
 ['.replace(/\\u2028/g, "\\\\u2028")','.replace(__probeScriptLine, "\\\\u2028")'],
 ['.replace(/\\u2029/g, "\\\\u2029")','.replace(__probeScriptParagraph, "\\\\u2029")']
];
for(const [from,to] of replacements){const start=from.startsWith('.replace')?code.indexOf('function serializeJson('):0;const end=from.startsWith('.replace')?code.indexOf('\n}',start)+2:code.length;const section=code.slice(start,end);if(section.split(from).length!==2)throw Error('Unexpected expression: '+from);code=code.slice(0,start)+section.replace(from,to)+code.slice(end);}
code+='\nconst __probeTextEscape=/[&<>]/g, __probeAttrEscape=/[&<>\"]/g, __probeAttrName=/^[A-Za-z_:][A-Za-z0-9_:.-]*$/, __probeScriptLt=/</g, __probeScriptLine=/\\u2028/g, __probeScriptParagraph=/\\u2029/g;\n';
code+='\nexport {escapeText as __probeEscapeText, escapeAttr as __probeEscapeAttr, escapeAttrName as __probeEscapeAttrName, serializeJson as __probeSerializeJson};\n';
for(const tag of ['stable-regex','stable-regex-stream'])writeFileSync(root+'/'+tag+'.mjs',code);
const probe=await import(pathToFileURL(resolve(root+'/stable-regex.mjs')));
for(let round=0;round<3;round++)for(const value of ['plain', 'a </script>\u2028\u2029 &" caf\u00e9\ud83d\ude80']){
 assert.equal(probe.__probeEscapeText(value),value.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'));
 assert.equal(probe.__probeEscapeAttr(value),value.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'));
 assert.equal(probe.__probeSerializeJson({value}),JSON.stringify({value}).replace(/</g,'\\u003C').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029'));
}
assert.equal(probe.__probeEscapeAttrName('data-value'),'data-value');
assert.equal(probe.__probeEscapeAttrName('bad name'),'data-exact-invalid-attr');
let runner=readFileSync(root+'/render-round.mjs','utf8');runner=runner.replace(/^copyFileSync\([^\n]+\);\r?\n/m,'');writeFileSync(root+'/regex-round.mjs',runner);
