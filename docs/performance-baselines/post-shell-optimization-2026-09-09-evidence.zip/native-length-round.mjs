import {spawnSync} from 'node:child_process';import {writeFileSync,copyFileSync,readFileSync} from 'node:fs';
const tag=process.argv[2]??'body-search';
const source=readFileSync('framework-comparison/participants/exact/dist-server/server-entry.js','utf8');const needle='function utf8ByteLength(value) {';if(source.split(needle).length!==2)throw Error('Byte counter not found');writeFileSync(`.tmp/post-shell-optimization/${tag}.mjs`,source.replace(needle,needle+'return Buffer.byteLength(value);')); 
const paths={baseline:'.tmp/post-shell-optimization/baseline.mjs',candidate:`.tmp/post-shell-optimization/${tag}.mjs`,react:'framework-comparison/participants/react/dist-server/server-entry.js'};
const mode=process.argv[4]??'string'; if(process.argv[3])paths.baseline=process.argv[3]; const rows=[];
for(const runtime of ['node','bun'])for(const scenario of ['small','large','unicode'])for(let round=0;round<4;round++)for(const variant of round%2?['react','candidate','baseline']:['baseline','candidate','react']){
 const result=spawnSync(runtime,['.tmp/post-shell-optimization/render-worker.mjs',paths[variant],mode,scenario,scenario==='small'?'8000':'1500'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(result.status!==0)throw Error(result.stderr||result.stdout);
 const row={variant,round,...JSON.parse(result.stdout)};rows.push(row);console.log(runtime,scenario,round,variant,row.usPerRender.toFixed(2));
 writeFileSync(`.tmp/post-shell-optimization/${tag}-render.json`,JSON.stringify(rows,null,2));
}
for(const runtime of ['v26.8.1','1.4.2'])for(const scenario of ['small','large','unicode']){const avg=variant=>{const a=rows.filter(r=>r.runtime===runtime&&r.scenario===scenario&&r.variant===variant);return a.reduce((s,r)=>s+r.usPerRender,0)/a.length};const b=avg('baseline'),c=avg('candidate');console.log(JSON.stringify({runtime,scenario,baseline:b,candidate:c,react:avg('react'),change:(c/b-1)*100}));}
