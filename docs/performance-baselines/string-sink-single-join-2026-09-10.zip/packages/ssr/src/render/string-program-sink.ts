import { SsrOutputLimitError } from './limits.js';
import type { SsrProgramSink } from './program-sink.js';
import { utf8ByteLength } from './utf8.js';

/** Collects one request's ordered text, validating its complete UTF-8 size before publication. */
export class StringProgramSink implements SsrProgramSink {
	private readonly chunks: string[] = [];
	private characters = 0;
	private closed = false;
	constructor(private readonly maxBytes: number) {}

	/** Rejects the UTF-16 lower bound before retaining additional request output. */
	write(html: string): void {
		if (this.closed) throw new Error('SSR string sink is closed');
		if (this.characters + html.length > this.maxBytes) {
			this.destroy();
			throw new SsrOutputLimitError(this.maxBytes);
		}
		if (!html) return;
		this.characters += html.length;
		this.chunks.push(html);
	}

	/** Complete-string collection has no transport pressure. */
	ready(): void {}

	/** Publication boundaries do not expose an unfinished string result. */
	flush(): void {}

	/** Includes late resource hints and checks exact encoded size once, including split surrogates. */
	finish(prefix: readonly string[] = []): string {
		if (this.closed) throw new Error('SSR string sink is closed');
		let characters = this.characters;
		for (const part of prefix) {
			characters += part.length;
			if (characters > this.maxBytes) {
				this.destroy();
				throw new SsrOutputLimitError(this.maxBytes);
			}
		}
		const parts = prefix.length ? prefix.concat(this.chunks) : this.chunks;
		const html = parts.length === 1 ? parts[0]! : parts.join('');
		this.destroy();
		if (utf8ByteLength(html) > this.maxBytes) throw new SsrOutputLimitError(this.maxBytes);
		return html;
	}

	/** Releases retained text on completion, failure, or cancellation. */
	destroy(): void {
		this.chunks.length = 0;
		this.characters = 0;
		this.closed = true;
	}
}
