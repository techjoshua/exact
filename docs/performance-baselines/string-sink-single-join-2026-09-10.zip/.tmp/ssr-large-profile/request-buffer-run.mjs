import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/';
const original=fs.readFileSync(d+'request-buffered-sink/server-entry.js','utf8');
assert.equal(original.split('bufferCharacters = 8192').length,2);
for(const size of [2048,8192,32768])fs.writeFileSync(d+`request-buffer-${size}.mjs`,original.replace('bufferCharacters = 8192',`bufferCharacters = ${size}`));
const entries={previous:d+'source-sink-boundaries/server-entry.js',concat:d+'request-string-sink/server-entry.js',
 b2048:d+'request-buffer-2048.mjs',b8192:d+'request-buffer-8192.mjs',b32768:d+'request-buffer-32768.mjs',
 react:'framework-comparison/participants/react/dist-server/server-entry.js'};
const rows=[];
for(const runtime of ['node','bun'])for(const scenario of ['assets','large'])for(let round=0;round<2;round++){
 const order=Object.keys(entries);if(round)order.reverse();
 for(const variant of order){
  const entry=entries[variant];
  const result=spawnSync(runtime,[d+'production-refresh-worker.mjs',entry,'string',scenario,'12000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
  if(result.status!==0)throw Error(result.stderr+result.stdout);
  const row={runtimeId:runtime,round,variant,artifactSha256:createHash('sha256').update(fs.readFileSync(entry)).digest('hex'),...JSON.parse(result.stdout)};
  const peer=rows.find(r=>r.scenario===scenario&&(r.variant==='react')===(variant==='react'));
  if(peer)assert.equal(row.hash,peer.hash,'Complete document changed');
  rows.push(row);fs.writeFileSync(d+'request-buffer-results.json',JSON.stringify(rows,null,2));
  console.log(runtime,scenario,round,variant,row.usPerRender.toFixed(2));
 }
}
