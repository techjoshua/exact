from pathlib import Path
import json,statistics
p=Path('.tmp/ssr-data-path'); rows=[]
for f in sorted(p.glob('*.json')):
 d=json.loads(f.read_text())
 if not isinstance(d,dict) or 'blocks' not in d: continue
 for b in d['blocks']:
  stages=[r['stages'][-1] for r in b['results']]
  rows.append({'capture':f.stem,'framework':b['id'],'population':b['population']+1,'rps':sum(s['validRps'] for s in stages),'errors':sum(s['errors'] for s in stages),'invalid':sum(s['invalid'] for s in stages),'p99MinMs':min(s['distributions']['responseMs']['p99'] for s in stages),'p99MaxMs':max(s['distributions']['responseMs']['p99'] for s in stages)})
p.joinpath('summary.json').write_text(json.dumps(rows,indent=2))
for x in rows:
 if x['capture'] in ['node-string-auto','node-string-off','bun-string-auto','bun-string-off','node-string-direct-write','node-string-frozen-render']: print(x['capture'],x['framework'],round(x['rps']),x['p99MinMs'],x['p99MaxMs'])
