from pathlib import Path
import json
p=Path('.tmp/ssr-data-path')
w=Path('framework-comparison/src/ssr-benchmark-worker.mjs').read_text()
w=w.replace("'./", "'../../framework-comparison/src/").replace("resolve(import.meta.dirname, '..')", "resolve(import.meta.dirname, '../../framework-comparison')")
w=w.replace('participant.handle(request, response, signal)\n\t\t\t\t)',"participant.handle(request, response, signal),\n                    { adaptive: process.env.DATA_PATH_POLICY !== 'off' }\n                )")
w=w.replace('? createBunRequestHandler : undefined',"? (handler) => createBunRequestHandler(handler, { adaptive: process.env.DATA_PATH_POLICY !== 'off' }) : undefined")
(p/'worker.mjs').write_text(w)
r=Path('.tmp/bun-adaptive-final/capacity-runner.mjs').read_text().replace("resolve('framework-comparison/src/ssr-benchmark-worker.mjs')","resolve('.tmp/ssr-data-path/worker.mjs')")
r=r.replace("plan.preloaded===false?'':'?__benchmarkPreloaded=true'", "plan.preloaded===false?'?__benchmarkServicePhases=true':'?__benchmarkPreloaded=true'")
(p/'capacity.mjs').write_text(r)
plan=json.loads(Path('.tmp/bun-adaptive-final/normal-plan.json').read_text())
plan['stages'][0]['durationMs']=5000
plan['stages'][1]['durationMs']=8000
(p/'plan.json').write_text(json.dumps(plan))
