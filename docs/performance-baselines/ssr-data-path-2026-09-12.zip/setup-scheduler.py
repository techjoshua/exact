from pathlib import Path
p=Path('.tmp/ssr-data-path')
s=Path('packages/ssr/src/render/async-scheduler.ts').read_text()
(p/'scheduler-before.ts').write_text(s)
s=s.replace('await this.acquire(signal);','const pending = this.acquire(signal);\n\t\tif (pending) await pending;').replace('await this.acquire();','const pending = this.acquire();\n\t\t\tif (pending) await pending;').replace('private acquire(signal?: AbortSignal): Promise<void>', 'private acquire(signal?: AbortSignal): void | Promise<void>').replace('return Promise.resolve();','return;')
(p/'scheduler-after.ts').write_text(s)
