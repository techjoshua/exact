import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync} from 'node:fs';
const npm='C:/Program Files/nodejs-v26.8.1/node_modules/npm/bin/npm-cli.js';
const checks=[['comparison-build',[npm,'run','build:exact','-w','@exactjs/framework-comparison-suite']],['comparison-tests',[npm,'run','test:framework-comparison']],['docs-types',[npm,'run','typecheck','-w','@exactjs/docs']],['docs-tests',[npm,'run','test','-w','@exactjs/docs']],['platform',[npm,'run','check:platform-boundaries']],['architecture',[npm,'run','check:source-architecture']],['lint',['node_modules/eslint/bin/eslint.js','packages/ssr/src/render/async-scheduler.ts','packages/ssr/src/render/async-scheduler.test.ts','apps/docs/src/pages/AdvancedPage.tsx']]];
const rows=[];
for(const [name,args] of checks){const row={name,args,startedAt:new Date().toISOString()};rows.push(row);const fd=openSync(`.tmp/ssr-data-path/check-${name}.log`,'w');console.log('START '+name);
try{await new Promise((yes,no)=>{const c=spawn(process.execPath,args,{windowsHide:true,env:{...process.env,NODE_ENV:name==='comparison-build'?'production':'test'},stdio:['ignore',fd,fd]});row.pid=c.pid;c.once('error',no);c.once('exit',code=>{row.code=code;code===0?yes():no(Error(name+' failed'));});});}
finally{closeSync(fd);row.endedAt=new Date().toISOString();writeFileSync('.tmp/ssr-data-path/checks.json',JSON.stringify(rows,null,2));}console.log('DONE '+name);}
