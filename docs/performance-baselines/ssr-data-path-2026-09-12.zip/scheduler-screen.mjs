import ts from 'typescript';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHook} from 'node:async_hooks';
import {performance} from 'node:perf_hooks';
const root='.tmp/ssr-data-path';
for(const variant of ['before','after'])writeFileSync(`${root}/scheduler-${variant}.mjs`,ts.transpileModule(readFileSync(`${root}/scheduler-${variant}.ts`,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText);
const variants={};for(const v of ['before','after'])variants[v]=(await import(`./scheduler-${v}.mjs`)).AsyncSsrScheduler;
const results=[];
for(let round=0;round<4;round++)for(const v of round%2?['after','before']:['before','after'])for(const count of [1,4,8]){
 const C=variants[v];const work=()=>Promise.resolve(1);
 async function sample(n){for(let i=0;i<n;i++){const s=new C(4);const tasks=[];for(let j=0;j<count;j++)tasks.push(s.run(work));const values=await Promise.all(tasks);if(values.some(x=>x!==1))throw Error('bad task result');}}
 await sample(1000);const start=performance.now();await sample(20000);const us=(performance.now()-start)*1000/20000;
 let promises=0;const hook=createHook({init(_id,type){if(type==='PROMISE')promises++;}});hook.enable();await sample(1000);hook.disable();
 const row={round,variant:v,tasks:count,microsecondsPerRequest:us,promisesPerRequest:promises/1000};results.push(row);console.log(JSON.stringify(row));
}
writeFileSync(`${root}/scheduler-screen.json`,JSON.stringify(results,null,2));
