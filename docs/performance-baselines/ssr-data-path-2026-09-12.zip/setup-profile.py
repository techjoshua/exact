from pathlib import Path
p=Path('.tmp/ssr-data-path');(p/'profiles').mkdir(exist_ok=True)
r=(p/'capacity.mjs').read_text()
r=r.replace('population<2','population<1')
r=r.replace("const runtime=availableSsrRuntimes(runtimeId)[0];", "const runtime=availableSsrRuntimes(runtimeId)[0];runtime.arguments=[...runtime.arguments,'--cpu-prof','--cpu-prof-dir='+resolve('.tmp/ssr-data-path/profiles')];")
(p/'profile-capacity.mjs').write_text(r)
