from pathlib import Path
p=Path('.tmp/ssr-data-path')
s=Path('framework-comparison/participants/exact/dist-server/server-entry.js').read_text()
start=s.index('function serializeJson(payload, replacer) {');end=s.index('\n}',start)+2
new=r'''function escapeHydrationCharacter(value) { return value === '<' ? '\u003C' : value === '\u2028' ? '\u2028' : '\u2029'; }
function serializeJson(payload, replacer) { return JSON.stringify(payload, replacer).replace(/[<\u2028\u2029]/g, escapeHydrationCharacter); }'''
(p/'escaping-candidate.mjs').write_text(s[:start]+new+s[end:])
r=(p/'projector-screen.mjs').read_text().replace('projector-candidate','escaping-candidate').replace('projector-screen-','escaping-screen-')
(p/'escaping-screen.mjs').write_text(r)
