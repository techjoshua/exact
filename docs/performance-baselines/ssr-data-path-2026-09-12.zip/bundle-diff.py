from pathlib import Path
import difflib,hashlib
p=Path('.tmp/ssr-data-path');s=p.joinpath('projector-candidate.mjs').read_text().replace('!state.path ? readPositionalProjector(schema[1]) : void 0','value.length >= 16 && !state.path ? readPositionalProjector(schema[1]) : void 0')
p.joinpath('original-node.mjs').write_text(s)
t=Path('framework-comparison/participants/exact/dist-server/server-entry.js').read_text();diff='\n'.join(difflib.unified_diff(s.splitlines(),t.splitlines(),fromfile='measured',tofile='rebuilt'))
p.joinpath('rebuilt-node.diff').write_text(diff)
print(diff[:8500])
