from pathlib import Path
p=Path('.tmp/ssr-data-path')
t=Path('packages/ssr/src/data-path-screen.test.mjs');t.write_text(t.read_text().replace("from '@exactjs/core'", "from './test-support/native-operations.js'"))
s=Path('framework-comparison/participants/exact/dist-server/server-entry.js').read_text()
needle='value.length >= 16 && !state.path ? readPositionalProjector(schema[1]) : void 0'
assert s.count(needle)==1
(p/'projector-candidate.mjs').write_text(s.replace(needle,'!state.path ? readPositionalProjector(schema[1]) : void 0'))
r=(p/'fresh-data.mjs').read_text().replace("['exact','react']", "['exact','candidate']").replace("['react','exact']", "['candidate','exact']")
r=r.replace("await import(`../../framework-comparison/participants/${id}/dist-server/server-entry.js`)", "await import(id==='candidate'?'./projector-candidate.mjs':`../../framework-comparison/participants/${id}/dist-server/server-entry.js`)")
r=r.replace('fresh-data-${', 'projector-screen-${')
(p/'projector-screen.mjs').write_text(r)
