from pathlib import Path
p=Path('.tmp/ssr-data-path');d=Path('packages/ssr/dist/render/async-scheduler.js');p.joinpath('scheduler-dist-original.js').write_bytes(d.read_bytes());d.write_text(d.read_text().replace('constructor(limit) {','constructor(limit) {\n        if(globalThis.__ssrScreenConstruct)return globalThis.__ssrScreenConstruct(limit);'))
t=Path('packages/ssr/src/data-path-screen.test.mjs');s=p.joinpath('compiled-task-screen-source.mjs').read_text();s=s.replace('const rows=[];', 'globalThis.__ssrScreenConstruct=(limit)=>{selection.constructed++;return new selection.constructors[selection.variant](limit);};\n const rows=[];').replace('await run(300)','await run(5000)').replace('await run(2000)','await run(5000)').replace('/2000','/5000')
t.write_text(s)
