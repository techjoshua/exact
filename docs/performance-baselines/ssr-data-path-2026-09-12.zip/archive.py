from pathlib import Path
import json,zipfile,hashlib
p=Path('.tmp/ssr-data-path')
verification={'sourceBefore':'103fa1da','ssrTests':423,'harnessTests':88,'docsTests':10,'successfulChecks':['ssr-build','ssr-rebuilt-tests','comparison-build','comparison-tests','docs-types','docs-tests','docs-build','platform','architecture','packages-final','lint-final','docs-browser'],'checks':json.loads(p.joinpath('checks.json').read_text()),'finalChecks':json.loads(p.joinpath('final-checks.json').read_text()),'notes':['The package check was rerun successfully with npm_execpath after direct npm.cmd spawning failed on Windows.','The attempted component scheduler screen did not reach the selected variant. Discard its timing differences.','The explicit native compilation of the SSR runtime was not part of its declared build plan. Its standard TypeScript build passed.'],'browser':json.loads(p.joinpath('docs-verification.json').read_text()),'taskOwnedProcessesRemaining':0}
p.joinpath('verification.json').write_text(json.dumps(verification,indent=2))
archive=Path('docs/performance-baselines/ssr-data-path-2026-09-12.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(p.rglob('*')):
  if f.is_file() and f.suffix in ['.json','.mjs','.ts','.log','.cpuprofile','.diff','.py']:
   z.write(f, str(f.relative_to(p)))
print('Evidence archive bytes:',archive.stat().st_size)
