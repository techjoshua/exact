import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync} from 'node:fs';
const steps=[];
for(const [runtime,mode] of [['node','string'],['bun','stream'],['node','stream'],['bun','string']])for(const policy of ['auto','off']){
 const name=`${runtime}-${mode}-${policy}`;console.log('START '+name);
 const step={name,startedAt:new Date().toISOString()};steps.push(step);
 const fd=openSync(`.tmp/ssr-data-path/${name}.log`,'w');
 try{await new Promise((yes,no)=>{const c=spawn(process.execPath,['.tmp/ssr-data-path/capacity.mjs','.tmp/ssr-data-path/plan.json',`.tmp/ssr-data-path/${name}.json`,runtime],{windowsHide:true,env:{...process.env,NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:mode,DATA_PATH_POLICY:policy},stdio:['ignore',fd,fd]});step.pid=c.pid;c.on('error',no);c.on('exit',code=>{step.code=code;code===0?yes():no(Error(name+' '+code));});});}
 finally{closeSync(fd);step.endedAt=new Date().toISOString();writeFileSync('.tmp/ssr-data-path/execution.json',JSON.stringify(steps,null,2));}
 console.log('DONE '+name);
}
