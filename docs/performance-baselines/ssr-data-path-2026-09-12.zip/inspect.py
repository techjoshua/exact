import json
from pathlib import Path
p=Path('.tmp/ssr-data-path/node-string-auto.json');d=json.loads(p.read_text());b=d['blocks'][0]
print('interval', b['serviceIntervals'][-2]);print('driverstage',b['results'][0]['stages'][-1]);print('worker',b['telemetry'][-1]['value']['cpu'])
