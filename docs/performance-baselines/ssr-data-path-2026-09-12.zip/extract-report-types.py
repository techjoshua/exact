from pathlib import Path
p=Path('apps/docs/src/pages/PerformancePage.tsx');s=p.read_text()
a=s.index('interface DistributionStatistics');b=s.index('const report = reportJson as unknown as {');c=s.index('\n};',b)+3
interfaces=s[a:b]
for name,description in [('DistributionStatistics','Percentile values admitted by the benchmark report.'),('DistributionChart','A benchmark distribution rendered without recomputing its statistics.'),('ValueChart','Scalar benchmark measurements with their display units.'),('ResponseCompositionChart','Per-framework document byte categories.')]:
 interfaces=interfaces.replace('interface '+name, '/** '+description+' */\n'+('' if name=='DistributionStatistics' else 'export ')+'interface '+name)
report=s[b:c].replace('const report = reportJson as unknown as {','/** Published browser and SSR data consumed by the performance page. */\nexport interface PerformanceReport {').removesuffix(';')
Path('apps/docs/src/data/performance-report-types.ts').write_text(interfaces+report+'\n')
s=s[:a]+"import type { DistributionChart, ValueChart, ResponseCompositionChart, PerformanceReport } from '../data/performance-report-types.js';\n\nconst report = reportJson as unknown as PerformanceReport;"+s[c:]
p.write_text(s)
