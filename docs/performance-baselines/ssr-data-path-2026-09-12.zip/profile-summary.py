import json,collections
from pathlib import Path
for p in Path('.tmp/ssr-data-path/profiles').glob('*.cpuprofile'):
 d=json.loads(p.read_text());nodes={n['id']:n for n in d['nodes']};counts=collections.Counter()
 for id,dt in zip(d['samples'],d['timeDeltas']):
  f=nodes[id]['callFrame'];counts[(f['functionName'],f['url'],f['lineNumber'])]+=dt
 print(p.name)
 for (name,url,line),n in counts.most_common(18): print(round(n/1000),name,url[-85:],line+1)
rows=json.loads(Path('.tmp/ssr-data-path/fresh-data-node.json').read_text());groups=collections.defaultdict(list)
for row in rows:groups[(row['id'],row['fresh'])].append(round(row['us'],2))
print(dict(groups))
