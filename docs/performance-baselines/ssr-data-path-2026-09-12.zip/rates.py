import json
from pathlib import Path
for p in sorted(Path('.tmp/ssr-data-path').glob('*.json')):
 d=json.loads(p.read_text())
 if not isinstance(d,dict) or 'blocks' not in d: continue
 print(p.stem,[(b['id'],round(sum(r['stages'][-1]['validRps'] for r in b['results']))) for b in d['blocks']])
