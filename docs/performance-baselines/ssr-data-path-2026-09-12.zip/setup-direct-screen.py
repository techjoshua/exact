from pathlib import Path
p=Path('.tmp/ssr-data-path')
# Restore every experimentally instrumented generated artifact before another test.
for target in ['', 'server/','client/']:
 suffix='-'+target.rstrip('/') if target else ''
 Path(f'packages/ssr/dist/{target}render/async-scheduler.js').write_bytes(p.joinpath(f'scheduler-dist{suffix}-original.js').read_bytes())
t=Path('packages/ssr/src/data-path-screen.test.mjs');s=p.joinpath('compiled-task-screen-source.mjs').read_text()
s=s.replace("import {renderToString} from './index.js';", "import {createSsrContext} from './render/context.js';\nimport {createDirectScheduledSsrComponent} from './render/direct-component-scheduling.js';")
s=s.replace("['child',ParentWithSettledChild,'<section><strong>Ready</strong></section>']", "['task-repeat',ProfileComponent,'<p>Ada</p>']")
s=s.replace("const result=await renderToString(createOperation(component,{}),{markers:false});if(result.html!==expected)throw Error('Wrong task output: '+result.html);", "const contract=Reflect.get(component,Symbol.for('@exactjs/component-contract'));const result=await createDirectScheduledSsrComponent(createSsrContext({}),{componentId:contract.artifact.id,contract},{},undefined,{});await result.drain();if(result.snapshot.state.name!=='Ada')throw Error('Wrong task state');await result[Symbol.asyncDispose]();")
s=s.replace('await run(300)','await run(5000)').replace('await run(2000)','await run(5000)').replace('/2000','/5000')
s=s.replace('compiled-task-screen.json','direct-task-screen.json')
t.write_text(s)
