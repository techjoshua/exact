import {it,vi} from 'vitest';
import {writeFileSync} from 'node:fs';
import {createHook} from 'node:async_hooks';
import {createOperation} from './test-support/native-operations.js';
import {createSsrContext} from './render/context.js';
import {createDirectScheduledSsrComponent} from './render/direct-component-scheduling.js';
import {ProfileComponent,ParentWithSettledChild} from './component-rendering.fixtures.test.tsx';
const selection=vi.hoisted(()=>({variant:'before',constructors:{},constructed:0}));
vi.mock('./render/async-scheduler.js',()=>({AsyncSsrScheduler:class {constructor(limit){selection.constructed++;return new selection.constructors[selection.variant](limit);}}}));
it('screens scheduler variants against compiled task components',async()=>{
 for(const v of ['before','after'])selection.constructors[v]=(await import(new URL(`../../../.tmp/ssr-data-path/scheduler-${v}.mjs`,import.meta.url).href)).AsyncSsrScheduler;
 const rows=[];
 for(let round=0;round<4;round++)for(const variant of round%2?['after','before']:['before','after'])for(const [name,component,expected] of [['task',ProfileComponent,'<p>Ada</p>'],['task-repeat',ProfileComponent,'<p>Ada</p>']]){
  selection.variant=variant;
  async function run(n){for(let i=0;i<n;i++){const contract=Reflect.get(component,Symbol.for('@exactjs/component-contract'));const result=await createDirectScheduledSsrComponent(createSsrContext({}),{componentId:contract.artifact.id,contract},{},undefined,{});await result.drain();if(result.snapshot.state.name!=='Ada')throw Error('Wrong task state');await result[Symbol.asyncDispose]();}}
  await run(5000);const start=performance.now();await run(5000);const us=(performance.now()-start)*1000/5000;
  let promises=0;const hook=createHook({init(_id,type){if(type==='PROMISE')promises++;}});hook.enable();try{await run(100);}finally{hook.disable();}
  rows.push({round,variant,name,us,promisesPerRender:promises/100});
 }
 if(!selection.constructed)throw Error('Scheduler not reached by fixture');
 writeFileSync(new URL('../../../.tmp/ssr-data-path/direct-task-screen.json',import.meta.url),JSON.stringify(rows,null,2));
},120000);



