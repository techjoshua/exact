import json,statistics
from pathlib import Path
for file in ['projector-screen-node.json','compiled-task-screen.json']:
 p=Path('.tmp/ssr-data-path')/file
 if not p.exists():continue
 groups={}
 for row in json.loads(p.read_text()):
  key=(row.get('id',row.get('variant')),row.get('fresh',row.get('name')))
  groups.setdefault(key,[]).append(round(row['us'],2))
 print(file,groups)
