import json
from pathlib import Path
for p in Path('.tmp/ssr-data-path').glob('node-string-*.json'):
 d=json.loads(p.read_text())
 print(p.name)
 for b in d['blocks']:
  stages=[r['stages'][-1] for r in b['results']]
  t=b['telemetry'][-1]['value']['statistics']
  print(b['population'],b['id'],round(sum(s['validRps'] for s in stages)), {k:round(v['sum']/v['count'],3) for k,v in t.items() if v['count'] and k in ['dataLoadMs','dataFetchMs','dataDecodeMs','renderMs','totalMs','participantWorkMs']})

