from pathlib import Path
p=Path('.tmp/ssr-data-path')
for target in ['server','client']:
 d=Path(f'packages/ssr/dist/{target}/render/async-scheduler.js');p.joinpath(f'scheduler-dist-{target}-original.js').write_bytes(d.read_bytes());d.write_text(d.read_text().replace('constructor(limit) {','constructor(limit) {\n        if(globalThis.__ssrScreenConstruct)return globalThis.__ssrScreenConstruct(limit);'))
