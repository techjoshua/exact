from pathlib import Path
import hashlib,json
p=Path('.tmp/ssr-data-path')
checks={}
for runtime in ['node','bun']:
 d=json.loads(p.joinpath(f'{runtime}-string-auto.json').read_text())
 f=Path(d['artifacts']['exact']['path']); checks[runtime]={'before':d['artifacts']['exact']['sha256'],'after':hashlib.sha256(f.read_bytes()).hexdigest()}
print(checks)
p.joinpath('rebuilt-artifacts.json').write_text(json.dumps(checks,indent=2))
