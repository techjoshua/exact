import {readFileSync,writeFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {createComparisonService} from '../../framework-comparison/src/service.mjs';
const service=createComparisonService(JSON.parse(readFileSync('framework-comparison/fixtures/baseline.json','utf8')));
let data;
try{const [session,incidents]=await Promise.all(['/api/session','/api/incidents'].map(async path=>(await service.fetch(new Request('http://local'+path))).json()));data={...session,...incidents};}finally{service.dispose();}
const serialized=JSON.stringify(data), participants={};
for(const id of ['exact','react'])participants[id]=(await import(`../../framework-comparison/participants/${id}/dist-server/server-entry.js`)).renderParticipant;
const results=[];
for(let round=0;round<4;round++)for(const id of round%2?['react','exact']:['exact','react'])for(const fresh of [false,true]){
 const render=participants[id];const expected=await render(data,'/incidents/inc-101');let bytes=0;
 async function run(n){for(let i=0;i<n;i++){const html=await render(fresh?JSON.parse(serialized):data,'/incidents/inc-101');if(html.length!==expected.length)throw Error('length mismatch');bytes+=html.length;}}
 await run(1000);const start=performance.now();await run(10000);const row={round,id,fresh,us:(performance.now()-start)*1000/10000,characters:expected.length};results.push(row);console.log(row);
}
writeFileSync(`.tmp/ssr-data-path/fresh-data-${process.versions.bun?'bun':'node'}.json`,JSON.stringify(results,null,2));
