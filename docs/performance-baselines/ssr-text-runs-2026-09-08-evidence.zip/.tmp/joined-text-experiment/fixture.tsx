import { type Component, batch } from '@exactjs/core';
import { flushSync } from '@exactjs/reactive';

type RowState = { owner: string; status: string };
const instances: Component<RowState>[] = [];

function Row(this: Component<RowState>, props: { index: number }) {
	instances.push(this);
	this.state.owner = 'Assigned';
	this.state.status = 'open';
	return () => <small>{this.state.owner} · {this.state.status}</small>;
}

function Rows(props: { rows: number[] }) {
	return () => <section>{props.rows.map(index => <Row index={index} />)}</section>;
}

export function tree(rows: number[]) {
	instances.length = 0;
	return <Rows rows={rows} />;
}
export function update(value: number, both = false) {
	batch(() => {
		for (const instance of instances) {
			instance.state.status = value % 2 ? 'closed' : 'open';
			if (both) instance.state.owner = value % 2 ? 'Unassigned' : 'Assigned';
		}
	});
	flushSync();
}
export function release() { instances.length = 0; }
