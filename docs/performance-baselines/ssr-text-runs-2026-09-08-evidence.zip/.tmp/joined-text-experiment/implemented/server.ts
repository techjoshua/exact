import { renderToHydratableString } from '@exactjs/ssr';
import { tree, release } from './fixture.jsx';
const inputs = new Map<number, number[]>();
export function render(count: number) {
	let rows = inputs.get(count);
	if (!rows) { rows = Array.from({ length: count }, (_, index) => index); inputs.set(count, rows); }
	try { return renderToHydratableString(tree(rows)).htmlWithHydration; }
	finally { release(); }
}
