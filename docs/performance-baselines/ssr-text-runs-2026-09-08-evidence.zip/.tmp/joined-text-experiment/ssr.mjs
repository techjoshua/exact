import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const names=process.env.TEXT_VARIANTS?.split(',') ?? ['separate','joined'];
const entries=Object.fromEntries(await Promise.all(names.map(async name=>[name,await import(`./${name}/dist-server/entry.js`)])));
const samples=[],documents={};let consumed=0;
const visible=html=>html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/g,'').replace(/<!--[\s\S]*?-->/g,'');
for(const count of [3,100,1000]){
 documents[count]={};
 for(const name of names){documents[count][name]=entries[name].render(count);for(let i=0;i<500;i++)consumed+=entries[name].render(count).length;}
 for(const name of names){const matches=[...documents[count][name].matchAll(/<small[^>]*>([\s\S]*?)<\/small>/g)];assert.equal(matches.length,count);assert.equal(matches.filter(m=>m[1].includes('<!--')).length,name==='separate'?count:0);assert.equal(visible(documents[count].separate),visible(documents[count][name]));}
 const iterations=count===1000?200:count===100?1000:5000;
 for(let round=0;round<12;round++)for(const name of round%2?[...names].reverse():names){const start=performance.now();for(let i=0;i<iterations;i++)consumed+=entries[name].render(count).length;samples.push({count,name,round,microseconds:(performance.now()-start)*1000/iterations});}
 console.log(count,...names.map(name=>[name,samples.filter(s=>s.count===count&&s.name===name).reduce((n,s)=>n+s.microseconds,0)/12,Buffer.byteLength(documents[count][name])]));
}
await writeFile(`.tmp/joined-text-experiment/ssr-${globalThis.Bun?'bun':'node'}${process.env.TEXT_RUN?'-'+process.env.TEXT_RUN:''}.json`,JSON.stringify({samples,consumed},null,2));
await writeFile('.tmp/joined-text-experiment/documents.json',JSON.stringify(documents));
