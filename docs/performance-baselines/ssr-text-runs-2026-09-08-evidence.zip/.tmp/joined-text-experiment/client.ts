import { hydrate } from '@exactjs/hydrate';
import { tree, update, release } from './fixture.jsx';
let root: ReturnType<typeof hydrate> | undefined;
export function setup(count: number, html: string) {
	root?.dispose(); release();
	const container = document.getElementById('root')!;
	container.innerHTML = html;
	const before = Array.from(container.querySelectorAll('small'));
	const rows = Array.from({ length: count }, (_, index) => index);
	const start = performance.now();
	root = hydrate(tree(rows), container);
	const elapsed = performance.now() - start;
	if (before.some((element, i) => container.querySelectorAll('small')[i] !== element)) throw Error('Replaced SSR elements');
	return elapsed;
}
export function updates(iterations: number, both = false) {
	const start = performance.now();
	for (let i = 0; i < iterations; i++) update(i, both);
	return (performance.now() - start) / iterations;
}
export function check() {
	update(1, true);
	const rows = Array.from(document.querySelectorAll('small'));
	if (rows.some(row => row.textContent !== 'Unassigned · closed')) throw Error('Combined update failed');
	update(0, false);
	if (rows.some(row => row.textContent !== 'Unassigned · open')) throw Error('Independent update failed');
	return rows.map(row => ({text: row.textContent, nodes: row.childNodes.length}));
}
export function dispose() { root?.dispose(); root = undefined; release(); }
