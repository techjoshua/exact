import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {build} from '../../framework-comparison/node_modules/vite/dist/node/index.js';
import {exact} from '../../framework-adapters/vite-plugin/dist/index.js';
const dir=resolve('.tmp/joined-text-experiment');
const source=await readFile(dir+'/fixture.tsx','utf8');
for(const name of process.env.TEXT_VARIANTS?.split(',') ?? ['separate','joined']) {
 const root=dir+'/'+name;await mkdir(root,{recursive:true});
 const fixture=(name==='separate'||name==='implemented')?source:name==='derived'?source.replace('return () => <small>{this.state.owner} · {this.state.status}</small>;', 'const label = `${this.state.owner} · ${this.state.status}`;\n\treturn () => <small>{label}</small>;'):source.replace('{this.state.owner} · {this.state.status}', '{`${this.state.owner} · ${this.state.status}`}');
 if(name==='joined'&&fixture===source)throw Error('Missing replacement');
 await writeFile(root+'/fixture.tsx',fixture);
 await writeFile(root+'/package.json',JSON.stringify({name:'exact-text-'+name,private:true,type:'module'}));
 await writeFile(root+'/tsconfig.json',JSON.stringify({compilerOptions:{target:'ESNext',module:'ESNext',moduleResolution:'Bundler',jsx:'react-jsx',jsxImportSource:'@exactjs/jsx',strict:true},include:['*.ts','*.tsx']}));
 for(const target of ['server','client']) {
  await copyFile(dir+'/'+target+'.ts',root+'/'+target+'.ts');
  await build({configFile:false,root,logLevel:'warn',plugins:[exact({target:target==='server'?'server':'client',renderMode:target==='server'?'server-render':'hydrate'})],build:{outDir:root+'/dist-'+target,emptyOutDir:true,minify:false,...(target==='server'?{ssr:root+'/server.ts'}:{lib:{entry:root+'/client.ts',formats:['es']}}),rollupOptions:{output:{entryFileNames:'entry.js'}}}});
 }
}
