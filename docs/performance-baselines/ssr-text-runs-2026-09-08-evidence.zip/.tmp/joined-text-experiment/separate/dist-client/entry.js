//#region packages/core/dist/client/component/element-identity.js
var identities = /* @__PURE__ */ new WeakMap();
var idToken = /^[^\t\n\f\r ]+$/u;
/**
* Associates a live element with its ref identity, preserving a valid authored ID when present.
* A generated token remains on the element after individual relationships are released.
*/
function attachElementIdentity(binding, element) {
	const authored = validElementId(element.id);
	if (authored) {
		identities.set(binding, {
			id: authored,
			generated: false
		});
		return;
	}
	if (element.id) return;
	const reserved = identities.get(binding);
	if (reserved) element.id = reserved.id;
}
function validElementId(value) {
	return typeof value === "string" && idToken.test(value) ? value : void 0;
}
//#endregion
//#region packages/reactive/dist/internal/dependency-graph.js
var deps = /* @__PURE__ */ new WeakMap();
var depObservationHooks = /* @__PURE__ */ new WeakMap();
var reactionStack = [];
/** Contains only synchronous reruns; popped passes cannot retain disposed reactions. */
var trackingPasses = [];
var trackingPauseFloors = [];
var pendingObservationTransitions = [];
var publishingObservationTransitions = false;
/** Records that the active reaction depends on a target/key pair. */
function track(target, key) {
	const pauseFloor = trackingPauseFloors[trackingPauseFloors.length - 1];
	if (pauseFloor !== void 0 && reactionStack.length <= pauseFloor) return false;
	const reaction = reactionStack[reactionStack.length - 1];
	if (!reaction) return false;
	linkReaction(reaction, target, key);
	return true;
}
/** Registers lifecycle hooks for the observer count of one dependency source. */
function registerDependencyObservationHooks(target, key, hooks) {
	let targetHooks = depObservationHooks.get(target);
	if (!targetHooks) depObservationHooks.set(target, targetHooks = /* @__PURE__ */ new Map());
	targetHooks.set(key, hooks);
	return () => {
		const current = depObservationHooks.get(target);
		if (current?.get(key) !== hooks) return;
		current.delete(key);
		if (!current.size) depObservationHooks.delete(target);
	};
}
/** Adds a reaction to one dependency while preserving observer-count transitions. */
function linkReaction(reaction, target, key) {
	linkReactionToDependency(reaction, getDep(target, key));
}
/** Adds a reaction to an existing dependency set while preserving observer-count transitions. */
function linkReactionToDependency(reaction, dep) {
	const subscribers = dep.subscribers;
	const pass = trackingPasses[trackingPasses.length - 1];
	const collecting = pass?.reaction === reaction;
	if (subscribers === reaction || subscribers instanceof Set && subscribers.has(reaction)) {
		if (collecting && !pass.seen.has(dep)) {
			pass.seen.add(dep);
			reaction.deps.push(dep);
		}
		return;
	}
	if (collecting) pass.seen.add(dep);
	const wasEmpty = subscribers === void 0;
	dep.subscribers = subscribers === void 0 ? reaction : subscribers instanceof Set ? subscribers.add(reaction) : /* @__PURE__ */ new Set([subscribers, reaction]);
	reaction.deps.push(dep);
	if (wasEmpty) publishObservationTransition(depObservationHooks.get(dep.target)?.get(dep.key)?.onObserved);
}
/** Returns immutable target/key descriptors for a reaction's current dependencies. */
function reactionDependencies(reaction) {
	return reaction.deps;
}
/** Returns the dependency set for a target/key pair, creating it on first use. */
function getDep(target, key) {
	let targetDeps = deps.get(target);
	if (!targetDeps) deps.set(target, targetDeps = /* @__PURE__ */ new Map());
	let dep = targetDeps.get(key);
	if (!dep) {
		dep = {
			target,
			key
		};
		targetDeps.set(key, dep);
	}
	return dep;
}
/** Removes a reaction from all dependency sets it currently belongs to. */
function cleanupReaction(reaction) {
	for (const pass of trackingPasses) if (pass.reaction === reaction) {
		for (const dep of pass.previous) detachDependency(reaction, dep);
		pass.previous = [];
	}
	for (const dep of reaction.deps) detachDependency(reaction, dep);
	reaction.deps.length = 0;
}
/** Removes a single membership and publishes a real last-observer transition. */
function detachDependency(reaction, dep) {
	const subscribers = dep.subscribers;
	if (subscribers === reaction) dep.subscribers = void 0;
	else if (subscribers instanceof Set && subscribers.delete(reaction)) {
		if (subscribers.size === 1) dep.subscribers = subscribers.values().next().value;
		else if (subscribers.size === 0) dep.subscribers = void 0;
	} else return;
	if (dep.subscribers === void 0) releaseEmptyDependency(dep);
}
/** Schedules one stable snapshot of the reactions subscribed to a dependency. */
function scheduleDependencyReactions(target, key) {
	const dep = deps.get(target)?.get(key);
	const subscribers = dep?.subscribers;
	if (subscribers instanceof Set) {
		for (const reaction of [...subscribers]) if (observesDuringTracking(reaction, dep)) reaction.schedule();
	} else if (subscribers && observesDuringTracking(subscribers, dep)) subscribers.schedule();
}
/** Schedules subscribers for an atomic trigger collection through the coalescing scheduler. */
function scheduleTriggeredReactions(triggers) {
	if (!triggers.size) return;
	const reactions = /* @__PURE__ */ new Set();
	for (const [target, keys] of triggers) {
		const targetDeps = deps.get(target);
		if (!targetDeps) continue;
		for (const key of keys) {
			const dep = targetDeps.get(key);
			const subscribers = dep?.subscribers;
			if (subscribers instanceof Set) {
				for (const reaction of subscribers) if (observesDuringTracking(reaction, dep)) reactions.add(reaction);
			} else if (subscribers && observesDuringTracking(subscribers, dep)) reactions.add(subscribers);
		}
	}
	for (const reaction of reactions) reaction.schedule();
}
/** Old memberships remain retained until exit but cannot invalidate an unread branch during execution. */
function observesDuringTracking(reaction, dep) {
	for (let i = trackingPasses.length - 1; i >= 0; i--) {
		const pass = trackingPasses[i];
		if (pass.reaction === reaction) return pass.seen.has(dep);
	}
	return true;
}
/**
* Collects replacement dependencies without tearing down memberships that the reaction rereads.
* Old memberships are ineligible to notify this execution until read again. Unused memberships
* are released on exit, including exceptional exits; disposal also releases reads made afterward.
*/
function runTracked(reaction, fn) {
	const pass = {
		reaction,
		previous: reaction.deps,
		seen: /* @__PURE__ */ new Set()
	};
	reaction.deps = [];
	trackingPasses.push(pass);
	reactionStack.push(reaction);
	try {
		fn();
	} finally {
		reactionStack.pop();
		trackingPasses.pop();
		for (const dep of pass.previous) if (!pass.seen.has(dep)) detachDependency(reaction, dep);
		if (!reaction.active) cleanupReaction(reaction);
	}
}
/** Runs a function without linking its reads to the currently active reaction. */
function peek(fn) {
	trackingPauseFloors.push(reactionStack.length);
	try {
		return fn();
	} finally {
		trackingPauseFloors.pop();
	}
}
function releaseEmptyDependency(dep) {
	publishObservationTransition(depObservationHooks.get(dep.target)?.get(dep.key)?.onUnobserved);
	const targetDeps = deps.get(dep.target);
	if (targetDeps?.get(dep.key) === dep) targetDeps.delete(dep.key);
	if (targetDeps && !targetDeps.size) deps.delete(dep.target);
}
function publishObservationTransition(transition) {
	if (!transition) return;
	pendingObservationTransitions.push(transition);
	if (publishingObservationTransitions) return;
	publishingObservationTransitions = true;
	try {
		while (pendingObservationTransitions.length) pendingObservationTransitions.pop()();
	} finally {
		publishingObservationTransitions = false;
	}
}
//#endregion
//#region packages/reactive/dist/internal/deps.js
var transactions = [];
var mutationVersions = /* @__PURE__ */ new WeakMap();
var restorationVersion = 0;
/** Schedules every reaction currently subscribed to a target/key pair. */
function trigger(target, key) {
	const previousVersion = readMutationVersion(target, key);
	const nextVersion = incrementMutationVersion(target, key);
	const transaction = transactions[transactions.length - 1];
	if (transaction) {
		let keys = transaction.triggers.get(target);
		if (!keys) {
			keys = /* @__PURE__ */ new Set();
			transaction.triggers.set(target, keys);
		}
		keys.add(key);
		if (transaction.versionRanges) recordMutationVersionRange(transaction.versionRanges, target, key, previousVersion, nextVersion);
		return;
	}
	triggerNow(target, key);
}
/**
* Runs a group of writes as one atomic observable state transition.
* Reactive mutations are rolled back when the callback throws.
* The transaction covers synchronous callback execution only. If the callback
* returns a promise, synchronous writes are committed before that promise
* settles; use separate batches after awaits.
*/
function batch(fn) {
	const parent = transactions[transactions.length - 1];
	const transaction = createTransaction(true, Boolean(parent?.versionRanges));
	transactions.push(transaction);
	let result;
	try {
		result = fn();
	} catch (error) {
		transactions.pop();
		rollbackTransaction(transaction);
		throw error;
	}
	transactions.pop();
	publishTransaction(parent, transaction);
	return result;
}
/**
* Publishes one framework-owned synchronous update group without retaining inverse mutations.
*
* Native compiled event handlers use this lane because ordinary event mutations remain published
* when a later statement throws. A surrounding rollback-capable transaction upgrades the lane so
* its complete atomic contract is preserved when framework operations are nested.
*
* @internal
*/
function publishBatch(fn) {
	const parent = transactions[transactions.length - 1];
	const transaction = createTransaction(Boolean(parent?.undos), Boolean(parent?.versionRanges));
	transactions.push(transaction);
	let result;
	try {
		result = fn();
	} catch (error) {
		transactions.pop();
		publishTransaction(parent, transaction);
		throw error;
	}
	transactions.pop();
	publishTransaction(parent, transaction);
	return result;
}
/**
* Records an inverse operation for the currently active transaction.
*
* Supplying the mutated target and dependency key lets a retained optimistic
* journal preserve a newer authoritative write to that path during rollback.
*/
function recordTransactionUndo(undo, target, key) {
	transactions[transactions.length - 1]?.undos?.push({
		apply: undo,
		target,
		key
	});
}
/** Returns whether mutations currently need an inverse journal entry. */
function hasActiveTransaction() {
	return Boolean(transactions[transactions.length - 1]?.undos);
}
/** Returns whether target/key notifications are currently deferred by a reactive transaction. */
function hasActiveReactiveTransaction() {
	return transactions.length > 0;
}
function mergeTransaction(parent, child) {
	if (parent.undos && child.undos) parent.undos.push(...child.undos);
	mergeTriggers(parent.triggers, child.triggers);
	if (parent.versionRanges && child.versionRanges) mergeVersionRanges(parent.versionRanges, child.versionRanges);
}
function publishTransaction(parent, transaction) {
	if (parent) mergeTransaction(parent, transaction);
	else flushTriggers(transaction.triggers);
}
function mergeTriggers(parent, child) {
	for (const [target, keys] of child) {
		let pending = parent.get(target);
		if (!pending) {
			pending = /* @__PURE__ */ new Set();
			parent.set(target, pending);
		}
		for (const key of keys) pending.add(key);
	}
}
function rollbackTransaction(transaction, protectedVersions) {
	const undos = transaction.undos;
	if (!undos) return;
	const restored = /* @__PURE__ */ new Map();
	for (let index = undos.length - 1; index >= 0; index--) {
		const undo = undos[index];
		if (protectedVersions && undo.target && undo.key !== void 0 && readMutationVersion(undo.target, undo.key) !== protectedVersions.get(undo.target)?.get(undo.key)) continue;
		undo.apply();
		if (undo.target && undo.key !== void 0) recordRestoredDependency(restored, undo.target, undo.key);
	}
	advanceRestoredDependencyVersions(restored);
}
function incrementMutationVersion(target, key) {
	let versions = mutationVersions.get(target);
	if (!versions) mutationVersions.set(target, versions = /* @__PURE__ */ new Map());
	const next = (versions.get(key) ?? 0) + 1;
	versions.set(key, next);
	return next;
}
/** Returns the current mutation generation for one dependency without tracking it. */
function readMutationVersion(target, key) {
	return mutationVersions.get(target)?.get(key) ?? 0;
}
/** Returns the generation of the most recent transaction restoration. */
function readReactiveRestorationVersion() {
	return restorationVersion;
}
function createTransaction(rollback, retainVersions = false) {
	return {
		...rollback ? { undos: [] } : {},
		triggers: /* @__PURE__ */ new Map(),
		...retainVersions ? { versionRanges: /* @__PURE__ */ new Map() } : {}
	};
}
function recordMutationVersionRange(versionRanges, target, key, start, end) {
	let ranges = versionRanges.get(target);
	if (!ranges) versionRanges.set(target, ranges = /* @__PURE__ */ new Map());
	const range = ranges.get(key);
	if (range) range.end = end;
	else ranges.set(key, {
		start,
		end
	});
}
function mergeVersionRanges(parent, child) {
	for (const [target, childRanges] of child) {
		let ranges = parent.get(target);
		if (!ranges) parent.set(target, ranges = /* @__PURE__ */ new Map());
		for (const [key, childRange] of childRanges) {
			const range = ranges.get(key);
			if (range) range.end = childRange.end;
			else ranges.set(key, { ...childRange });
		}
	}
}
function recordRestoredDependency(restored, target, key) {
	let keys = restored.get(target);
	if (!keys) restored.set(target, keys = /* @__PURE__ */ new Set());
	keys.add(key);
}
function advanceRestoredDependencyVersions(restored) {
	if (!restored.size) return;
	for (const [target, keys] of restored) for (const key of keys) incrementMutationVersion(target, key);
	restorationVersion++;
}
function flushTriggers(triggers) {
	scheduleTriggeredReactions(triggers);
}
function triggerNow(target, key) {
	scheduleDependencyReactions(target, key);
}
//#endregion
//#region packages/instrumentation/dist/index.js
/** Publishes an observation without allowing an instrumentation failure to affect framework work. */
function publishExactProfile(sink, event) {
	if (!sink) return;
	try {
		sink(event);
	} catch {}
}
/** Returns a monotonic high-resolution timestamp when the host provides one. */
function profileTimestamp() {
	return globalThis.performance?.now() ?? Date.now();
}
//#endregion
//#region packages/reactive/dist/internal/scheduler.js
var queuedReactions = /* @__PURE__ */ new Map();
var queuedComputations = /* @__PURE__ */ new Map();
var priorityStack = [];
var foregroundFlushScheduled = false;
var deferredFlushScheduled = false;
var consecutiveForegroundFlushes = 0;
var maxFlushPasses = 1e3;
var maxForegroundFlushesBeforeDeferred = 8;
var priorityOrder = {
	interactive: 0,
	normal: 1,
	deferred: 2
};
var captureScheduledWorkContext;
var settlementCallbacks = /* @__PURE__ */ new Set();
var settlementScheduled = false;
var settling = false;
/** Installs framework ownership capture for subsequently scheduled reactive work. */
function setScheduledWorkContextCapture(capture) {
	captureScheduledWorkContext = capture;
}
/** Queues a reaction to run during the next scheduler flush. */
function queueReaction(reaction, priority = currentWorkPriority()) {
	priority = constrainedPriority(reaction.scope, priority);
	const previous = queuedReactions.get(reaction);
	const context = captureScheduledWorkContext?.(priority);
	if (context) previous?.context?.cancel();
	if (!previous || isHigherWorkPriority(priority, previous.priority) || context) queuedReactions.set(reaction, {
		priority: previous && !isHigherWorkPriority(priority, previous.priority) ? previous.priority : priority,
		context: context ?? previous?.context
	});
	scheduleFlush(priority);
}
/** Queues an arbitrary computation to run before reactions during the next flush. */
function queueComputation(computation, onError, priority = currentWorkPriority(), scope) {
	priority = constrainedPriority(scope, priority);
	const previous = queuedComputations.get(computation);
	if (!previous || isHigherWorkPriority(priority, previous.priority)) queuedComputations.set(computation, {
		priority,
		onError: onError ?? previous?.onError,
		scope: scope ?? previous?.scope
	});
	scheduleFlush(priority);
}
/** Removes a computation that was queued but has already been run synchronously. */
function removeQueuedComputation(computation) {
	queuedComputations.delete(computation);
}
/**
* Releases queued work for one stopped scope or a completed subtree in one queue traversal.
*
* Paused work is deliberately ineligible for ordinary draining, so scope teardown must remove it
* explicitly rather than relying on a later flush to observe that the scope is inactive.
*/
function discardScheduledScopeWork(scope, scopes) {
	for (const reaction of queuedReactions.keys()) if (scopes ? reaction.scope && scopes.has(reaction.scope) : reaction.scope === scope) {
		queuedReactions.get(reaction)?.context?.cancel();
		queuedReactions.delete(reaction);
	}
	for (const [computation, queued] of queuedComputations) if (scopes ? queued.scope && scopes.has(queued.scope) : queued.scope === scope) queuedComputations.delete(computation);
}
/** Allocates a subtree purge batch only when queue scanning can repeat across descendants. */
function createScheduledScopePurge() {
	return queuedReactions.size || queuedComputations.size ? /* @__PURE__ */ new Set() : void 0;
}
/** Returns the priority inherited by work scheduled in the current synchronous execution scope. */
function currentWorkPriority() {
	return priorityStack[priorityStack.length - 1] ?? "normal";
}
/** Runs synchronous work so its reactive invalidations inherit the requested priority. */
function runWithPriority(priority, work) {
	priorityStack.push(priority);
	try {
		return work();
	} finally {
		priorityStack.pop();
	}
}
/** Schedules framework-owned computation work at an explicit priority. */
function scheduleWork(work, priority = currentWorkPriority(), onError, scope) {
	queueComputation(work, onError, priority, scope);
}
/** Reschedules queued work whose owning scopes may just have become runnable. */
function resumeScheduledWork() {
	scheduleRemainingWork();
}
/**
* Drains pending work through a priority until the eligible scheduler reaches a stable state.
*
* The default drains every priority for deterministic SSR, testing, and explicit synchronous
* rendering. Passing `normal` leaves deferred work queued for its host turn.
*/
function flushSync(through = "deferred") {
	let passes = 0;
	let firstError;
	let hasError = false;
	let profileStarted;
	const profiledReactions = /* @__PURE__ */ new Map();
	try {
		while (hasEligibleWork(through)) {
			if (++passes > maxFlushPasses) {
				const overflow = /* @__PURE__ */ new Error("eXact reactive scheduler exceeded its flush limit; a reaction is repeatedly invalidating itself");
				if (settleOverflow(overflow)) return;
				throw overflow;
			}
			while (hasEligibleComputations(through)) {
				if (++passes > maxFlushPasses) {
					const overflow = /* @__PURE__ */ new Error("eXact reactive scheduler exceeded its flush limit; a computation is repeatedly invalidating itself");
					if (settleOverflow(overflow)) return;
					throw overflow;
				}
				const computations = takeEligibleComputations(through);
				for (const [computation, queued] of computations) {
					if (queued.scope && !queued.scope.active) continue;
					try {
						runWithPriority(queued.priority, computation);
					} catch (error) {
						if (queued.onError) try {
							queued.onError(error);
						} catch (handlerError) {
							if (!hasError) firstError = handlerError;
							hasError = true;
						}
						else {
							if (!hasError) firstError = error;
							hasError = true;
						}
					}
				}
			}
			const reactions = takeEligibleReactions(through);
			for (const [reaction, queued] of reactions) {
				if (!reaction.active || reaction.scope && (!reaction.scope.active || reaction.scope.paused)) {
					queued.context?.cancel();
					continue;
				}
				const profile = reaction.scope?.onProfile;
				if (profile) {
					profileStarted ??= profileTimestamp();
					profiledReactions.set(profile, (profiledReactions.get(profile) ?? 0) + 1);
				}
				try {
					if (queued.context) queued.context.run(() => runReactionWithPriority(queued.priority, reaction));
					else runReactionWithPriority(queued.priority, reaction);
				} catch (error) {
					if (!hasError) firstError = error;
					hasError = true;
				}
			}
		}
	} finally {
		if (through === "deferred") {
			foregroundFlushScheduled = false;
			deferredFlushScheduled = false;
		} else foregroundFlushScheduled = false;
		scheduleRemainingWork();
		if (!hasEligibleWork("deferred")) settleScheduler();
		if (profileStarted !== void 0) for (const [sink, reactions] of profiledReactions) publishExactProfile(sink, Object.freeze({
			subsystem: "reactive",
			phase: "flush",
			elapsedMs: profileTimestamp() - profileStarted,
			counts: Object.freeze({
				passes,
				reactions
			})
		}));
	}
	if (hasError) throw firstError;
}
function runReactionWithPriority(priority, reaction) {
	priorityStack.push(priority);
	try {
		reaction.run();
	} finally {
		priorityStack.pop();
	}
}
/** Publishes one stable settlement generation without admitting recursive reconciliation. */
function settleScheduler() {
	if (settling || hasEligibleWork("deferred")) return;
	settlementScheduled = false;
	if (!settlementCallbacks.size) return;
	const callbacks = [...settlementCallbacks];
	settlementCallbacks.clear();
	settling = true;
	try {
		for (const callback of callbacks) callback();
	} finally {
		settling = false;
		if (settlementCallbacks.size && !settlementScheduled) {
			settlementScheduled = true;
			queueMicrotask(settleScheduler);
		}
	}
}
/** Clears a runaway generation and reports it once to each owning scope. */
function settleOverflow(error) {
	const handlers = /* @__PURE__ */ new Set();
	for (const queued of queuedComputations.values()) if (queued.onError) handlers.add(queued.onError);
	for (const [reaction, queued] of queuedReactions) {
		reaction.scheduled = false;
		reaction.pendingPriority = void 0;
		queued.context?.cancel();
		if (reaction.scope?.onError) handlers.add(reaction.scope.onError);
	}
	queuedComputations.clear();
	queuedReactions.clear();
	if (!handlers.size) return false;
	let firstError;
	let failed = false;
	for (const handler of handlers) try {
		handler(error);
	} catch (handlerError) {
		if (!failed) firstError = handlerError;
		failed = true;
	}
	if (failed) throw firstError;
	return true;
}
function scheduleFlush(priority) {
	if (priority === "deferred") {
		if (foregroundFlushScheduled || deferredFlushScheduled) return;
		deferredFlushScheduled = true;
		scheduleDeferredFlush(() => {
			deferredFlushScheduled = false;
			consecutiveForegroundFlushes = 0;
			flushSync();
		});
		return;
	}
	if (foregroundFlushScheduled) return;
	foregroundFlushScheduled = true;
	queueMicrotask(() => {
		foregroundFlushScheduled = false;
		const drainDeferred = hasQueuedPriority("deferred") && ++consecutiveForegroundFlushes >= maxForegroundFlushesBeforeDeferred;
		if (drainDeferred) consecutiveForegroundFlushes = 0;
		flushSync(drainDeferred ? "deferred" : "normal");
	});
}
function scheduleRemainingWork() {
	const priority = highestQueuedPriority();
	if (priority) scheduleFlush(priority);
}
function highestQueuedPriority() {
	let selected;
	for (const [reaction, queued] of queuedReactions) {
		if (reaction.scope?.paused) continue;
		if (!selected || isHigherWorkPriority(queued.priority, selected)) selected = queued.priority;
	}
	for (const queued of queuedComputations.values()) {
		if (queued.scope?.paused) continue;
		if (!selected || isHigherWorkPriority(queued.priority, selected)) selected = queued.priority;
	}
	return selected;
}
function hasEligibleWork(through) {
	return hasEligibleComputations(through) || hasEligibleReactions(through);
}
function hasEligibleComputations(through) {
	for (const queued of queuedComputations.values()) {
		if (queued.scope?.paused) continue;
		if (isEligible(queued.priority, through)) return true;
	}
	return false;
}
function hasEligibleReactions(through) {
	for (const [reaction, queued] of queuedReactions) {
		if (reaction.scope?.paused) continue;
		if (isEligible(queued.priority, through)) return true;
	}
	return false;
}
function hasQueuedPriority(priority) {
	for (const [reaction, queued] of queuedReactions) if (!reaction.scope?.paused && queued.priority === priority) return true;
	for (const queued of queuedComputations.values()) if (!queued.scope?.paused && queued.priority === priority) return true;
	return false;
}
function takeEligibleComputations(through) {
	const selected = [];
	for (const [computation, queued] of queuedComputations) {
		if (queued.scope?.paused) continue;
		if (!isEligible(queued.priority, through)) continue;
		queuedComputations.delete(computation);
		selected.push([computation, queued]);
	}
	selected.sort((left, right) => priorityOrder[left[1].priority] - priorityOrder[right[1].priority]);
	return selected;
}
function takeEligibleReactions(through) {
	const selected = [];
	for (const [reaction, queued] of queuedReactions) {
		if (reaction.scope?.paused) continue;
		if (!isEligible(queued.priority, through)) continue;
		queuedReactions.delete(reaction);
		selected.push([reaction, queued]);
	}
	selected.sort((left, right) => priorityOrder[left[1].priority] - priorityOrder[right[1].priority] || (left[0].order ?? 1) - (right[0].order ?? 1));
	return selected;
}
function isEligible(priority, through) {
	return priorityOrder[priority] <= priorityOrder[through];
}
/** Reports whether candidate should run before current. */
function isHigherWorkPriority(candidate, current) {
	return priorityOrder[candidate] < priorityOrder[current];
}
function constrainedPriority(scope, requested) {
	let resolved = requested;
	for (let cursor = scope; cursor; cursor = cursor.parent) if (cursor.workPriority && isHigherWorkPriority(resolved, cursor.workPriority)) resolved = cursor.workPriority;
	return resolved;
}
function scheduleDeferredFlush(flush) {
	setTimeout(flush, 0);
}
//#endregion
//#region packages/reactive/dist/internal/scopes.js
var scopeStack = [];
var emptyScopes = /* @__PURE__ */ new Set();
var emptyReactions = /* @__PURE__ */ new Set();
var emptyCleanups = /* @__PURE__ */ new Set();
var emptyResumeWaiters = /* @__PURE__ */ new Set();
/**
* Stores reactive ownership with shared lifecycle methods and first-use collections.
*
* A scope participates in its parent's child collection immediately, but reactions, cleanups,
* descendants, and pause waiters do not allocate storage until their corresponding capability is
* used.
*/
var EffectScopeRecord = class {
	active = true;
	selfPaused = false;
	workPriority;
	parent;
	onError;
	onProfile;
	childrenValue;
	reactionsValue;
	cleanupsValue;
	resumeWaitersValue;
	constructor(parent, onError, onProfile) {
		this.parent = parent;
		this.onError = onError ?? parent?.onError;
		this.onProfile = onProfile ?? parent?.onProfile;
		parent?.children.add(this);
	}
	get paused() {
		return isEffectScopePaused(this);
	}
	get children() {
		return this.childrenValue ??= /* @__PURE__ */ new Set();
	}
	get reactions() {
		return this.reactionsValue ??= /* @__PURE__ */ new Set();
	}
	get cleanups() {
		return this.cleanupsValue ??= /* @__PURE__ */ new Set();
	}
	get resumeWaiters() {
		return this.resumeWaitersValue ??= /* @__PURE__ */ new Set();
	}
	pause() {
		this.selfPaused = true;
	}
	resume() {
		if (!this.selfPaused) return;
		this.selfPaused = false;
		notifyResumedSubtree(this);
		resumeScheduledWork();
	}
	stop() {
		stopEffectScope(this);
	}
	/** Returns descendants without materializing an empty child collection. */
	ownedChildren() {
		return this.childrenValue ?? emptyScopes;
	}
	/** Returns reactions without materializing an empty reaction collection. */
	ownedReactions() {
		return this.reactionsValue ?? emptyReactions;
	}
	/** Returns cleanups without materializing an empty cleanup collection. */
	ownedCleanups() {
		return this.cleanupsValue ?? emptyCleanups;
	}
	/** Returns pause waiters without materializing an empty waiter collection. */
	ownedResumeWaiters() {
		return this.resumeWaitersValue ?? emptyResumeWaiters;
	}
	/** Removes a child without allocating storage for a collection that cannot contain it. */
	removeChild(child) {
		this.childrenValue?.delete(child);
		if (this.childrenValue?.size === 0) this.childrenValue = void 0;
	}
	/** Removes a reaction and releases its now-empty backing collection. */
	removeReaction(reaction) {
		this.reactionsValue?.delete(reaction);
		if (this.reactionsValue?.size === 0) this.reactionsValue = void 0;
	}
	/** Removes a cleanup and releases its now-empty backing collection. */
	removeCleanup(cleanup) {
		this.cleanupsValue?.delete(cleanup);
		if (this.cleanupsValue?.size === 0) this.cleanupsValue = void 0;
	}
	/** Releases every settled pause waiter without retaining an empty set. */
	releaseResumeWaiters() {
		this.resumeWaitersValue = void 0;
	}
	/** Releases empty ownership collections after final disposal. */
	releaseCollections() {
		this.childrenValue = void 0;
		this.reactionsValue = void 0;
		this.cleanupsValue = void 0;
		this.resumeWaitersValue = void 0;
	}
};
/** Registers one reaction against a live scope using first-use ownership storage. */
function registerEffectScopeReaction(scope, reaction) {
	scope.reactions.add(reaction);
}
/** Releases one reaction and its empty scope storage after final disposal. */
function releaseEffectScopeReaction(scope, reaction) {
	scope.removeReaction(reaction);
}
/** Registers one cleanup against a live scope using first-use ownership storage. */
function registerEffectScopeCleanup(scope, cleanup) {
	scope.cleanups.add(cleanup);
}
/** Creates an effect scope that can stop all child scopes and reactions as one unit. */
function createEffectScope(parent = currentEffectScope(), onError, onProfile) {
	const parentScope = parent;
	if (parentScope && !parentScope.active) throw new Error("Cannot create an effect scope beneath an inactive parent scope");
	return new EffectScopeRecord(parentScope, onError, onProfile);
}
/** Returns the current ownership parent for framework integrations that preserve nested scope identity. */
function effectScopeParent(scope) {
	return scope.parent;
}
/** Transfers a live scope beneath another live scope without stopping owned work. */
function transferEffectScope(scope, parent) {
	const child = scope;
	const nextParent = parent;
	if (!child.active) throw new Error("Cannot transfer an inactive effect scope");
	if (nextParent && !nextParent.active) throw new Error("Cannot transfer an effect scope beneath an inactive parent scope");
	for (let cursor = nextParent; cursor; cursor = cursor.parent) if (cursor === child) throw new Error("Cannot create an effect scope cycle");
	if (child.parent === nextParent) return;
	child.parent?.removeChild(child);
	child.parent = nextParent;
	nextParent?.children.add(child);
	notifyResumedSubtree(child);
	resumeScheduledWork();
}
function stopEffectScope(root) {
	if (!root.active) return;
	const stopped = createScheduledScopePurge();
	const pending = [root];
	let firstError;
	let failed = false;
	while (pending.length) {
		const entry = pending.pop();
		const complete = entry === void 0;
		const scope = complete ? pending.pop() : entry;
		if (!complete) {
			if (!scope.active) continue;
			scope.active = false;
			for (const resume of scope.ownedResumeWaiters()) resume();
			scope.releaseResumeWaiters();
			const children = scope.ownedChildren();
			if (children.size) {
				pending.push(scope, void 0);
				const childStart = pending.length;
				for (const child of children) pending.push(child);
				for (let left = childStart, right = pending.length - 1; left < right; left++, right--) {
					const child = pending[left];
					pending[left] = pending[right];
					pending[right] = child;
				}
				continue;
			}
		}
		for (const reaction of [...scope.ownedReactions()]) try {
			reaction.stop();
		} catch (error) {
			if (!failed) firstError = error;
			failed = true;
		}
		for (const cleanup of [...scope.ownedCleanups()]) try {
			cleanup();
		} catch (error) {
			if (!failed) firstError = error;
			failed = true;
		}
		if (stopped) stopped.add(scope);
		else discardScheduledScopeWork(scope);
		scope.parent?.removeChild(scope);
		scope.parent = void 0;
		scope.releaseCollections();
	}
	if (stopped) discardScheduledScopeWork(void 0, stopped);
	resumeScheduledWork();
	if (failed) throw firstError;
}
/** Runs a function with the supplied scope as the current reactive ownership scope. */
function withEffectScope(scope, fn) {
	if (!scope) return fn();
	if (!scope.active) throw new Error("Cannot create reactive work inside an inactive effect scope");
	scopeStack.push(scope);
	try {
		return fn();
	} finally {
		scopeStack.pop();
	}
}
/** Returns the currently active effect scope, if code is executing inside one. */
function currentEffectScope() {
	return scopeStack[scopeStack.length - 1];
}
/** Resolves a requested priority through every effective ancestor constraint. */
function effectScopeWorkPriority(scope, requested) {
	let resolved = requested;
	for (let cursor = scope; cursor; cursor = cursor.parent) if (cursor.workPriority && isHigherWorkPriority(resolved, cursor.workPriority)) resolved = cursor.workPriority;
	return resolved;
}
function isEffectScopePaused(scope) {
	for (let cursor = scope; cursor; cursor = cursor.parent) if (cursor.selfPaused) return true;
	return false;
}
function notifyResumedSubtree(root) {
	const pending = [root];
	while (pending.length) {
		const scope = pending.pop();
		if (scope.active && !scope.paused && scope.ownedResumeWaiters().size) {
			for (const resume of scope.ownedResumeWaiters()) resume();
			scope.releaseResumeWaiters();
		}
		for (const child of scope.ownedChildren()) pending.push(child);
	}
}
//#endregion
//#region packages/reactive/dist/internal/symbols.js
/** Provides the canonical proxy marker value. */
var proxyMarker = Symbol.for("exact.reactive.proxy");
/** Provides the canonical reactive value marker value. */
var reactiveValueMarker = Symbol.for("exact.reactive.value");
/** Provides the canonical raw target value. */
var rawTarget = Symbol.for("exact.reactive.raw");
/** Provides the canonical reactive value ref value. */
var reactiveValueRef = Symbol.for("exact.reactive.valueRef");
/** Provides the canonical iterate key value. */
var iterateKey = Symbol.for("exact.reactive.iterate");
//#endregion
//#region packages/reactive/dist/internal/values.js
/** Returns whether a value is an eXact reactive-value wrapper. */
function isReactiveValue(value) {
	return !!value && typeof value === "object" && reactiveValueMarker in value;
}
/** Returns whether a value is an eXact reactive proxy. */
function isReactive(value) {
	return !!value && typeof value === "object" && Boolean(value[proxyMarker]);
}
/**
* Returns the raw value behind a reactive proxy or reactive-value wrapper.
*
* Reactive-value reads remain tracked; proxy unwrapping only removes the proxy
* layer and does not recursively clone descendants.
*/
function unwrap(value) {
	if (value === null || typeof value !== "object") return value;
	if (isReactiveValue(value)) return value.get();
	if (isReactive(value)) return value[rawTarget];
	return value;
}
/** Rejects mutation through a readonly reactive-value reference. */
function rejectReadonlyReactiveValueWrite() {
	throw new TypeError("Cannot write to readonly reactive value");
}
//#endregion
//#region packages/reactive/dist/proxy/state.js
/** Performs the conflicting list key error domain operation. */
function conflictingListKeyError(left, right) {
	const sites = [left, right].sort();
	return /* @__PURE__ */ new Error(`Conflicting this.map() key extractors for the same collection (${sites[0]} and ${sites[1]}). A reactive collection must have one stable key contract.`);
}
/** Provides the canonical default reactive options value. */
var defaultReactiveOptions = Object.freeze({});
/** Provides the canonical readonly reactive options key value. */
var readonlyReactiveOptionsKey = Object.freeze({ readonly: true });
/** Provides the canonical root proxy cache value. */
var rootProxyCache = /* @__PURE__ */ new WeakMap();
/** Provides the canonical sourced proxy cache value. */
var sourcedProxyCache = /* @__PURE__ */ new WeakMap();
/** Provides the canonical parent source cache value. */
var parentSourceCache = /* @__PURE__ */ new WeakMap();
/** Provides the canonical proxy refs value. */
var proxyRefs = /* @__PURE__ */ new WeakMap();
/** Provides the canonical proxy sources value. */
var proxySources = /* @__PURE__ */ new WeakMap();
/** Provides the canonical reactive raw objects value. */
var reactiveRawObjects = /* @__PURE__ */ new WeakSet();
/** Provides the canonical list key extractors value. */
var listKeyExtractors = /* @__PURE__ */ new WeakMap();
/** Provides the canonical mutating array methods value. */
var mutatingArrayMethods = /* @__PURE__ */ new Set([
	"copyWithin",
	"fill",
	"pop",
	"push",
	"reverse",
	"shift",
	"sort",
	"splice",
	"unshift"
]);
//#endregion
//#region packages/reactive/dist/internal/objects.js
/** Returns whether a value is a plain object that can be structurally traversed. */
function isPlainObject(value) {
	if (!value || typeof value !== "object") return false;
	const prototype = Object.getPrototypeOf(value);
	return prototype === Object.prototype || prototype === null;
}
/** Returns whether an array key can affect iteration or length-sensitive dependencies. */
function isArrayStructureKey(target, key) {
	return Array.isArray(target) && (key === "length" || isArrayIndex$1(key));
}
function isArrayIndex$1(key) {
	if (typeof key === "number") return Number.isInteger(key) && key >= 0;
	if (typeof key !== "string" || key === "") return false;
	const index = Number(key);
	return Number.isInteger(index) && index >= 0 && String(index) === key;
}
//#endregion
//#region packages/reactive/dist/internal/equality.js
var exactOpaqueOperationIdentity$2 = Symbol.for("@exactjs/opaque-target-operation");
/** Returns whether two values differ after reactive wrappers and plain structures are compared. */
function hasChanged$1(previous, next, unwrap) {
	return !structurallyEqual(previous, next, unwrap);
}
/** Compares primitives, arrays, and plain objects after unwrapping reactive values. */
function structurallyEqual(left, right, unwrap) {
	const leftToRight = /* @__PURE__ */ new WeakMap();
	const rightToLeft = /* @__PURE__ */ new WeakMap();
	const pending = [[left, right]];
	let visited = 0;
	while (pending.length) {
		if (++visited > 1e6) return false;
		const [rawLeft, rawRight] = pending.pop();
		if (Object.is(rawLeft, rawRight)) continue;
		const currentLeft = unwrap(rawLeft);
		const currentRight = unwrap(rawRight);
		if (Object.is(currentLeft, currentRight)) continue;
		if (!currentLeft || !currentRight || typeof currentLeft !== "object" || typeof currentRight !== "object") return false;
		if (exactOpaqueOperationIdentity$2 in currentLeft || exactOpaqueOperationIdentity$2 in currentRight) return false;
		const priorRight = leftToRight.get(currentLeft);
		const priorLeft = rightToLeft.get(currentRight);
		if (priorRight || priorLeft) {
			if (priorRight !== currentRight || priorLeft !== currentLeft) return false;
			continue;
		}
		leftToRight.set(currentLeft, currentRight);
		rightToLeft.set(currentRight, currentLeft);
		const arrays = Array.isArray(currentLeft) && Array.isArray(currentRight);
		const objects = isPlainObject(currentLeft) && isPlainObject(currentRight);
		if (!arrays && !objects) return false;
		if (Object.getPrototypeOf(currentLeft) !== Object.getPrototypeOf(currentRight)) return false;
		if (arrays && currentLeft.length !== currentRight.length) return false;
		const leftKeys = Reflect.ownKeys(currentLeft).filter((key) => !arrays || key !== "length");
		const rightKeys = Reflect.ownKeys(currentRight).filter((key) => !arrays || key !== "length");
		if (leftKeys.length !== rightKeys.length) return false;
		for (const key of leftKeys) {
			if (!Object.prototype.hasOwnProperty.call(currentRight, key)) return false;
			const leftDescriptor = Reflect.getOwnPropertyDescriptor(currentLeft, key);
			const rightDescriptor = Reflect.getOwnPropertyDescriptor(currentRight, key);
			if (!leftDescriptor || !rightDescriptor) return false;
			if (!("value" in leftDescriptor) || !("value" in rightDescriptor)) {
				if (leftDescriptor.get !== rightDescriptor.get || leftDescriptor.set !== rightDescriptor.set || leftDescriptor.enumerable !== rightDescriptor.enumerable || leftDescriptor.configurable !== rightDescriptor.configurable) return false;
				continue;
			}
			if (leftDescriptor.enumerable !== rightDescriptor.enumerable || leftDescriptor.configurable !== rightDescriptor.configurable || leftDescriptor.writable !== rightDescriptor.writable) return false;
			pending.push([leftDescriptor.value, rightDescriptor.value]);
		}
	}
	return true;
}
//#endregion
//#region packages/reactive/dist/change-detection.js
var exactOpaqueOperationIdentity$1 = Symbol.for("@exactjs/opaque-target-operation");
/** Compares values after unwrapping reactive containers. */
function hasChanged(previous, next) {
	return hasChanged$1(previous, next, unwrap);
}
/** Identifies objects whose nested structure can participate in reactive reconciliation. */
function isReactiveContainer(value) {
	if (value && typeof value === "object" && Object.prototype.hasOwnProperty.call(value, exactOpaqueOperationIdentity$1)) return false;
	return Array.isArray(value) || value instanceof Map || value instanceof Set || isPlainObject(value);
}
//#endregion
//#region packages/reactive/dist/computation.js
var computedTargets = /* @__PURE__ */ new WeakMap();
var computedValues = /* @__PURE__ */ new WeakMap();
var maximumSettlementSteps = 1e5;
var cycleMessage = "eXact reactive computation cycle detected";
var nextSettlementGeneration = 0;
var activeSettlementGeneration = 0;
/** Creates a lazy, cached derived value with depth-independent synchronous freshness. */
function computed(compute) {
	const node = new ComputedNode(compute, currentEffectScope());
	const value = {
		[reactiveValueMarker]: true,
		[reactiveValueRef]: node,
		get: () => node.get(),
		toJSON: readComputedValue,
		toString: computedValueToString,
		valueOf: readComputedValue,
		[Symbol.toPrimitive]: readComputedValue
	};
	computedValues.set(value, node);
	return value;
}
function readComputedValue() {
	return this.get();
}
function computedValueToString() {
	return String(this.get());
}
var ComputedNode = class {
	compute;
	scope;
	active = true;
	scheduled = false;
	pendingPriority;
	deps = [];
	target = {};
	key = "value";
	state = "dirty";
	initialized = false;
	current;
	observed = false;
	failed = false;
	invalidatedWhileComputing = false;
	validatedGeneration = 0;
	restorationVersion = readReactiveRestorationVersion();
	dependencies = [];
	computedSources;
	computedSinks;
	releaseObservationHooks;
	settleScheduled = () => this.settle();
	constructor(compute, scope) {
		this.compute = compute;
		this.scope = scope;
		computedTargets.set(this.target, this);
		this.releaseObservationHooks = registerDependencyObservationHooks(this.target, this.key, {
			onObserved: () => this.becomeObserved(),
			onUnobserved: () => this.becomeUnobserved()
		});
		if (scope) registerEffectScopeReaction(scope, this);
	}
	set(_value) {
		rejectReadonlyReactiveValueWrite();
	}
	get() {
		if (this.state === "computing") throw new Error(cycleMessage);
		if (this.active && !this.scope?.paused && (activeSettlementGeneration === 0 || this.validatedGeneration !== activeSettlementGeneration)) this.settle();
		track(this.target, this.key);
		return this.current;
	}
	run() {
		this.scheduled = false;
		this.pendingPriority = void 0;
		if (!this.active || this.scope && !this.scope.active) {
			this.stop();
			return;
		}
		this.settle();
	}
	schedule() {
		if (!this.active || this.scope && !this.scope.active) {
			this.stop();
			return;
		}
		if (this.state !== "computing" && this.initialized && this.dependencies.every((dependency) => readMutationVersion(dependency.target, dependency.key) === dependency.version)) return;
		if (this.state === "computing") this.invalidatedWhileComputing = true;
		else this.state = "dirty";
		this.markSinksChecked();
		if (this.isRetained()) this.queue();
	}
	stop() {
		if (!this.active) return;
		this.active = false;
		this.state = "stopped";
		this.scheduled = false;
		this.pendingPriority = void 0;
		removeQueuedComputation(this.settleScheduled);
		cleanupReaction(this);
		this.detachComputedSources();
		this.releaseObservationHooks();
		if (this.scope) releaseEffectScopeReaction(this.scope, this);
	}
	inspect() {
		return Object.freeze({
			state: this.failed ? "failed" : this.scope?.paused ? "paused" : this.state,
			priority: this.pendingPriority ?? effectScopeWorkPriority(this.scope, currentWorkPriority()),
			observed: this.isRetained(),
			initialized: this.initialized,
			sources: this.dependencies.length,
			sinks: this.computedSinks?.size ?? 0
		});
	}
	settle() {
		if (!this.active || this.scope?.paused) return;
		const ownsGeneration = activeSettlementGeneration === 0;
		if (ownsGeneration) activeSettlementGeneration = ++nextSettlementGeneration;
		try {
			settleGraph(this);
		} finally {
			if (ownsGeneration) activeSettlementGeneration = 0;
		}
	}
	needsValidation() {
		return this.state !== "clean" || !this.isRetained() || hasActiveReactiveTransaction() || this.restorationVersion !== readReactiveRestorationVersion();
	}
	validateAndEvaluate() {
		if (!this.active || this.scope?.paused) return;
		if (this.state === "computing") throw new Error(cycleMessage);
		if (this.initialized && this.state !== "dirty") {
			if (!this.dependencies.some((dependency) => readMutationVersion(dependency.target, dependency.key) !== dependency.version)) {
				this.state = "clean";
				removeQueuedComputation(this.settleScheduled);
				this.scheduled = false;
				this.pendingPriority = void 0;
				this.validatedGeneration = activeSettlementGeneration;
				this.restorationVersion = readReactiveRestorationVersion();
				return;
			}
			this.state = "dirty";
		}
		if (this.state === "dirty" || !this.initialized) this.evaluate();
		this.validatedGeneration = activeSettlementGeneration;
		this.restorationVersion = readReactiveRestorationVersion();
	}
	evaluate() {
		const previousDependencies = this.dependencies;
		const previousValue = this.current;
		const hadValue = this.initialized;
		this.state = "computing";
		this.failed = false;
		this.invalidatedWhileComputing = false;
		removeQueuedComputation(this.settleScheduled);
		cleanupReaction(this);
		this.detachComputedSources();
		let next;
		try {
			withEffectScope(this.scope, () => runTracked(this, () => {
				const computedValue = this.compute();
				trackReturnedReference(computedValue);
				next = unwrap(computedValue);
			}));
		} catch (error) {
			this.recoverFromFailure(previousDependencies, error);
			return;
		}
		this.dependencies = snapshotDependencies(this);
		this.refreshComputedSources();
		if (!this.isRetained()) {
			cleanupReaction(this);
			this.detachComputedSources();
		}
		const changed = !hadValue || hasChanged(previousValue, next);
		this.current = hadValue && !changed ? previousValue : next;
		this.initialized = true;
		this.state = this.invalidatedWhileComputing ? "dirty" : "clean";
		this.scheduled = false;
		this.pendingPriority = void 0;
		if (hadValue && changed) trigger(this.target, this.key);
		if (this.invalidatedWhileComputing) this.queue(true);
	}
	recoverFromFailure(previousDependencies, error) {
		const attemptedDependencies = snapshotDependencies(this);
		cleanupReaction(this);
		this.dependencies = mergeDependencies(previousDependencies, attemptedDependencies);
		if (this.isRetained()) this.attachDependencies();
		this.failed = true;
		this.state = "clean";
		this.validatedGeneration = activeSettlementGeneration;
		this.restorationVersion = readReactiveRestorationVersion();
		removeQueuedComputation(this.settleScheduled);
		this.scheduled = false;
		this.pendingPriority = void 0;
		const onError = this.scope?.onError;
		if (!onError) throw error;
		onError(error);
	}
	queue(force = false) {
		if (!force && !this.isRetained()) return;
		const priority = effectScopeWorkPriority(this.scope, currentWorkPriority());
		if (this.pendingPriority === void 0 || priority === "interactive" || this.pendingPriority === "deferred" && priority === "normal") this.pendingPriority = priority;
		this.scheduled = true;
		queueComputation(this.settleScheduled, void 0, priority, this.scope);
	}
	markSinksChecked() {
		const pending = this.computedSinks ? [...this.computedSinks] : [];
		const visited = /* @__PURE__ */ new Set();
		while (pending.length) {
			const sink = pending.pop();
			if (!visited.add(sink) || !sink.active) continue;
			if (sink.state === "clean") sink.state = "checked";
			if (sink.state === "computing") sink.invalidatedWhileComputing = true;
			if (sink.isRetained()) sink.queue();
			if (sink.computedSinks) for (const descendant of sink.computedSinks) pending.push(descendant);
		}
	}
	becomeObserved() {
		if (this.observed || !this.active) return;
		this.observed = true;
		this.attachDependencies();
		if (this.state !== "clean") this.queue();
	}
	becomeUnobserved() {
		if (!this.observed) return;
		this.observed = false;
		if (this.scope) return;
		cleanupReaction(this);
		this.detachComputedSources();
		removeQueuedComputation(this.settleScheduled);
		this.scheduled = false;
		this.pendingPriority = void 0;
	}
	attachDependencies() {
		for (const dependency of this.dependencies) linkReaction(this, dependency.target, dependency.key);
		this.refreshComputedSources();
	}
	refreshComputedSources() {
		this.detachComputedSources();
		if (!this.isRetained()) return;
		for (const dependency of this.dependencies) {
			if (!dependency.computed) continue;
			(this.computedSources ??= /* @__PURE__ */ new Set()).add(dependency.computed);
			(dependency.computed.computedSinks ??= /* @__PURE__ */ new Set()).add(this);
		}
	}
	detachComputedSources() {
		if (!this.computedSources) return;
		for (const source of this.computedSources) {
			source.computedSinks?.delete(this);
			if (source.computedSinks?.size === 0) source.computedSinks = void 0;
		}
		this.computedSources = void 0;
	}
	computedDependencies() {
		return this.dependencies;
	}
	isRetained() {
		return this.observed || Boolean(this.scope);
	}
};
function settleGraph(root) {
	const stack = [{
		node: root,
		leave: false
	}];
	const visiting = /* @__PURE__ */ new Set();
	let steps = 0;
	while (stack.length) {
		if (++steps > maximumSettlementSteps) throw new Error("eXact reactive computation graph exceeded its settlement limit");
		const frame = stack.pop();
		const node = frame.node;
		if (frame.leave) {
			visiting.delete(node);
			node.validateAndEvaluate();
			continue;
		}
		if (!node.needsValidation()) continue;
		if (visiting.has(node)) throw new Error(cycleMessage);
		visiting.add(node);
		stack.push({
			node,
			leave: true
		});
		const dependencies = node.computedDependencies();
		for (let index = dependencies.length - 1; index >= 0; index--) {
			const source = dependencies[index].computed;
			if (source) stack.push({
				node: source,
				leave: false
			});
		}
	}
}
function snapshotDependencies(reaction) {
	return reactionDependencies(reaction).map(({ target, key }) => ({
		target,
		key,
		version: readMutationVersion(target, key),
		computed: computedTargets.get(target)
	}));
}
function mergeDependencies(previous, attempted) {
	const merged = [...attempted];
	for (const dependency of previous) {
		if (merged.some((candidate) => candidate.target === dependency.target && candidate.key === dependency.key)) continue;
		merged.push({
			...dependency,
			version: readMutationVersion(dependency.target, dependency.key)
		});
	}
	return merged;
}
function trackReturnedReference(value) {
	if (isReactiveValue(value)) {
		value.get();
		return;
	}
	if (value && typeof value === "object") proxyRefs.get(value)?.get();
}
//#endregion
//#region packages/reactive/dist/observation.js
var inactiveWatch = () => void 0;
var collectionRefs = /* @__PURE__ */ new WeakMap();
/** Installs a framework-owned structural watcher ahead of ordinary bindings at equal priority. */
function watchStructural(fn, options = {}) {
	return watchRetained(fn, void 0, {
		...options,
		structural: true
	}) ?? inactiveWatch;
}
function watchRetained(fn, scheduler, options = {}) {
	const scope = resolveObservationScope(options);
	const reaction = new RetainedReaction(fn, scheduler, options, scope);
	if (scope) registerEffectScopeReaction(scope, reaction);
	try {
		reaction.run();
	} catch (error) {
		reaction.stop();
		throw error;
	}
	return reaction.active ? options.owned ? reaction : () => reaction.stop() : void 0;
}
/** Shared executor for retained watchers; instances store data rather than method closures. */
var RetainedReaction = class {
	fn;
	scheduler;
	scope;
	fixed;
	active = true;
	scheduled = false;
	pendingPriority;
	deps = [];
	order;
	constructor(fn, scheduler, options, scope, fixed = false) {
		this.fn = fn;
		this.scheduler = scheduler;
		this.scope = scope;
		this.fixed = fixed;
		this.order = options.structural ? 0 : 1;
		this.onSchedule = options.onSchedule;
		this.onError = options.onError;
		this.onRelease = options.onRelease;
	}
	onSchedule;
	onError;
	onRelease;
	run() {
		if (!this.active) return;
		if (this.scope && !this.scope.active) {
			this.stop();
			return;
		}
		this.scheduled = false;
		this.pendingPriority = void 0;
		try {
			if (this.fixed) withEffectScope(this.scope, this.fn);
			else {
				withEffectScope(this.scope, () => runTracked(this, this.fn));
				if (this.deps.length === 0) this.stop();
			}
		} catch (error) {
			this.handleError(error);
		}
	}
	schedule() {
		if (!this.active) return;
		if (this.scope && !this.scope.active) {
			this.stop();
			return;
		}
		const priority = effectScopeWorkPriority(this.scope, currentWorkPriority());
		if (this.scheduled) {
			if (this.pendingPriority !== void 0 && isHigherWorkPriority(priority, this.pendingPriority)) {
				this.pendingPriority = priority;
				if (this.scheduler) this.scheduler();
				else queueReaction(this, priority);
			}
			return;
		}
		this.scheduled = true;
		this.pendingPriority = priority;
		try {
			if (this.onSchedule) withEffectScope(this.scope, this.onSchedule);
			if (this.scheduler) this.scheduler();
			else queueReaction(this);
		} catch (error) {
			this.scheduled = false;
			this.pendingPriority = void 0;
			this.handleError(error);
		}
	}
	stop() {
		if (!this.active) return;
		this.active = false;
		this.scheduled = false;
		this.pendingPriority = void 0;
		cleanupReaction(this);
		if (this.scope) releaseEffectScopeReaction(this.scope, this);
		this.onRelease?.();
	}
	handleError(error) {
		const onError = this.onError ?? this.scope?.onError;
		if (!onError) throw error;
		onError(error);
	}
};
/** Subscribes directly to a reactive reference without running a dependency collection pass. */
function subscribe(source, callback, options = {}) {
	const scope = resolveObservationScope(options);
	const reaction = new RetainedReaction(callback, void 0, options, scope, true);
	linkReactionToDependency(reaction, getDep(source.target, source.key));
	if (scope) registerEffectScopeReaction(scope, reaction);
	return () => reaction.stop();
}
/** Subscribes one coalesced reaction to compiler-selected keys on a shared target. */
function subscribeKeys(target, keys, callback, options = {}) {
	if (keys.length === 0) return inactiveWatch;
	const scope = resolveObservationScope(options);
	const reaction = new RetainedReaction(callback, void 0, options, scope, true);
	for (const key of keys) linkReactionToDependency(reaction, getDep(target, key));
	if (scope) registerEffectScopeReaction(scope, reaction);
	return () => reaction.stop();
}
/** Inherits ownership only when the caller did not explicitly capture an unowned scope. */
function resolveObservationScope(options) {
	return Object.prototype.hasOwnProperty.call(options, "scope") ? options.scope : currentEffectScope();
}
function ref(value) {
	if (isReactiveValue(value)) {
		value.get();
		return value[reactiveValueRef];
	}
	if (value && typeof value === "object") return proxyRefs.get(value);
}
/** Returns the structural dependency source for a reactive iterable collection. */
function collectionRef(value) {
	const existing = ref(value);
	let source = collectionRefs.get(value);
	if (source) return source;
	if (!existing && !isReactive(value)) return void 0;
	const target = unwrap(value);
	source = {
		target: existing?.target ?? target,
		key: existing?.key ?? iterateKey,
		get() {
			const current = existing ? existing.get() : value;
			trackCollectionStructure(current);
			return current;
		},
		set(next) {
			if (existing) {
				existing.set(next);
				return;
			}
			throw new TypeError("Cannot replace a collection through its structural reference");
		}
	};
	collectionRefs.set(value, source);
	return source;
}
/** Records the structural dependency for a framework-owned collection consumer. */
function trackCollectionStructure(value) {
	track(unwrap(value), iterateKey);
}
//#endregion
//#region packages/reactive/dist/internal/hash.js
var encoder$1 = new TextEncoder();
/** Hashes strict JSON data with deterministic object ordering. This is not a security primitive. */
function hashCanonicalJson(value, domain) {
	const canonical = canonicalJson(value);
	return hashText(`${domain.length}:${domain}${canonical.length}:${canonical}`);
}
/** Hashes an ordered string sequence using unambiguous length framing. */
function hashStringSequence(values, domain) {
	let framed = `${domain.length}:${domain}${values.length}:`;
	for (const value of values) framed += `${value.length}:${value}`;
	return hashText(framed);
}
/** Performs the canonical json domain operation. */
function canonicalJson(value) {
	return encodeValue$1(value, /* @__PURE__ */ new WeakSet(), 0);
}
function encodeValue$1(value, active, depth) {
	if (depth > 100) throw new TypeError("Cannot hash JSON deeper than 100 levels");
	if (value === null) return "null";
	if (typeof value === "boolean") return value ? "true" : "false";
	if (typeof value === "string") return JSON.stringify(value);
	if (typeof value === "number") {
		if (!Number.isFinite(value)) throw new TypeError("Cannot hash non-finite JSON numbers");
		return Object.is(value, -0) ? "0" : JSON.stringify(value);
	}
	if (!value || typeof value !== "object") throw new TypeError(`Cannot hash non-JSON ${typeof value}`);
	if (active.has(value)) throw new TypeError("Cannot hash cyclic JSON");
	active.add(value);
	try {
		if (Array.isArray(value)) {
			if (Object.getPrototypeOf(value) !== Array.prototype) throw new TypeError("Cannot hash non-standard arrays");
			const keys = Object.keys(value);
			if (keys.length !== value.length || keys.some((key, index) => key !== String(index))) throw new TypeError("Cannot hash sparse arrays or arrays with enumerable properties");
			if (Object.getOwnPropertySymbols(value).some((symbol) => Object.prototype.propertyIsEnumerable.call(value, symbol))) throw new TypeError("Cannot hash arrays with enumerable symbols");
			const items = [];
			for (let index = 0; index < value.length; index++) {
				const descriptor = Object.getOwnPropertyDescriptor(value, String(index));
				if (!descriptor || !("value" in descriptor)) throw new TypeError("Cannot hash array accessors");
				items.push(encodeValue$1(descriptor.value, active, depth + 1));
			}
			return `[${items.join(",")}]`;
		}
		const prototype = Object.getPrototypeOf(value);
		if (prototype !== Object.prototype && prototype !== null) throw new TypeError("Cannot hash non-plain JSON objects");
		if (Object.getOwnPropertySymbols(value).some((symbol) => Object.prototype.propertyIsEnumerable.call(value, symbol))) throw new TypeError("Cannot hash objects with enumerable symbols");
		const descriptors = Object.getOwnPropertyDescriptors(value);
		const keys = Object.keys(descriptors).filter((key) => descriptors[key].enumerable).sort();
		const properties = [];
		for (const key of keys) {
			const descriptor = descriptors[key];
			if (!("value" in descriptor)) throw new TypeError("Cannot hash object accessors");
			properties.push(`${JSON.stringify(key)}:${encodeValue$1(descriptor.value, active, depth + 1)}`);
		}
		return `{${properties.join(",")}}`;
	} finally {
		active.delete(value);
	}
}
function hashText(value) {
	const bytes = encoder$1.encode(value);
	let a = 2166136261;
	let b = 2654435769;
	let c = 2246822507;
	let d = 3266489909;
	for (const byte of bytes) {
		a = Math.imul(a ^ byte, 16777619);
		b = Math.imul(b ^ byte, 668265261);
		c = Math.imul(c ^ byte, 374761393);
		d = Math.imul(d ^ byte, 2246822519);
	}
	a = avalanche(a ^ bytes.length);
	b = avalanche(b ^ a);
	c = avalanche(c ^ b);
	d = avalanche(d ^ c);
	return [
		a,
		b,
		c,
		d
	].map((part) => (part >>> 0).toString(16).padStart(8, "0")).join("");
}
function avalanche(value) {
	value ^= value >>> 16;
	value = Math.imul(value, 2146121005);
	value ^= value >>> 15;
	value = Math.imul(value, 2221713035);
	return value ^ value >>> 16;
}
//#endregion
//#region packages/reactive/dist/internal/keyed/protocol.js
var hashPattern = /^[0-9a-f]{32}$/;
/** Encodes transport-safe reactive data with caller-owned keyed metadata lookup. */
function encodeKeyedProtocolValue(value, extractorFor, metadataFor) {
	return encodeValue(value, extractorFor, metadataFor, /* @__PURE__ */ new WeakSet(), 0);
}
/** Decodes reactive protocol data and delegates keyed metadata installation. */
function decodeKeyedProtocolValue(value, install) {
	return decodeValue(value, install, /* @__PURE__ */ new WeakSet(), 0);
}
function encodeValue(value, extractorFor, metadataFor, active, depth) {
	if (!value || typeof value !== "object") return value;
	if (depth > 100 || active.has(value)) throw new TypeError("Cannot encode cyclic or excessively deep reactive protocol data");
	active.add(value);
	try {
		if (value instanceof Map) {
			const entries = [];
			for (const [key, item] of value) {
				assertTransportableMapKey(key);
				entries.push([key, encodeValue(item, extractorFor, metadataFor, active, depth + 1)]);
			}
			return {
				$exact: "map",
				version: 1,
				entries
			};
		}
		if (value instanceof Set) return {
			$exact: "set",
			version: 1,
			values: [...value].map((item) => encodeValue(item, extractorFor, metadataFor, active, depth + 1))
		};
		if (Array.isArray(value)) {
			const metadata = metadataFor(value, extractorFor(value));
			const items = value.map((item) => encodeValue(item, extractorFor, metadataFor, active, depth + 1));
			if (!metadata) return items;
			return createKeyedCollectionEnvelope(metadata, items);
		}
		const output = {};
		for (const key of Object.keys(value)) defineEncodedProperty(output, key, encodeValue(value[key], extractorFor, metadataFor, active, depth + 1));
		return output;
	} finally {
		active.delete(value);
	}
}
/** Wraps already encoded items with one collection's stable reactive protocol metadata. */
function createKeyedCollectionEnvelope(metadata, items) {
	return {
		$exact: "keyed-collection",
		version: 1,
		keys: [...metadata.keys],
		keyHash: metadata.keyHash,
		itemHashes: [...metadata.itemHashes],
		itemsHash: metadata.itemsHash,
		items
	};
}
function defineEncodedProperty(output, key, value) {
	Object.defineProperty(output, key, {
		configurable: true,
		enumerable: true,
		writable: true,
		value
	});
}
function decodeValue(value, install, active, depth) {
	if (!value || typeof value !== "object") return value;
	if (depth > 100 || active.has(value)) throw new TypeError("Cannot decode cyclic or excessively deep reactive protocol data");
	active.add(value);
	try {
		if (Array.isArray(value)) return value.map((item) => decodeValue(item, install, active, depth + 1));
		if (value.$exact === "map") {
			const envelope = validateMapEnvelope(value);
			return new Map(envelope.entries.map(([key, item]) => [key, decodeValue(item, install, active, depth + 1)]));
		}
		if (value.$exact === "set") {
			const envelope = validateSetEnvelope(value);
			return new Set(envelope.values.map((item) => decodeValue(item, install, active, depth + 1)));
		}
		if (value.$exact === "keyed-collection") {
			const envelope = validateEnvelope(value);
			const items = envelope.items.map((item) => decodeValue(item, install, active, depth + 1));
			install(items, envelope);
			return items;
		}
		const output = {};
		for (const key of Object.keys(value)) Object.defineProperty(output, key, {
			configurable: true,
			enumerable: true,
			writable: true,
			value: decodeValue(value[key], install, active, depth + 1)
		});
		return output;
	} finally {
		active.delete(value);
	}
}
function validateMapEnvelope(value) {
	if (!hasOnlyEnvelopeKeys(value, [
		"$exact",
		"version",
		"entries"
	]) || value.version !== 1 || !Array.isArray(value.entries) || !value.entries.every((entry) => Array.isArray(entry) && entry.length === 2 && isTransportableReactiveMapKey(entry[0]))) throw new TypeError("Malformed eXact Map envelope");
	return value;
}
function validateSetEnvelope(value) {
	if (!hasOnlyEnvelopeKeys(value, [
		"$exact",
		"version",
		"values"
	]) || value.version !== 1 || !Array.isArray(value.values)) throw new TypeError("Malformed eXact Set envelope");
	return value;
}
function validateEnvelope(value) {
	const allowed = /* @__PURE__ */ new Set([
		"$exact",
		"version",
		"keys",
		"keyHash",
		"itemHashes",
		"itemsHash",
		"items"
	]);
	if (Object.keys(value).some((key) => !allowed.has(key)) || value.version !== 1 || !Array.isArray(value.keys) || !value.keys.every((key) => typeof key === "string") || new Set(value.keys).size !== value.keys.length || !Array.isArray(value.itemHashes) || !value.itemHashes.every((hash) => typeof hash === "string" && hashPattern.test(hash)) || !Array.isArray(value.items) || value.keys.length !== value.itemHashes.length || value.keys.length !== value.items.length || typeof value.keyHash !== "string" || !hashPattern.test(value.keyHash) || typeof value.itemsHash !== "string" || !hashPattern.test(value.itemsHash)) throw new TypeError("Malformed eXact keyed-collection envelope");
	return value;
}
function assertTransportableMapKey(value) {
	if (!isTransportableReactiveMapKey(value)) throw new TypeError("eXact Map protocol keys must be null, boolean, finite number, or string values");
}
/** Reports whether a value can be transported as a reactive Map protocol key. */
function isTransportableReactiveMapKey(value) {
	return value === null || typeof value === "boolean" || typeof value === "string" || typeof value === "number" && Number.isFinite(value);
}
function hasOnlyEnvelopeKeys(value, allowed) {
	const keys = new Set(allowed);
	return Object.keys(value).every((key) => keys.has(key));
}
//#endregion
//#region packages/reactive/dist/internal/keyed-collections.js
var metadataByCollection = /* @__PURE__ */ new WeakMap();
var ownersByObject = /* @__PURE__ */ new WeakMap();
/** Performs the seed keyed collection metadata domain operation. */
function seedKeyedCollectionMetadata(collection, key) {
	return rebuildMetadata(collection, key);
}
/** Releases keyed metadata and every reverse mutation-owner link for one retired collection. */
function releaseKeyedCollectionMetadata(collection) {
	clearMetadata(collection);
}
/** Performs the keyed collection metadata domain operation. */
function keyedCollectionMetadata(collection, key) {
	const metadata = metadataByCollection.get(collection);
	if (!metadata) return key ? rebuildMetadata(collection, key) : void 0;
	if (!metadata.structureDirty && metadata.dirtyKeys.size === 0) return metadata;
	if (!key) return void 0;
	if (metadata.structureDirty || keysChanged(collection, metadata.keys, key)) return rebuildMetadata(collection, key);
	try {
		const dirtyKeys = new Set(metadata.dirtyKeys);
		for (let index = 0; index < collection.length; index++) {
			const itemKey = metadata.keys[index];
			if (metadata.dirtyKeys.has(itemKey)) metadata.itemHashes[index] = hashItem(itemKey, collection[index]);
		}
		metadata.itemsHash = hashStringSequence(metadata.itemHashes, "exact:keyed-items:v1");
		metadata.dirtyKeys.clear();
		rebindOwners(metadata, collection, dirtyKeys);
		return metadata;
	} catch {
		clearMetadata(collection);
		return;
	}
}
/** Performs the mark reactive hash dirty domain operation. */
function markReactiveHashDirty(target) {
	const own = metadataByCollection.get(target);
	if (own) own.structureDirty = true;
	for (const owner of ownersByObject.get(target) ?? []) ownerMetadata(owner)?.dirtyKeys.add(owner.key);
}
/** Performs the install keyed collection metadata domain operation. */
function installKeyedCollectionMetadata(collection, source, bindMutationOwners = true) {
	clearMetadata(collection);
	const metadata = {
		keys: [...source.keys],
		keyHash: source.keyHash,
		itemHashes: [...source.itemHashes],
		itemsHash: source.itemsHash,
		structureDirty: false,
		dirtyKeys: /* @__PURE__ */ new Set(),
		owners: []
	};
	metadataByCollection.set(collection, metadata);
	if (bindMutationOwners) bindOwners(metadata, collection);
}
/** Performs the adopt keyed collection metadata domain operation. */
function adoptKeyedCollectionMetadata(collection, source, changedKeys) {
	const metadata = metadataByCollection.get(collection);
	if (!metadata) {
		installKeyedCollectionMetadata(collection, source);
		return;
	}
	const previousOwners = /* @__PURE__ */ new Map();
	for (let index = 0; index < metadata.keys.length; index++) {
		const owner = metadata.owners[index];
		if (owner) previousOwners.set(metadata.keys[index], owner);
	}
	const retainedOwners = /* @__PURE__ */ new Set();
	const nextOwners = [];
	for (let index = 0; index < source.keys.length; index++) {
		const key = source.keys[index];
		const previous = previousOwners.get(key);
		if (previous && !changedKeys.has(key)) {
			retainedOwners.add(previous);
			nextOwners.push(previous);
			continue;
		}
		if (previous) clearOwner(previous);
		nextOwners.push(createOwner(collection, key, collection[index]));
	}
	for (const owner of metadata.owners) if (!retainedOwners.has(owner) && !changedKeys.has(owner.key)) clearOwner(owner);
	metadata.owners = nextOwners;
	metadata.keys = [...source.keys];
	metadata.keyHash = source.keyHash;
	metadata.itemHashes = [...source.itemHashes];
	metadata.itemsHash = source.itemsHash;
	metadata.structureDirty = false;
	metadata.dirtyKeys.clear();
}
/** Produces a reactive protocol value internal in its external representation. */
function encodeReactiveProtocolValueInternal(value, extractorFor) {
	return encodeKeyedProtocolValue(value, extractorFor, keyedCollectionMetadata);
}
/** Reads a reactive protocol value internal from its source representation. */
function decodeReactiveProtocolValueInternal(value) {
	return decodeKeyedProtocolValue(value, (items, envelope) => installKeyedCollectionMetadata(items, envelope, false));
}
function rebuildMetadata(collection, key) {
	try {
		const keys = [];
		const itemHashes = [];
		const seen = /* @__PURE__ */ new Set();
		for (const item of collection) {
			const itemKey = String(key(item));
			if (seen.has(itemKey)) throw new Error(`Duplicate key "${itemKey}"`);
			seen.add(itemKey);
			keys.push(itemKey);
			itemHashes.push(hashItem(itemKey, item));
		}
		clearMetadata(collection);
		const metadata = {
			keys,
			keyHash: hashStringSequence(keys, "exact:keyed-keys:v1"),
			itemHashes,
			itemsHash: hashStringSequence(itemHashes, "exact:keyed-items:v1"),
			structureDirty: false,
			dirtyKeys: /* @__PURE__ */ new Set(),
			owners: []
		};
		metadataByCollection.set(collection, metadata);
		bindOwners(metadata, collection);
		return metadata;
	} catch {
		clearMetadata(collection);
		return;
	}
}
function keysChanged(collection, keys, key) {
	if (collection.length !== keys.length) return true;
	for (let index = 0; index < collection.length; index++) if (String(key(collection[index])) !== keys[index]) return true;
	return false;
}
function hashItem(key, value) {
	return hashCanonicalJson([key, value], "exact:keyed-item:v1");
}
function bindOwners(metadata, collection) {
	clearOwners(metadata);
	for (let index = 0; index < collection.length; index++) {
		const owner = createOwner(collection, metadata.keys[index], collection[index]);
		metadata.owners.push(owner);
	}
}
function rebindOwners(metadata, collection, keys) {
	for (let index = 0; index < metadata.keys.length; index++) {
		if (!keys.has(metadata.keys[index])) continue;
		const previous = metadata.owners[index];
		if (previous) clearOwner(previous);
		const owner = createOwner(collection, metadata.keys[index], collection[index]);
		metadata.owners[index] = owner;
	}
}
function createOwner(collection, key, value) {
	const nodes = [];
	collectJsonObjects(value, nodes, /* @__PURE__ */ new WeakSet(), 0);
	const owner = {
		collection,
		key,
		nodes
	};
	for (const node of nodes) {
		let owners = ownersByObject.get(node);
		if (!owners) ownersByObject.set(node, owners = /* @__PURE__ */ new Set());
		owners.add(owner);
	}
	return owner;
}
function collectJsonObjects(value, output, seen, depth) {
	if (!value || typeof value !== "object" || seen.has(value) || depth > 100) return;
	seen.add(value);
	output.push(value);
	if (Array.isArray(value)) for (const item of value) collectJsonObjects(item, output, seen, depth + 1);
	else for (const key of Object.keys(value)) {
		const descriptor = Object.getOwnPropertyDescriptor(value, key);
		if (descriptor && "value" in descriptor) collectJsonObjects(descriptor.value, output, seen, depth + 1);
	}
}
function clearMetadata(collection) {
	const metadata = metadataByCollection.get(collection);
	if (metadata) clearOwners(metadata);
	metadataByCollection.delete(collection);
}
function clearOwners(metadata) {
	for (const owner of metadata.owners) clearOwner(owner);
	metadata.owners = [];
}
function clearOwner(owner) {
	for (const node of owner.nodes) {
		const owners = ownersByObject.get(node);
		owners?.delete(owner);
		if (owners?.size === 0) ownersByObject.delete(node);
	}
}
function ownerMetadata(owner) {
	return metadataByCollection.get(owner.collection);
}
//#endregion
//#region packages/reactive/dist/array-mutation.js
/** Applies an array to the owned runtime state. */
function mutateArray(target, methodName, method, args, receiver, options) {
	if ((methodName === "push" || methodName === "pop") && method === Array.prototype[methodName]) return mutateArrayEnd(target, methodName, method, args, receiver, options);
	const previous = target.slice();
	let result;
	try {
		result = method.apply(target, args.map((arg) => unwrap(arg)));
	} finally {
		recordArrayMutationUndo(target, previous);
		batch(() => {
			const maxLength = Math.max(previous.length, target.length);
			let changed = previous.length !== target.length;
			for (let index = 0; index < maxLength; index++) {
				if (Reflect.has(previous, index) === Reflect.has(target, index) && Object.is(unwrap(previous[index]), unwrap(target[index]))) continue;
				changed = true;
				trigger(target, String(index));
			}
			if (previous.length !== target.length) trigger(target, "length");
			if (changed) {
				markReactiveHashDirty(target);
				trigger(target, iterateKey);
				notifyMutation$1(options, methodName);
			}
		});
	}
	return result === target ? receiver : result;
}
function notifyMutation$1(options, operation) {
	try {
		options.onMutation?.(void 0, operation);
	} catch {}
}
/**
* Records a sequence-aware inverse for an authored array method.
*
* The changed middle segment is replaced while any later authoritative prefix, suffix, or append
* remains in place. If authoritative work changed the optimistic segment itself, rollback falls
* back to restoring only positions that still contain the optimistic value.
*/
function recordArrayMutationUndo(target, previous) {
	if (!hasActiveTransaction()) return;
	const optimistic = target.slice();
	let prefix = 0;
	while (prefix < previous.length && prefix < optimistic.length && sameArraySlot(previous, optimistic, prefix, prefix)) prefix++;
	let suffix = 0;
	while (suffix < previous.length - prefix && suffix < optimistic.length - prefix && sameArraySlot(previous, optimistic, previous.length - suffix - 1, optimistic.length - suffix - 1)) suffix++;
	const previousEnd = previous.length - suffix;
	const optimisticEnd = optimistic.length - suffix;
	const removed = previous.slice(prefix, previousEnd);
	const inserted = optimistic.slice(prefix, optimisticEnd);
	recordTransactionUndo(() => {
		let segmentUnchanged = true;
		for (let offset = 0; offset < inserted.length; offset++) if (!sameArraySlot(optimistic, target, prefix + offset, prefix + offset)) {
			segmentUnchanged = false;
			break;
		}
		if (segmentUnchanged) {
			Array.prototype.splice.call(target, prefix, inserted.length, ...removed.map((value) => unwrap(value)));
			for (let offset = 0; offset < removed.length; offset++) {
				const previousIndex = prefix + offset;
				const targetIndex = prefix + offset;
				const descriptor = Reflect.getOwnPropertyDescriptor(previous, String(previousIndex));
				if (descriptor) Reflect.defineProperty(target, String(targetIndex), descriptor);
				else Reflect.deleteProperty(target, String(targetIndex));
			}
			return;
		}
		const changedLength = Math.max(previousEnd, optimisticEnd);
		for (let index = prefix; index < changedLength; index++) {
			if (!sameArraySlot(optimistic, target, index, index)) continue;
			if (Reflect.has(previous, index)) target[index] = previous[index];
			else Reflect.deleteProperty(target, index);
		}
	});
}
function sameArraySlot(left, right, leftIndex, rightIndex) {
	const leftExists = Reflect.has(left, leftIndex);
	return leftExists === Reflect.has(right, rightIndex) && (!leftExists || Object.is(unwrap(left[leftIndex]), unwrap(right[rightIndex])));
}
function mutateArrayEnd(target, methodName, method, args, receiver, options) {
	const oldLength = target.length;
	const removed = methodName === "pop" && oldLength > 0 ? Reflect.getOwnPropertyDescriptor(target, String(oldLength - 1)) : void 0;
	const journaled = hasActiveTransaction();
	const result = method.apply(target, args.map((arg) => unwrap(arg)));
	const newLength = target.length;
	if (newLength !== oldLength) {
		if (journaled) {
			if (methodName === "push") for (let index = oldLength; index < newLength; index++) {
				const insertedIndex = index;
				recordTransactionUndo(() => {
					Array.prototype.splice.call(target, insertedIndex, 1);
				}, target, String(insertedIndex));
			}
			else recordTransactionUndo(() => {
				Array.prototype.splice.call(target, oldLength - 1, 0, void 0);
				if (removed) Reflect.defineProperty(target, String(oldLength - 1), removed);
				else Reflect.deleteProperty(target, String(oldLength - 1));
			}, target, String(oldLength - 1));
		}
		batch(() => {
			markReactiveHashDirty(target);
			if (methodName === "push") for (let index = oldLength; index < newLength; index++) trigger(target, String(index));
			else trigger(target, String(oldLength - 1));
			trigger(target, "length");
			trigger(target, iterateKey);
		});
		notifyMutation$1(options, methodName);
	}
	return result === target ? receiver : result;
}
/** Performs the record property undo domain operation. */
function recordPropertyUndo(target, key) {
	if (!hasActiveTransaction()) return;
	recordTransactionUndo(createPropertyUndo(target, key), target, key);
}
/** Creates a property undo. */
function createPropertyUndo(target, key) {
	if (Array.isArray(target) && key === "length") return createArrayUndo(target);
	const descriptor = Reflect.getOwnPropertyDescriptor(target, key);
	const arrayTarget = Array.isArray(target) ? target : void 0;
	const oldLength = arrayTarget?.length;
	return () => {
		if (descriptor) Reflect.defineProperty(target, key, descriptor);
		else Reflect.deleteProperty(target, key);
		if (oldLength !== void 0 && arrayTarget && arrayTarget.length !== oldLength) arrayTarget.length = oldLength;
	};
}
/** Performs the record array undo domain operation. */
function recordArrayUndo(target) {
	if (!hasActiveTransaction()) return;
	recordTransactionUndo(createArrayUndo(target), target, iterateKey);
}
/** Creates an array undo. */
function createArrayUndo(target) {
	const descriptors = /* @__PURE__ */ new Map();
	for (const key of Reflect.ownKeys(target)) {
		const descriptor = Reflect.getOwnPropertyDescriptor(target, key);
		if (descriptor) descriptors.set(key, descriptor);
	}
	return () => {
		for (const key of Reflect.ownKeys(target)) if (key !== "length" && !descriptors.has(key)) Reflect.deleteProperty(target, key);
		const length = descriptors.get("length")?.value;
		if (typeof length === "number") target.length = length;
		for (const [key, descriptor] of descriptors) if (key !== "length") Reflect.defineProperty(target, key, descriptor);
	};
}
//#endregion
//#region packages/reactive/dist/proxy/create-base.js
/**
* Retains alias-specific proxy ownership while sharing the trap code across every nested proxy.
* A per-proxy record is required because one raw value may have several simultaneous parent paths.
*/
var reactiveProxyHandler = {
	get(target, key, receiver) {
		if (key === proxyMarker) return true;
		if (key === rawTarget) return target;
		const { collectionMember, options, proxy } = this.record;
		trackProxySources(proxy);
		if (target instanceof Map || target instanceof Set) {
			if (!collectionMember) throw new TypeError("Compiled object/array state received a Map or Set value");
			return collectionMember(target, key, proxy, options, (current, dependency) => {
				if (!current || typeof current !== "object" || !isReactiveContainer(unwrap(current))) return current;
				return sourcedReactive(unwrap(current), options, dependency === void 0 ? void 0 : createParentSource(target, dependency, options, collectionMember), collectionMember);
			});
		}
		const current = Reflect.get(target, key, receiver);
		if (current && typeof current === "object" && requiresExactProxyValue(target, key)) return current;
		if (Array.isArray(target) && mutatingArrayMethods.has(key) && typeof current === "function") return (...args) => mutateArray(target, String(key), current, args, receiver, options);
		if (options.passthroughKeys?.includes(key)) {
			track(target, key);
			return current;
		}
		if (isReactiveValue(current)) {
			track(target, key);
			const currentTarget = unwrap(current.get());
			return isReactiveContainer(currentTarget) ? sourcedReactive(currentTarget, options, createParentSource(target, key, options, collectionMember), collectionMember) : currentTarget;
		}
		if (current && typeof current === "object" && isReactiveContainer(unwrap(current))) {
			const currentTarget = unwrap(current);
			if (currentTarget === target) {
				track(target, key);
				return receiver;
			}
			return sourcedReactive(currentTarget, options, createParentSource(target, key, options, collectionMember), collectionMember);
		}
		track(target, key);
		return current;
	},
	set(target, key, next, receiver) {
		const { options } = this.record;
		if (options.readonly) {
			options.onReadonlyWrite?.(key);
			return false;
		}
		const previousLength = Array.isArray(target) ? target.length : void 0;
		const removedIndexes = Array.isArray(target) && key === "length" && typeof next === "number" && next < target.length ? Array.from({ length: target.length - next }, (_, offset) => next + offset).filter((index) => Reflect.has(target, index)) : [];
		const previous = Reflect.get(target, key, receiver);
		const unwrapped = unwrap(next);
		const hadKey = Object.prototype.hasOwnProperty.call(target, key);
		const changed = hasChanged(previous, unwrapped);
		const ownDescriptor = Reflect.getOwnPropertyDescriptor(target, key);
		if (!changed && ownDescriptor && "value" in ownDescriptor) return true;
		const undo = hasActiveTransaction() ? createPropertyUndo(target, key) : void 0;
		this.record.forwardingSet = true;
		let ok;
		try {
			ok = Reflect.set(target, key, unwrapped, receiver);
		} finally {
			this.record.forwardingSet = false;
		}
		if (ok && undo && (!hadKey || !Object.is(previous, Reflect.get(target, key, receiver)))) recordTransactionUndo(undo, target, key);
		if (ok && changed) {
			markReactiveHashDirty(target);
			trigger(target, key);
			for (const index of removedIndexes) trigger(target, String(index));
			if (previousLength !== void 0 && Array.isArray(target) && target.length !== previousLength && key !== "length") trigger(target, "length");
			if (!hadKey || isArrayStructureKey(target, key)) trigger(target, iterateKey);
			notifyMutation(options, key, "set");
		}
		return ok;
	},
	defineProperty(target, key, descriptor) {
		const { options } = this.record;
		if (this.record.forwardingSet) return Reflect.defineProperty(target, key, descriptor);
		if (options.readonly) {
			options.onReadonlyWrite?.(key);
			return false;
		}
		const previous = Reflect.getOwnPropertyDescriptor(target, key);
		if (samePropertyDescriptor(previous, descriptor)) return true;
		const undo = hasActiveTransaction() ? createPropertyUndo(target, key) : void 0;
		const oldLength = Array.isArray(target) ? target.length : void 0;
		if (!Reflect.defineProperty(target, key, normalizeDescriptor(descriptor))) return false;
		if (undo) recordTransactionUndo(undo, target, key);
		markReactiveHashDirty(target);
		trigger(target, key);
		if (!previous || isArrayStructureKey(target, key)) trigger(target, iterateKey);
		if (oldLength !== void 0 && target.length !== oldLength && key !== "length") trigger(target, "length");
		notifyMutation(options, key, "define");
		return true;
	},
	deleteProperty(target, key) {
		const { options } = this.record;
		if (options.readonly) {
			options.onReadonlyWrite?.(key);
			return false;
		}
		const hadKey = Object.prototype.hasOwnProperty.call(target, key);
		const descriptor = hadKey && hasActiveTransaction() ? Reflect.getOwnPropertyDescriptor(target, key) : void 0;
		const ok = Reflect.deleteProperty(target, key);
		if (ok && hadKey) {
			if (descriptor) recordTransactionUndo(() => {
				Reflect.defineProperty(target, key, descriptor);
			}, target, key);
			markReactiveHashDirty(target);
			trigger(target, key);
			trigger(target, iterateKey);
			notifyMutation(options, key, "delete");
		}
		return ok;
	},
	ownKeys(target) {
		trackProxySources(this.record.proxy);
		track(target, iterateKey);
		return Reflect.ownKeys(target);
	},
	has(target, key) {
		track(target, key);
		return Reflect.has(target, key);
	}
};
/** Creates a reactive with an explicitly selected collection capability. */
function createReactiveBase(value, options, parentSource, collectionMember) {
	const reactiveTarget = isReactive(value) ? value[rawTarget] : value;
	const cached = getCachedProxy(reactiveTarget, options, parentSource);
	if (cached) {
		if (parentSource) registerProxySource(cached, parentSource);
		return cached;
	}
	const record = {
		options,
		collectionMember,
		forwardingSet: false
	};
	const handler = Object.create(reactiveProxyHandler);
	handler.record = record;
	const proxy = new Proxy(reactiveTarget, handler);
	record.proxy = proxy;
	cacheProxy(reactiveTarget, options, parentSource, proxy);
	if (parentSource) {
		reactiveRawObjects.add(reactiveTarget);
		registerProxySource(proxy, parentSource);
	}
	return proxy;
}
/** Preserves ECMAScript invariants for frozen object-valued data properties. */
function requiresExactProxyValue(target, key) {
	const descriptor = Reflect.getOwnPropertyDescriptor(target, key);
	return !!descriptor && "value" in descriptor && !descriptor.configurable && !descriptor.writable;
}
function createParentSource(target, key, options, collectionMember) {
	const optionKey = reactiveOptionsKey(options);
	let byKey = parentSourceCache.get(target);
	if (!byKey) parentSourceCache.set(target, byKey = /* @__PURE__ */ new Map());
	let byOptions = byKey.get(key);
	if (!byOptions) byKey.set(key, byOptions = /* @__PURE__ */ new WeakMap());
	const cached = byOptions.get(optionKey);
	if (cached) return cached;
	const source = {
		target,
		key,
		get() {
			track(target, key);
			const next = Reflect.get(target, key);
			if (isReactiveValue(next)) {
				const nextValue = next.get();
				return nextValue && typeof nextValue === "object" ? sourcedReactive(unwrap(nextValue), options, source, collectionMember) : nextValue;
			}
			return next && typeof next === "object" ? sourcedReactive(unwrap(next), options, source, collectionMember) : next;
		},
		set(value) {
			const previous = Reflect.get(target, key);
			const unwrapped = unwrap(value);
			if (!hasChanged(previous, unwrapped)) return;
			recordPropertyUndo(target, key);
			Reflect.set(target, key, unwrapped);
			markReactiveHashDirty(target);
			trigger(target, key);
			if (isArrayStructureKey(target, key)) trigger(target, iterateKey);
		}
	};
	byOptions.set(optionKey, source);
	return source;
}
/** Reuses the child proxy most recently resolved through one stable parent path. */
function sourcedReactive(raw, options, source, collectionMember) {
	if (!source) return createReactiveBase(raw, options, void 0, collectionMember);
	if (source.cachedRaw === raw && source.cachedProxy) {
		registerProxySource(source.cachedProxy, source);
		return source.cachedProxy;
	}
	const proxy = createReactiveBase(raw, options, source, collectionMember);
	source.cachedRaw = raw;
	source.cachedProxy = proxy;
	return proxy;
}
function getCachedProxy(raw, options, source) {
	const optionKey = reactiveOptionsKey(options);
	if (!source) return rootProxyCache.get(raw)?.get(optionKey);
	const bySource = sourcedProxyCache.get(raw)?.get(optionKey);
	const exact = bySource?.get(source);
	if (exact) return exact;
	if (bySource) for (const [oldSource, proxy] of bySource) {
		if (unwrap(Reflect.get(oldSource.target, oldSource.key)) === raw) continue;
		bySource.delete(oldSource);
		bySource.set(source, proxy);
		proxySources.set(proxy, /* @__PURE__ */ new Set([source]));
		proxyRefs.set(proxy, source);
		return proxy;
	}
}
function cacheProxy(raw, options, source, proxy) {
	const optionKey = reactiveOptionsKey(options);
	if (source) {
		let byOptions = sourcedProxyCache.get(raw);
		if (!byOptions) sourcedProxyCache.set(raw, byOptions = /* @__PURE__ */ new WeakMap());
		let bySource = byOptions.get(optionKey);
		if (!bySource) byOptions.set(optionKey, bySource = /* @__PURE__ */ new Map());
		bySource.set(source, proxy);
		return;
	}
	let byOptions = rootProxyCache.get(raw);
	if (!byOptions) rootProxyCache.set(raw, byOptions = /* @__PURE__ */ new WeakMap());
	byOptions.set(optionKey, proxy);
}
function registerProxySource(proxy, source) {
	proxySources.set(proxy, /* @__PURE__ */ new Set([source]));
	proxyRefs.set(proxy, source);
}
function trackProxySources(proxy) {
	for (const source of proxySources.get(proxy) ?? []) track(source.target, source.key);
}
function normalizeDescriptor(descriptor) {
	return "value" in descriptor ? {
		...descriptor,
		value: unwrap(descriptor.value)
	} : descriptor;
}
function samePropertyDescriptor(left, right) {
	if (!left) return false;
	if ("value" in left !== "value" in right) return false;
	if (left.configurable !== right.configurable || left.enumerable !== right.enumerable) return false;
	if ("value" in left && "value" in right) return left.writable === right.writable && !hasChanged(left.value, right.value);
	return left.get === right.get && left.set === right.set;
}
function reactiveOptionsKey(options) {
	if ("__exactCollectionCacheMode" in options) return options;
	if (!options.readonly && !options.onReadonlyWrite && !options.onMutation && !options.passthroughKeys?.length) return defaultReactiveOptions;
	if (options.readonly && !options.onReadonlyWrite && !options.onMutation && !options.passthroughKeys?.length) return readonlyReactiveOptionsKey;
	return options;
}
function notifyMutation(options, key, operation) {
	try {
		options.onMutation?.(key, operation);
	} catch {}
}
//#endregion
//#region packages/reactive/dist/framework/objects.js
/** Creates a compiler-proven object/array reactive without retaining collection interception. */
function reactiveObjects(value, options = defaultReactiveOptions, parentSource) {
	const raw = unwrap(value);
	if (!isReactiveContainer(raw)) return value;
	if (raw instanceof Map || raw instanceof Set) throw new TypeError("Compiled object/array state received a Map or Set value");
	return createReactiveBase(raw, options, parentSource);
}
//#endregion
//#region packages/reactive/dist/indexed-layout.js
var indexedLayouts = /* @__PURE__ */ new WeakMap();
/** Reuses one immutable indexed layout for every facade built from the same compiler key array. */
function indexedLayout(keys) {
	const identity = keys;
	const cached = indexedLayouts.get(identity);
	if (cached) return cached;
	const indexes = /* @__PURE__ */ new Map();
	const uniqueKeys = [];
	for (const key of keys) {
		if (indexes.has(key)) continue;
		indexes.set(key, indexes.size);
		uniqueKeys.push(key);
	}
	const layout = {
		indexes,
		keys: uniqueKeys
	};
	indexedLayouts.set(identity, layout);
	return layout;
}
//#endregion
//#region packages/reactive/dist/reactive-record-slots.js
/** Resolves a compiler-known or instance-local dynamic property to its stable numeric slot. */
function indexedRecordIndex(record, key) {
	return record.layout.indexes.get(key) ?? record.dynamicIndexes?.get(key);
}
/** Resolves one property slot, extending only the receiving instance for a dynamic property. */
function ensureIndexedRecordIndex(record, key) {
	const existing = indexedRecordIndex(record, key);
	if (existing !== void 0) return existing;
	const dynamicIndexes = record.dynamicIndexes ??= /* @__PURE__ */ new Map();
	const dynamicKeys = record.dynamicKeys ??= [];
	const index = record.layout.keys.length + dynamicIndexes.size;
	dynamicIndexes.set(key, index);
	dynamicKeys.push(key);
	record.initialized.push(false);
	return index;
}
/** Resolves one validated numeric slot back to its authored property identity. */
function indexedRecordKey(record, index) {
	if (index < record.layout.keys.length) return record.layout.keys[index];
	return record.dynamicKeys[index - record.layout.keys.length];
}
//#endregion
//#region packages/reactive/dist/indexed-base.js
/** Private compiler operand for one direct property read owned by a component prop slot. */
var compiledReactivePropertyOperand = Symbol.for("exact.reactive.property-operand");
var indexedRecords = /* @__PURE__ */ new WeakMap();
/**
* Shared traps resolve instance-owned storage through each handler's record. Keeping the trap
* methods module-local avoids retaining equivalent closures for every indexed state or props facade.
*/
var indexedProxyHandler = {
	get(target, key, receiver) {
		if (key === proxyMarker) return true;
		if (key === rawTarget) return target;
		const { record } = this;
		const index = indexedRecordIndex(record, key);
		return index === void 0 ? Reflect.get(target, key, receiver) : readIndexedValue(record, key, index, "facade");
	},
	set(_target, key, next) {
		const { record } = this;
		if (record.options.readonly) {
			record.options.onReadonlyWrite?.(key);
			return false;
		}
		return writeIndexedRecord(record, ensureIndexedRecordIndex(record, key), next);
	},
	deleteProperty(target, key) {
		const { record } = this;
		const index = indexedRecordIndex(record, key);
		return index === void 0 ? Reflect.deleteProperty(target, key) : deleteIndexedRecord(record, index);
	},
	has(target, key) {
		const { record } = this;
		const index = indexedRecordIndex(record, key);
		return index !== void 0 && record.initialized[index] === true || Reflect.has(target, key);
	}
};
/**
* Creates an inspectable object facade whose compiler-known top-level fields are
* stored in stable numeric slots. Nested containers retain the general reactive
* proxy so ordinary mutable objects, arrays, maps, and sets keep their semantics.
*/
function createIndexedReactive(keys, options, wrap, initial, preserveReactiveValues = false) {
	const layout = indexedLayout(keys);
	const target = {};
	const record = {
		layout,
		initialized: new Array(layout.keys.length).fill(false),
		target,
		options,
		wrap,
		preserveReactiveValues
	};
	if (initial) seedIndexedRecord(record, initial);
	const handler = Object.create(indexedProxyHandler);
	handler.record = record;
	const facade = new Proxy(target, handler);
	indexedRecords.set(facade, record);
	return facade;
}
/** Reads one compiler-proven top-level slot without entering the facade's property trap. */
function readIndexedReactiveSlot(value, index) {
	const indexed = indexedRecord(value, index, "read");
	return readIndexedValue(indexed, indexedRecordKey(indexed, index), index, "direct");
}
/** Reads one compiler-proven slot without collecting a dependency. */
function peekIndexedReactiveSlot(value, index) {
	const indexed = indexedRecord(value, index, "peek");
	return readIndexedValue(indexed, indexedRecordKey(indexed, index), index, "peek");
}
/** Commits one compiler-proven slot without entering the facade's proxy traps. */
function setIndexedReactiveSlot(value, index, next) {
	writeIndexedRecord(indexedRecord(value, index, "write"), index, next);
}
/** Commits one compiler-proven slot and reports whether its dependency version advanced. */
function setIndexedReactiveSlotWithResult(value, index, next) {
	const indexed = indexedRecord(value, index, "write");
	const previous = readMutationVersion(indexed.target, index);
	writeIndexedRecord(indexed, index, next);
	return readMutationVersion(indexed.target, index) !== previous;
}
/** Deletes one compiler-proven slot and reports whether its dependency version advanced. */
function deleteIndexedReactiveSlotWithResult(value, index) {
	const indexed = indexedRecord(value, index, "delete");
	const previous = readMutationVersion(indexed.target, index);
	deleteIndexedRecord(indexed, index);
	return readMutationVersion(indexed.target, index) !== previous;
}
function indexedRecord(value, index, operation) {
	const indexed = indexedRecords.get(value);
	if (!indexed || !Number.isSafeInteger(index) || index < 0 || index >= indexed.initialized.length) throw new TypeError(`Compiled reactive ${operation} referenced an invalid indexed slot`);
	return indexed;
}
function writeIndexedRecord(indexed, index, next) {
	const key = indexedRecordKey(indexed, index);
	const previous = indexed.target[key];
	const raw = retainedIndexedValue(indexed, key, next);
	const value = !indexed.options.passthroughKeys?.includes(key) && !(Array.isArray(raw) && raw[0] === compiledReactivePropertyOperand) && !isReactiveValue(raw) && raw && typeof raw === "object" && isReactiveContainer(raw) ? indexed.wrap(raw, indexed.options, indexedParentSource(indexed, index)) : raw;
	const wasInitialized = indexed.initialized[index] === true;
	if (wasInitialized && !hasChanged(previous, value)) return true;
	if (hasActiveTransaction()) recordTransactionUndo(() => {
		if (wasInitialized) indexed.target[key] = previous;
		if (!wasInitialized) {
			indexed.initialized[index] = false;
			Reflect.deleteProperty(indexed.target, key);
		}
	}, indexed.target, index);
	Reflect.defineProperty(indexed.target, key, {
		configurable: true,
		enumerable: true,
		value,
		writable: true
	});
	indexed.initialized[index] = true;
	trigger(indexed.target, index);
	try {
		indexed.options.onMutation?.(key, "set");
	} catch {}
	return true;
}
function seedIndexedRecord(indexed, initial) {
	for (const key of Reflect.ownKeys(initial)) {
		const index = ensureIndexedRecordIndex(indexed, key);
		const raw = retainedIndexedValue(indexed, key, Reflect.get(initial, key));
		indexed.target[key] = !indexed.options.passthroughKeys?.includes(key) && !(Array.isArray(raw) && raw[0] === compiledReactivePropertyOperand) && !isReactiveValue(raw) && raw && typeof raw === "object" && isReactiveContainer(raw) ? indexed.wrap(raw, indexed.options, indexedParentSource(indexed, index)) : raw;
		indexed.initialized[index] = true;
	}
}
function retainedIndexedValue(indexed, key, value) {
	if (indexed.options.passthroughKeys?.includes(key)) return value;
	if (indexed.preserveReactiveValues && isReactiveValue(value)) return value;
	return unwrap(value);
}
function readIndexedValue(indexed, key, index, mode) {
	const current = indexed.target[key];
	if (indexed.options.passthroughKeys?.includes(key)) {
		if (mode !== "peek") track(indexed.target, index);
		return current;
	}
	const propertyOperand = indexed.preserveReactiveValues && Array.isArray(current) && current[0] === compiledReactivePropertyOperand ? current : void 0;
	const raw = unwrap(propertyOperand ? Reflect.get(propertyOperand[1], propertyOperand[2]) : indexed.preserveReactiveValues && isReactiveValue(current) ? current.get() : current);
	if (raw && typeof raw === "object" && isReactiveContainer(raw)) {
		if (mode === "direct") track(indexed.target, index);
		return indexed.wrap(raw, indexed.options, indexedParentSource(indexed, index));
	}
	if (mode !== "peek") track(indexed.target, index);
	return raw;
}
/** Stable parent dependency used by nested proxies without subscribing a reader that only forwards them. */
function indexedParentSource(indexed, index) {
	const sources = indexed.sources ??= [];
	const existing = sources[index];
	if (existing) return existing;
	const source = {
		target: indexed.target,
		key: index,
		get() {
			return readIndexedValue(indexed, indexedRecordKey(indexed, index), index, "direct");
		},
		set(value) {
			writeIndexedRecord(indexed, index, value);
		}
	};
	sources[index] = source;
	return source;
}
function deleteIndexedRecord(indexed, index) {
	const key = indexedRecordKey(indexed, index);
	if (indexed.initialized[index]) {
		const previous = indexed.target[key];
		if (hasActiveTransaction()) recordTransactionUndo(() => {
			Reflect.defineProperty(indexed.target, key, {
				configurable: true,
				enumerable: true,
				value: previous,
				writable: true
			});
			indexed.initialized[index] = true;
		}, indexed.target, index);
		trigger(indexed.target, index);
	}
	indexed.initialized[index] = false;
	return Reflect.deleteProperty(indexed.target, key);
}
/** Resolves compiler-known own fields to compact stable dependencies without evaluating them. */
function reactiveOwnDependencies(value, keys) {
	const indexed = indexedRecords.get(value);
	if (!indexed) return void 0;
	const indexes = [];
	for (const key of keys) {
		const index = indexedRecordIndex(indexed, key);
		if (index === void 0) return void 0;
		indexes.push(index);
	}
	return {
		target: indexed.target,
		keys: indexes
	};
}
/** Resolves compiler-emitted numeric fields without repeating a property-layout lookup. */
function reactiveIndexedDependencies(value, indexes) {
	const indexed = indexedRecords.get(value);
	if (!indexed) return void 0;
	for (const index of indexes) if (!Number.isSafeInteger(index) || index < 0 || index >= indexed.initialized.length) return void 0;
	return {
		target: indexed.target,
		keys: indexes
	};
}
/** Reads the retained source value for one validated compiler-indexed field without evaluating it. */
function readIndexedReactiveSource(value, index) {
	const indexed = indexedRecords.get(value);
	if (!indexed || !Number.isSafeInteger(index) || index < 0 || index >= indexed.initialized.length || !indexed.initialized[index]) return { present: false };
	return {
		present: true,
		value: indexed.target[indexedRecordKey(indexed, index)]
	};
}
//#endregion
//#region packages/reactive/dist/protocol.js
/** Encodes registered keyed arrays into the eXact server-to-client JSON protocol shape. */
function encodeReactiveProtocolValue(value) {
	return encodeReactiveProtocolValueInternal(unwrap(value), (collection) => listKeyExtractors.get(collection)?.key);
}
/** Decodes eXact keyed-collection envelopes into ordinary arrays with hash sidecars. */
function decodeReactiveProtocolValue(value) {
	return decodeReactiveProtocolValueInternal(value);
}
//#endregion
//#region packages/reactive/dist/reconciliation.js
/** Returns true when a compatible structured value was reconciled in place. */
function reconcileReactiveValue(previous, next, seen, depth = 0) {
	if (depth > 100) return false;
	const oldValue = unwrap(previous);
	const nextValue = unwrap(next);
	if (Object.is(oldValue, nextValue)) return true;
	if (!oldValue || !nextValue || typeof oldValue !== "object" || typeof nextValue !== "object") return false;
	if (!(Array.isArray(oldValue) && Array.isArray(nextValue) ? Object.getPrototypeOf(oldValue) === Object.getPrototypeOf(nextValue) && canReconcileStructure(oldValue) && canReadStructure(nextValue) : isPlainObject(oldValue) && isPlainObject(nextValue) && Object.getPrototypeOf(oldValue) === Object.getPrototypeOf(nextValue) && canReconcileStructure(oldValue) && canReadStructure(nextValue))) return false;
	const priorNext = seen.oldToNext.get(oldValue);
	const priorOld = seen.nextToOld.get(nextValue);
	if (priorNext || priorOld) return priorNext === nextValue && priorOld === oldValue;
	seen.oldToNext.set(oldValue, nextValue);
	seen.nextToOld.set(nextValue, oldValue);
	const current = previous;
	if (Array.isArray(oldValue) && Array.isArray(nextValue)) {
		const registration = listKeyExtractors.get(oldValue);
		if (registration) return reconcileKeyedArray(current, oldValue, nextValue, registration.key, seen, depth);
		const oldLength = oldValue.length;
		const previousItems = Array.from({ length: oldLength }, (_, index) => Object.prototype.hasOwnProperty.call(current, index) ? current[index] : arrayHole);
		const existingByIdentity = /* @__PURE__ */ new WeakMap();
		for (const item of previousItems) {
			const identity = structuredIdentity(item);
			if (identity) existingByIdentity.set(identity, item);
		}
		const retainedIdentities = /* @__PURE__ */ new WeakSet();
		for (const incoming of nextValue) {
			const identity = structuredIdentity(incoming);
			if (identity && existingByIdentity.has(identity)) retainedIdentities.add(identity);
		}
		reconcileArrayItems(current, oldLength, nextValue.map((incoming, index) => {
			const incomingIdentity = structuredIdentity(incoming);
			const retained = incomingIdentity ? existingByIdentity.get(incomingIdentity) : void 0;
			if (retained !== void 0) return retained;
			const previousItem = previousItems[index];
			if (previousItem === arrayHole) return incoming;
			const previousIdentity = structuredIdentity(previousItem);
			if (previousIdentity && retainedIdentities.has(previousIdentity)) return incoming;
			return previousItem !== void 0 && reconcileReactiveValue(previousItem, incoming, seen, depth + 1) ? previousItem : incoming;
		}));
		reconcileArrayProperties(current, oldValue, nextValue, seen, depth);
		return true;
	}
	const nextRecord = nextValue;
	for (const key of Reflect.ownKeys(oldValue)) if (!Object.prototype.hasOwnProperty.call(nextRecord, key)) Reflect.deleteProperty(current, key);
	for (const key of Reflect.ownKeys(nextRecord)) {
		const nextDescriptor = Reflect.getOwnPropertyDescriptor(nextRecord, key);
		const oldDescriptor = Reflect.getOwnPropertyDescriptor(oldValue, key);
		if (!("value" in nextDescriptor)) return false;
		if (!oldDescriptor || !("value" in oldDescriptor) || !reconcileReactiveValue(current[key], nextDescriptor.value, seen, depth + 1)) Reflect.defineProperty(current, key, {
			...nextDescriptor,
			value: unwrap(nextDescriptor.value)
		});
	}
	return true;
}
var arrayHole = Symbol("exact.array-hole");
/** Creates a reconcile pairs. */
function createReconcilePairs() {
	return {
		oldToNext: /* @__PURE__ */ new WeakMap(),
		nextToOld: /* @__PURE__ */ new WeakMap()
	};
}
function reconcileArrayProperties(current, oldValue, nextValue, seen, depth) {
	const isExtra = (key) => key !== "length" && !(typeof key === "string" && /^(0|[1-9]\d*)$/.test(key));
	for (const key of Reflect.ownKeys(oldValue)) if (isExtra(key) && !Object.prototype.hasOwnProperty.call(nextValue, key)) Reflect.deleteProperty(current, key);
	for (const key of Reflect.ownKeys(nextValue)) {
		if (!isExtra(key)) continue;
		const nextDescriptor = Reflect.getOwnPropertyDescriptor(nextValue, key);
		const oldDescriptor = Reflect.getOwnPropertyDescriptor(oldValue, key);
		if (!("value" in nextDescriptor)) continue;
		if (!oldDescriptor || !("value" in oldDescriptor) || !reconcileReactiveValue(current[key], nextDescriptor.value, seen, depth + 1)) Reflect.defineProperty(current, key, {
			...nextDescriptor,
			value: unwrap(nextDescriptor.value)
		});
	}
}
function reconcileKeyedArray(current, oldValue, nextValue, key, seen, depth) {
	const previousMetadata = keyedCollectionMetadata(oldValue, key);
	const incomingMetadata = keyedCollectionMetadata(nextValue);
	if (previousMetadata && incomingMetadata && previousMetadata.itemsHash === incomingMetadata.itemsHash) return true;
	if (previousMetadata && incomingMetadata && previousMetadata.keyHash === incomingMetadata.keyHash) {
		const changedKeys = /* @__PURE__ */ new Set();
		for (let index = 0; index < nextValue.length; index++) {
			if (previousMetadata.itemHashes[index] === incomingMetadata.itemHashes[index]) continue;
			const id = incomingMetadata.keys[index];
			changedKeys.add(id);
			if (!reconcileReactiveValue(current[index], nextValue[index], seen, depth + 1)) current[index] = nextValue[index];
		}
		adoptKeyedCollectionMetadata(oldValue, incomingMetadata, changedKeys);
		return true;
	}
	const existing = /* @__PURE__ */ new Map();
	for (let index = 0; index < oldValue.length; index++) {
		const id = String(key(oldValue[index]));
		if (existing.has(id)) throw new Error(`Duplicate key "${id}" in the current keyed reactive array`);
		existing.set(id, {
			item: current[index],
			index
		});
	}
	const incomingEntries = nextValue.map((incoming) => ({
		id: String(key(incoming)),
		incoming
	}));
	const keys = /* @__PURE__ */ new Set();
	for (const { id } of incomingEntries) {
		if (keys.has(id)) throw new Error(`Duplicate key "${id}" in the next keyed reactive array`);
		keys.add(id);
	}
	const nextItems = [];
	const changedKeys = /* @__PURE__ */ new Set();
	for (let index = 0; index < incomingEntries.length; index++) {
		const { id, incoming } = incomingEntries[index];
		const previousEntry = existing.get(id);
		if (previousEntry !== void 0 && previousMetadata !== void 0 && incomingMetadata !== void 0 && previousMetadata.itemHashes[previousEntry.index] === incomingMetadata.itemHashes[index]) nextItems.push(previousEntry.item);
		else if (previousEntry !== void 0 && reconcileReactiveValue(previousEntry.item, incoming, seen, depth + 1)) {
			changedKeys.add(id);
			nextItems.push(previousEntry.item);
		} else {
			if (previousEntry !== void 0) changedKeys.add(id);
			nextItems.push(incoming);
		}
	}
	reconcileArrayItems(current, oldValue.length, nextItems);
	if (incomingMetadata) adoptKeyedCollectionMetadata(oldValue, incomingMetadata, changedKeys);
	else seedKeyedCollectionMetadata(oldValue, key);
	return true;
}
function structuredIdentity(value) {
	const identity = unwrap(value);
	return identity && typeof identity === "object" ? identity : void 0;
}
function reconcileArrayItems(current, oldLength, nextItems) {
	const target = unwrap(current);
	recordArrayUndo(target);
	const changedIndexes = /* @__PURE__ */ new Set();
	for (let index = 0; index < nextItems.length; index++) {
		if (!Reflect.has(nextItems, index)) {
			if (Reflect.has(target, index)) {
				Reflect.deleteProperty(target, index);
				changedIndexes.add(index);
			}
			continue;
		}
		const next = unwrap(nextItems[index]);
		if (Object.is(unwrap(target[index]), next)) continue;
		Reflect.set(target, index, next);
		changedIndexes.add(index);
	}
	if (nextItems.length < oldLength) for (let index = oldLength - 1; index >= nextItems.length; index--) {
		if (Reflect.has(target, index)) changedIndexes.add(index);
		Reflect.deleteProperty(target, index);
	}
	if (target.length !== nextItems.length) target.length = nextItems.length;
	for (const index of changedIndexes) trigger(target, String(index));
	if (oldLength !== nextItems.length) trigger(target, "length");
	if (changedIndexes.size || oldLength !== nextItems.length) trigger(target, iterateKey);
}
function canReconcileStructure(value) {
	if (!Object.isExtensible(value)) return false;
	return Reflect.ownKeys(value).every((key) => {
		if (Array.isArray(value) && key === "length") return true;
		const descriptor = Reflect.getOwnPropertyDescriptor(value, key);
		return !!descriptor && "value" in descriptor && descriptor.writable !== false && descriptor.configurable !== false;
	});
}
function canReadStructure(value) {
	return Reflect.ownKeys(value).every((key) => {
		if (Array.isArray(value) && key === "length") return true;
		const descriptor = Reflect.getOwnPropertyDescriptor(value, key);
		return !!descriptor && "value" in descriptor;
	});
}
//#endregion
//#region packages/reactive/dist/writes.js
/** Compiler hook that assigns a value to one proven top-level state slot. */
function writeIndexedReactiveValue(target, index, next) {
	commitIndexedReactiveWrite(target, index, next);
	return next;
}
function commitIndexedReactiveWrite(target, index, next) {
	const previous = peekIndexedReactiveSlot(target, index);
	const rawPrevious = unwrap(previous);
	const rawNext = unwrap(next);
	if (Object.is(rawPrevious, rawNext)) return;
	if (rawPrevious === null || rawNext === null || typeof rawPrevious !== "object" || typeof rawNext !== "object") {
		setIndexedReactiveSlot(target, index, next);
		return;
	}
	const reconcile = () => {
		if (!reconcileReactiveValue(previous, next, createReconcilePairs())) setIndexedReactiveSlot(target, index, next);
	};
	if (hasActiveReactiveTransaction()) reconcile();
	else batch(reconcile);
}
/** Records the stable identity used by a keyed list for compiler reconciliation. */
function registerReactiveListKey(collection, key, site = "an unlabelled this.map() call", identity) {
	if (!collection || typeof collection !== "object") return () => void 0;
	const raw = unwrap(collection);
	if (!Array.isArray(raw)) return () => void 0;
	const signature = identity ? `compiler:${identity}` : `runtime:${Function.prototype.toString.call(key)}`;
	const previous = listKeyExtractors.get(raw);
	if (previous && previous.signature !== signature) throw conflictingListKeyError(previous.site, site);
	if (previous && !identity) {
		for (const item of raw) if (String(previous.key(item)) !== String(key(item))) throw conflictingListKeyError(previous.site, site);
	}
	if (previous) previous.references++;
	else listKeyExtractors.set(raw, {
		key,
		signature,
		site,
		references: 1
	});
	let active = true;
	return () => {
		if (!active) return;
		active = false;
		const registration = listKeyExtractors.get(raw);
		if (!registration || registration.signature !== signature) return;
		if (--registration.references === 0) {
			listKeyExtractors.delete(raw);
			releaseKeyedCollectionMetadata(raw);
		}
	};
}
//#endregion
//#region packages/core/dist/client/class-values.js
/**
* Normalizes one compiler-authored class value into its DOM attribute representation.
*
* Arrays retain source order, objects contribute truthy keys in property order, and reactive
* values are unwrapped at every nesting level. Duplicate tokens are deliberately preserved:
* only the compiler can diagnose collisions that are statically provable without changing
* dynamic authored behavior.
*/
function normalizeClassValue(value) {
	return appendClassValue("", value);
}
function appendClassValue(output, candidate) {
	const actual = unwrap(candidate);
	if (actual === false || actual === null || actual === void 0) return output;
	if (Array.isArray(actual)) {
		for (const item of actual) output = appendClassValue(output, item);
		return output;
	}
	if (typeof actual === "object") {
		for (const name in actual) {
			if (!Object.hasOwn(actual, name)) continue;
			if (Boolean(unwrap(actual[name]))) output = appendClassToken(output, name);
		}
		return output;
	}
	return appendClassToken(output, String(actual));
}
function appendClassToken(output, token) {
	if (!token) return output;
	return output ? `${output} ${token}` : token;
}
//#endregion
//#region packages/core/dist/client/cleanup.js
/** Creates an empty collector for a failure-complete cleanup sequence. */
function createCleanupFailure() {
	return {
		failed: false,
		error: void 0
	};
}
/** Records the first cleanup error while retaining the fact that cleanup failed. */
function recordCleanupFailure(failure, error) {
	if (!failure.failed) failure.error = error;
	failure.failed = true;
}
/**
* Attempts one synchronous cleanup without interrupting subsequent cleanups.
*/
function attemptCleanup(failure, cleanup) {
	try {
		cleanup();
	} catch (error) {
		recordCleanupFailure(failure, error);
	}
}
/** Throws the first error recorded by a completed cleanup sequence. */
function throwCleanupFailure(failure) {
	if (failure.failed) throw failure.error;
}
/**
* Preserves an active primary failure while retaining cleanup diagnostics.
*
* Attaching diagnostic metadata is deliberately best-effort because a frozen
* or hostile primary value must never replace the error already in flight.
*/
function attachSuppressedCleanupFailure(primary, cleanup) {
	if (!primary || typeof primary !== "object" && typeof primary !== "function") return;
	try {
		const target = primary;
		const suppressed = Array.isArray(target.suppressed) ? target.suppressed : [];
		suppressed.push(cleanup);
		if (target.suppressed !== suppressed) Object.defineProperty(target, "suppressed", {
			configurable: true,
			value: suppressed
		});
	} catch {}
}
//#endregion
//#region packages/core/dist/client/keys.js
/** Creates a context token; global tokens use Symbol.for so separate bundles can share identity. */
function createContext(description, options = false) {
	const global = typeof options === "boolean" ? options : options.global ?? false;
	const reactive = typeof options === "boolean" ? true : options.reactive ?? true;
	return {
		id: global ? Symbol.for(`exact.context:${description}`) : Symbol(description),
		description,
		global,
		reactive,
		keep: typeof options === "boolean" ? void 0 : options.keep,
		scope: typeof options === "boolean" ? "component" : options.scope ?? "component"
	};
}
//#endregion
//#region packages/core/dist/client/component/authorization.js
/** Validates the compact, provenance-free authorization identity allowed at runtime. */
function isExactComponentAuthorizationIdentity(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	const record = value;
	return Object.keys(record).every((key) => [
		"protocol",
		"buildKey",
		"fingerprint"
	].includes(key)) && record.protocol === 1 && typeof record.buildKey === "string" && record.buildKey.length > 0 && record.buildKey.length <= 256 && typeof record.fingerprint === "string" && record.fingerprint.length > 0 && record.fingerprint.length <= 256 && /^[A-Za-z0-9_-]+$/.test(record.fingerprint);
}
/** Requires two coordinated runtime artifacts to carry the same authorization decision. */
function sameExactComponentAuthorization(left, right) {
	return left.protocol === right.protocol && left.buildKey === right.buildKey && left.fingerprint === right.fingerprint;
}
//#endregion
//#region packages/core/dist/client/tasks/observers.js
var taskObserverStack = [];
var retainedTaskObservers = /* @__PURE__ */ new WeakMap();
/** Returns the observer that currently owns work for a component. */
function taskObserverFor(instance) {
	return taskObserverStack[taskObserverStack.length - 1] ?? retainedTaskObservers.get(instance);
}
/** Registers promise settlement with the current component observer. */
function observeTaskPromise(promise, instance) {
	taskObserverFor(instance)?.register(promise, instance);
}
//#endregion
//#region packages/core/dist/client/component/async-value.js
/** Identifies values that participate in promise-style asynchronous settlement. */
function isPromiseLike$2(value) {
	return !!value && (typeof value === "object" || typeof value === "function") && typeof value.then === "function";
}
//#endregion
//#region packages/core/dist/client/component/contexts.js
/** Provides the canonical logger context value. */
var LoggerContext = createContext("exact.logger", true);
/** Provides the canonical error context value. */
var ErrorContext = createContext("exact.error", {
	global: true,
	reactive: false
});
/** Provides the canonical suspension context value. */
var SuspensionContext = createContext("exact.suspension", true);
createContext("exact.readiness", true);
//#endregion
//#region packages/core/dist/client/component/domain.js
var componentDomainRuntimeStateKey = Symbol.for("@exactjs/component-domain.runtime-state");
var componentDomainRuntimeState = (() => {
	const scope = globalThis;
	return scope[componentDomainRuntimeStateKey] ??= {
		resumingDomains: /* @__PURE__ */ new WeakMap(),
		domainCapabilities: /* @__PURE__ */ new WeakMap(),
		wallClockUsedDomains: /* @__PURE__ */ new WeakSet()
	};
})();
var { domainCapabilities, resumingDomains, wallClockUsedDomains } = componentDomainRuntimeState;
var pageComponentDomainKey = Symbol.for("@exactjs/page-component-domain");
var sharedDomains = globalThis;
/** The default execution namespace for ordinary page-authored component instances. */
var pageComponentDomain = sharedDomains[pageComponentDomainKey] ??= constructComponentDomain({ executionRoot: "page" });
/** Creates immutable ownership metadata carried by operations and component instances. */
function createComponentDomain(options) {
	return constructComponentDomain(options);
}
/** Creates a component domain with capabilities reserved for framework packages. */
function createFrameworkComponentDomain(options) {
	const domain = constructComponentDomain(options);
	const logging = Object.prototype.hasOwnProperty.call(options, "logger") ? {
		logger: options.logger,
		componentOverride: false
	} : void 0;
	const capabilities = Object.freeze({
		target: options.target ? options.target : void 0,
		dispatchContinuation: options.dispatchContinuation ? options.dispatchContinuation : void 0,
		resumeComponent: options.resumeComponent ? options.resumeComponent : void 0,
		inspection: options.inspection ? options.inspection : void 0,
		inspectionActivation: options.inspectionActivation ? options.inspectionActivation : void 0,
		wallClockSnapshot: options.wallClockSnapshot !== void 0 ? options.wallClockSnapshot : void 0,
		logging
	});
	domainCapabilities.set(domain, capabilities);
	return domain;
}
/** Resolves the shared logger lane for a framework-owned root. */
function componentDomainLogging(domain) {
	return domainCapabilities.get(domain)?.logging;
}
/** Returns the inspection owner attached by a framework rendering boundary. */
function componentDomainInspection(domain) {
	return domainCapabilities.get(domain)?.inspection;
}
/** Returns the resumption source attached by a framework hydration boundary. */
function componentDomainResumption(domain) {
	return domainCapabilities.get(domain)?.resumeComponent;
}
/** Reports whether a framework domain activated its root through hydration. */
function isHydrationComponentDomain(domain) {
	return domainCapabilities.get(domain)?.inspectionActivation === "hydration";
}
function constructComponentDomain(options) {
	if (!options.executionRoot) throw new Error("Component execution root must be a non-empty string");
	return Object.freeze({ executionRoot: options.executionRoot });
}
/** Runs synchronous operation creation with an explicit immutable component domain. */
function withComponentDomain(domain, work) {
	const previous = componentDomainRuntimeState.activeDomain;
	componentDomainRuntimeState.activeDomain = domain;
	try {
		return work();
	} finally {
		componentDomainRuntimeState.activeDomain = previous;
	}
}
/** Runs an existing operation under one component domain and reactive ownership scope. */
function callWithComponentDomainInEffectScope(domain, scope, work) {
	const previous = componentDomainRuntimeState.activeDomain;
	componentDomainRuntimeState.activeDomain = domain;
	try {
		return withEffectScope(scope, work);
	} finally {
		componentDomainRuntimeState.activeDomain = previous;
	}
}
/** Runs component construction with permission to consume this domain's SSR activation. */
function withComponentResumption(domain, work) {
	const depth = resumingDomains.get(domain) ?? 0;
	resumingDomains.set(domain, depth + 1);
	try {
		return work();
	} finally {
		if (depth === 0) resumingDomains.delete(domain);
		else resumingDomains.set(domain, depth);
	}
}
/** Resolves SSR state only for construction explicitly authorized by an adoption boundary. */
function resolveComponentResumption(domain, type) {
	return resumingDomains.has(domain) ? domainCapabilities.get(domain)?.resumeComponent?.(type) : void 0;
}
/** Returns the domain currently responsible for authored operation creation. */
function currentComponentDomain() {
	return componentDomainRuntimeState.activeDomain;
}
//#endregion
//#region packages/core/dist/client/logging.js
var logLevelOrder = {
	trace: 0,
	debug: 1,
	info: 2,
	warn: 3,
	error: 4
};
/** Creates a logger implementation that writes formatted eXact events to the console. */
function createConsoleLogger(options = {}) {
	const minimumLevel = options.level ?? "info";
	return {
		isEnabled(level) {
			return logLevelOrder[level] >= logLevelOrder[minimumLevel];
		},
		log(event) {
			const prefix = `${formatLogScope(event.scope)} ${event.message}`;
			const consoleMethod = getConsoleMethod(event.level);
			if (event.error !== void 0 && event.data !== void 0) consoleMethod(prefix, event.error, event.data);
			else if (event.error !== void 0) consoleMethod(prefix, event.error);
			else if (event.data !== void 0) consoleMethod(prefix, event.data);
			else consoleMethod(prefix);
		}
	};
}
/** Formats a structured log scope into the compact prefix used by framework logs. */
function formatLogScope(scope) {
	if (scope.source === "component" && scope.component) return `[exact] [component:${scope.component.name}#${scope.component.id}]`;
	return `[exact] [${[
		"framework",
		scope.packageName,
		scope.category
	].filter(Boolean).join(":")}]`;
}
function getConsoleMethod(level) {
	if (level === "trace") return console.trace?.bind(console) ?? console.debug.bind(console);
	if (level === "debug") return console.debug.bind(console);
	if (level === "info") return console.info.bind(console);
	if (level === "warn") return console.warn.bind(console);
	return console.error.bind(console);
}
//#endregion
//#region packages/core/dist/client/component/default-logger.js
/** Provides the canonical default console logger without linking component logging machinery. */
var defaultConsoleLogger = createConsoleLogger();
//#endregion
//#region packages/core/dist/client/component/log.js
/** Emits a framework-scoped log event through the supplied or default logger. */
function logFrameworkEvent(level, packageName, category, message, data, logger = defaultConsoleLogger) {
	const scope = {
		source: "framework",
		packageName,
		category
	};
	if (!isLogEnabled(logger, level, scope)) return;
	emitLogEvent(logger, {
		level,
		message: evaluateLogValue(message),
		data: data === void 0 ? void 0 : evaluateLogValue(data),
		scope
	});
}
/**
* Resolves an enabled component-log method without evaluating authored log arguments.
* The result is intentionally decided at call time so a running application can change
* logger contexts or enabled levels without rebuilding its artifact.
*/
function componentLogMethod(instance, level) {
	return prepareComponentLogMethod(instance, level);
}
/** Prepares one shared compiled/runtime logging operation for a specific component instance. */
function prepareComponentLogMethod(instance, level, cachedScope) {
	const logger = resolveLogger(instance);
	if (logger === defaultConsoleLogger && !isLogEnabled(logger, level, defaultComponentEnablementScope)) return void 0;
	const scope = cachedScope ?? componentLogScope(instance);
	if (scope.component) scope.component.mounted = instance.mounted;
	if (logger !== defaultConsoleLogger && !isLogEnabled(logger, level, scope)) return void 0;
	return (readArguments) => {
		peek(() => {
			const [message, errorOrData, data] = readArguments();
			emitPreparedComponentLog(logger, scope, level, message, errorOrData, data);
		});
	};
}
var defaultComponentEnablementScope = Object.freeze({ source: "component" });
function emitPreparedComponentLog(logger, scope, level, message, errorOrData, data) {
	const evaluatedMessage = evaluateLogValue(message);
	let evaluatedError;
	let evaluatedData;
	if (level === "error" && data !== void 0) {
		evaluatedError = evaluateLogValue(errorOrData);
		evaluatedData = evaluateLogValue(data);
	} else if (level === "error" && errorOrData !== void 0) {
		const value = evaluateLogValue(errorOrData);
		if (isErrorLike(value)) evaluatedError = value;
		else evaluatedData = value;
	} else if (errorOrData !== void 0) evaluatedData = evaluateLogValue(errorOrData);
	emitLogEvent(logger, {
		level,
		message: evaluatedMessage,
		error: evaluatedError,
		data: evaluatedData,
		scope
	});
}
function isLogEnabled(logger, level, scope) {
	try {
		return !logger.isEnabled || logger.isEnabled(level, scope);
	} catch (error) {
		reportLoggerFailure(error);
		return false;
	}
}
function emitLogEvent(logger, event) {
	try {
		logger.log(event);
	} catch (error) {
		reportLoggerFailure(error);
	}
}
function reportLoggerFailure(error) {
	try {
		defaultConsoleLogger.log({
			level: "error",
			message: "logger failed while handling eXact log event",
			error,
			scope: {
				source: "framework",
				packageName: "core",
				category: "logger"
			}
		});
	} catch {}
}
function resolveLogger(instance) {
	const shared = componentDomainLogging(instance.domain);
	if (shared && !shared.componentOverride) return shared.logger ?? defaultConsoleLogger;
	let cursor = instance.parent;
	while (cursor) {
		if (cursor.contexts.has(LoggerContext.id)) return unwrap(cursor.contexts.get(LoggerContext.id));
		cursor = cursor.parent;
	}
	if (instance.ambientContexts?.has(LoggerContext.id)) return unwrap(instance.ambientContexts.get(LoggerContext.id));
	return defaultConsoleLogger;
}
/** Performs the component log scope domain operation. */
function componentLogScope(instance) {
	return {
		source: "component",
		component: {
			id: instance.id,
			name: instance.type.name || "anonymous",
			mounted: instance.mounted
		}
	};
}
function evaluateLogValue(value) {
	return typeof value === "function" ? value() : value;
}
function isErrorLike(value) {
	return value instanceof Error;
}
/** Reports whether error report. */
function isErrorReport(value) {
	return !!value && typeof value === "object" && "id" in value && "error" in value && "source" in value;
}
/** Performs the format error domain operation. */
function formatError(error) {
	if (error instanceof Error) return error.stack ?? error.message;
	return String(error);
}
//#endregion
//#region packages/core/dist/client/render-children.js
/** Flattens nested compiler-produced child arrays without assigning renderer topology. */
function normalizeChildren(children) {
	const normalized = [];
	for (const child of children) if (Array.isArray(child)) normalized.push(...normalizeChildren(child));
	else normalized.push(child);
	return normalized;
}
/** Normalizes one component output into its owned child sequence. */
function normalizeRenderResult(result) {
	if (!Array.isArray(result)) return [result];
	for (const child of result) if (Array.isArray(child)) return normalizeChildren(result);
	return result;
}
//#endregion
//#region packages/core/dist/client/component-abi/opaque-operation.js
/** Realm-stable identity marker for compiler-issued operations with WeakMap-private contents. */
var exactOpaqueOperationIdentity = Symbol.for("@exactjs/opaque-target-operation");
var exactOpaqueOperationExecution = Symbol.for("@exactjs/opaque-target-operation-execution");
var exactOpaqueOperationMetadata = Symbol.for("@exactjs/opaque-target-operation-metadata");
/** Returns one private redemption table shared by every copy of the core runtime in this realm. */
function sharedOpaqueOperationStore(name) {
	const key = Symbol.for(`@exactjs/opaque-target-operation-store/${name}`);
	const scope = globalThis;
	const existing = scope[key];
	if (existing instanceof WeakMap) return existing;
	const store = /* @__PURE__ */ new WeakMap();
	scope[key] = store;
	return store;
}
/** Allocates an immutable identity whose contents remain private to its issuing target protocol. */
function createOpaqueOperation(execute, metadata) {
	const operation = Object.defineProperty({}, exactOpaqueOperationIdentity, { value: true });
	if (execute) Object.defineProperty(operation, exactOpaqueOperationExecution, { value: execute });
	if (metadata && (metadata.key !== void 0 || metadata.domain !== void 0)) Object.defineProperty(operation, exactOpaqueOperationMetadata, { value: Object.freeze({ ...metadata }) });
	return Object.freeze(operation);
}
/** Reports whether a value is a compiler-issued operation without redeeming its private payload. */
function isOpaqueOperation(value) {
	return typeof value === "object" && value !== null && value[exactOpaqueOperationIdentity] === true;
}
/** Reads authored sibling identity without exposing an operation kind or target-local topology. */
function opaqueOperationKey(value) {
	return isOpaqueOperation(value) ? value[exactOpaqueOperationMetadata]?.key : void 0;
}
/** Reads component-domain ownership without exposing an operation kind or target-local topology. */
function opaqueOperationDomain(value) {
	return isOpaqueOperation(value) ? value[exactOpaqueOperationMetadata]?.domain : void 0;
}
/** Invokes one compiler-issued operation without reading a kind, payload, or child topology. */
function executeOpaqueOperation(value, target) {
	if (typeof value !== "object" || value === null) return void 0;
	const execute = value[exactOpaqueOperationExecution];
	return typeof execute === "function" ? { value: Reflect.apply(execute, value, [target]) } : void 0;
}
//#endregion
//#region packages/core/dist/client/component-abi/intrinsic-receipt.js
var intrinsics = sharedOpaqueOperationStore("intrinsic");
/** Dispatch key implemented by render targets that accept intrinsic operations. */
var exactIntrinsicOperation = Symbol.for("@exactjs/target-operation/intrinsic");
function executeIntrinsicOperation(target) {
	const data = intrinsics.get(this);
	if (!data) throw new TypeError("Intrinsic operation lost its compiler-issued payload");
	return target[exactIntrinsicOperation](this, data);
}
/** Issues a direct intrinsic operation. */
function createCompiledIntrinsicReceipt(tag, props, ...children) {
	if (typeof tag !== "string") throw new TypeError("Compiled intrinsic receipt requires an intrinsic tag");
	const { key: authoredKey, __exactEnhancements: enhancement, ...intrinsicProps } = props ?? {};
	const rawKey = unwrap(authoredKey);
	const domain = currentComponentDomain();
	const key = rawKey === null || rawKey === void 0 ? void 0 : String(rawKey);
	const receipt = createOpaqueOperation(executeIntrinsicOperation, {
		...key === void 0 ? {} : { key },
		...domain ? { domain } : {}
	});
	intrinsics.set(receipt, {
		tag,
		props: intrinsicProps,
		children: normalizeRenderResult(children),
		...key === void 0 ? {} : { key },
		...domain ? { domain } : {},
		...enhancement ? { enhancement } : {}
	});
	return receipt;
}
/** Reads only compiler-issued intrinsic operations. */
function readCompiledIntrinsicReceipt(value) {
	return typeof value === "object" && value !== null ? intrinsics.get(value) : void 0;
}
//#endregion
//#region packages/core/dist/client/component/error-view.js
/** Creates the common framework error report list with caller-owned optional actions. */
function createDefaultErrorView(errors, options = {}) {
	return createCompiledIntrinsicReceipt("section", {
		role: "alert",
		className: "exact-error-boundary"
	}, createCompiledIntrinsicReceipt("h1", null, "Application error"), ...Array.from(errors, (error) => createCompiledIntrinsicReceipt("article", {
		key: error.id,
		className: "exact-error"
	}, createCompiledIntrinsicReceipt("h2", null, error.component?.name ?? options.componentFallback ?? "Framework"), createCompiledIntrinsicReceipt("p", null, `${error.source}${error.phase ? `:${error.phase}` : ""}`), createCompiledIntrinsicReceipt("pre", null, formatError(error.error)))), ...options.actions ?? []);
}
//#endregion
//#region packages/core/dist/client/component/errors.js
var nextErrorId = 1;
/** Creates the default reactive error context used by app and framework error boundaries. */
function createErrorContext(errors = []) {
	return createErrorContextWithLimit(errors);
}
function createErrorContextWithLimit(errors, maxReports) {
	const reactiveErrors = reactiveObjects(errors);
	return {
		errors: reactiveErrors,
		report(error, options) {
			const report = isErrorReport(error) ? error : createErrorReportFromOptions(error, options);
			batch(() => {
				reactiveErrors.push(report);
				if (maxReports !== void 0 && reactiveErrors.length > maxReports) reactiveErrors.splice(0, reactiveErrors.length - maxReports);
			});
			return report;
		},
		clear(error) {
			const id = typeof error === "string" ? error : error.id;
			const index = reactiveErrors.findIndex((item) => item.id === id);
			if (index >= 0) reactiveErrors.splice(index, 1);
		},
		clearAll() {
			reactiveErrors.splice(0, reactiveErrors.length);
		}
	};
}
/** Creates a structured error report for component or framework failures. */
function createErrorReport(error, source, component, phase) {
	return {
		id: `e${nextErrorId++}`,
		error,
		source,
		component: component ? componentLogScope(component).component : void 0,
		phase
	};
}
function createErrorReportFromOptions(error, options = {}) {
	return {
		id: `e${nextErrorId++}`,
		error,
		source: options.source ?? "component",
		component: options.component,
		phase: options.phase
	};
}
/** Routes a component error to the nearest error context or installs the default fallback view. */
function handleComponentError(instance, event, errorOwner = instance) {
	let cursor = instance;
	while (cursor) {
		if (cursor.contexts.has(ErrorContext.id)) {
			const context = unwrap(cursor.contexts.get(ErrorContext.id));
			if (context.boundary === errorOwner) {
				cursor = cursor.parent;
				continue;
			}
			context.report(event);
			(context.boundary ?? cursor).invalidate?.();
			return;
		}
		cursor = cursor.parent;
	}
	const ambient = instance?.ambientContexts?.get(ErrorContext.id);
	if (ambient) {
		const context = unwrap(ambient);
		if (context.boundary !== errorOwner) {
			context.report(event);
			if (instance) componentLogMethod(instance, "error")?.(() => [
				"root error context handled failure",
				event.error,
				{
					source: event.source,
					phase: event.phase,
					component: event.component
				}
			]);
			return;
		}
	}
	const context = defaultErrorContext;
	context.report(event);
	const fallback = () => createDefaultErrorView(context.errors);
	if (instance) {
		instance.errorFallback = fallback;
		instance.invalidate?.();
		componentLogMethod(instance, "error")?.(() => [
			"root error context handled failure",
			event.error,
			{
				source: event.source,
				phase: event.phase,
				component: event.component
			}
		]);
	} else logFrameworkEvent("error", "core", event.source, "root error context handled failure", {
		phase: event.phase,
		component: event.component
	});
	return fallback;
}
/** Routes a thrown promise to the nearest async rendering boundary. */
function handleComponentSuspension(instance, promise) {
	return registerComponentSuspension(instance, promise) !== false;
}
/** Registers a thrown promise and exposes renderer-owned cancellation when the boundary supports it. */
function registerComponentSuspension(instance, promise) {
	let cursor = instance;
	while (cursor) {
		if (cursor.contexts.has(SuspensionContext.id)) return unwrap(cursor.contexts.get(SuspensionContext.id)).suspend(promise) ?? true;
		cursor = cursor.parent;
	}
	return false;
}
/** Provides the canonical default error context value. */
var defaultErrorContext = /* @__PURE__ */ createErrorContextWithLimit([], 100);
//#endregion
//#region packages/core/dist/client/tasks/cancellation.js
/** Framework cancellation raised when a task generation loses ownership. */
var TaskCancellation = class extends Error {
	reason;
	/** Creates a cancellation result that is excluded from application task error state. */
	constructor(reason) {
		super(reason === void 0 ? "Component task was cancelled" : String(reason));
		this.name = "AbortError";
		this.reason = reason;
	}
};
/** Reports whether a rejected value represents framework task cancellation. */
function isTaskCancellation(error) {
	return error instanceof TaskCancellation;
}
/** Rejects promptly when task ownership is cancelled without cancelling the source promise. */
function raceTaskCancellation(signal, settlement) {
	if (signal.aborted) {
		Promise.resolve(settlement).catch(() => void 0);
		return Promise.reject(new TaskCancellation(signal.reason));
	}
	return new Promise((resolve, reject) => {
		const cancel = () => reject(new TaskCancellation(signal.reason));
		signal.addEventListener("abort", cancel, { once: true });
		Promise.resolve(settlement).then((value) => {
			signal.removeEventListener("abort", cancel);
			resolve(value);
		}, (error) => {
			signal.removeEventListener("abort", cancel);
			reject(error);
		});
	});
}
//#endregion
//#region packages/core/dist/client/component/async.js
/** Performs the observe lifecycle promise domain operation. */
function observeLifecyclePromise(instance, promise, phase) {
	observeTaskPromise(Promise.resolve(promise).catch((error) => {
		handleComponentError(instance, createErrorReport(error, "lifecycle", instance, phase));
	}), instance);
}
/** Observes asynchronous component work so renderers and test harnesses can await it and route failures. */
function observeComponentAsync(instance, value, source, phase) {
	if (!isPromiseLike$2(value)) return;
	const observed = Promise.resolve(value).catch((error) => {
		if (isTaskCancellation(error)) return;
		handleComponentError(instance, createErrorReport(error, source, instance, phase));
	});
	if (instance) observeTaskPromise(observed, instance);
}
//#endregion
//#region packages/core/dist/client/component/performance-trace.js
/**
* Begins a component performance span only when trace logging is currently enabled.
* Disabled tracing performs no timestamp read and allocates no span or log arguments.
*/
function componentTraceStarter(instance) {
	const trace = componentLogMethod(instance, "trace");
	if (!trace) return void 0;
	return (operation, operationId, attributes) => {
		const span = Object.freeze({
			operation,
			operationId,
			startedAt: traceTimestamp()
		});
		trace(() => [`performance ${operation} started`, {
			operation,
			operationId,
			phase: "started",
			elapsedMs: 0,
			...attributes ? { attributes } : {}
		}]);
		return span;
	};
}
/** Emits one runtime-rechecked timing mark for an enabled component trace span. */
function markComponentTrace(instance, span, phase, attributes) {
	if (!span) return;
	componentLogMethod(instance, "trace")?.(() => [`performance ${span.operation} ${phase}`, {
		operation: span.operation,
		operationId: span.operationId,
		phase,
		elapsedMs: traceTimestamp() - span.startedAt,
		...attributes ? { attributes: typeof attributes === "function" ? attributes() : attributes } : {}
	}]);
}
function traceTimestamp() {
	return globalThis.performance?.now() ?? Date.now();
}
//#endregion
//#region packages/core/dist/client/tasks/frame-continuation.js
var framesBySignal = /* @__PURE__ */ new WeakMap();
/** Associates a frame signal with the frame restored after compiler-lowered awaits. */
function registerTaskFrameSignal(signal, frame) {
	framesBySignal.set(signal, frame);
}
/** Releases continuation restoration state when its frame settles. */
function releaseTaskFrameSignal(signal) {
	framesBySignal.delete(signal);
}
//#endregion
//#region packages/core/dist/client/tasks/frame-context.js
var contextFrames = /* @__PURE__ */ new WeakMap();
/** Creates and retains the public context owned by one task frame. */
function createTaskFrameContext(frame, options) {
	const context = {
		signal: frame.controller.signal,
		generation: options.generation ?? 1,
		activation: options.activation ?? "invoked",
		peek,
		optimistic: options.optimistic ?? (() => {
			throw new Error("Optimistic state is not available for this task activation");
		}),
		cleanup(cleanup) {
			if (frame.settled || !frame.producerOpen) throw new Error("Cannot register cleanup after the task producer has closed");
			(frame.cleanups ??= []).push(cleanup);
		},
		own(resource) {
			context.cleanup(async () => {
				if (Symbol.asyncDispose in resource) await resource[Symbol.asyncDispose]();
				else resource[Symbol.dispose]();
			});
			return resource;
		}
	};
	contextFrames.set(context, frame);
	return context;
}
//#endregion
//#region packages/core/dist/client/tasks/frame-inspection-capability.js
var capability$2;
/** Publishes through the optional diagnostic capability without retaining its implementation. */
function publishTaskFrameEvent(frame, kind, reason, observation) {
	capability$2?.publish(frame, kind, reason, observation);
}
/** Reports attachment without loading task snapshot and preview machinery in production builds. */
function taskFrameInspectionAttached(frame) {
	return capability$2?.attached(frame) ?? false;
}
//#endregion
//#region packages/core/dist/client/tasks/frame-settlement.js
var frameSettlements = /* @__PURE__ */ new WeakMap();
/** Associates a task frame with the promise representing its structural settlement. */
function registerTaskFrameSettlement(frame, settlement) {
	frameSettlements.set(frame, settlement);
}
/** Returns the structural settlement promise retained for a task frame. */
function waitForTaskFrameSettlement(frame) {
	return frameSettlements.get(frame) ?? Promise.resolve();
}
/**
* Waits for every attached descendant, including children transferred from an
* atomic reservation, then reports the first structural failure.
*/
async function settleTaskFrameChildren(frame) {
	let primary;
	let failed = false;
	while (frame.children?.size) {
		const results = await Promise.allSettled([...frame.children]);
		for (const result of results) {
			if (result.status === "fulfilled" || failed) continue;
			primary = result.reason;
			failed = true;
		}
	}
	if (failed) throw primary;
}
/** Runs frame-owned cleanup in last-in-first-out order and reports its first failure. */
async function runTaskFrameCleanups(frame) {
	let primary;
	for (const cleanup of frame.cleanups?.reverse() ?? []) try {
		await cleanup();
	} catch (error) {
		primary ??= error;
	}
	if (primary !== void 0) throw primary;
}
//#endregion
//#region packages/core/dist/client/tasks/frame-contracts.js
/** Brands internal task frame records without exposing their representation publicly. */
var taskFrameTokenBrand = Symbol("exact.task-frame-token");
/** Brands durable task owners shared by compiler-authored and explicit runtime tasks. */
var taskOwnerBrand = Symbol.for("@exactjs/task-owner");
//#endregion
//#region packages/core/dist/client/tasks/owner-record.js
var TaskOwnerRecordImpl = class {
	[taskOwnerBrand] = true;
	label;
	host;
	observeSettlement;
	registerReadiness;
	activationsDeferred = false;
	disposed = false;
	controllerValue;
	framesValue;
	settlementsValue;
	ownerCleanupsValue;
	activationRegistrationsValue;
	constructor(label) {
		this.label = label;
	}
	get controller() {
		if (!this.controllerValue) {
			this.controllerValue = new AbortController();
			if (this.disposed) this.controllerValue.abort("task-owner-disposed");
		}
		return this.controllerValue;
	}
	get signal() {
		return this.controller.signal;
	}
	get frames() {
		return this.framesValue ??= /* @__PURE__ */ new Set();
	}
	get settlements() {
		return this.settlementsValue ??= /* @__PURE__ */ new Set();
	}
	get ownerCleanups() {
		return this.ownerCleanupsValue ??= /* @__PURE__ */ new Set();
	}
	get activationRegistrations() {
		return this.activationRegistrationsValue ??= /* @__PURE__ */ new Set();
	}
	async [Symbol.asyncDispose]() {
		if (this.disposed) return;
		this.disposed = true;
		this.controllerValue?.abort("task-owner-disposed");
		for (const frame of this.framesValue ?? []) frame.controller.abort("task-owner-disposed");
		for (const cleanup of [...this.ownerCleanupsValue ?? []].reverse()) await cleanup();
		this.ownerCleanupsValue?.clear();
		await Promise.allSettled([...[...this.framesValue ?? []].map(waitForTaskFrameSettlement), ...this.settlementsValue ?? []]);
	}
};
/** Creates a task owner whose cancellation and collection storage is materialized on first use. */
function createLazyTaskOwnerRecord(label) {
	return new TaskOwnerRecordImpl(label);
}
//#endregion
//#region packages/core/dist/client/tasks/scheduled-reactions.js
var scheduledReactionBatches = /* @__PURE__ */ new WeakMap();
/** Acquires one lease on the consequence frame shared by a task invalidation wave. */
function acquireScheduledReactionBatch(parent) {
	let batch = scheduledReactionBatches.get(parent);
	if (!batch || batch.closed) {
		batch = createScheduledReactionBatch(parent);
		scheduledReactionBatches.set(parent, batch);
	}
	batch.pending++;
	let released = false;
	const release = (error, failed = false) => {
		if (released) return;
		released = true;
		if (failed && !batch.failed) {
			batch.failed = true;
			batch.failure = error;
		}
		if (--batch.pending !== 0) return;
		batch.closed = true;
		if (scheduledReactionBatches.get(parent) === batch) scheduledReactionBatches.delete(parent);
		if (batch.failed) batch.reject(batch.failure);
		else batch.resolve();
	};
	return {
		run(work) {
			if (released) return;
			try {
				if (batch.signal.aborted) throw new TaskCancellation(batch.signal.reason);
				withTaskFrameRecord(batch.frame, work);
			} catch (error) {
				release(error, true);
				throw error;
			}
			release();
		},
		cancel: release
	};
}
function createScheduledReactionBatch(parent) {
	return taskFrameInspectionAttached(parent) ? createInspectedScheduledReactionBatch(parent) : createInlineScheduledReactionBatch(parent);
}
/** Attaches one completion lease without a complete public task frame. */
function createInlineScheduledReactionBatch(parent) {
	let controller;
	let acceptCompletion;
	let rejectCompletion;
	const completion = new Promise((accept, fail) => {
		acceptCompletion = accept;
		rejectCompletion = fail;
	});
	const frame = {
		[taskFrameTokenBrand]: true,
		id: allocateTaskFrameId(),
		owner: parent.owner,
		parent,
		get controller() {
			if (!controller) {
				controller = new AbortController();
				linkAbort$1(parent.controller.signal, controller);
			}
			return controller;
		},
		kind: "reactive",
		label: "reactive consequences",
		activation: parent.activation,
		generation: parent.generation,
		placement: parent.placement,
		concurrency: parent.concurrency,
		priority: parent.priority,
		readiness: parent.readiness,
		startedAt: monotonicTimestamp$1(),
		producerOpen: true,
		settled: false
	};
	attachTaskFrameSettlement(parent, completion);
	return {
		frame,
		signal: parent.controller.signal,
		resolve() {
			frame.producerOpen = false;
			settleTaskFrameChildren(frame).then(() => finishInlineFrame(frame, acceptCompletion), (error) => finishInlineFrame(frame, () => rejectCompletion(error)));
		},
		reject(error) {
			frame.producerOpen = false;
			controller?.abort(error);
			const finish = () => finishInlineFrame(frame, () => rejectCompletion(error));
			settleTaskFrameChildren(frame).then(finish, finish);
		},
		pending: 0,
		failed: false,
		closed: false
	};
}
function finishInlineFrame(frame, settle) {
	frame.settled = true;
	settle();
}
/** Retains the complete consequence projection while DevTools inspection is attached. */
function createInspectedScheduledReactionBatch(parent) {
	let resolve;
	let reject;
	const completion = new Promise((accept, fail) => {
		resolve = accept;
		reject = fail;
	});
	let frame;
	executeTaskFrame({
		parent,
		owner: parent.owner,
		activation: parent.activation,
		kind: "reactive",
		label: "reactive consequences",
		publicContext: false
	}, () => {
		frame = currentTaskFrameRecord();
		return completion;
	}).catch(() => void 0);
	return {
		frame,
		signal: frame.controller.signal,
		resolve,
		reject,
		pending: 0,
		failed: false,
		closed: false
	};
}
function linkAbort$1(signal, target) {
	if (signal.aborted) target.abort(signal.reason);
	else signal.addEventListener("abort", () => target.abort(signal.reason), { once: true });
}
function monotonicTimestamp$1() {
	return globalThis.performance?.now() ?? Date.now();
}
//#endregion
//#region packages/core/dist/client/tasks/frame-runtime.js
var nextFrameId = 1;
var currentFrame;
var deferredFrameMaterializer;
var scheduledWorkCaptureInstalled = false;
var synchronousFrameErrors = /* @__PURE__ */ new WeakMap();
/** Creates a durable task owner and its cancellation lifetime. */
function createTaskOwnerRecord(label) {
	return createLazyTaskOwnerRecord(label);
}
/** Returns the frame active for the current synchronous execution segment. */
function currentTaskFrameRecord() {
	return currentFrame;
}
/** Installs the lazy structural parent available to task and navigation operations during work. */
function withDeferredTaskFrame(materialize, work) {
	const previous = deferredFrameMaterializer;
	deferredFrameMaterializer = materialize;
	try {
		return work();
	} finally {
		deferredFrameMaterializer = previous;
	}
}
/** Runs a synchronous segment with one frame as ambient context. */
function withTaskFrameRecord(frame, work) {
	if (frame.settled) throw new Error("Cannot resume a settled task frame");
	ensureScheduledWorkContextCapture();
	const previous = currentFrame;
	currentFrame = frame;
	try {
		return work();
	} finally {
		currentFrame = previous;
	}
}
/**
* Runs work in a frame, then waits for dynamically attached descendants and
* executes cleanup in last-in-first-out order.
*/
function executeTaskFrame(options, work) {
	const structuralParent = options.detached ? void 0 : options.parent ?? currentFrame;
	if (structuralParent && !options.parentReserved && (!structuralParent.producerOpen || structuralParent.settled)) return Promise.reject(/* @__PURE__ */ new Error("Cannot attach work after the parent task producer has closed"));
	const owner = options.owner ?? structuralParent?.owner ?? createTaskOwnerRecord("implicit task invocation");
	if (owner.disposed) return Promise.reject(/* @__PURE__ */ new Error("Task owner has been disposed"));
	const controller = options.controller ?? new AbortController();
	if (structuralParent) linkAbort(structuralParent.controller.signal, controller);
	let resolveSettlement;
	let rejectSettlement;
	const settlement = new Promise((resolve, reject) => {
		resolveSettlement = resolve;
		rejectSettlement = reject;
	});
	const frame = {
		[taskFrameTokenBrand]: true,
		id: nextFrameId++,
		owner,
		parent: structuralParent,
		controller,
		...options.label === void 0 ? {} : { label: options.label },
		...options.sourceEntityId === void 0 ? {} : { sourceEntityId: options.sourceEntityId },
		activation: options.activation ?? "invoked",
		generation: options.generation ?? 1,
		placement: options.placement ?? "current",
		concurrency: options.concurrency ?? "parallel",
		priority: options.priority ?? structuralParent?.priority ?? "normal",
		readiness: options.readiness ?? (options.priority === "deferred" ? "nonblocking" : structuralParent?.readiness ?? "blocking"),
		kind: options.kind ?? "task",
		producerOpen: true,
		settled: false,
		startedAt: monotonicTimestamp()
	};
	if (options.publicContext !== false) frame.context = createTaskFrameContext(frame, options);
	registerTaskFrameSignal(controller.signal, frame);
	registerTaskFrameSettlement(frame, settlement);
	owner.frames.add(frame);
	if (taskFrameInspectionAttached(frame)) {
		publishTaskFrameEvent(frame, "task.frame.enter");
		publishTaskFrameEvent(frame, "task.start", void 0, {
			kind: "start",
			arguments: options.inspectionArguments
		});
	} else uninspectedSynchronousFrames.add(frame);
	if (structuralParent) {
		(structuralParent.children ??= /* @__PURE__ */ new Set()).add(settlement);
		settlement.finally(() => structuralParent.children?.delete(settlement)).catch(() => void 0);
	} else settlement.catch(() => void 0);
	let directResult;
	let synchronousError;
	try {
		if (controller.signal.aborted) throw new TaskCancellation(controller.signal.reason);
		directResult = withTaskFrameRecord(frame, () => work(frame.context));
	} catch (error) {
		synchronousError = error;
		directResult = Promise.reject(error);
	} finally {
		uninspectedSynchronousFrames.delete(frame);
	}
	const output = raceTaskCancellation(controller.signal, directResult).then(async (value) => {
		frame.producerOpen = false;
		publishTaskFrameEvent(frame, "task.foreground-settle");
		let structuralError;
		let structuralFailed = false;
		try {
			await settleTaskFrameChildren(frame);
		} catch (error) {
			structuralError = error;
			structuralFailed = true;
		}
		try {
			await runTaskFrameCleanups(frame);
		} catch (cleanupError) {
			if (!structuralFailed) throw cleanupError;
			if (structuralError && typeof structuralError === "object") Object.defineProperty(structuralError, "suppressed", {
				configurable: true,
				value: [cleanupError]
			});
		}
		if (controller.signal.aborted) throw new TaskCancellation(controller.signal.reason);
		if (structuralFailed) throw structuralError;
		return value;
	}, async (error) => {
		const outcomeError = controller.signal.aborted && !(error instanceof TaskCancellation) ? new TaskCancellation(controller.signal.reason) : error;
		frame.producerOpen = false;
		publishTaskFrameEvent(frame, "task.foreground-settle");
		controller.abort(error);
		let childError;
		let childFailed = false;
		try {
			await settleTaskFrameChildren(frame);
		} catch (error) {
			childError = error;
			childFailed = true;
		}
		try {
			await runTaskFrameCleanups(frame);
		} catch (cleanupError) {
			if (outcomeError && typeof outcomeError === "object") Object.defineProperty(outcomeError, "suppressed", {
				configurable: true,
				value: [cleanupError]
			});
		}
		if (outcomeError === void 0 && childFailed) throw childError;
		throw outcomeError;
	}).then((value) => {
		frame.settled = true;
		releaseTaskFrameSignal(controller.signal);
		owner.frames.delete(frame);
		resolveSettlement();
		publishTaskFrameEvent(frame, "task.frame.exit");
		publishTaskFrameEvent(frame, "task.structural-settle");
		publishTaskFrameEvent(frame, "task.settle", void 0, {
			kind: "outcome",
			status: "settled",
			value
		});
		return value;
	}, (error) => {
		frame.settled = true;
		releaseTaskFrameSignal(controller.signal);
		owner.frames.delete(frame);
		if (options.propagateFailure?.() === false) resolveSettlement();
		else rejectSettlement(error);
		publishTaskFrameEvent(frame, "task.frame.exit");
		const cancelled = error instanceof TaskCancellation;
		publishTaskFrameEvent(frame, cancelled ? "task.cancel" : "task.fail", error, {
			kind: "outcome",
			status: cancelled ? "cancelled" : "failed",
			value: error
		});
		throw error;
	});
	if (synchronousError !== void 0) {
		synchronousFrameErrors.set(output, { error: synchronousError });
		output.catch(() => void 0);
	}
	return output;
}
/** Returns an error thrown before a task frame's producer yielded to asynchronous work. */
function taskFrameSynchronousError(execution) {
	return execution instanceof Promise ? synchronousFrameErrors.get(execution) : void 0;
}
/** Adds a structural contribution to a frame before its producer closes. */
function attachTaskFrameSettlement(frame, settlement) {
	if (frame.settled || !frame.producerOpen) throw new Error("Cannot attach work after the task frame producer has closed");
	const normalized = Promise.resolve(settlement).then(() => void 0);
	(frame.children ??= /* @__PURE__ */ new Set()).add(normalized);
	normalized.finally(() => frame.children?.delete(normalized)).catch(() => void 0);
}
var interactiveReactionContexts = /* @__PURE__ */ new WeakMap();
var uninspectedSynchronousFrames = /* @__PURE__ */ new WeakSet();
function linkAbort(signal, target) {
	if (signal.aborted) {
		target.abort(signal.reason);
		return;
	}
	signal.addEventListener("abort", () => target.abort(signal.reason), { once: true });
}
function monotonicTimestamp() {
	return globalThis.performance?.now() ?? Date.now();
}
/** Allocates one process-local frame identity for internal consequence frames. */
function allocateTaskFrameId() {
	return nextFrameId++;
}
function ensureScheduledWorkContextCapture() {
	if (scheduledWorkCaptureInstalled) return;
	scheduledWorkCaptureInstalled = true;
	setScheduledWorkContextCapture((priority) => {
		const parent = currentTaskFrameRecord();
		if (!parent || !parent.producerOpen || parent.settled) return void 0;
		if (priority === "interactive" && uninspectedSynchronousFrames.has(parent)) return interactiveReactionContext(parent);
		return acquireScheduledReactionBatch(parent);
	});
}
/** Reuses an open interaction producer for consequences drained inside the same DOM callback. */
function interactiveReactionContext(parent) {
	let context = interactiveReactionContexts.get(parent);
	if (context) return context;
	context = {
		run: (work) => withTaskFrameRecord(parent, work),
		cancel() {}
	};
	interactiveReactionContexts.set(parent, context);
	return context;
}
//#endregion
//#region packages/core/dist/client/tasks/owner-hosts.js
var taskOwnerHost = Symbol.for("@exactjs/task-owner-host");
/** Returns the durable task owner registered for a framework host. */
function taskOwnerForHost(host) {
	return host[taskOwnerHost];
}
//#endregion
//#region packages/core/dist/client/interaction/execution.js
var nextInteractionId = 1;
var interactionsByFrame = /* @__PURE__ */ new WeakMap();
var interactionTraces;
/** Reports whether a component already owns the durable task lane required by full interactions. */
function hasComponentTaskOwner(owner) {
	return taskOwnerForHost(owner) !== void 0;
}
/** Emits a correlated performance mark for a currently executing interaction. */
function traceInteractionPhase(interaction, phase, attributes) {
	if (!interaction) return;
	markComponentTrace(interaction.owner, interactionTraces?.get(interaction), phase, attributes);
}
/**
* Executes a component interaction as a task-frame root.
*
* The frame exclusively owns cancellation, descendants, cleanup, continuation restoration, and
* structural settlement. Interaction state exists only as inspection metadata associated with it.
*/
function runComponentInteraction(owner, source, generation, priority, controller, work) {
	return executeComponentInteraction(owner, source, generation, priority, controller, true, work);
}
/**
* Executes a compiler-owned DOM interaction without allocating diagnostic metadata when component
* tracing is disabled. Structural task parenting and settlement still use the canonical frame.
*/
function runCompiledComponentInteraction(owner, source, generation, priority, controller, work, onTraceScope, trace) {
	return executeComponentInteraction(owner, source, generation, priority, controller, false, work, onTraceScope, trace);
}
/**
* Executes a compiled interaction directly until task work requests a structural parent.
* Trace-enabled builds retain the complete observable interaction contract from the start.
*/
function runDirectCompiledComponentInteraction(owner, source, generation, priority, work, onTraceScope, trace) {
	const startTrace = trace === void 0 ? componentTraceStarter(owner) : trace;
	if (startTrace) return runCompiledComponentInteraction(owner, source, interactionGeneration(generation, owner), priority, new AbortController(), work, onTraceScope, startTrace);
	let frame;
	let execution;
	let resolveForeground;
	let rejectForeground;
	const materialize = () => {
		if (frame) return frame;
		const registeredOwner = taskOwnerForHost(owner);
		const taskOwner = registeredOwner ?? createTaskOwnerRecord(`${owner.id}:interaction`);
		const foreground = new Promise((resolve, reject) => {
			resolveForeground = resolve;
			rejectForeground = reject;
		});
		execution = executeTaskFrame({
			owner: taskOwner,
			generation: interactionGeneration(generation, owner),
			activation: "interaction",
			label: `${source} interaction`,
			concurrency: "latest",
			priority: priority === "interactive" ? "immediate" : priority,
			readiness: priority === "deferred" ? "nonblocking" : "blocking",
			publicContext: false,
			detached: true
		}, () => {
			frame = currentTaskFrameRecord();
			return foreground;
		}).finally(() => registeredOwner ? void 0 : taskOwner[Symbol.asyncDispose]());
		return frame;
	};
	let directResult;
	try {
		directResult = withDeferredTaskFrame(materialize, work);
	} catch (error) {
		if (execution) {
			rejectForeground(error);
			execution.catch(() => void 0);
		}
		throw error;
	}
	if (!execution) return directResult;
	resolveForeground(directResult);
	return execution;
}
function interactionGeneration(generation, owner) {
	return typeof generation === "function" ? generation(owner) : generation;
}
function executeComponentInteraction(owner, source, generation, priority, controller, exposeScope, work, onTraceScope, trace) {
	const registeredOwner = taskOwnerForHost(owner);
	const taskOwner = registeredOwner ?? createTaskOwnerRecord(`${owner.id}:interaction`);
	const startTrace = trace === void 0 ? componentTraceStarter(owner) : trace || void 0;
	let interactionScope;
	const frameExecution = executeTaskFrame({
		owner: taskOwner,
		controller,
		generation,
		activation: "interaction",
		label: `${source} interaction`,
		concurrency: "latest",
		priority: priority === "interactive" ? "immediate" : priority,
		readiness: priority === "deferred" ? "nonblocking" : "blocking",
		publicContext: false
	}, () => {
		if (exposeScope || startTrace) {
			const frame = currentTaskFrameRecord();
			const scope = Object.freeze({
				id: nextInteractionId++,
				owner,
				source,
				priority,
				generation
			});
			interactionScope = scope;
			interactionsByFrame.set(frame, scope);
			const trace = startTrace?.("interaction", `interaction:${scope.id}`, {
				source,
				priority,
				generation
			});
			if (trace) (interactionTraces ??= /* @__PURE__ */ new WeakMap()).set(scope, trace);
			onTraceScope?.(scope);
			return work(scope);
		}
		return work();
	});
	const synchronousError = taskFrameSynchronousError(frameExecution);
	if (synchronousError) {
		if (!registeredOwner) frameExecution.finally(() => taskOwner[Symbol.asyncDispose]()).catch(() => void 0);
		if (interactionScope && interactionTraces?.has(interactionScope)) finishInteractionTrace(interactionScope, "error");
		throw synchronousError.error;
	}
	const execution = registeredOwner ? frameExecution : frameExecution.finally(() => taskOwner[Symbol.asyncDispose]());
	if (interactionScope && interactionTraces?.has(interactionScope)) execution.then(() => finishInteractionTrace(interactionScope, "success"), () => finishInteractionTrace(interactionScope, "error"));
	return execution;
}
function finishInteractionTrace(interaction, outcome) {
	traceInteractionPhase(interaction, "settled", { outcome });
	interactionTraces?.delete(interaction);
}
//#endregion
//#region packages/core/dist/client/component/construction.js
/**
* Releases every lifecycle resource registered before component initialization failed.
*
* The construction error remains primary; teardown failures are retained as
* suppressed diagnostics on that error.
*/
function cleanupFailedComponentConstruction(instance, primary) {
	try {
		instance.unmount("construct-failed");
	} catch (cleanup) {
		attachSuppressedCleanupFailure(primary, cleanup);
	}
}
//#endregion
//#region packages/core/dist/client/component/instance-identity.js
var nextComponentId$1 = 1;
/** Allocates the process-local diagnostic identity shared by every client instance storage lane. */
function allocateComponentInstanceId() {
	return `c${nextComponentId$1++}`;
}
//#endregion
//#region packages/core/dist/client/component/resumption.js
/** Applies compiler-selected SSR state paths without replacing client-local setup state. */
function applyComponentResumption(state, resumption) {
	const values = "componentId" in resumption ? resumption.values : resumption[1] ?? [];
	if (Array.isArray(values)) {
		for (const [field, value] of values) {
			if (typeof field !== "string") throw new Error(`eXact indexed resumption was not prepared for ${"componentId" in resumption ? resumption.componentId : resumption[0]}`);
			writePath(state, field, value);
		}
		return;
	}
	for (const [path, value] of Object.entries(values)) writePath(state, path, value);
}
/** Materializes one validated dotted state path into the live reactive state object. */
function writePath(target, path, value) {
	const segments = path.split(".");
	if (!segments.length || !segments.every(safeSegment)) throw new Error(`Malformed eXact component resumption state path ${path}`);
	let cursor = target;
	for (const segment of segments.slice(0, -1)) {
		const current = cursor[segment];
		if (current && typeof current === "object" && !Array.isArray(current)) cursor = current;
		else {
			const created = {};
			cursor[segment] = created;
			cursor = created;
		}
	}
	cursor[segments.at(-1)] = value;
}
/** Rejects prototype-bearing path segments before touching reactive state. */
function safeSegment(segment) {
	return segment.length > 0 && segment !== "__proto__" && segment !== "prototype" && segment !== "constructor";
}
//#endregion
//#region packages/core/dist/client/component/runtime-surface.js
/**
* Minimal durable component surface shared by every compiled component.
*
* Optional authored operations are declaration-only here. Compiler-selected runtime entries
* install their implementations on the shared prototype, keeping unused implementation graphs
* unreachable without changing the public {@link Component} authoring contract.
*/
var ComponentRuntimeSurface = class {
	contextsValue;
	contextTokensValue;
	/** Returns the lazily allocated local context value map owned by this instance. */
	get contexts() {
		return this.contextsValue ??= /* @__PURE__ */ new Map();
	}
	/** Returns the lazily allocated token catalog used for inspection and resumption. */
	get contextTokens() {
		return this.contextTokensValue ??= /* @__PURE__ */ new Map();
	}
};
//#endregion
//#region packages/reactive/dist/framework/indexed-objects.js
/** Creates compiler-proven indexed state with object/array-only nested observation. */
function indexedReactiveObjects(keys, options = {}, initial, preserveReactiveValues = false) {
	return createIndexedReactive(keys, options, reactiveObjects, initial, preserveReactiveValues);
}
//#endregion
//#region packages/core/dist/client/component/state.js
/** Creates inspectable component state before the final instance reference is assigned. */
function createComponentState(domain, instance, indexedKeys, collections = false) {
	const options = { onMutation(key, operation) {
		const component = instance();
		if (!component) return;
		componentDomainInspection(domain)?.publish({
			kind: "state.change",
			component,
			path: key === void 0 ? "state" : `state.${String(key)}`,
			attributes: Object.freeze({ operation })
		});
	} };
	if (collections) {
		if (!collectionStateFactory) throw new Error("Collection state requires the compiler-selected collection capability");
		return collectionStateFactory(indexedKeys, options);
	}
	return indexedReactiveObjects(indexedKeys, options);
}
var collectionStateFactory;
/** Creates readonly reactive props while preserving compiler-owned children passthrough. */
function createComponentProps(rawProps, indexedKeys, collections = false, opaqueKeys = []) {
	const options = {
		readonly: true,
		passthroughKeys: ["children", ...opaqueKeys],
		onReadonlyWrite(key) {
			throw new TypeError(`Cannot write to readonly props.${String(key)}`);
		}
	};
	if (collections) {
		if (!collectionPropsFactory) throw new Error("Collection props require the compiler-selected collection capability");
		return collectionPropsFactory(rawProps, indexedKeys, options);
	}
	return indexedReactiveObjects(indexedKeys, options, rawProps, true);
}
var collectionPropsFactory;
//#endregion
//#region packages/core/dist/client/component/context-capability.js
var contextCapability;
/** Reads the optional context implementation without making it universally reachable. */
function optionalComponentContextCapability() {
	return contextCapability;
}
//#endregion
//#region packages/core/dist/client/component/compact-instance.js
/**
* Compact durable record shared by compiler-selected render and task construction lanes.
*
* The record owns generated reactive work and the common component identity. Concrete lanes add
* only the capability state their compiler artifact declares and must release it from `unmount`.
*/
var CompactComponentInstance = class extends ComponentRuntimeSurface {
	type;
	parent;
	domain;
	id = allocateComponentInstanceId();
	scope;
	state;
	props;
	ambientContexts;
	runtimeABI;
	renderStop;
	invalidate;
	errorFallback;
	inspection;
	mountedValue = false;
	activeValue = false;
	disposedValue = false;
	activityBlockers;
	renderFunctionValue = () => null;
	componentResumption;
	inputUpdates;
	constructor(type, rawProps, parent, ambientContexts, domain, contract) {
		super();
		this.type = type;
		this.parent = parent;
		this.domain = domain;
		this.ambientContexts = ambientContexts;
		this.runtimeABI = contract.artifact.abi;
		this.inspection = componentDomainInspection(domain);
		this.scope = createEffectScope(void 0, (error) => {
			handleComponentError(this, createErrorReport(error, "reactive", this, "watch"));
		});
		this.state = createComponentState(domain, () => this, contract.artifact.state, Boolean(this.runtimeABI & 16));
		this.props = createComponentProps(rawProps, contract.artifact.props, Boolean(this.runtimeABI & 16), contract.artifact.opaqueProps);
		this.componentResumption = resolveComponentResumption(this.domain, this.type);
		this.inputUpdates = "inputs" in contract.artifact ? contract.artifact.inputs : void 0;
		if (this.componentResumption) applyComponentResumption(this.state, this.componentResumption);
	}
	/** Reports whether mount publication has completed and disposal has not begun. */
	get mounted() {
		return this.mountedValue;
	}
	/** Returns the compiler-produced render operation initialized for this record. */
	get renderFunction() {
		return this.renderFunctionValue;
	}
	/** Opens a render pass; compact artifacts cannot own runtime-managed lists. */
	beginRender() {}
	/** Closes a render pass; compact artifacts cannot own runtime-managed lists. */
	endRender() {}
	/** Publishes the first mount and activates the record without lifecycle dispatch. */
	markMounted() {
		if (this.mountedValue || this.disposedValue) return;
		this.mountedValue = true;
		this.inspection?.publish({
			kind: "component.mount",
			component: this
		});
		this.handleMounted();
		this.updateActivation();
	}
	/** Applies one activity blocker without allocating lifecycle controllers or handler arrays. */
	setActivity(token, active, reason = "activity") {
		if (active) {
			this.activityBlockers?.delete(token);
			if (!this.activityBlockers?.size) this.activityBlockers = void 0;
		} else (this.activityBlockers ??= /* @__PURE__ */ new Set()).add(token);
		const blockers = this.activityBlockers?.size ?? 0;
		this.inspection?.publish({
			kind: "activity.change",
			component: this,
			reason,
			attributes: Object.freeze({
				active: blockers === 0,
				blockers
			})
		});
		this.updateActivation(reason);
	}
	/** Reconciles parent-owned inputs against the stable props facade. */
	receiveProps(slots, source, children) {
		batch(() => {
			let dirtyLow = 0;
			let dirtyHigh = 0;
			let binding = 0;
			const bindings = this.inputUpdates?.bindings;
			for (let slot = 0; slot < slots.length; slot++) {
				const name = slots[slot];
				while (bindings && binding < bindings.length && bindings[binding][0] < slot) binding++;
				let changed;
				if (name === "children" && children.length !== 0) changed = setIndexedReactiveSlotWithResult(this.props, slot, children.length === 1 ? children[0] : children);
				else if (Object.prototype.hasOwnProperty.call(source, name)) changed = setIndexedReactiveSlotWithResult(this.props, slot, source[name]);
				else changed = deleteIndexedReactiveSlotWithResult(this.props, slot);
				const dependency = bindings?.[binding];
				if (changed && dependency?.[0] === slot) {
					dirtyLow |= dependency[1];
					dirtyHigh |= dependency[2];
				}
			}
			if (dirtyLow || dirtyHigh) this.inputUpdates.apply(this, dirtyLow, dirtyHigh);
		});
		this.inspection?.publish({
			kind: "props.change",
			component: this,
			path: "props"
		});
	}
	/** Releases generated reactive ownership and render invalidation exactly once. */
	unmount(reason = "unmount") {
		if (this.disposedValue) return;
		this.inspection?.publish({
			kind: "component.unmount",
			component: this,
			reason
		});
		this.deactivate(reason);
		this.disposedValue = true;
		this.mountedValue = false;
		let primary;
		try {
			this.renderStop?.();
		} catch (error) {
			primary = error;
		}
		try {
			this.scope.stop();
		} catch (error) {
			if (primary === void 0) primary = error;
		}
		if (primary !== void 0) throw primary;
	}
	/** Runs one compiler-selected setup lane around shared construction and resumption semantics. */
	initializeComponent(invoke) {
		const resumption = this.componentResumption;
		const resumedContexts = resumption ? "componentId" in resumption ? resumption.contexts : resumption[2] ?? [] : void 0;
		try {
			this.inspection?.publish({
				kind: "component.construct",
				component: this
			});
			if (!this.parent && isHydrationComponentDomain(this.domain)) this.inspection?.publish({
				kind: "hydration.activate",
				component: this
			});
			if (!this.parent && !this.ambientContexts?.has(ErrorContext.id)) this.contexts.set(ErrorContext.id, createErrorContext());
			if (resumption && resumedContexts && (Array.isArray(resumedContexts) ? resumedContexts.length !== 0 : Object.keys(resumedContexts).length !== 0)) {
				const contextCapability = optionalComponentContextCapability();
				if (!contextCapability) throw new Error("Component context resumption requires the compiler-selected context capability");
				contextCapability.prepare(this, resumption);
			}
			const result = callWithComponentDomainInEffectScope(this.domain, this.scope, invoke);
			if (resumption) {
				applyComponentResumption(this.state, resumption);
				this.inspection?.publish({
					kind: "resumption.activate",
					component: this
				});
			}
			if (typeof result !== "function") throw new TypeError("eXact runtime components must synchronously return their compiled render function");
			this.renderFunctionValue = result;
		} catch (error) {
			cleanupFailedComponentConstruction(this, error);
			throw error;
		}
	}
	/** Runs capability-specific mount work before the common activation decision. */
	handleMounted() {}
	/** Publishes allocation-free activation state for inspection. */
	updateActivation(reason = "activity") {
		if (this.disposedValue || !this.mountedValue || this.activityBlockers?.size) {
			this.deactivate(reason);
			return;
		}
		this.activate(reason);
	}
	/** Publishes activation and reports whether this call changed state. */
	activate(reason) {
		if (this.activeValue) return false;
		this.activeValue = true;
		this.inspection?.publish({
			kind: "component.activate",
			component: this,
			reason
		});
		return true;
	}
	/** Publishes deactivation and reports whether this call changed state. */
	deactivate(reason) {
		if (!this.activeValue) return false;
		this.activeValue = false;
		this.inspection?.publish({
			kind: "component.deactivate",
			component: this,
			reason
		});
		return true;
	}
};
//#endregion
//#region packages/core/dist/client/component/ownership.js
/** Transfers a live component to a new logical parent during renderer-owned root replacement. */
function reparentComponentInstance(instance, parent) {
	for (let cursor = parent; cursor; cursor = cursor.parent) if (cursor === instance) throw new Error("Cannot create a component parent cycle");
	instance.parent = parent;
}
//#endregion
//#region packages/core/dist/client/render-program.js
var renderProgramReceipts = sharedOpaqueOperationStore("render-program");
/** Dispatch key implemented by targets that execute compiler-closed render programs. */
var exactRenderProgramOperation = Symbol.for("@exactjs/target-operation/render-program");
function executeRenderProgramOperation(target) {
	const data = renderProgramReceipts.get(this);
	if (!data) throw new TypeError("Render-program operation lost its compiler-issued payload");
	return target[exactRenderProgramOperation](this, data);
}
/**
* Registers one compiler-emitted descriptor without copying its trusted executable data.
*
* The module-private weak identity is the renderer's authority boundary. Descriptors are emitted
* as module-local constants by the compiler, so recursively cloning and freezing their nested
* tables during browser startup adds allocation and traversal without validating an external
* input. Network and plugin payloads remain subject to their own boundary validation before they
* can reach this compiler-only operation.
*/
function prepareCompiledRenderProgram(program) {
	if (program.version !== 1) throw new TypeError("Unsupported eXact render-program ABI; expected version 1");
	return program;
}
/** Joins invocation-local readers to one compiler-hoisted immutable descriptor. */
function createPreparedRenderProgram(branded, readers, owner, propertyWriter, enhancement) {
	const domain = currentComponentDomain();
	const receipt = createOpaqueOperation(executeRenderProgramOperation, { ...domain ? { domain } : {} });
	renderProgramReceipts.set(receipt, {
		invocation: {
			program: branded,
			readers,
			owner,
			...propertyWriter ? { propertyWriter } : {}
		},
		...enhancement ? { enhancement } : {},
		...domain ? { domain } : {}
	});
	return receipt;
}
/** Reads the invocation carried by a compiler-only render-program operation. */
function readRenderProgram(value) {
	return readRenderProgramReceipt(value)?.invocation;
}
/** Reads only compiler-issued client render-program operations. */
function readRenderProgramReceipt(value) {
	return typeof value === "object" && value !== null ? renderProgramReceipts.get(value) : void 0;
}
/** Evaluates one invocation-local slot through per-slot readers or a combined dispatcher. */
function readRenderProgramSlot(invocation, index) {
	if (invocation.eagerValues) return invocation.eagerValues[index];
	return typeof invocation.readers === "function" ? invocation.readers(index) : invocation.readers[index]();
}
//#endregion
//#region packages/core/dist/client/protocol.js
/** Encodes arbitrary UTF-8 data for use inside an eXact HTML comment marker. */
function encodeExactMarkerPart(value) {
	if (/^[A-Za-z0-9._-]+$/.test(value) && !value.includes("--")) return value;
	return `~${Array.from(new TextEncoder().encode(value), (byte) => byte.toString(16).padStart(2, "0")).join("")}`;
}
/** Decodes data emitted by encodeExactMarkerPart; directly encoded safe values pass through. */
function decodeExactMarkerPart(value) {
	if (!value.startsWith("~") || !/^(?:[0-9a-f]{2})+$/i.test(value.slice(1))) return value;
	const hex = value.slice(1);
	const bytes = new Uint8Array(hex.length / 2);
	for (let index = 0; index < bytes.length; index++) bytes[index] = Number.parseInt(hex.slice(index * 2, index * 2 + 2), 16);
	return new TextDecoder().decode(bytes);
}
sharedOpaqueOperationStore("server-boundary");
var slots = sharedOpaqueOperationStore("server-slot");
/** Dispatch key implemented by SSR targets that publish a client island. */
var exactServerBoundaryOperation = Symbol.for("@exactjs/target-operation/server-boundary");
/** Dispatch key implemented by SSR targets that retain a server-owned range. */
var exactServerSlotOperation = Symbol.for("@exactjs/target-operation/server-slot");
function executeServerSlotOperation(target) {
	const data = slots.get(this);
	if (!data) throw new TypeError("Server-slot operation lost its compiler-issued payload");
	return target[exactServerSlotOperation](this, data);
}
/** Issues one compiler-owned retained server-range operation. */
function createServerSlotReceipt(id, authority = {}, ...children) {
	return issueServerSlotReceipt(String(unwrap(id) ?? ""), authority, children);
}
/** Creates or adopts one compiler-owned retained server range. */
var createServerSlot = createServerSlotReceipt;
function issueServerSlotReceipt(id, authority, children) {
	const { key, ...protocolAuthority } = authority;
	const receipt = createOpaqueOperation(executeServerSlotOperation);
	slots.set(receipt, {
		id,
		children: normalizeRenderResult(children),
		...key === null || key === void 0 ? {} : { key: String(unwrap(key)) },
		...protocolAuthority
	});
	return receipt;
}
/** Reads a compiler-issued retained server-range operation without accepting arbitrary objects. */
function readServerSlotReceipt(value) {
	return typeof value === "object" && value !== null ? slots.get(value) : void 0;
}
//#endregion
//#region packages/core/dist/client/component-abi/child-range-receipt.js
var ranges = sharedOpaqueOperationStore("child-range");
/** Dispatch key implemented by render targets that accept focused child ranges. */
var exactChildRangeOperation = Symbol.for("@exactjs/target-operation/child-range");
function executeChildRangeOperation(target) {
	const data = ranges.get(this);
	if (!data) throw new TypeError("Child-range operation lost its compiler-issued payload");
	return target[exactChildRangeOperation](this, data);
}
/** Issues a focused child-range operation without exposing child topology. */
function createChildRangeReceipt(value, markerId, mayReplaceSubtree = true, dynamicComponent) {
	const domain = currentComponentDomain();
	const receipt = createOpaqueOperation(executeChildRangeOperation, { ...domain ? { domain } : {} });
	ranges.set(receipt, {
		value,
		mayReplaceSubtree,
		...markerId ? { markerId } : {},
		...domain ? { domain } : {},
		...dynamicComponent ? { dynamicComponent } : {}
	});
	return receipt;
}
/** Reads only compiler-issued range operations. */
function readChildRangeReceipt(value) {
	return typeof value === "object" && value !== null ? ranges.get(value) : void 0;
}
//#endregion
//#region packages/core/dist/client/component-abi/compiled-child-range.js
/** Creates the client operation for a compiler-owned dynamic child range. */
function createCompiledChildRangeReceipt(compute, markerId, mayReplaceSubtree = true) {
	return createChildRangeReceipt(computed(compute), markerId, mayReplaceSubtree);
}
//#endregion
//#region packages/core/dist/client/component/reactive-expressions.js
/** Creates a reactive expression wrapper for compiler-generated expression boundaries. */
function createExpression(compute) {
	return computed(compute);
}
//#endregion
//#region packages/core/dist/client/component-contract/metadata-validation.js
/** Narrows generated metadata to a non-array record. */
function isContractRecord(value) {
	return !!value && typeof value === "object" && !Array.isArray(value);
}
/** Requires a stable generated contract name to be non-empty. */
function isContractString(value) {
	return typeof value === "string" && value.length > 0;
}
/** Rejects unexpected fields in versioned generated metadata. */
function hasOnlyContractKeys(value, allowed) {
	return Object.keys(value).every((key) => allowed.includes(key));
}
//#endregion
//#region packages/core/dist/client/component-contract/continuation-validation.js
/** Reports whether a generated continuation dependency has a supported source. */
function isExactContinuationDependency(value) {
	return isContractRecord(value) && hasOnlyContractKeys(value, [
		"index",
		"source",
		"path"
	]) && (value.index === void 0 || typeof value.index === "number" && Number.isSafeInteger(value.index) && value.index >= 0) && (value.path === void 0 || isContractString(value.path)) && (value.source === "state" || value.source === "props" || value.source === "derived" || value.source === "argument");
}
function isExactContinuationInvocation(value, options = {}) {
	if (!isContractRecord(value) || !hasOnlyContractKeys(value, ["arguments", "concurrency"])) return false;
	const argumentsValue = value.arguments;
	return (options.argumentsOptional && argumentsValue === void 0 || Array.isArray(argumentsValue) && argumentsValue.every((argument) => isContractRecord(argument) && hasOnlyContractKeys(argument, [
		"index",
		"source",
		"path"
	]) && (argument.index === void 0 || typeof argument.index === "number" && Number.isSafeInteger(argument.index) && argument.index >= 0) && (argument.path === void 0 || isContractString(argument.path)) && argument.source === "argument")) && (value.concurrency === "parallel" || value.concurrency === "latest" || value.concurrency === "queue");
}
/** Reports whether a generated continuation state-path descriptor is valid. */
function isExactContinuationStatePath(value) {
	return isContractRecord(value) && hasOnlyContractKeys(value, [
		"path",
		"kind",
		"confidence",
		"operation"
	]) && isContractString(value.path) && (value.kind === "read" || value.kind === "write") && (value.confidence === "exact" || value.confidence === "broad" || value.confidence === "unknown") && (value.operation === void 0 || value.operation === "value" || value.operation === "map" || value.operation === "set");
}
//#endregion
//#region packages/core/dist/client/component-contract/composition-support.js
/** Adds one generated continuation implementation while rejecting ambiguous authority. */
function addUniqueExecutor(target, executor) {
	const previous = target[executor.id];
	if (previous && (previous.componentId !== executor.componentId || previous.execute !== executor.execute)) throw new Error(`Conflicting eXact component continuation executor ${executor.id}`);
	target[executor.id] = executor;
}
/** Adds one implementation while rejecting ID or runtime-name collisions. */
function addUniqueImplementation(target, key, implementation) {
	const previous = target[key];
	if (previous && previous !== implementation) throw new Error(`Conflicting eXact component implementation ${key}`);
	target[key] = implementation;
}
/** Adds immutable JSON-shaped metadata while rejecting conflicting identities. */
function addUniqueJson(target, key, value, kind) {
	const previous = target[key];
	if (previous && JSON.stringify(previous) !== JSON.stringify(value)) throw new Error(`Conflicting eXact component ${kind} ${key}`);
	target[key] = value;
}
//#endregion
//#region packages/core/dist/client/component-contracts.js
/** Global property under which compiled artifacts carry their target-local contract. */
var exactComponentContract = Symbol.for("@exactjs/component-contract");
/** Global marker distinguishing a native eXact component from compatibility-owned functions. */
var exactComponentType = Symbol.for("@exactjs/component");
/** Reads build-validated compiler metadata without repeating recursive runtime validation. */
var readPreparedExactComponentContract = (component) => component[exactComponentContract];
/** Reads a build-validated current executable target artifact. */
function readPreparedExactExecutableComponentContract(component) {
	const contract = readPreparedExactComponentContract(component);
	if (!contract?.artifact) throw new TypeError(`Native eXact component execution requires a compiled component artifact: ${component.name || "<anonymous>"}`);
	return contract;
}
/** Reads one build-validated client-target executable component contract. */
function readPreparedExactClientExecutableComponentContract(component) {
	const contract = readPreparedExactExecutableComponentContract(component);
	if (contract.artifact.target !== "client") throw new TypeError("Client execution requires a current client component artifact");
	return contract;
}
/** Returns the stable compiler identity used to pair SSR and client component boundaries. */
function exactComponentIdentity(component) {
	const identity = component[exactComponentType];
	if (typeof identity === "string" && identity) return identity;
	throw new Error("Native eXact components require compiler-owned identity");
}
/** Composes build-validated compiler metadata without repeating recursive validation. */
function composePreparedExactComponentContracts(components, role) {
	return composeComponentContracts(components, role, readPreparedExactComponentContract);
}
function composeComponentContracts(components, role, readContract) {
	const implementations = {};
	const implementationsById = {};
	const continuations = {};
	const executors = {};
	const boundaries = {};
	const resumptions = {};
	const executions = {};
	const artifacts = {};
	for (const component of components) {
		const contract = readContract(component);
		if (!contract) continue;
		const componentId = exactComponentIdentity(component);
		const projectedRole = contract.role ?? (contract.artifact.target === "client" ? "client" : "render");
		if (projectedRole !== role) throw new Error(`Expected eXact ${role} component contract for ${componentId}, received ${projectedRole}`);
		const projectedImplementations = contract.implementations ?? [{
			id: componentId,
			name: component.name,
			role: "root",
			implementation: component
		}];
		for (const implementation of projectedImplementations) {
			addUniqueImplementation(implementationsById, implementation.id, implementation.implementation);
			addUniqueImplementation(implementations, implementation.name, implementation.implementation);
		}
		for (const continuation of contract.continuations ?? []) addUniqueJson(continuations, continuation.id, continuation, "continuation");
		for (const executor of contract.executors ?? []) addUniqueExecutor(executors, executor);
		for (const boundary of contract.boundaries ?? []) addUniqueJson(boundaries, boundary.id, boundary, "boundary");
		if (contract.resumption) addUniqueJson(resumptions, contract.resumption.componentId, contract.resumption, "resumption");
		if (contract.execution) addUniqueJson(executions, componentId, contract.execution, "execution plan");
		artifacts[componentId] = contract.artifact;
	}
	return Object.freeze({
		implementations,
		implementationsById,
		continuations,
		executors,
		boundaries,
		resumptions,
		executions,
		artifacts
	});
}
//#endregion
//#region packages/core/dist/client/component/task-capability.js
var taskCapability;
/** Returns the reachable task integration, if this artifact contains task support. */
function componentTaskCapability() {
	return taskCapability;
}
//#endregion
//#region packages/core/dist/client/tasks/resources.js
var taskMutations = /* @__PURE__ */ new WeakMap();
var taskCollectionMutations = /* @__PURE__ */ new WeakMap();
/** Stages a compiler-generated mutation until its blocking task generation commits. */
function stageTaskMutation(signal, mutation) {
	if (signal.aborted) return;
	let staged = taskMutations.get(signal);
	if (!staged) {
		staged = [];
		taskMutations.set(signal, staged);
		signal.addEventListener("abort", () => discardTaskMutations(signal), { once: true });
	}
	staged.push(mutation);
}
/** Discards every unpublished mutation owned by a task generation. */
function discardTaskMutations(signal) {
	taskMutations.delete(signal);
	taskCollectionMutations.delete(signal);
}
//#endregion
//#region packages/core/dist/client/tasks/component-execution-slice.js
var activeSlice;
/** Constructs one generated island region under its exact transition allowlist. */
function withComponentExecutionSlice(slice, work) {
	const previous = activeSlice;
	activeSlice = slice;
	try {
		return work();
	} finally {
		activeSlice = previous;
	}
}
//#endregion
//#region packages/core/dist/client/component/runtime-surface-registration.js
function installDescriptors(descriptors) {
	const target = CompactComponentInstance.prototype;
	for (const key of Reflect.ownKeys(descriptors)) {
		if (Object.hasOwn(target, key)) throw new Error(`Component runtime surface already defines ${String(key)}`);
		Object.defineProperty(target, key, descriptors[key]);
	}
}
/**
* Registers one compiler-selectable group of authored component operations.
*
* Registration is order-independent: feature entries may evaluate before or after the component
* implementation that receives them. A duplicate property is an artifact construction error.
*/
function registerComponentRuntimeSurface(descriptors) {
	installDescriptors(descriptors);
}
//#endregion
//#region packages/core/dist/client/component/lifecycle-handlers.js
var registrations = /* @__PURE__ */ new WeakMap();
var emptyLifecycleHandlers = Object.freeze([]);
var emptyRenderHandlers = Object.freeze([]);
/** Reads a lifecycle phase without allocating storage for components that do not use it. */
function componentLifecycleHandlers(instance, phase) {
	return registrations.get(instance)?.[phase] ?? emptyLifecycleHandlers;
}
/** Reads render listeners without allocating storage for components that do not observe renders. */
function componentRenderHandlers(instance) {
	return registrations.get(instance)?.render ?? emptyRenderHandlers;
}
/** Releases handler arrays after component teardown, including when inspection retains the shell. */
function clearComponentLifecycleHandlers(instance) {
	registrations.delete(instance);
}
//#endregion
//#region packages/core/dist/client/component/compiled-output.js
/** Executes one compiler-owned output operation without installing component-wide invalidation. */
function executeCompiledComponentOutput(instance) {
	let output = null;
	const start = performanceNow();
	instance.invalidate = void 0;
	instance.beginRender();
	try {
		const render = instance.errorFallback ?? instance.renderFunction;
		output = withEffectScope(instance.scope, () => withComponentDomain(instance.domain, render));
	} catch (error) {
		if (isPromiseLike$2(error) && handleComponentSuspension(instance, error)) output = null;
		else {
			const fallback = handleComponentError(instance, createErrorReport(error, "render", instance));
			if (fallback) {
				instance.errorFallback = fallback;
				output = withEffectScope(instance.scope, () => withComponentDomain(instance.domain, fallback));
			}
		}
	} finally {
		instance.endRender();
	}
	if (instance.runtimeABI & 2) {
		const duration = performanceNow() - start;
		for (const handler of componentRenderHandlers(instance)) try {
			const result = handler({ duration });
			if (isPromiseLike$2(result)) observeLifecyclePromise(instance, Promise.resolve(result), "render");
		} catch (error) {
			handleComponentError(instance, createErrorReport(error, "lifecycle", instance, "render"));
		}
	}
	return normalizeRenderResult(output);
}
function performanceNow() {
	return typeof globalThis.performance?.now === "function" ? globalThis.performance.now() : Date.now();
}
//#endregion
//#region packages/core/dist/client/component-abi/client.js
/** DOM protocol key used only by compiler-produced one-shot component output attachment. */
var exactCompiledClientAttachment = Symbol.for("@exactjs/compiled-client-component-attachment");
/** DOM protocol key used by a foreign renderer's fixed compiled island artifact. */
var exactCompatibilityClientAttachment = Symbol.for("@exactjs/compatibility-client-component-attachment");
//#endregion
//#region packages/core/dist/client/component-abi/compiled-runtime.js
var emptyChildren = Object.freeze([]);
/** Executes one compiler-owned output and delegates its opaque child ranges to the DOM owner. */
function attachExactCompiledClientComponent(instance, target, mode) {
	flushSync("normal");
	return target[exactCompiledClientAttachment](this, instance, executeCompiledComponentOutput(instance), mode);
}
/** Applies one final-value-per-slot prop receipt and publishes it to the receiving instance once. */
function receiveExactClientComponentProps(instance, source, children = emptyChildren) {
	instance.receiveProps(this.props, source, children);
}
/** Releases a client component instance through its idempotent instance-owned finalizer. */
function disposeExactClientComponent(instance, reason) {
	instance.unmount(typeof reason === "string" ? reason : "artifact-dispose");
}
Object.freeze([]);
var receipts = sharedOpaqueOperationStore("component");
/** Dispatch key implemented by render targets that accept component operations. */
var exactComponentOperation = Symbol.for("@exactjs/target-operation/component");
function executeComponentOperation(target) {
	const data = receipts.get(this);
	if (!data) throw new TypeError("Component operation lost its compiler-issued payload");
	return target[exactComponentOperation](this, data);
}
/**
* Publishes a direct component-ABI operation without exposing component shape.
* The compiler selects this operation only after resolving the target artifact at build time.
*/
function createCompiledComponentReceipt(type, props, ...children) {
	const { key: authoredKey, __exactEnhancements: enhancement, ...componentProps } = props ?? {};
	const rawKey = unwrap(authoredKey);
	const domain = currentComponentDomain();
	const key = rawKey === null || rawKey === void 0 ? void 0 : String(rawKey);
	const receipt = createOpaqueOperation(executeComponentOperation, {
		...key === void 0 ? {} : { key },
		...domain ? { domain } : {}
	});
	receipts.set(receipt, {
		contract: readPreparedExactExecutableComponentContract(type),
		props: componentProps,
		children: normalizeRenderResult(children),
		...key === void 0 ? {} : { key },
		...domain ? { domain } : {},
		...enhancement ? { enhancement } : {}
	});
	return receipt;
}
/** Reads a compiler-issued receipt; arbitrary objects never become component candidates. */
function readCompiledComponentReceipt(value) {
	return typeof value === "object" && value !== null ? receipts.get(value) : void 0;
}
//#endregion
//#region packages/core/dist/client/component-abi/suspense-receipt.js
var suspenseReceipts = sharedOpaqueOperationStore("suspense");
/** Dispatch key implemented by render targets that accept Suspense operations. */
var exactSuspenseOperation = Symbol.for("@exactjs/target-operation/suspense");
/** Reads only compiler-issued native readiness-boundary operations. */
function readCompiledSuspenseReceipt(value) {
	return typeof value === "object" && value !== null ? suspenseReceipts.get(value) : void 0;
}
//#endregion
//#region packages/core/dist/client/component-abi/activity-receipt.js
var activityReceipts = sharedOpaqueOperationStore("activity");
/** Dispatch key implemented by render targets that accept Activity operations. */
var exactActivityOperation = Symbol.for("@exactjs/target-operation/activity");
/** Reads only compiler-issued retained Activity operations. */
function readCompiledActivityReceipt(value) {
	return typeof value === "object" && value !== null ? activityReceipts.get(value) : void 0;
}
//#endregion
//#region packages/core/dist/client/component-abi/fragment-receipt.js
var fragments = sharedOpaqueOperationStore("fragment");
/** Dispatch key implemented by render targets that accept fragment ranges. */
var exactFragmentOperation = Symbol.for("@exactjs/target-operation/fragment");
/** Reads only compiler-issued transparent range operations. */
function readCompiledFragmentReceipt(value) {
	return typeof value === "object" && value !== null ? fragments.get(value) : void 0;
}
//#endregion
//#region packages/core/dist/client/component-abi/target-receipt.js
var targets = sharedOpaqueOperationStore("target");
/** Dispatch key implemented by render targets that accept semantic target ranges. */
var exactTargetOperation = Symbol.for("@exactjs/target-operation/target");
/** Reads only compiler-issued semantic-target operations. */
function readCompiledTargetReceipt(value) {
	return typeof value === "object" && value !== null ? targets.get(value) : void 0;
}
//#endregion
//#region packages/core/dist/client/component-abi/keyed-child-receipt.js
var keyedChildren = sharedOpaqueOperationStore("keyed-child");
/** Dispatch key implemented by render targets that accept keyed-child operations. */
var exactKeyedChildOperation = Symbol.for("@exactjs/target-operation/keyed-child");
function executeKeyedChildOperation(target) {
	const data = keyedChildren.get(this);
	if (!data) throw new TypeError("Keyed child operation lost its compiler-issued payload");
	return target[exactKeyedChildOperation](this, data);
}
/** Joins compiler-proven list identity without mutating or interpreting the child operation. */
function createCompiledKeyedChildReceipt(value, authoredKey, ownerScope) {
	const key = unwrap(authoredKey);
	if (key === null || key === void 0) throw new Error("Compiled keyed lists require a key");
	const stringKey = String(key);
	const domain = opaqueOperationDomain(value);
	const receipt = createOpaqueOperation(executeKeyedChildOperation, {
		key: stringKey,
		...domain ? { domain } : {}
	});
	keyedChildren.set(receipt, {
		value,
		key: stringKey,
		...ownerScope ? { ownerScope } : {}
	});
	return receipt;
}
/** Reads only compiler-issued keyed sibling operations. */
function readCompiledKeyedChildReceipt(value) {
	return typeof value === "object" && value !== null ? keyedChildren.get(value) : void 0;
}
//#endregion
//#region packages/core/dist/client/component-abi/unsafe-html-receipt.js
var unsafeHtmlReceipts = sharedOpaqueOperationStore("unsafe-html");
/** Dispatch key implemented by render targets that accept audited raw HTML. */
var exactUnsafeHtmlOperation = Symbol.for("@exactjs/target-operation/unsafe-html");
/** Reads only compiler-authorized raw-HTML operations. */
function readUnsafeHtmlReceipt(value) {
	return typeof value === "object" && value !== null ? unsafeHtmlReceipts.get(value) : void 0;
}
sharedOpaqueOperationStore("portal");
/** Dispatch key implemented by render targets that accept portal operations. */
var exactPortalOperation = Symbol.for("@exactjs/target-operation/portal");
//#endregion
//#region packages/core/dist/client/component/render-instance.js
/** Compact durable record selected for compiler artifacts without task, lifecycle, or list work. */
var RenderComponentInstance = class extends CompactComponentInstance {
	constructor(type, rawProps, parent, ambientContexts, domain, contract) {
		super(type, rawProps, parent, ambientContexts, domain, contract);
		this.initializeComponent(() => contract.artifact.instantiate.call(this, this.props));
	}
};
//#endregion
//#region packages/core/dist/client/component/render-instance-construction.js
/** Constructs the compact record selected by a render-only compiled component artifact. */
var constructRenderComponentInstance = function(parent, rawProps, ambientContexts, domain, _execution, contract) {
	return new RenderComponentInstance(this.instantiate, rawProps, parent, ambientContexts, domain, contract);
};
//#endregion
//#region packages/devtools-protocol/dist/identity.js
/** Validates the shape and bounded fields of a runtime identity. */
function isExactInspectionRuntimeId(value) {
	if (!record$1(value)) return false;
	if (!boundedString$1(value.sessionId, 256) || value.side !== "client" && value.side !== "server" || !boundedString$1(value.buildKey, 256) || !boundedString$1(value.executionRoot, 512) || !boundedString$1(value.componentTypeId, 512)) return false;
	for (const key of [
		"binding",
		"instanceId",
		"sourceEntityId",
		"operationId"
	]) if (value[key] !== void 0 && !boundedString$1(value[key], 512)) return false;
	return value.generation === void 0 || Number.isSafeInteger(value.generation) && value.generation >= 0;
}
function boundedString$1(value, maximum) {
	return typeof value === "string" && value.length > 0 && value.length <= maximum;
}
function record$1(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
//#endregion
//#region packages/devtools-protocol/dist/runtime.js
var inspectionEventKinds = /* @__PURE__ */ new Set([
	"component.construct",
	"component.mount",
	"component.activate",
	"component.deactivate",
	"component.unmount",
	"state.change",
	"props.change",
	"task.queue",
	"task.start",
	"task.settle",
	"task.fail",
	"task.cancel",
	"task.supersede",
	"task.optimistic",
	"task.rollback",
	"task.commit",
	"task.frame.enter",
	"task.frame.exit",
	"task.foreground-settle",
	"task.structural-settle",
	"task.resource.acquire",
	"task.resource.release",
	"task.renderer.commit",
	"render.invalidate",
	"binding.invalidate",
	"activity.change",
	"suspense.change",
	"continuation.dispatch",
	"continuation.receive",
	"continuation.execute",
	"continuation.respond",
	"continuation.apply",
	"context.access",
	"hydration.activate",
	"resumption.activate",
	"patch.apply",
	"interaction",
	"navigation",
	"error",
	"profile"
]);
/** Validates one untrusted event before extension or CDP delivery. */
function isExactRuntimeInspectionEvent(value) {
	if (!record(value) || value.protocol !== 1 || !boundedString(value.cursor, 256) || !positiveInteger(value.sequence) || typeof value.timestamp !== "number" || !Number.isFinite(value.timestamp) || value.wallTime !== void 0 && (typeof value.wallTime !== "number" || !Number.isFinite(value.wallTime)) || typeof value.kind !== "string" || !inspectionEventKinds.has(value.kind) || !isExactInspectionRuntimeId(value.id)) return false;
	for (const key of [
		"requestId",
		"interactionId",
		"path",
		"reason"
	]) if (value[key] !== void 0 && !boundedString(value[key], key === "path" ? 2048 : 1024)) return false;
	if (value.attributes !== void 0) {
		if (!record(value.attributes) || Object.keys(value.attributes).length > 100) return false;
		for (const [key, attribute] of Object.entries(value.attributes)) if (key.length > 256 || !(attribute === null || typeof attribute === "string" || typeof attribute === "boolean" || typeof attribute === "number" && Number.isFinite(attribute)) || typeof attribute === "string" && attribute.length > 4096) return false;
	}
	return value.preview === void 0 || validPreview(value.preview, 0);
}
function validPreview(value, depth) {
	if (depth > 20 || !record(value) || typeof value.kind !== "string") return false;
	if (value.kind === "scalar") return value.value === null || typeof value.value === "boolean" || typeof value.value === "number" && Number.isFinite(value.value) || typeof value.value === "string" && value.value.length <= 1e5;
	if (value.kind === "redacted") return typeof value.reason === "string" && [
		"secret",
		"server-resource",
		"policy"
	].includes(value.reason);
	if (value.kind === "unavailable") return boundedString(value.reason, 1024);
	if (value.kind === "function") return value.name === void 0 || boundedString(value.name, 128);
	if (value.kind === "dom") return boundedString(value.tag, 64) && (value.id === void 0 || boundedString(value.id, 128)) && Array.isArray(value.classes) && value.classes.length <= 10 && value.classes.every((item) => boundedString(item, 128));
	return value.kind === "object" && boundedString(value.type, 256) && typeof value.truncated === "boolean" && Array.isArray(value.entries) && value.entries.length <= 1e4 && value.entries.every((entry) => record(entry) && boundedString(entry.key, 512) && validPreview(entry.value, depth + 1));
}
function boundedString(value, maximum) {
	return typeof value === "string" && value.length > 0 && value.length <= maximum;
}
function positiveInteger(value) {
	return Number.isSafeInteger(value) && value > 0;
}
function record(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
//#endregion
//#region packages/core/dist/client/json.js
/**
* Compares JSON data structurally without serialization, property-order
* sensitivity, recursion, getter execution, or unbounded work.
*
* Invalid JSON values, sparse arrays, accessors, cycles, and values exceeding
* the comparison budget fail closed.
*/
function sameJsonData(left, right, options = {}) {
	const maxComparisons = options.maxComparisons ?? 1e5;
	if (!Number.isSafeInteger(maxComparisons) || maxComparisons < 1) return false;
	const pending = [{
		kind: "compare",
		left,
		right
	}];
	const activeLeft = /* @__PURE__ */ new WeakSet();
	const activeRight = /* @__PURE__ */ new WeakSet();
	const completedLeft = /* @__PURE__ */ new WeakMap();
	let compared = 0;
	while (pending.length) {
		const comparison = pending.pop();
		const currentLeft = comparison.left;
		const currentRight = comparison.right;
		if (comparison.kind === "complete") {
			activeLeft.delete(currentLeft);
			activeRight.delete(currentRight);
			const matches = completedLeft.get(currentLeft) ?? /* @__PURE__ */ new WeakSet();
			matches.add(currentRight);
			completedLeft.set(currentLeft, matches);
			continue;
		}
		if (++compared > maxComparisons) return false;
		if (!isJsonObject(currentLeft) || !isJsonObject(currentRight)) {
			if (!isJsonScalar(currentLeft) || !isJsonScalar(currentRight) || !Object.is(currentLeft, currentRight)) return false;
			continue;
		}
		if (Array.isArray(currentLeft) !== Array.isArray(currentRight)) return false;
		if (completedLeft.get(currentLeft)?.has(currentRight)) continue;
		if (activeLeft.has(currentLeft) || activeRight.has(currentRight)) return false;
		activeLeft.add(currentLeft);
		activeRight.add(currentRight);
		pending.push({
			kind: "complete",
			left: currentLeft,
			right: currentRight
		});
		if (Array.isArray(currentLeft)) {
			const rightArray = currentRight;
			if (currentLeft.length !== rightArray.length) return false;
			if (Object.getOwnPropertySymbols(currentLeft).some((symbol) => Object.prototype.propertyIsEnumerable.call(currentLeft, symbol)) || Object.getOwnPropertySymbols(rightArray).some((symbol) => Object.prototype.propertyIsEnumerable.call(rightArray, symbol))) return false;
			if (Object.keys(currentLeft).some((key) => !isArrayIndexKey(key, currentLeft.length)) || Object.keys(rightArray).some((key) => !isArrayIndexKey(key, rightArray.length))) return false;
			for (let index = currentLeft.length - 1; index >= 0; index--) {
				const leftDescriptor = Object.getOwnPropertyDescriptor(currentLeft, index);
				const rightDescriptor = Object.getOwnPropertyDescriptor(rightArray, index);
				if (!leftDescriptor || !rightDescriptor || !("value" in leftDescriptor) || !("value" in rightDescriptor)) return false;
				pending.push({
					kind: "compare",
					left: leftDescriptor.value,
					right: rightDescriptor.value
				});
			}
			continue;
		}
		if (!isPlainJsonObject(currentLeft) || !isPlainJsonObject(currentRight)) return false;
		const leftDescriptors = Object.getOwnPropertyDescriptors(currentLeft);
		const rightDescriptors = Object.getOwnPropertyDescriptors(currentRight);
		if (Object.getOwnPropertySymbols(currentLeft).some((symbol) => Object.prototype.propertyIsEnumerable.call(currentLeft, symbol)) || Object.getOwnPropertySymbols(currentRight).some((symbol) => Object.prototype.propertyIsEnumerable.call(currentRight, symbol))) return false;
		const leftKeys = Object.keys(leftDescriptors).filter((key) => leftDescriptors[key].enumerable).sort();
		const rightKeys = Object.keys(rightDescriptors).filter((key) => rightDescriptors[key].enumerable).sort();
		if (leftKeys.length !== rightKeys.length || leftKeys.some((key, index) => key !== rightKeys[index])) return false;
		for (let index = leftKeys.length - 1; index >= 0; index--) {
			const key = leftKeys[index];
			const leftDescriptor = leftDescriptors[key];
			const rightDescriptor = rightDescriptors[key];
			if (!("value" in leftDescriptor) || !("value" in rightDescriptor)) return false;
			pending.push({
				kind: "compare",
				left: leftDescriptor.value,
				right: rightDescriptor.value
			});
		}
	}
	return true;
}
function isJsonObject(value) {
	return value !== null && typeof value === "object";
}
function isJsonScalar(value) {
	return value === null || typeof value === "boolean" || typeof value === "string" || typeof value === "number" && Number.isFinite(value);
}
function isPlainJsonObject(value) {
	const prototype = Object.getPrototypeOf(value);
	return prototype === Object.prototype || prototype === null;
}
function isArrayIndexKey(key, length) {
	const index = Number(key);
	return Number.isInteger(index) && index >= 0 && index < length && String(index) === key;
}
//#endregion
//#region packages/core/dist/client/url.js
var javascriptProtocol = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
var urlAttributes = /* @__PURE__ */ new Set([
	"action",
	"formaction",
	"href",
	"src",
	"xlink:href",
	"xlinkhref"
]);
/** Provides the canonical blocked javascript url value. */
var BLOCKED_JAVASCRIPT_URL = "javascript:throw new Error('eXact has blocked a javascript: URL as a security precaution.')";
/** Reports whether url attribute. */
function isUrlAttribute(name) {
	return urlAttributes.has(name.toLowerCase());
}
/** Applies the native eXact URL policy to one JSX/DOM attribute value. */
function sanitizeUrlAttribute(name, value) {
	if (!isUrlAttribute(name) || value === null || value === void 0) return value;
	const text = String(value);
	return javascriptProtocol.test(text) ? BLOCKED_JAVASCRIPT_URL : value;
}
//#endregion
//#region packages/dom/dist/client/namespace.js
/** Provides the canonical html namespace value. */
var HTML_NAMESPACE = "http://www.w3.org/1999/xhtml";
/** Provides the canonical svg namespace value. */
var SVG_NAMESPACE = "http://www.w3.org/2000/svg";
/** Provides the canonical mathml namespace value. */
var MATHML_NAMESPACE = "http://www.w3.org/1998/Math/MathML";
/** Resolves the namespace for an intrinsic child, including HTML integration points. */
function namespaceForTag(tag, parent) {
	if (tag === "svg") return SVG_NAMESPACE;
	if (tag === "math") return MATHML_NAMESPACE;
	if (!parent) return void 0;
	const inherited = parent.namespaceURI;
	if (inherited === "http://www.w3.org/2000/svg") return parent.localName === "foreignObject" ? void 0 : SVG_NAMESPACE;
	if (inherited !== "http://www.w3.org/1998/Math/MathML") return void 0;
	if ([
		"mi",
		"mo",
		"mn",
		"ms",
		"mtext"
	].includes(parent.localName) && tag !== "mglyph" && tag !== "malignmark") return void 0;
	if (parent.localName === "annotation-xml") {
		const encoding = parent.getAttribute("encoding")?.toLowerCase();
		if (encoding === "text/html" || encoding === "application/xhtml+xml") return void 0;
	}
	return MATHML_NAMESPACE;
}
//#endregion
//#region packages/dom/dist/client/debug.js
/** Emits a DOM patch trace event through the root logger. */
function domDebug(root, message, details) {
	logFrameworkEvent("trace", "dom", "patch", message, details, root.logger);
}
/** Produces a compact human-readable description of a DOM node for logs. */
function describeNode(node) {
	if (!node) return "none";
	if (node instanceof Element) {
		const id = node.id ? `#${node.id}` : "";
		const className = typeof node.className === "string" && node.className ? `.${node.className.split(/\s+/).filter(Boolean).join(".")}` : "";
		return `${node.tagName.toLowerCase()}${id}${className}`;
	}
	return node.nodeName;
}
//#endregion
//#region packages/dom/dist/client/focus.js
/** Runs DOM work and restores a user-focused element if patching drops focus to the document body. */
function preserveFocus(root, work) {
	if (root.focusTransactionDepth > 0) {
		root.focusTransactionDepth++;
		try {
			return work();
		} finally {
			root.focusTransactionDepth--;
		}
	}
	root.focusTransactionDepth = 1;
	root.focusSnapshot = captureFocus();
	try {
		const result = work();
		restoreFocus(root, root.focusSnapshot);
		return result;
	} finally {
		root.focusSnapshot = void 0;
		root.focusTransactionDepth = 0;
	}
}
/** Captures the one authored focus owner shared by a complete DOM transaction. */
function captureFocus() {
	const active = document.activeElement;
	if (!(active instanceof HTMLElement) || active === document.body) return void 0;
	return {
		active,
		inputSelection: active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement ? {
			start: active.selectionStart,
			end: active.selectionEnd,
			direction: active.selectionDirection
		} : void 0,
		documentSelection: active.isContentEditable ? cloneSelection(active) : void 0
	};
}
/** Restores the focus snapshot once, after all nested reconciliation work completes. */
function restoreFocus(root, snapshot) {
	if (!snapshot) return;
	const { active, inputSelection, documentSelection } = snapshot;
	if (active.isConnected && document.activeElement === document.body) {
		domDebug(root, "restore focus", () => ({
			active: describeNode(active),
			bodyOwnsFocus: document.activeElement === document.body
		}));
		active.focus({ preventScroll: true });
	}
	if (active.isConnected && document.activeElement === active) {
		if (inputSelection && (active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement) && inputSelection.start !== null && inputSelection.end !== null) active.setSelectionRange(inputSelection.start, inputSelection.end, inputSelection.direction ?? void 0);
		else if (documentSelection) restoreSelection(active, documentSelection);
	}
}
function cloneSelection(root) {
	const selection = document.getSelection();
	if (!selection?.rangeCount) return void 0;
	const range = selection.getRangeAt(0);
	if (!root.contains(range.startContainer) || !root.contains(range.endContainer)) return void 0;
	return {
		start: pathFrom(root, range.startContainer),
		startOffset: range.startOffset,
		end: pathFrom(root, range.endContainer),
		endOffset: range.endOffset
	};
}
function restoreSelection(root, saved) {
	const start = nodeFrom(root, saved.start);
	const end = nodeFrom(root, saved.end);
	if (!start || !end) return;
	try {
		const range = document.createRange();
		range.setStart(start, Math.min(saved.startOffset, maxOffset(start)));
		range.setEnd(end, Math.min(saved.endOffset, maxOffset(end)));
		const selection = document.getSelection();
		selection?.removeAllRanges();
		selection?.addRange(range);
	} catch {}
}
function pathFrom(root, node) {
	const result = [];
	for (let cursor = node; cursor && cursor !== root; cursor = cursor.parentNode) {
		if (!cursor.parentNode) return [];
		result.unshift(Array.prototype.indexOf.call(cursor.parentNode.childNodes, cursor));
	}
	return result;
}
function nodeFrom(root, path) {
	let node = root;
	for (const index of path) node = node?.childNodes[index];
	return node;
}
function maxOffset(node) {
	return node.nodeType === Node.TEXT_NODE ? node.textContent?.length ?? 0 : node.childNodes.length;
}
//#endregion
//#region packages/dom/dist/client/state.js
var exactDomRuntimeStateKey = Symbol.for("@exactjs/dom.runtime-state");
var runtimeState = (() => {
	const scope = globalThis;
	return scope[exactDomRuntimeStateKey] ??= {
		roots: /* @__PURE__ */ new WeakMap(),
		eventHandlers: /* @__PURE__ */ new WeakMap(),
		directEventHandlers: /* @__PURE__ */ new WeakMap(),
		elementOwners: /* @__PURE__ */ new WeakMap(),
		nodeOwners: /* @__PURE__ */ new WeakMap(),
		propBindings: /* @__PURE__ */ new WeakMap(),
		componentMounts: /* @__PURE__ */ new WeakMap(),
		inspectableRoots: /* @__PURE__ */ new Set(),
		rootInspectionReferences: /* @__PURE__ */ new WeakMap()
	};
})();
/** Renderer roots shared by every loaded copy of the DOM package in this JavaScript realm. */
var roots$1 = runtimeState.roots;
/** Delegated event handlers shared by every loaded copy of the DOM package. */
var eventHandlers = runtimeState.eventHandlers;
/** Direct event handlers shared by every loaded copy of the DOM package. */
var directEventHandlers = runtimeState.directEventHandlers;
/** Element ownership shared with inspection and compatibility package copies. */
var elementOwners = runtimeState.elementOwners;
/** Marker and text ownership shared with inspection and compatibility package copies. */
var nodeOwners = runtimeState.nodeOwners;
/** Reactive property bindings shared by every loaded copy of the DOM package. */
var propBindings = runtimeState.propBindings;
/** Component mount ranges shared with inspection and compatibility package copies. */
var componentMounts = runtimeState.componentMounts;
/** Returns the explicitly installed owner for a newly created renderer root. */
function exactDomInspectionOwner(options = {}) {
	return runtimeState.inspectionOwnerFactory?.(options);
}
/** Registers one active root for bounded late-attachment inspection. */
function registerInspectableRoot(root) {
	if (runtimeState.rootInspectionReferences.has(root)) return;
	const reference = new WeakRef(root);
	runtimeState.rootInspectionReferences.set(root, reference);
	runtimeState.inspectableRoots.add(reference);
}
/** Removes one disposed root from future late-attachment snapshots. */
function unregisterInspectableRoot(root) {
	const reference = runtimeState.rootInspectionReferences.get(root);
	if (!reference) return;
	runtimeState.inspectableRoots.delete(reference);
	runtimeState.rootInspectionReferences.delete(root);
}
//#endregion
//#region packages/dom/dist/client/ownership.js
/** Associates a DOM element with the component instance that rendered it. */
function setElementOwner(element, owner) {
	elementOwners.set(element, owner);
}
/** Removes the component ownership association for a DOM element. */
function clearElementOwner(element) {
	elementOwners.delete(element);
}
/** Associates a framework marker or text node with its logical component owner. */
function setNodeOwner(node, owner) {
	nodeOwners.set(node, owner);
}
/** Removes the logical ownership association for a framework marker or text node. */
function clearNodeOwner(node) {
	nodeOwners.delete(node);
}
/** Finds the closest component instance that owns an element or one of its ancestors. */
function findOwnerInstance(element) {
	let cursor = element;
	while (cursor) {
		const owner = elementOwners.get(cursor);
		if (owner) return owner;
		cursor = cursor.parentElement;
	}
}
/** Finds the closest logical component owner for any DOM node. */
function findNodeOwnerInstance(node) {
	let cursor = node;
	while (cursor) {
		const direct = nodeOwners.get(cursor);
		if (direct) return direct;
		if (cursor instanceof Element) {
			const element = elementOwners.get(cursor);
			if (element) return element;
		}
		cursor = cursor.parentNode;
	}
}
//#endregion
//#region packages/dom/dist/client/events.js
var eventGenerations = /* @__PURE__ */ new WeakMap();
var DIRECT_EVENTS = /* @__PURE__ */ new Set([
	"abort",
	"blur",
	"cancel",
	"canplay",
	"canplaythrough",
	"close",
	"cuechange",
	"durationchange",
	"emptied",
	"ended",
	"error",
	"focus",
	"gotpointercapture",
	"invalid",
	"load",
	"loadeddata",
	"loadedmetadata",
	"loadstart",
	"lostpointercapture",
	"mouseenter",
	"mouseleave",
	"pause",
	"play",
	"playing",
	"pointerenter",
	"pointerleave",
	"progress",
	"ratechange",
	"resize",
	"scroll",
	"seeked",
	"seeking",
	"stalled",
	"suspend",
	"timeupdate",
	"toggle",
	"volumechange",
	"waiting"
]);
/** Returns whether ordinary DOM semantics require a listener on the target element. */
function requiresDirectListener(type) {
	return DIRECT_EVENTS.has(type);
}
/** Ensures a delegated event listener exists for a root/type pair. */
function ensureDelegated(root, type, container = root.container) {
	let listeners = root.delegated.get(container);
	if (!listeners) {
		listeners = /* @__PURE__ */ new Map();
		root.delegated.set(container, listeners);
	}
	if (listeners.has(type)) return;
	const listener = (event) => {
		dispatchEventPath(event, container, (cursor) => {
			const binding = eventHandlers.get(cursor)?.get(type);
			if (binding) {
				const handler = binding[0];
				const flags = binding[1];
				const current = cursor;
				const closed = (flags & 2) !== 0;
				preserveFocus(root, () => {
					try {
						const owner = findOwnerInstance(current);
						observeComponentAsync(owner, runInteractiveEvent(root, owner, () => closed ? handler.call(current) : callDelegatedHandler(handler, current, event), (flags & 1) !== 0), "event", type);
					} catch (error) {
						const owner = findOwnerInstance(current);
						handleComponentError(owner, createErrorReport(error, "event", owner, type));
					}
				});
			}
			return !event.cancelBubble;
		});
	};
	container.addEventListener(type, listener);
	listeners.set(type, listener);
}
/**
* Runs one direct or delegated DOM callback in the owning component interaction.
*
* The caller retains responsibility for the synchronous reactive batch and error observation.
*/
function runEventInteraction(root, owner, work, onScope, direct = false) {
	if (!owner) return work();
	if (direct || !hasComponentTaskOwner(owner)) return runDirectCompiledComponentInteraction(owner, "event", nextEventGeneration, "interactive", work, onScope, compiledInteractionTrace(root));
	return runComponentInteraction(owner, "event", nextEventGeneration(owner), "interactive", new AbortController(), (scope) => {
		onScope?.(scope);
		return work();
	});
}
/** Publishes one event transaction and applies its interactive consequences before returning. */
function runInteractiveEvent(root, owner, work, direct = false) {
	let interaction;
	const useLazyInteraction = owner !== void 0 && !hasComponentTaskOwner(owner);
	try {
		const result = runWithPriority("interactive", () => (direct ? publishBatch : batch)(() => owner ? direct || useLazyInteraction ? runDirectCompiledComponentInteraction(owner, "event", nextEventGeneration, "interactive", work, (scope) => {
			interaction = scope;
			root.interactionWork = {
				reconciliations: 0,
				traversedNodes: 0
			};
		}, compiledInteractionTrace(root)) : runCompiledComponentInteraction(owner, "event", nextEventGeneration(owner), "interactive", new AbortController(), work, (scope) => {
			interaction = scope;
			root.interactionWork = {
				reconciliations: 0,
				traversedNodes: 0
			};
		}, compiledInteractionTrace(root)) : work()));
		traceInteractionPhase(interaction, "handler-complete");
		flushSync("interactive");
		traceInteractionPhase(interaction, "feedback-committed", () => ({
			reconciliations: root.interactionWork?.reconciliations ?? 0,
			traversedNodes: root.interactionWork?.traversedNodes ?? 0
		}));
		return result;
	} finally {
		root.interactionWork = void 0;
	}
}
/** Skips generic trace discovery when one shared root logger proves trace logging is disabled. */
function compiledInteractionTrace(root) {
	const logging = root.componentLogging;
	return logging && !logging.componentOverride && logging.logger === void 0 ? false : void 0;
}
/** Converts JSX's DOM-style handler names to platform event names and capture mode. */
function eventTypeForProp(key) {
	const pointerCaptureLifecycle = key === "onLostPointerCapture" || key === "onGotPointerCapture";
	const capture = key.endsWith("Capture") && !pointerCaptureLifecycle;
	const name = key.slice(2, capture ? -7 : void 0);
	return {
		type: {
			DoubleClick: "dblclick",
			FocusIn: "focusin",
			FocusOut: "focusout"
		}[name] ?? name.toLowerCase(),
		capture
	};
}
function nextEventGeneration(owner) {
	const generation = (eventGenerations.get(owner) ?? 0) + 1;
	eventGenerations.set(owner, generation);
	return generation;
}
/** Removes every event listener delegated through a renderer root. */
function clearDelegated(root) {
	for (const [container, listeners] of root.delegated) for (const [type, listener] of listeners) container.removeEventListener(type, listener);
	root.delegated.clear();
	root.portalTargets.clear();
}
/** Dispatches an event path without copying the browser's composed-path array. */
function dispatchEventPath(event, container, visit) {
	const native = typeof event.composedPath === "function" ? event.composedPath() : [];
	const containerIndex = native.indexOf(container);
	if (containerIndex >= 0) {
		for (let index = 0; index <= containerIndex; index++) {
			const target = native[index];
			if (target instanceof Element && !visit(target)) return;
		}
		return;
	}
	let cursor = eventTargetElement$1(event.target);
	while (cursor) {
		if (!visit(cursor)) return;
		if (cursor === container) break;
		cursor = cursor.parentElement;
	}
}
function callDelegatedHandler(handler, current, event) {
	const ownDescriptor = Object.getOwnPropertyDescriptor(event, "currentTarget");
	Object.defineProperty(event, "currentTarget", {
		configurable: true,
		value: current
	});
	try {
		return handler.call(current, event);
	} finally {
		if (ownDescriptor) Object.defineProperty(event, "currentTarget", ownDescriptor);
		else delete event.currentTarget;
	}
}
function eventTargetElement$1(target) {
	if (target instanceof Element) return target;
	if (target instanceof Node) return target.parentElement;
	return null;
}
//#endregion
//#region packages/dom/dist/client/modal/capability.js
var modalBindingCapability;
/** Returns modal binding support when this artifact contains it. */
function getModalBindingCapability() {
	return modalBindingCapability;
}
//#endregion
//#region packages/dom/dist/client/prop-binding-ownership.js
/** Stops and forgets one reactive property binding before its value is replaced. */
function clearPropBinding(element, key) {
	const bindings = propBindings.get(element);
	if (!bindings) return;
	const stop = bindings.get(key);
	if (!stop) return;
	stop();
	bindings.delete(key);
}
/** Forgets a binding whose external capability already performed its own cleanup. */
function releasePropBinding(element, key) {
	const bindings = propBindings.get(element);
	bindings?.delete(key);
	if (bindings && bindings.size === 0) propBindings.delete(element);
}
/** Retains one property cleanup under its owning element and compiler property key. */
function setPropBinding(element, key, stop) {
	let bindings = propBindings.get(element);
	if (!bindings) {
		bindings = /* @__PURE__ */ new Map();
		propBindings.set(element, bindings);
	}
	bindings.set(key, stop);
}
/** Converts a camelCase style property name to its CSS property spelling. */
function toCssProperty(name) {
	return name.replace(/[A-Z]/g, (match) => `-${match.toLowerCase()}`);
}
/**
* Applies string or object styles and retains diff state only while reactive dependencies exist.
*
* Object-property collections are created on first object output and released when output changes
* to a string or absent value.
*/
function bindStyle(element, value, scope, onRelease) {
	let previousNames;
	let previousCssText;
	let previousValues;
	return watchRetained(() => {
		const actual = unwrap(value);
		if (actual === false || actual === null || actual === void 0) {
			if (element.hasAttribute("style")) element.removeAttribute("style");
			previousNames = void 0;
			previousCssText = void 0;
			previousValues = void 0;
			return;
		}
		if (typeof actual === "string") {
			if (previousCssText !== actual || element.style.cssText !== actual) element.style.cssText = actual;
			previousNames = void 0;
			previousCssText = actual;
			previousValues = void 0;
			return;
		}
		if (!actual || typeof actual !== "object") {
			if (element.hasAttribute("style")) element.removeAttribute("style");
			previousNames = void 0;
			previousCssText = void 0;
			previousValues = void 0;
			return;
		}
		previousCssText = void 0;
		const oldNames = previousNames;
		const oldValues = previousValues ??= /* @__PURE__ */ new Map();
		const nextNames = /* @__PURE__ */ new Set();
		for (const [name, rawValue] of Object.entries(actual)) {
			const styleValue = unwrap(rawValue);
			const property = toCssProperty(name);
			nextNames.add(property);
			if (styleValue === null || styleValue === void 0 || styleValue === false) {
				if (oldValues.has(property) || element.style.getPropertyValue(property)) element.style.removeProperty(property);
				oldValues.delete(property);
			} else {
				const nextValue = String(styleValue);
				if (oldValues.get(property) !== nextValue || element.style.getPropertyValue(property) !== nextValue) element.style.setProperty(property, nextValue);
				oldValues.set(property, nextValue);
			}
		}
		for (const name of oldNames ?? []) if (!nextNames.has(name)) {
			element.style.removeProperty(name);
			oldValues.delete(name);
		}
		previousNames = nextNames;
	}, void 0, {
		scope,
		onRelease
	});
}
//#endregion
//#region packages/dom/dist/client/renderer/foreign-child-capability.js
var registryKey$2 = Symbol.for("@exactjs/dom.foreign-child-capability.v1");
function registry$1() {
	const realm = globalThis;
	const current = realm[registryKey$2];
	if (current !== void 0) {
		if (!current || typeof current !== "object" || current.abi !== 1) throw new Error("Incompatible eXact DOM foreign-child capability registry");
		return current;
	}
	const created = { abi: 1 };
	realm[registryKey$2] = created;
	return created;
}
/** Returns the optional foreign child interpreter without making it part of native execution. */
function foreignChildCapability() {
	return registry$1().capability;
}
/** Lets an explicitly installed foreign interpreter prepare its own render-program values. */
function prepareForeignProgramChildren(values) {
	return foreignChildCapability()?.prepareProgramChildren?.(values) ?? values;
}
//#endregion
//#region packages/dom/dist/client/props.js
/** Applies prop changes to a DOM element, including reactive bindings and delegated events. */
function updateProps(root, element, previous, next, scope, preserveUserFocus = true) {
	const apply = () => {
		for (const key of Object.keys(previous)) if (!(key in next)) setElementProp(root, element, key, void 0, previous[key], scope);
		for (const [key, value] of Object.entries(next)) if (!Object.is(previous[key], value)) setElementProp(root, element, key, value, previous[key], scope);
	};
	if (preserveUserFocus) preserveFocus(root, apply);
	else apply();
}
/** Stops reactive prop bindings and removes delegated event handlers for an element. */
function clearElementProps(element) {
	for (const stop of propBindings.get(element)?.values() ?? []) stop();
	propBindings.delete(element);
	eventHandlers.delete(element);
	for (const entry of directEventHandlers.get(element)?.values() ?? []) element.removeEventListener(entry.type, entry.listener, entry.capture);
	directEventHandlers.delete(element);
}
/**
* Publishes one adopted dirty control through its compiler-owned binding without synthesizing an
* authored DOM event.
*/
function synchronizeFormBinding(element) {
	const entries = directEventHandlers.get(element);
	const entry = entries?.get("__exactBindInput") ?? entries?.get("__exactBindChange") ?? entries?.get("__exactBindToggle") ?? entries?.get("__exactBindModalToggle") ?? entries?.get("__exactBindModalClose");
	if (!entry) return false;
	const event = new Event(entry.type, {
		bubbles: false,
		cancelable: false
	});
	Object.defineProperties(event, {
		target: {
			configurable: true,
			value: element
		},
		currentTarget: {
			configurable: true,
			value: element
		}
	});
	entry.listener(event);
	return true;
}
/** Applies one already-diffed property for compiler-owned and generic DOM lanes. */
function setElementProp(root, element, key, value, previous, scope) {
	if (key === "children") return;
	if (key === "dangerouslySetInnerHTML") throw new Error("Native eXact does not support dangerouslySetInnerHTML; use unsafeHtml() with explicit root opt-in.");
	clearPropBinding(element, key);
	if (key === "ref") {
		if (previous && previous !== value) previous.fulfill(void 0);
		if (value) attachElementIdentity(value, element);
		value?.fulfill(element);
		return;
	}
	if (isCompilerFormBindingProp(key)) {
		setDirectEventHandler(root, element, key, key === "__exactBindInput" ? "input" : key === "__exactBindToggle" || key === "__exactBindModalToggle" ? "toggle" : key === "__exactBindModalClose" ? "close" : "change", value, false);
		return;
	}
	if (key === "__exactModalOpen") {
		if (value === void 0) return;
		const capability = getModalBindingCapability();
		if (!capability) throw new Error("Modal binding is unavailable because this artifact did not include the modal capability");
		const stop = capability.bind(element, value, scope, () => releasePropBinding(element, key));
		if (stop) setPropBinding(element, key, stop);
		return;
	}
	const closedInteraction = key.startsWith("__exactClosedInteraction:");
	const directInteraction = closedInteraction || key.startsWith("__exactDirectInteraction:");
	const eventKey = authoredEventKey(key);
	if (/^on[A-Z]/.test(eventKey)) {
		const { type, capture } = eventTypeForProp(eventKey);
		if (closedInteraction || capture || requiresDirectListener(type)) {
			setDirectEventHandler(root, element, key, type, value, capture, directInteraction, closedInteraction);
			return;
		}
		let handlers = eventHandlers.get(element);
		if (!handlers) {
			handlers = /* @__PURE__ */ new Map();
			eventHandlers.set(element, handlers);
		}
		if (typeof value === "function") {
			const handler = value;
			const flags = (directInteraction ? 1 : 0) | (closedInteraction ? 2 : 0);
			const current = handlers.get(type);
			if (!current || current[0] !== handler || current[1] !== flags) handlers.set(type, [handler, flags]);
			ensureDelegated(root, type, eventContainerFor(root, element));
		} else handlers.delete(type);
		return;
	}
	if (key === "style") {
		if (previous !== value) element.removeAttribute("style");
		const stop = bindStyle(element, value, scope, () => releasePropBinding(element, key));
		if (stop) setPropBinding(element, key, stop);
		return;
	}
	clearPropBinding(element, key);
	if (!propMayObserveReactiveValue(key, value)) {
		applyPropValue(root, element, key, value);
		return;
	}
	const stop = watchRetained(() => preserveFocus(root, () => applyPropValue(root, element, key, value)), void 0, {
		scope,
		onRelease: () => releasePropBinding(element, key)
	});
	if (stop) setPropBinding(element, key, stop);
}
function authoredEventKey(key) {
	if (key.startsWith("__exactClosedInteraction:")) return key.slice(25);
	if (key.startsWith("__exactDirectInteraction:")) return key.slice(25);
	return key;
}
/** Identifies compiler-owned native-control bindings that enhancements must preserve verbatim. */
function isCompilerFormBindingProp(key) {
	return key === "__exactBindInput" || key === "__exactBindChange" || key === "__exactBindToggle" || key === "__exactBindModalToggle" || key === "__exactBindModalClose";
}
/** Applies one ordinary prop after the caller has selected static or observed execution. */
function applyPropValue(root, element, key, value) {
	const actual = unwrap(value);
	if (actual === false || actual === null || actual === void 0) {
		clearDomProp(element, key);
		return;
	}
	setDomProp(root, element, key, sanitizeUrlAttribute(key, key === "srcdoc" || key === "srcDoc" ? unsafeHtmlAttribute(root, actual) : key === "class" || key === "className" ? normalizeClassValue(actual) : actual));
}
/** Reports props whose supported value shape can contain compiler reactive expressions. */
function propMayObserveReactiveValue(key, value) {
	if (isReactiveValue(value)) return true;
	if (key === "class" || key === "className") return typeof value === "object" && value !== null;
	return (key === "srcdoc" || key === "srcDoc") && isReactiveValue(unsafeHtmlValue(value)?.value);
}
function setDirectEventHandler(root, element, key, type, value, capture, directInteraction = false, closedInteraction = false) {
	const previous = directEventHandlers.get(element)?.get(key);
	if (previous) {
		element.removeEventListener(previous.type, previous.listener, previous.capture);
		const direct = directEventHandlers.get(element);
		direct?.delete(key);
		if (direct && !direct.size) directEventHandlers.delete(element);
	}
	if (typeof value !== "function") return;
	const handler = value;
	const listener = (event) => preserveFocus(root, () => {
		try {
			const owner = findOwnerInstance(element);
			const invoke = () => closedInteraction ? handler.call(element) : handler.call(element, event);
			observeComponentAsync(owner, closedInteraction ? runInteractiveEvent(root, owner, invoke, true) : batch(() => runEventInteraction(root, owner, invoke, void 0, directInteraction)), "event", type);
		} catch (error) {
			const owner = findOwnerInstance(element);
			handleComponentError(owner, createErrorReport(error, "event", owner, type));
		}
	});
	const entry = {
		type,
		listener,
		capture
	};
	let direct = directEventHandlers.get(element);
	if (!direct) {
		direct = /* @__PURE__ */ new Map();
		directEventHandlers.set(element, direct);
	}
	direct.set(key, entry);
	element.addEventListener(type, listener, capture);
}
function eventContainerFor(root, element) {
	if (root.eventContainer) return root.eventContainer;
	if (root.container.contains(element)) return root.container;
	for (const target of root.portalTargets) if (target.contains(element)) return target;
	return root.container;
}
/** Applies one non-reactive property using the same semantics as JSX bindings. */
function applyDomProp(element, key, value) {
	if (key === "dangerouslySetInnerHTML") throw new Error("Native eXact does not support dangerouslySetInnerHTML; use unsafeHtml() with explicit root opt-in.");
	if ((key === "srcdoc" || key === "srcDoc") && value !== null && value !== void 0) throw new Error("Native eXact srcdoc patches require an unsafeHtml() capability owned by a render root.");
	if (value === false || value === null || value === void 0) clearDomProp(element, key);
	else setDomProp(void 0, element, key, sanitizeUrlAttribute(key, value));
}
function unsafeHtmlAttribute(root, value) {
	const receipt = readUnsafeHtmlReceipt(value);
	const foreign = receipt ? void 0 : unsafeHtmlValue(value);
	if (!receipt && !foreign) throw new Error("Native eXact iframe srcdoc requires unsafeHtml() and explicit allowUnsafeHtml root opt-in.");
	if (!root.allowUnsafeHtml) throw new Error("unsafeHtml() used for iframe srcdoc requires allowUnsafeHtml: true on the native eXact render or hydration root.");
	const html = String(unwrap(receipt?.value ?? foreign?.value) ?? "");
	root.onUnsafeHtml?.({ characters: html.length });
	return html;
}
/** Reads unsafe HTML only through the explicitly installed compatibility interpreter. */
function unsafeHtmlValue(value) {
	return foreignChildCapability()?.unsafeHtmlValue?.(value);
}
function setDomProp(root, element, key, value) {
	const property = normalizePropName(key);
	if (property === "defaultValue" && isFocusedTextControl(element)) {
		if (root) domDebug(root, "skip focused defaultValue", () => ({
			element: describeNode(element),
			value
		}));
		return;
	}
	if (property in element) try {
		const record = element;
		if (property === "value" && element instanceof HTMLSelectElement && element.multiple) {
			const selected = new Set(Array.isArray(value) ? value.map(String) : value == null ? [] : [String(value)]);
			for (const option of Array.from(element.options)) if (option.selected !== selected.has(option.value)) option.selected = selected.has(option.value);
			return;
		}
		if (property === "value" && element instanceof HTMLInputElement && value instanceof Date) {
			const next = Number.isNaN(value.getTime()) ? null : value;
			if ((element.valueAsDate?.getTime() ?? null) !== (next?.getTime() ?? null)) element.valueAsDate = next;
			return;
		}
		if (Object.is(record[property], value)) {
			syncBooleanAttribute(element, property, value);
			return;
		}
		if (property === "value" || property === "defaultValue") {
			if (root) domDebug(root, "set form value prop", () => ({
				element: describeNode(element),
				property,
				active: describeNode(document.activeElement),
				value
			}));
		}
		record[property] = value;
		syncBooleanAttribute(element, property, value);
		return;
	} catch {}
	const attributeValue = String(value);
	if (element.getAttribute(property) !== attributeValue) element.setAttribute(property, attributeValue);
}
function syncBooleanAttribute(element, property, value) {
	if (typeof value !== "boolean") return;
	if (value) {
		if (!element.hasAttribute(property)) element.setAttribute(property, "");
	} else if (element.hasAttribute(property)) element.removeAttribute(property);
}
function clearDomProp(element, key) {
	const property = normalizePropName(key);
	if (property in element) {
		const current = element[property];
		try {
			if (typeof current === "boolean") {
				if (current) element[property] = false;
			} else if (typeof current === "string") {
				if (current !== "") element[property] = "";
			}
		} catch {}
	}
	element.removeAttribute(property);
}
function normalizePropName(key) {
	if (key === "className") return "class";
	if (key === "commandFor") return "commandfor";
	return key;
}
function isFocusedTextControl(element) {
	return document.activeElement === element && (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement);
}
//#endregion
//#region packages/dom/dist/client/framework/hydration.js
/** Reads and validates the partition discriminator encoded on an SSR marker element. */
function readExactPartitionDiscriminator(marker) {
	const kind = marker.getAttribute("data-exact-partition-discriminator");
	if (kind === "single") return Object.freeze({ kind });
	if (kind === "branch") {
		const branch = marker.getAttribute("data-exact-partition-branch");
		return branch ? Object.freeze({
			kind,
			branch
		}) : void 0;
	}
	if (kind === "keyed") {
		const list = marker.getAttribute("data-exact-partition-list");
		const keyToken = marker.getAttribute("data-exact-partition-key");
		return list && keyToken ? Object.freeze({
			kind,
			list,
			keyToken
		}) : void 0;
	}
}
//#endregion
//#region packages/dom/dist/client/work.js
/** Provides the canonical default dom work limit value. */
var DEFAULT_DOM_WORK_LIMIT = 1e5;
/** Creates a dom work budget. */
function createDomWorkBudget(maxNodes) {
	return {
		limit: Number.isSafeInteger(maxNodes) && maxNodes > 0 ? maxNodes : DEFAULT_DOM_WORK_LIMIT,
		used: 0
	};
}
/** Performs the consume dom work domain operation. */
function consumeDomWork(budget) {
	if (++budget.used > budget.limit) throw new DomTraversalLimitError(budget.limit);
}
/** Reserves a known amount of work without allowing a partially consumed reservation. */
function reserveDomWork(budget, amount) {
	if (!Number.isSafeInteger(amount) || amount < 0) throw new RangeError("DOM work reservation must be a non-negative safe integer");
	if (amount > budget.limit - budget.used) throw new DomTraversalLimitError(budget.limit);
	budget.used += amount;
}
/** Represents a failure raised by dom traversal limit. */
var DomTraversalLimitError = class extends Error {
	limit;
	constructor(limit) {
		super(`eXact DOM traversal exceeds the configured maximum of ${limit} nodes`);
		this.limit = limit;
		this.name = "DomTraversalLimitError";
	}
};
/** Iterates an existing DOM subtree with one total, selector-independent budget. */
function walkDomSubtree(root, visit, options = {}) {
	const budget = options.budget ?? createDomWorkBudget(options.maxNodes);
	let visited = 0;
	const accept = (node) => {
		consumeDomWork(budget);
		visited++;
		visit(node);
	};
	if (options.includeRoot !== false) accept(root);
	const ownerDocument = root.nodeType === 9 ? root : root.ownerDocument;
	if (!ownerDocument) throw new Error("Cannot traverse a DOM node without an owner document");
	const walker = ownerDocument.createTreeWalker(root, 4294967295);
	while (walker.nextNode()) accept(walker.currentNode);
	return visited;
}
//#endregion
//#region packages/dom/dist/client/renderer/retained-release.js
var capability$1;
/** Retains a structurally absent range only when its component root is explicitly observed. */
function releaseMountedRange(root, parent, mounted, reason) {
	return capability$1?.release(root, parent, mounted, reason) ?? false;
}
/** Restores a retained root range when the optional capability owns a matching generation. */
function takeReversedRelease(root, parent, next) {
	return capability$1?.reverse(root, parent, next);
}
/** Cancels retained root releases when that capability was installed. */
function disposeRetainedReleases(root) {
	capability$1?.dispose(root);
}
//#endregion
//#region packages/core/dist/client/component/root-lifecycle.js
var componentRoots = /* @__PURE__ */ new WeakMap();
/** Publishes the current renderer-discovered intrinsic root for a component. */
function publishComponentRoot(instance, discovered, presented = true, introduction = "update") {
	const record = rootRecord(instance);
	const selected = record.explicit?.current ?? discovered;
	if (record.state.current !== selected) {
		record.state.current = selected;
		record.state.generation++;
		record.state.introduction = selected ? introduction : void 0;
		record.state.release = void 0;
	}
	record.state.presented = selected !== void 0 && presented;
}
/** Discards root lifecycle state after final component disposal. */
function disposeComponentRoot(instance) {
	const record = componentRoots.get(instance);
	if (record) {
		record.state.current = void 0;
		record.state.introduction = void 0;
		record.state.presented = false;
		record.state.release = void 0;
	}
	componentRoots.delete(instance);
}
/** Retains root history on first publication, deferring reactive machinery until observation. */
function rootRecord(instance) {
	const existing = componentRoots.get(instance);
	if (existing) return existing;
	const record = {
		lifecycle: void 0,
		state: {
			current: void 0,
			generation: 0,
			introduction: void 0,
			presented: false,
			release: void 0
		}
	};
	componentRoots.set(instance, record);
	return record;
}
//#endregion
//#region packages/dom/dist/client/renderer/component-roots.js
/** Publishes the first intrinsic element in the component's current logical output. */
function refreshComponentRoot(instance, presented = true, introduction = "update") {
	const mounted = componentMounts.get(instance);
	const target = mounted ? firstTargetElement(mounted) : void 0;
	const host = mounted ? firstHostElement(mounted) : void 0;
	if (mounted) mounted.componentRootCache = {
		target,
		host
	};
	publishComponentRoot(instance, target ?? host, presented, introduction);
}
function firstTargetElement(mounted) {
	if (mounted.targetReceipt && mounted.targetBoundary?.selected?.dom instanceof Element) return mounted.targetBoundary.selected.dom;
	for (const child of mounted.children) {
		if (child.instance && child.componentRootCache) {
			if (child.componentRootCache.target) return child.componentRootCache.target;
			continue;
		}
		const element = firstTargetElement(child);
		if (element) return element;
	}
}
/** Classifies a newly mounted component root without exposing renderer internals to components. */
function rootIntroduction(root) {
	if (root.initialCommitComplete) return "update";
	return root.mode === "hydrated" || root.mode === "document" ? "hydration" : "initial";
}
/** Releases the private lifecycle record after its owning component has unmounted. */
function disposeMountedComponentRoot(instance) {
	disposeComponentRoot(instance);
}
/** Finds the first intrinsic element while preserving logical traversal through framework ranges. */
function firstHostElement(mounted) {
	if ((mounted.intrinsicReceipt || mounted.renderProgram) && (mounted.renderProgram?.programRoot ?? mounted.dom) instanceof Element) return mounted.renderProgram?.programRoot ?? mounted.dom;
	if (mounted.scalar) return void 0;
	for (const child of mounted.children) {
		if (child.instance && child.componentRootCache) {
			if (child.componentRootCache.host) return child.componentRootCache.host;
			continue;
		}
		const element = firstHostElement(child);
		if (element) return element;
	}
}
//#endregion
//#region packages/dom/dist/client/renderer/target-capability.js
var targetDomCapabilityKey = Symbol.for("@exactjs/dom.target-capability.v1");
function targetDomCapability() {
	return targetCapabilityRegistry().capability;
}
/** Requires Target operation handling selected by the compiler for this artifact. */
function requireTargetDomCapability() {
	const capability = targetDomCapability();
	if (!capability) throw new Error("Target rendering is unavailable because this artifact did not include the DOM capability");
	return capability;
}
function targetCapabilityRegistry() {
	const host = globalThis;
	const current = host[targetDomCapabilityKey];
	if (current !== void 0) {
		if (current.abi !== 1) throw new Error("Incompatible eXact target DOM capability registry");
		return current;
	}
	const created = { abi: 1 };
	host[targetDomCapabilityKey] = created;
	return created;
}
/** Refreshes an emitted Target boundary and fails closed when its capability was not selected. */
function refreshTargetBoundary(root, boundary, owner) {
	const capability = targetDomCapability();
	if (!capability) throw new Error("Target rendering is unavailable because this artifact did not include the DOM capability");
	capability.refreshBoundary(root, boundary, owner);
}
/** Refreshes Target routes affected by a structural change when present. */
function refreshTargetDependents(root, structuralOwner) {
	targetDomCapability()?.refreshDependents(root, structuralOwner);
}
/** Applies ordinary authored props directly unless Target layers are enabled. */
function updateTargetedIntrinsicProps(root, mounted, previous, next) {
	const capability = targetDomCapability();
	if (capability) capability.updateIntrinsic(root, mounted, previous, next);
	else if (mounted.dom instanceof Element) updateProps(root, mounted.dom, previous, next, mounted.scope);
}
/** Releases optional Target-owned intrinsic resources. */
function clearTargetedIntrinsicProps(mounted) {
	targetDomCapability()?.clearIntrinsic(mounted);
}
//#endregion
//#region packages/dom/dist/client/renderer/teardown.js
/** Provides the canonical teardown failure value. */
var teardownFailure = createCleanupFailure;
/** Provides the canonical record teardown failure value. */
var recordTeardownFailure = recordCleanupFailure;
/** Provides the canonical attempt teardown value. */
var attemptTeardown = attemptCleanup;
/** Provides the canonical throw teardown failure value. */
var throwTeardownFailure = throwCleanupFailure;
/** Performs the unmount many domain operation. */
function unmountMany(mounts) {
	const failure = teardownFailure();
	for (const mounted of mounts) attemptTeardown(failure, () => unmountMounted(mounted));
	throwTeardownFailure(failure);
}
/** Releases mounted and its owned resources. */
function disposeMounted(parent, mounted) {
	const failure = teardownFailure();
	attemptTeardown(failure, () => unmountMounted(mounted));
	attemptTeardown(failure, () => removeMountedNodes(parent, mounted));
	throwTeardownFailure(failure);
}
/** Performs the unmount mounted domain operation. */
function unmountMounted(mounted) {
	const pending = [{
		mounted,
		complete: false
	}];
	const failure = teardownFailure();
	while (pending.length) {
		const current = pending.pop();
		if (!current.complete) {
			current.mounted.suspensionRegistration?.cancel();
			current.mounted.suspensionRegistration = void 0;
			attemptTeardown(failure, () => current.mounted.scope.stop());
			pending.push({
				mounted: current.mounted,
				complete: true
			});
			for (let index = (current.mounted.suspense?.candidate?.children.length ?? 0) - 1; index >= 0; index--) pending.push({
				mounted: current.mounted.suspense.candidate.children[index],
				complete: false
			});
			for (let index = current.mounted.children.length - 1; index >= 0; index--) pending.push({
				mounted: current.mounted.children[index],
				complete: false
			});
			continue;
		}
		if (current.mounted.instance) {
			componentMounts.delete(current.mounted.instance);
			attemptTeardown(failure, () => {
				const artifact = current.mounted.clientArtifact;
				if (artifact) artifact.dispose(current.mounted.instance, "dom-unmount");
				else current.mounted.instance.unmount();
			});
			attemptTeardown(failure, () => disposeMountedComponentRoot(current.mounted.instance));
		}
		if (current.mounted.targetBoundary?.release) attemptTeardown(failure, current.mounted.targetBoundary.release);
		if (current.mounted.stop) attemptTeardown(failure, current.mounted.stop);
		if (current.mounted.dom instanceof Element) {
			attemptTeardown(failure, () => clearTargetedIntrinsicProps(current.mounted));
			attemptTeardown(failure, () => clearElementProps(current.mounted.dom));
			attemptTeardown(failure, () => clearElementOwner(current.mounted.dom));
		}
		attemptTeardown(failure, () => clearNodeOwner(current.mounted.dom));
		if (current.mounted.end) attemptTeardown(failure, () => clearNodeOwner(current.mounted.end));
		const ref = current.mounted.intrinsicReceipt?.props.ref;
		if (ref && typeof ref.fulfill === "function") attemptTeardown(failure, () => ref.fulfill(void 0));
	}
	throwTeardownFailure(failure);
}
/** Releases mounted nodes and its owned resources. */
function removeMountedNodes(parent, mounted) {
	const pending = [{
		mounted,
		parent,
		complete: false
	}];
	const failure = teardownFailure();
	while (pending.length) {
		const current = pending.pop();
		if (!current.complete) {
			pending.push({
				...current,
				complete: true
			});
			const childParent = current.mounted.portalTarget ?? current.parent;
			for (let index = current.mounted.children.length - 1; index >= 0; index--) pending.push({
				mounted: current.mounted.children[index],
				parent: childParent,
				complete: false
			});
			continue;
		}
		if (current.mounted.dom.parentNode === current.parent) attemptTeardown(failure, () => current.parent.removeChild(current.mounted.dom));
		for (const node of current.mounted.rawNodes ?? []) if (node.parentNode === current.parent) attemptTeardown(failure, () => current.parent.removeChild(node));
		if (current.mounted.end?.parentNode === current.parent) attemptTeardown(failure, () => current.parent.removeChild(current.mounted.end));
	}
	throwTeardownFailure(failure);
}
//#endregion
//#region packages/dom/dist/client/renderer/root-disposal.js
/** Unmounts a renderer root and removes its owned DOM range. */
function unmount(container) {
	return dispose$1(container, true);
}
/** Releases a renderer root and optionally removes its owned DOM range. */
function dispose$1(container, removeDom = false) {
	const root = roots$1.get(container);
	if (!root) return false;
	roots$1.delete(container);
	unregisterInspectableRoot(root);
	const failure = teardownFailure();
	attemptTeardown(failure, () => clearDelegated(root));
	attemptTeardown(failure, () => disposeRetainedReleases(root));
	const mounted = root.mounted;
	root.mounted = void 0;
	if (mounted) {
		attemptTeardown(failure, () => unmountMounted(mounted));
		if (removeDom) attemptTeardown(failure, () => removeMountedNodes(container, mounted));
	}
	throwTeardownFailure(failure);
	return true;
}
/** Releases renderer roots owned by a bounded DOM subtree. */
function disposeOwnedSubtree(container, includeSelf = true, work) {
	const candidates = [];
	walkDomSubtree(container, (node) => {
		if (node instanceof Element && (includeSelf || node !== container)) candidates.push(node);
	}, typeof work === "number" ? { maxNodes: work } : { budget: work });
	let disposed = 0;
	const failure = teardownFailure();
	for (let index = candidates.length - 1; index >= 0; index--) try {
		if (dispose$1(candidates[index], false)) disposed++;
	} catch (error) {
		recordTeardownFailure(failure, error);
	}
	throwTeardownFailure(failure);
	return disposed;
}
//#endregion
//#region packages/dom/dist/client/placement.js
/** Places the full DOM range for a mounted subtree before the requested cursor. */
function placeMountedBefore(root, parent, mounted, before) {
	const cursor = before?.parentNode === parent ? before : null;
	const nodes = mountedDomNodes(mounted);
	const first = nodes[0];
	const last = nodes[nodes.length - 1];
	if (first.parentNode === parent && last.nextSibling === cursor && areContiguous(nodes)) {
		domDebug(root, "skip placement", () => ({
			reason: "mounted-range-already-before-cursor",
			parent: describeNode(parent),
			node: describeNode(first),
			before: describeNode(cursor)
		}));
		runAfterPlacement(root, mounted);
		return;
	}
	for (const node of nodes) insertBeforeIfNeeded(root, parent, node, cursor);
	runAfterPlacement(root, mounted);
}
/** Returns every DOM node owned by a mounted subtree in document order. */
function mountedDomNodes(mounted) {
	const nodes = [];
	const pending = [{
		mounted,
		end: false
	}];
	while (pending.length) {
		const current = pending.pop();
		if (current.end) {
			if (current.mounted.end) nodes.push(current.mounted.end);
			continue;
		}
		if (aliasesKeyedChildRange(current.mounted)) {
			pending.push({
				mounted: current.mounted.children[0],
				end: false
			});
			continue;
		}
		nodes.push(current.mounted.dom);
		if (current.mounted.end) pending.push({
			mounted: current.mounted,
			end: true
		});
		if (current.mounted.rawNodes) nodes.push(...current.mounted.rawNodes);
		if (ownsChildDom(current.mounted)) for (let index = current.mounted.children.length - 1; index >= 0; index--) pending.push({
			mounted: current.mounted.children[index],
			end: false
		});
	}
	return nodes;
}
/** Returns the DOM node immediately after the last mounted child, if one exists. */
function afterMountedChildren(mounted) {
	if (mounted.end) return mounted.end.nextSibling;
	const lastChild = mounted.children[mounted.children.length - 1];
	return lastChild ? lastMountedNode(lastChild).nextSibling : mounted.dom.nextSibling;
}
/** Returns the final DOM node owned by a mounted subtree. */
function lastMountedNode(mounted) {
	let current = mounted;
	while (!current.end && ownsChildDom(current) && current.children.length) current = current.children[current.children.length - 1];
	return current.end ?? current.dom;
}
function ownsChildDom(mounted) {
	return !!mounted.end || mounted.childRangeReceipt !== void 0 || mounted.range === "item" || mounted.range === "root" || mounted.fragmentReceipt !== void 0 || mounted.targetReceipt !== void 0 || mounted.clientArtifact !== void 0 || foreignChildCapability()?.ownsChildDom?.(mounted) === true;
}
/** A client-created keyed owner reuses its only child's physical range without extra markers. */
function aliasesKeyedChildRange(mounted) {
	const child = mounted.range === "item" && mounted.children.length === 1 ? mounted.children[0] : void 0;
	return !!child && mounted.dom === child.dom && mounted.end === child.end;
}
function runAfterPlacement(root, mounted) {
	const pending = [{ mounted }];
	while (pending.length) {
		const entry = pending.pop();
		const current = entry.mounted;
		if (entry.mountCommit) {
			const callback = current.afterPlacement;
			if (callback && current.afterPlacementPhase === "mount" && isInFinalPlacement(root, current.dom)) {
				current.afterPlacement = void 0;
				current.afterPlacementPhase = void 0;
				callback();
			}
			continue;
		}
		if (current.afterPlacementPhase === "mount") pending.push({
			mounted: current,
			mountCommit: true
		});
		for (let index = current.children.length - 1; index >= 0; index--) pending.push({ mounted: current.children[index] });
		const callback = current.afterPlacement;
		const phase = current.afterPlacementPhase;
		if (!callback || phase === "mount") continue;
		current.afterPlacement = void 0;
		current.afterPlacementPhase = void 0;
		if (phase === "retention") (root.placementRetentions ??= /* @__PURE__ */ new Map()).set(current, callback);
		else callback();
	}
}
/** Reports whether a provisional subtree has reached its root or a connected portal target. */
function isInFinalPlacement(root, node) {
	if (root.container.contains(node)) return true;
	if (node.isConnected) return true;
	for (const target of root.portalTargets) if (target.contains(node)) return true;
	return false;
}
/** Commits range retention after every ordinary placement callback in the transaction. */
function flushPlacementRetentions(root) {
	while (root.placementRetentions?.size) {
		const callbacks = [...root.placementRetentions.values()];
		root.placementRetentions.clear();
		for (const callback of callbacks) callback();
	}
}
function areContiguous(nodes) {
	for (let index = 0; index < nodes.length - 1; index++) if (nodes[index].nextSibling !== nodes[index + 1]) return false;
	return true;
}
function insertBeforeIfNeeded(root, parent, node, before) {
	const cursor = before?.parentNode === parent ? before : null;
	if (node === cursor) {
		domDebug(root, "skip placement", () => ({
			reason: "node-is-cursor",
			parent: describeNode(parent),
			node: describeNode(node),
			before: describeNode(cursor)
		}));
		return;
	}
	if (node.parentNode === parent && node.nextSibling === cursor) {
		domDebug(root, "skip placement", () => ({
			reason: "already-before-cursor",
			parent: describeNode(parent),
			node: describeNode(node),
			before: describeNode(cursor)
		}));
		return;
	}
	domDebug(root, "place node", () => ({
		parent: describeNode(parent),
		node: describeNode(node),
		before: describeNode(cursor),
		active: describeNode(document.activeElement)
	}));
	parent.insertBefore(node, cursor);
}
//#endregion
//#region packages/dom/dist/client/renderer/limits.js
var DEFAULT_MAX_TREE_DEPTH = 512;
var HARD_MAX_TREE_DEPTH = 1024;
var DEFAULT_MAX_TREE_NODES = 1e5;
/** Signals that a renderer traversal exceeded its configured nesting limit. */
var DomTreeDepthError = class extends Error {
	constructor(limit) {
		super(`eXact DOM tree exceeds the configured maximum depth of ${limit}`);
		this.name = "DomTreeDepthError";
	}
};
/** Signals that one renderer update exceeded its configured work limit. */
var DomTreeWorkError = class extends Error {
	constructor(limit) {
		super(`eXact DOM update exceeds the configured maximum of ${limit} render values`);
		this.name = "DomTreeWorkError";
	}
};
/** Normalizes a caller-provided depth limit and enforces the hard safety cap. */
function normalizeTreeDepth(value) {
	return Number.isSafeInteger(value) && value > 0 ? Math.min(value, HARD_MAX_TREE_DEPTH) : DEFAULT_MAX_TREE_DEPTH;
}
/** Normalizes the amount of operation work permitted during one renderer update. */
function normalizeTreeNodes(value) {
	return Number.isSafeInteger(value) && value > 0 ? value : DEFAULT_MAX_TREE_NODES;
}
/**
* Establishes an update-scoped work counter.
*
* Nested renderer calls share the outer counter so re-entrant work cannot reset
* the safety budget partway through an update.
*/
function withDomWork(root, run) {
	const outermost = root.workDepth++ === 0;
	if (outermost) root.traversedNodes = 0;
	try {
		return run();
	} finally {
		root.workDepth--;
		if (outermost) flushPlacementRetentions(root);
	}
}
/** Charges one render value against both local and hydration-shared budgets. */
function countDomWork(root) {
	if (root.workBudget) consumeDomWork(root.workBudget);
	if (root.interactionWork) root.interactionWork.traversedNodes++;
	if (++root.traversedNodes > root.maxTreeNodes) throw new DomTreeWorkError(root.maxTreeNodes);
}
/** Returns whether an error represents an intentional renderer safety limit. */
function isDomRenderLimitError(error) {
	return error instanceof DomTreeDepthError || error instanceof DomTreeWorkError;
}
/** Runs one nested traversal step while restoring depth on every exit path. */
function withTreeDepth(root, run) {
	root.traversalDepth++;
	if (root.traversalDepth > root.maxTreeDepth) {
		root.traversalDepth--;
		throw new DomTreeDepthError(root.maxTreeDepth);
	}
	try {
		return run();
	} finally {
		root.traversalDepth--;
	}
}
//#endregion
//#region packages/dom/dist/client/renderer/component-mount-ownership.js
/** Transfers a mounted component instance to its DOM range for exactly-once teardown. */
function ownMountedInstance(mounted, instance) {
	mounted.instance = instance;
	componentMounts.set(instance, mounted);
}
//#endregion
//#region packages/dom/dist/client/renderer/root-support.js
/** Creates a dom error context. */
function createDomErrorContext(options, onReport) {
	const base = createErrorContext();
	return {
		...base,
		report(error, reportOptions) {
			const report = base.report(error, reportOptions);
			options.onErrorReport?.(report);
			onReport?.(base.errors);
			return report;
		}
	};
}
/** Creates a root error view. */
function createRootErrorView(errors) {
	return createCompiledIntrinsicReceipt("section", {
		role: "alert",
		className: "exact-error-boundary"
	}, createCompiledIntrinsicReceipt("h1", null, "Application error"), ...errors.map((error) => createCompiledIntrinsicReceipt("article", {
		key: error.id,
		className: "exact-error"
	}, createCompiledIntrinsicReceipt("h2", null, error.component?.name ?? "Application"), createCompiledIntrinsicReceipt("p", null, `${error.source}${error.phase ? `:${error.phase}` : ""}`), createCompiledIntrinsicReceipt("pre", null, formatError(error.error)))));
}
/** Creates a marker. */
function createMarker(root, label) {
	return root.debugMarkers ? document.createComment(`exact-${label}`) : document.createTextNode("");
}
/** Creates an element. */
function createElement(tag, parent, props) {
	const namespace = namespaceForTag(tag, parent instanceof Element ? parent : void 0);
	const element = namespace ? document.createElementNS(namespace, tag) : document.createElement(tag);
	if (namespace === "http://www.w3.org/1998/Math/MathML" && tag === "annotation-xml" && typeof props?.encoding === "string") element.setAttribute("encoding", props.encoding);
	return element;
}
//#endregion
//#region packages/dom/dist/client/server-slots.js
/** Mounts or reclaims one opaque compiler-owned server range. */
function mountServerSlotReceipt(root, receipt, scope) {
	const element = findServerSlotDeep(root.container, receipt.id, root.maxTreeNodes) ?? document.createElement("span");
	element.setAttribute("data-exact-server-slot", receipt.id);
	if (element instanceof HTMLElement) element.style.display = "contents";
	return {
		serverSlotReceipt: receipt,
		dom: element,
		scope,
		children: []
	};
}
/** Adopts a retained server range at its exact SSR cursor. */
function adoptServerSlotReceipt(receipt, nodes, cursor, scope) {
	const element = nodes[cursor];
	if (!(element instanceof Element) || element.getAttribute("data-exact-server-slot") !== receipt.id) return void 0;
	return {
		mounted: {
			serverSlotReceipt: receipt,
			dom: element,
			scope,
			children: []
		},
		next: cursor + 1
	};
}
/** Repoints a mounted server slot at an existing matching element under the parent. */
function adoptServerSlot(parent, mounted) {
	const id = mounted.serverSlotReceipt?.id;
	if (id === void 0) return;
	const existing = findServerSlot(parent, id);
	if (!existing || existing === mounted.dom) return;
	mounted.dom = existing;
}
function findServerSlot(parent, id) {
	for (const child of Array.from(parent.childNodes)) if (child instanceof Element && child.getAttribute("data-exact-server-slot") === id) return child;
}
function findServerSlotDeep(parent, id, maxNodes) {
	let match;
	walkDomSubtree(parent, (node) => {
		if (!match && node instanceof Element && node.getAttribute("data-exact-server-slot") === id) match = node;
	}, { maxNodes });
	return match;
}
//#endregion
//#region packages/dom/dist/client/renderer/mounting/operation-parking.js
/** Reclaims an authored compiler operation parked by one enhancement replacement transaction. */
function takeParkedOperation(root, value, parentInstance, parentScope) {
	const mounts = root.replacementParking?.mounts;
	let parkedKey = value;
	let candidates = mounts?.get(value);
	if (!candidates?.length) {
		const receipt = readCompiledComponentReceipt(value);
		if (receipt && mounts) for (const [candidateKey, candidateMounts] of mounts) {
			const candidate = readCompiledComponentReceipt(candidateKey) ?? candidateMounts[0]?.mounted.componentReceipt;
			if (candidate && candidate.contract.artifact === receipt.contract.artifact && candidate.key === receipt.key && candidate.domain === receipt.domain) {
				parkedKey = candidateKey;
				candidates = candidateMounts;
				break;
			}
		}
	}
	const parked = candidates?.shift();
	if (!parked) return void 0;
	if (!candidates?.length && parkedKey) mounts?.delete(parkedKey);
	root.replacementParking?.commits.push(() => {
		transferEffectScope(parked.mounted.scope, parentScope);
		parked.mounted.operation = value;
		const component = readCompiledComponentReceipt(value);
		if (component) {
			if (parked.mounted.instance) {
				reparentComponentInstance(parked.mounted.instance, parentInstance);
				receiveComponentReceipt(parked.mounted, component);
			} else parked.mounted.componentReceipt = component;
		}
		const intrinsic = readCompiledIntrinsicReceipt(value);
		if (intrinsic) parked.mounted.intrinsicReceipt = intrinsic;
		const fragment = readCompiledFragmentReceipt(value);
		if (fragment) parked.mounted.fragmentReceipt = fragment;
		const program = readRenderProgramReceipt(value);
		if (program) parked.mounted.renderProgramReceipt = program;
	});
	return parked.mounted;
}
//#endregion
//#region packages/dom/dist/client/renderer/enhancement-capability.js
var registryKey$1 = Symbol.for("@exactjs/dom.enhancement-capability.v1");
/** Returns the realm-wide registry shared by independently bundled compatible eXact clients. */
function capabilityRegistry() {
	const realm = globalThis;
	const current = realm[registryKey$1];
	if (current !== void 0) {
		if (!isCapabilityRegistry(current)) throw new Error("Incompatible eXact DOM enhancement capability registry in this realm");
		return current;
	}
	const created = { abi: 1 };
	realm[registryKey$1] = created;
	return created;
}
/** Resolves enhancement behavior at the explicit compatibility boundary, including late registrations. */
function domEnhancementCapability() {
	return capabilityRegistry().capability;
}
/** Requires the integration only after authored enhancement state makes it semantically necessary. */
function requireDomEnhancementCapability() {
	const capability = domEnhancementCapability();
	if (!capability) throw new Error("eXact enhancement declarations require the compiler-selected DOM enhancement integration");
	return capability;
}
function isCapabilityRegistry(value) {
	return !!value && typeof value === "object" && value.abi === 1;
}
//#endregion
//#region packages/dom/dist/client/renderer/child-keys.js
/** Rejects ambiguous authored sibling identity before mounting any child resources. */
function assertUniqueChildKeys(children) {
	const keys = /* @__PURE__ */ new Set();
	for (const child of children) {
		const key = isOpaqueOperation(child) ? opaqueOperationKey(child) : foreignChildCapability()?.key(child);
		if (key === void 0) continue;
		if (keys.has(key)) throw new Error(`Duplicate key "${key}" in rendered children`);
		keys.add(key);
	}
}
//#endregion
//#region packages/dom/dist/client/renderer/scalar-child.js
/** Normalizes only scalar text values; object representations remain opaque to this target. */
function scalarText(value) {
	const resolved = unwrap(value);
	return typeof resolved === "string" || typeof resolved === "number" ? String(resolved) : void 0;
}
//#endregion
//#region packages/dom/dist/client/renderer/patching/text-binding.js
/** Binds one compiler-selected text node to its reactive source. */
function bindText(mounted, value) {
	mounted.stop?.();
	const node = mounted.dom;
	mounted.stop = watchRetained(() => {
		const text = String(unwrap(value) ?? "");
		if (node.data !== text) node.data = text;
	}, void 0, {
		scope: mounted.scope,
		onRelease: () => mounted.stop = void 0
	});
}
//#endregion
//#region packages/dom/dist/client/renderer/portal-routing.js
/** Resolves a portal destination without inspecting any of its supplied children. */
function portalTarget(value) {
	const target = value.target;
	if (!(target instanceof Node)) throw new TypeError("An eXact portal target must be a DOM Node");
	return target;
}
/** Runs target-owned work against the portal's effective delegated-event container. */
function withEventContainer(root, container, run) {
	const previous = root.eventContainer;
	root.eventContainer = container;
	try {
		return run();
	} finally {
		root.eventContainer = previous;
	}
}
/** Selects the delegated-event container for a physical portal destination. */
function portalEventContainer(root, target) {
	return root.container === target || root.container.contains(target) ? root.container : target;
}
//#endregion
//#region packages/dom/dist/client/renderer/mounting/intrinsic-receipt.js
/** Executes one compiler-selected intrinsic operation directly. */
function mountIntrinsicReceipt(root, receipt, scope, parentInstance, parentNode) {
	const element = createElement(receipt.tag, parentNode, receipt.props);
	const mounted = {
		intrinsicReceipt: receipt,
		dom: element,
		scope,
		children: []
	};
	if (parentInstance) setElementOwner(element, parentInstance);
	mounted.children = mountChildren(root, element, [...receipt.children], parentInstance, scope);
	updateProps(root, element, {}, receipt.props, scope);
	return mounted;
}
//#endregion
//#region packages/dom/dist/client/renderer/reconciliation.js
/**
* Finds positions belonging to one longest increasing subsequence.
*
* Negative values represent new children and are excluded. Keyed
* reconciliation retains the returned positions and moves only the remaining
* DOM ranges. The implementation is O(n log n).
*/
function longestIncreasingSubsequencePositions(values) {
	const tails = [];
	const predecessors = new Array(values.length).fill(-1);
	for (let index = 0; index < values.length; index++) {
		const value = values[index];
		if (value < 0) continue;
		let low = 0;
		let high = tails.length;
		while (low < high) {
			const middle = low + high >> 1;
			if (values[tails[middle]] < value) low = middle + 1;
			else high = middle;
		}
		if (low > 0) predecessors[index] = tails[low - 1];
		tails[low] = index;
	}
	const positions = /* @__PURE__ */ new Set();
	let cursor = tails[tails.length - 1] ?? -1;
	while (cursor >= 0) {
		positions.add(cursor);
		cursor = predecessors[cursor];
	}
	return positions;
}
//#endregion
//#region packages/dom/dist/client/renderer/patching/mixed-child-operations.js
/** Classifies sibling inputs into target-local operations without converting native receipts. */
function mixedChildOperations(children) {
	const operations = [];
	for (const value of children) {
		if (value === null || value === void 0 || value === false || value === true) continue;
		if (isOpaqueOperation(value)) {
			const key = opaqueOperationKey(value);
			operations.push({
				value,
				native: true,
				...key === void 0 ? {} : { key }
			});
			continue;
		}
		const scalar = scalarText(value);
		if (scalar !== void 0) {
			operations.push({
				value,
				scalar
			});
			continue;
		}
		throw new TypeError("Native eXact children must be compiler-issued operations, scalar values, or empty placeholders");
	}
	return operations;
}
/** Returns renderer sibling identity for a native operation or explicit compatibility value. */
function mountedChildKey(mounted) {
	return mounted.operationKey ?? mounted.componentReceipt?.key ?? mounted.intrinsicReceipt?.key ?? mounted.fragmentReceipt?.key ?? mounted.targetReceipt?.key;
}
//#endregion
//#region packages/dom/dist/client/renderer/patching/reconciliation-completion.js
/** Publishes ownership-dependent work after target-local child reconciliation. */
function completeChildReconciliation(root, parentInstance, structuralOwner) {
	if (structuralOwner) refreshTargetDependents(root, structuralOwner);
	if (parentInstance) refreshComponentRoot(parentInstance);
	if (!root.enhancementReconciliationDepth) root.reconcileEnhancements?.();
}
//#endregion
//#region packages/dom/dist/client/compiled-props.js
/** Applies one compiler-closed property group without allocating or enumerating a props record. */
function applyCompiledProps(mounted, element, group, initialBinding, operands) {
	const state = mounted.renderProgram;
	const groups = state.compiledProps ??= [];
	let retained = groups[group];
	if (!retained) {
		retained = {
			element,
			values: {}
		};
		groups[group] = retained;
	}
	const previous = retained.values;
	const write = () => {
		let spreadValues;
		const apply = (key, source) => {
			if (key === "") {
				spreadValues ??= {};
				const spread = unwrap(source);
				if (spread !== null && spread !== void 0 && typeof spread === "object") Object.assign(spreadValues, spread);
				return;
			}
			const value = unwrap(source);
			if (spreadValues) {
				spreadValues[key] = value;
				return;
			}
			if (Object.hasOwn(previous, key) && Object.is(previous[key], value)) return;
			setElementProp(state.root, element, key, value, previous[key], mounted.scope);
			previous[key] = value;
		};
		if (operands) {
			const owner = state.invocation.owner;
			for (const [key, source, slot] of operands) apply(key, readIndexedReactiveSlot(source === 0 ? owner.state : owner.props, slot));
		}
		state.invocation.propertyWriter?.(group, apply);
		if (spreadValues) for (const key of /* @__PURE__ */ new Set([...Object.keys(previous), ...Object.keys(spreadValues)])) {
			const value = unwrap(spreadValues[key]);
			if (Object.hasOwn(previous, key) && Object.is(previous[key], value)) continue;
			setElementProp(state.root, element, key, value, previous[key], mounted.scope);
			if (key in spreadValues) previous[key] = value;
			else delete previous[key];
		}
	};
	if (!initialBinding) preserveFocus(state.root, write);
	else write();
}
/** Releases refs and listeners retained by compact compiler property groups. */
function releaseCompiledProps(mounted) {
	const state = mounted.renderProgram;
	if (!state.compiledProps) return;
	for (const retained of state.compiledProps) {
		if (!retained) continue;
		retained.values.ref?.fulfill(void 0);
		clearElementProps(retained.element);
	}
	state.compiledProps = void 0;
}
//#endregion
//#region packages/dom/dist/client/renderer/dynamic-children.js
/** Reads one compiler-selected structural slot without allocating a reader closure. */
function readCompiledDynamicChildren(invocation, index, parentInstance, label) {
	try {
		return normalizeRenderResult(unwrap(readRenderProgramSlot(invocation, index)));
	} catch (error) {
		if (isPromiseLike$1(error)) {
			handleComponentSuspension(parentInstance, error);
			return [];
		}
		return dynamicFailure(error, parentInstance, label);
	}
}
/** Produces the component-owned fallback for one failed dynamic reader. */
function dynamicFailure(error, parentInstance, label = "dynamic-component") {
	const fallback = handleComponentError(parentInstance, createErrorReport(error, "render", parentInstance, label));
	return fallback ? normalizeRenderResult(fallback()) : [];
}
function isPromiseLike$1(value) {
	return (typeof value === "object" || typeof value === "function") && value !== null && typeof value.then === "function";
}
//#endregion
//#region packages/dom/dist/client/renderer/render-program-markers.js
/** Finds the closing marker for one compiler-owned structural child slot. */
function findProgramChildEnd(start, id) {
	if (!(start instanceof Comment) || !id) return void 0;
	const closing = `/x:${id.startsWith("exact:") ? id.slice(6) : id}`;
	for (let node = start.nextSibling; node; node = node.nextSibling) if (node instanceof Comment && node.data === closing) return node;
}
//#endregion
//#region packages/dom/dist/client/renderer/render-program-children.js
/** Installs one structural slot reaction through the ordinary mounted-child operations. */
function bindProgramChild(mounted, index, initialBinding, stopBindings, direct = false) {
	const applyChildren = prepareProgramChildBinding(mounted, index, initialBinding);
	if (!applyChildren) return false;
	if (direct) {
		(mounted.renderProgram.directChildUpdates ??= [])[index] = applyChildren;
		applyChildren();
		return true;
	}
	const watcher = watchRetained(applyChildren, void 0, {
		scope: mounted.scope,
		owned: true
	});
	if (watcher) stopBindings.push(watcher);
	return true;
}
/** Refreshes every compiler-owned list lane in one component render transaction. */
function bindProgramLists(mounted, indexes, initialBinding, stopBindings) {
	const apply = indexes.map((index) => prepareProgramChildBinding(mounted, index, initialBinding));
	if (apply.some((binding) => !binding)) return false;
	const refresh = () => {
		const owner = mounted.renderProgram.parentInstance;
		owner?.beginRender();
		try {
			for (const binding of apply) binding();
		} finally {
			owner?.endRender();
		}
	};
	const watcher = watchRetained(refresh, void 0, {
		scope: mounted.scope,
		owned: true
	});
	if (watcher) stopBindings.push(watcher);
	return true;
}
/** Installs one compiler-keyed array lane without constructing a Fragment/ListBinding wrapper. */
function bindProgramKeyedChild(mounted, index, initialBinding, stopBindings) {
	const apply = prepareProgramChildBinding(mounted, index, initialBinding, readDirectProgramChildren);
	if (!apply) return false;
	const owner = mounted.renderProgram.parentInstance;
	const refresh = () => {
		owner?.beginRender();
		try {
			apply();
		} finally {
			owner?.endRender();
		}
	};
	const watcher = watchRetained(refresh, void 0, {
		scope: mounted.scope,
		owned: true
	});
	if (watcher) stopBindings.push(watcher);
	return true;
}
function prepareProgramChildBinding(mounted, index, initialBinding, read = readProgramChildren) {
	const state = mounted.renderProgram;
	let childState = state.childSlots?.[index];
	const start = state.slotNodes[index];
	const identity = structuralProgramSlotIdentity(state, index);
	const componentSlot = identity !== void 0 && programComponentSlotIncludes(state.componentSlots, index);
	const anchor = isKeyedChildAnchor$1(start) ? start : void 0;
	const marker = start instanceof Node ? start : void 0;
	const end = childState ? childState.before : anchor ? void 0 : findProgramChildEnd(marker, identity);
	const parent = childState?.parent ?? anchor?.[0] ?? marker?.parentNode;
	const before = childState ? childState.before : anchor ? null : end;
	if (!parent || !anchor && (!(marker instanceof Comment) || !end)) return void 0;
	if (!childState) {
		childState = {
			parent,
			before: before ?? null,
			children: []
		};
		(state.childSlots ??= [])[index] = childState;
	}
	let skipAdoptedInitialPatch = initialBinding && childState.children.length !== 0;
	return () => {
		const next = withEffectScope(mounted.scope, () => read(state.invocation, index, state.parentInstance));
		if (skipAdoptedInitialPatch) {
			skipAdoptedInitialPatch = false;
			return;
		}
		peek(() => {
			const component = componentSlot ? soleComponentReceipt(next) : void 0;
			if (component ? Object.is(childState.componentValue, component) : sameProgramChildren(childState.value, next)) return;
			const parent = childState.parent;
			const before = childState.before;
			childState.children = patchChildren(state.root, parent, childState.children, next, state.parentInstance, mounted.scope, before, mounted);
			if (component) {
				childState.componentValue = component;
				childState.value = void 0;
			} else {
				childState.componentValue = void 0;
				childState.value = next;
			}
			refreshProgramMountedChildren(mounted);
		});
	};
}
/** Resolves one compiler-indexed structural slot's bounded marker identity without allocating. */
function structuralProgramSlotIdentity(state, index) {
	const marker = state.slotNodes[index];
	if (isKeyedChildAnchor$1(marker)) return "";
	if (!(marker instanceof Comment) || !marker.data.startsWith("x:")) return void 0;
	return marker.data.slice(2);
}
/** Narrows the renderer's tuple anchor used by compiler-keyed child slots. */
function isKeyedChildAnchor$1(value) {
	return Array.isArray(value);
}
/** Tests whether a compiler-indexed structural slot owns a component operation. */
function programComponentSlotIncludes(slots, index) {
	return typeof slots === "number" ? index < 31 && (slots & 1 << index) !== 0 : slots?.has(index) === true;
}
function soleComponentReceipt(children) {
	return children.length === 1 ? readCompiledComponentReceipt(children[0]) : void 0;
}
/** Resolves a general structural slot and admits only explicitly installed foreign children. */
function readProgramChildren(invocation, index, parentInstance) {
	return prepareForeignProgramChildren(readCompiledDynamicChildren(invocation, index, parentInstance, "compiled-child-slot"));
}
/** Resolves a compiler-keyed structural slot without the foreign-child compatibility boundary. */
function readDirectProgramChildren(invocation, index, parentInstance) {
	return readCompiledDynamicChildren(invocation, index, parentInstance, "compiled-keyed-child-slot");
}
/** Tests a compact or widened compiler-owned keyed-child slot set. */
function programKeyedChildIncludes(slots, index) {
	return typeof slots === "number" ? index < 31 && (slots & 1 << index) !== 0 : slots?.includes(index) === true;
}
function sameProgramChildren(previous, next) {
	if (!previous || previous.length !== next.length) return false;
	return next.every((value, index) => Object.is(value, previous[index]));
}
/** Rebuilds the flattened mounted-child view after one render-program slot changes. */
function refreshProgramMountedChildren(mounted) {
	mounted.children.length = 0;
	for (const slot of mounted.renderProgram.childSlots ?? []) if (slot) mounted.children.push(...slot.children);
}
//#endregion
//#region packages/dom/dist/client/renderer/render-program-components.js
/**
* Installs one compiler-proven component receipt.
*
* The retained reaction evaluates only the parent expressions that produce the component's
* inputs. A stable mounted child receives those inputs through its selected target artifact; the
* parent never calculates the child's dirty operations or routes through structural normalization.
*/
function bindProgramComponent(mounted, index, initialBinding) {
	const applyComponent = prepareProgramComponentBinding(mounted, index, initialBinding);
	if (!applyComponent) return false;
	(mounted.renderProgram.componentReceipts ??= [])[index] = applyComponent;
	applyComponent();
	return true;
}
/** Publishes the current inputs through one retained compiler-proven component receipt. */
function applyProgramComponent(mounted, index) {
	const apply = mounted.renderProgram?.componentReceipts?.[index];
	if (!apply) return false;
	apply();
	return true;
}
/** Prepares one stable receipt operation for a compiler-owned component slot. */
function prepareProgramComponentBinding(mounted, index, initialBinding) {
	const state = mounted.renderProgram;
	let childState = state.childSlots?.[index];
	const start = state.slotNodes[index];
	const anchor = isKeyedChildAnchor(start) ? start : void 0;
	const marker = start instanceof Node ? start : void 0;
	const identity = componentSlotIdentity(state, index, marker, anchor);
	if (identity === void 0) return void 0;
	const end = childState ? childState.before : anchor ? void 0 : findProgramChildEnd(marker, identity);
	const parent = childState?.parent ?? anchor?.[0] ?? marker?.parentNode;
	const before = childState ? childState.before : anchor ? anchor[2] ?? null : end;
	if (!parent || !anchor && (!(marker instanceof Comment) || !end)) return void 0;
	if (!childState) {
		childState = {
			parent,
			before: before ?? null,
			children: []
		};
		(state.childSlots ??= [])[index] = childState;
	}
	let skipAdoptedInitialReceipt = initialBinding && childState.children.length !== 0;
	return () => {
		const value = withEffectScope(mounted.scope, () => readRenderProgramSlot(state.invocation, index));
		const component = readCompiledComponentReceipt(value);
		if (!component) return;
		if (skipAdoptedInitialReceipt) {
			skipAdoptedInitialReceipt = false;
			childState.componentValue = component;
			return;
		}
		peek(() => {
			const current = childState.children.length === 1 ? childState.children[0] : void 0;
			const parked = takeParkedOperation(state.root, value, state.parentInstance, mounted.scope);
			if (!parked && current?.clientArtifact && current.instance && current.componentReceipt && current.componentReceipt.contract.artifact === component.contract.artifact && current.componentReceipt.key === component.key && current.componentReceipt.domain === component.domain && !componentIdentityChanged(current, component.props)) receiveComponentReceipt(current, component);
			else if (current) {
				const replacement = parked ?? mountComponentReceipt(state.root, component, state.parentInstance, mounted.scope, childState.parent);
				placeMountedBefore(state.root, childState.parent, replacement, current.dom);
				if (!releaseMountedRange(state.root, childState.parent, current, "reconcile-replaced")) disposeMounted(childState.parent, current);
				childState.children[0] = replacement;
			} else {
				const child = parked ?? mountComponentReceipt(state.root, component, state.parentInstance, mounted.scope, childState.parent);
				placeMountedBefore(state.root, childState.parent, child, childState.before);
				childState.children.push(child);
			}
			childState.componentValue = component;
			childState.value = void 0;
			refreshProgramMountedChildren(mounted);
		});
	};
}
/** Compares only identity inputs declared by the selected target artifact. */
function componentIdentityChanged(mounted, next) {
	const previous = mounted.componentReceipt?.props;
	const identities = mounted.clientArtifact?.identityProps;
	return !!previous && !!identities?.some((key) => !Object.is(Reflect.get(previous, key), Reflect.get(next, key)));
}
/** Resolves only a compiler-declared component slot and its marker identity. */
function componentSlotIdentity(state, index, marker, anchor) {
	if (!componentSlotIncludes(state.componentSlots, index)) return void 0;
	if (anchor) return "";
	if (!(marker instanceof Comment) || !marker.data.startsWith("x:")) return void 0;
	return marker.data.slice(2);
}
/** Tests membership in the compact or expanded compiler component-slot set. */
function componentSlotIncludes(slots, index) {
	return typeof slots === "number" ? index < 31 && (slots & 1 << index) !== 0 : slots?.has(index) === true;
}
/** Narrows the alternate marker-free anchor representation. */
function isKeyedChildAnchor(value) {
	return Array.isArray(value);
}
//#endregion
//#region packages/dom/dist/client/renderer/component-update-storage.js
/** Opaque owner field used by exactly one update ABI for a compiled component definition. */
var compiledComponentUpdateState = Symbol("exact.dom.component-updates");
/** Resolves the durable component that owns a generated finite-region target. */
function componentUpdateOwner(target) {
	const context = target;
	const owner = context.owner ?? context.mounted.renderProgram?.bindingOwner ?? context.mounted.renderProgram?.parentInstance;
	if (owner) return owner;
	context.valid = false;
}
/** Installs one compiler-indexed region target and clears it when that region is released. */
function bindComponentUpdateTarget(target, targets, index) {
	const current = targets[index];
	if (!current) targets[index] = target;
	else if (current instanceof Set) current.add(target);
	else if (current !== target) targets[index] = /* @__PURE__ */ new Set([current, target]);
	target.stopBindings.push({ stop: () => {
		const bound = targets[index];
		if (bound === target) targets[index] = void 0;
		else if (bound instanceof Set) {
			bound.delete(target);
			if (bound.size === 0) targets[index] = void 0;
			else if (bound.size === 1) targets[index] = bound.values().next().value;
		}
	} });
}
/** Applies a generated update once to singleton regions and once to every repeated region. */
function publishComponentUpdateTargets(targets, apply) {
	const singletons = [];
	let hasSingleton = false;
	for (let index = 0; index < targets.length; index++) {
		const target = targets[index];
		if (!target || target instanceof Set) continue;
		singletons[index] = target;
		hasSingleton = true;
	}
	if (hasSingleton) apply(singletons);
	for (let index = 0; index < targets.length; index++) {
		const repeated = targets[index];
		if (!(repeated instanceof Set)) continue;
		for (const target of repeated) {
			const occurrence = [];
			occurrence[index] = target;
			apply(occurrence);
		}
	}
}
/** Resolves the subset of generated dependencies backed by one indexed state or props facade. */
function createComponentDependencyGroup(owner, bindings, source, start = 0, end = bindings.length) {
	const slots = [];
	for (let index = start; index < end; index++) {
		const binding = bindings[index];
		slots.push(binding[0]);
	}
	if (slots.length === 0) return null;
	const dependencies = reactiveIndexedDependencies(owner[source], slots);
	if (!dependencies) return void 0;
	return {
		d: dependencies.target,
		k: dependencies.keys,
		v: dependencies.keys.map((key) => readMutationVersion(dependencies.target, key)),
		o: start
	};
}
/** Visits every generated binding whose indexed mutation version advanced. */
function visitChangedComponentDependencyGroup(group, visit) {
	let changed = false;
	for (let index = 0; index < group.k.length; index++) {
		const version = readMutationVersion(group.d, group.k[index]);
		if (version === group.v[index]) continue;
		group.v[index] = version;
		changed = true;
		visit(group.o + index);
	}
	return changed;
}
//#endregion
//#region packages/dom/dist/client/renderer/component-update-dependencies.js
/** Source-qualified subscriptions, including forwarded reactive prop values. */
var CompiledComponentDependencies = class {
	owner;
	bindings;
	props;
	scope;
	publish;
	g = [];
	f = [];
	s = [];
	constructor(owner, bindings, props, scope, publish) {
		this.owner = owner;
		this.bindings = bindings;
		this.props = props;
		this.scope = scope;
		this.publish = publish;
	}
	/** Releases binder-local source and forwarded-value subscriptions idempotently. */
	stop() {
		for (const release of this.s.splice(0)) release();
		for (const forwarded of this.f.splice(0)) forwarded?.stop();
	}
};
/** Resolves generated state/props dependencies and installs one subscription per backing object. */
function createCompiledComponentDependencies(owner, bindings, props, publish, scope = owner.scope) {
	const result = new CompiledComponentDependencies(owner, bindings, props, scope, publish);
	for (const [source, start, end] of [[
		"props",
		0,
		props
	], [
		"state",
		props,
		bindings.length
	]]) {
		const group = createComponentDependencyGroup(owner, bindings, source, start, end);
		if (group === void 0) return void 0;
		if (!group) continue;
		result.g.push(group);
		result.s.push(subscribeKeys(group.d, group.k, publish, { scope }));
	}
	for (let index = 0; index < bindings.length; index++) refreshForwardedProp(result, index);
	return result;
}
/** Visits the generated binding identity for every dependency whose mutation version advanced. */
function visitChangedCompiledComponentDependencies(dependencies, visit, forwardedBinding = -1) {
	let changed = forwardedBinding >= 0;
	if (changed) visit(forwardedBinding);
	for (const group of dependencies.g) changed = visitChangedComponentDependencyGroup(group, (binding) => {
		if (binding !== forwardedBinding) visit(binding);
		refreshForwardedProp(dependencies, binding);
	}) || changed;
	return changed;
}
function refreshForwardedProp(dependencies, index) {
	const binding = dependencies.bindings[index];
	if (!binding || index >= dependencies.props) return;
	const read = readIndexedReactiveSource(dependencies.owner.props, binding[0]);
	const operand = read.present && Array.isArray(read.value) && read.value[0] === compiledReactivePropertyOperand ? read.value : void 0;
	const value = read.present && isReactiveValue(read.value) ? read.value : void 0;
	const sourceValue = operand ?? value;
	const current = dependencies.f[index];
	if (current?.value === sourceValue) return;
	current?.stop();
	dependencies.f[index] = void 0;
	if (!sourceValue) return;
	const notify = () => {
		value?.get();
		dependencies.publish(index);
	};
	const propertyDependencies = operand ? reactiveOwnDependencies(operand[1], [operand[2]]) : void 0;
	const stop = operand ? subscribeKeys(propertyDependencies?.target ?? unwrap(operand[1]), propertyDependencies?.keys ?? [operand[2]], notify, { scope: dependencies.scope }) : subscribe(ref(value), notify, { scope: dependencies.scope });
	dependencies.f[index] = {
		value: sourceValue,
		stop
	};
}
//#endregion
//#region packages/dom/dist/client/renderer/component-update-binding.js
/**
* Joins one finite DOM region to its compiler-generated component update program.
*
* The first mounted region allocates one dependency subscription on the durable component scope.
* Every later region installs only its stable indexed target. Region teardown clears that target;
* component scope teardown releases the shared subscription.
*/
function bindCompiledComponentUpdate(target, index, updates) {
	const owner = componentUpdateOwner(target);
	if (!owner) return;
	const component = owner;
	let state = component[compiledComponentUpdateState];
	if (!state) {
		let initialized;
		const dependencies = createCompiledComponentDependencies(owner, updates.bindings, updates.props, (binding) => publishCompiledComponentUpdate(updates, initialized, binding));
		if (!dependencies) {
			target.valid = false;
			return;
		}
		state = initialized = {
			d: dependencies,
			t: []
		};
		component[compiledComponentUpdateState] = state;
	}
	bindComponentUpdateTarget(target, state.t, index);
}
/** Converts one mutation-version snapshot into the component's generated dirty operation mask. */
function publishCompiledComponentUpdate(updates, state, forwardedBinding) {
	let dirtyLow = 0;
	let dirtyHigh = 0;
	visitChangedCompiledComponentDependencies(state.d, (index) => {
		dirtyLow |= updates.bindings[index][1];
		dirtyHigh |= updates.bindings[index][2];
	}, forwardedBinding);
	if (dirtyLow || dirtyHigh) publishComponentUpdateTargets(state.t, (targets) => updates.apply(targets, dirtyLow, dirtyHigh));
}
//#endregion
//#region packages/dom/dist/client/renderer/component-update-wide-binding.js
var wideComponentUpdateState = Symbol("exact.dom.component-wide-updates");
/** Joins one finite DOM region to a compiler-generated update program wider than 64 operations. */
function bindCompiledWideComponentUpdate(target, index, updates) {
	const context = target;
	const owner = context.mounted.renderProgram?.bindingOwner ?? context.mounted.renderProgram?.parentInstance;
	if (!owner) {
		context.valid = false;
		return;
	}
	const component = owner;
	let state = component[wideComponentUpdateState];
	if (!state) {
		let initialized;
		const dependencies = createCompiledComponentDependencies(owner, updates.bindings, updates.props, (binding) => publishCompiledWideComponentUpdate(updates, initialized, binding));
		if (!dependencies) {
			context.valid = false;
			return;
		}
		state = initialized = {
			d: dependencies,
			t: [],
			w: new Uint32Array(updates.words - 2)
		};
		component[wideComponentUpdateState] = state;
	}
	bindComponentUpdateTarget(target, state.t, index);
}
/** Publishes every changed compiler-sized mask word through the generated wide updater. */
function publishCompiledWideComponentUpdate(updates, state, forwardedBinding) {
	let dirtyLow = 0;
	let dirtyHigh = 0;
	let changed = false;
	changed = visitChangedCompiledComponentDependencies(state.d, (index) => {
		const binding = updates.bindings[index];
		dirtyLow |= binding[1];
		dirtyHigh |= binding[2];
		const bindingWords = binding;
		for (let word = 0; word < state.w.length; word++) state.w[word] = state.w[word] | (bindingWords[word + 3] ?? 0);
	}, forwardedBinding);
	if (!changed) return;
	try {
		publishComponentUpdateTargets(state.t, (targets) => updates.apply(targets, dirtyLow, dirtyHigh, state.w));
	} finally {
		state.w.fill(0);
	}
}
//#endregion
//#region packages/dom/dist/client/renderer/component-state-update-binding.js
var wideComponentStateUpdate = Symbol("exact.dom.component-wide-state-updates");
/** Joins a finite region to an update artifact proven to read only indexed component state. */
function bindCompiledStateComponentUpdate(target, index, updates) {
	const owner = componentUpdateOwner(target);
	if (!owner) return;
	let state = owner[compiledComponentUpdateState];
	if (!state) {
		const dependencies = createComponentDependencyGroup(owner, updates.bindings, "state");
		if (!dependencies) {
			target.valid = false;
			return;
		}
		state = {
			d: dependencies,
			t: []
		};
		owner[compiledComponentUpdateState] = state;
		subscribeKeys(state.d.d, state.d.k, () => publishStateUpdate(updates, state), { scope: owner.scope });
	}
	bindComponentUpdateTarget(target, state.t, index);
}
/** Joins a finite region to a state-only update artifact wider than 64 operations. */
function bindCompiledWideStateComponentUpdate(target, index, updates) {
	const owner = componentUpdateOwner(target);
	if (!owner) return;
	let state = owner[wideComponentStateUpdate];
	if (!state) {
		const dependencies = createComponentDependencyGroup(owner, updates.bindings, "state");
		if (!dependencies) {
			target.valid = false;
			return;
		}
		state = {
			d: dependencies,
			t: [],
			w: new Uint32Array(updates.words - 2)
		};
		owner[wideComponentStateUpdate] = state;
		subscribeKeys(state.d.d, state.d.k, () => publishWideStateUpdate(updates, state), { scope: owner.scope });
	}
	bindComponentUpdateTarget(target, state.t, index);
}
function publishStateUpdate(updates, state) {
	let dirtyLow = 0;
	let dirtyHigh = 0;
	visitChangedComponentDependencyGroup(state.d, (index) => {
		dirtyLow |= updates.bindings[index][1];
		dirtyHigh |= updates.bindings[index][2];
	});
	if (dirtyLow || dirtyHigh) publishComponentUpdateTargets(state.t, (targets) => updates.apply(targets, dirtyLow, dirtyHigh));
}
function publishWideStateUpdate(updates, state) {
	let dirtyLow = 0;
	let dirtyHigh = 0;
	let changed = false;
	changed = visitChangedComponentDependencyGroup(state.d, (index) => {
		const binding = updates.bindings[index];
		dirtyLow |= binding[1];
		dirtyHigh |= binding[2];
		const bindingWords = binding;
		for (let word = 0; word < state.w.length; word++) state.w[word] = state.w[word] | (bindingWords[word + 3] ?? 0);
	});
	if (!changed) return;
	try {
		publishComponentUpdateTargets(state.t, (targets) => updates.apply(targets, dirtyLow, dirtyHigh, state.w));
	} finally {
		state.w.fill(0);
	}
}
//#endregion
//#region packages/dom/dist/client/renderer/render-program-text.js
/** Applies one focused text value from either an exact operand or an arbitrary slot reader. */
function applyProgramText(mounted, index, source, operandSlot, prefix = "", suffix = "") {
	const state = mounted.renderProgram;
	const owner = state.invocation.owner;
	const value = unwrap(source !== void 0 ? readIndexedReactiveSlot(source === 0 ? owner.state : owner.props, operandSlot) : readRenderProgramSlot(state.invocation, index));
	const node = state.slotNodes[index];
	if (!(node instanceof Text)) return false;
	const text = value === null || value === void 0 || value === false || value === true ? "" : typeof value === "string" || typeof value === "number" ? String(value) : void 0;
	if (text === void 0) return false;
	const projected = `${prefix}${text}${suffix}`;
	if (node.data !== projected) node.data = projected;
	return true;
}
//#endregion
//#region packages/dom/dist/client/renderer/render-program-retained-binding.js
/** Installs one owned watcher and transfers its cleanup to the binding transaction. */
function retainProgramBinding(context, apply) {
	const watcher = watchRetained(apply, void 0, {
		scope: context.mounted.scope,
		owned: true
	});
	if (watcher) context.stopBindings.push(watcher);
}
//#endregion
//#region packages/dom/dist/client/renderer/render-program-property-bindings.js
/** Binds one compiler-written property group to its exact target slot. */
function bindCompiledProgramProperties(target, group, firstSlot, direct, operands) {
	const context = target;
	const state = context.mounted.renderProgram;
	const element = state.slotNodes[firstSlot];
	if (!state.invocation.propertyWriter && !operands || !element) {
		context.valid = false;
		return;
	}
	const apply = () => applyCompiledProps(context.mounted, element, group, context.initialBinding, operands);
	if (direct) apply();
	else retainProgramBinding(context, apply);
}
/** Binds one compiler-selected arbitrary-JavaScript property reader as a focused reactive update. */
function bindCompiledReactiveProgramProperties(target, group, firstSlot) {
	const context = target;
	const state = context.mounted.renderProgram;
	const element = state.slotNodes[firstSlot];
	if (!state.invocation.propertyWriter || !element) {
		context.valid = false;
		return;
	}
	retainProgramBinding(context, () => applyCompiledProps(context.mounted, element, group, context.initialBinding));
}
//#endregion
//#region packages/dom/dist/client/renderer/render-program-bindings.js
/** Installs and owns the compiler-emitted direct bindings for one mounted program. */
function bindRenderProgram(mounted) {
	const state = mounted.renderProgram;
	let released = false;
	let initialBinding = true;
	let stopBindings = [];
	const stopCurrentBindings = () => {
		for (const binding of stopBindings) binding.stop();
		stopBindings = [];
		state.directChildUpdates = void 0;
		state.componentReceipts = void 0;
	};
	const release = () => {
		if (released) return;
		released = true;
		stopCurrentBindings();
		if (state.props) {
			for (const [element, props] of state.props) {
				props.ref?.fulfill(void 0);
				clearElementProps(element);
			}
			state.props.clear();
			state.props = void 0;
		}
		releaseCompiledProps(mounted);
		mounted.stop = void 0;
		state.refresh = void 0;
	};
	const bind = () => {
		stopCurrentBindings();
		const target = {
			mounted,
			initialBinding,
			stopBindings,
			valid: true
		};
		const wiring = state.invocation.program.wire;
		const binder = state.invocation.program.bind;
		if (wiring) executeCompiledProgramBindings(wiring, target);
		else if (binder) binder(target);
		else target.valid = false;
		initialBinding = false;
		return target.valid;
	};
	state.refresh = bind;
	mounted.stop = release;
	if (!bind()) {
		release();
		return false;
	}
	return true;
}
/** Executes one immutable component-local binding sequence against the mounted region. */
function executeCompiledProgramBindings(wiring, target) {
	for (const operation of wiring[2]) {
		executeCompiledProgramBinding(operation, target);
		if (!target.valid) return;
	}
}
function executeCompiledProgramBinding(operation, target) {
	switch (operation[0]) {
		case 0:
			const operand = Array.isArray(operation[2]) ? operation[2] : void 0;
			bindCompiledProgramText(target, operation[1], (operand ? operation[3] : operation[2]) === true ? true : void 0, operand);
			return;
		case 11: {
			const projection = operation[2];
			const projectedOperand = projection[3] === void 0 ? void 0 : [projection[3], projection[4]];
			bindCompiledProgramText(target, operation[1], projection[2], projectedOperand, projection[0], projection[1]);
			return;
		}
		case 1:
			bindCompiledProgramChild(target, operation[1], operation[2] === true ? true : void 0);
			return;
		case 2:
			bindCompiledProgramComponent(target, operation[1], operation[2], operation[3]);
			return;
		case 3:
			bindCompiledProgramKeyedChild(target, operation[1]);
			return;
		case 4:
			bindCompiledProgramLists(target, operation[1]);
			return;
		case 5:
			bindCompiledProgramProperties(target, operation[1], operation[2], operation[3] === true ? true : void 0);
			return;
		case 6:
			bindCompiledReactiveProgramProperties(target, operation[1], operation[2]);
			return;
		case 12:
			bindCompiledProgramProperties(target, operation[1], operation[2], operation[4] === true ? true : void 0, operation[3]);
			return;
		case 7:
			bindCompiledComponentUpdate(target, operation[1], operation[2]);
			return;
		case 8:
			bindCompiledWideComponentUpdate(target, operation[1], operation[2]);
			return;
		case 9:
			bindCompiledStateComponentUpdate(target, operation[1], operation[2]);
			return;
		case 10:
			bindCompiledWideStateComponentUpdate(target, operation[1], operation[2]);
			return;
		default: target.valid = false;
	}
}
/** Binds one compiler-proven native component slot to direct target-artifact prop receipt. */
function bindCompiledProgramComponent(target, index, bindings, props) {
	const context = target;
	const owner = componentUpdateOwner(target);
	if (!owner || !bindProgramComponent(context.mounted, index, context.initialBinding)) {
		context.valid = false;
		return;
	}
	if (bindings.length !== 0) {
		const applyReceipt = () => {
			if (!applyProgramComponent(context.mounted, index)) context.valid = false;
		};
		const publish = (forwardedBinding) => {
			if (dependencies) visitChangedCompiledComponentDependencies(dependencies, () => void 0, forwardedBinding);
			scheduleWork(applyReceipt, currentWorkPriority(), void 0, context.mounted.scope);
		};
		const dependencies = createCompiledComponentDependencies(owner, bindings, props, publish, context.mounted.scope);
		if (!dependencies) context.valid = false;
		else context.stopBindings.push(dependencies);
	}
}
/** Binds one compiler-selected scalar text slot. */
function bindCompiledProgramText(target, index, direct, operand, prefix = "", suffix = "") {
	const context = target;
	let initialTarget = context;
	const applyText = () => {
		if (!applyProgramText(context.mounted, index, operand?.[0], operand?.[1], prefix, suffix)) {
			if (initialTarget) initialTarget.valid = false;
		}
	};
	if (direct) applyText();
	else retainProgramBinding(context, applyText);
	initialTarget = void 0;
}
/** Applies one compiler-selected text operation without installing a dynamic watcher. */
function applyCompiledProgramText(target, index, source, operandSlot, prefix = "", suffix = "") {
	const context = target;
	if (!applyProgramText(context.mounted, index, source, operandSlot, prefix, suffix)) context.valid = false;
}
/** Binds one compiler-selected structural child slot. */
function bindCompiledProgramChild(target, index, direct) {
	const context = target;
	if (!bindProgramChild(context.mounted, index, context.initialBinding, context.stopBindings, direct)) context.valid = false;
}
/** Binds the compiler-selected keyed-list slots as one render transaction. */
function bindCompiledProgramLists(target, indexes) {
	const context = target;
	if (!bindProgramLists(context.mounted, indexes, context.initialBinding, context.stopBindings)) context.valid = false;
}
/** Binds one compiler-generated keyed child array without a component list controller. */
function bindCompiledProgramKeyedChild(target, index) {
	const context = target;
	if (!bindProgramKeyedChild(context.mounted, index, context.initialBinding, context.stopBindings)) context.valid = false;
}
//#endregion
//#region packages/dom/dist/client/renderer/render-program-claim-path.js
/** Claims one required intrinsic through its compiler-encoded element-child path. */
function claimCompiledProgramElementPath(target, index, path, tag, namespace) {
	const claim = target;
	if (claim.claiming !== true || !claim.valid || !claim.root || !claim.elements) return;
	let remaining = Math.floor(path);
	let depth = remaining % 16;
	remaining = Math.floor(remaining / 16);
	let element = claim.root;
	while (depth-- > 0) {
		const step = remaining % 128;
		const ordinal = step % 64;
		const child = element.children.item(step < 64 ? ordinal : element.children.length - ordinal - 1);
		if (!child) {
			claim.valid = false;
			return;
		}
		element = child;
		remaining = Math.floor(remaining / 128);
	}
	if (!matchesProgramElement(element, tag, namespace ?? claim.namespace)) {
		claim.valid = false;
		return;
	}
	claim.elements[index] = element;
}
/** Tests a claimed intrinsic against its compiler-selected namespace. */
function matchesProgramElement(element, tag, namespace) {
	const uri = namespace === "contextual" ? element.parentElement ? namespaceForTag(tag, element.parentElement) ?? "http://www.w3.org/1999/xhtml" : element.namespaceURI : namespace === "svg" ? SVG_NAMESPACE : namespace === "mathml" ? MATHML_NAMESPACE : HTML_NAMESPACE;
	return element.localName.toLowerCase() === tag.toLowerCase() && element.namespaceURI === uri;
}
//#endregion
//#region packages/dom/dist/client/renderer/render-program-claims.js
/** Runs the descriptor's generated claim lane without interpreting its node or slot tables. */
function claimCompiledRenderProgram(program, root, source) {
	if (!program.directClaims) return void 0;
	const fixtureBinder = program.bind;
	if (!program.wire && !fixtureBinder) {
		if (!matchesProgramElement(root, program.root[0], program.root[1] ?? program.namespace)) return void 0;
		return {
			elements: [root],
			slotNodes: [],
			componentSlots: 0,
			work: program.work
		};
	}
	const target = {
		claiming: true,
		root,
		source,
		namespace: concreteElementNamespace(root),
		elements: [],
		slotNodes: [],
		componentSlots: 0,
		work: [0, 0],
		parents: [],
		container: root,
		current: null,
		valid: true,
		began: false
	};
	if (program.wire) claimCompiledProgramWiring(program.wire, target);
	else fixtureBinder(target);
	if (target.valid && target.began && target.parents.length === 0) return {
		elements: target.elements,
		slotNodes: target.slotNodes,
		componentSlots: target.componentSlots,
		work: target.work
	};
}
/** Executes one immutable component-local claim sequence against the bounded claim cursor. */
function claimCompiledProgramWiring(wiring, target) {
	const [root, claims] = wiring;
	if (!beginCompiledProgramClaims(target, root[0], root[1], root[2], root[3])) return;
	for (const operation of claims) switch (operation[0]) {
		case 0:
			claimCompiledProgramElement(target, operation[1], operation[2], operation[3], operation[4]);
			break;
		case 1:
			enterCompiledProgramElement(target, operation[1]);
			break;
		case 2:
			leaveCompiledProgramElement(target);
			break;
		case 3:
			claimCompiledProgramText(target, operation[1], operation[2], operation[3]);
			break;
		case 4:
			claimCompiledProgramKeyedChild(target, operation[1], operation[2], operation[3] === true, operation[4]);
			break;
		case 5:
			claimCompiledProgramChild(target, operation[1], operation[2], operation[3], operation[4] === true);
			break;
		case 6:
			claimCompiledProgramElementPath(target, operation[1], operation[2], operation[3], operation[4]);
			break;
		case 7:
			claimCompiledProgramProperty(target, operation[1], operation[2]);
			break;
		default:
			target.valid = false;
			return;
	}
}
/** Copies one claimed element into the slot lane consumed by a compiled property group. */
function claimCompiledProgramProperty(target, slot, element) {
	if (!isClaimTarget(target) || !target.valid) return;
	const claimed = target.elements[element];
	if (!claimed) {
		target.valid = false;
		return;
	}
	target.slotNodes[slot] = claimed;
}
/** Selects the generated claim lane and validates its intrinsic root. */
function beginCompiledProgramClaims(target, tag, namespace, nodes, slots) {
	if (!isClaimTarget(target)) return false;
	target.began = true;
	target.namespace = concreteElementNamespace(target.root);
	target.work = [nodes, slots];
	if (!matchesProgramElement(target.root, tag, namespace)) {
		target.valid = false;
		return true;
	}
	target.elements[0] = target.root;
	target.current = target.root.firstChild;
	return true;
}
/** Claims one compiler-known intrinsic at the current parent cursor. */
function claimCompiledProgramElement(target, index, skip, tag, namespace) {
	if (!isClaimTarget(target) || !target.valid) return;
	const node = advance(target.current, skip);
	if (!(node instanceof Element) || !matchesProgramElement(node, tag, namespace ?? target.namespace)) {
		target.valid = false;
		return;
	}
	target.elements[index] = node;
	target.current = node.nextSibling;
}
/** Enters the children of the last compiler-claimed intrinsic. */
function enterCompiledProgramElement(target, index) {
	if (!isClaimTarget(target) || !target.valid) return;
	const element = target.elements[index];
	if (!element) {
		target.valid = false;
		return;
	}
	target.parents.push(target.current, target.container);
	target.container = element;
	target.current = element.firstChild;
}
/** Restores the parent cursor after a compiler-known intrinsic subtree. */
function leaveCompiledProgramElement(target) {
	if (!isClaimTarget(target) || !target.valid) return;
	const container = target.parents.pop();
	const parent = target.parents.pop();
	if (parent === void 0 || !container) {
		target.valid = false;
		return;
	}
	target.container = container;
	target.current = parent;
}
/** Claims and removes one compiler-known scalar SSR sentinel pair. */
function claimCompiledProgramText(target, index, skip, id) {
	if (!isClaimTarget(target) || !target.valid) return;
	if (target.source === "ssr" && id === true) {
		let marker = target.current;
		for (let offset = 0; offset < skip; offset++) {
			if (!marker) {
				target.valid = false;
				return;
			}
			marker = marker.nextSibling;
		}
		if (marker instanceof Comment && marker.data.startsWith("exact:")) {
			target.valid = false;
			return;
		}
		const text = marker instanceof Text ? marker : (marker?.ownerDocument ?? target.root.ownerDocument).createTextNode("");
		if (!(marker instanceof Text)) target.container.insertBefore(text, marker);
		target.slotNodes[index] = text;
		target.current = marker instanceof Text ? marker.nextSibling : marker;
		return;
	}
	const marker = advance(target.current, skip);
	const identity = id === true ? "" : markerIdentity(id);
	const expectedOpen = target.source === "template" ? "" : `x:${identity}`;
	if (!(marker instanceof Comment) || marker.data !== expectedOpen) {
		target.valid = false;
		return;
	}
	const candidate = marker.nextSibling;
	let text;
	let closing;
	if (candidate instanceof Text) {
		text = candidate;
		closing = candidate.nextSibling;
	} else {
		text = marker.ownerDocument.createTextNode("");
		closing = candidate;
	}
	if (!(closing instanceof Comment)) {
		target.valid = false;
		return;
	}
	if (target.source === "ssr" ? closing.data !== `/x:${identity}` : closing.data !== "") {
		target.valid = false;
		return;
	}
	const next = closing.nextSibling;
	if (text.parentNode === null) closing.parentNode?.insertBefore(text, closing);
	target.slotNodes[index] = text;
	marker.remove();
	closing.remove();
	target.current = next;
}
/** Claims one variable-width structural range and advances past its matching boundary. */
function claimCompiledProgramChild(target, index, skip, id, component = false) {
	if (!isClaimTarget(target) || !target.valid) return;
	const marker = advance(target.current, skip);
	const identity = markerIdentity(id);
	if (!(marker instanceof Comment) || marker.data !== `x:${identity}`) {
		target.valid = false;
		return;
	}
	let closing;
	for (let candidate = marker.nextSibling; candidate; candidate = candidate.nextSibling) if (candidate instanceof Comment && candidate.data === `/x:${identity}`) {
		closing = candidate;
		break;
	}
	if (!closing) {
		target.valid = false;
		return;
	}
	target.slotNodes[index] = marker;
	if (component) markComponentSlot(target, index);
	target.current = closing.nextSibling;
}
/** Claims a compiler-proven final or next-intrinsic-bounded range without SSR delimiters. */
function claimCompiledProgramKeyedChild(target, index, skip, component = false, endIndex) {
	if (!isClaimTarget(target) || !target.valid) return;
	if (endIndex !== void 0) {
		const start = advance(target.current, skip);
		const end = target.elements[endIndex];
		if (!end || end.parentNode !== target.container) {
			target.valid = false;
			return;
		}
		target.slotNodes[index] = [
			target.container,
			start,
			end
		];
		if (component) markComponentSlot(target, index);
		target.current = end;
		return;
	}
	let start = target.current;
	for (let offset = 0; offset < skip; offset++) {
		if (!start) {
			target.valid = false;
			return;
		}
		start = start.nextSibling;
	}
	target.slotNodes[index] = [target.container, start];
	if (component) markComponentSlot(target, index);
	target.current = null;
}
function isClaimTarget(target) {
	return target.claiming === true;
}
function advance(node, count) {
	for (let index = 0; node && index < count; index++) node = node.nextSibling;
	return node;
}
function concreteElementNamespace(element) {
	return element.namespaceURI === "http://www.w3.org/2000/svg" ? "svg" : element.namespaceURI === "http://www.w3.org/1998/Math/MathML" ? "mathml" : "html";
}
function markerIdentity(id) {
	return id.startsWith("exact:") ? id.slice(6) : id;
}
function markComponentSlot(target, index) {
	if (index < 31 && typeof target.componentSlots === "number") {
		target.componentSlots |= 1 << index;
		return;
	}
	if (typeof target.componentSlots === "number") {
		const slots = /* @__PURE__ */ new Set();
		for (let bit = 0; bit < 31; bit++) if ((target.componentSlots & 1 << bit) !== 0) slots.add(bit);
		target.componentSlots = slots;
	}
	target.componentSlots.add(index);
}
//#endregion
//#region packages/dom/dist/client/renderer/render-program-hydration.js
/** Resolves the optional outer cell range enclosing a marked render program. */
function markedProgramRange(nodes, cursor, end) {
	const start = nodes[cursor];
	if (!(start instanceof Comment) || !start.data.startsWith("exact:cell:")) return {
		contentStart: cursor,
		endIndex: cursor + 1
	};
	for (let index = cursor + 1; index < end; index++) {
		const candidate = nodes[index];
		if (candidate instanceof Comment && candidate.data === `/${start.data}`) return {
			start,
			contentStart: cursor + 1,
			endIndex: index
		};
	}
}
//#endregion
//#region packages/dom/dist/client/renderer/render-program-slot-claims.js
/** Releases ownership installed for direct compiler claims after an atomic binding failure. */
function releaseDirectProgramNodeOwners(elements) {
	if (!elements) return;
	for (const element of elements) {
		if (!element) continue;
		clearNodeOwner(element);
		clearElementOwner(element);
	}
}
/** Assigns direct compiler-claimed elements to their durable component instance. */
function ownDirectProgramNodes(elements, owner) {
	if (!elements || !owner) return;
	for (const element of elements) {
		if (!element) continue;
		setNodeOwner(element, owner);
		setElementOwner(element, owner);
	}
}
//#endregion
//#region packages/dom/dist/client/renderer/render-program-template.js
var templateCaches = /* @__PURE__ */ new WeakMap();
/** Materializes one program fragment in its attachment namespace, caching only compatible DOM. */
function materializeProgramTemplate(program, ownerDocument, parentNode) {
	let cache = templateCaches.get(ownerDocument);
	if (!cache) templateCaches.set(ownerDocument, cache = /* @__PURE__ */ new WeakMap());
	let namespaces = cache.get(program);
	if (!namespaces) cache.set(program, namespaces = /* @__PURE__ */ new Map());
	const namespace = materializedNamespace(program, parentNode);
	let state = namespaces.get(namespace);
	if (!state) namespaces.set(namespace, state = { uses: 0 });
	state.uses++;
	if (state.template) return state.template.content.cloneNode(true);
	const template = createProgramTemplate(program, ownerDocument, namespace);
	if (state.uses > 1) {
		state.template = template;
		return template.content.cloneNode(true);
	}
	return template.content;
}
function createProgramTemplate(program, ownerDocument, namespace) {
	const template = ownerDocument.createElement("template");
	if (namespace === "html") template.innerHTML = program.template;
	else {
		const namespaceUri = namespace === "svg" ? SVG_NAMESPACE : MATHML_NAMESPACE;
		const wrapper = ownerDocument.createElementNS(namespaceUri, namespace === "svg" ? "svg" : "math");
		wrapper.innerHTML = program.template;
		while (wrapper.firstChild) template.content.append(wrapper.firstChild);
	}
	return template;
}
function materializedNamespace(program, parentNode) {
	if (program.namespace !== "contextual") return program.namespace;
	if (!program.attachmentTag) throw new TypeError("Contextual eXact render program omitted its attachment tag");
	const parent = parentNode instanceof Element ? parentNode : void 0;
	const namespace = namespaceForTag(program.attachmentTag, parent) ?? "http://www.w3.org/1999/xhtml";
	return namespace === "http://www.w3.org/2000/svg" ? "svg" : namespace === "http://www.w3.org/1998/Math/MathML" ? "mathml" : "html";
}
//#endregion
//#region packages/dom/dist/client/renderer/render-program-operation.js
/** Mounts one compiler-specialized browser program. */
function mountRenderProgram(root, value, scope, parentInstance, parentNode) {
	const invocation = readRenderProgram(value);
	if (!invocation) return void 0;
	const bindingOwner = invocation.owner ?? parentInstance;
	const program = directProgram(invocation.program);
	const fragment = materializeProgramTemplate(program, root.container.ownerDocument, parentNode ?? root.container);
	if (!fragment.firstChild || fragment.firstChild !== fragment.lastChild) return void 0;
	const dom = fragment.firstChild;
	if (!(dom instanceof Element)) return void 0;
	const direct = claimCompiledRenderProgram(program, dom, "template");
	if (!direct) return void 0;
	const receipt = readRenderProgramReceipt(value);
	if (!receipt) return void 0;
	const mounted = {
		renderProgramReceipt: receipt,
		dom,
		scope,
		children: [],
		renderProgram: {
			invocation,
			programRoot: dom,
			slotNodes: direct.slotNodes,
			...direct.componentSlots ? { componentSlots: direct.componentSlots } : {},
			root,
			bindingOwner,
			parentInstance
		}
	};
	if (bindingOwner) ownDirectProgramNodes(direct.elements, bindingOwner);
	if (renderProgramHasBindings(program) && !bindRenderProgram(mounted)) {
		releaseDirectProgramNodeOwners(direct.elements);
		return;
	}
	countProgramWork(root, direct.work, false);
	return mounted;
}
/** Reports whether a direct program owns any invocation-local client bindings. */
function renderProgramHasBindings(program) {
	return program.wire ? program.wire[2].length !== 0 : Boolean(program.bind);
}
/** Rebinds invocation-local readers when a component publishes the same program again. */
function patchRenderProgram(mounted, value) {
	const invocation = readRenderProgram(value);
	if (!invocation || !mounted.renderProgram || mounted.renderProgram.invocation.program.id !== invocation.program.id) return false;
	const receipt = readRenderProgramReceipt(value);
	if (!receipt) return false;
	mounted.renderProgramReceipt = receipt;
	mounted.renderProgram.invocation = invocation;
	mounted.renderProgram.refresh?.();
	return true;
}
/** Charges compiler-proven program work without walking its static DOM. */
function countProgramWork(root, work, includeRoot) {
	const [nodes, slots] = work;
	for (let index = includeRoot ? 0 : 1; index < nodes; index++) countDomWork(root);
	if (!includeRoot) for (let index = 0; index < slots; index++) countDomWork(root);
}
/** Requires the compiler-closed browser claim contract. */
function directProgram(program) {
	if (!program.directClaims) throw new TypeError("Browser rendering requires a compiler-specialized client program");
	return program;
}
//#endregion
//#region packages/dom/dist/client/renderer/structural-capability.js
var structuralBoundaryCapability;
/** Requires native structural-boundary rendering selected for this artifact. */
function requireStructuralBoundaryCapability() {
	if (!structuralBoundaryCapability) throw new Error("Activity or Suspense rendering is unavailable because this artifact did not include the structural boundary capability");
	return structuralBoundaryCapability;
}
//#endregion
//#region packages/dom/dist/client/renderer/structural-range-receipt.js
/** Mounts one compiler-owned transparent range. */
function mountFragmentReceipt(root, receipt, scope, parentInstance, parentNode) {
	const mounted = {
		fragmentReceipt: receipt,
		dom: createMarker(root, "fragment"),
		scope,
		children: []
	};
	mounted.children = mountDetachedChildren(root, [...receipt.children], parentInstance, scope, parentNode);
	return mounted;
}
/** Patches one compiler-owned transparent range in place. */
function patchFragmentReceipt(root, parent, mounted, next, parentInstance) {
	mounted.fragmentReceipt = next;
	mounted.children = patchChildren(root, parent, mounted.children, [...next.children], parentInstance, mounted.scope, afterMountedChildren(mounted), mounted);
	return mounted;
}
//#endregion
//#region packages/dom/dist/client/renderer/unsafe-html-capability.js
var unsafeHtmlDomCapability;
/** Requires the unsafe-HTML range renderer selected for this artifact. */
function requireUnsafeHtmlDomCapability() {
	if (!unsafeHtmlDomCapability) throw new Error("unsafeHtml() rendering is unavailable because this artifact did not include the DOM capability");
	return unsafeHtmlDomCapability;
}
//#endregion
//#region packages/dom/dist/client/renderer/patching/keyed-operation.js
/** Updates one compiler-keyed child while retaining its range and reactive owner scope. */
function patchKeyedOperation(root, parent, mounted, operation, data, parentInstance, parentScope, structuralOwner) {
	const retainedRange = mounted.range === "item" ? mounted : void 0;
	const previous = retainedRange?.children[0] ?? mounted;
	const previousScope = retainedRange?.scope;
	const nextScope = data.ownerScope ?? previousScope ?? createEffectScope(parentScope);
	if (data.ownerScope && nextScope !== previousScope) transferEffectScope(nextScope, parentScope);
	const patchedChildren = patchChildren(root, parent, [previous], [data.value], parentInstance, nextScope, void 0, structuralOwner);
	if (patchedChildren.length !== 1) throw new Error("A keyed compiler operation must contribute one child range");
	const patched = patchedChildren[0];
	if (retainedRange) {
		if (patched.scope !== nextScope) transferEffectScope(patched.scope, nextScope);
		if (previousScope && previousScope !== nextScope) previousScope.stop();
		retainedRange.operation = operation;
		retainedRange.operationKey = data.key;
		retainedRange.scope = nextScope;
		retainedRange.dom = patched.dom;
		retainedRange.end = patched.end;
		retainedRange.children = [patched];
		return retainedRange;
	}
	return {
		operation,
		operationKey: data.key,
		range: "item",
		dom: patched.dom,
		...patched.end ? { end: patched.end } : {},
		scope: nextScope,
		children: [patched]
	};
}
//#endregion
//#region packages/dom/dist/client/renderer/patching/portal.js
/** Updates a focused portal while preserving its logical owner and physical target range. */
function patchPortalReceipt(root, mounted, receipt, parentInstance) {
	const previousTarget = mounted.portalTarget ?? portalTarget(mounted.portalReceipt);
	const nextTarget = portalTarget(receipt);
	mounted.portalReceipt = receipt;
	if (previousTarget !== nextTarget) {
		mounted.children = patchChildren(root, previousTarget, mounted.children, [], parentInstance, mounted.scope);
		mounted.portalTarget = nextTarget;
		const eventContainer = portalEventContainer(root, nextTarget);
		if (eventContainer === nextTarget) root.portalTargets.add(nextTarget);
		mounted.children = withEventContainer(root, eventContainer, () => mountDetachedChildren(root, [...receipt.children], parentInstance, mounted.scope, nextTarget));
		for (const child of mounted.children) placeMountedBefore(root, nextTarget, child, null);
		return;
	}
	mounted.children = withEventContainer(root, portalEventContainer(root, nextTarget), () => patchChildren(root, nextTarget, mounted.children, [...receipt.children], parentInstance, mounted.scope));
}
//#endregion
//#region packages/dom/dist/client/renderer/patching/native-operation-target.js
/** DOM target that decides in-place compatibility and applies one opaque component operation. */
var NativePatchOperationTarget = class {
	mounted;
	root;
	parent;
	parentInstance;
	parentScope;
	structuralOwner;
	constructor(mounted, root, parent, parentInstance, parentScope, structuralOwner) {
		this.mounted = mounted;
		this.root = root;
		this.parent = parent;
		this.parentInstance = parentInstance;
		this.parentScope = parentScope;
		this.structuralOwner = structuralOwner;
	}
	[exactKeyedChildOperation](operation, data) {
		if (this.mounted.operationKey !== data.key) return void 0;
		if (!this.root || !this.parent) return this.mounted;
		return patchKeyedOperation(this.root, this.parent, this.mounted, operation, data, this.parentInstance, this.parentScope, this.structuralOwner);
	}
	[exactRenderProgramOperation](operation, data) {
		if (this.mounted.renderProgram?.invocation.program.id !== data.invocation.program.id) return void 0;
		if (!this.root || !this.parent) return this.mounted;
		return patchRenderProgram(this.mounted, operation) ? this.mounted : void 0;
	}
	[exactComponentOperation](_operation, data) {
		const previous = this.mounted.componentReceipt;
		if (previous?.contract.artifact !== data.contract.artifact || previous.key !== data.key || previous.domain !== data.domain) return void 0;
		if (!this.root || !this.parent) return this.mounted;
		return receiveComponentReceipt(this.mounted, data) ? this.mounted : void 0;
	}
	[exactIntrinsicOperation](_operation, data) {
		const previous = this.mounted.intrinsicReceipt;
		if (previous?.tag !== data.tag || previous.key !== data.key || previous.domain !== data.domain) return void 0;
		if (!this.root || !this.parent) return this.mounted;
		this.mounted.intrinsicReceipt = data;
		this.mounted.children = patchChildren(this.root, this.mounted.dom, this.mounted.children, [...data.children], this.parentInstance, this.mounted.scope, void 0, this.mounted);
		updateTargetedIntrinsicProps(this.root, this.mounted, { ...previous.props }, { ...data.props });
		return this.mounted;
	}
	[exactChildRangeOperation](_operation, data) {
		const previous = this.mounted.childRangeReceipt;
		if (!previous || previous.markerId !== data.markerId || previous.domain !== data.domain) return void 0;
		if (!this.root || !this.parent) return this.mounted;
		patchChildRangeReceipt(this.root, this.parent, this.mounted, data, this.parentInstance);
		return this.mounted;
	}
	[exactActivityOperation](_operation, data) {
		if (this.mounted.activityReceipt?.domain !== data.domain) return void 0;
		if (!this.root || !this.parent) return this.mounted;
		requireStructuralBoundaryCapability().patchActivityReceipt(this.root, this.parent, this.mounted, data);
		return this.mounted;
	}
	[exactSuspenseOperation](_operation, data) {
		if (this.mounted.suspenseReceipt?.domain !== data.domain) return void 0;
		if (!this.root || !this.parent) return this.mounted;
		requireStructuralBoundaryCapability().patchSuspenseReceipt(this.root, this.parent, this.mounted, data, this.parentInstance);
		return this.mounted;
	}
	[exactFragmentOperation](_operation, data) {
		const previous = this.mounted.fragmentReceipt;
		if (!previous || previous.key !== data.key || previous.domain !== data.domain) return void 0;
		if (!this.root || !this.parent) return this.mounted;
		patchFragmentReceipt(this.root, this.parent, this.mounted, data, this.parentInstance);
		return this.mounted;
	}
	[exactTargetOperation](_operation, data) {
		const previous = this.mounted.targetReceipt;
		if (!previous || previous.key !== data.key || previous.domain !== data.domain) return void 0;
		if (!this.root || !this.parent) return this.mounted;
		requireTargetDomCapability().patch(this.root, this.parent, this.mounted, data, this.parentInstance);
		return this.mounted;
	}
	[exactUnsafeHtmlOperation](_operation, data) {
		if (this.mounted.unsafeHtmlReceipt?.domain !== data.domain) return void 0;
		if (!this.root || !this.parent) return this.mounted;
		this.mounted.unsafeHtmlReceipt = data;
		const capability = requireUnsafeHtmlDomCapability();
		capability.assertAllowed(this.root);
		capability.bind(this.root, this.mounted, data.value);
		return this.mounted;
	}
	[exactPortalOperation](_operation, data) {
		if (this.mounted.portalReceipt?.domain !== data.domain) return void 0;
		if (!this.root || !this.parent) return this.mounted;
		patchPortalReceipt(this.root, this.mounted, data, this.parentInstance);
		return this.mounted;
	}
	[exactServerBoundaryOperation](_operation, _data) {}
	[exactServerSlotOperation](_operation, data) {
		if (this.mounted.serverSlotReceipt?.id !== data.id) return void 0;
		if (!this.root || !this.parent) return this.mounted;
		this.mounted.serverSlotReceipt = data;
		return this.mounted;
	}
};
/** Reports whether a mounted range can receive an opaque operation without replacement. */
function canPatchOpaqueOperation(mounted, value) {
	return executeOpaqueOperation(value, new NativePatchOperationTarget(mounted))?.value !== void 0;
}
/** Applies one opaque operation when its target-specific identity matches the mounted range. */
function patchOpaqueOperation(root, parent, mounted, value, parentInstance, parentScope, structuralOwner) {
	const result = executeOpaqueOperation(value, new NativePatchOperationTarget(mounted, root, parent, parentInstance, parentScope, structuralOwner))?.value;
	if (result) result.operation = value;
	return result;
}
//#endregion
//#region packages/dom/dist/client/renderer/patching/replacement-parking.js
/** Parks every descendant outside the replaced component's immutable domain. */
function createForeignReplacementParking(owner, fallbackParent) {
	const parking = {
		mounts: /* @__PURE__ */ new Map(),
		commits: []
	};
	if (owner.instance) parkForeignMounts(owner, owner.instance.domain, parking.mounts, fallbackParent);
	return parking;
}
/** Detaches descendants from foreign component domains so a replacement can reclaim them. */
function parkForeignMounts(owner, replacedDomain, parking, fallbackParent) {
	const retained = [];
	for (const child of owner.children) {
		const domain = child.instance?.domain ?? child.componentReceipt?.domain;
		const operation = child.operation ?? child.componentReceipt;
		if (operation && domain && domain !== replacedDomain) {
			const candidates = parking.get(operation) ?? [];
			candidates.push({
				mounted: child,
				parent: child.dom.parentNode ?? fallbackParent
			});
			parking.set(operation, candidates);
			continue;
		}
		parkForeignMounts(child, replacedDomain, parking, child.portalTarget ?? fallbackParent);
		retained.push(child);
	}
	owner.children = retained;
}
//#endregion
//#region packages/dom/dist/client/renderer/patching/children.js
/** Performs the patch children domain operation. */
function patchChildren(root, parent, oldChildren, nextChildren, parentInstance, parentScope, before, structuralOwner) {
	if (root.interactionWork) root.interactionWork.reconciliations++;
	domDebug(root, "patch children", () => ({
		parent: describeNode(parent),
		oldCount: oldChildren.length,
		nextCount: nextChildren.length,
		before: describeNode(before)
	}));
	return withDomWork(root, () => preserveFocus(root, () => {
		return patchMixedNativeChildren(root, parent, oldChildren, mixedChildOperations(nextChildren), parentInstance, parentScope, before, structuralOwner);
	}));
}
/** Reconciles scalar, explicit foreign, and native-operation siblings without conversion. */
function patchMixedNativeChildren(root, parent, oldChildren, next, parentInstance, parentScope, before, structuralOwner) {
	const oldKeys = /* @__PURE__ */ new Map();
	const oldUnkeyed = [];
	for (let index = 0; index < oldChildren.length; index++) {
		const mounted = oldChildren[index];
		const key = mountedChildKey(mounted);
		if (key === void 0) oldUnkeyed.push({
			mounted,
			index
		});
		else {
			if (oldKeys.has(key)) throw new Error(`Duplicate key "${key}" in mounted children`);
			oldKeys.set(key, {
				mounted,
				index
			});
		}
	}
	const seenKeys = /* @__PURE__ */ new Set();
	const matches = new Array(next.length);
	let unkeyedIndex = 0;
	for (let index = 0; index < next.length; index++) {
		const operation = next[index];
		if (operation.key === void 0) matches[index] = oldUnkeyed[unkeyedIndex++];
		else {
			if (seenKeys.has(operation.key)) throw new Error(`Duplicate key "${operation.key}" in rendered children`);
			seenKeys.add(operation.key);
			matches[index] = oldKeys.get(operation.key);
		}
	}
	const matched = new Set(matches.flatMap((entry) => entry ? [entry.mounted] : []));
	const stable = longestIncreasingSubsequencePositions(matches.map((entry) => entry?.index ?? -1));
	const mounted = new Array(next.length);
	let cursor = before ?? null;
	for (let index = next.length - 1; index >= 0; index--) {
		const operation = next[index];
		const previous = matches[index];
		const current = operation.native ? previous ? Object.is(previous.mounted.operation, operation.value) ? previous.mounted : patchCompilerChildReceipt(root, parent, previous.mounted, operation.value, parentInstance, parentScope, void 0) : (() => {
			const reversed = takeReversedRelease(root, parent, operation.value);
			return reversed ? patchCompilerChildReceipt(root, parent, reversed, operation.value, parentInstance, parentScope, void 0) : mountDetachedChildren(root, [operation.value], parentInstance, parentScope, parent)[0];
		})() : operation.scalar !== void 0 ? patchScalarChild(root, parent, previous?.mounted, operation.value, operation.scalar, parentInstance, parentScope) : (() => {
			throw new TypeError("Unsupported native child operation");
		})();
		mounted[index] = current;
		if (!previous || !stable.has(index)) placeMountedBefore(root, parent, current, cursor);
		cursor = current.dom;
	}
	const teardown = teardownFailure();
	for (const old of oldChildren) {
		if (matched.has(old)) continue;
		if (!releaseMountedRange(root, parent, old, "reconcile-removed")) {
			attemptTeardown(teardown, () => unmountMounted(old));
			attemptTeardown(teardown, () => removeMountedNodes(parent, old));
		}
	}
	throwTeardownFailure(teardown);
	completeChildReconciliation(root, parentInstance, structuralOwner);
	return mounted;
}
/** Patches one compiler-issued operation without normalizing it into renderer topology. */
function patchCompilerChildReceipt(root, parent, oldChild, next, parentInstance, parentScope, structuralOwner) {
	if (oldChild.enhancement && canPatchOpaqueOperation(oldChild.enhancement.target, next)) return requireDomEnhancementCapability().patch(root, oldChild, next, parent, parentInstance, parentScope, (current, value, instance, scope) => current ? patchCompilerChildReceipt(root, parent, current, value, instance, scope, structuralOwner) : mountDetachedOperation(root, value, instance, scope, parent));
	const patched = patchOpaqueOperation(root, parent, oldChild, next, parentInstance, parentScope, structuralOwner);
	if (patched) {
		completeChildReconciliation(root, parentInstance, structuralOwner);
		return patched;
	}
	const previousParking = root.replacementParking;
	const parking = createForeignReplacementParking(oldChild, parent);
	root.replacementParking = parking;
	let replacement;
	try {
		replacement = mountDetachedChildren(root, [next], parentInstance, parentScope, parent)[0];
	} finally {
		root.replacementParking = previousParking;
	}
	if (!replacement) throw new Error("Compiler-issued child operation did not mount a range");
	for (const commit of parking.commits) commit();
	placeMountedBefore(root, parent, replacement, oldChild.dom);
	if (!releaseMountedRange(root, parent, oldChild, "reconcile-replaced")) {
		unmountMounted(oldChild);
		removeMountedNodes(parent, oldChild);
	}
	for (const remaining of parking.mounts.values()) for (const parked of remaining) disposeMounted(parked.parent, parked.mounted);
	completeChildReconciliation(root, parentInstance, structuralOwner);
	return replacement;
}
/** Updates native scalar text or replaces a differently owned range as one operation. */
function patchScalarChild(root, parent, mounted, value, scalar, parentInstance, parentScope) {
	if (mounted?.scalar && mounted.dom.nodeType === 3) {
		if (mounted.scalarValue !== scalar) mounted.dom.data = scalar;
		mounted.scalarValue = scalar;
		bindText(mounted, value);
		return mounted;
	}
	const replacement = mountDetachedOperation(root, value, parentInstance, parentScope, parent);
	if (!mounted) return replacement;
	placeMountedBefore(root, parent, replacement, mounted.dom);
	if (!releaseMountedRange(root, parent, mounted, "reconcile-replaced")) {
		unmountMounted(mounted);
		removeMountedNodes(parent, mounted);
	}
	return replacement;
}
//#endregion
//#region packages/dom/dist/client/renderer/child-range-receipt.js
/** Mounts one focused compiler-owned child-range operation. */
function mountChildRangeReceipt(root, receipt, scope, parentInstance, parentNode) {
	const mounted = {
		childRangeReceipt: receipt,
		dom: createMarker(root, "dynamic"),
		scope,
		children: []
	};
	const initial = rangeChildren(receipt, parentInstance, (registration) => {
		ownSuspensionRegistration(mounted, registration);
	});
	mounted.dynamicChildren = initial;
	mounted.children = mountDetachedChildren(root, initial, parentInstance, scope, parentNode);
	installRangeWatch(root, mounted, receipt, parentInstance);
	return mounted;
}
/** Rebinds a stable compiler-owned range to its next opaque authored value. */
function patchChildRangeReceipt(root, parent, mounted, receipt, parentInstance) {
	mounted.stop?.();
	mounted.stop = void 0;
	mounted.childRangeReceipt = receipt;
	mounted.suspensionRegistration?.cancel();
	mounted.suspensionRegistration = void 0;
	const next = rangeChildren(receipt, parentInstance, (registration) => {
		ownSuspensionRegistration(mounted, registration);
	});
	mounted.dynamicChildren = next;
	mounted.children = patchChildren(root, parent, mounted.children, next, parentInstance, mounted.scope, afterMountedChildren(mounted), mounted);
	installRangeWatch(root, mounted, receipt, parentInstance, parent);
	return mounted;
}
function installRangeWatch(root, mounted, receipt, parentInstance, fallbackParent) {
	let reconciling = false;
	let pending;
	const reconcile = () => {
		const next = rangeChildren(receipt, parentInstance, (registration) => {
			ownSuspensionRegistration(mounted, registration);
		});
		if (reconciling) {
			pending = next;
			return;
		}
		reconciling = true;
		try {
			let candidate = next;
			while (candidate) {
				pending = void 0;
				if (!sameRangeChildren(mounted.dynamicChildren, candidate)) {
					const parent = mounted.dom.parentNode ?? fallbackParent;
					if (!parent) {
						for (const child of mounted.children) disposeMounted(document.createDocumentFragment(), child);
						mounted.dynamicChildren = candidate;
						mounted.children = mountDetachedChildren(root, candidate, parentInstance, mounted.scope);
						candidate = pending;
						continue;
					}
					mounted.dynamicChildren = candidate;
					mounted.children = peek(() => patchChildren(root, parent, mounted.children, candidate, parentInstance, mounted.scope, afterMountedChildren(mounted), mounted));
					if (parentInstance) refreshComponentRoot(parentInstance);
				}
				candidate = pending;
			}
		} finally {
			reconciling = false;
			pending = void 0;
		}
	};
	mounted.stop = watchStructural(reconcile, {
		scope: mounted.scope,
		onSchedule: reconcile
	});
}
/** Retains one cancellation handle per pending settlement owned by a compiled range. */
function ownSuspensionRegistration(mounted, registration) {
	const previous = mounted.suspensionRegistration;
	if (previous?.settlement === registration.settlement) {
		registration.cancel();
		return;
	}
	previous?.cancel();
	mounted.suspensionRegistration = registration;
}
/** Installs retained updates after hydration has claimed a compiler-owned child range. */
function installAdoptedChildRangeReceipt(root, mounted, receipt, parentInstance) {
	installRangeWatch(root, mounted, receipt, parentInstance, mounted.dom.parentNode ?? void 0);
}
/** Reads a range through the existing component error and suspension ownership. */
function rangeChildren(receipt, parentInstance, onSuspension) {
	const dynamic = receipt.dynamicComponent;
	if (dynamic?.inspection.status === "pending") {
		const pending = dynamic.readiness?.();
		if (pending) {
			const registration = registerComponentSuspension(parentInstance, pending);
			if (registration !== true && registration !== false) onSuspension?.(registration);
		}
		return [];
	}
	if (dynamic?.inspection.status === "failed") {
		const fallback = handleComponentError(parentInstance, createErrorReport(dynamic.inspection.error, "render", parentInstance, "dynamic-component"));
		return fallback ? normalizeRenderResult(fallback()) : [];
	}
	try {
		return normalizeRenderResult(unwrap(receipt.value));
	} catch (error) {
		if (isPromiseLike(error)) {
			handleComponentSuspension(parentInstance, error);
			return [];
		}
		const fallback = handleComponentError(parentInstance, createErrorReport(error, "render", parentInstance, "compiled-child-range"));
		return fallback ? normalizeRenderResult(fallback()) : [];
	}
}
function sameRangeChildren(previous, next) {
	if (!previous || previous.length !== next.length) return false;
	for (let index = 0; index < next.length; index++) if (!Object.is(previous[index], next[index])) return false;
	return true;
}
function isPromiseLike(value) {
	return (typeof value === "object" || typeof value === "function") && value !== null && typeof value.then === "function";
}
//#endregion
//#region packages/dom/dist/client/renderer/mounting/native-operation-target.js
/**
* Redeems compiler-issued operations without inspecting an operation kind or payload at the call
* site. Each operation invokes one shared symbol method selected when the compiler created it.
*/
var NativeMountOperationTarget = class {
	root;
	parentInstance;
	parentScope;
	parentNode;
	constructor(root, parentInstance, parentScope, parentNode) {
		this.root = root;
		this.parentInstance = parentInstance;
		this.parentScope = parentScope;
		this.parentNode = parentNode;
	}
	/** Mounts a compiler-issued component operation into this target. */
	[exactComponentOperation](_operation, data) {
		return mountComponentReceipt(this.root, data, this.parentInstance, this.parentScope, this.parentNode);
	}
	/** Mounts a compiler-closed render program into this target. */
	[exactRenderProgramOperation](operation, _data) {
		const mounted = mountRenderProgram(this.root, operation, createEffectScope(this.parentScope), this.parentInstance, this.parentNode);
		if (!mounted) throw new Error("Compiler-closed render program could not be mounted");
		return mounted;
	}
	/** Mounts a compiler-issued intrinsic operation into this target. */
	[exactIntrinsicOperation](_operation, data) {
		return withTreeDepth(this.root, () => mountIntrinsicReceipt(this.root, data, createEffectScope(this.parentScope), this.parentInstance, this.parentNode));
	}
	/** Mounts a compiler-issued fragment range into this target. */
	[exactFragmentOperation](_operation, data) {
		return mountFragmentReceipt(this.root, data, createEffectScope(this.parentScope), this.parentInstance, this.parentNode);
	}
	/** Mounts a compiler-issued semantic target range. */
	[exactTargetOperation](_operation, data) {
		return requireTargetDomCapability().mount(this.root, data, createEffectScope(this.parentScope), this.parentInstance, this.parentNode);
	}
	/** Mounts a focused compiler-owned child range. */
	[exactChildRangeOperation](_operation, data) {
		return mountChildRangeReceipt(this.root, data, createEffectScope(this.parentScope), this.parentInstance, this.parentNode);
	}
	/** Mounts a retained Activity boundary through its installed capability. */
	[exactActivityOperation](_operation, data) {
		return requireStructuralBoundaryCapability().mountActivityReceipt(this.root, data, createEffectScope(this.parentScope), this.parentInstance, this.parentNode);
	}
	/** Mounts a Suspense boundary through its installed capability. */
	[exactSuspenseOperation](_operation, data) {
		return requireStructuralBoundaryCapability().mountSuspenseReceipt(this.root, data, createEffectScope(this.parentScope), this.parentInstance, this.parentNode);
	}
	/** Mounts audited raw HTML through its installed capability. */
	[exactUnsafeHtmlOperation](_operation, data) {
		return requireUnsafeHtmlDomCapability().mount(this.root, data, this.parentScope);
	}
	/** Mounts one compiler-owned keyed child range. */
	[exactKeyedChildOperation](operation, data) {
		const itemScope = data.ownerScope ?? createEffectScope(this.parentScope);
		if (data.ownerScope) transferEffectScope(itemScope, this.parentScope);
		const child = mountDetachedChildren(this.root, [data.value], this.parentInstance, itemScope, this.parentNode)[0];
		if (!child) {
			itemScope.stop();
			throw new Error("A keyed compiler operation must contribute one child range");
		}
		return {
			operation,
			operationKey: data.key,
			range: "item",
			dom: child.dom,
			...child.end ? { end: child.end } : {},
			scope: itemScope,
			children: [child]
		};
	}
	/** Mounts a compiler-issued portal in its foreign container. */
	[exactPortalOperation](_operation, data) {
		return mountPortalReceipt(this.root, data, this.parentInstance, this.parentScope);
	}
	/** Rejects a server-only publication at the client DOM boundary. */
	[exactServerBoundaryOperation](_operation, data) {
		throw new TypeError(`A server boundary cannot be mounted by the DOM target (${data.name})`);
	}
	/** Mounts a retained server slot for client hydration ownership. */
	[exactServerSlotOperation](_operation, data) {
		return mountServerSlotReceipt(this.root, data, createEffectScope(this.parentScope));
	}
};
/** Retains the authored operation as the opaque identity used by later target updates. */
function retainMountedOperation(mounted, operation) {
	mounted.operation = operation;
	return mounted;
}
//#endregion
//#region packages/dom/dist/client/renderer/mounting/children.js
/** Mounts one opaque compiler or compatibility child operation. */
function mountDetachedOperation(root, value, parentInstance, parentScope, parentNode) {
	const parked = takeParkedOperation(root, value, parentInstance, parentScope);
	if (parked) return parked;
	const mounted = mountDetachedChildren(root, [value], parentInstance, parentScope, parentNode);
	if (mounted.length !== 1) throw new Error("A renderer child operation must contribute exactly one mounted range");
	return mounted[0];
}
/** Performs the mount detached children domain operation. */
function mountDetachedChildren(root, children, parentInstance, parentScope, parentNode) {
	assertUniqueChildKeys(children);
	const mounted = [];
	const operationTarget = new NativeMountOperationTarget(root, parentInstance, parentScope, parentNode);
	try {
		for (const child of children) {
			const parked = takeParkedOperation(root, child, parentInstance, parentScope);
			if (parked) {
				mounted.push(parked);
				continue;
			}
			const enhanced = mountEnhancedCompilerOperation(root, child, parentInstance, parentScope, parentNode);
			if (enhanced) {
				mounted.push(enhanced);
				continue;
			}
			const executed = executeOpaqueOperation(child, operationTarget);
			if (executed) {
				mounted.push(retainMountedOperation(executed.value, child));
				continue;
			}
			const scalar = scalarText(child);
			if (scalar !== void 0) {
				countDomWork(root);
				const scope = createEffectScope(parentScope);
				const textMounted = {
					scalar: true,
					scalarValue: scalar,
					dom: document.createTextNode(scalar),
					scope,
					children: []
				};
				bindText(textMounted, child);
				mounted.push(textMounted);
				continue;
			}
			if (child === null || child === void 0 || child === false || child === true) {
				countDomWork(root);
				continue;
			}
			throw new TypeError("Native eXact children must be compiler-issued operations, scalar values, or empty placeholders");
		}
		return mounted;
	} catch (error) {
		rollbackMountedChildren(mounted, void 0, error);
		throw error;
	}
}
/** Mounts one focused portal operation while retaining logical ownership in its source tree. */
function mountPortalReceipt(root, receipt, parentInstance, parentScope) {
	const scope = createEffectScope(parentScope);
	const marker = document.createComment("exact:portal");
	const target = portalTarget(receipt);
	const mounted = {
		portalReceipt: receipt,
		dom: marker,
		scope,
		children: [],
		portalTarget: target
	};
	const eventContainer = portalEventContainer(root, target);
	if (eventContainer === target) root.portalTargets.add(target);
	mounted.children = withEventContainer(root, eventContainer, () => mountChildren(root, target, [...receipt.children], parentInstance, scope));
	return mounted;
}
/** Performs the mount children domain operation. */
function mountChildren(root, parent, children, parentInstance, parentScope) {
	const mounted = mountDetachedChildren(root, children, parentInstance, parentScope, parent);
	try {
		for (const childMounted of mounted) {
			if (childMounted.serverSlotReceipt) adoptServerSlot(parent, childMounted);
			placeMountedBefore(root, parent, childMounted, null);
		}
		return mounted;
	} catch (error) {
		rollbackMountedChildren(mounted, parent, error);
		throw error;
	}
}
/** Applies compiler-carried enhancement declarations without interpreting target topology. */
function mountEnhancedCompilerOperation(root, value, parentInstance, parentScope, parentNode) {
	const capability = domEnhancementCapability();
	if (!capability || !capability.has(value) || (root.enhancementNesting ?? 0) > 0) return void 0;
	const mountOperation = (next, instance, scope, node) => {
		const mounted = mountDetachedOperation(root, next, instance, scope, node);
		mounted.operation = next;
		return mounted;
	};
	capability.install(root, mountOperation);
	const direct = capability.mountDirect?.(root, value, parentInstance, parentScope, mountOperation);
	if (direct) return direct;
	root.enhancementNesting = 1;
	try {
		return capability.activate(root, mountOperation(value, parentInstance, parentScope, parentNode), parentInstance, parentScope, mountOperation);
	} finally {
		root.enhancementNesting = 0;
	}
}
/**
* Rolls back provisional children in reverse ownership order.
*
* Detached roots use a temporary parent only as the traversal origin; portal
* descendants still remove themselves from their actual portal targets.
*/
function rollbackMountedChildren(mounted, parent, primary) {
	for (let index = mounted.length - 1; index >= 0; index--) {
		const child = mounted[index];
		const removalParent = parent ?? child.dom.parentNode ?? document.createDocumentFragment();
		try {
			disposeMounted(removalParent, child);
		} catch (cleanup) {
			attachSuppressedCleanupFailure(primary, cleanup);
		}
	}
}
//#endregion
//#region packages/dom/dist/client/renderer/foreign-component-capability.js
var registryKey = Symbol.for("@exactjs/dom.foreign-component-capability.v1");
function registry() {
	const realm = globalThis;
	const current = realm[registryKey];
	if (current !== void 0) {
		if (!current || typeof current !== "object" || current.abi !== 1) throw new Error("Incompatible eXact DOM foreign component registry");
		return current;
	}
	const created = { abi: 1 };
	realm[registryKey] = created;
	return created;
}
/** Resolves the renderer selected by an explicit foreign component artifact. */
function requireForeignComponentCapability() {
	const capability = registry().capability;
	if (!capability) throw new Error("A foreign component artifact was used without its renderer integration");
	return capability;
}
//#endregion
//#region packages/dom/dist/client/renderer/mounting/native-component-artifact.js
var transparentComponentUpdateOwners = /* @__PURE__ */ new WeakMap();
/** Redeems one opaque component receipt through only its compiler-selected client attachment ABI. */
function mountComponentReceipt(root, receipt, parentInstance, parentScope, parentNode) {
	return withTreeDepth(root, () => {
		countDomWork(root);
		const scope = createEffectScope(parentScope);
		try {
			return mountNativeComponentArtifact(root, receipt, scope, parentInstance, parentNode);
		} catch (error) {
			scope.stop();
			throw error;
		}
	});
}
function mountNativeComponentArtifact(root, receipt, scope, parentInstance, parentNode) {
	const artifact = receipt.contract.artifact;
	if (artifact.target !== "client") throw new TypeError(`Component receipt selected non-client artifact ${artifact.id}`);
	const mounted = {
		componentReceipt: receipt,
		dom: createMarker(root, "component"),
		end: void 0,
		scope,
		children: [],
		clientArtifact: artifact
	};
	const target = new NativeClientAttachmentTarget(root, mounted, parentNode);
	try {
		const domain = receipt.domain ?? parentInstance?.domain ?? root.domain ?? pageComponentDomain;
		const initialProps = receipt.update ? resolvePropReceipt(receipt.props) : receipt.props;
		const instance = withEffectScope(scope, () => artifact.construct(parentInstance, componentProps(initialProps, resolveChildReceipt(receipt.children)), parentInstance?.ambientContexts ?? root.ambientContexts, domain, void 0, receipt.contract));
		ownMountedInstance(mounted, instance);
		const authoredUpdateOwner = componentReceiptUpdateOwner(parentInstance);
		if (receipt.transparentUpdateOwner && authoredUpdateOwner) transparentComponentUpdateOwners.set(instance, authoredUpdateOwner);
		artifact.attach(instance, target, "mount");
		bindComponentReceiptUpdate(mounted, authoredUpdateOwner, receipt);
		target.finishConstruction();
	} catch (error) {
		if (isDomRenderLimitError(error)) throw error;
		const output = handleComponentError(parentInstance, createErrorReport(error, "construct", parentInstance, artifact.id), null)?.();
		mounted.children = output === void 0 ? [] : mountDetachedChildren(root, Array.isArray(output) ? output : [output], parentInstance, scope, parentNode);
	}
	return mounted;
}
/** Joins one compiler-indexed parent dirty target to this retained child receipt. */
function bindComponentReceiptUpdate(mounted, owner, receipt) {
	const update = receipt.update;
	if (!update || !owner) return;
	const stopBindings = [];
	const target = {
		mounted,
		owner,
		stopBindings,
		valid: true
	};
	const wide = "words" in update.contract && typeof update.contract.words === "number";
	const receivesProps = "props" in update.contract && typeof update.contract.props === "number";
	if (wide) {
		if (receivesProps) bindCompiledWideComponentUpdate(target, update.target, update.contract);
		else bindCompiledWideStateComponentUpdate(target, update.target, update.contract);
	} else if (receivesProps) bindCompiledComponentUpdate(target, update.target, update.contract);
	else bindCompiledStateComponentUpdate(target, update.target, update.contract);
	if (stopBindings.length !== 0) mounted.stop = () => {
		for (const binding of stopBindings) binding.stop();
	};
}
/** Skips renderer-injected providers while retaining their semantic context parentage. */
function componentReceiptUpdateOwner(instance) {
	let owner = instance;
	const visited = /* @__PURE__ */ new Set();
	while (owner && !visited.has(owner)) {
		visited.add(owner);
		const transparent = transparentComponentUpdateOwners.get(owner);
		if (!transparent) return owner;
		owner = transparent;
	}
	return owner;
}
/** Resolves only compiler-marked prop operands; arbitrary objects remain opaque values. */
function resolvePropReceipt(props) {
	let resolved;
	for (const key of Object.keys(props)) {
		const value = props[key];
		const operand = Array.isArray(value) && value[0] === compiledReactivePropertyOperand ? value : void 0;
		if (!operand && !isReactiveValue(value)) continue;
		(resolved ??= { ...props })[key] = operand ? Reflect.get(operand[1], operand[2]) : unwrap(value);
	}
	return resolved ?? props;
}
/** Publishes the next compiler-issued receipt through its selected prop update contract. */
function receiveComponentReceipt(mounted, receipt) {
	if (!mounted.clientArtifact || !mounted.instance) return false;
	mounted.clientArtifact.receive(mounted.instance, receipt.update ? resolvePropReceipt(receipt.props) : receipt.props, resolveChildReceipt(receipt.children));
	mounted.componentReceipt = receipt;
	return true;
}
function componentProps(props, children) {
	const result = { ...props };
	if (children.length === 1) result.children = children[0];
	else if (children.length > 1) result.children = children;
	return result;
}
/** Resolves compiler-marked child operands to the finalized values in this receipt batch. */
function resolveChildReceipt(children) {
	return normalizeChildren(children.map((child) => unwrap(child)));
}
var NativeClientAttachmentTarget = class {
	root;
	mounted;
	parentNode;
	constructor(root, mounted, parentNode) {
		this.root = root;
		this.mounted = mounted;
		this.parentNode = parentNode;
	}
	[exactCompiledClientAttachment](artifact, instance, rendered, mode) {
		this.assertAttachment(artifact, instance, mode);
		this.mounted.children = mountDetachedChildren(this.root, rendered, instance, this.mounted.scope, this.parentNode);
		refreshComponentRoot(instance, true, rootIntroduction(this.root));
		this.mounted.afterPlacement = () => instance.markMounted();
		this.mounted.afterPlacementPhase = "mount";
		return this.mounted;
	}
	[exactCompatibilityClientAttachment](artifact, instance, mode) {
		this.assertAttachment(artifact, instance, mode);
		requireForeignComponentCapability().attach(this.root, this.mounted, artifact, instance, this.parentNode);
		return this.mounted;
	}
	finishConstruction() {
		return false;
	}
	assertAttachment(artifact, instance, mode) {
		if (mode !== "mount" || instance !== this.mounted.instance || artifact !== this.mounted.clientArtifact) throw new TypeError("Client component attached through an incompatible DOM target");
	}
};
//#endregion
//#region packages/dom/dist/client/renderer/root-construction.js
/** Constructs the common renderer-root state shared by mount and adoption entry points. */
function createRendererRoot(container, current, options, construction) {
	const domain = childDomain(current) ?? options.componentDomain ?? (options.inspection ? createFrameworkComponentDomain({
		executionRoot: options.inspection.executionRoot,
		inspection: options.inspection,
		logger: options.logger
	}) : void 0);
	const errors = createDomErrorContext(options, () => renderRootErrorView(root));
	const ambientEntries = [[ErrorContext.id, errors]];
	if (options.logger) ambientEntries.push([LoggerContext.id, options.logger]);
	const ambientContexts = new Map(ambientEntries);
	const root = {
		container,
		delegated: /* @__PURE__ */ new Map(),
		errors,
		portalTargets: /* @__PURE__ */ new Set(),
		current,
		version: construction.version,
		...domain ? { domain } : {},
		debugMarkers: false,
		maxTreeDepth: normalizeTreeDepth(options.maxTreeDepth),
		traversalDepth: 0,
		maxTreeNodes: normalizeTreeNodes(options.maxTreeNodes),
		traversedNodes: 0,
		workDepth: 0,
		focusTransactionDepth: 0,
		workBudget: options.workBudget,
		allowUnsafeHtml: options.allowUnsafeHtml ?? false,
		onUnsafeHtml: options.onUnsafeHtml,
		onProfile: options.onProfile,
		logger: options.logger,
		componentLogging: domain ? componentDomainLogging(domain) : void 0,
		ambientContexts,
		enhancementCatalog: options.enhancementCatalog,
		...construction.mode ? { mode: construction.mode } : {},
		...construction.markerlessHydration ? { markerlessHydration: true } : {}
	};
	return root;
}
/** Replaces an initialized root's failed output with its accumulated framework error view. */
function renderRootErrorView(root) {
	const mounted = root?.mounted;
	if (!mounted || root.errors.errors.length === 0) return;
	mounted.children = patchChildren(root, root.container, mounted.children, [createRootErrorView(root.errors.errors)], mounted.instance, mounted.scope, afterMountedChildren(mounted), mounted);
}
/** Reads compiler-owned domain identity without interpreting the operation's output. */
function childDomain(value) {
	return isOpaqueOperation(value) ? opaqueOperationDomain(value) : void 0;
}
//#endregion
//#region packages/dom/dist/client/framework/root-policy.js
/** Adds the inspection-owned domain required by a compiler-issued root operation. */
function resolveRootRenderOptions(domain, root, options, inspection = options.inspection) {
	return inspection && !domain && !root?.domain && !options.componentDomain ? {
		...options,
		componentDomain: createFrameworkComponentDomain({
			executionRoot: inspection.executionRoot,
			inspection,
			logger: options.logger
		})
	} : options;
}
/** Applies mutable root policy without changing operation or range ownership. */
function applyRootOptions(root, options) {
	root.logger = options.logger;
	root.debugMarkers = options.debugMarkers ?? false;
	root.workBudget = options.workBudget;
	root.allowUnsafeHtml = options.allowUnsafeHtml ?? root.allowUnsafeHtml;
	root.onUnsafeHtml = options.onUnsafeHtml ?? root.onUnsafeHtml;
	root.onProfile = options.onProfile ?? root.onProfile;
	root.enhancementCatalog = options.enhancementCatalog ?? root.enhancementCatalog;
}
//#endregion
//#region packages/dom/dist/client/renderer/adoption/component-attachment.js
/** Adopts the output supplied by one artifact through the same attachment ABI used for mounting. */
function attachHydratedComponent(root, mounted, artifact, instance, adopt) {
	const target = new DomClientHydrationTarget(root, mounted, adopt);
	artifact.attach(instance, target, "hydrate");
	if (!target.attached) return false;
	target.finishConstruction();
	return true;
}
/** One hydration cursor validating artifact identity before it adopts generated output. */
var DomClientHydrationTarget = class {
	root;
	mounted;
	adopt;
	attached = false;
	constructing = true;
	invalidatedDuringConstruction = false;
	constructor(root, mounted, adopt) {
		this.root = root;
		this.mounted = mounted;
		this.adopt = adopt;
	}
	[exactCompiledClientAttachment](artifact, instance, children, mode) {
		const attached = this.assertAttachment(artifact, instance, mode);
		return this.attachChildren(attached, children);
	}
	[exactCompatibilityClientAttachment](artifact, instance, mode) {
		const attached = this.assertAttachment(artifact, instance, mode);
		this.attached = requireForeignComponentCapability().hydrate(this.root, this.mounted, artifact, attached);
		return this.mounted;
	}
	finishConstruction() {
		this.constructing = false;
		return this.invalidatedDuringConstruction;
	}
	assertAttachment(artifact, instance, mode) {
		if (mode !== "hydrate" || instance !== this.mounted.instance || artifact !== this.mounted.clientArtifact) throw new TypeError("Client component attached through an incompatible hydration target");
		return instance;
	}
	attachChildren(instance, children) {
		const adopted = this.adopt(children);
		if (!adopted) throw new Error("Compiler-owned component output did not match the hydrated DOM");
		this.mounted.children = adopted;
		refreshComponentRoot(instance, true, rootIntroduction(this.root));
		instance.markMounted();
		this.attached = true;
		return this.mounted;
	}
};
//#endregion
//#region packages/dom/dist/client/renderer/adoption/component-receipt-identity.js
/** Locates one complete component marker pair by its selected artifact identity. */
function componentMarkerBoundaryByIdentity(nodes, cursor, identity, end = nodes.length) {
	const start = nodes[cursor];
	if (!(start instanceof Comment) || !start.data.startsWith("exact:component:")) return void 0;
	let endIndex = -1;
	for (let index = cursor + 1; index < end; index++) {
		const node = nodes[index];
		if (node instanceof Comment && node.data === `/${start.data}`) {
			endIndex = index;
			break;
		}
	}
	if (endIndex < 0) return void 0;
	const parts = start.data.split(":");
	return {
		start,
		endIndex,
		matches: parts.length >= 4 && decodeExactMarkerPart(parts[3]) === identity
	};
}
//#endregion
//#region packages/dom/dist/client/renderer/adoption/component-receipt.js
/** Adopts one opaque receipt through the artifact that issued it. */
function adoptComponentReceipt(root, receipt, nodes, cursor, parentInstance, parentScope, rangeEnd, omitCompilerOwnedBoundary) {
	const scope = createEffectScope(parentScope);
	const boundary = componentMarkerBoundaryByIdentity(nodes, cursor, receipt.contract.artifact.id, rangeEnd);
	if ((root.markerlessHydration || omitCompilerOwnedBoundary) && !boundary) return adoptMarkerlessReceipt(root, receipt, nodes, cursor, parentInstance, scope, rangeEnd);
	if (!boundary) {
		scope.stop();
		return;
	}
	if (!boundary.matches) {
		const parent = nodes[cursor]?.parentNode;
		if (!parent) {
			scope.stop();
			return;
		}
		scope.stop();
		const replacement = mountComponentReceipt(root, receipt, parentInstance, parentScope, parent);
		placeMountedBefore(root, parent, replacement, nodes[cursor]);
		for (let index = cursor; index <= boundary.endIndex; index++) {
			const stale = nodes[index];
			if (stale?.parentNode === parent) parent.removeChild(stale);
		}
		return {
			mounted: replacement,
			next: boundary.endIndex + 1
		};
	}
	const mounted = {
		componentReceipt: receipt,
		dom: boundary.start,
		end: nodes[boundary.endIndex],
		scope,
		children: [],
		clientArtifact: receiptClientArtifact(receipt)
	};
	try {
		const instance = constructReceipt(root, receipt, parentInstance);
		ownMountedInstance(mounted, instance);
		const artifact = mounted.clientArtifact;
		if (!attachHydratedComponent(root, mounted, artifact, instance, (children) => adoptComponentChildren(root, children, nodes, instance, scope, cursor + 1, boundary.endIndex))) {
			unmountMounted(mounted);
			return;
		}
		return {
			mounted,
			next: boundary.endIndex + 1
		};
	} catch {
		unmountMounted(mounted);
		return;
	}
}
function adoptMarkerlessReceipt(root, receipt, nodes, cursor, parentInstance, scope, rangeEnd) {
	const mounted = {
		componentReceipt: receipt,
		dom: document.createTextNode(""),
		end: void 0,
		scope,
		children: [],
		clientArtifact: receiptClientArtifact(receipt)
	};
	try {
		const instance = constructReceipt(root, receipt, parentInstance);
		ownMountedInstance(mounted, instance);
		let adoptedNext = cursor;
		const artifact = mounted.clientArtifact;
		if (!attachHydratedComponent(root, mounted, artifact, instance, (children) => {
			const adopted = adoptComponentChildren(root, children, nodes, instance, scope, cursor, rangeEnd);
			if (!adopted) return void 0;
			adoptedNext = rangeEnd;
			return adopted;
		})) return void 0;
		const first = mounted.children[0]?.dom;
		const last = mounted.children.at(-1);
		if (!first || !last) {
			const boundary = nodes[rangeEnd] ?? nodes[cursor];
			const parent = boundary?.parentNode;
			if (!parent) return void 0;
			parent.insertBefore(mounted.dom, boundary);
			mounted.end = document.createTextNode("");
			parent.insertBefore(mounted.end, boundary);
			return {
				mounted,
				next: adoptedNext
			};
		}
		const parent = first?.parentNode;
		if (!parent) return void 0;
		const endNode = last.end ?? last.dom;
		parent.insertBefore(mounted.dom, first);
		mounted.end = document.createTextNode("");
		parent.insertBefore(mounted.end, endNode.nextSibling);
		return {
			mounted,
			next: adoptedNext
		};
	} catch {
		unmountMounted(mounted);
		return;
	}
}
/** Returns the client artifact already selected by an opaque component operation. */
function receiptClientArtifact(receipt) {
	const artifact = receipt.contract.artifact;
	if (artifact.target !== "client") throw new TypeError("Hydration received a non-client component receipt");
	return artifact;
}
/** Constructs the durable instance selected by an adopted component operation. */
function constructReceipt(root, receipt, parent) {
	const artifact = receiptClientArtifact(receipt);
	const props = { ...receipt.props };
	if (receipt.children.length === 1) props.children = receipt.children[0];
	else if (receipt.children.length > 1) props.children = receipt.children;
	const domain = receipt.domain ?? parent?.domain ?? root.domain ?? pageComponentDomain;
	return withComponentResumption(domain, () => withEffectScope(parent?.scope, () => artifact.construct(parent, props, parent?.ambientContexts ?? root.ambientContexts, domain, void 0, receipt.contract)));
}
//#endregion
//#region packages/dom/dist/client/renderer/adoption/native-receipt.js
/** Adopts one direct intrinsic operation against its compiler-known host. */
function adoptIntrinsicReceipt(root, receipt, nodes, cursor, parentInstance, parentScope, adoptChildren) {
	const scope = createEffectScope(parentScope);
	const node = nodes[cursor];
	if (!(node instanceof Element) || node.tagName.toLowerCase() !== receipt.tag.toLowerCase()) {
		scope.stop();
		return;
	}
	const framework = frameworkChildRange(node);
	const children = adoptChildren(root, [...receipt.children], authoredChildNodes(node, framework), parentInstance, scope);
	if (!children) {
		scope.stop();
		return;
	}
	if (parentInstance) setElementOwner(node, parentInstance);
	updateProps(root, node, {}, receipt.props, scope, false);
	return {
		mounted: {
			intrinsicReceipt: receipt,
			dom: node,
			scope,
			children,
			...framework ? { childEnd: framework.start } : {}
		},
		next: cursor + 1
	};
}
/** Adopts one transparent or semantic-target receipt marker range. */
function adoptStructuralRangeReceipt(root, receipt, kind, nodes, cursor, parentInstance, parentScope, end, adoptChildren) {
	const scope = createEffectScope(parentScope);
	const start = nodes[cursor];
	if (!(start instanceof Comment) || !start.data.startsWith(`exact:${kind}:`)) {
		scope.stop();
		return;
	}
	const endIndex = closingMarkerIndex(nodes, cursor, start.data, end);
	if (endIndex < 0) {
		scope.stop();
		return;
	}
	const children = adoptChildren(root, [...receipt.children], nodes, parentInstance, scope, cursor + 1, endIndex);
	if (!children) {
		scope.stop();
		return;
	}
	const mounted = {
		...kind === "fragment" ? { fragmentReceipt: receipt } : {
			targetReceipt: receipt,
			targetBoundary: {}
		},
		dom: start,
		end: nodes[endIndex],
		scope,
		children
	};
	if (kind === "target") refreshTargetBoundary(root, mounted, parentInstance);
	return {
		mounted,
		next: endIndex + 1
	};
}
/** Adopts one focused dynamic range and installs its retained reader. */
function adoptChildRangeReceipt(root, receipt, nodes, cursor, parentInstance, parentScope, end, adoptChildren) {
	const scope = createEffectScope(parentScope);
	const start = nodes[cursor];
	if (!(start instanceof Comment) || !isChildRangeOpening(start.data)) {
		scope.stop();
		return;
	}
	const endIndex = closingMarkerIndex(nodes, cursor, start.data, end);
	if (endIndex < 0) {
		scope.stop();
		return;
	}
	const initial = receipt.dynamicComponent ? [] : rangeChildren(receipt, parentInstance);
	const children = adoptChildren(root, initial, nodes, parentInstance, scope, cursor + 1, endIndex);
	if (!children) {
		scope.stop();
		return;
	}
	const mounted = {
		childRangeReceipt: receipt,
		dom: start,
		end: nodes[endIndex],
		scope,
		children,
		dynamicChildren: initial
	};
	installAdoptedChildRangeReceipt(root, mounted, receipt, parentInstance);
	return {
		mounted,
		next: endIndex + 1
	};
}
//#endregion
//#region packages/dom/dist/client/renderer/render-program-adoption.js
/** Adopts every compiler-owned variable-width child range inside one program. */
function adoptProgramChildSlots(mounted, parentInstance, adoptChildren) {
	const state = mounted.renderProgram;
	const ownsLists = state.invocation.program.listBindings === true || state.invocation.program.keyedChildren !== void 0;
	if (ownsLists) parentInstance?.beginRender();
	try {
		for (let index = 0; index < state.slotNodes.length; index++) {
			const identity = structuralProgramSlotIdentity(state, index);
			if (identity === void 0) continue;
			const componentSlot = programComponentSlotIncludes(state.componentSlots, index);
			const start = state.slotNodes[index];
			const anchor = isKeyedChildAnchor$1(start) ? start : void 0;
			const marker = start instanceof Node ? start : void 0;
			const end = anchor ? void 0 : findProgramChildEnd(marker, identity);
			const parent = anchor?.[0] ?? marker?.parentNode;
			if (!parent || !anchor && (!(marker instanceof Comment) || !end)) return false;
			const nodes = Array.from(parent.childNodes, (node) => node);
			const cursor = anchor ? anchor[1] ? nodes.indexOf(anchor[1]) : nodes.length : nodes.indexOf(marker) + 1;
			const anchorEnd = anchor?.[2] ?? null;
			const endIndex = anchorEnd ? nodes.indexOf(anchorEnd) : anchor ? nodes.length : nodes.indexOf(end);
			if (cursor < 0 || endIndex < cursor) return false;
			const componentReceipt = componentSlot ? readCompiledComponentReceipt(withEffectScope(mounted.scope, () => readRenderProgramSlot(state.invocation, index))) : void 0;
			const value = componentReceipt ? [] : withEffectScope(mounted.scope, () => programKeyedChildIncludes(state.invocation.program.keyedChildren, index) ? readDirectProgramChildren(state.invocation, index, parentInstance) : readProgramChildren(state.invocation, index, parentInstance));
			const receiptAdoption = componentReceipt ? adoptComponentReceipt(state.root, componentReceipt, nodes, cursor, parentInstance, mounted.scope, endIndex, true) : void 0;
			const children = componentReceipt ? receiptAdoption ? [receiptAdoption.mounted] : void 0 : adoptChildren(value, nodes, parentInstance, mounted.scope, cursor, endIndex, false);
			if (!children) return false;
			(state.childSlots ??= [])[index] = {
				parent,
				before: anchor ? anchorEnd : end,
				children,
				...componentReceipt ? { componentValue: componentReceipt } : { value }
			};
		}
	} finally {
		if (ownsLists) parentInstance?.endRender();
	}
	refreshProgramMountedChildren(mounted);
	return true;
}
//#endregion
//#region packages/dom/dist/client/renderer/render-program.js
/** Adopts an existing markerless program root with one bounded path cursor. */
function adoptRenderProgram(root, value, dom, scope, parentInstance, adoptChildren) {
	const invocation = readRenderProgram(value);
	if (!invocation) return void 0;
	const bindingOwner = invocation.owner ?? parentInstance;
	const program = directProgram(invocation.program);
	if (!(dom instanceof Element)) return void 0;
	const direct = claimCompiledRenderProgram(program, dom, "ssr");
	if (!direct) return void 0;
	const receipt = readRenderProgramReceipt(value);
	if (!receipt) return void 0;
	const mounted = {
		renderProgramReceipt: receipt,
		dom,
		scope,
		children: [],
		renderProgram: {
			invocation,
			programRoot: dom,
			slotNodes: direct.slotNodes,
			...direct.componentSlots ? { componentSlots: direct.componentSlots } : {},
			root,
			bindingOwner,
			parentInstance
		}
	};
	if (!adoptProgramChildSlots(mounted, parentInstance, adoptChildren)) return void 0;
	ownDirectProgramNodes(direct.elements, bindingOwner);
	if (!(!renderProgramHasBindings(program) || bindRenderProgram(mounted))) {
		releaseDirectProgramNodeOwners(direct.elements);
		return;
	}
	countProgramWork(root, direct.work, true);
	return mounted;
}
/** Adopts a compiler-specialized program or asks the hydration root to recover. */
function adoptCompiledRenderProgram(root, value, nodes, cursor, parentInstance, scope, end, adoptChildren) {
	const marked = adoptMarkedRenderProgram(root, value, nodes, cursor, end, scope, parentInstance, adoptChildren);
	if (marked) return marked;
	const adopted = nodes[cursor] ? adoptRenderProgram(root, value, nodes[cursor], scope, parentInstance, adoptChildren) : void 0;
	if (adopted) return {
		mounted: adopted,
		next: cursor + 1
	};
	scope.stop();
}
/** Adopts compiler-addressed program nodes inside the marker ranges required by generic SSR. */
function adoptMarkedRenderProgram(root, value, nodes, cursor, end, scope, parentInstance, adoptChildren) {
	const invocation = readRenderProgram(value);
	if (!invocation) return void 0;
	const program = directProgram(invocation.program);
	const range = markedProgramRange(nodes, cursor, end);
	if (!range) return void 0;
	let programRoot;
	for (let index = range.contentStart; index < range.endIndex; index++) {
		const node = nodes[index];
		if (node instanceof Element) {
			programRoot = node;
			break;
		}
	}
	if (!programRoot) return void 0;
	const direct = claimCompiledRenderProgram(program, programRoot, "ssr");
	if (!direct) return void 0;
	const receipt = readRenderProgramReceipt(value);
	if (!receipt) return void 0;
	const mounted = {
		renderProgramReceipt: receipt,
		dom: range.start ?? programRoot,
		...range.start ? { end: nodes[range.endIndex] } : {},
		...range.start ? { rawNodes: [programRoot] } : {},
		scope,
		children: [],
		renderProgram: {
			invocation,
			programRoot,
			slotNodes: direct.slotNodes,
			...direct.componentSlots ? { componentSlots: direct.componentSlots } : {},
			root,
			parentInstance
		}
	};
	if (!adoptProgramChildSlots(mounted, parentInstance, adoptChildren)) return void 0;
	ownDirectProgramNodes(direct.elements, parentInstance);
	countProgramWork(root, direct.work, true);
	if (!(!renderProgramHasBindings(program) || bindRenderProgram(mounted))) {
		releaseDirectProgramNodeOwners(direct.elements);
		return;
	}
	return {
		mounted,
		next: range.start ? range.endIndex + 1 : range.endIndex
	};
}
//#endregion
//#region packages/dom/dist/client/renderer/adoption/boundaries.js
/** Performs the framework child range domain operation. */
function frameworkChildRange(parent) {
	const children = Array.from(parent.childNodes);
	const startIndex = children.findIndex((node) => node instanceof Comment && node.data === "exact:framework-body:start");
	if (startIndex < 0) return void 0;
	const endIndex = children.findIndex((node, index) => index > startIndex && node instanceof Comment && node.data === "exact:framework-body:end");
	if (endIndex < 0) return void 0;
	return {
		start: children[startIndex],
		end: children[endIndex]
	};
}
/** Performs the authored child nodes domain operation. */
function authoredChildNodes(parent, framework) {
	if (!framework) return Array.from(parent.childNodes);
	const nodes = [];
	let frameworkOwned = false;
	for (const node of Array.from(parent.childNodes)) {
		if (node === framework.start) {
			frameworkOwned = true;
			continue;
		}
		if (node === framework.end) {
			frameworkOwned = false;
			continue;
		}
		if (!frameworkOwned) nodes.push(node);
	}
	return nodes;
}
/** Performs the adopt static children domain operation. */
function adoptStaticChildren(root, children, nodes, parentInstance, parentScope, start = 0, end = nodes.length) {
	return adoptStaticChildrenRange(root, children, nodes, parentInstance, parentScope, true, start, end)?.mounts;
}
/**
* Adopts component-owned children while retiring an enclosing server-executor transport range.
* The target-local wrapper is not part of the client component's child topology.
*/
function adoptComponentChildren(root, children, nodes, parentInstance, parentScope, start = 0, end = nodes.length) {
	const direct = adoptStaticChildren(root, children, nodes, parentInstance, parentScope, start, end);
	if (direct) return direct;
	const opening = nodes[start];
	if (!(opening instanceof Comment) || !isChildRangeOpening(opening.data)) return void 0;
	const closingIndex = closingMarkerIndex(nodes, start, opening.data, end);
	if (closingIndex !== end - 1) return void 0;
	const adopted = adoptStaticChildren(root, children, nodes, parentInstance, parentScope, start + 1, closingIndex);
	if (!adopted) return void 0;
	opening.remove();
	const closing = nodes[closingIndex];
	closing?.parentNode?.removeChild(closing);
	return adopted;
}
/** Identifies a stable dynamic range or the compact ordered compiler-direct range. */
function isChildRangeOpening(value) {
	return value === "x" || value.startsWith("exact:dynamic:");
}
/** Performs the adopt static children range domain operation. */
function adoptStaticChildrenRange(root, children, nodes, parentInstance, parentScope, requireAll, start = 0, end = nodes.length) {
	const mounts = [];
	let cursor = start;
	for (const child of children) {
		if (child === null || child === void 0 || child === false || child === true) continue;
		const keyedReceipt = readCompiledKeyedChildReceipt(child);
		if (keyedReceipt) {
			const opening = nodes[cursor];
			if (opening instanceof Element && readRenderProgramReceipt(keyedReceipt.value)) {
				const itemScope = keyedReceipt.ownerScope ?? createEffectScope(parentScope);
				if (keyedReceipt.ownerScope) transferEffectScope(itemScope, parentScope);
				const adopted = adoptStaticChildrenRange(root, [keyedReceipt.value], nodes, parentInstance, itemScope, true, cursor, cursor + 1);
				if (!adopted || adopted.mounts.length !== 1) {
					itemScope.stop();
					unmountMany(mounts);
					return;
				}
				mounts.push({
					operation: child,
					operationKey: keyedReceipt.key,
					range: "item",
					dom: opening,
					scope: itemScope,
					children: adopted.mounts
				});
				cursor++;
				continue;
			}
			if (!(opening instanceof Comment) || !opening.data.startsWith("i:")) {
				unmountMany(mounts);
				return;
			}
			const closing = closingMarkerIndex(nodes, cursor, opening.data, end);
			if (closing < 0) {
				unmountMany(mounts);
				return;
			}
			const itemScope = keyedReceipt.ownerScope ?? createEffectScope(parentScope);
			if (keyedReceipt.ownerScope) transferEffectScope(itemScope, parentScope);
			const adopted = adoptStaticChildrenRange(root, [keyedReceipt.value], nodes, parentInstance, itemScope, true, cursor + 1, closing);
			if (!adopted || adopted.mounts.length !== 1) {
				itemScope.stop();
				unmountMany(mounts);
				return;
			}
			mounts.push({
				operation: child,
				operationKey: keyedReceipt.key,
				range: "item",
				dom: opening,
				end: nodes[closing],
				scope: itemScope,
				children: adopted.mounts
			});
			cursor = closing + 1;
			continue;
		}
		const componentReceipt = readCompiledComponentReceipt(child);
		const intrinsicReceipt = readCompiledIntrinsicReceipt(child);
		const fragmentReceipt = readCompiledFragmentReceipt(child);
		const targetReceipt = readCompiledTargetReceipt(child);
		const rangeReceipt = readChildRangeReceipt(child);
		const activityReceipt = readCompiledActivityReceipt(child);
		const suspenseReceipt = readCompiledSuspenseReceipt(child);
		const unsafeHtmlReceipt = readUnsafeHtmlReceipt(child);
		const serverSlotReceipt = readServerSlotReceipt(child);
		const renderProgramReceipt = readRenderProgramReceipt(child);
		const scalar = scalarText(child);
		if (scalar !== void 0) {
			const node = nodes[cursor];
			if (node?.nodeType !== Node.TEXT_NODE || node.textContent !== scalar) {
				unmountMany(mounts);
				return;
			}
			const scope = createEffectScope(parentScope);
			mounts.push({
				scalar: true,
				scalarValue: scalar,
				dom: node,
				scope,
				children: []
			});
			cursor++;
			continue;
		}
		const result = serverSlotReceipt ? adoptServerSlotReceipt(serverSlotReceipt, nodes, cursor, createEffectScope(parentScope)) : componentReceipt ? adoptComponentReceipt(root, componentReceipt, nodes, cursor, parentInstance, parentScope, end, false) : intrinsicReceipt ? adoptIntrinsicReceipt(root, intrinsicReceipt, nodes, cursor, parentInstance, parentScope, adoptStaticChildren) : fragmentReceipt || targetReceipt ? adoptStructuralRangeReceipt(root, fragmentReceipt ?? targetReceipt, fragmentReceipt ? "fragment" : "target", nodes, cursor, parentInstance, parentScope, end, adoptStaticChildren) : rangeReceipt ? adoptChildRangeReceipt(root, rangeReceipt, nodes, cursor, parentInstance, parentScope, end, adoptStaticChildren) : activityReceipt ? requireStructuralBoundaryCapability().adoptActivityReceipt(root, activityReceipt, nodes, cursor, parentInstance, parentScope, end, adoptStaticChildren) : unsafeHtmlReceipt ? requireUnsafeHtmlDomCapability().adopt(root, unsafeHtmlReceipt, nodes, cursor, parentScope, end) : suspenseReceipt ? requireStructuralBoundaryCapability().adoptSuspenseReceipt(root, suspenseReceipt, nodes, cursor, parentInstance, parentScope, end, adoptStaticChildren) : renderProgramReceipt ? withTreeDepth(root, () => {
			countDomWork(root);
			return adoptCompiledRenderProgram(root, child, nodes, cursor, parentInstance, createEffectScope(parentScope), end, (values, childNodes, owner, scope, childCursor, childEnd) => adoptStaticChildren(root, [...values], childNodes, owner, scope, childCursor, childEnd));
		}) : void 0;
		if (!result) {
			unmountMany(mounts);
			return;
		}
		result.mounted.operation = child;
		mounts.push(result.mounted);
		cursor = result.next;
	}
	if (requireAll && cursor !== end) {
		unmountMany(mounts);
		return;
	}
	return {
		mounts,
		next: cursor
	};
}
/** Finds the closing comment for an authored marker range after its opening cursor. */
function closingMarkerIndex(nodes, cursor, opening, end = nodes.length) {
	const closing = `/${opening}`;
	let nested = 0;
	for (let index = cursor + 1; index < end; index++) {
		const node = nodes[index];
		if (!(node instanceof Comment)) continue;
		if (node.data === opening) nested++;
		else if (node.data === closing) {
			if (nested === 0) return index;
			nested--;
		}
	}
	return -1;
}
//#endregion
//#region packages/dom/dist/client/renderer/adoption/component-receipt-root.js
/** Adopts one marked compiler-issued component root without generic root classification. */
function adoptCompiledComponentReceiptRoot(operation, receipt, container, options = {}) {
	if (roots$1.has(container)) return false;
	const nodes = Array.from(container.childNodes);
	const boundary = componentMarkerBoundaryByIdentity(nodes, 0, receipt.contract.artifact.id);
	if (!boundary?.matches) return false;
	return adoptReceiptRoot(createRendererRoot(container, operation, options, {
		version: 1,
		mode: "hydrated"
	}), {
		componentReceipt: receipt,
		dom: boundary.start,
		end: nodes[boundary.endIndex],
		scope: createEffectScope(),
		children: [],
		clientArtifact: receiptClientArtifact(receipt)
	}, receipt, nodes.slice(1, boundary.endIndex), options);
}
/** Adopts a markerless compiler-issued component root using the same attachment ABI. */
function adoptMarkerlessCompiledComponentReceiptRoot(operation, receipt, container, options = {}) {
	if (roots$1.has(container)) return false;
	const start = document.createTextNode("");
	const end = document.createTextNode("");
	container.insertBefore(start, container.firstChild);
	container.insertBefore(end, container.querySelector(":scope > script#__exact_hydration[type=\"application/json\"]"));
	const root = createRendererRoot(container, operation, options, {
		version: 1,
		mode: "hydrated",
		markerlessHydration: true
	});
	const mounted = {
		componentReceipt: receipt,
		dom: start,
		end,
		scope: createEffectScope(),
		children: [],
		clientArtifact: receiptClientArtifact(receipt)
	};
	const nodes = [];
	for (let current = start.nextSibling; current && current !== end; current = current.nextSibling) nodes.push(current);
	const adopted = adoptReceiptRoot(root, mounted, receipt, nodes, options);
	if (!adopted) {
		start.remove();
		end.remove();
	}
	return adopted;
}
/** Adopts a compiler-issued component whose opaque output owns the current document element. */
function adoptDocumentCompiledComponentReceiptRoot(operation, receipt, documentNode, options = {}) {
	const container = documentNode.documentElement;
	if (!container || roots$1.has(container)) return false;
	const start = documentNode.createComment("exact:document-root");
	const end = documentNode.createComment("/exact:document-root");
	documentNode.insertBefore(start, container);
	documentNode.insertBefore(end, container.nextSibling);
	const adopted = adoptReceiptRoot(createRendererRoot(container, operation, options, {
		version: 1,
		mode: "document",
		markerlessHydration: true
	}), {
		componentReceipt: receipt,
		dom: start,
		end,
		scope: createEffectScope(),
		children: [],
		clientArtifact: receiptClientArtifact(receipt)
	}, receipt, [container], options);
	if (!adopted) {
		start.remove();
		end.remove();
	}
	return adopted;
}
function adoptReceiptRoot(root, mounted, receipt, nodes, options) {
	try {
		return withDomWork(root, () => {
			countDomWork(root);
			const instance = withEffectScope(mounted.scope, () => constructReceipt(root, receipt, options.logicalParent));
			ownMountedInstance(mounted, instance);
			if (!attachHydratedComponent(root, mounted, mounted.clientArtifact, instance, (children) => adoptComponentChildren(root, children, nodes, instance, mounted.scope))) return false;
			const capability = domEnhancementCapability();
			root.mounted = capability ? capability.activate(root, mounted, void 0, void 0, (value, owner, scope, node) => mountDetachedOperation(root, value, owner, scope, node)) : mounted;
			root.initialCommitComplete = true;
			roots$1.set(root.container, root);
			return true;
		});
	} catch (error) {
		if (isDomRenderLimitError(error)) throw error;
		return false;
	} finally {
		if (!roots$1.has(root.container)) {
			unmountMounted(mounted);
			clearDelegated(root);
		}
		root.workBudget = void 0;
	}
}
//#endregion
//#region packages/dom/dist/client/framework/component-root.js
/**
* Mounts or updates a compiler-issued native component root without entering the generic child
* renderer. The operation remains opaque; only the selected artifact's standard ABI is invoked.
*/
function renderCompiledComponentRoot(operation, container, options = {}) {
	const receipt = readCompiledComponentReceipt(operation);
	if (!receipt) throw new TypeError("Compiled component root requires a compiler-issued component operation");
	let root = roots$1.get(container);
	const inspection = options.inspection ?? exactDomInspectionOwner();
	const effectiveOptions = resolveRootRenderOptions(receipt.domain, root, options, inspection);
	if (root?.mode === "document") {
		applyRootOptions(root, effectiveOptions);
		if (root.mounted?.componentReceipt && root.mounted.clientArtifact === receipt.contract.artifact && root.mounted.componentReceipt.key === receipt.key && root.mounted.componentReceipt.domain === receipt.domain) {
			const previousReceipt = root.mounted.componentReceipt;
			try {
				receiveComponentReceipt(root.mounted, receipt);
				flushSync();
				root.current = operation;
				root.version++;
			} catch (error) {
				root.mounted.componentReceipt = previousReceipt;
				throw error;
			}
			return;
		}
		throw new Error("eXact cannot safely replace a mounted Document root with a different component artifact");
	}
	if (!root) {
		root = createRendererRoot(container, operation, effectiveOptions, {
			version: 0,
			mode: "client"
		});
		roots$1.set(container, root);
		if (root.domain && componentDomainInspection(root.domain)) registerInspectableRoot(root);
	}
	applyRootOptions(root, effectiveOptions);
	if (root.domain && componentDomainInspection(root.domain)) registerInspectableRoot(root);
	const previous = root.mounted;
	const startedAt = profileTimestamp();
	if (previous?.componentReceipt && previous.clientArtifact === receipt.contract.artifact && previous.componentReceipt.key === receipt.key && previous.componentReceipt.domain === receipt.domain) {
		const previousReceipt = previous.componentReceipt;
		try {
			withDomWork(root, () => {
				receiveComponentReceipt(previous, receipt);
				flushSync();
			});
		} catch (error) {
			previous.componentReceipt = previousReceipt;
			throw error;
		}
	} else {
		const previousParking = root.replacementParking;
		const parking = createRootReplacementParking(previous, container);
		root.replacementParking = parking;
		try {
			withDomWork(root, () => {
				const mounted = mountComponentReceipt(root, receipt, effectiveOptions.logicalParent, void 0, container);
				placeMountedBefore(root, container, mounted, previous?.dom ?? null);
				root.mounted = mounted;
				renderRootErrorView(root);
				flushSync();
			});
		} finally {
			root.replacementParking = previousParking;
		}
		for (const commit of parking.commits) commit();
		if (previous) disposeMounted(container, previous);
		for (const remaining of parking.mounts.values()) for (const parked of remaining) disposeMounted(parked.parent, parked.mounted);
	}
	root.current = operation;
	root.version++;
	publishExactProfile(root.onProfile, {
		subsystem: "dom",
		phase: "render",
		elapsedMs: profileTimestamp() - startedAt
	});
	root.initialCommitComplete = true;
	root.workBudget = void 0;
}
function createRootReplacementParking(previous, container) {
	return previous ? createForeignReplacementParking(previous, container) : {
		mounts: /* @__PURE__ */ new Map(),
		commits: []
	};
}
/** Updates mutable root policy without changing component or range ownership. */
//#endregion
//#region packages/core/dist/client/protocol-utf8.js
var encoder = new TextEncoder();
/** Counts UTF-8 bytes without buffering short strings, matching TextEncoder for lone surrogates. */
function protocolUtf8ByteLength(value) {
	if (value.length > 64) return encoder.encode(value).byteLength;
	let bytes = 0;
	for (let index = 0; index < value.length; index++) {
		const code = value.charCodeAt(index);
		if (code <= 127) bytes++;
		else if (code <= 2047) bytes += 2;
		else if (code >= 55296 && code <= 56319 && index + 1 < value.length) {
			const next = value.charCodeAt(index + 1);
			if (next >= 56320 && next <= 57343) {
				bytes += 4;
				index++;
			} else bytes += 3;
		} else bytes += 3;
	}
	return bytes;
}
//#endregion
//#region packages/core/dist/client/framework/protocol-records.js
var reservedObjectKeys = /* @__PURE__ */ new Set([
	"__proto__",
	"prototype",
	"constructor"
]);
/** Returns whether a key can be materialized in an eXact protocol dictionary. */
function isSafeProtocolKey(key) {
	return !reservedObjectKeys.has(key);
}
/** Creates a prototype-free dictionary for decoded or generated protocol records. */
function createProtocolRecord() {
	return Object.create(null);
}
/** Normalizes a positive safe-integer protocol resource limit. */
function normalizeProtocolLimit(value, fallback) {
	return typeof value === "number" && Number.isSafeInteger(value) && value > 0 ? value : fallback;
}
/**
* Validates every own key in a recursively decoded JSON-like protocol value.
* Cycles are tolerated for defensive use outside JSON decoding.
*/
function hasOnlySafeProtocolKeys(value) {
	if (!value || typeof value !== "object") return true;
	const pending = [value];
	const seen = /* @__PURE__ */ new WeakSet();
	while (pending.length) {
		const current = pending.pop();
		if (seen.has(current)) continue;
		seen.add(current);
		for (const key of Object.keys(current)) {
			if (!isSafeProtocolKey(key)) return false;
			const child = current[key];
			if (child && typeof child === "object") pending.push(child);
		}
	}
	return true;
}
//#endregion
//#region packages/hydrate/dist/validation.js
/** Returns whether an object contains only the explicitly allowed own enumerable keys. */
function hasOnlyKeys(record, allowed) {
	return Object.keys(record).every((key) => allowed.includes(key));
}
/** Returns whether a value can be safely encoded as JSON without prototypes or cycles. */
function isJsonSafe(value, limits = {}) {
	const maxDepth = normalizeProtocolLimit(limits.maxDepth, 100);
	const maxNodes = normalizeProtocolLimit(limits.maxNodes, 1e5);
	const maxBytes = normalizeProtocolLimit(limits.maxBytes, 16777216);
	try {
		const seen = /* @__PURE__ */ new Set();
		const pending = [{
			value,
			depth: 0
		}];
		let nodes = 0;
		let bytes = 0;
		while (pending.length) {
			const { value: item, depth } = pending.pop();
			if (++nodes > maxNodes || depth > maxDepth || item === void 0) return false;
			if (item === null || typeof item === "boolean") continue;
			if (typeof item === "number") {
				if (!Number.isFinite(item)) return false;
				continue;
			}
			if (typeof item === "string") {
				bytes += protocolUtf8ByteLength(item);
				if (bytes > maxBytes) return false;
				continue;
			}
			if (typeof item !== "object" || seen.has(item)) return false;
			seen.add(item);
			if (item instanceof Map) {
				for (const [key, entryValue] of item) {
					if (!isTransportableReactiveMapKey(key)) return false;
					if (nodes + pending.length + 1 > maxNodes) return false;
					if (typeof key === "string") bytes += protocolUtf8ByteLength(key);
					if (bytes > maxBytes) return false;
					pending.push({
						value: entryValue,
						depth: depth + 1
					});
				}
				continue;
			}
			if (item instanceof Set) {
				for (const entryValue of item) {
					if (nodes + pending.length + 1 > maxNodes) return false;
					pending.push({
						value: entryValue,
						depth: depth + 1
					});
				}
				continue;
			}
			if (!Array.isArray(item) && Object.getPrototypeOf(item) !== Object.prototype) return false;
			const keys = Object.keys(item);
			if (nodes + pending.length + keys.length > maxNodes) return false;
			for (const key of keys) {
				const descriptor = Object.getOwnPropertyDescriptor(item, key);
				if (!descriptor || !("value" in descriptor)) return false;
				bytes += protocolUtf8ByteLength(key);
				if (bytes > maxBytes) return false;
				pending.push({
					value: descriptor.value,
					depth: depth + 1
				});
			}
		}
		return true;
	} catch {
		return false;
	}
}
//#endregion
//#region packages/hydrate/dist/config-validation.js
var emptyList = Object.freeze([]);
var emptyRecord = Object.freeze({});
/** Validates and restores compact serialized continuation defaults. */
function normalizeContinuationMap(value) {
	if (value === void 0) return void 0;
	if (!value || typeof value !== "object" || Array.isArray(value)) throw new TypeError("Malformed eXact hydration continuations");
	const entries = Object.entries(value);
	if (!entries.length) return emptyRecord;
	const output = createProtocolRecord();
	for (const [id, continuation] of entries) {
		if (!isSafeProtocolKey(id)) throw new TypeError(`Malformed eXact hydration continuation ${id}`);
		if (!isContinuation(continuation)) throw new TypeError(`Malformed eXact hydration continuation ${id}`);
		output[id] = normalizeContinuation(continuation);
	}
	return output;
}
/** Validates the single compact representation accepted across the document boundary. */
function normalizeSerializedComponentResumptions(value) {
	if (value === void 0) return void 0;
	if (!Array.isArray(value)) throw new TypeError("Malformed eXact component resumptions");
	if (!value.length) return emptyList;
	for (let index = 0; index < value.length; index++) {
		const item = value[index];
		if (!isIndexedComponentResumption(item)) throw new TypeError(`Malformed eXact component resumption ${index}`);
	}
	return value;
}
/** Narrows an unknown protocol value to a plain record shape. */
function isRecord(value) {
	return !!value && typeof value === "object" && !Array.isArray(value);
}
/** Validates serialized invocation and boundary endpoint routing maps. */
function isEndpointRoutes(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	const record = value;
	if (!hasOnlyKeys(record, ["invocations", "boundaries"])) return false;
	return (record.invocations === void 0 || isEndpointMap(record.invocations)) && (record.boundaries === void 0 || isEndpointMap(record.boundaries));
}
function safeResumptionPath(path) {
	return path.length > 0 && path.split(".").every((segment) => segment.length > 0 && segment !== "__proto__" && segment !== "prototype" && segment !== "constructor");
}
function isContinuation(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	const record = value;
	return hasOnlyKeys(record, [
		"kind",
		"id",
		"componentId",
		"readiness",
		"concurrency",
		"dependencies",
		"invocation",
		"stateReads",
		"stateWrites",
		"publicContexts",
		"serverContexts",
		"contextWrites",
		"serverContextWrites",
		"boundaries"
	]) && record.kind === "task" && typeof record.id === "string" && typeof record.componentId === "string" && (record.readiness === "blocking" || record.readiness === "nonblocking") && (record.concurrency === void 0 || record.concurrency === "parallel" || record.concurrency === "latest" || record.concurrency === "queue") && (record.dependencies === void 0 || Array.isArray(record.dependencies) && record.dependencies.every(isExactContinuationDependency)) && (record.stateReads === void 0 || isStatePathList(record.stateReads)) && (record.stateWrites === void 0 || isStatePathList(record.stateWrites)) && (record.publicContexts === void 0 || isStringList(record.publicContexts)) && (record.serverContexts === void 0 || isStringList(record.serverContexts)) && (record.serverContexts === void 0 || record.serverContexts.length === 0) && (record.contextWrites === void 0 || isStringList(record.contextWrites)) && (record.serverContextWrites === void 0 || isStringList(record.serverContextWrites)) && (record.serverContextWrites === void 0 || record.serverContextWrites.length === 0) && (record.invocation === void 0 || isExactContinuationInvocation(record.invocation, { argumentsOptional: true })) && (record.boundaries === void 0 || isStringList(record.boundaries));
}
function normalizeContinuation(value) {
	const { invocation, serverContextWrites: _serverContextWrites, ...fields } = value;
	return {
		...fields,
		dependencies: value.dependencies ?? emptyList,
		stateReads: value.stateReads ?? emptyList,
		stateWrites: value.stateWrites ?? emptyList,
		publicContexts: value.publicContexts ?? emptyList,
		serverContexts: emptyList,
		contextWrites: value.contextWrites ?? emptyList,
		boundaries: value.boundaries ?? emptyList,
		...invocation === void 0 ? {} : { invocation: {
			...invocation,
			arguments: invocation.arguments ?? emptyList
		} }
	};
}
function isIndexedComponentResumption(value) {
	if (!Array.isArray(value) || value.length < 1 || value.length > 4) return false;
	if (typeof value[0] !== "string" || value[0].length === 0) return false;
	return indexedPairs(value[1]) && indexedPairs(value[2]) && (value[3] === void 0 || isStringList(value[3]));
}
function indexedPairs(value) {
	if (value === void 0) return true;
	if (!Array.isArray(value)) return false;
	const fields = [];
	for (const pair of value) {
		const field = Array.isArray(pair) ? pair[0] : void 0;
		if (!Array.isArray(pair) || pair.length !== 2 || !(typeof field === "number" && Number.isSafeInteger(field) && field >= 0 || typeof field === "string" && !field.startsWith("@") && safeResumptionPath(field)) || fields.includes(field)) return false;
		fields.push(field);
	}
	return true;
}
function isStatePathList(value) {
	return Array.isArray(value) && value.every(isExactContinuationStatePath);
}
function isStringList(value) {
	return Array.isArray(value) && value.every((item) => typeof item === "string");
}
function isEndpointMap(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	return Object.entries(value).every(([id, endpoint]) => {
		return id.length > 0 && typeof endpoint === "string" && endpoint.length > 0;
	});
}
//#endregion
//#region packages/hydrate/dist/protocol-decoding.js
/** Validates, decodes, and revalidates an untrusted reactive-protocol graph. */
function decodeBoundedReactiveProtocolValue(encoded, limits, failure) {
	if (!isJsonSafe(encoded, limits)) throw failure();
	let decoded;
	try {
		decoded = decodeReactiveProtocolValue(encoded);
	} catch {
		throw failure();
	}
	if (!isJsonSafe(decoded, limits)) throw failure();
	return decoded;
}
//#endregion
//#region packages/hydrate/dist/endpoint-routes.js
/** Merges endpoint routing maps without retaining either caller-owned container. */
function mergeEndpointRoutes(base, override) {
	const invocations = {
		...base?.invocations ?? {},
		...override?.invocations ?? {}
	};
	const boundaries = {
		...base?.boundaries ?? {},
		...override?.boundaries ?? {}
	};
	return Object.keys(invocations).length || Object.keys(boundaries).length ? {
		...Object.keys(invocations).length ? { invocations } : {},
		...Object.keys(boundaries).length ? { boundaries } : {}
	} : void 0;
}
/** Clones endpoint routing maps so runtime mutation does not alter serialized config objects. */
function cloneEndpointRoutes(routes) {
	return mergeEndpointRoutes(void 0, routes);
}
//#endregion
//#region packages/hydrate/dist/document-config.js
/** Parses the bounded full-runtime hydration document protocol and fails closed on malformed data. */
function parseDocumentHydrationConfig(script, limits) {
	try {
		const source = script.textContent ?? "{}";
		const maxBytes = normalizeProtocolLimit(limits.maxBytes, 16777216);
		if (source.length > maxBytes || protocolUtf8ByteLength(source) > maxBytes) return {};
		const value = decodeBoundedReactiveProtocolValue(JSON.parse(source), {
			maxDepth: limits.maxDepth,
			maxNodes: limits.maxNodes,
			maxBytes
		}, () => /* @__PURE__ */ new TypeError("Malformed eXact hydration config"));
		if (!value || typeof value !== "object") return {};
		let pluginRegistryFingerprint;
		let endpoint;
		let endpointRoutes;
		let state;
		let hasState = false;
		let serializedContinuations;
		let serializedResumptions;
		let publicContexts;
		let wallClockSnapshot;
		let hydrationTableValue;
		let executionRoot;
		let binding;
		let buildKeyValue;
		let componentAuthorizationValue;
		if (Array.isArray(value)) {
			const mask = value[1];
			if (value[0] !== 1 || typeof mask !== "number" || !Number.isSafeInteger(mask) || mask < 0 || (mask & -16384) !== 0) return {};
			let index = 2;
			if (mask & 1) pluginRegistryFingerprint = value[index++];
			if (mask & 2) endpoint = value[index++];
			if (mask & 4) endpointRoutes = value[index++];
			if (mask & 8) {
				hasState = true;
				state = value[index++];
			}
			if (mask & 32) serializedContinuations = value[index++];
			if (mask & 64) serializedResumptions = value[index++];
			if (mask & 128) publicContexts = value[index++];
			if (mask & 256) wallClockSnapshot = value[index++];
			if (mask & 512) hydrationTableValue = value[index++];
			if (mask & 1024) executionRoot = value[index++];
			if (mask & 2048) binding = value[index++];
			if (mask & 4096) buildKeyValue = value[index++];
			if (mask & 8192) componentAuthorizationValue = value[index++];
			if (index !== value.length) return {};
		} else {
			const record = value;
			if (!hasOnlyKeys(record, [
				"pluginRegistryFingerprint",
				"endpoint",
				"endpoints",
				"state",
				"continuations",
				"resumptions",
				"publicContexts",
				"wallClockSnapshot",
				"h",
				"executionRoot",
				"binding",
				"buildKey",
				"componentAuthorization"
			])) return {};
			pluginRegistryFingerprint = record.pluginRegistryFingerprint;
			endpoint = record.endpoint;
			endpointRoutes = record.endpoints;
			hasState = "state" in record;
			state = record.state;
			serializedContinuations = record.continuations;
			serializedResumptions = record.resumptions;
			publicContexts = record.publicContexts;
			wallClockSnapshot = record.wallClockSnapshot;
			hydrationTableValue = record.h;
			executionRoot = record.executionRoot;
			binding = record.binding;
			buildKeyValue = record.buildKey;
			componentAuthorizationValue = record.componentAuthorization;
		}
		const componentAuthorization = isExactComponentAuthorizationIdentity(componentAuthorizationValue) ? componentAuthorizationValue : void 0;
		const buildKey = typeof buildKeyValue === "string" ? buildKeyValue : void 0;
		if (componentAuthorization && buildKey && componentAuthorization.buildKey !== buildKey) return {};
		const continuations = safelyNormalizeContinuationMap(serializedContinuations);
		const resumptions = safelyNormalizeComponentResumptions(serializedResumptions);
		const endpoints = isEndpointRoutes(endpointRoutes) ? cloneEndpointRoutes(endpointRoutes) : void 0;
		const hydrationTable = normalizeHydrationTable(hydrationTableValue);
		return {
			...typeof pluginRegistryFingerprint === "string" ? { pluginRegistryFingerprint } : {},
			...typeof endpoint === "string" ? { endpoint } : {},
			...endpoints === void 0 ? {} : { endpoints },
			...hasState ? { state } : {},
			...continuations === void 0 ? {} : { continuations },
			...resumptions === void 0 ? {} : { resumptions },
			...isRecord(publicContexts) ? { publicContexts } : {},
			...typeof wallClockSnapshot === "number" && Number.isFinite(wallClockSnapshot) ? { wallClockSnapshot } : {},
			...hydrationTable ? { hydrationTable } : {},
			...typeof executionRoot === "string" ? { executionRoot } : {},
			...typeof binding === "string" ? { binding } : {},
			...buildKey === void 0 ? {} : { buildKey },
			...componentAuthorization === void 0 ? {} : { componentAuthorization }
		};
	} catch {
		return {};
	}
}
function safelyNormalizeContinuationMap(value) {
	try {
		return normalizeContinuationMap(value);
	} catch {
		return;
	}
}
function safelyNormalizeComponentResumptions(value) {
	try {
		return normalizeSerializedComponentResumptions(value);
	} catch {
		return;
	}
}
function normalizeHydrationTable(value) {
	if (!Array.isArray(value) || value.length !== 2 || value[0] !== 1 || !Array.isArray(value[1])) return void 0;
	return [1, value[1].map((group) => {
		if (!Array.isArray(group) || group.length !== 3 || typeof group[0] !== "string" || !Array.isArray(group[1]) || !group[1].every((name) => typeof name === "string") || new Set(group[1]).size !== group[1].length || !Array.isArray(group[2])) return void 0;
		const rows = group[2].map((row) => Array.isArray(row) && row.length === group[1].length + 1 && typeof row[0] === "string" ? row : void 0);
		return [
			group[0],
			group[1],
			rows
		];
	})];
}
//#endregion
//#region packages/hydrate/dist/config.js
/** Combines explicit hydration options with the nearest serialized document config. */
function resolveHydrateOptions(container, options) {
	const config = readNearestHydrationConfig(container, options.configLimits, options.maxTreeNodes);
	if (config.pluginRegistryFingerprint && options.clientPluginRegistryFingerprint && config.pluginRegistryFingerprint !== options.clientPluginRegistryFingerprint) throw new Error("Client and server eXact plugin registry fingerprints do not match");
	if (config.buildKey && options.buildKey && config.buildKey !== options.buildKey) throw new Error("Client and server eXact build identities do not match");
	if (config.componentAuthorization && options.componentAuthorization && !sameExactComponentAuthorization(config.componentAuthorization, options.componentAuthorization)) throw new Error("Client and server component authorization fingerprints do not match");
	const componentAuthorization = options.componentAuthorization ?? config.componentAuthorization;
	const buildKey = options.buildKey ?? config.buildKey;
	if (componentAuthorization && buildKey && componentAuthorization.buildKey !== buildKey) throw new Error("Component authorization identity does not match the hydration build key");
	return {
		...options,
		endpoint: options.endpoint ?? config.endpoint,
		endpoints: mergeEndpointRoutes(config.endpoints, options.endpoints),
		state: options.state === void 0 ? config.state : options.state,
		continuations: mergeUniqueRecord(config.continuations, normalizeContinuationMap(options.continuations), "continuation", sameJsonData),
		resumptions: options.resumptions ?? config.resumptions,
		publicContexts: options.publicContexts ?? config.publicContexts,
		wallClockSnapshot: options.wallClockSnapshot ?? config.wallClockSnapshot,
		hydrationTable: options.hydrationTable ?? config.hydrationTable,
		executionRoot: options.executionRoot ?? config.executionRoot,
		binding: options.binding ?? config.binding,
		buildKey,
		componentAuthorization,
		headers: componentAuthorization ? {
			...options.headers,
			"X-Exact-Component-Authorization": componentAuthorization.fingerprint
		} : options.headers
	};
}
/** Merges a late-loaded hydration registration into an existing client runtime configuration. */
function mergeHydrationRegistration(options, registration) {
	if (registration.endpoint !== void 0) {
		if (options.endpoint !== void 0 && options.endpoint !== registration.endpoint) throw new Error("Conflicting eXact hydration endpoint registration");
		options.endpoint = registration.endpoint;
	}
	options.endpoints = mergeHydrationEndpointRoutes(options.endpoints, registration.endpoints);
	if (registration.state !== void 0) options.state = registration.state;
	if (registration.continuations) options.continuations = mergeUniqueRecord(options.continuations, normalizeRegistrationContinuations(registration.continuations), "continuation", sameJsonData);
	if (registration.resumptions) options.resumptions = [...options.resumptions ?? [], ...registration.resumptions];
	if (registration.publicContexts) options.publicContexts = mergeUniqueRecord(options.publicContexts, registration.publicContexts, "public context", sameJsonData);
	if (registration.islands) mergeClientIslands(options, registration.islands);
	if (registration.transports) options.transports = mergeUniqueRecord(options.transports, registration.transports, "endpoint transport", sameEndpointTransport);
}
/**
* Canonicalizes valid compiler contracts while retaining malformed values for
* the existing fail-closed duplicate-conflict path.
*/
function normalizeRegistrationContinuations(continuations) {
	try {
		return normalizeContinuationMap(continuations);
	} catch {
		return continuations;
	}
}
/** Merges client island component registrations while rejecting conflicting names. */
function mergeClientIslands(options, islands) {
	options.islands = mergeUniqueRecord(options.islands, islands, "client island", (left, right) => left === right);
}
/** Creates a stable cache key for a header object independent of property order. */
function headersCacheKey(headers) {
	if (!headers) return "";
	return Object.entries(headers).sort(([left], [right]) => left.localeCompare(right)).map(([name, value]) => `${name}:${value}`).join("\n");
}
function mergeHydrationEndpointRoutes(base, registration) {
	if (!registration) return cloneEndpointRoutes(base);
	return mergeEndpointRoutes(base, {
		invocations: mergeUniqueRecord(base?.invocations, registration.invocations, "invocation endpoint route", (left, right) => left === right),
		boundaries: mergeUniqueRecord(base?.boundaries, registration.boundaries, "boundary endpoint route", (left, right) => left === right)
	});
}
function mergeUniqueRecord(base, next, label, same) {
	if (!base && !next) return void 0;
	const output = { ...base ?? {} };
	for (const [key, value] of Object.entries(next ?? {})) {
		if (Object.prototype.hasOwnProperty.call(output, key) && !same(output[key], value)) throw new Error(`Conflicting eXact hydration ${label} registration: ${key}`);
		output[key] = value;
	}
	return output;
}
function sameEndpointTransport(left, right) {
	return left.fetch === right.fetch && sameHeaderMap(left.headers, right.headers);
}
function sameHeaderMap(left, right) {
	return headersCacheKey(left) === headersCacheKey(right);
}
function readNearestHydrationConfig(container, limits = {}, maxDomNodes) {
	const root = container.getRootNode();
	const indexed = indexedHydrationScript(root, "__exact_hydration");
	if (indexed) return parseDocumentHydrationConfig(indexed, limits);
	const work = createDomWorkBudget(maxDomNodes);
	const scripts = [];
	walkDomSubtree(root, (node) => {
		if (node instanceof HTMLScriptElement && node.id === "__exact_hydration") scripts.push(node);
	}, { budget: work });
	for (let cursor = container; cursor; cursor = cursor.parentElement) {
		const script = scripts.find((candidate) => cursor.contains(candidate));
		if (script) return parseDocumentHydrationConfig(script, limits);
	}
	return scripts[0] ? parseDocumentHydrationConfig(scripts[0], limits) : {};
}
/** Uses the document's id index when the requested root owns the indexed hydration script. */
function indexedHydrationScript(root, scriptId) {
	const documentRoot = root.nodeType === 9 ? root : root.ownerDocument;
	const candidate = documentRoot?.getElementById(scriptId);
	if (!(candidate instanceof HTMLScriptElement)) return void 0;
	return root === documentRoot || root.contains(candidate) ? candidate : void 0;
}
//#endregion
//#region packages/hydrate/dist/adoption/form-state.js
/** Captures dirty or focused form controls and detects eXact hydration markers in one bounded walk. */
function captureHydrationDom(container, work) {
	const active = document.activeElement;
	const controls = [];
	let hasMarkers = false;
	walkDomSubtree(container, (node) => {
		if (node.nodeType === Node.COMMENT_NODE) {
			if (node.data.startsWith("exact:")) hasMarkers = true;
			return;
		}
		if (node.nodeType !== Node.ELEMENT_NODE) return;
		const element = node;
		if (element.localName === "input" || element.localName === "textarea" || element.localName === "select" || element.localName === "details" || element.localName === "dialog" || element.getAttribute("contenteditable") === "true") controls.push(element);
	}, { budget: work });
	return {
		formState: controls.flatMap((control) => {
			if (!(control instanceof HTMLInputElement ? control.value !== control.defaultValue || control.checked !== control.defaultChecked : control instanceof HTMLTextAreaElement ? control.value !== control.defaultValue : control instanceof HTMLSelectElement ? Array.from(control.options).some((option) => option.selected !== option.defaultSelected) : isDetailsElement(control) ? control.open !== (control.getAttribute("data-exact-ssr-open") === "true") : isDialogElement(control) ? control.open : control.textContent !== control.getAttribute("data-exact-ssr-text")) && control !== active) return [];
			const state = {
				node: control,
				path: nodePath(container, control, work),
				identity: formControlIdentity(control),
				signature: formControlSignature(control),
				focused: control === active
			};
			if (control instanceof HTMLInputElement || control instanceof HTMLTextAreaElement) {
				state.value = control.value;
				if (control instanceof HTMLInputElement) state.checked = control.checked;
				state.selection = {
					start: control.selectionStart,
					end: control.selectionEnd,
					direction: control.selectionDirection
				};
			} else if (control instanceof HTMLSelectElement) state.selected = Array.from(control.options, (option) => option.selected);
			else if (isDetailsElement(control)) state.open = control.open;
			else if (isDialogElement(control)) state.modal = control.matches(":modal");
			else state.value = control.textContent ?? "";
			return [state];
		}),
		hasMarkers
	};
}
/** Restores captured values, selection, and focus using stable identity before positional fallback. */
function restoreFormState(container, states, work) {
	if (!states.length) return [];
	const restored = [];
	let identities;
	for (const state of states) {
		let candidate = container.contains(state.node) && (!state.identity || state.node.getAttribute(state.identity.attribute) === state.identity.value) ? state.node : void 0;
		if (!candidate) {
			identities ??= indexFormControlIdentities(container, work);
			candidate = (state.identity ? identities.get(`${state.identity.attribute}\0${state.identity.value}`) : void 0) ?? nodeAtPath(container, state.path, work);
		}
		const control = candidate instanceof Element && formControlSignature(candidate) === state.signature ? candidate : void 0;
		if (!(control instanceof Element)) continue;
		restored.push(control);
		if (control instanceof HTMLInputElement || control instanceof HTMLTextAreaElement) {
			if (state.value !== void 0) control.value = state.value;
			if (control instanceof HTMLInputElement && state.checked !== void 0) control.checked = state.checked;
			if (state.focused) control.focus({ preventScroll: true });
			if (state.selection && state.selection.start !== null && state.selection.end !== null) control.setSelectionRange(state.selection.start, state.selection.end, state.selection.direction ?? void 0);
		} else if (control instanceof HTMLSelectElement && state.selected) {
			Array.from(control.options).forEach((option, index) => {
				option.selected = state.selected[index] ?? false;
			});
			if (state.focused) control.focus({ preventScroll: true });
		} else if (isDetailsElement(control) && state.open !== void 0) control.open = state.open;
		else if (isDialogElement(control) && state.modal !== void 0) {
			if (state.modal && !control.matches(":modal")) {
				if (control.open) control.close();
				control.showModal();
			} else if (!state.modal && control.matches(":modal")) control.close();
		} else if (state.value !== void 0) {
			control.textContent = state.value;
			if (state.focused && control instanceof HTMLElement) control.focus({ preventScroll: true });
		}
	}
	return restored;
}
function formControlIdentity(element) {
	for (const attribute of [
		"data-exact-control-id",
		"data-exact-id",
		"id",
		"name"
	]) {
		const value = element.getAttribute(attribute);
		if (value) return {
			attribute,
			value
		};
	}
}
function isDetailsElement(value) {
	return value instanceof Element && value.localName === "details" && "open" in value;
}
function isDialogElement(value) {
	return value instanceof Element && value.localName === "dialog" && "open" in value && typeof value.showModal === "function";
}
function formControlSignature(element) {
	const type = element instanceof HTMLInputElement ? element.type : "";
	return `${element.namespaceURI ?? ""}|${element.localName}|${type}|${element.getAttribute("name") ?? ""}`;
}
function indexFormControlIdentities(container, work) {
	const identities = /* @__PURE__ */ new Map();
	walkDomSubtree(container, (node) => {
		if (!(node instanceof Element)) return;
		for (const attribute of [
			"data-exact-control-id",
			"data-exact-id",
			"id",
			"name"
		]) {
			const value = node.getAttribute(attribute);
			if (!value) continue;
			const key = `${attribute}\0${value}`;
			identities.set(key, identities.has(key) ? void 0 : node);
		}
	}, { budget: work });
	return identities;
}
function nodePath(root, node, work) {
	const path = [];
	for (let cursor = node; cursor && cursor !== root; cursor = cursor.parentNode) {
		consumeDomWork(work);
		if (!cursor.parentNode) return [];
		path.unshift(Array.prototype.indexOf.call(cursor.parentNode.childNodes, cursor));
	}
	return path;
}
function nodeAtPath(root, path, work) {
	let cursor = root;
	for (const index of path) {
		consumeDomWork(work);
		cursor = cursor?.childNodes[index];
	}
	return cursor;
}
//#endregion
//#region packages/hydrate/dist/islands/interaction-control-state.js
/** Captures only the value fields authorized by input/change replay. */
function captureInteractionControlState(target) {
	if (target instanceof HTMLSelectElement) return {
		value: target.value,
		selected: Array.from(target.options, (option, index) => option.selected ? index : -1).filter((index) => index >= 0)
	};
	if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
		const selectionStart = target.selectionStart;
		const selectionEnd = target.selectionEnd;
		return {
			value: target.value,
			...target instanceof HTMLInputElement ? { checked: target.checked } : {},
			...selectionStart === null ? {} : { selectionStart },
			...selectionEnd === null ? {} : { selectionEnd },
			...target.selectionDirection ? { selectionDirection: target.selectionDirection } : {}
		};
	}
	return {};
}
/** Restores a queued value before notifying the newly adopted handler. */
function restoreInteractionControlState(target, state) {
	if (target instanceof HTMLSelectElement) {
		if (state.selected) {
			const selected = new Set(state.selected);
			for (let index = 0; index < target.options.length; index++) target.options[index].selected = selected.has(index);
		} else if (state.value !== void 0) target.value = state.value;
		return;
	}
	if (!(target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement)) return;
	if (state.value !== void 0) target.value = state.value;
	if (target instanceof HTMLInputElement && state.checked !== void 0) target.checked = state.checked;
	if (state.selectionStart === void 0 || state.selectionEnd === void 0) return;
	try {
		target.setSelectionRange(state.selectionStart, state.selectionEnd, state.selectionDirection ?? "none");
	} catch {}
}
//#endregion
//#region packages/hydrate/dist/islands/interaction.js
var maxQueuedInteractions = 256;
var islandBoundarySelector = "[data-exact-client-boundary], [data-xh]";
var controllers$1 = /* @__PURE__ */ new WeakMap();
/** Installs policy-specific capture listeners for compiler-proven dormant islands. */
function ensureInteractionHydration(container, activate, eventTypes, resolvePolicy, options) {
	controllers$1.get(container)?.dispose();
	const pending = /* @__PURE__ */ new WeakMap();
	const activations = /* @__PURE__ */ new Set();
	const failedGenerations = /* @__PURE__ */ new WeakMap();
	let replaying = false;
	const listener = (event) => {
		if (replaying) return;
		const target = eventTargetElement(event.target);
		const boundary = target?.closest(islandBoundarySelector);
		if (!target || !boundary || !container.contains(boundary) || boundary.getAttribute("data-exact-client-hydration") !== "interaction" || boundary.getAttribute("data-exact-client-hydrated") === "true") return;
		const policy = resolvePolicy(boundary, target, event.type);
		if (!policy) return;
		const generation = boundary.getAttribute("data-exact-client-generation");
		if (failedGenerations.get(boundary) === generation) return;
		const queued = captureQueuedInteraction(boundary, target, event, policy);
		const existing = pending.get(boundary);
		if (existing) {
			interceptOriginalInteraction(event, policy);
			queueInteraction(existing.events, queued, options);
			return;
		}
		let activated = false;
		try {
			activated = activate(boundary, event);
		} catch (error) {
			logActivationFailure(error, options);
		}
		if (activated instanceof Promise) {
			interceptOriginalInteraction(event, policy);
			const activation = {
				boundary,
				events: [queued],
				released: false
			};
			pending.set(boundary, activation);
			activations.add(activation);
			activated.then((result) => {
				pending.delete(boundary);
				activations.delete(activation);
				if (activation.released || !sameGeneration(container, boundary, generation)) return;
				if (!result) failedGenerations.set(boundary, generation);
				replaying = true;
				try {
					if (result) replayQueued(boundary, activation.events, false);
					else replayQueued(boundary, activation.events, true);
				} finally {
					replaying = false;
				}
				if (result && !hasDormantIsland(container)) dispose();
				activation.events.length = 0;
			}, (error) => {
				pending.delete(boundary);
				activations.delete(activation);
				logActivationFailure(error, options);
				if (activation.released || !sameGeneration(container, boundary, generation)) return;
				failedGenerations.set(boundary, generation);
				replaying = true;
				try {
					replayQueued(boundary, activation.events, true);
				} finally {
					replaying = false;
				}
				activation.events.length = 0;
			});
			return;
		}
		if (!activated) return;
		if (!sameGeneration(container, boundary, generation)) {
			interceptOriginalInteraction(event, policy);
			if (!hasDormantIsland(container)) dispose();
			return;
		}
		if (boundary.contains(target)) {
			if (!hasDormantIsland(container)) dispose();
			return;
		}
		interceptOriginalInteraction(event, policy);
		replaying = true;
		try {
			replayQueued(boundary, [queued], false);
		} finally {
			replaying = false;
		}
		if (!hasDormantIsland(container)) dispose();
	};
	const listenedEvents = [...new Set(eventTypes)];
	const dispose = () => {
		for (const activation of activations) {
			activation.released = true;
			activation.events.length = 0;
			pending.delete(activation.boundary);
		}
		activations.clear();
		for (const type of listenedEvents) container.removeEventListener(type, listener, true);
		options.signal?.removeEventListener("abort", dispose);
		controllers$1.delete(container);
	};
	for (const type of listenedEvents) container.addEventListener(type, listener, true);
	options.signal?.addEventListener("abort", dispose, { once: true });
	controllers$1.set(container, { dispose });
}
function captureQueuedInteraction(boundary, target, event, policy) {
	const identity = captureTargetIdentity(boundary, target);
	return {
		type: policy.type,
		replay: policy.replay,
		identity,
		...policy.replay === "latest-value" ? { control: captureInteractionControlState(target) } : {},
		...event instanceof SubmitEvent && event.submitter instanceof Element ? { submitterIdentity: captureTargetIdentity(boundary, event.submitter) } : {},
		key: `${policy.type}:${identity.exactId ?? identity.id ?? identity.name ?? identity.path.join(".")}`
	};
}
function queueInteraction(queue, interaction, options) {
	if (interaction.replay === "latest-value") {
		const previous = queue.findIndex((candidate) => candidate.key === interaction.key);
		if (previous >= 0) queue.splice(previous, 1);
	}
	if (queue.length >= maxQueuedInteractions) {
		const discard = queue.findIndex((candidate) => candidate.type !== "submit");
		if (discard < 0) {
			logFrameworkEvent("warn", "hydrate", "interaction-overflow", "interaction queue rejected a submit because its bounded capacity contains only submits", void 0, options.logger);
			return;
		}
		queue.splice(discard, 1);
	}
	queue.push(interaction);
}
function replayQueued(boundary, queue, failed) {
	for (const interaction of queue) {
		const target = resolveTargetIdentity(boundary, interaction.identity);
		if (target) replayInteraction(interaction, target, failed);
	}
}
/** Removes an interaction broker when its hydration root is explicitly released. */
function disposeInteractionHydration(container) {
	controllers$1.get(container)?.dispose();
}
function eventTargetElement(target) {
	if (target instanceof Element) return target;
	if (target instanceof Node) return target.parentElement ?? void 0;
}
function sameGeneration(container, boundary, generation) {
	return container.contains(boundary) && boundary.getAttribute("data-exact-client-generation") === generation;
}
function hasDormantIsland(container) {
	return !!container.querySelector("[data-exact-client-hydration=\"interaction\"]:not([data-exact-client-hydrated=\"true\"])");
}
function captureTargetIdentity(boundary, target) {
	const path = [];
	for (let cursor = target; cursor && cursor !== boundary; cursor = cursor.parentNode) {
		if (!cursor.parentNode) break;
		path.unshift(Array.prototype.indexOf.call(cursor.parentNode.childNodes, cursor));
	}
	return {
		exactId: target.getAttribute("data-exact-id") ?? void 0,
		id: target.id || void 0,
		name: target.getAttribute("name") ?? void 0,
		signature: targetSignature(target),
		path
	};
}
function resolveTargetIdentity(boundary, identity) {
	for (const [attribute, value] of [
		["data-exact-id", identity.exactId],
		["id", identity.id],
		["name", identity.name]
	]) {
		if (!value) continue;
		const candidates = Array.from(boundary.querySelectorAll(`[${attribute}]`)).filter((candidate) => candidate.getAttribute(attribute) === value);
		if (candidates.length === 1 && targetSignature(candidates[0]) === identity.signature) return candidates[0];
	}
	let cursor = boundary;
	for (const index of identity.path) cursor = cursor?.childNodes[index];
	return cursor instanceof Element && targetSignature(cursor) === identity.signature ? cursor : void 0;
}
function targetSignature(target) {
	return `${target.namespaceURI ?? ""}|${target.localName}|${target instanceof HTMLInputElement ? target.type : ""}`;
}
function interceptOriginalInteraction(event, policy) {
	if (policy.replay === "native-click" || policy.replay === "request-submit") event.preventDefault();
	event.stopImmediatePropagation();
}
function replayInteraction(interaction, target, failed) {
	if (interaction.control) restoreInteractionControlState(target, interaction.control);
	if (interaction.replay === "native-click" && target instanceof HTMLElement) {
		target.click();
		return;
	}
	if (interaction.replay === "request-submit") {
		const form = target instanceof HTMLFormElement ? target : target.closest("form") instanceof HTMLFormElement ? target.closest("form") : void 0;
		if (!form) return;
		const resolved = interaction.submitterIdentity ? resolveTargetIdentity(boundaryFor(form), interaction.submitterIdentity) : void 0;
		const submitter = resolved instanceof HTMLButtonElement || resolved instanceof HTMLInputElement ? resolved : void 0;
		form.requestSubmit(submitter);
		return;
	}
	if (!failed) target.dispatchEvent(new Event(interaction.type, {
		bubbles: interaction.type !== "focus" && interaction.type !== "blur",
		composed: true
	}));
}
function boundaryFor(element) {
	return element.closest(islandBoundarySelector) ?? element;
}
function logActivationFailure(error, options) {
	logFrameworkEvent("error", "hydrate", "interaction", "interaction island activation failed", error, options.logger);
}
//#endregion
//#region packages/hydrate/dist/islands/loading.js
var pendingLoads = /* @__PURE__ */ new WeakMap();
var loadedContracts = /* @__PURE__ */ new WeakMap();
/** Resolves and registers one lazy component exactly once for every shared loader entry. */
function loadClientIsland(entry, options) {
	let pending = pendingLoads.get(entry);
	if (!pending) {
		pending = entry.load().then((component) => {
			if (typeof component !== "function") throw new TypeError("An eXact client island loader must resolve to a component function");
			return component;
		}).catch((error) => {
			pendingLoads.delete(entry);
			throw error;
		});
		pendingLoads.set(entry, pending);
	}
	return pending.then((component) => {
		let contracts = loadedContracts.get(component);
		if (!contracts) {
			contracts = composePreparedExactComponentContracts([component], "client");
			loadedContracts.set(component, contracts);
		}
		mergeHydrationRegistration(options, { continuations: contracts.continuations });
		return component;
	});
}
/** Reports whether one registry value is an unambiguous lazy island loader. */
function isClientIslandLoader(value) {
	return !!value && typeof value === "object" && typeof value.load === "function";
}
//#endregion
//#region packages/hydrate/dist/islands/policies.js
/** Computes the smallest delegated listener set needed by one island registry. */
function interactionEventTypes(registry) {
	const types = /* @__PURE__ */ new Set();
	for (const entry of Object.values(registry)) {
		if (!isClientIslandLoader(entry)) continue;
		for (const target of entry.activation?.targets ?? []) for (const event of target.events) types.add(event.type);
	}
	return [...types];
}
/** Authorizes one captured event against compiler metadata for its exact target. */
function interactionPolicyForEntry(boundary, target, type, entry) {
	if (!isClientIslandLoader(entry)) return void 0;
	if (entry.activation?.mode !== "interaction") return void 0;
	for (let cursor = target; cursor && boundary.contains(cursor); cursor = cursor.parentElement) {
		const id = cursor.getAttribute("data-exact-id");
		if (!id) continue;
		const policy = entry.activation.targets.find((candidate) => candidate.id === id)?.events.find((candidate) => candidate.type === type);
		if (policy) return policy;
	}
}
//#endregion
//#region packages/hydrate/dist/islands/partition-slots.js
/** Revives serialized server ranges and invalidates only markers with mismatched authority. */
function revivePartitionServerSlots(value, options, boundary) {
	if (!value || typeof value !== "object") return value;
	const rootSlot = serverSlot(value, options, boundary);
	if (rootSlot) return rootSlot;
	const root = Array.isArray(value) ? new Array(value.length) : {};
	const pending = [{
		source: value,
		target: root
	}];
	while (pending.length) {
		const { source, target } = pending.pop();
		for (const key of Object.keys(source)) {
			if (!Array.isArray(source) && !isSafeProtocolKey(key)) continue;
			const child = Reflect.get(source, key);
			if (!child || typeof child !== "object") {
				Reflect.set(target, key, child);
				continue;
			}
			const slot = serverSlot(child, options, boundary);
			if (slot) {
				Reflect.set(target, key, slot);
				continue;
			}
			const revived = Array.isArray(child) ? new Array(child.length) : {};
			Reflect.set(target, key, revived);
			pending.push({
				source: child,
				target: revived
			});
		}
	}
	return root;
}
function serverSlot(value, options, boundary) {
	const record = value;
	if (typeof record.__exactServerSlot !== "string") return void 0;
	const id = record.__exactServerSlot;
	if (record.planVersion === void 0) return createServerSlot(id);
	const discriminator = record.discriminator;
	if (record.planVersion !== 1 || typeof record.buildKey !== "string" || options.buildKey !== void 0 && record.buildKey !== options.buildKey || record.executionRoot !== (options.executionRoot ?? "page") || typeof record.ownerComponentId !== "string" || !record.ownerComponentId || !partitionDiscriminator(discriminator) || record.planEdgeId !== id && !keyedPartitionSlotIdentity(id, record.planEdgeId, discriminator) || !Number.isSafeInteger(record.generation) || record.generation < 1 || !partitionMarkerMatches(boundary, record)) {
		clearMismatchedPartitionMarker(boundary, id);
		return createServerSlot(id);
	}
	return createServerSlot(id);
}
function clearMismatchedPartitionMarker(boundary, id) {
	if (!boundary) return;
	const marker = [...boundary.querySelectorAll("[data-exact-server-slot]")].find((candidate) => candidate.getAttribute("data-exact-server-slot") === id);
	if (!marker) return;
	marker.replaceChildren();
	for (const attribute of [...marker.attributes]) if (attribute.name.startsWith("data-exact-partition-")) marker.removeAttribute(attribute.name);
}
function keyedPartitionSlotIdentity(id, planEdgeId, discriminator) {
	return typeof planEdgeId === "string" && !!discriminator && typeof discriminator === "object" && discriminator.kind === "keyed" && id.startsWith(`${planEdgeId}:key:`);
}
function partitionDiscriminator(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	const discriminator = value;
	if (discriminator.kind === "single") return Object.keys(discriminator).length === 1;
	if (discriminator.kind === "branch") return Object.keys(discriminator).length === 2 && typeof discriminator.branch === "string" && !!discriminator.branch;
	return discriminator.kind === "keyed" && Object.keys(discriminator).length === 3 && typeof discriminator.list === "string" && !!discriminator.list && typeof discriminator.keyToken === "string" && !!discriminator.keyToken;
}
function partitionMarkerMatches(boundary, reference) {
	if (!boundary) return true;
	const marker = [...boundary.querySelectorAll("[data-exact-server-slot]")].find((candidate) => candidate.getAttribute("data-exact-server-slot") === reference.__exactServerSlot);
	return !!marker && marker.getAttribute("data-exact-partition-version") === String(reference.planVersion) && marker.getAttribute("data-exact-partition-build") === reference.buildKey && marker.getAttribute("data-exact-partition-root") === reference.executionRoot && marker.getAttribute("data-exact-partition-edge") === reference.planEdgeId && marker.getAttribute("data-exact-partition-owner") === reference.ownerComponentId && marker.getAttribute("data-exact-partition-discriminator") === reference.discriminator.kind && partitionDiscriminatorMarkerMatches(marker, reference.discriminator) && marker.getAttribute("data-exact-partition-generation") === String(reference.generation);
}
function partitionDiscriminatorMarkerMatches(marker, discriminator) {
	if (discriminator.kind === "single") return true;
	if (discriminator.kind === "branch") return marker.getAttribute("data-exact-partition-branch") === discriminator.branch;
	return marker.getAttribute("data-exact-partition-list") === discriminator.list && marker.getAttribute("data-exact-partition-key") === discriminator.keyToken;
}
//#endregion
//#region packages/hydrate/dist/partition-instances.js
/** Reconstructs the bounded live partition-instance tree from authoritative range markers. */
function inspectExactPartitionInstances(container, options = {}) {
	const executionRoot = options.executionRoot ?? "page";
	const byElement = /* @__PURE__ */ new Map();
	const roots = [];
	walkDomSubtree(container, (node) => {
		if (!(node instanceof Element) || !node.hasAttribute("data-exact-partition-edge")) return;
		const instance = partitionInstance(node, executionRoot, options.buildKey);
		if (!instance) return;
		const mutable = {
			value: instance,
			children: []
		};
		byElement.set(node, mutable);
		const parentElement = node.parentElement?.closest("[data-exact-partition-edge]");
		const parent = parentElement && byElement.get(parentElement);
		if (parent) parent.children.push(mutable);
		else roots.push(mutable);
	}, options.maxTreeNodes === void 0 ? void 0 : { maxNodes: options.maxTreeNodes });
	return Object.freeze(roots.map(freezePartitionInstance));
}
function partitionInstance(marker, executionRoot, buildKey) {
	const markerRoot = marker.getAttribute("data-exact-partition-root");
	const markerBuild = marker.getAttribute("data-exact-partition-build");
	const plan = marker.getAttribute("data-exact-partition-edge");
	const ownerComponentId = marker.getAttribute("data-exact-partition-owner");
	const generation = Number(marker.getAttribute("data-exact-partition-generation"));
	const discriminator = readExactPartitionDiscriminator(marker);
	if (marker.getAttribute("data-exact-partition-version") !== "1" || markerRoot !== executionRoot || !markerBuild || buildKey !== void 0 && markerBuild !== buildKey || !plan || !ownerComponentId || !discriminator || !Number.isSafeInteger(generation) || generation < 1) return void 0;
	const owner = findNodeOwnerInstance(marker);
	return Object.freeze({
		executionRoot,
		buildKey: markerBuild,
		plan,
		ownerComponentId,
		ownerComponentInstance: owner?.id ?? ownerComponentId,
		discriminator,
		generation,
		host: "server"
	});
}
function freezePartitionInstance(instance) {
	return Object.freeze({
		...instance.value,
		children: Object.freeze(instance.children.map(freezePartitionInstance))
	});
}
//#endregion
//#region packages/core/dist/client/component/list-capability.js
var capability;
/** Installs keyed-list support when the compiled artifact contains component list ownership. */
function registerComponentListCapability(next) {
	if (capability && capability !== next) throw new Error("Conflicting eXact component list capability integration");
	capability = next;
}
/** Returns the reachable list implementation or fails when compiler capability emission is stale. */
function componentListCapability() {
	if (!capability) throw new Error("Component lists require the compiler-selected @exactjs/core/runtime/lists capability");
	return capability;
}
/** Returns keyed-list support only when this artifact registered it. */
function optionalComponentListCapability() {
	return capability;
}
//#endregion
//#region packages/core/dist/client/component/task-instance.js
/** Compact durable record for task-owning artifacts without lifecycle or list machinery. */
var TaskComponentInstance = class extends CompactComponentInstance {
	taskCapability;
	taskState;
	taskReleased = false;
	constructor(type, rawProps, parent, ambientContexts, domain, execution, contract, instantiate = contract.artifact.instantiate) {
		super(type, rawProps, parent, ambientContexts, domain, contract);
		const capability = this.runtimeABI & 8 ? componentTaskCapability() : void 0;
		if (this.runtimeABI & 8 && !capability) {
			const error = /* @__PURE__ */ new Error("Task component construction requires the compiler-selected task capability");
			cleanupFailedComponentConstruction(this, error);
			throw error;
		}
		this.taskCapability = capability;
		try {
			this.taskState = capability?.create(this, type, contract, execution, rawProps, Boolean(this.componentResumption));
			this.initializeComponent(() => {
				return capability ? capability.run(this.taskState, () => instantiate.call(this, this.props)) : instantiate.call(this, this.props);
			});
			if (capability && this.componentResumption) capability.resume(this.taskState, new Set("componentId" in this.componentResumption ? this.componentResumption.settledContinuations : this.componentResumption[3] ?? []));
			capability?.retain(this.taskState, this);
		} catch (error) {
			cleanupFailedComponentConstruction(this, error);
			throw error;
		}
	}
	/** Releases task ownership in addition to the compact render scope exactly once. */
	unmount(reason = "unmount") {
		let primary;
		try {
			super.unmount(reason);
		} catch (error) {
			primary = error;
		}
		if (!this.taskReleased) {
			this.taskReleased = true;
			try {
				this.taskCapability?.release(this.taskState, this);
			} catch (error) {
				if (primary === void 0) primary = error;
			}
		}
		if (primary !== void 0) throw primary;
	}
};
//#endregion
//#region packages/core/dist/client/component/runtime.js
/**
* Compiler-selected component record for artifacts that own lifecycle or list machinery.
*
* Common identity, state, props, render, activation, and reactive disposal live in the compact
* base. This lane allocates and executes only the durable capability hooks declared by its ABI.
*/
var ComponentInstanceImpl = class extends TaskComponentInstance {
	mountController;
	activationController;
	durableReleased = false;
	constructor(type, instantiate, rawProps, parent, ambientContexts, domain, execution, contract) {
		super(type, rawProps, parent, ambientContexts, domain, execution, contract, instantiate);
	}
	/** Opens compiler-selected list bookkeeping for one render pass when lists are present. */
	beginRender() {
		if (this.runtimeABI & 4) optionalComponentListCapability()?.begin(this);
	}
	/** Closes compiler-selected list bookkeeping and releases entries absent from this pass. */
	endRender() {
		if (this.runtimeABI & 4) optionalComponentListCapability()?.end(this);
	}
	/** Releases list and lifecycle ownership after common reactive and task disposal. */
	unmount(reason = "unmount") {
		let primary;
		try {
			super.unmount(reason);
		} catch (error) {
			primary = error;
		}
		if (!this.durableReleased) {
			this.durableReleased = true;
			const teardown = (run) => {
				try {
					run();
				} catch (error) {
					if (primary === void 0) primary = error;
				}
			};
			if (this.runtimeABI & 4) teardown(() => optionalComponentListCapability()?.dispose(this));
			if (this.mountController) teardown(() => this.mountController.abort(reason));
			const unmountHandlers = this.runtimeABI & 2 ? componentLifecycleHandlers(this, "unmount") : [];
			for (const handler of unmountHandlers) try {
				const result = handler({
					signal: AbortSignal.abort(reason),
					reason
				});
				if (isPromiseLike$2(result)) observeLifecyclePromise(this, Promise.resolve(result), "unmount");
			} catch (error) {
				teardown(() => handleComponentError(this, createErrorReport(error, "lifecycle", this, "unmount")));
			}
			if (this.runtimeABI & 2) clearComponentLifecycleHandlers(this);
		}
		if (primary !== void 0) throw primary;
	}
	/** Runs mount handlers before the compact record makes its initial activation decision. */
	handleMounted() {
		const handlers = this.runtimeABI & 2 ? componentLifecycleHandlers(this, "mount") : [];
		this.mountController = handlers.length ? new AbortController() : void 0;
		for (const handler of handlers) {
			if (!this.mounted) break;
			try {
				const result = handler({ signal: this.mountController.signal });
				if (isPromiseLike$2(result)) observeLifecyclePromise(this, Promise.resolve(result), "mount");
			} catch (error) {
				handleComponentError(this, createErrorReport(error, "lifecycle", this, "mount"));
			}
		}
	}
	/** Activates the compact record and then dispatches compiler-selected lifecycle work. */
	activate(reason) {
		if (!super.activate(reason)) return false;
		const handlers = this.runtimeABI & 2 ? componentLifecycleHandlers(this, "activate") : [];
		this.activationController = handlers.length ? new AbortController() : void 0;
		for (const handler of handlers) try {
			const result = handler({ signal: this.activationController.signal });
			if (isPromiseLike$2(result)) observeLifecyclePromise(this, Promise.resolve(result), "activate");
		} catch (error) {
			handleComponentError(this, createErrorReport(error, "lifecycle", this, "activate"));
		}
		return true;
	}
	/** Deactivates the compact record, aborts activation work, and dispatches handlers. */
	deactivate(reason) {
		if (!super.deactivate(reason)) return false;
		this.activationController?.abort(reason);
		this.activationController = void 0;
		const handlers = this.runtimeABI & 2 ? componentLifecycleHandlers(this, "deactivate") : [];
		for (const handler of handlers) try {
			const result = handler({
				signal: AbortSignal.abort(reason),
				reason
			});
			if (isPromiseLike$2(result)) observeLifecyclePromise(this, Promise.resolve(result), "deactivate");
		} catch (error) {
			handleComponentError(this, createErrorReport(error, "lifecycle", this, "deactivate"));
		}
		return true;
	}
};
//#endregion
//#region packages/hydrate/dist/islands/execution-slice.js
var slices = /* @__PURE__ */ new WeakMap();
/** Prepares and caches the exact setup-transition slice for one loaded island artifact. */
function prepareClientIslandExecutionSlice(component) {
	const cached = slices.get(component);
	if (cached) return cached;
	const contract = readPreparedExactComponentContract(component);
	if (!contract?.execution) return emptySlice;
	assertAcyclic(contract.execution);
	const transitions = new Set(contract.execution.transitions.filter((transition) => transition[2] === "setup").map((transition) => transition[0]));
	const slice = /* @__PURE__ */ new Map([[exactComponentIdentity(component), transitions]]);
	slices.set(component, slice);
	return slice;
}
var emptySlice = /* @__PURE__ */ new Map();
function assertAcyclic(plan) {
	if (!plan) return;
	const producers = /* @__PURE__ */ new Map();
	for (const transition of plan.transitions) for (const output of transition[7]) {
		const values = producers.get(output) ?? [];
		values.push(transition[0]);
		producers.set(output, values);
	}
	const edges = /* @__PURE__ */ new Map();
	for (const transition of plan.transitions) {
		const dependencies = edges.get(transition[0]) ?? /* @__PURE__ */ new Set();
		for (const input of transition[6]) for (const producer of producers.get(input) ?? []) if (producer !== transition[0]) dependencies.add(producer);
		edges.set(transition[0], dependencies);
	}
	const visiting = /* @__PURE__ */ new Set();
	const visited = /* @__PURE__ */ new Set();
	const visit = (id) => {
		if (visiting.has(id)) throw new Error(`eXact island dependency cycle includes transition ${id}`);
		if (visited.has(id)) return;
		visiting.add(id);
		for (const dependency of edges.get(id) ?? []) visit(dependency);
		visiting.delete(id);
		visited.add(id);
	};
	for (const id of edges.keys()) visit(id);
}
//#endregion
//#region packages/hydrate/dist/runtime/state.js
/** Provides the canonical roots value. */
var roots = /* @__PURE__ */ new WeakMap();
/** Provides the canonical request versions value. */
var requestVersions = /* @__PURE__ */ new WeakMap();
//#endregion
//#region packages/hydrate/dist/runtime/resumption.js
/** Creates the ordered, contract-checked source of SSR component activations. */
function createComponentResumptionResolver(records) {
	let cursor = 0;
	const resolve = ((type) => {
		const contract = readPreparedExactClientExecutableComponentContract(type);
		if (!contract.resumption) return void 0;
		const componentId = exactComponentIdentity(type);
		const available = records();
		if (!available?.length) throw new Error("eXact SSR resumption payload is unavailable");
		const record = available[cursor];
		if (!record) throw new Error(`eXact SSR resumption is missing component ${componentId}`);
		const indexedRecord = !("componentId" in record);
		const recordComponentId = indexedRecord ? record[0] : record.componentId;
		if (recordComponentId !== componentId) throw new Error(`eXact SSR resumption expected component ${recordComponentId} before ${componentId}`);
		const values = indexedRecord ? record[1] ?? [] : record.values;
		const contexts = indexedRecord ? record[2] ?? [] : record.contexts;
		const settledContinuations = indexedRecord ? record[3] ?? [] : record.settledContinuations;
		const indexed = Array.isArray(values) && Array.isArray(contexts);
		if (indexed) {
			prepareIndexedFields(values, contract.resumption.statePaths, componentId, "state path");
			prepareIndexedFields(contexts, contract.resumption.contexts, componentId, "context");
		}
		if (!indexed) {
			validateNamedFields(values, contract.resumption.statePaths, componentId, "state path");
			validateNamedFields(contexts, contract.resumption.contexts, componentId, "context");
		}
		for (const id of settledContinuations) if (!contract.continuations?.some((continuation) => continuation.id === id)) throw new Error(`eXact SSR resumption contains undeclared continuation ${componentId}:${id}`);
		cursor++;
		return record;
	});
	resolve.checkpoint = () => cursor;
	resolve.rollback = (checkpoint) => {
		if (!Number.isSafeInteger(checkpoint) || checkpoint < 0 || checkpoint > cursor) throw new Error("Malformed eXact component resumption checkpoint");
		cursor = checkpoint;
	};
	return resolve;
}
/** Resolves compact field cells in place only after the receiving artifact supplies its schema. */
function prepareIndexedFields(entries, fields, componentId, fieldKind) {
	for (let index = 0; index < entries.length; index++) {
		const rawField = entries[index][0];
		const field = typeof rawField === "number" ? fields[rawField] : rawField;
		if (field === void 0) throw new Error(`eXact SSR resumption index is outside component ${componentId}`);
		if (typeof rawField === "string" && !fields.includes(rawField)) throw new Error(`eXact SSR resumption contains undeclared ${fieldKind} ${componentId}:${rawField}`);
		for (let previous = 0; previous < index; previous++) if (entries[previous][0] === field) throw new Error(`Duplicate eXact resumption field ${componentId}:${field}`);
		entries[index][0] = field;
	}
}
/** Validates the explicit registration lane against its receiving component contract. */
function validateNamedFields(values, fields, componentId, fieldKind) {
	const keys = Object.keys(values);
	for (const key of keys) if (!fields.includes(key)) throw new Error(`eXact SSR resumption contains undeclared ${fieldKind} ${componentId}:${key}`);
}
/** Captures the current activation cursor before a fallible adoption attempt. */
function checkpointComponentResumptions(domain) {
	return resolverForDomain(domain)?.checkpoint() ?? 0;
}
/** Retries a known component fallback with its rolled-back SSR activations. */
function withComponentResumptionFallback(domain, work) {
	const resolver = resolverForDomain(domain);
	if (!resolver) return work();
	const checkpoint = resolver.checkpoint();
	try {
		return withComponentResumption(domain, work);
	} catch (error) {
		resolver.rollback(checkpoint);
		throw error;
	}
}
/** Restores activations consumed by a failed adoption attempt. */
function rollbackComponentResumptions(domain, checkpoint) {
	resolverForDomain(domain)?.rollback(checkpoint);
}
function resolverForDomain(domain) {
	return componentDomainResumption(domain);
}
//#endregion
//#region packages/hydrate/dist/islands.js
/** Hydrates all unhydrated client island boundaries found under a container. */
function hydrateClientIslands(container, registry, options = {}) {
	let hydrated = 0;
	const attempted = /* @__PURE__ */ new Set();
	const work = createDomWorkBudget(options.maxTreeNodes);
	const boundaries = [];
	const rootContainer = container.nodeType === 9 ? container.documentElement : container;
	const domain = options.componentDomain ?? (rootContainer instanceof Element ? roots.get(rootContainer)?.domain : void 0) ?? createComponentDomain({ executionRoot: options.executionRoot ?? "page" });
	const enqueue = (root) => walkDomSubtree(root, (node) => {
		if (node instanceof Element && (node.hasAttribute("data-exact-client-boundary") || node.hasAttribute("data-xh")) && !attempted.has(node)) boundaries.push(node);
	}, { budget: work });
	enqueue(container);
	let dormant = false;
	for (let index = 0; index < boundaries.length; index++) {
		const boundary = boundaries[index];
		if (!container.contains(boundary) || boundary.getAttribute("data-exact-client-hydrated") === "true" || attempted.has(boundary)) continue;
		const parent = boundary.parentElement?.closest("[data-exact-client-boundary], [data-xh]");
		if (parent && parent.getAttribute("data-exact-client-hydrated") !== "true") continue;
		if (shouldDeferIsland(boundary, options)) {
			dormant = true;
			continue;
		}
		attempted.add(boundary);
		const result = hydrateIslandBoundary(boundary, registry, options, work, domain);
		if (result === true) {
			hydrated++;
			enqueue(boundary);
		} else if (result instanceof Promise) result.then((mounted) => {
			if (mounted && container.contains(boundary)) hydrateClientIslands(boundary, registry, {
				...options,
				componentDomain: domain
			});
		}).catch((error) => logFrameworkEvent("error", "hydrate", "island", "client island loading failed", error, options.logger));
	}
	if (dormant) ensureInteractionHydration(container, (boundary, event) => {
		const result = hydrateIslandChain(boundary, registry, options, createDomWorkBudget(options.maxTreeNodes), domain, event);
		if (result instanceof Promise) return result.then((hydrated) => {
			if (hydrated) releaseHydrationTableIfUnused(container, options);
			return hydrated;
		});
		if (result) releaseHydrationTableIfUnused(container, options);
		return result;
	}, interactionEventTypes(registry), (boundary, target, type) => interactionPolicyForBoundary(boundary, target, type, registry, options), options);
	else {
		disposeInteractionHydration(container);
		releaseHydrationTableIfUnused(container, options);
	}
	return hydrated;
}
function hydrateIslandChain(boundary, registry, options, work, domain, activationEvent) {
	const parent = boundary.parentElement?.closest("[data-exact-client-boundary], [data-xh]");
	if (parent && parent.getAttribute("data-exact-client-hydrated") !== "true") {
		const parentResult = hydrateIslandChain(parent, registry, options, work, domain);
		if (parentResult instanceof Promise) return parentResult.then((hydrated) => hydrated ? hydrateIslandBoundary(boundary, registry, options, work, domain, activationEvent) : false);
		if (!parentResult) return false;
	}
	return hydrateIslandBoundary(boundary, registry, options, work, domain, activationEvent);
}
function hydrateIslandBoundary(boundary, registry, options, work, domain, activationEvent) {
	if (boundary.getAttribute("data-exact-client-hydrated") === "true") return true;
	const generation = boundary.getAttribute("data-exact-client-generation");
	const compact = compactBoundaryProps(boundary, options);
	const name = boundary.getAttribute("data-exact-client-name") ?? compact?.name ?? null;
	if (!name) return false;
	const entry = registry[name];
	if (!entry) {
		logFrameworkEvent("warn", "hydrate", "island", `missing client island ${name}`, void 0, options.logger);
		return false;
	}
	if (compact && !boundary.hasAttribute("data-exact-client-boundary")) boundary.setAttribute("data-exact-client-boundary", compact.id);
	if (isClientIslandLoader(entry)) return loadClientIsland(entry, options).then((component) => {
		if (options.signal?.aborted || boundary.getAttribute("data-exact-client-generation") !== generation || !boundary.isConnected && !boundary.parentNode) return false;
		return mountIslandBoundary(boundary, name, component, options, work, domain, activationEvent, compact?.props);
	});
	return mountIslandBoundary(boundary, name, entry, options, work, domain, activationEvent, compact?.props);
}
function interactionPolicyForBoundary(boundary, target, type, registry, options) {
	const compact = compactBoundaryProps(boundary, options);
	const name = boundary.getAttribute("data-exact-client-name") ?? compact?.name;
	const entry = name ? registry[name] : void 0;
	if (!entry) return void 0;
	return interactionPolicyForEntry(boundary, target, type, entry);
}
function mountIslandBoundary(boundary, name, component, options, work, domain, activationEvent, compactProps) {
	return withComponentExecutionSlice(prepareClientIslandExecutionSlice(component), () => mountIslandBoundaryInSlice(boundary, name, component, options, work, domain, activationEvent, compactProps));
}
function mountIslandBoundaryInSlice(boundary, name, component, options, work, domain, activationEvent, compactProps) {
	if (boundary.getAttribute("data-exact-client-hydrated") === "true") return true;
	const props = compactProps ?? parseIslandProps(boundary.getAttribute("data-exact-client-props"), options, boundary);
	const operation = withComponentDomain(domain, () => createCompiledComponentReceipt(component, props));
	const receipt = readCompiledComponentReceipt(operation);
	if (!receipt) throw new TypeError("A client island must resolve to a compiled component operation");
	const remaining = work.limit - work.used;
	if (remaining <= 0) consumeDomWork(work);
	const rendererOptions = {
		logger: options.logger,
		onErrorReport: options.onErrorReport,
		maxTreeDepth: options.maxTreeDepth,
		maxTreeNodes: remaining,
		workBudget: work,
		logicalParent: findNodeOwnerInstance(boundary)
	};
	const interaction = boundary.getAttribute("data-exact-client-hydration") === "interaction" && boundary.childNodes.length > 0;
	const eagerAdoption = boundary.getAttribute("data-exact-client-hydration") === "eager" && boundary.childNodes.length > 0;
	const resumption = boundary.getAttribute("data-exact-client-resumption") === "true" && boundary.childNodes.length > 0;
	const adopting = interaction || eagerAdoption || resumption;
	const captured = adopting ? captureHydrationDom(boundary, work) : void 0;
	const checkpoint = adopting ? checkpointComponentResumptions(domain) : 0;
	const adopted = adopting ? adoptMarkerlessCompiledComponentReceiptRoot(operation, receipt, boundary, rendererOptions) : false;
	if (!adopted) {
		if (adopting) rollbackComponentResumptions(domain, checkpoint);
		if (adopting) boundary.replaceChildren();
		if (adopting) withComponentResumptionFallback(domain, () => renderCompiledComponentRoot(operation, boundary, rendererOptions));
		else renderCompiledComponentRoot(operation, boundary, rendererOptions);
	}
	if (captured) {
		for (const control of restoreFormState(boundary, captured.formState, work)) if (activationEvent?.target !== control || activationEvent.type !== "input" && activationEvent.type !== "change") synchronizeFormBinding(control);
	}
	boundary.setAttribute("data-exact-client-hydrated", "true");
	options.onHydration?.(Object.freeze({
		kind: "island",
		outcome: adopted ? "adopted" : "mounted",
		component: name,
		markers: adopted ? "markerless" : "none"
	}));
	options.onPartitionInstances?.(inspectExactPartitionInstances(boundary, {
		executionRoot: options.executionRoot,
		buildKey: options.buildKey,
		maxTreeNodes: options.maxTreeNodes
	}));
	return true;
}
function releaseHydrationTableIfUnused(container, options) {
	if (!options.hydrationTable) return;
	if (container.querySelector("[data-xh]:not([data-exact-client-hydrated=\"true\"])")) return;
	options.hydrationTable = void 0;
}
function compactBoundaryProps(boundary, options) {
	const match = boundary.getAttribute("data-xh")?.match(/^([0-9a-z]+)\.([0-9a-z]+)$/);
	const table = options.hydrationTable;
	if (!match || !table || table[0] !== 1) return void 0;
	const group = table[1][Number.parseInt(match[1], 36)];
	const row = group?.[2][Number.parseInt(match[2], 36)];
	if (!group || !row || typeof group[0] !== "string" || !Array.isArray(group[1]) || !group[1].every((name) => typeof name === "string") || typeof row[0] !== "string") return void 0;
	const authoredId = boundary.getAttribute("data-exact-client-boundary");
	if (authoredId !== null && row[0] !== authoredId) return void 0;
	const names = group[1];
	if (row.length !== names.length + 1) return void 0;
	const props = Object.create(null);
	for (let index = 0; index < names.length; index++) props[names[index]] = row[index + 1];
	return {
		id: row[0],
		name: group[0],
		props: revivePartitionServerSlots(props, options, boundary)
	};
}
function shouldDeferIsland(boundary, options) {
	if (options.hydration?.strategy === "eager") return false;
	return boundary.getAttribute("data-exact-client-hydration") === "interaction";
}
function parseIslandProps(raw, options, boundary) {
	if (!raw) return {};
	try {
		const maxBytes = normalizeProtocolLimit(options.configLimits?.maxBytes, 16777216);
		if (protocolUtf8ByteLength(raw) > maxBytes) return {};
		const parsed = decodeBoundedReactiveProtocolValue(JSON.parse(raw), {
			maxDepth: normalizeProtocolLimit(options.configLimits?.maxDepth, 100),
			maxNodes: normalizeProtocolLimit(options.configLimits?.maxNodes, 1e5),
			maxBytes
		}, () => /* @__PURE__ */ new TypeError("Malformed eXact island props"));
		if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
		const props = parsed.props;
		return props && typeof props === "object" && !Array.isArray(props) ? revivePartitionServerSlots(props, options, boundary) : {};
	} catch {
		return {};
	}
}
//#endregion
//#region packages/hydrate/dist/mismatch.js
/** Publishes one hydration or patch mismatch through logging and structured diagnostics. */
function reportMismatch(options, message, code = "adoption-mismatch", patch) {
	logFrameworkEvent("warn", "hydrate", "mismatch", message, void 0, options.logger);
	options.onDiagnostic?.({
		code,
		message,
		patch
	});
}
//#endregion
//#region packages/core/dist/client/framework/operation-protocol.js
var forbiddenDomPatchProperties = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"dangerouslysetinnerhtml",
	"innerhtml",
	"innertext",
	"outerhtml",
	"outertext",
	"prototype",
	"srcdoc",
	"textcontent"
]);
/**
* Reports whether a server property patch may cross the operation boundary.
* Structural HTML/text setters, inline event handlers, iframe documents, and
* JavaScript prototype controls require dedicated framework-owned operations.
*/
function isSafeDomPatchProperty(name) {
	const normalized = name.toLowerCase();
	return !!normalized && !normalized.startsWith("on") && !forbiddenDomPatchProperties.has(normalized);
}
//#endregion
//#region packages/hydrate/dist/patching/lookup.js
/** Resolves an exact target. */
function findExactTarget(container, id, index) {
	const range = findExactRange(container, id, index);
	if (!range) return findExactElement(container, id, index);
	let node = range.start.nextSibling;
	while (node && node !== range.end) {
		if (node.nodeType !== Node.COMMENT_NODE) return node;
		node = node.nextSibling;
	}
}
/** Resolves an exact element. */
function findExactElement(container, id, index) {
	if (index) return index.exactElements.get(id);
	return findElementByExactAttribute(container, "data-exact-id", id);
}
/** Resolves a server slot element. */
function findServerSlotElement(container, id, index) {
	if (index) return index.serverSlots.get(id);
	return findElementByExactAttribute(container, "data-exact-server-slot", id);
}
/** Resolves a client boundary element. */
function findClientBoundaryElement(container, id, index) {
	if (index) return index.clientBoundaries.get(id);
	return findElementByExactAttribute(container, "data-exact-client-boundary", id);
}
/** Resolves an element by exact attribute. */
function findElementByExactAttribute(container, attribute, id) {
	let match;
	walkDomSubtree(container, (node) => {
		if (!match && node instanceof Element && node.getAttribute(attribute) === id) match = node;
	});
	return match;
}
/** Resolves an exact element target. */
function findExactElementTarget(container, id, index) {
	const exact = findExactElement(container, id, index);
	if (exact) return exact;
	const range = findExactRange(container, id, index);
	if (!range) return void 0;
	let node = range.start.nextSibling;
	while (node && node !== range.end) {
		if (node.nodeType === Node.ELEMENT_NODE) return node;
		node = node.nextSibling;
	}
}
/** Resolves an exact range. */
function findExactRange(container, id, index) {
	if (index) return index.ranges.get(id);
	let start;
	let result;
	walkDomSubtree(container, (node) => {
		if (result || !(node instanceof Comment)) return;
		const comment = node;
		if (comment.data === `exact:${id}`) start = comment;
		if (start && comment.data === `/exact:${id}`) result = {
			start,
			end: comment
		};
	});
	return result;
}
/** Resolves an exact item range. */
function findExactItemRange(container, key, within) {
	let inRange = !within;
	let start;
	let result;
	walkDomSubtree(container, (node) => {
		if (result || !(node instanceof Comment)) return;
		const comment = node;
		if (within && comment === within.start) {
			inRange = true;
			return;
		}
		if (within && comment === within.end) {
			inRange = false;
			return;
		}
		if (!inRange) return;
		if (isExactItemStart(comment, key)) start = comment;
		if (start && comment.data === `/${start.data}`) result = {
			start,
			end: comment
		};
	});
	return result;
}
/** Reports whether exact item start. */
function isExactItemStart(comment, key) {
	if (!comment.data.startsWith("exact:item:")) return false;
	const suffix = comment.data.slice(comment.data.lastIndexOf(":") + 1);
	return suffix === key || suffix === encodeExactMarkerPart(key) || comment.data.endsWith(`:${key}`);
}
/** Resolves an indexed item. */
function findIndexedItem(index, listId, key) {
	const items = index.listItems.get(listId);
	if (!items) return void 0;
	return items.get(key) ?? items.get(encodeExactMarkerPart(key));
}
//#endregion
//#region packages/hydrate/dist/patching/mutation.js
/** Performs the replace range domain operation. */
function replaceRange(range, fragment, budget, cleanupFailure) {
	const parent = range.end.parentNode;
	let cursor = range.start.nextSibling;
	while (cursor && cursor !== range.end) {
		consumeDomWork(budget);
		const next = cursor.nextSibling;
		if (cursor instanceof Element) {
			const element = cursor;
			attemptCleanup(cleanupFailure, () => disposeOwnedSubtree(element, true, budget));
		}
		cursor.parentNode?.removeChild(cursor);
		cursor = next;
	}
	if (fragment && parent) parent.insertBefore(fragment, range.end);
}
/** Performs the replace element children domain operation. */
function replaceElementChildren(element, fragment, budget, cleanupFailure) {
	attemptCleanup(cleanupFailure, () => disposeOwnedSubtree(element, false, budget));
	element.replaceChildren();
	if (fragment) element.appendChild(fragment);
}
/** Performs the replace element domain operation. */
function replaceElement(element, fragment, budget, cleanupFailure) {
	attemptCleanup(cleanupFailure, () => disposeOwnedSubtree(element, true, budget));
	if (!fragment) {
		element.remove();
		return;
	}
	element.replaceWith(fragment);
}
/** Performs the insert fragment before domain operation. */
function insertFragmentBefore(anchor, fragment) {
	const parent = anchor.parentNode;
	if (parent && fragment) parent.insertBefore(fragment, anchor);
}
/** Reads a fragment from its source representation. */
function parseFragment(parent, html, budget) {
	let fragment;
	const ownerDocument = parent.nodeType === Node.DOCUMENT_NODE ? parent : parent.ownerDocument;
	if (!ownerDocument) throw new Error("Cannot parse a patch fragment without an owner document");
	if (parent instanceof Element) {
		const range = ownerDocument.createRange();
		range.selectNodeContents(parent);
		fragment = range.createContextualFragment(html);
	} else {
		const template = ownerDocument.createElement("template");
		template.innerHTML = html;
		fragment = template.content;
	}
	const nodeCount = walkDomSubtree(fragment, () => void 0, { budget });
	return {
		fragment,
		nodeCount
	};
}
/** Reports whether valid list item fragment. */
function isValidListItemFragment(fragment, key) {
	const stack = [];
	let started = false;
	let complete = false;
	for (const node of Array.from(fragment.childNodes)) {
		if (node instanceof Comment && node.data.startsWith("exact:")) {
			if (!stack.length) {
				if (started || complete || !isExactItemStart(node, key)) return false;
				started = true;
			}
			stack.push(node.data);
			continue;
		}
		if (node instanceof Comment && node.data.startsWith("/exact:")) {
			const start = stack.pop();
			if (!start || node.data !== `/${start}`) return false;
			if (!stack.length) complete = true;
			continue;
		}
		if (!stack.length && (!(node instanceof Text) || node.data.trim())) return false;
	}
	return started && complete && stack.length === 0;
}
/** Performs the move range before domain operation. */
function moveRangeBefore(range, anchor, budget) {
	if (isNodeInsideRange(anchor, range)) return;
	const fragment = document.createDocumentFragment();
	let cursor = range.start;
	while (cursor) {
		if (budget) consumeDomWork(budget);
		const next = cursor.nextSibling;
		fragment.appendChild(cursor);
		if (cursor === range.end) break;
		cursor = next;
	}
	anchor.parentNode?.insertBefore(fragment, anchor);
}
/** Reports whether node inside range. */
function isNodeInsideRange(node, range) {
	let cursor = range.start;
	while (cursor) {
		if (cursor === node) return true;
		if (cursor === range.end) return false;
		cursor = cursor.nextSibling;
	}
	return false;
}
//#endregion
//#region packages/hydrate/dist/patching/planning.js
/** Resolves the indexed DOM target addressed by a hydration protocol operation. */
function protocolTarget(index, id) {
	return index.ranges.get(id) ?? index.exactElements.get(id) ?? index.serverSlots.get(id) ?? index.clientBoundaries.get(id);
}
/** Reports whether one protocol target structurally contains another target. */
function protocolTargetContains(container, target) {
	const targetNode = target instanceof Node ? target : target.start;
	if (container instanceof Node) return container === targetNode || container.contains(targetNode);
	if (targetNode === container.start || targetNode === container.end) return true;
	const parent = container.start.parentNode;
	if (!parent || container.end.parentNode !== parent) return false;
	let direct = targetNode;
	while (direct?.parentNode && direct.parentNode !== parent) direct = direct.parentNode;
	if (!direct || direct.parentNode !== parent) return false;
	for (let cursor = container.start.nextSibling; cursor && cursor !== container.end; cursor = cursor.nextSibling) if (cursor === direct) return true;
	return false;
}
/** Reports whether apply patch. */
function canApplyPatch(index, patch) {
	if (patch.type === "text") return index.ranges.has(patch.id) || index.exactElements.has(patch.id) || index.serverSlots.has(patch.id);
	if (patch.type === "prop" || patch.type === "style") return index.exactElements.has(patch.id) || index.ranges.has(patch.id);
	if (patch.type === "replace") return index.ranges.has(patch.id) || index.exactElements.has(patch.id) || index.serverSlots.has(patch.id) || index.clientBoundaries.has(patch.id);
	if (patch.type === "state") return index.exactElements.has(patch.id);
	if (patch.type === "list") {
		if (!index.ranges.has(patch.id)) return false;
		if (patch.op === "insert") return !!patch.html && (!patch.before || !!findIndexedItem(index, patch.id, patch.before));
		const item = findIndexedItem(index, patch.id, patch.key);
		if (patch.op === "remove") return !!item;
		return !!item || !!patch.html;
	}
	return false;
}
/** Validates patch sequence and throws when the contract is violated. */
function validatePatchSequence(index, patches) {
	const keys = /* @__PURE__ */ new Map();
	for (const [listId, items] of index.listItems) keys.set(listId, new Set(items.keys()));
	const has = (set, key) => !key || set.has(key) || set.has(encodeExactMarkerPart(key));
	for (const patch of patches) {
		if (patch.type !== "list") {
			if (!canApplyPatch(index, patch)) return false;
			continue;
		}
		if (!index.ranges.has(patch.id)) return false;
		let list = keys.get(patch.id);
		if (!list) keys.set(patch.id, list = /* @__PURE__ */ new Set());
		if (!has(list, patch.before)) return false;
		if (patch.op === "insert") {
			if (!patch.html || has(list, patch.key)) return false;
			list.add(patch.key);
		} else if (patch.op === "remove") {
			if (!has(list, patch.key)) return false;
			list.delete(patch.key);
			list.delete(encodeExactMarkerPart(patch.key));
		} else if (!has(list, patch.key)) {
			if (!patch.html) return false;
			list.add(patch.key);
		}
	}
	return true;
}
/** Validates patch topology and throws when the contract is violated. */
function validatePatchTopology(index, patches) {
	const targets = patches.map((patch) => protocolTarget(index, patch.id));
	for (let left = 0; left < patches.length; left++) {
		const leftPatch = patches[left];
		if (!isStructuralPatch(leftPatch) || !targets[left]) continue;
		for (let right = 0; right < patches.length; right++) {
			if (left === right || !targets[right]) continue;
			const rightPatch = patches[right];
			if (leftPatch.type === "list" && rightPatch.type === "list" && leftPatch.id === rightPatch.id) continue;
			if (leftPatch.type === "text" && leftPatch.id === rightPatch.id) continue;
			if (protocolTargetContains(targets[left], targets[right])) return false;
		}
	}
	return true;
}
/** Reports whether structural patch. */
function isStructuralPatch(patch) {
	return patch.type === "text" || patch.type === "replace" || patch.type === "list";
}
/** Validates and orders a patch batch before any DOM mutation becomes observable. */
function preparePatchBatch(container, index, patches) {
	const prepared = [];
	let commitWork = 0;
	for (const patch of patches) {
		const item = {};
		let fragmentNodes = 0;
		if ((patch.type === "replace" || patch.type === "list") && patch.html) {
			const parent = fragmentContext(container, index, patch);
			if (!parent) return {
				ok: false,
				detail: `missing fragment context for ${patch.type}:${patch.id}`
			};
			const parsed = parseFragment(parent, patch.html, index.budget);
			if (patch.type === "list" && !isValidListItemFragment(parsed.fragment, patch.key)) return {
				ok: false,
				detail: `list fragment does not declare key ${patch.key}`
			};
			item.fragment = parsed.fragment;
			fragmentNodes = parsed.nodeCount;
		}
		if (patch.type === "prop") {
			if (!isSafeDomPatchProperty(patch.name)) return {
				ok: false,
				detail: `forbidden prop patch ${patch.name}`
			};
			const target = findExactElementTarget(container, patch.id, index);
			if (!target) return {
				ok: false,
				detail: `missing prop target ${patch.id}`
			};
			target.ownerDocument.createAttribute(patch.name);
		}
		if (patch.type === "state") {
			const stateJson = JSON.stringify(patch.value);
			if (stateJson === void 0) return {
				ok: false,
				detail: `state ${patch.id} is not JSON serializable`
			};
			item.stateJson = stateJson;
		}
		const targetNodes = isStructuralPatch(patch) ? countProtocolTargetNodes(index, patch.id) : 0;
		const patchWork = isStructuralPatch(patch) ? targetNodes * 3 + fragmentNodes : 1;
		if (!Number.isSafeInteger(patchWork) || commitWork > Number.MAX_SAFE_INTEGER - patchWork) return {
			ok: false,
			detail: "patch work estimate exceeds the safe integer range"
		};
		commitWork += patchWork;
		prepared.push(item);
	}
	reserveDomWork(index.budget, commitWork);
	return {
		ok: true,
		patches: prepared
	};
}
/** Performs the fragment context domain operation. */
function fragmentContext(container, index, patch) {
	if (patch.type === "list") return index.ranges.get(patch.id)?.end.parentNode ?? void 0;
	if (patch.type !== "replace") return void 0;
	const range = index.ranges.get(patch.id);
	if (range) return range.end.parentNode ?? void 0;
	const clientBoundary = findClientBoundaryElement(container, patch.id, index);
	if (clientBoundary) return clientBoundary.parentNode ?? void 0;
	const exactElement = findExactElement(container, patch.id, index);
	if (exactElement) return exactElement.parentNode ?? void 0;
	return findServerSlotElement(container, patch.id, index);
}
/** Counts the concrete DOM nodes represented by a protocol target without mutating it. */
function countProtocolTargetNodes(index, id) {
	const target = protocolTarget(index, id);
	if (!target) return 0;
	if (target instanceof Node) return walkDomSubtree(target, () => void 0, { budget: index.budget });
	let count = 0;
	for (let cursor = target.start; cursor; cursor = cursor.nextSibling) {
		count += walkDomSubtree(cursor, () => void 0, { budget: index.budget });
		if (cursor === target.end) break;
	}
	return count;
}
//#endregion
//#region packages/hydrate/dist/patching/indexing.js
/** Creates a protocol index. */
function createProtocolIndex(container, work, executionRoot) {
	const budget = typeof work === "number" || work === void 0 ? createDomWorkBudget(work) : work;
	const index = {
		ranges: /* @__PURE__ */ new Map(),
		exactElements: /* @__PURE__ */ new Map(),
		serverSlots: /* @__PURE__ */ new Map(),
		clientBoundaries: /* @__PURE__ */ new Map(),
		listItems: /* @__PURE__ */ new Map(),
		budget
	};
	const attributes = [
		["data-exact-id", index.exactElements],
		["data-exact-server-slot", index.serverSlots],
		["data-exact-client-boundary", index.clientBoundaries]
	];
	const stack = [];
	let valid = true;
	walkDomSubtree(container, (node) => {
		if (!valid) return;
		if (node instanceof Element) {
			if (!ownedByExecutionRoot(node, executionRoot)) return;
			for (const [attribute, output] of attributes) {
				const value = node.getAttribute(attribute);
				if (value === null) continue;
				if (output.has(value)) {
					valid = false;
					return;
				}
				output.set(value, node);
			}
			return;
		}
		if (!(node instanceof Comment)) return;
		const comment = node;
		const data = comment.data;
		if (data.startsWith("/exact:")) {
			const open = stack.pop();
			if (!open || data !== `/${open.data}`) {
				valid = false;
				return;
			}
			const range = {
				start: open.start,
				end: comment
			};
			if (!ownedByExecutionRoot(open.start, executionRoot)) return;
			if (open.itemKey !== void 0 && open.listId) {
				let items = index.listItems.get(open.listId);
				if (!items) index.listItems.set(open.listId, items = /* @__PURE__ */ new Map());
				if (items.has(open.itemKey)) {
					valid = false;
					return;
				}
				items.set(open.itemKey, range);
			} else {
				if (index.ranges.has(open.id)) {
					valid = false;
					return;
				}
				index.ranges.set(open.id, range);
			}
			return;
		}
		if (!data.startsWith("exact:")) return;
		const id = data.slice(6);
		const itemKey = id.startsWith("item:") ? id.slice(id.lastIndexOf(":") + 1) : void 0;
		const parentBoundary = stack.at(-1)?.nearestBoundaryId;
		const listId = itemKey === void 0 ? void 0 : parentBoundary;
		const nearestBoundaryId = itemKey === void 0 ? id : parentBoundary;
		stack.push({
			data,
			id,
			start: comment,
			nearestBoundaryId,
			listId,
			itemKey
		});
	}, { budget });
	return !valid || stack.length ? void 0 : index;
}
function ownedByExecutionRoot(node, executionRoot) {
	if (!executionRoot) return true;
	const owner = findNodeOwnerInstance(node);
	return !owner || owner.domain.executionRoot === executionRoot;
}
/** Performs the reindex list domain operation. */
function reindexList(index, listId) {
	const list = index.ranges.get(listId);
	if (!list) return;
	const items = /* @__PURE__ */ new Map();
	let cursor = list.start.nextSibling;
	const starts = /* @__PURE__ */ new Map();
	while (cursor && cursor !== list.end) {
		consumeDomWork(index.budget);
		if (cursor instanceof Comment && cursor.data.startsWith("exact:item:")) starts.set(cursor.data, cursor);
		else if (cursor instanceof Comment && cursor.data.startsWith("/exact:item:")) {
			const data = cursor.data.slice(1);
			const start = starts.get(data);
			if (start) items.set(data.slice(data.lastIndexOf(":") + 1), {
				start,
				end: cursor
			});
		}
		cursor = cursor.nextSibling;
	}
	index.listItems.set(listId, items);
}
//#endregion
//#region packages/hydrate/dist/patching/application.js
/** Applies a patch to the owned runtime state. */
function applyPatch(container, patch, index, prepared, budget, cleanupFailure) {
	if (patch.type === "text") {
		const target = findExactTarget(container, patch.id, index) ?? findServerSlotElement(container, patch.id, index);
		if (!target) return false;
		if (target instanceof Element) attemptCleanup(cleanupFailure, () => disposeOwnedSubtree(target, false, budget));
		target.textContent = patch.value;
		return true;
	}
	if (patch.type === "prop") {
		if (!isSafeDomPatchProperty(patch.name)) return false;
		const target = findExactElementTarget(container, patch.id, index);
		if (!target) return false;
		applyDomProp(target, patch.name, patch.value);
		return true;
	}
	if (patch.type === "style") {
		const target = findExactElementTarget(container, patch.id, index);
		if (!target) return false;
		if (patch.value === null) target.style.removeProperty(patch.name);
		else target.style.setProperty(patch.name, patch.value);
		return true;
	}
	if (patch.type === "replace") {
		const range = findExactRange(container, patch.id, index);
		if (!range) {
			const clientBoundary = findClientBoundaryElement(container, patch.id, index);
			if (clientBoundary) {
				replaceElement(clientBoundary, prepared?.fragment, budget, cleanupFailure);
				return true;
			}
			const exactElement = findExactElement(container, patch.id, index);
			if (exactElement) {
				replaceElement(exactElement, prepared?.fragment, budget, cleanupFailure);
				return true;
			}
			const slot = findServerSlotElement(container, patch.id, index);
			if (!slot) return false;
			replaceElementChildren(slot, prepared?.fragment, budget, cleanupFailure);
			return true;
		}
		replaceRange(range, prepared?.fragment, budget, cleanupFailure);
		return true;
	}
	if (patch.type === "state") {
		const target = findExactElement(container, patch.id, index);
		if (!target) return false;
		target.setAttribute("data-exact-state", prepared.stateJson);
		return true;
	}
	if (patch.type === "list") {
		const range = findExactRange(container, patch.id, index);
		if (!range) return false;
		if (patch.op === "remove") {
			const item = index ? findIndexedItem(index, patch.id, patch.key) : findExactItemRange(container, patch.key, range);
			if (!item) return false;
			replaceRange(item, void 0, budget, cleanupFailure);
			if (index) reindexList(index, patch.id);
			return true;
		}
		const anchor = (patch.before ? index ? findIndexedItem(index, patch.id, patch.before) : findExactItemRange(container, patch.before, range) : void 0)?.start ?? range.end;
		if (patch.op === "move") {
			const item = index ? findIndexedItem(index, patch.id, patch.key) : findExactItemRange(container, patch.key, range);
			if (!item) {
				if (!patch.html) return false;
				insertFragmentBefore(anchor, prepared?.fragment);
				if (index) reindexList(index, patch.id);
				return true;
			}
			moveRangeBefore(item, anchor, budget);
			if (index) reindexList(index, patch.id);
			return true;
		}
		if (!patch.html) return false;
		insertFragmentBefore(anchor, prepared?.fragment);
		if (index) reindexList(index, patch.id);
		return true;
	}
	return false;
}
//#endregion
//#region packages/hydrate/dist/patching/api.js
/** Applies a patches to the owned runtime state. */
function applyPatches(container, patches, options = {}) {
	if (!patches.length) return true;
	const index = createProtocolIndex(container, options.workBudget ?? options.maxTreeNodes, options.executionRoot);
	if (!index || !validatePatchSequence(index, patches) || !validatePatchTopology(index, patches)) {
		const failed = patches.find((patch) => !index || !canApplyPatch(index, patch));
		const detail = failed ? `${failed.type}:${failed.id}` : "invalid marker topology";
		reportMismatch(options, `could not atomically apply exact patches (${detail})`, "invalid-patch", failed);
		if (options.onMismatch === "throw") throw new Error(`Could not apply exact patch batch (${detail})`);
		return false;
	}
	const prepared = preparePatchBatch(container, index, patches);
	if (!prepared.ok) {
		reportMismatch(options, `could not atomically apply exact patches (${prepared.detail})`, "invalid-patch");
		if (options.onMismatch === "throw") throw new Error(`Could not apply exact patch batch (${prepared.detail})`);
		return false;
	}
	const crossesRoot = options.executionRoot !== void 0 && options.onCrossRootReplacement !== void 0 && patches.some((patch) => isStructuralPatch(patch) && targetContainsForeignRoot(protocolTarget(index, patch.id), options.executionRoot, index.budget));
	const cleanupFailure = createCleanupFailure();
	const commitBudget = createDomWorkBudget(Number.MAX_SAFE_INTEGER);
	for (let patchIndex = 0; patchIndex < patches.length; patchIndex++) {
		const patch = patches[patchIndex];
		if (!applyPatch(container, patch, index, prepared.patches[patchIndex], commitBudget, cleanupFailure)) throw new Error(`Prepared exact patch invariant failed for ${patch.type}:${patch.id}`);
	}
	throwCleanupFailure(cleanupFailure);
	if (crossesRoot) options.onCrossRootReplacement?.();
	return true;
}
function targetContainsForeignRoot(target, executionRoot, work) {
	if (!target) return false;
	let foreign = false;
	const inspect = (node) => {
		const owner = findNodeOwnerInstance(node);
		if (owner && owner.domain.executionRoot !== executionRoot) foreign = true;
	};
	if (target instanceof Node) {
		walkDomSubtree(target, inspect, { budget: work });
		return foreign;
	}
	for (let cursor = target.start.nextSibling; cursor && cursor !== target.end; cursor = cursor.nextSibling) walkDomSubtree(cursor, inspect, { budget: work });
	return foreign;
}
/** Performs the boundary inner html domain operation. */
function boundaryInnerHtml(container, id, work, executionRoot) {
	const index = createProtocolIndex(container, work, executionRoot);
	if (!index) return void 0;
	return indexedBoundaryHtml(container, index, id);
}
/** Reads one fully attributed partition instance from the bounded protocol index. */
function partitionAuthority(container, id, work, executionRoot = "page") {
	const index = createProtocolIndex(container, work, executionRoot);
	const marker = index && findServerSlotElement(container, id, index);
	if (!marker) return void 0;
	const version = Number(marker.getAttribute("data-exact-partition-version"));
	const buildKey = marker.getAttribute("data-exact-partition-build");
	const root = marker.getAttribute("data-exact-partition-root");
	const planEdgeId = marker.getAttribute("data-exact-partition-edge");
	const ownerComponentId = marker.getAttribute("data-exact-partition-owner");
	const discriminator = readExactPartitionDiscriminator(marker);
	const generation = Number(marker.getAttribute("data-exact-partition-generation"));
	if (version !== 1 || !buildKey || root !== executionRoot || !planEdgeId || !discriminator || planEdgeId !== id && !(discriminator.kind === "keyed" && id.startsWith(`${planEdgeId}:key:`)) || !ownerComponentId || !Number.isSafeInteger(generation) || generation < 1) return void 0;
	return Object.freeze({
		version: 1,
		buildKey,
		executionRoot: root,
		planEdgeId,
		ownerComponentId,
		discriminator,
		generation
	});
}
/** Performs the boundary inner htmls domain operation. */
function boundaryInnerHtmls(container, ids, work, executionRoot) {
	const index = createProtocolIndex(container, work, executionRoot);
	if (!index) return {};
	const htmls = {};
	for (const id of ids) {
		const html = indexedBoundaryHtml(container, index, id);
		if (html !== void 0) htmls[id] = html;
	}
	return htmls;
}
/** Performs the indexed boundary html domain operation. */
function indexedBoundaryHtml(container, index, id) {
	const range = index.ranges.get(id);
	if (!range) return findServerSlotElement(container, id, index)?.innerHTML ?? findClientBoundaryElement(container, id, index)?.outerHTML;
	const wrapper = document.createElement("div");
	let cursor = range.start.nextSibling;
	while (cursor && cursor !== range.end) {
		wrapper.appendChild(cursor.cloneNode(true));
		cursor = cursor.nextSibling;
	}
	return wrapper.innerHTML;
}
/** Creates a patch boundary resolver. */
function createPatchBoundaryResolver(container, boundaryIds, work) {
	const index = createProtocolIndex(container, work);
	if (!index) return () => void 0;
	const boundaries = boundaryIds.flatMap((id) => {
		const target = protocolTarget(index, id);
		return target ? [{
			id,
			target
		}] : [];
	});
	const ids = new Set(boundaries.map((boundary) => boundary.id));
	return (patchId) => {
		if (ids.has(patchId)) return patchId;
		const target = protocolTarget(index, patchId);
		if (!target) return void 0;
		let owner;
		for (const candidate of boundaries) {
			if (!protocolTargetContains(candidate.target, target)) continue;
			if (!owner || protocolTargetContains(owner.target, candidate.target)) owner = candidate;
		}
		return owner?.id;
	};
}
//#endregion
//#region packages/hydrate/dist/runtime/current-document.js
/**
* Enforces that hydration runs against the executing realm's current document.
* eXact's DOM renderer, event delegation, focus ownership, and lifecycle use
* that realm's platform constructors and therefore cannot own a foreign window.
*/
function assertCurrentDocumentContainer(container) {
	const currentDocument = globalThis.document;
	if ((container.nodeType === 9 ? container : container.ownerDocument) !== currentDocument) throw new Error("eXact hydration requires a container owned by the current document.");
	const elementConstructor = currentDocument.defaultView?.Element;
	if (container.nodeType !== 9 && elementConstructor && !(container instanceof elementConstructor)) throw new Error("eXact hydration requires a container created in the current window realm.");
}
//#endregion
//#region packages/core/dist/client/inspection-transport.js
var bridgeSymbol = Symbol.for("@exactjs/server-observation-bridge");
var observationsKey = "__exactObservations";
/** Returns the internal request header only while browser DevTools is attached. */
function exactServerObservationRequestHeaders() {
	const sessionId = globalThis[bridgeSymbol]?.sessionId;
	return sessionId ? { "x-exact-debug-session": sessionId } : {};
}
/** Removes and publishes a bounded observation attachment from one JSON response envelope. */
function consumeExactServerObservations(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return value;
	const record = value;
	if (!Object.hasOwn(record, observationsKey)) return value;
	const descriptors = Object.getOwnPropertyDescriptors(record);
	const observationDescriptor = descriptors[observationsKey];
	if (!observationDescriptor || !("value" in observationDescriptor)) return value;
	publishObservations(observationDescriptor.value);
	delete descriptors[observationsKey];
	const copy = Object.create(Object.getPrototypeOf(record));
	Object.defineProperties(copy, descriptors);
	return copy;
}
/** Publishes a request-scoped observation array after validating every protocol event. */
function publishExactServerObservations(value) {
	publishObservations(value);
}
function publishObservations(value) {
	if (!Array.isArray(value)) return;
	const bridge = globalThis[bridgeSymbol];
	if (!bridge) return;
	for (const event of value) {
		if (!isExactRuntimeInspectionEvent(event) || event.id.sessionId !== bridge.sessionId) continue;
		try {
			bridge.publish(event);
		} catch {}
	}
}
//#endregion
//#region packages/core/dist/client/framework/async-values.js
/** Reports whether a value provides the AbortSignal surface used by framework transports. */
function isAbortSignal(value) {
	return !!value && typeof value === "object" && "aborted" in value && typeof value.addEventListener === "function";
}
//#endregion
//#region packages/hydrate/dist/response/ndjson.js
/** Reads a ndjson events from its source representation. */
async function readNdjsonEvents(stream, message, receive, options) {
	const reader = stream.getReader();
	const decoder = new TextDecoder("utf-8", { fatal: true });
	const signal = options.signal;
	const maxBytes = normalizeProtocolLimit(options.maxBytes, 16777216);
	const maxEvents = normalizeProtocolLimit(options.maxEvents, 1e5);
	let buffer = "";
	let bytes = 0;
	let events = 0;
	const abort = () => {
		reader.cancel(signal?.reason);
	};
	if (signal?.aborted) abort();
	else signal?.addEventListener("abort", abort, { once: true });
	try {
		while (true) {
			if (signal?.aborted) throw signal.reason ?? new DOMException("eXact request aborted", "AbortError");
			const next = await reader.read();
			if (signal?.aborted) throw signal.reason ?? new DOMException("eXact request aborted", "AbortError");
			if (next.done) break;
			bytes += next.value.byteLength;
			if (bytes > maxBytes) throw new Error("eXact stream response exceeded maxBytes");
			buffer += decoder.decode(next.value, { stream: true });
			let newline;
			while ((newline = buffer.indexOf("\n")) >= 0) {
				const line = buffer.slice(0, newline).replace(/\r$/, "");
				buffer = buffer.slice(newline + 1);
				if (!line.trim()) continue;
				if (++events > maxEvents) throw new Error("eXact stream response exceeded maxEvents");
				receive(parseNdjsonLine(line, message));
			}
		}
		buffer += decoder.decode();
		if (buffer.trim()) {
			if (++events > maxEvents) throw new Error("eXact stream response exceeded maxEvents");
			receive(parseNdjsonLine(buffer.replace(/\r$/, ""), message));
		}
	} catch (error) {
		const failure = error instanceof TypeError ? new Error(message) : error;
		try {
			await reader.cancel(failure);
		} catch {}
		throw failure;
	} finally {
		signal?.removeEventListener("abort", abort);
		reader.releaseLock();
	}
}
/** Reads a ndjson line from its source representation. */
function parseNdjsonLine(line, message) {
	try {
		return JSON.parse(line);
	} catch {
		throw new Error(message);
	}
}
//#endregion
//#region packages/hydrate/dist/response/events.js
/** Reports whether exact stream start event. */
function isExactStreamStartEvent(value) {
	if (!value || typeof value !== "object" || Array.isArray(value) || !isJsonSafe(value)) return false;
	const record = value;
	return hasOnlyKeys(record, [
		"event",
		"version",
		"operations"
	]) && record.event === "start" && record.version === 1 && typeof record.operations === "number" && Number.isInteger(record.operations) && record.operations >= 0;
}
/** Reports whether exact stream result event. */
function isExactStreamResultEvent(value) {
	if (!value || typeof value !== "object" || Array.isArray(value) || !isJsonSafe(value)) return false;
	const record = value;
	return hasOnlyKeys(record, [
		"event",
		"version",
		"index",
		"result"
	]) && record.event === "result" && record.version === 1 && typeof record.index === "number" && Number.isInteger(record.index);
}
/** Reports whether exact stream patch event. */
function isExactStreamPatchEvent(value) {
	if (!value || typeof value !== "object" || Array.isArray(value) || !isJsonSafe(value)) return false;
	const record = value;
	return hasOnlyKeys(record, [
		"event",
		"version",
		"index",
		"type",
		"id",
		"opId",
		"patch"
	]) && record.event === "patch" && record.version === 1 && typeof record.index === "number" && (record.type === "invoke" || record.type === "refresh") && typeof record.id === "string" && !!record.id && (record.opId === void 0 || typeof record.opId === "string") && isPatchLike(record.patch);
}
/** Reports whether exact stream state event. */
function isExactStreamStateEvent(value) {
	if (!value || typeof value !== "object" || Array.isArray(value) || !isJsonSafe(value)) return false;
	const record = value;
	return hasOnlyKeys(record, [
		"event",
		"version",
		"index",
		"type",
		"id",
		"opId",
		"value"
	]) && record.event === "state" && record.version === 1 && typeof record.index === "number" && (record.type === "invoke" || record.type === "refresh") && typeof record.id === "string" && !!record.id && (record.opId === void 0 || typeof record.opId === "string") && "value" in record && record.value !== void 0;
}
/** Reports whether an exact stream event contains ordered collection deltas. */
function isExactStreamMutationsEvent(value) {
	if (!value || typeof value !== "object" || Array.isArray(value) || !isJsonSafe(value)) return false;
	const record = value;
	return hasOnlyKeys(record, [
		"event",
		"version",
		"index",
		"type",
		"id",
		"opId",
		"mutations"
	]) && record.event === "mutations" && record.version === 1 && typeof record.index === "number" && (record.type === "invoke" || record.type === "refresh") && typeof record.id === "string" && !!record.id && (record.opId === void 0 || typeof record.opId === "string") && Array.isArray(record.mutations) && record.mutations.every(isCollectionMutationLike);
}
/** Reports whether exact stream html event. */
function isExactStreamHtmlEvent(value) {
	if (!value || typeof value !== "object" || Array.isArray(value) || !isJsonSafe(value)) return false;
	const record = value;
	return hasOnlyKeys(record, [
		"event",
		"version",
		"index",
		"type",
		"id",
		"opId",
		"html"
	]) && record.event === "html" && record.version === 1 && typeof record.index === "number" && (record.type === "invoke" || record.type === "refresh") && typeof record.id === "string" && !!record.id && (record.opId === void 0 || typeof record.opId === "string") && typeof record.html === "string";
}
/** Reports whether exact stream complete event. */
function isExactStreamCompleteEvent(value) {
	if (!value || typeof value !== "object" || Array.isArray(value) || !isJsonSafe(value)) return false;
	const record = value;
	return hasOnlyKeys(record, ["event", "version"]) && record.event === "complete" && record.version === 1;
}
/** Reports whether an exact stream event carries observations owned by this response. */
function isExactStreamObservationsEvent(value) {
	if (!value || typeof value !== "object" || Array.isArray(value) || !isJsonSafe(value)) return false;
	const record = value;
	return hasOnlyKeys(record, [
		"event",
		"version",
		"observations"
	]) && record.event === "observations" && record.version === 1 && Array.isArray(record.observations);
}
//#endregion
//#region packages/hydrate/dist/response/stream.js
/** Reads an exact stream response from its source representation. */
async function readExactStreamResponse(response, expected, options = {}) {
	const message = "eXact stream invocation returned malformed events";
	if (!response.body) throw new Error(message);
	const expectedOperations = typeof expected === "number" ? expected : expected.length;
	const expectedList = typeof expected === "number" ? void 0 : expected;
	const normalized = isAbortSignal(options) ? { signal: options } : options;
	const results = new Array(expectedOperations);
	const chunks = new Array(expectedOperations).fill(void 0).map(() => ({}));
	const stateReceived = new Array(expectedOperations).fill(false);
	const mutationsReceived = new Array(expectedOperations).fill(false);
	const htmlReceived = new Array(expectedOperations).fill(false);
	const maxPatches = normalizeProtocolLimit(normalized.maxPatches, 1e4);
	let started = false;
	let completed = false;
	await readNdjsonEvents(response.body, message, (rawEvent) => {
		const event = decodeBoundedReactiveProtocolValue(rawEvent, {
			maxDepth: normalized.maxJsonDepth,
			maxNodes: normalized.maxJsonNodes,
			maxBytes: normalized.maxBytes
		}, () => /* @__PURE__ */ new Error(message));
		if (completed) throw new Error(message);
		if (!started) {
			if (!isExactStreamStartEvent(event) || event.operations !== expectedOperations) throw new Error(message);
			started = true;
			return;
		}
		if (isExactStreamCompleteEvent(event)) {
			completed = true;
			return;
		}
		if (isExactStreamObservationsEvent(event)) {
			publishExactServerObservations(event.observations);
			return;
		}
		if (isExactStreamPatchEvent(event)) {
			assertStreamIndex(event.index, expectedOperations, message);
			assertStreamOperation(event.index, event, expectedList, message);
			if (results[event.index]) throw new Error(message);
			const target = chunks[event.index];
			if ((target.patches?.length ?? 0) >= maxPatches) throw new Error(message);
			target.patches = [...target.patches ?? [], event.patch];
			return;
		}
		if (isExactStreamStateEvent(event)) {
			assertStreamIndex(event.index, expectedOperations, message);
			assertStreamOperation(event.index, event, expectedList, message);
			if (results[event.index] || stateReceived[event.index]) throw new Error(message);
			stateReceived[event.index] = true;
			chunks[event.index].state = event.value;
			return;
		}
		if (isExactStreamMutationsEvent(event)) {
			assertStreamIndex(event.index, expectedOperations, message);
			assertStreamOperation(event.index, event, expectedList, message);
			if (results[event.index] || mutationsReceived[event.index]) throw new Error(message);
			mutationsReceived[event.index] = true;
			chunks[event.index].mutations = event.mutations;
			return;
		}
		if (isExactStreamHtmlEvent(event)) {
			assertStreamIndex(event.index, expectedOperations, message);
			assertStreamOperation(event.index, event, expectedList, message);
			if (results[event.index] || htmlReceived[event.index]) throw new Error(message);
			htmlReceived[event.index] = true;
			chunks[event.index].html = event.html;
			return;
		}
		if (isExactStreamResultEvent(event)) {
			assertStreamIndex(event.index, expectedOperations, message);
			if (results[event.index]) throw new Error(message);
			const result = parseExactOperationResult(event.result, expectedList?.[event.index], normalized);
			if (result.ok && (result.patches?.length ?? 0) + (chunks[event.index].patches?.length ?? 0) > maxPatches) throw new Error(message);
			if (result.ok && ("state" in result && stateReceived[event.index] || result.html !== void 0 && htmlReceived[event.index])) throw new Error(message);
			results[event.index] = result.ok ? {
				...result,
				...chunks[event.index]
			} : result;
			return;
		}
		throw new Error(message);
	}, normalized);
	if (!started || !completed) throw new Error(message);
	for (let index = 0; index < expectedOperations; index++) if (!results[index]) throw new Error(message);
	return results;
}
/** Validates stream operation and throws when the contract is violated. */
function assertStreamOperation(index, actual, expected, message) {
	if (expected && !matchesOperation(actual, expected[index])) throw new Error(message);
}
/** Reports whether operation. */
function matchesOperation(record, expected) {
	return record.type === expected.type && record.id === expected.id && record.opId === expected.opId;
}
/** Validates stream index and throws when the contract is violated. */
function assertStreamIndex(index, expectedOperations, message) {
	if (!Number.isInteger(index) || index < 0 || index >= expectedOperations) throw new Error(message);
}
//#endregion
//#region packages/hydrate/dist/response/result.js
/** Reads an exact operation result from its source representation. */
function parseExactOperationResult(value, expected, limits = {}) {
	if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("eXact batch invocation returned malformed results");
	if (!isJsonSafe(value, {
		maxDepth: limits.maxJsonDepth,
		maxNodes: limits.maxJsonNodes,
		maxBytes: limits.maxBytes
	})) throw new Error("eXact batch invocation returned malformed results");
	const record = value;
	if (record.ok === true) {
		if (!hasOnlyKeys(record, [
			"ok",
			"type",
			"id",
			"opId",
			"patches",
			"state",
			"mutations",
			"contexts",
			"value",
			"html"
		])) throw new Error("eXact batch invocation returned malformed results");
		if (record.type !== "invoke" && record.type !== "refresh") throw new Error("eXact batch invocation returned malformed results");
		if (typeof record.id !== "string" || !record.id) throw new Error("eXact batch invocation returned malformed results");
		if (record.opId !== void 0 && typeof record.opId !== "string") throw new Error("eXact batch invocation returned malformed results");
		if (expected && !matchesOperation(record, expected)) throw new Error("eXact batch invocation returned malformed results");
		const result = parseExactInvocationResponse({
			ok: true,
			...record.patches === void 0 ? {} : { patches: record.patches },
			..."state" in record ? { state: record.state } : {},
			...record.mutations === void 0 ? {} : { mutations: record.mutations },
			...record.contexts === void 0 ? {} : { contexts: record.contexts },
			..."value" in record ? { value: record.value } : {},
			...record.html === void 0 ? {} : { html: record.html }
		}, "eXact batch invocation returned malformed results", void 0, limits);
		return {
			ok: true,
			type: record.type,
			id: record.id,
			...record.opId === void 0 ? {} : { opId: record.opId },
			...result
		};
	}
	if (record.ok === false) {
		if (!hasOnlyKeys(record, [
			"ok",
			"type",
			"id",
			"opId",
			"status",
			"error"
		])) throw new Error("eXact batch invocation returned malformed results");
		if (record.type !== "invoke" && record.type !== "refresh") throw new Error("eXact batch invocation returned malformed results");
		if (typeof record.id !== "string" || !record.id) throw new Error("eXact batch invocation returned malformed results");
		if (record.opId !== void 0 && typeof record.opId !== "string") throw new Error("eXact batch invocation returned malformed results");
		if (expected && !matchesOperation(record, expected)) throw new Error("eXact batch invocation returned malformed results");
		if (typeof record.status !== "number" || !Number.isInteger(record.status)) throw new Error("eXact batch invocation returned malformed results");
		if (record.error !== "bad_request" && record.error !== "not_found" && record.error !== "forbidden" && record.error !== "internal_error" && record.error !== "dependency_failed") throw new Error("eXact batch invocation returned malformed results");
		return {
			ok: false,
			type: record.type,
			id: record.id,
			...record.opId === void 0 ? {} : { opId: record.opId },
			status: record.status,
			error: record.error
		};
	}
	throw new Error("eXact batch invocation returned malformed results");
}
/** Reports whether a decoded ordered collection delta has a valid protocol shape. */
function isCollectionMutationLike(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	const record = value;
	if (typeof record.path !== "string" || !record.path) return false;
	switch (record.operation) {
		case "map-set": return hasOnlyKeys(record, [
			"path",
			"operation",
			"key",
			"value"
		]) && isTransportableReactiveMapKey(record.key) && "value" in record;
		case "map-delete": return hasOnlyKeys(record, [
			"path",
			"operation",
			"key"
		]) && isTransportableReactiveMapKey(record.key);
		case "map-clear":
		case "set-clear": return hasOnlyKeys(record, ["path", "operation"]);
		case "set-add":
		case "set-delete": return hasOnlyKeys(record, [
			"path",
			"operation",
			"value"
		]) && "value" in record;
		default: return false;
	}
}
/** Reports whether patch like. */
function isPatchLike(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	if (!isJsonSafe(value)) return false;
	const record = value;
	if (typeof record.type !== "string" || typeof record.id !== "string" || !record.id) return false;
	switch (record.type) {
		case "text": return hasOnlyKeys(record, [
			"type",
			"id",
			"value"
		]) && typeof record.value === "string";
		case "prop": return hasOnlyKeys(record, [
			"type",
			"id",
			"name",
			"value"
		]) && typeof record.name === "string" && "value" in record && record.value !== void 0;
		case "style": return hasOnlyKeys(record, [
			"type",
			"id",
			"name",
			"value"
		]) && typeof record.name === "string" && (typeof record.value === "string" || record.value === null);
		case "list": return hasOnlyKeys(record, [
			"type",
			"id",
			"op",
			"key",
			"before",
			"html"
		]) && (record.op === "insert" || record.op === "move" || record.op === "remove") && typeof record.key === "string" && (record.before === void 0 || typeof record.before === "string") && (record.html === void 0 || typeof record.html === "string");
		case "state": return hasOnlyKeys(record, [
			"type",
			"id",
			"value"
		]) && "value" in record && record.value !== void 0;
		case "replace": return hasOnlyKeys(record, [
			"type",
			"id",
			"html"
		]) && typeof record.html === "string";
		default: return false;
	}
}
//#endregion
//#region packages/hydrate/dist/response/json.js
/** Reads an exact invocation response from its source representation. */
function parseExactInvocationResponse(body, message, expected, limits = {}) {
	body = decodeBoundedReactiveProtocolValue(body, {
		maxDepth: limits.maxJsonDepth,
		maxNodes: limits.maxJsonNodes,
		maxBytes: limits.maxBytes
	}, () => new Error(message));
	if (!body || typeof body !== "object" || Array.isArray(body)) throw new Error(message);
	const record = body;
	if (record.ok !== true) throw new Error(message);
	if (!hasOnlyKeys(record, [
		"ok",
		"type",
		"id",
		"opId",
		"patches",
		"state",
		"mutations",
		"contexts",
		"value",
		"html"
	])) throw new Error(message);
	if (expected && !matchesOperation(record, expected)) throw new Error(message);
	if ("state" in record && record.state === void 0) throw new Error(message);
	if (record.contexts !== void 0 && (!record.contexts || typeof record.contexts !== "object" || Array.isArray(record.contexts))) throw new Error(message);
	if (record.patches !== void 0 && (!Array.isArray(record.patches) || !record.patches.every(isPatchLike))) throw new Error(message);
	if (record.mutations !== void 0 && (!Array.isArray(record.mutations) || !record.mutations.every((value) => isCollectionMutationLike(value)))) throw new Error(message);
	if (Array.isArray(record.patches) && record.patches.length > normalizeProtocolLimit(limits.maxPatches, 1e4)) throw new Error(message);
	if (record.html !== void 0 && typeof record.html !== "string") throw new Error(message);
	return {
		...record.patches === void 0 ? {} : { patches: record.patches },
		..."state" in record ? { state: record.state } : {},
		...record.mutations === void 0 ? {} : { mutations: record.mutations },
		...record.contexts === void 0 ? {} : { contexts: record.contexts },
		..."value" in record ? { value: record.value } : {},
		...record.html === void 0 ? {} : { html: record.html }
	};
}
/** Reads an exact batch response from its source representation. */
function parseExactBatchResponse(body, expected, limits = {}) {
	const message = "eXact batch invocation returned malformed results";
	body = decodeBoundedReactiveProtocolValue(body, {
		maxDepth: limits.maxJsonDepth,
		maxNodes: limits.maxJsonNodes,
		maxBytes: limits.maxBytes
	}, () => /* @__PURE__ */ new Error(message));
	if (!body || typeof body !== "object" || Array.isArray(body)) throw new Error(message);
	const record = body;
	if (record.ok !== true) throw new Error(message);
	if (!hasOnlyKeys(record, [
		"ok",
		"version",
		"results"
	])) throw new Error(message);
	if (record.version !== 1) throw new Error(message);
	if (!Array.isArray(record.results)) throw new Error(message);
	if (expected && record.results.length !== expected.length) throw new Error(message);
	return record.results.map((result, index) => parseExactOperationResult(result, expected?.[index], limits));
}
//#endregion
//#region packages/hydrate/dist/invocations.js
/** Invokes a single eXact server task or boundary refresh endpoint operation. */
async function invokeExact(options) {
	const fetchImpl = options.fetch ?? globalThis.fetch;
	if (!fetchImpl) throw new Error("eXact endpoint invocation requires fetch");
	const requestBody = encodeRequest({
		type: options.type,
		root: options.root,
		id: options.id,
		partition: options.partition,
		payload: options.payload,
		state: options.state,
		publicContext: options.publicContext,
		boundaryHtml: options.boundaryHtml,
		boundaryHtmls: options.boundaryHtmls
	}, options.streamLimits?.maxRequestBytes);
	const response = await withAbort(fetchImpl(options.endpoint, {
		method: "POST",
		headers: {
			"content-type": "application/json",
			...options.stream ? {
				accept: "application/x-ndjson",
				"x-exact-stream": "1"
			} : {},
			...options.headers,
			...exactServerObservationRequestHeaders()
		},
		signal: options.signal,
		body: requestBody
	}), options.signal);
	notifyResponse(options.onResponse, response);
	if (!response.ok) {
		logFrameworkEvent("warn", "hydrate", "request", `exact ${options.type} invocation failed with ${response.status}`, void 0, options.logger);
		throw await invocationFailure(response, `eXact ${options.type} invocation failed`, options);
	}
	const operation = {
		type: options.type,
		root: options.root,
		id: options.id
	};
	if (options.stream) {
		const result = (await readExactStreamResponse(response, [operation], {
			signal: options.signal,
			...options.streamLimits
		}))[0];
		if (!result?.ok) throw new Error(`eXact ${options.type} invocation failed`);
		const { ok: _ok, type: _type, id: _id, ...body } = result;
		return body;
	}
	return parseExactInvocationResponse(await readJsonResponse(response, options.streamLimits, options.signal), `eXact ${options.type} invocation returned malformed result`, operation, options.streamLimits);
}
/** Invokes multiple eXact operations as one batch request and returns per-operation results. */
async function invokeExactBatch(options) {
	const fetchImpl = options.fetch ?? globalThis.fetch;
	if (!fetchImpl) throw new Error("eXact endpoint invocation requires fetch");
	const requestBody = encodeRequest({
		type: "batch",
		version: 1,
		operations: options.operations
	}, options.streamLimits?.maxRequestBytes);
	const response = await withAbort(fetchImpl(options.endpoint, {
		method: "POST",
		headers: {
			"content-type": "application/json",
			...options.stream ? {
				accept: "application/x-ndjson",
				"x-exact-stream": "1"
			} : {},
			...options.headers,
			...exactServerObservationRequestHeaders()
		},
		signal: options.signal,
		body: requestBody
	}), options.signal);
	notifyResponse(options.onResponse, response);
	if (!response.ok) {
		logFrameworkEvent("warn", "hydrate", "request", `exact batch invocation failed with ${response.status}`, void 0, options.logger);
		throw await invocationFailure(response, "eXact batch invocation failed", options);
	}
	if (options.stream) return readExactStreamResponse(response, options.operations, {
		signal: options.signal,
		...options.streamLimits
	});
	return parseExactBatchResponse(await readJsonResponse(response, options.streamLimits, options.signal), options.operations, options.streamLimits);
}
/** Identifies the reserved top-level response that asks a remote root to replace its build. */
var ExactBuildUnsupportedError = class extends Error {
	status = 410;
	code = "exact_build_unsupported";
	constructor() {
		super("eXact remote build is no longer supported");
		this.name = "ExactBuildUnsupportedError";
	}
};
async function invocationFailure(response, fallback, options) {
	try {
		const value = await readJsonResponse(response, options.streamLimits, options.signal);
		if (response.status === 410 && value !== null && typeof value === "object" && value.error === "exact_build_unsupported") return new ExactBuildUnsupportedError();
	} catch {}
	return new Error(fallback);
}
function notifyResponse(listener, response) {
	if (!listener) return;
	const preferredBuildKey = responseHeader(response.headers, "x-exact-preferred-build");
	listener(Object.freeze({
		status: response.status,
		...preferredBuildKey ? { preferredBuildKey } : {}
	}));
}
function responseHeader(headers, name) {
	if (!headers) return void 0;
	if ("get" in headers && typeof headers.get === "function") return headers.get(name) ?? void 0;
	const key = Object.keys(headers).find((candidate) => candidate.toLowerCase() === name);
	return key ? headers[key] : void 0;
}
function encodeRequest(value, maxBytes) {
	const body = JSON.stringify(encodeReactiveProtocolValue(value));
	if (protocolUtf8ByteLength(body) > normalizeProtocolLimit(maxBytes, 4194304)) throw new Error("eXact request exceeded maxRequestBytes");
	return body;
}
async function readJsonResponse(response, limits, signal) {
	if (response.body) {
		const text = await readBoundedResponseBody(response.body, normalizeProtocolLimit(limits?.maxBytes, 16777216), signal);
		return consumeExactServerObservations(JSON.parse(text));
	}
	if (response.text) {
		const text = await withAbort(response.text(), signal);
		assertResponseBytes(text, limits?.maxBytes);
		return consumeExactServerObservations(JSON.parse(text));
	}
	const value = await withAbort(response.json(), signal);
	let encoded;
	try {
		encoded = JSON.stringify(value);
	} catch {}
	if (encoded !== void 0) assertResponseBytes(encoded, limits?.maxBytes);
	return consumeExactServerObservations(value);
}
async function readBoundedResponseBody(body, maxBytes, signal) {
	const reader = body.getReader();
	const chunks = [];
	let length = 0;
	const abort = () => void reader.cancel(signal?.reason).catch(() => void 0);
	if (signal?.aborted) abort();
	else signal?.addEventListener("abort", abort, { once: true });
	try {
		while (true) {
			if (signal?.aborted) throw signal.reason ?? new DOMException("eXact request aborted", "AbortError");
			const next = await reader.read();
			if (signal?.aborted) throw signal.reason ?? new DOMException("eXact request aborted", "AbortError");
			if (next.done) break;
			length += next.value.byteLength;
			if (length > maxBytes) throw new Error("eXact response exceeded maxBytes");
			chunks.push(next.value);
		}
		const bytes = new Uint8Array(length);
		let offset = 0;
		for (const chunk of chunks) {
			bytes.set(chunk, offset);
			offset += chunk.byteLength;
		}
		return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
	} catch (error) {
		try {
			await reader.cancel(error);
		} catch {}
		throw error;
	} finally {
		signal?.removeEventListener("abort", abort);
		reader.releaseLock();
	}
}
function assertResponseBytes(value, configured) {
	if (protocolUtf8ByteLength(value) > normalizeProtocolLimit(configured, 16777216)) throw new Error("eXact response exceeded maxBytes");
}
function withAbort(promise, signal) {
	if (!signal) return promise;
	if (signal.aborted) return Promise.reject(signal.reason ?? new DOMException("eXact request aborted", "AbortError"));
	return new Promise((resolve, reject) => {
		const abort = () => reject(signal.reason ?? new DOMException("eXact request aborted", "AbortError"));
		signal.addEventListener("abort", abort, { once: true });
		promise.then(resolve, reject).finally(() => signal.removeEventListener("abort", abort));
	});
}
//#endregion
//#region packages/hydrate/dist/batching.js
var batchQueues = [];
/** Queues an eXact operation for microtask batching by endpoint, transport, and headers. */
function enqueueExactOperation(_container, options) {
	const headersKey = headersCacheKey(options.headers);
	let queue = batchQueues.find((item) => item.endpoint === options.endpoint && item.fetch === options.fetch && item.headersKey === headersKey && item.logger === options.logger && item.stream === options.stream && item.streamLimits === options.streamLimits);
	if (!queue) {
		queue = {
			endpoint: options.endpoint,
			fetch: options.fetch,
			headers: options.headers,
			headersKey,
			logger: options.logger,
			stream: options.stream,
			streamLimits: options.streamLimits,
			pending: [],
			scheduled: false,
			active: 0
		};
		batchQueues.push(queue);
	}
	const promise = new Promise((resolve, reject) => {
		queue.pending.push({
			operation: options.operation,
			signal: options.signal,
			onResponse: options.onResponse,
			resolve,
			reject
		});
	});
	if (!queue.scheduled) {
		queue.scheduled = true;
		queueMicrotask(() => {
			flushExactBatchQueue(queue).finally(() => reclaimQueue(queue));
		});
	}
	return promise;
}
async function flushExactBatchQueue(queue) {
	const pending = queue.pending.splice(0);
	queue.scheduled = false;
	if (!pending.length) return;
	const active = pending.filter((item) => {
		if (!item.signal?.aborted) return true;
		item.reject(abortReason(item.signal));
		return false;
	});
	if (!active.length) return;
	queue.active = (queue.active ?? 0) + 1;
	try {
		if (active.length === 1) {
			try {
				const result = await invokeExact({
					endpoint: queue.endpoint,
					...active[0].operation,
					fetch: queue.fetch,
					headers: queue.headers,
					logger: queue.logger,
					stream: queue.stream,
					streamLimits: queue.streamLimits,
					signal: active[0].signal,
					onResponse: active[0].onResponse
				});
				if (active[0].signal?.aborted) active[0].reject(abortReason(active[0].signal));
				else active[0].resolve(result);
			} catch (error) {
				active[0].reject(error);
			}
			return;
		}
		const combined = abortWhenAllAbort(active.map((item) => item.signal));
		try {
			const results = await invokeExactBatch({
				endpoint: queue.endpoint,
				operations: active.map((item) => item.operation),
				fetch: queue.fetch,
				headers: queue.headers,
				logger: queue.logger,
				stream: queue.stream,
				streamLimits: queue.streamLimits,
				signal: combined.signal,
				onResponse: (response) => {
					for (const item of active) item.onResponse?.(response);
				}
			});
			active.forEach((item, index) => {
				if (item.signal?.aborted) {
					item.reject(abortReason(item.signal));
					return;
				}
				const result = results[index];
				if (!result) {
					item.reject(/* @__PURE__ */ new Error(`eXact ${item.operation.type} invocation failed`));
					return;
				}
				if (!result.ok) {
					logFrameworkEvent("warn", "hydrate", "request", `exact ${item.operation.type} invocation failed with ${result.status}`, void 0, queue.logger);
					item.reject(/* @__PURE__ */ new Error(`eXact ${item.operation.type} invocation failed`));
					return;
				}
				const { ok: _ok, type: _type, id: _id, ...body } = result;
				item.resolve(body);
			});
		} catch (error) {
			for (const item of active) item.reject(error);
		} finally {
			combined.dispose();
		}
	} finally {
		queue.active = Math.max(0, (queue.active ?? 1) - 1);
	}
}
function reclaimQueue(queue) {
	if (queue.scheduled || queue.pending.length || queue.active) return;
	const index = batchQueues.indexOf(queue);
	if (index >= 0) batchQueues.splice(index, 1);
}
function abortWhenAllAbort(signals) {
	const defined = signals.filter((signal) => signal !== void 0);
	if (!defined.length) return {
		signal: void 0,
		dispose() {}
	};
	const controller = new AbortController();
	const abort = () => {
		if (defined.every((signal) => signal.aborted)) controller.abort(defined.find((signal) => signal.reason !== void 0)?.reason);
	};
	for (const signal of defined) signal.addEventListener("abort", abort);
	abort();
	return {
		signal: controller.signal,
		dispose() {
			for (const signal of defined) signal.removeEventListener("abort", abort);
		}
	};
}
function abortReason(signal) {
	return signal.reason ?? new DOMException("eXact request aborted", "AbortError");
}
//#endregion
//#region packages/hydrate/dist/state.js
/** Returns only the client state paths required by an eXact server invocation contract. */
function stateForContract(state, contract) {
	if (!contract) return state;
	const reads = contract.reads?.filter((read) => read.kind === "read" && read.confidence === "exact") ?? [];
	if (!reads.length) return void 0;
	if (reads.some((read) => read.path === "*")) return state;
	const output = {};
	for (const read of reads) {
		const value = getPath(state, read.path);
		if (value !== void 0) setPath(output, read.path, value);
	}
	return Object.keys(output).length ? output : void 0;
}
/**
* Validates and merges the partial state returned by a continuation.
*
* The returned object may contain only exact compiler-declared write paths.
* Parent writes replace their complete subtree; unrelated client state is
* retained. A wildcard write deliberately authorizes full replacement.
*/
function mergeStateForContract(state, update, contract) {
	const writes = contract.writes?.filter((write) => write.kind === "write" && write.confidence === "exact") ?? [];
	if (writes.some((write) => write.path === "*")) return hasOnlySafeProtocolKeys(update) ? {
		ok: true,
		state: update
	} : { ok: false };
	if (!update || typeof update !== "object" || Array.isArray(update)) return { ok: false };
	const paths = writes.map((write) => write.path);
	if (!stateNodeMatchesWrites(update, "", paths)) return { ok: false };
	let output = cloneContainer(state);
	for (const path of paths) {
		const value = getPath(update, path);
		if (value === void 0) continue;
		if (!output) output = {};
		setPath(output, path, value);
	}
	return {
		ok: true,
		state: output ?? state
	};
}
/** Commits validated continuation writes into a live reactive component state object. */
function commitStateForContract(target, update, contract) {
	const writes = contract.writes?.filter((write) => write.kind === "write" && write.confidence === "exact") ?? [];
	if (writes.some((write) => write.path === "*")) {
		if (!update || typeof update !== "object" || Array.isArray(update)) return;
		if (!hasOnlySafeProtocolKeys(update)) return;
		for (const key of Object.keys(target)) if (!Object.prototype.hasOwnProperty.call(update, key)) delete target[key];
		for (const key of Object.keys(update)) target[key] = update[key];
		return;
	}
	for (const write of writes) {
		const value = getPath(update, write.path);
		if (value !== void 0) setPath(target, write.path, value);
	}
}
/** Validates and immutably applies ordered Map and Set continuation deltas. */
function mergeCollectionMutationsForContract(state, mutations, contract) {
	const allowed = collectionWritePaths(contract);
	const output = cloneContainer(state);
	if (!output) return { ok: false };
	const cloned = /* @__PURE__ */ new Set();
	for (const mutation of mutations) {
		const expected = mutation.operation.startsWith("map-") ? "map" : "set";
		if (allowed.get(mutation.path) !== expected) return { ok: false };
		if (!cloned.has(mutation.path)) {
			if (!cloneCollectionAtPath(output, mutation.path, expected)) return { ok: false };
			cloned.add(mutation.path);
		}
		if (!applyCollectionMutation(getPath(output, mutation.path), mutation)) return { ok: false };
	}
	return {
		ok: true,
		state: output
	};
}
/** Applies already-validated ordered collection deltas to live reactive state. */
function commitCollectionMutationsForContract(target, mutations, contract) {
	const allowed = collectionWritePaths(contract);
	for (const mutation of mutations) {
		const expected = mutation.operation.startsWith("map-") ? "map" : "set";
		if (allowed.get(mutation.path) !== expected) return false;
		if (!applyCollectionMutation(getPath(target, mutation.path), mutation)) return false;
	}
	return true;
}
function collectionWritePaths(contract) {
	return new Map((contract.writes ?? []).filter((write) => write.kind === "write" && write.confidence === "exact" && (write.operation === "map" || write.operation === "set")).map((write) => [write.path, write.operation]));
}
function cloneCollectionAtPath(root, path, kind) {
	const segments = path.split(".");
	let source = root;
	let target = root;
	for (let index = 0; index < segments.length; index++) {
		const segment = segments[index];
		if (!isSafeProtocolKey(segment) && !isArrayIndex(segment)) return false;
		const next = readContainerValue(source, segment);
		if (index === segments.length - 1) {
			if (kind === "map" && next instanceof Map) {
				writeContainerValue(target, segment, new Map(next));
				return true;
			}
			if (kind === "set" && next instanceof Set) {
				writeContainerValue(target, segment, new Set(next));
				return true;
			}
			return false;
		}
		const clone = cloneContainer(next);
		if (!clone) return false;
		writeContainerValue(target, segment, clone);
		source = next;
		target = clone;
	}
	return false;
}
function applyCollectionMutation(value, mutation) {
	switch (mutation.operation) {
		case "map-set":
			if (!(value instanceof Map)) return false;
			value.set(mutation.key, mutation.value);
			return true;
		case "map-delete":
			if (!(value instanceof Map)) return false;
			value.delete(mutation.key);
			return true;
		case "map-clear":
			if (!(value instanceof Map)) return false;
			value.clear();
			return true;
		case "set-add":
			if (!(value instanceof Set)) return false;
			value.add(mutation.value);
			return true;
		case "set-delete":
			if (!(value instanceof Set)) return false;
			value.delete(mutation.value);
			return true;
		case "set-clear":
			if (!(value instanceof Set)) return false;
			value.clear();
			return true;
	}
}
function getPath(value, path) {
	if (path === "*") return value;
	let cursor = value;
	for (const segment of path.split(".")) {
		if (Array.isArray(cursor)) {
			if (!isArrayIndex(segment) || !Object.prototype.hasOwnProperty.call(cursor, segment)) return void 0;
			cursor = cursor[Number(segment)];
			continue;
		}
		if (!cursor || typeof cursor !== "object") return void 0;
		if (!isSafeProtocolKey(segment) || !Object.prototype.hasOwnProperty.call(cursor, segment)) return void 0;
		cursor = cursor[segment];
	}
	return cursor;
}
function setPath(target, path, value) {
	if (path === "*") return;
	const segments = path.split(".");
	if (!segments.every((segment) => isSafeProtocolKey(segment) || isArrayIndex(segment))) return;
	let cursor = target;
	for (let index = 0; index < segments.length - 1; index++) {
		const segment = segments[index];
		const nextSegment = segments[index + 1];
		if (Array.isArray(cursor) && !isArrayIndex(segment)) return;
		const next = readContainerValue(cursor, segment);
		if (!isMutableStateContainer(next)) {
			const nextContainer = isArrayIndex(nextSegment) ? [] : {};
			writeContainerValue(cursor, segment, nextContainer);
			cursor = nextContainer;
		} else {
			const nextContainer = Array.isArray(next) ? [...next] : { ...next };
			writeContainerValue(cursor, segment, nextContainer);
			cursor = nextContainer;
		}
	}
	const last = segments[segments.length - 1];
	if (Array.isArray(cursor) && !isArrayIndex(last)) return;
	writeContainerValue(cursor, last, value);
}
/** Validates a partial state response against exact writable paths. */
function stateNodeMatchesWrites(value, path, writes) {
	for (const key of Object.keys(value)) {
		if (!isSafeProtocolKey(key)) return false;
		if (Array.isArray(value) && !isArrayIndex(key)) return false;
		const childPath = path ? `${path}.${key}` : key;
		if (writes.includes(childPath)) continue;
		if (!writes.some((write) => write.startsWith(`${childPath}.`))) return false;
		const child = value[key];
		if (!child || typeof child !== "object") return false;
		if (!stateNodeMatchesWrites(child, childPath, writes)) return false;
	}
	return true;
}
/** Clones the root container so state commits do not mutate a prior snapshot. */
function cloneContainer(value) {
	if (Array.isArray(value)) return [...value];
	if (value && typeof value === "object") return { ...value };
}
function readContainerValue(container, segment) {
	return Array.isArray(container) ? container[Number(segment)] : container[segment];
}
function writeContainerValue(container, segment, value) {
	if (Array.isArray(container)) container[Number(segment)] = value;
	else container[segment] = value;
}
function isMutableStateContainer(value) {
	return Boolean(value && typeof value === "object");
}
function isArrayIndex(segment) {
	return /^(0|[1-9]\d*)$/.test(segment);
}
//#endregion
//#region packages/hydrate/dist/runtime/operations.js
/** Runs and apply with the supplied execution context. */
async function invokeAndApply(container, client, type, id, payload, options, component) {
	const work = createDomWorkBudget(options.maxTreeNodes);
	const continuation = type === "invoke" ? options.continuations?.[id] : void 0;
	if (type === "invoke" && !continuation) throw new Error(`No eXact client continuation contract is registered for ${id}`);
	let versions = requestVersions.get(container);
	if (!versions) {
		versions = /* @__PURE__ */ new Map();
		requestVersions.set(container, versions);
	}
	const configuredBoundaries = continuation?.boundaries;
	const componentKey = component ? componentIdentity(component.instance) : void 0;
	const requestKeys = [...new Set(type === "refresh" ? [`boundary:${id}`] : configuredBoundaries?.length ? configuredBoundaries.map((boundary) => `boundary:${boundary}`) : [`invocation:${id}`])].map((key) => componentKey ? `${componentKey}:${key}` : key);
	const requestVersion = Math.max(0, ...requestKeys.map((key) => versions.get(key) ?? 0)) + 1;
	for (const key of requestKeys) versions.set(key, requestVersion);
	const requestOrdinalKey = componentKey ? `${componentKey}:request` : "request";
	const stateCommittedKey = componentKey ? `${componentKey}:state-committed` : "state-committed";
	const requestOrdinal = (versions.get(requestOrdinalKey) ?? 0) + 1;
	versions.set(requestOrdinalKey, requestOrdinal);
	const refreshPartition = type === "refresh" ? partitionAuthority(container, id, work, options.executionRoot ?? "page") : void 0;
	const operation = {
		type,
		root: options.executionRoot ?? "page",
		id: refreshPartition?.planEdgeId ?? id,
		...refreshPartition ? { partition: refreshPartition } : {},
		payload: component ? {
			dependencies: component.dependencies,
			...component.generation === void 0 ? {} : { generation: component.generation }
		} : payload,
		state: type === "invoke" ? stateForContract(component?.instance.state ?? client.state, { reads: continuation.stateReads }) : client.state,
		publicContext: type === "invoke" ? publicContextFor(options.publicContexts, continuation?.publicContexts) : void 0,
		boundaryHtml: type === "refresh" ? boundaryInnerHtml(container, id, work, options.executionRoot ?? "page") : void 0,
		boundaryHtmls: type === "invoke" ? boundaryHtmlsFor(container, configuredBoundaries, work, options.executionRoot ?? "page") : void 0
	};
	if (component) componentDomainInspection(component.instance.domain)?.publish({
		kind: "continuation.dispatch",
		component: component.instance,
		operationId: id,
		generation: component.generation
	});
	const endpoint = requireEndpoint(endpointForOperation(client, type, refreshPartition?.planEdgeId ?? id));
	const transport = transportForEndpoint(options, endpoint);
	let result;
	try {
		result = options.batch === false ? await invokeExact({
			endpoint,
			...operation,
			fetch: transport.fetch,
			headers: transport.headers,
			logger: options.logger,
			stream: options.stream,
			streamLimits: options.streamLimits,
			signal: component?.signal ?? options.signal,
			onResponse: options.onResponse
		}) : await enqueueExactOperation(container, {
			endpoint,
			operation,
			fetch: transport.fetch,
			headers: transport.headers,
			logger: options.logger,
			stream: options.stream,
			streamLimits: options.streamLimits,
			signal: component?.signal ?? options.signal,
			onResponse: options.onResponse
		});
	} catch (error) {
		if (error instanceof ExactBuildUnsupportedError) options.onBuildUnsupported?.();
		throw error;
	}
	let responseHasState = false;
	let responseState;
	if (continuation) {
		responseHasState = "state" in result;
		responseState = result.state;
		const invalidPatch = unauthorizedContinuationPatch(container, result.patches, continuation.boundaries, work);
		let mergedState = "state" in result ? mergeStateForContract(client.state, result.state, { writes: continuation.stateWrites }) : void 0;
		if (result.mutations) {
			const mergedCollections = mergeCollectionMutationsForContract(mergedState?.ok ? mergedState.state : client.state, result.mutations, { writes: continuation.stateWrites });
			if (mergedCollections.ok) mergedState = mergedCollections;
			else mergedState = { ok: false };
		}
		const invalidContexts = unauthorizedContinuationContexts(result.contexts, continuation.contextWrites, component?.contextWrites);
		if (invalidPatch || mergedState?.ok === false || invalidContexts) {
			options.onDiagnostic?.({
				code: "invalid-response",
				message: `rejected exact invocation response outside the continuation contract for ${id}`,
				patch: invalidPatch
			});
			options.onOperation?.({
				operation,
				result,
				appliedPatches: [],
				patchesApplied: false,
				stale: false
			});
			return result;
		}
		if (mergedState?.ok) result = {
			...result,
			state: mergedState.state
		};
	}
	const staleKeys = new Set(requestKeys.filter((key) => versions.get(key) !== requestVersion));
	if (staleKeys.size === requestKeys.length) {
		options.onDiagnostic?.({
			code: "stale-response",
			message: `ignored stale exact ${type} response for ${id}`,
			patch: {
				type,
				id
			}
		});
		options.onOperation?.({
			operation,
			result,
			appliedPatches: [],
			patchesApplied: false,
			stale: true
		});
		return result;
	}
	let responsePatches = refreshPartition && result.patches ? result.patches.map((patch) => patch.id === refreshPartition.planEdgeId ? {
		...patch,
		id
	} : patch) : result.patches;
	const partiallyStale = staleKeys.size > 0;
	if (partiallyStale && configuredBoundaries && responsePatches) {
		const rejected = [];
		const boundaryForPatch = createPatchBoundaryResolver(container, configuredBoundaries, work);
		responsePatches = responsePatches.filter((patch) => {
			const owner = boundaryForPatch(patch.id);
			const accepted = owner !== void 0 && !staleKeys.has(`boundary:${owner}`);
			if (!accepted) rejected.push(`${patch.type}:${patch.id}`);
			return accepted;
		});
		options.onDiagnostic?.({
			code: "stale-response",
			message: `partially ignored stale exact ${type} response for ${id}` + (rejected.length ? ` (${rejected.join(", ")})` : ""),
			patch: {
				type,
				id
			}
		});
	}
	const patchOptions = {
		...options,
		workBudget: work
	};
	const applyResponse = () => {
		let appliedPatches = responsePatches ?? [];
		let patchesApplied = responsePatches ? applyPatches(container, responsePatches, patchOptions) : true;
		if (!patchesApplied && type === "refresh" && result.html) {
			appliedPatches = [{
				type: "replace",
				id,
				html: result.html
			}];
			patchesApplied = applyPatches(container, appliedPatches, patchOptions);
		}
		if (!patchesApplied) {
			options.onDiagnostic?.({
				code: "invalid-patch",
				message: `rejected exact ${type} response for ${id}; DOM and state were left unchanged`,
				patch: {
					type,
					id
				}
			});
			options.onOperation?.({
				operation,
				result,
				appliedPatches,
				patchesApplied: false,
				stale: partiallyStale
			});
			return;
		}
		if (responsePatches?.length && options.islands) hydrateClientIslands(container, options.islands, options);
		if (!partiallyStale && "state" in result && requestOrdinal >= (versions.get(stateCommittedKey) ?? 0)) {
			versions.set(stateCommittedKey, requestOrdinal);
			if (component) {
				if (responseHasState) commitStateForContract(component.instance.state, responseState, { writes: continuation.stateWrites });
				if (result.mutations) commitCollectionMutationsForContract(component.instance.state, result.mutations, { writes: continuation.stateWrites });
			} else client.state = result.state;
		}
		if (!partiallyStale && component && result.contexts) {
			const tokens = new Map(component.contextWrites.map((write) => [write.name, write.token]));
			for (const [name, value] of Object.entries(result.contexts)) component.instance.setContext(tokens.get(name), value);
		}
		if (component) {
			if (appliedPatches.length) componentDomainInspection(component.instance.domain)?.publish({
				kind: "patch.apply",
				component: component.instance,
				operationId: id,
				generation: component.generation,
				attributes: Object.freeze({ count: appliedPatches.length })
			});
			componentDomainInspection(component.instance.domain)?.publish({
				kind: "continuation.apply",
				component: component.instance,
				operationId: id,
				generation: component.generation,
				attributes: Object.freeze({ stale: partiallyStale })
			});
		}
		options.onOperation?.({
			operation,
			result,
			appliedPatches,
			patchesApplied: true,
			stale: partiallyStale
		});
	};
	if (component && continuation?.readiness === "blocking") stageTaskMutation(component.signal, applyResponse);
	else applyResponse();
	return result;
}
/** Rejects undeclared or unmapped component-context projections before client mutation. */
function unauthorizedContinuationContexts(contexts, allowed, mappings) {
	if (!contexts) return false;
	const allowedNames = new Set(allowed);
	const mappedNames = new Set((mappings ?? []).map((mapping) => mapping.name));
	return Object.keys(contexts).some((name) => !allowedNames.has(name) || !mappedNames.has(name));
}
var componentIds = /* @__PURE__ */ new WeakMap();
var nextComponentId = 1;
/** Returns one request-generation namespace for a live component instance. */
function componentIdentity(instance) {
	let id = componentIds.get(instance);
	if (!id) {
		id = nextComponentId++;
		componentIds.set(instance, id);
	}
	return `component:${id}`;
}
/** Returns the first patch outside every compiler-declared affected boundary. */
function unauthorizedContinuationPatch(container, patches, boundaries, work) {
	if (!patches?.length) return void 0;
	if (!boundaries.length) return patches[0];
	const boundaryForPatch = createPatchBoundaryResolver(container, boundaries, work);
	return patches.find((patch) => boundaryForPatch(patch.id) === void 0);
}
/** Selects only compiler-approved shared context projections for one activation record. */
function publicContextFor(values, tokens) {
	if (!tokens?.length) return void 0;
	const output = {};
	for (const token of tokens) {
		if (!values || !Object.prototype.hasOwnProperty.call(values, token)) throw new Error(`Missing eXact public context projection ${token}`);
		output[token] = values[token];
	}
	return output;
}
/** Validates endpoint and throws when the contract is violated. */
function requireEndpoint(endpoint) {
	if (!endpoint) throw new Error("eXact endpoint is not configured");
	return endpoint;
}
/** Performs the endpoint for operation domain operation. */
function endpointForOperation(client, type, id) {
	if (type === "invoke") return client.endpoints?.invocations?.[id] ?? client.endpoint;
	return client.endpoints?.boundaries?.[id] ?? client.endpoint;
}
/** Performs the transport for endpoint domain operation. */
function transportForEndpoint(options, endpoint) {
	const transport = options.transports?.[endpoint];
	return {
		fetch: transport?.fetch ?? options.fetch,
		headers: {
			...options.headers ?? {},
			...transport?.headers ?? {},
			...options.binding ? { "X-Exact-Binding": options.binding } : {},
			...options.buildKey ? { "X-Exact-Build": options.buildKey } : {}
		}
	};
}
/** Performs the boundary htmls for domain operation. */
function boundaryHtmlsFor(container, ids, work, executionRoot) {
	if (!ids?.length) return void 0;
	const htmls = boundaryInnerHtmls(container, ids, work, executionRoot);
	return Object.keys(htmls).length ? htmls : void 0;
}
//#endregion
//#region packages/hydrate/dist/runtime/client.js
var requestClients = /* @__PURE__ */ new WeakMap();
var requestDomains = /* @__PURE__ */ new WeakMap();
var activeRequestClients = /* @__PURE__ */ new WeakSet();
/**
* Associates one immutable component-domain generation with the request client
* selected by its hidden framework root.
* @internal
*/
function bindRequestClientDomain(domain, client) {
	if (!activeRequestClients.has(client)) throw new Error("Cannot bind a component root to an inactive eXact client");
	const previous = requestClients.get(domain);
	if (previous && previous !== client) requestDomains.get(previous)?.delete(domain);
	requestClients.set(domain, client);
	let domains = requestDomains.get(client);
	if (!domains) {
		domains = /* @__PURE__ */ new Set();
		requestDomains.set(client, domains);
	}
	domains.add(domain);
}
/** Creates a client from options already validated for this container by the hydration entry point. */
function createExactClientFromResolvedOptions(container, resolvedOptions) {
	const lifetime = new AbortController();
	const abortLifetime = () => lifetime.abort(resolvedOptions.signal?.reason);
	if (resolvedOptions.signal?.aborted) abortLifetime();
	else resolvedOptions.signal?.addEventListener("abort", abortLifetime, { once: true });
	const runtimeOptions = {
		...resolvedOptions,
		endpoints: cloneEndpointRoutes(resolvedOptions.endpoints),
		continuations: { ...resolvedOptions.continuations ?? {} },
		resumptions: [...resolvedOptions.resumptions ?? []],
		publicContexts: { ...resolvedOptions.publicContexts ?? {} },
		islands: { ...resolvedOptions.islands ?? {} },
		transports: { ...resolvedOptions.transports ?? {} },
		signal: lifetime.signal
	};
	let disposed = false;
	let retired = false;
	let pendingRequests = 0;
	const settlementWaiters = /* @__PURE__ */ new Set();
	const assertActive = () => {
		if (disposed) throw new Error("eXact hydration root has been disposed");
		if (retired) throw new Error("eXact hydration root has been retired");
	};
	const run = async (operation) => {
		assertActive();
		pendingRequests++;
		try {
			return await operation();
		} finally {
			pendingRequests--;
			if (!pendingRequests) {
				for (const settle of settlementWaiters) settle();
				settlementWaiters.clear();
			}
		}
	};
	let domain;
	const client = {
		get domain() {
			return domain;
		},
		get endpoint() {
			return runtimeOptions.endpoint;
		},
		get endpoints() {
			return runtimeOptions.endpoints;
		},
		get state() {
			return runtimeOptions.state;
		},
		set state(value) {
			runtimeOptions.state = value;
		},
		get continuations() {
			return runtimeOptions.continuations;
		},
		get pendingRequests() {
			return pendingRequests;
		},
		applyPatches(patches) {
			assertActive();
			return applyPatches(container, patches, runtimeOptions);
		},
		invokeTask(id, payload) {
			return run(() => invokeAndApply(container, client, "invoke", id, payload, runtimeOptions));
		},
		refreshBoundary(id, payload) {
			return run(() => invokeAndApply(container, client, "refresh", id, payload, runtimeOptions));
		},
		async refreshIsland(id, registry, payload) {
			assertActive();
			mergeClientIslands(runtimeOptions, registry);
			return run(() => invokeAndApply(container, client, "refresh", id, payload, runtimeOptions));
		},
		registerComponents(config) {
			assertActive();
			mergeHydrationRegistration(runtimeOptions, config);
			if (config.islands) hydrateClientIslands(container, runtimeOptions.islands ?? {}, runtimeOptions);
		},
		retire() {
			if (!disposed) retired = true;
		},
		whenSettled() {
			if (!pendingRequests) return Promise.resolve();
			return new Promise((resolve) => settlementWaiters.add(resolve));
		},
		dispose() {
			if (disposed) return;
			disposed = true;
			retired = true;
			resolvedOptions.signal?.removeEventListener("abort", abortLifetime);
			lifetime.abort(new DOMException("eXact hydration root disposed", "AbortError"));
			disposeInteractionHydration(container);
			roots.delete(container);
			container.removeAttribute("data-exact-hydrated");
			requestVersions.get(container)?.clear();
			activeRequestClients.delete(client);
			for (const ownedDomain of requestDomains.get(client) ?? []) requestClients.delete(ownedDomain);
			requestDomains.delete(client);
			disposeOwnedSubtree(container, false);
			unmount(container);
		}
	};
	const resumptionResolver = createComponentResumptionResolver(() => runtimeOptions.resumptions);
	const inspection = runtimeOptions.inspection ?? exactDomInspectionOwner({
		buildKey: runtimeOptions.buildKey,
		executionRoot: runtimeOptions.executionRoot,
		binding: runtimeOptions.binding
	});
	domain = createFrameworkComponentDomain({
		executionRoot: runtimeOptions.executionRoot ?? "page",
		logger: runtimeOptions.logger,
		dispatchContinuation: (request) => run(() => invokeAndApply(container, client, "invoke", request.id, void 0, runtimeOptions, {
			instance: request.instance,
			dependencies: request.dependencies,
			contextWrites: request.contextWrites,
			signal: request.signal,
			generation: request.generation
		})).then((result) => result.value),
		resumeComponent: resumptionResolver,
		inspection,
		inspectionActivation: "hydration",
		...runtimeOptions.wallClockSnapshot === void 0 ? {} : { wallClockSnapshot: runtimeOptions.wallClockSnapshot }
	});
	runtimeOptions.componentDomain = domain;
	const existing = roots.get(container);
	if (existing && existing !== client) throw new Error("An eXact client root is already registered for this container");
	activeRequestClients.add(client);
	bindRequestClientDomain(domain, client);
	roots.set(container, client);
	if (runtimeOptions.islands) hydrateClientIslands(container, runtimeOptions.islands, runtimeOptions);
	return client;
}
//#endregion
//#region packages/hydrate/dist/runtime/hydration.js
/** Hydrates a server-rendered container and returns ownership of its client root. */
function hydrateWithClient(operation, container, options, createClient, resolveOptions) {
	const started = options.onProfile ? performance.now() : void 0;
	try {
		return hydrateRootWithClient(operation, container, options, createClient, resolveOptions);
	} finally {
		if (started !== void 0) publishExactProfile(options.onProfile, Object.freeze({
			subsystem: "hydrate",
			phase: "hydrate",
			elapsedMs: performance.now() - started
		}));
	}
}
/** Adopts the root DOM range, reporting mismatches before applying client mutations. */
function hydrateRootWithClient(operation, container, options, createClient, resolveOptions) {
	assertCurrentDocumentContainer(container);
	const documentNode = container.nodeType === 9 ? container : void 0;
	const rootContainer = documentNode?.documentElement ?? container;
	const existing = roots.get(rootContainer);
	if (existing) {
		renderCompiledComponentRoot(operation, rootContainer, {
			logger: options.logger,
			onErrorReport: options.onErrorReport,
			maxTreeDepth: options.maxTreeDepth,
			maxTreeNodes: options.maxTreeNodes,
			allowUnsafeHtml: options.allowUnsafeHtml,
			onUnsafeHtml: options.onUnsafeHtml,
			onProfile: options.onProfile,
			enhancementCatalog: options.enhancementCatalog,
			componentDomain: existing.domain
		});
		options.onHydration?.(Object.freeze({
			kind: "root",
			outcome: "updated",
			markers: "none"
		}));
		return existing;
	}
	const resolvedOptions = resolveOptions(rootContainer, options);
	const root = createClient(rootContainer, resolvedOptions);
	const work = createDomWorkBudget(resolvedOptions.maxTreeNodes);
	const captured = captureHydrationDom(rootContainer, work);
	const formState = captured.formState;
	try {
		const outcome = adoptOrMountRoot(operation, rootContainer, documentNode, captured.hasMarkers, resolvedOptions, work, root.domain);
		for (const control of restoreFormState(rootContainer, formState, work)) synchronizeFormBinding(control);
		releaseProgressiveHelper(rootContainer);
		rootContainer.setAttribute("data-exact-hydrated", "true");
		resolvedOptions.onHydration?.(Object.freeze({
			kind: "root",
			outcome,
			markers: documentNode ? "document" : resolvedOptions.markerlessRoot ? "markerless" : captured.hasMarkers ? "exact" : resolvedOptions.allowMarkerless ? "markerless" : "none"
		}));
		return root;
	} catch (error) {
		root.dispose();
		throw error;
	}
}
/** Returns the unconsumed portion of a shared hydration traversal budget. */
function remainingDomWork(work) {
	const remaining = work.limit - work.used;
	if (remaining <= 0) consumeDomWork(work);
	return remaining;
}
function releaseProgressiveHelper(root) {
	let hash = 2166136261;
	const rootId = root.id || "exact-root";
	for (let index = 0; index < rootId.length; index++) {
		hash ^= rootId.charCodeAt(index);
		hash = Math.imul(hash, 16777619);
	}
	delete globalThis[`__xR${(hash >>> 0).toString(36)}`];
}
/** Adopts compatible SSR output or mounts a fresh non-document tree after reporting the mismatch. */
function adoptOrMountRoot(operation, container, documentNode, hasMarkers, options, work, domain) {
	const componentReceipt = readCompiledComponentReceipt(operation);
	if (!componentReceipt) throw new TypeError("Native hydration requires a compiler-issued component operation");
	if (documentNode) {
		const checkpoint = checkpointComponentResumptions(domain);
		if (adoptDocumentCompiledComponentReceiptRoot(operation, componentReceipt, documentNode, rendererOptions(options, work, domain))) return "adopted";
		rollbackComponentResumptions(domain, checkpoint);
		reportMismatch(options, "server document did not match the authored client document", "adoption-mismatch");
		throw new Error("eXact cannot safely replace a mismatched Document root; reload the document or correct the authored root.");
	}
	if (!hasMarkers || options.markerlessRoot) {
		const checkpoint = checkpointComponentResumptions(domain);
		if (options.allowMarkerless ? adoptMarkerlessCompiledComponentReceiptRoot(operation, componentReceipt, container, rendererOptions(options, work, domain)) : false) return "adopted";
		rollbackComponentResumptions(domain, checkpoint);
		reportMismatch(options, options.allowMarkerless ? "server markup did not match the client tree" : "missing exact hydration markers", options.allowMarkerless ? "adoption-mismatch" : "missing-markers");
		mountFreshRoot(operation, container, options, work, domain);
		return "mounted";
	}
	const checkpoint = checkpointComponentResumptions(domain);
	if (adoptCompiledComponentReceiptRoot(operation, componentReceipt, container, rendererOptions(options, work, domain))) return "adopted";
	rollbackComponentResumptions(domain, checkpoint);
	mountFreshRoot(operation, container, options, work, domain);
	return "mounted";
}
/** Clears an unowned SSR range and mounts the client-owned replacement. */
function mountFreshRoot(operation, container, options, work, domain) {
	container.replaceChildren();
	renderCompiledComponentRoot(operation, container, rendererOptions(options, work, domain));
}
/** Creates renderer options against the one shared hydration traversal budget. */
function rendererOptions(options, work, domain) {
	return {
		logger: options.logger,
		onErrorReport: options.onErrorReport,
		maxTreeDepth: options.maxTreeDepth,
		maxTreeNodes: remainingDomWork(work),
		workBudget: work,
		allowUnsafeHtml: options.allowUnsafeHtml,
		onUnsafeHtml: options.onUnsafeHtml,
		onProfile: options.onProfile,
		enhancementCatalog: options.enhancementCatalog,
		componentDomain: domain
	};
}
//#endregion
//#region packages/hydrate/dist/runtime/full-hydration.js
/** Hydrates with the complete request, patch, island, and registration client capabilities. */
function hydrate(operation, container, options = {}) {
	return hydrateWithClient(operation, container, options, createExactClientFromResolvedOptions, resolveHydrateOptions);
}
//#endregion
//#region packages/core/dist/client/component/list-controller.js
/** Owns keyed-list registrations and compiler-operation caches retained by one component instance. */
function createComponentListController(ownerScope) {
	const caches = /* @__PURE__ */ new Map();
	const registrations = /* @__PURE__ */ new Map();
	const activeSlots = /* @__PURE__ */ new Set();
	const directSlots = /* @__PURE__ */ new Set();
	const scopePrefixes = /* @__PURE__ */ new WeakMap();
	let mapCallIndex = 0;
	let itemScopeGeneration = 0;
	const scopedSlot = (slot) => {
		const prefix = currentScopePrefix();
		return prefix === void 0 ? slot : `${prefix}${encodeSlot(slot)}`;
	};
	const currentScopePrefix = () => {
		for (let scope = currentEffectScope(); scope; scope = effectScopeParent(scope)) {
			const prefix = scopePrefixes.get(scope);
			if (prefix !== void 0) return prefix;
		}
	};
	const releaseNestedSlots = (prefix) => {
		for (const [slot, registration] of registrations) {
			if (!slot.startsWith(prefix)) continue;
			registration.stop();
			registrations.delete(slot);
			caches.delete(slot);
			directSlots.delete(slot);
			activeSlots.delete(slot);
		}
	};
	return {
		beginRender() {
			mapCallIndex = 0;
			activeSlots.clear();
		},
		endRender() {
			for (const [slot, registration] of registrations) {
				if (activeSlots.has(slot) || directSlots.has(slot)) continue;
				registration.stop();
				registrations.delete(slot);
				caches.delete(slot);
			}
		},
		dispose() {
			for (const registration of registrations.values()) registration.stop();
			registrations.clear();
			caches.clear();
			directSlots.clear();
		},
		map(collection, key, render, id, provenance, keyIdentity, direct = false) {
			const source = peek(() => collectionRef(collection));
			const current = isReactiveValue(collection) && source ? peek(() => source.get()) : collection;
			const authoredId = id ?? `map:${mapCallIndex++}`;
			const cacheId = scopedSlot(authoredId);
			activeSlots.add(cacheId);
			if (direct) directSlots.add(cacheId);
			const registrationCollection = unwrap(provenance ?? current);
			const registrationIdentity = keyIdentity ?? Function.prototype.toString.call(key);
			const registered = registrations.get(cacheId);
			if (!registered || registered.collection !== registrationCollection || registered.identity !== registrationIdentity) {
				registered?.stop();
				const stop = registerReactiveListKey(provenance ?? current, key, id ?? "an unlabelled this.map() call", keyIdentity);
				registrations.set(cacheId, {
					collection: registrationCollection,
					identity: registrationIdentity,
					stop
				});
			}
			const previous = caches.get(cacheId);
			const activeCache = (id !== void 0 || previous?.render === render ? previous?.cache : void 0) ?? /* @__PURE__ */ new Map();
			if (!previous || previous.render !== render) caches.set(cacheId, {
				render,
				cache: activeCache
			});
			const materialize = () => {
				const values = source ? source.get() : isReactiveValue(collection) ? collection.get() : collection;
				const activeKeys = /* @__PURE__ */ new Set();
				const result = [];
				for (const item of values) {
					const itemKey = String(key(item));
					if (activeKeys.has(itemKey)) throw new Error(`Duplicate key "${itemKey}" in ${id ?? "an unlabelled this.map() call"}`);
					activeKeys.add(itemKey);
					let cached = activeCache.get(itemKey);
					if (!cached || !Object.is(unwrap(cached.item), unwrap(item))) {
						const scope = createEffectScope(ownerScope);
						const itemScope = `${cacheId}${encodeSlot(itemKey)}${itemScopeGeneration++}:`;
						scopePrefixes.set(scope, itemScope);
						registerEffectScopeCleanup(scope, () => releaseNestedSlots(itemScope));
						let operation;
						try {
							operation = withEffectScope(scope, () => render(item));
						} catch (error) {
							scope.stop();
							throw error;
						}
						cached = {
							item,
							operation,
							keyed: createCompiledKeyedChildReceipt(operation, itemKey, scope),
							scope
						};
						activeCache.set(itemKey, cached);
						registerEffectScopeCleanup(scope, () => {
							if (activeCache.get(itemKey)?.scope === scope) activeCache.delete(itemKey);
						});
					}
					result.push(cached.keyed);
				}
				for (const cachedKey of activeCache.keys()) if (!activeKeys.has(cachedKey)) activeCache.delete(cachedKey);
				return result;
			};
			return direct ? materialize() : createCompiledChildRangeReceipt(materialize, id);
		}
	};
}
/** Encodes one authored list identity without allowing nested key collisions. */
function encodeSlot(value) {
	return `${value.length}:${value}/`;
}
//#endregion
//#region packages/core/dist/client/component/list-capability-integration.js
var controllers = /* @__PURE__ */ new WeakMap();
function controller(owner) {
	let value = controllers.get(owner);
	if (!value) {
		value = createComponentListController(owner.scope);
		controllers.set(owner, value);
	}
	return value;
}
registerComponentListCapability(Object.freeze({
	map(owner, collection, key, render, id, provenance, keyIdentity) {
		return controller(owner).map(collection, key, render, id, provenance, keyIdentity);
	},
	mapDirect(owner, collection, key, render, id, provenance, keyIdentity) {
		return controller(owner).map(collection, key, render, id, provenance, keyIdentity, true);
	},
	begin(owner) {
		controllers.get(owner)?.beginRender();
	},
	end(owner) {
		controllers.get(owner)?.endRender();
	},
	dispose(owner) {
		const value = controllers.get(owner);
		if (!value) return;
		controllers.delete(owner);
		value.dispose();
	}
}));
//#endregion
//#region packages/core/dist/client/component/runtime-surface-lists.js
function map(collection, key, render, id, provenance, keyIdentity) {
	return componentListCapability().map(this, collection, key, render, id, provenance, keyIdentity);
}
registerComponentRuntimeSurface({ map: {
	configurable: true,
	writable: true,
	value: map
} });
//#endregion
//#region packages/core/dist/client/runtime/lists.js
/** Evaluates one compiler-keyed render-program lane through its component-local range cache. */
function mapExactCompiledKeyedChildren(owner, collection, key, render, id, provenance, keyIdentity) {
	return componentListCapability().mapDirect(owner, collection, key, render, id, provenance, keyIdentity);
}
//#endregion
//#region packages/core/dist/client/component/durable-instance-construction.js
/** Constructs the durable record selected by a lifecycle, list, or task component artifact. */
var constructDurableComponentInstance = function(parent, rawProps, ambientContexts, domain, execution, contract) {
	return new ComponentInstanceImpl(this.instantiate, contract.artifact.instantiate, rawProps, parent, ambientContexts, domain, execution, contract);
};
//#endregion
//#region .tmp/joined-text-experiment/separate/fixture.tsx
var __exactComponentContract_1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
var __exact_component_updates_1 = {
	bindings: [[
		0,
		1,
		0
	], [
		1,
		2,
		0
	]],
	apply: (__exactTargets, __exactDirtyLow, __exactDirtyHigh) => {
		const __exactTarget0 = __exactTargets[0];
		if (__exactTarget0) {
			if ((__exactDirtyLow & 1) !== 0) applyCompiledProgramText(__exactTarget0, 0, 0, 0);
			if ((__exactDirtyLow & 2) !== 0) applyCompiledProgramText(__exactTarget0, 1, 0, 1);
		}
	}
};
var __exact_render_program_1 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 1,
	id: "xJLjHU3kTG4AzdkNEeAM6pL",
	namespace: "html",
	template: "<small><!---->exact:0<!----> · <!---->exact:1<!----></small>",
	wire: [
		[
			"small",
			"html",
			1,
			2
		],
		[[
			3,
			0,
			0,
			"0"
		], [
			3,
			1,
			1,
			"1"
		]],
		[
			[
				0,
				0,
				[0, 0],
				true
			],
			[
				0,
				1,
				[0, 1],
				true
			],
			[
				9,
				0,
				__exact_component_updates_1
			]
		]
	],
	directClaims: true
});
var __exact_render_program_2 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 1,
	id: "x9IYOkTPwdaGOrPATaY2qc8",
	namespace: "html",
	template: "<section></section>",
	wire: [
		[
			"section",
			"html",
			1,
			1
		],
		[[
			4,
			0,
			0
		]],
		[[3, 0]]
	],
	directClaims: true,
	keyedChildren: 1
});
var instances = [];
var __exactImplementation_Row_1 = function Row(props) {
	instances.push(this);
	writeIndexedReactiveValue(this.state, 0, "Assigned");
	writeIndexedReactiveValue(this.state, 1, "open");
	return () => createPreparedRenderProgram(__exact_render_program_1, [], this);
};
var Row = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Row_1, {
	[Symbol.for("@exactjs/component")]: "xi32if-lXtl3vdtVjnsoR9G",
	[__exactComponentContract_1]: { artifact: {
		version: 1,
		target: "client",
		id: "xi32if-lXtl3vdtVjnsoR9G",
		instantiate: __exactImplementation_Row_1,
		construct: constructRenderComponentInstance,
		abi: 1,
		capabilities: [],
		state: ["owner", "status"],
		props: [],
		attach: attachExactCompiledClientComponent,
		receive: receiveExactClientComponentProps,
		dispose: disposeExactClientComponent,
		updates: __exact_component_updates_1
	} }
}))();
var __exactImplementation_Rows_1 = function Rows(props) {
	return () => createPreparedRenderProgram(__exact_render_program_2, [() => mapExactCompiledKeyedChildren(this, readIndexedReactiveSlot(props, 0), (index) => index, (index) => createCompiledComponentReceipt(Row, { index: createExpression(() => index) }), "xGiNkRW9sx5ps42dJTOx8te", void 0, void 0)], this);
};
var Rows = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Rows_1, {
	[Symbol.for("@exactjs/component")]: "x9dHIt6IGkiXwwrX0-S0XNU",
	[__exactComponentContract_1]: { artifact: {
		version: 1,
		target: "client",
		id: "x9dHIt6IGkiXwwrX0-S0XNU",
		instantiate: __exactImplementation_Rows_1,
		construct: constructDurableComponentInstance,
		abi: 5,
		capabilities: [],
		state: [],
		props: ["rows"],
		serialization: [
			1,
			"rows",
			[2, 0]
		],
		attach: attachExactCompiledClientComponent,
		receive: receiveExactClientComponentProps,
		dispose: disposeExactClientComponent
	} }
}))();
function tree(rows) {
	instances.length = 0;
	return createCompiledComponentReceipt(Rows, { rows });
}
function update(value, both = false) {
	batch(() => {
		for (const instance of instances) {
			instance.state.status = value % 2 ? "closed" : "open";
			if (both) instance.state.owner = value % 2 ? "Unassigned" : "Assigned";
		}
	});
	flushSync();
}
function release() {
	instances.length = 0;
}
//#endregion
//#region .tmp/joined-text-experiment/separate/client.ts
var root;
function setup(count, html) {
	root?.dispose();
	release();
	const container = document.getElementById("root");
	container.innerHTML = html;
	const before = Array.from(container.querySelectorAll("small"));
	const rows = Array.from({ length: count }, (_, index) => index);
	const start = performance.now();
	root = hydrate(tree(rows), container);
	const elapsed = performance.now() - start;
	if (before.some((element, i) => container.querySelectorAll("small")[i] !== element)) throw Error("Replaced SSR elements");
	return elapsed;
}
function updates(iterations, both = false) {
	const start = performance.now();
	for (let i = 0; i < iterations; i++) update(i, both);
	return (performance.now() - start) / iterations;
}
function check() {
	update(1, true);
	const rows = Array.from(document.querySelectorAll("small"));
	if (rows.some((row) => row.textContent !== "Unassigned · closed")) throw Error("Combined update failed");
	update(0, false);
	if (rows.some((row) => row.textContent !== "Unassigned · open")) throw Error("Independent update failed");
	return rows.map((row) => ({
		text: row.textContent,
		nodes: row.childNodes.length
	}));
}
function dispose() {
	root?.dispose();
	root = void 0;
	release();
}
//#endregion
export { check, dispose, setup, updates };
