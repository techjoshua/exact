import {chromium} from '../../node_modules/@playwright/test/index.mjs';
import {readFile,writeFile} from 'node:fs/promises';
import {resolve,sep} from 'node:path';
import assert from 'node:assert/strict';
const documents=JSON.parse(await readFile('.tmp/joined-text-experiment/documents.json','utf8'));
const browser=await chromium.launch({headless:true});
const pages={},samples=[],errors=[];
const names=process.env.TEXT_VARIANTS?.split(',') ?? ['separate','joined'];
let splitCases;
try {
 for(const name of names) {
  const page=await browser.newPage();pages[name]=page;
  page.on('pageerror',error=>errors.push(String(error)));
  const root=resolve('.tmp/joined-text-experiment',name,'dist-client');
  await page.route('http://text.test/**',async route=>{
   const pathname=new URL(route.request().url()).pathname;
   if(pathname==='/')return route.fulfill({contentType:'text/html',body:'<div id="root"></div><script type="module">window.textBench=await import("/entry.js");</script>'});
   const path=resolve(root,'.'+pathname);assert(path.startsWith(root+sep));
   await route.fulfill({contentType:'text/javascript',body:await readFile(path)});
  });
  await page.goto('http://text.test/');await page.waitForFunction(()=>window.textBench);
 }
 if(pages.split) {
  splitCases=await pages.split.evaluate(()=>{
   const cases=[['','',''],['',' · ','open'],['Assigned',' · ',''],['A · B',' · ','C · D'],['<>&',' · ','"'],['😀',' · ','漢字'],['\u2028','','\u2029'],['0',' · ','0']];
   for(const parts of cases){
    const source=document.createElement('small');source.textContent=parts.join('');
    const container=document.createElement('div');container.innerHTML=source.outerHTML;
    const first=container.firstElementChild.firstChild;
    window.textBench.splitExperimentalTextRuns(container,parts);
    const nodes=[...container.firstElementChild.childNodes];
    if(nodes.length!==parts.length||nodes.some((n,i)=>!(n instanceof Text)||n.data!==parts[i]))throw Error('Bad split '+JSON.stringify(parts));
    if(first&&nodes[0]!==first)throw Error('Replaced original Text');
   }
   const bad=document.createElement('div');bad.innerHTML='<small>unexpected</small>';const original=bad.innerHTML;
   let rejected=false;try{window.textBench.splitExperimentalTextRuns(bad,['expected','','']);}catch{rejected=true;}
   if(!rejected||bad.innerHTML!==original)throw Error('Mismatch mutated DOM');
   return {valid:cases.length,mismatch:1};
  });
 }
 for(const count of [3,100,1000]) {
  for(const name of names) {
   await pages[name].evaluate(({count,html})=>{for(let i=0;i<10;i++)window.textBench.setup(count,html);window.textBench.updates(100,true);}, {count,html:documents[count][name]});
   const checked=await pages[name].evaluate(()=>window.textBench.check());
   assert.equal(checked.length,count);assert(checked.every(row=>row.nodes===(name==='separate'||name==='split'||name==='implemented'?3:1)));
  }
  for(let round=0;round<12;round++)for(const name of round%2?[...names].reverse():names) {
   const result=await pages[name].evaluate(({count,html})=>{
    const hydrationMs=window.textBench.setup(count,html);
    const oneMs=window.textBench.updates(50,false);
    const bothMs=window.textBench.updates(50,true);
    return {hydrationMs,oneMs,bothMs};
   },{count,html:documents[count][name]});
   samples.push({count,name,round,...result});
  }
  for(const name of names)console.log(count,name,Object.fromEntries(['hydrationMs','oneMs','bothMs'].map(key=>[key,samples.filter(s=>s.count===count&&s.name===name).reduce((n,s)=>n+s[key],0)/12])));
 }
 assert.deepEqual(errors,[]);
 await writeFile('.tmp/joined-text-experiment/browser'+(process.env.TEXT_RUN?'-'+process.env.TEXT_RUN:'')+'.json',JSON.stringify({browser:browser.version(),samples,errors,splitCases},null,2));
}finally{
 for(const page of Object.values(pages))await page.evaluate(()=>window.textBench?.dispose()).catch(()=>{});
 await browser.close();
}
