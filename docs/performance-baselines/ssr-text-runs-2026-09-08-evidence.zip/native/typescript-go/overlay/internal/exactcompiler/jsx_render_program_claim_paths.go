package exactcompiler

import (
	"sort"
	"strconv"

	"github.com/microsoft/TypeScript/tsc/internal/ast"
)

// directRenderProgramClaimsAll retains the cursor-only fallback for an element path that cannot
// fit the compact generated path operand. Ordinary compiled DOM stays on the targeted lane.
func (lowering *jsxLowering) directRenderProgramClaimsAll(
	build *renderProgramBuild,
) []*ast.Node {
	operations := make([]*ast.Node, 0, len(build.nodes)+len(build.slots))
	emitCall := func(helper string, arguments ...*ast.Node) {
		opcode := map[string]int{
			lowering.names.claimProgramElement:    0,
			lowering.names.enterProgramElement:    1,
			lowering.names.leaveProgramElement:    2,
			lowering.names.claimProgramText:       3,
			lowering.names.claimProgramKeyedChild: 4,
			lowering.names.claimProgramChild:      5,
			lowering.names.claimElementPath:       6,
			lowering.names.claimProgramProperty:   7,
		}[helper]
		operations = append(operations, lowering.renderProgramOperation(opcode, arguments...))
	}
	var emitChildren func([]int)
	emitChildren = func(parentPath []int) {
		if run := lowering.renderProgramTextRunClaim(build, parentPath); run != nil {
			operations = append(operations, run)
		}
		claims := lowering.directProgramChildClaims(build, parentPath)
		position := 0
		for _, claim := range claims {
			childIndex := claim.path[len(claim.path)-1]
			skip := lowering.factory.NewNumericLiteral(strconv.Itoa(childIndex-position), ast.TokenFlagsNone)
			claimIndex := lowering.factory.NewNumericLiteral(strconv.Itoa(claim.index), ast.TokenFlagsNone)
			switch claim.kind {
			case "element":
				arguments := []*ast.Node{claimIndex, skip, lowering.factory.NewStringLiteral(claim.tag, ast.TokenFlagsNone)}
				if claim.namespace != build.namespace {
					arguments = append(arguments, lowering.factory.NewStringLiteral(claim.namespace, ast.TokenFlagsNone))
				}
				emitCall(lowering.names.claimProgramElement, arguments...)
				if directProgramHasChildren(build, claim.path) {
					emitCall(lowering.names.enterProgramElement, claimIndex)
					emitChildren(claim.path)
					emitCall(lowering.names.leaveProgramElement)
				}
			case "text":
				arguments := []*ast.Node{claimIndex, skip}
				if build.markerlessTextSlot(claim.index) {
					arguments = append(arguments, lowering.factory.NewTrueExpression())
				} else {
					arguments = append(arguments, lowering.factory.NewStringLiteral(claim.id, ast.TokenFlagsNone))
				}
				emitCall(lowering.names.claimProgramText, arguments...)
			case "keyed":
				arguments := []*ast.Node{claimIndex, skip}
				if claim.component {
					arguments = append(arguments, lowering.factory.NewTrueExpression())
				}
				emitCall(lowering.names.claimProgramKeyedChild, arguments...)
			case "bounded-component":
				endNodeIndex, endPath, _ := boundedComponentEnd(build, claim.index)
				endNode := build.nodes[endNodeIndex]
				endIndex := lowering.factory.NewNumericLiteral(strconv.Itoa(endNodeIndex), ast.TokenFlagsNone)
				endArguments := []*ast.Node{
					endIndex,
					lowering.factory.NewNumericLiteral(strconv.FormatUint(endPath, 10), ast.TokenFlagsNone),
					lowering.factory.NewStringLiteral(endNode.tag, ast.TokenFlagsNone),
				}
				if endNode.namespace != build.namespace || build.namespace == "contextual" {
					endArguments = append(endArguments, lowering.factory.NewStringLiteral(endNode.namespace, ast.TokenFlagsNone))
				}
				emitCall(lowering.names.claimElementPath, endArguments...)
				emitCall(
					lowering.names.claimProgramKeyedChild,
					claimIndex,
					skip,
					lowering.factory.NewTrueExpression(),
					endIndex,
				)
			default:
				arguments := []*ast.Node{claimIndex, skip, lowering.factory.NewStringLiteral(claim.id, ast.TokenFlagsNone)}
				if claim.kind == "component" {
					arguments = append(arguments, lowering.factory.NewTrueExpression())
				}
				emitCall(lowering.names.claimProgramChild, arguments...)
			}
			position = childIndex + claim.width
		}
	}
	emitChildren(nil)
	for _, binding := range build.propertyBindings() {
		emitCall(
			lowering.names.claimProgramProperty,
			lowering.factory.NewNumericLiteral(strconv.Itoa(binding.slots[0]), ast.TokenFlagsNone),
			lowering.factory.NewNumericLiteral(strconv.Itoa(binding.node), ast.TokenFlagsNone),
		)
	}
	return operations
}

func (lowering *jsxLowering) directProgramChildClaims(
	build *renderProgramBuild,
	parentPath []int,
) []renderProgramClaim {
	claims := make([]renderProgramClaim, 0)
	for index, node := range build.nodes {
		if index != 0 && directChildPath(node.path, parentPath) {
			claims = append(claims, renderProgramClaim{
				kind: "element", index: index, path: node.path, tag: node.tag,
				namespace: node.namespace, width: 1,
			})
		}
	}
	for index, slot := range build.slots {
		if slot.kind != "text" && slot.kind != "child" && slot.kind != "component" {
			continue
		}
		path := append([]int(nil), slot.path...)
		width := 2
		kind := slot.kind
		if slot.markerlessTail {
			kind = "keyed"
			width = 0
		} else if _, bounded := boundedComponentEndPath(build, index); bounded {
			kind = "bounded-component"
			width = 0
		}
		if slot.kind == "text" {
			path[len(path)-1]--
			width = 3
		}
		if directChildPath(path, parentPath) {
			claims = append(claims, renderProgramClaim{
				kind: kind, component: slot.kind == "component", index: index, path: path, id: slot.id, width: width,
			})
		}
	}
	sort.SliceStable(claims, func(left int, right int) bool {
		leftPosition := claims[left].path[len(claims[left].path)-1]
		rightPosition := claims[right].path[len(claims[right].path)-1]
		if leftPosition == rightPosition {
			return claims[left].kind == "bounded-component" && claims[right].kind != "bounded-component"
		}
		return leftPosition < rightPosition
	})
	return claims
}

// directProgramElementPath packs stable element-child ordinals rather than Node.childNodes offsets.
// Each seven-bit step stores a six-bit ordinal and a high bit selecting children from the end.
// The compiler selects an edge that no preceding structural slot can perturb; a component with
// structural slots on both sides falls back to its generated cursor claims.
func directProgramElementPath(build *renderProgramBuild, path []int) (uint64, bool) {
	if len(path) > 7 {
		return 0, false
	}
	encoded := uint64(len(path))
	factor := uint64(16)
	parent := []int{}
	for pathIndex, childNodeIndex := range path {
		step, stable := directProgramElementPathStep(build, parent, childNodeIndex)
		if !stable {
			return 0, false
		}
		encoded += step * factor
		if pathIndex != len(path)-1 {
			factor *= 128
		}
		parent = append(parent, childNodeIndex)
	}
	return encoded, encoded <= 9007199254740991
}

func directProgramElementPathStep(
	build *renderProgramBuild,
	parent []int,
	childNodeIndex int,
) (uint64, bool) {
	variableBefore := false
	variableAfter := false
	for _, slot := range build.slots {
		if (slot.kind != "child" && slot.kind != "component") || !directChildPath(slot.path, parent) {
			continue
		}
		candidate := slot.path[len(slot.path)-1]
		if candidate < childNodeIndex || (slot.boundedMarkerless && candidate == childNodeIndex) {
			variableBefore = true
		} else if candidate > childNodeIndex {
			variableAfter = true
		}
	}
	if variableBefore && variableAfter {
		return 0, false
	}

	before := 0
	after := 0
	found := false
	for _, node := range build.nodes {
		if !directChildPath(node.path, parent) {
			continue
		}
		candidate := node.path[len(node.path)-1]
		switch {
		case candidate < childNodeIndex:
			before++
		case candidate > childNodeIndex:
			after++
		default:
			found = true
		}
	}
	if !found {
		return 0, false
	}
	if !variableBefore && before < 64 {
		return uint64(before), true
	}
	if !variableAfter && after < 64 {
		return uint64(after + 64), true
	}
	return 0, false
}

// boundedComponentEndPath returns the first static intrinsic immediately following a candidate
// component slot when that intrinsic remains addressable from a stable edge of every ancestor.
func boundedComponentEnd(build *renderProgramBuild, slotIndex int) (int, uint64, bool) {
	slot := build.slots[slotIndex]
	if slot.kind != "component" || !slot.boundedMarkerless {
		return 0, 0, false
	}
	parent := slot.path[:len(slot.path)-1]
	position := slot.path[len(slot.path)-1]
	for index, node := range build.nodes {
		if directChildPath(node.path, parent) && node.path[len(node.path)-1] == position {
			encoded, exists := directProgramElementPath(build, node.path)
			return index, encoded, exists
		}
	}
	return 0, 0, false
}

func boundedComponentEndPath(build *renderProgramBuild, slotIndex int) (uint64, bool) {
	_, path, exists := boundedComponentEnd(build, slotIndex)
	return path, exists
}

func pathPrefix(prefix []int, path []int) bool {
	if len(prefix) > len(path) {
		return false
	}
	for index := range prefix {
		if prefix[index] != path[index] {
			return false
		}
	}
	return true
}

func directProgramHasSlotDescendant(build *renderProgramBuild, path []int) bool {
	for _, slot := range build.slots {
		if slot.kind != "text" && slot.kind != "child" && slot.kind != "component" {
			continue
		}
		parent := slot.path[:len(slot.path)-1]
		if pathPrefix(path, parent) {
			return true
		}
	}
	return false
}

func directChildPath(path []int, parent []int) bool {
	if len(path) != len(parent)+1 {
		return false
	}
	for index := range parent {
		if path[index] != parent[index] {
			return false
		}
	}
	return true
}

func directProgramHasChildren(build *renderProgramBuild, parent []int) bool {
	for index, node := range build.nodes {
		if index != 0 && directChildPath(node.path, parent) {
			return true
		}
	}
	for _, slot := range build.slots {
		if slot.kind != "text" && slot.kind != "child" && slot.kind != "component" {
			continue
		}
		path := slot.path
		if slot.kind == "text" {
			path = append([]int(nil), path...)
			path[len(path)-1]--
		}
		if directChildPath(path, parent) {
			return true
		}
	}
	return false
}

// noRenderedProgramChildrenAfter proves that a structural slot owns the host's physical tail.
func noRenderedProgramChildrenAfter(children []*ast.Node, index int) bool {
	for childIndex := index + 1; childIndex < len(children); childIndex++ {
		child := children[childIndex]
		if ast.IsJsxText(child) && normalizeJSXChildText(
			child.AsJsxText().Text,
			childIndex,
			len(children),
		) == "" {
			continue
		}
		if ast.IsJsxExpression(child) && child.AsJsxExpression().Expression == nil {
			continue
		}
		return false
	}
	return true
}

// boundedComponentParentIsStable limits the local range optimization to the render root or a
// direct intrinsic child reachable by a forward element path. A forward path cannot be shifted by
// variable-width siblings that the compiler encounters later.
func (build *renderProgramBuild) boundedComponentParentIsStable(path []int) bool {
	if len(path) == 0 {
		return true
	}
	if len(path) != 1 {
		return false
	}
	encoded, stable := directProgramElementPath(build, path)
	return stable && (encoded/16)%128 < 64
}

// nextRenderedProgramChildIsPlainIntrinsic limits bounded marker elision to a directly adjacent
// intrinsic whose root DOM element is guaranteed to exist in both the client template and SSR.
// Later fixed-width text and intrinsic siblings do not affect its element-child path.
func (lowering *jsxLowering) nextRenderedProgramChildIsPlainIntrinsic(children []*ast.Node, index int) bool {
	for childIndex := index + 1; childIndex < len(children); childIndex++ {
		child := children[childIndex]
		if ast.IsJsxText(child) && normalizeJSXChildText(
			child.AsJsxText().Text,
			childIndex,
			len(children),
		) == "" {
			continue
		}
		if ast.IsJsxExpression(child) && child.AsJsxExpression().Expression == nil {
			continue
		}
		if ast.IsJsxElement(child) {
			element := child.AsJsxElement()
			if _, island := lowering.clientIslands[child]; island {
				return false
			}
			return jsxIntrinsic(sourceText(lowering.sourceFile, openingTag(element.OpeningElement))) &&
				!lowering.renderProgramIntrinsicHasEnhancements(element.OpeningElement.Attributes()) &&
				lowering.remainingProgramSiblingsHaveFixedWidth(children, childIndex)
		}
		if ast.IsJsxSelfClosingElement(child) {
			if _, island := lowering.clientIslands[child]; island {
				return false
			}
			return jsxIntrinsic(sourceText(lowering.sourceFile, openingTag(child))) &&
				!lowering.renderProgramIntrinsicHasEnhancements(child.Attributes()) &&
				lowering.remainingProgramSiblingsHaveFixedWidth(children, childIndex)
		}
		return false
	}
	return false
}

func (lowering *jsxLowering) remainingProgramSiblingsHaveFixedWidth(children []*ast.Node, index int) bool {
	for childIndex := index + 1; childIndex < len(children); childIndex++ {
		child := children[childIndex]
		if ast.IsJsxText(child) {
			continue
		}
		if ast.IsJsxExpression(child) && child.AsJsxExpression().Expression == nil {
			continue
		}
		if ast.IsJsxElement(child) {
			element := child.AsJsxElement()
			if _, island := lowering.clientIslands[child]; island {
				return false
			}
			if !jsxIntrinsic(sourceText(lowering.sourceFile, openingTag(element.OpeningElement))) {
				return false
			}
			continue
		}
		if ast.IsJsxSelfClosingElement(child) {
			if _, island := lowering.clientIslands[child]; island {
				return false
			}
			if !jsxIntrinsic(sourceText(lowering.sourceFile, openingTag(child))) {
				return false
			}
			continue
		}
		return false
	}
	return true
}
