import json, hashlib, zipfile
from pathlib import Path
from statistics import mean

root=Path('.tmp/ssr-large-profile')
rows=json.loads((root/'boundary-state-machine-http/http.json').read_text())
assert len(rows)==64
for row in rows:
    for path,key in [('entry','artifactSha256'),('workerFile','workerSha256')]:
        assert hashlib.sha256(Path(row[path]).read_bytes()).hexdigest()==row[key]
stages=[s for r in rows for d in r['results'] for s in d['stages']]
assert all(s['errors']==0 and s['started']==s['completed']==s['valid'] for s in stages)
summary={'valid':sum(s['valid'] for s in stages),'errors':0,'populations':[]}
for population in [0,1,'pooled']:
    selected=[r for r in rows if population=='pooled' or r['population']==population]
    a=mean(r['rps'] for r in selected if r['implementation']=='baseline')
    b=mean(r['rps'] for r in selected if r['implementation']=='combined')
    summary['populations'].append({'population':population,'currentRps':a,'candidateRps':b,'changePercent':(b/a-1)*100})
(root/'boundary-state-machine-http/summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))

files=set()
for path in root.glob('boundary-state-machine*'):
    if path.is_file(): files.add(path)
    else: files.update(p for p in path.rglob('*') if p.is_file())
for folder in ['conditional-emission','structural-count-warmup']:
    files.update(p for p in (root/folder).rglob('*') if p.is_file() and p.suffix in ['.js','.mjs'])
files.add(Path('framework-comparison/src/ssr-benchmark-worker.mjs'))
files.add(Path('.tmp/positional-leaves/data.json'))
archive=Path('docs/performance-baselines/boundary-state-machine-2026-09-10-evidence.zip')
assert not archive.exists()
manifest={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files):z.write(p,str(p).replace('\\','/'))
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified archive entries:',len(manifest))
