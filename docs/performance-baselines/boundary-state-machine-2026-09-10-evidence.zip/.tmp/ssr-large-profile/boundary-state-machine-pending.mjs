import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const root='.tmp/ssr-large-profile/';
const extra=`
export async function auditPending({childFails,flushFailure,pressure}) {
 const events=[];let pending;let release;
 const child=new Promise((resolve,reject)=>{release=()=>{events.push('child-settled');childFails?reject(Error('child-failed')):resolve('child');};});
 const sink={write(text){events.push(text);if(pressure)pending=Promise.resolve().then(()=>{events.push('drained');pending=undefined;});},ready(){return pending;},flush(){events.push('flush');queueMicrotask(release);if(flushFailure==='sync')throw Error('flush-failed');if(flushFailure==='async')return Promise.reject(Error('flush-failed'));}};
 try {await writeProgramBoundary({},sink,'open','close',()=>{events.push('render');return child;});events.push('complete');}catch(error){events.push(error.message);}
 return events;
}
`;
const modules=[];
for(const name of ['conditional-emission','boundary-state-machine']){
 const file=root+'boundary-state-machine/'+name+'-pending.js';
 await fs.writeFile(file,(await fs.readFile(root+name+'/server-entry.js','utf8'))+extra);
 modules.push(await import(pathToFileURL(resolve(file))));
}
const rows=[];
for(const childFails of [false,true])for(const flushFailure of ['none','sync','async'])for(const pressure of [false,true]){
 const options={childFails,flushFailure,pressure};
 const current=await modules[0].auditPending(options),candidate=await modules[1].auditPending(options);
 assert.deepEqual(candidate,current);
 assert.ok(current.indexOf('child-settled')<current.length-1);
 if(childFails||flushFailure!=='none')assert.ok(!current.includes('close'));
 rows.push({options,events:current});
}
await fs.writeFile(root+'boundary-state-machine/pending-checks.json',JSON.stringify(rows,null,2));
console.log('Matched pending-child and flush-failure ordering:',rows.length);
