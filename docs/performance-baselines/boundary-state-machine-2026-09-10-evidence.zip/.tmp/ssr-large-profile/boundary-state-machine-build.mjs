import fs from 'node:fs/promises';import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'boundary-state-machine');
const replacement=`function writeProgramBoundary(context,sink,opening,closing,render,stage=0,html='') {
 while(true){
  switch(stage){
   case 0:{if(opening){context.outputSink?.accountKnown(opening,opening.length);sink.write(opening);}stage=1;const pending=sink.ready();if(pending)return pending.then(()=>writeProgramBoundary(context,sink,opening,closing,render,stage));break;}
   case 1:{const rendered=render();stage=2;if(rendered instanceof Promise)return awaitSsrProgramSink(sink,rendered).then(value=>writeProgramBoundary(context,sink,opening,closing,render,stage,value));html=rendered;break;}
   case 2:{if(html)sink.write(html);stage=3;const pending=sink.ready();if(pending)return pending.then(()=>writeProgramBoundary(context,sink,opening,closing,render,stage));break;}
   case 3:{if(!closing)return '';context.outputSink?.accountKnown(closing,closing.length);sink.write(closing);stage=4;const pending=sink.ready();if(pending)return pending.then(()=>writeProgramBoundary(context,sink,opening,closing,render,stage));break;}
   case 4:return '';
  }
 }
}`;
for(const name of ['server-entry.js','bun-server-entry.js']){
 const source=await fs.readFile(root+'conditional-emission/'+name,'utf8');const ast=ts.createSourceFile(name,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);const nodes=ast.statements.filter(n=>ts.isFunctionDeclaration(n)&&n.name?.text==='writeProgramBoundary');if(nodes.length!==1)throw Error('Boundary declaration mismatch');const node=nodes[0];await fs.writeFile(root+'boundary-state-machine/'+name,source.slice(0,node.getStart(ast))+replacement+source.slice(node.end));
}
for(const kind of ['check','limits']){const source=await fs.readFile(root+'structural-stack-'+kind+'.mjs','utf8');await fs.writeFile(root+'boundary-state-machine-'+kind+'.mjs',source.replaceAll('structural-stack','boundary-state-machine'));}
const lifecycle=await fs.readFile(root+'structural-stack-lifecycle.mjs','utf8');await fs.writeFile(root+'boundary-state-machine-lifecycle.mjs',lifecycle.replaceAll('structural-stack','boundary-state-machine'));
