import type { RenderValue } from './execution.js';

/**
 * Request-owned destination for ordered render-program spans.
 * The destination owns buffering and byte limits. A write accepts its entire span;
 * the renderer checks readiness before producing another span. Destruction and
 * final hydration publication belong to the request owner, not individual programs.
 * A terminal destination failure must cancel the request's task signal, allowing
 * pending descendants to settle and release their scopes before their parents.
 */
export interface SsrProgramSink {
	/** Accepts one completed span, retaining its order even when transport pressure begins. */
	write(html: string): void;
	/** Returns a pending drain only when the destination cannot accept the next span. */
	ready(): RenderValue<void>;
	/** Publishes buffered output at a completed head or before awaiting descendant work. */
	flush(reason: 'head' | 'await'): RenderValue<void>;
}
