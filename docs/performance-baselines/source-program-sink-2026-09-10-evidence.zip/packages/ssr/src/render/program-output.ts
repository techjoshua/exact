import type { SsrContext } from '../types.js';
import { mapRenderValue, withRenderCleanup, type RenderValue } from './execution.js';
import { claimRootText, enterHostTag, leaveHost } from './host.js';
import { appendBoundedHtml, assertOutputCharacterBound } from './limits.js';
import { captureNestedEnhancementStringPrefix } from './operation-enhancement-routes.js';
import type { SsrProgramSink } from './program-sink.js';

/**
 * Consumes completed spans directly and renders only deferred program segments.
 * Retains compiler-owned document ancestry through pending descendants and releases it on failure.
 */
export function renderProgramOutput<T extends object>(
	context: SsrContext,
	segments: readonly (string | T)[],
	render: (segment: T) => RenderValue<string>,
	host?: string
): RenderValue<string> {
	const sink = context.writerSink;
	// Ordinary roots must invalidate document probing too. Only document hosts and their
	// immediate intrinsic children need a retained stack frame for document validation.
	if (
		host &&
		(host === 'html' ||
			host === 'head' ||
			host === 'body' ||
			(context.documentRootSeen && context.hostStack.at(-1) === 'html'))
	) {
		const entered = enterHostTag(context, host);
		return withRenderCleanup(
			() => {
				if (!sink)
					return mapRenderValue(renderProgramOutput(context, segments, render), (html) =>
						entered.prefix ? appendBoundedHtml(context, entered.prefix, html) : html
					);
				if (entered.prefix) sink.write(entered.prefix);
				return mapRenderValue(sink.ready(), () =>
					mapRenderValue(renderProgramOutput(context, segments, render), (html) =>
						mapRenderValue(host === 'head' ? sink.flush('head') : undefined, () => html)
					)
				);
			},
			() => leaveHost(context, entered.tag)
		);
	}
	if (host && !context.hostStack.length) claimRootText(context);
	const first = segments[0];
	if (
		segments.length === 1 &&
		typeof first === 'string' &&
		!sink &&
		!context.enhancementOperationRoutes?.length
	) {
		assertOutputCharacterBound(context, first);
		return first;
	}
	return continueProgramOutput(context, segments, render, 0, '', sink);
}

/** Resumes ordered output after actual suspension; completed work allocates no continuations. */
function continueProgramOutput<T extends object>(
	context: SsrContext,
	segments: readonly (string | T)[],
	render: (segment: T) => RenderValue<string>,
	start: number,
	output: string,
	sink?: SsrProgramSink
): RenderValue<string> {
	for (let index = start; index < segments.length; index++) {
		const segment = segments[index]!;
		const value = typeof segment === 'string' ? segment : render(segment);
		if (value instanceof Promise) {
			// Observe descendant rejection before a transport flush can itself fail.
			const pending = flushBeforeAwait(sink, value);
			return pending.then((html) =>
				mapRenderValue(appendProgramSpan(context, sink, output, html), (next) =>
					continueProgramOutput(context, segments, render, index + 1, next, sink)
				)
			);
		}
		if (sink) {
			if (value !== '') sink.write(value);
			const pending = sink.ready();
			if (pending instanceof Promise)
				return pending.then(() =>
					continueProgramOutput(context, segments, render, index + 1, '', sink)
				);
		} else {
			output = appendBoundedHtml(
				context,
				captureNestedEnhancementStringPrefix(context, output),
				value
			);
		}
	}
	return output;
}

/** Keeps scoped strings local while shared destinations own publication and pressure. */
function appendProgramSpan(
	context: SsrContext,
	sink: SsrProgramSink | undefined,
	output: string,
	html: string
): RenderValue<string> {
	if (!sink)
		return appendBoundedHtml(context, captureNestedEnhancementStringPrefix(context, output), html);
	if (html !== '') sink.write(html);
	const pending = sink.ready();
	return pending instanceof Promise ? pending.then(() => '') : '';
}

/** Observes both pending work and a failing drain, including synchronous flush failures. */
function flushBeforeAwait(
	sink: SsrProgramSink | undefined,
	value: Promise<string>
): Promise<string> {
	if (!sink) return value;
	let drain: RenderValue<void>;
	try {
		drain = sink.flush('await');
	} catch (error) {
		return value.then(
			() => {
				throw error;
			},
			() => {
				throw error;
			}
		);
	}
	return drain instanceof Promise ? settleProgramFlush(value, drain) : value;
}

/** A failed drain cannot unwind a parent's scope while its descendant still owns it. */
async function settleProgramFlush(value: Promise<string>, drain: Promise<void>): Promise<string> {
	try {
		const [html] = await Promise.all([value, drain]);
		return html;
	} finally {
		// The destination's failure cancels request tasks. Retain ownership through
		// their settlement even when the transport failed before the child did.
		await value.then(
			() => undefined,
			() => undefined
		);
	}
}
