import fs from 'node:fs';
import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/';
function regions(path){
 const text=fs.readFileSync(path,'utf8'),result=new Map();
 for(const match of text.matchAll(/\/\/#region ([^\r\n]+)\r?\n([\s\S]*?)\/\/#endregion/g)){
  assert.ok(!result.has(match[1]),match[1]);result.set(match[1],match[2]);
 }
 return result;
}
const before=regions(d+'source-sink-before.mjs'),after=regions(d+'source-sink-refined/server-entry.js');
assert.deepEqual([...after.keys()],[...before.keys()]);
const changed=[...after.keys()].filter(key=>before.get(key)!==after.get(key));
fs.writeFileSync(d+'source-sink-diff.json',JSON.stringify({regions:after.size,changed},null,2));
console.log(JSON.stringify({regions:after.size,changed},null,2));
