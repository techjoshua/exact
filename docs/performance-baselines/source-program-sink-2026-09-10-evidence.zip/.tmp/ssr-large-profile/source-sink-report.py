from pathlib import Path
import hashlib,json,statistics,zipfile

root=Path.cwd(); d=root/'.tmp/ssr-large-profile'
report=root/'docs/performance-baselines/source-program-sink-2026-09-10.md'
archive=report.with_name(report.stem+'-evidence.zip')
initial=json.loads((d/'source-sink-results.json').read_text())
final=json.loads((d/'source-sink-refined-results.json').read_text())
assert len(initial)==len(final)==32
for row in initial+final:
    assert hashlib.sha256((root/row['entry']).read_bytes()).hexdigest()==row['artifactSha256']
checks=json.loads((d/'source-sink-validation.json').read_text())
assert all(result['exit_code']==0 for result in checks.values())
assert '298 passed' in checks['tests']['output']
diff=json.loads((d/'source-sink-diff.json').read_text())
assert diff['changed']==['../packages/ssr/dist/render/program-output.js','../packages/ssr/dist/render/operation-enhancements.js']
lines=['# Source integration of ordered program sinks','',
'Date: 2026-09-10. Internal runtime integration; public stream selection is not yet migrated.','',
'## Source change','',
'The shared program visitor now accepts an internal request-owned destination through',
'SsrContext.writerSink. This is separate from the output byte-accounting ledger. The sink owns',
'buffering and byte limits. It accepts each ordered span once; the visitor checks readiness',
'before subsequent work, flushes a completed head, and flushes before awaiting pending children.',
'Scoped string capture uses the same visitor. Enhancement rendering suspends outer publication',
'until routing has determined the final target order and wrappers, restoring the destination',
'through success or failure.','',
'Failure handling retains parent host ownership until pending descendants settle. The first',
'implementation used Promise.all alone for child work and a pending drain, which could release',
'an ancestor while the child still owned its scope. The corrected implementation observes both',
'promises and waits for descendant settlement before unwinding. A synchronous flush failure',
'also observes and waits for the child. The destination owner must cancel request tasks on',
'terminal transport failure so that cancelled descendants can release their scopes.','',
'This is an integration step toward one renderer with interchangeable destinations. Public',
'entry points do not yet install the destination. Their full-document streaming behavior remains',
'unchanged. Compiler-emitted writer signatures and the released-artifact epoch are unchanged.',
'Native writer migration, structural boundary capture, request-owned sinks, and progressive',
'hydration-tail publication remain required before the full application uses progressive traversal.','',
'## Correctness checks','',
'All 298 SSR tests pass. Seven new cases cover head publication while a body child remains',
'pending, write pressure before later children, final-drain completion, rejected pressure,',
'synchronous flush failure with later child rejection, asynchronous flush failure while nested',
'hosts remain owned, and nested enhancement capture restoration on success and failure.',
'The success/failure capture case is parameterized, giving seven executed cases in total.',
'These are runtime boundary tests, not a claim that the public response already publishes its',
'head before pending work. No browser performance improvement is claimed.','',
'SSR package build, repository test type checking, source architecture, focused ESLint, platform',
'boundaries, and package contents checks pass. Engineering documentation records the current',
'integration boundary; public application documentation is unchanged because public behavior',
'is unchanged.','',
'## Performance checks','',
'The initial hypothesis was negligible overhead in ordinary rendering while the destination is',
'absent. The first comparison showed a possible large Bun string regression: 224.25 to 231.13',
'microseconds. Inspection found that the initial implementation checked for a promise after',
'every local string append and allocated extra host callbacks even without a shared sink.',
'The refinement confines drain checks to shared destinations and preserves direct local appends.',
'The hypothesis for that refinement was to recover the possible overhead without changing',
'publication or cleanup behavior.','',
'Both runs use fresh production-mode Node 26.8.1 and Bun 1.4.2 processes, 5,000 warmups and',
'12,000 measured renders per sample, two reversed-order samples per cell. Documents contain',
'three or 96 incidents, all four assets, the authored shell, and hydration/bootstrap output.',
'Streams are fully consumed through Response.text(). No build or test runs concurrently with',
'timing. Complete-document hashes match across candidates and controls. These are renderer',
'microseconds, not HTTP requests/s.','',
'The isolated application build uses the production native compiler and built source packages.',
'Comparing all 126 bundled regions finds changes only in program output and enhancement rendering.',
'The saved production application artifact is the control; the native sink prototype is not a',
'variant in this particular overhead check.','',
'### Initial source integration','',
'| Runtime | Document | Mode | Production control | Initial source | Change |',
'| --- | --- | --- | ---: | ---: | ---: |']
def table(rows):
    result=[]
    for rt in ['node','bun']:
        for scenario in ['assets','large']:
            for mode in ['string','stream']:
                a,b=[statistics.mean(r['usPerRender'] for r in rows if r['runtimeId']==rt and r['scenario']==scenario and r['mode']==mode and r['variant']==v) for v in ['before','source']]
                result.append(f'| {rt} | {scenario} | {mode} | {a:.2f} | {b:.2f} | {(b/a-1)*100:+.1f}% |')
    return result
lines+=table(initial)
lines+=['','### Refined local collection','',
'| Runtime | Document | Mode | Production control | Refined source | Change |',
'| --- | --- | --- | ---: | ---: | ---: |']
lines+=table(final)
lines+=['','Both complete runs are preserved; neither is relabeled as a measurement of the other artifact.',
'Machine variation and the small sample count limit interpretation. This work establishes and',
'validates the source integration boundary, rather than demonstrating a throughput improvement.',
'React was not rerun here. Its last paired lead in string rendering remains unresolved; see',
'[the native lazy-frame comparison](native-lazy-frame-2026-09-09.md).','',
'The [evidence archive](source-program-sink-2026-09-10-evidence.zip) includes both timed runs,',
'the exact three application artifacts, source and tests, build/run scripts, validation output,',
'and a verified SHA-256 manifest.','']
report.write_text('\n'.join(lines),encoding='utf8')
paths=[d/name for name in ['source-sink-build.mjs','source-sink-run.mjs','source-sink-report.py',
'source-sink-results.json','source-sink-refined-results.json','source-sink-validation.json',
'source-sink-diff.mjs','source-sink-diff.json','source-sink-before.mjs',
'source-sink-application/server-entry.js','source-sink-refined/server-entry.js',
'source-sink-first-program-output.ts','production-refresh-worker.mjs']]
paths += [root/name for name in ['packages/ssr/src/types.ts','packages/ssr/src/render/program-sink.ts',
'packages/ssr/src/render/program-sink.test.ts','packages/ssr/src/render/program-output.ts',
'packages/ssr/src/render/operation-enhancements.ts','docs/ssr-hydration.md','.tmp/positional-leaves/data.json']]
paths.append(report);manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for path in paths:
        content=path.read_bytes();name=path.relative_to(root).as_posix()
        manifest[name]=hashlib.sha256(content).hexdigest();z.writestr(name,content)
    z.writestr('SHA256SUMS.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    for name,digest in manifest.items(): assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('\n'.join(table(final)))
print(f'Wrote report; verified {len(manifest)} archive hashes.')
