import {spawn,execFileSync} from 'node:child_process';
import {openSync,closeSync,writeFileSync,readFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
const root=resolve('.'),output=resolve('.tmp/client-deferred-repeat-2026-09-13'),suite=resolve('framework-comparison');
const journal=existsSync(`${output}/execution.json`)?JSON.parse(readFileSync(`${output}/execution.json`)):[];
process.env.NODE_ENV='production';process.env.COMPARISON_SSR_RENDER_MODE='string';
async function run(name,args,cwd=root,env={}) {
 if(journal.some(s=>s.name===name&&s.code===0)){console.log('RETAIN '+name);return;}
 const step={name,args,cwd,env,startedAt:new Date().toISOString()};journal.push(step);
 const save=()=>writeFileSync(`${output}/execution.json`,JSON.stringify(journal,null,2));save();console.log('START '+name);
 const log=openSync(`${output}/${name}.log`,'w');
 try{await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{cwd,env:{...process.env,...env},stdio:['ignore',log,log],windowsHide:true});step.pid=child.pid;save();child.once('error',fail);child.once('exit',(code,signal)=>{step.code=code;step.signal=signal;code===0?done():fail(Error(`${name} failed: ${code??signal}`));});});}
 finally{closeSync(log);step.endedAt=new Date().toISOString();save();}console.log('DONE '+name);
}

await run('correctness-before',['../node_modules/@playwright/test/cli.js','test','-c','playwright.config.ts'],suite);
await run('browser',['src/measure.mjs','--correctness-passed','--output='+output+'/browser.json'],suite,{COMPARISON_SAMPLES:'30',COMPARISON_MEASUREMENT_ROUND:'16'});
await run('correctness-built',['../node_modules/@playwright/test/cli.js','test','-c','playwright.config.ts'],suite);
await run('startup',['src/measure-startup-cpu.mjs','--correctness-passed','--output='+output+'/startup.json'],suite,{COMPARISON_STARTUP_SAMPLES:'10',COMPARISON_CPU_RATES:'1,4,6',COMPARISON_MEASUREMENT_ROUND:'16'});
await run('heap',['src/measure-heap.mjs','--correctness-passed'],suite,{COMPARISON_HEAP_SAMPLES:'5',COMPARISON_HEAP_OUTPUT:output+'/heap.json'});
console.log('COMPLETE client measurements');
