import json, pathlib, hashlib, zipfile
directory=pathlib.Path('.tmp/ssr-large-profile')
rows=json.loads((directory/'unowned-program-current-results.json').read_text(encoding='utf-8'))
assert len(rows)==32
candidate=directory/'unowned-program-current.mjs'
built=pathlib.Path('framework-comparison/participants/exact/dist-server/server-entry.js')
assert candidate.read_bytes()==built.read_bytes()
text='''# Skip empty prepared-sibling cleanup scopes

Date: 2026-09-09. Retained in production.

Prepared server programs previously entered withRenderCleanup even when sibling preparation
returned no owned resources. The operation target now returns directly through renderProgramOutput
in that case. Programs owning prepared siblings retain the existing cleanup path. Descendant
ownership, document host unwinding, and error propagation remain in their owning render operations.
This removes two callback constructions and empty cleanup dispatch at each affected call site;
it does not remove any resource disposal. It does not establish direct-to-sink traversal.

The hypothesis was a modest improvement most visible with many compiled programs. Thirty-two
fresh production processes compare the frozen text-surroundings control with this isolated change:
Node/Bun, string/consumed stream, three/96 incidents with four assets, two reversed-order pairs.
Each process uses 5,000 warmups and 12,000 measured renders. Full application-owned documents and
hydration hashes match in every pair. No completed population was discarded. These are local
renderer timings, not HTTP throughput; two pairs do not establish confidence intervals.

Positive percentages mean slower rendering.

| Runtime | Mode | Fixture | Pair 1 time change | Pair 2 time change |
| --- | --- | --- | ---: | ---: |
'''
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['small','large']:
   deltas=[]
   for round in range(2):
    pair=[r for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['round']==round]
    assert len(pair)==2 and pair[0]['hash']==pair[1]['hash']
    old=next(r for r in pair if r['variant']=='text-surroundings-current')
    new=next(r for r in pair if r['variant']=='unowned-program-current')
    deltas.append((new['usPerRender']/old['usPerRender']-1)*100)
   text+=f'| {runtime} | {mode} | {scenario} | {deltas[0]:+.2f}% | {deltas[1]:+.2f}% |\n'
text+='''
String rendering improved in both pairs of every cell. Node streaming also improved in both
pairs. Small Bun streaming was better once and essentially unchanged once; large Bun streaming
was mixed. Retention is based on simpler ownership handling and these measured results, without
claiming a universal improvement. React was not rerun, so its preceding comparison remains dated.

Validation: 288 SSR tests in 45 files, including new synchronous/asynchronous child-failure
host-unwinding checks; test type checking; changed-file lint; source architecture; platform
boundaries; compiled ABI fixtures; initial release ABI epoch 1; package contents. Existing SSR
tests cover scheduled sibling issuance and component cleanup. Client, Node server, and Bun server
builds completed. The client artifact remains index-CdIXDKwS.js.
The rebuilt Node entry is byte-for-byte identical to the timed candidate.

Browser correctness checks passed for both frameworks in Node/Bun and string/stream, 14 per cell,
56 total. These are interaction/hydration checks, not new browser performance timings.
Engineering documentation now describes the cleanup ownership rule. Public APIs and authored
usage are unchanged, so no package README or docs-app edits are needed.

The adjacent evidence ZIP contains raw measurements, both frozen artifacts, source snapshots,
scripts, browser logs, and a verified SHA-256 manifest. Validation command summaries here reflect
successful tool output; raw transcripts for every package check are not included.

The broader direct-sink implementation and React parity goal remain incomplete.
'''
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  log=directory/f'unowned-program-browser-{runtime}-{mode}.log'
  assert '14 passed' in log.read_text(encoding='utf-8')
target=pathlib.Path('docs/performance-baselines/unowned-program-2026-09-09')
target.with_suffix('.md').write_text(text,encoding='utf-8')
files=[directory/name for name in ['text-surroundings-current.mjs','unowned-program-current.mjs','unowned-program-build.mjs','unowned-program-run.mjs','unowned-program-current-results.json','unowned-program-browser.mjs','unowned-program-report.py','direct-map-worker.mjs']]
files+=list(directory.glob('unowned-program-browser-*.log'))
files+=[pathlib.Path(name) for name in ['.tmp/positional-leaves/data.json','packages/ssr/src/render/operation-target.ts','packages/ssr/src/render/operation-target.test.ts','docs/ssr-hydration.md']]
manifest={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=pathlib.Path(str(target)+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p).replace('\\','/'))
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(text)
