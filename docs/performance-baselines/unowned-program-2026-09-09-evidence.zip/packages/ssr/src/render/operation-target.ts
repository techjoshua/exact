import {
	isFiniteClientBoundary,
	normalizeRenderResult,
	type AnyComponentInstance
} from '@exactjs/core';
import {
	readPreparedServerRenderProgram,
	type ExactPreparedServerChildRange,
	type ExactPreparedServerKeyedChild
} from '@exactjs/core/framework/server-render-structure';
import {
	exactActivityOperation,
	exactChildRangeOperation,
	exactComponentOperation,
	exactFragmentOperation,
	exactIntrinsicOperation,
	exactKeyedChildOperation,
	exactPortalOperation,
	exactServerBoundaryOperation,
	exactServerSlotOperation,
	exactSuspenseOperation,
	exactTargetOperation,
	exactUnsafeHtmlOperation,
	withoutCompiledFragmentReceiptEnhancement,
	withoutCompiledIntrinsicReceiptEnhancement,
	withoutCompiledSuspenseReceiptEnhancement,
	type ExactActivityReceiptData,
	type ExactChildRangeReceiptData,
	type ExactComponentReceiptData,
	type ExactFragmentReceiptData,
	type ExactIntrinsicReceiptData,
	type ExactKeyedChildReceiptData,
	type ExactPortalReceiptData,
	type ExactServerBoundaryReceiptData,
	type ExactServerSlotReceiptData,
	type ExactSuspenseReceiptData,
	type ExactTargetReceiptData,
	type ExactUnsafeHtmlReceiptData
} from '@exactjs/core/runtime/component-operations';
import {
	exactRenderProgramOperation,
	withoutRenderProgramReceiptEnhancement,
	type ExactRenderProgramReceiptData
} from '@exactjs/core/runtime/render-operations';
import { unwrap } from '@exactjs/reactive/framework/values';
import { exactMarkerId, markerId, markerPair } from '../markup.js';
import type { Child, RenderToStringOptions, SsrContext } from '../types.js';
import { renderComponentReference } from './component.js';
import { prepareDirectScheduledSsrComponentReferences } from './direct-component-scheduling.js';
import type { RenderValue } from './execution.js';
import { mapRenderValue, withRenderCleanup } from './execution.js';
import { renderUnsafeHtmlValue } from './host.js';
import { renderIntrinsicReceipt } from './intrinsic-receipt.js';
import { renderOperationEnhancements } from './operation-enhancements.js';
import { renderProgramOutput } from './program-output.js';
import { renderPreparedSsrProgram } from './render-program.js';
import { registerDynamicComponentPreload } from './resource-hints.js';
import { exactSerializedSsrHtmlOperation } from './serialized-html-operation.js';
import { renderServerBoundary } from './server-boundary-capability.js';
import type { ServerComponentReference } from './server-component-reference.js';
import { serverSlotOpening, serverSlotReceiptReference } from './server-slots.js';
import {
	renderActivityReceipt,
	renderFragmentReceipt,
	renderKeyedChildReceipt,
	renderSuspenseReceipt,
	renderTargetReceipt
} from './structural-receipts.js';

type RenderChildren = (
	context: SsrContext,
	children: readonly Child[],
	parent: AnyComponentInstance | undefined,
	options: RenderToStringOptions,
	hasComponentAncestor?: boolean
) => RenderValue<string>;

/** Shared SSR target selected directly by each opaque compiler-issued operation. */
export class SsrOperationTarget {
	constructor(
		private readonly context: SsrContext,
		private readonly parent: AnyComponentInstance | undefined,
		private readonly options: RenderToStringOptions,
		private readonly hasComponentAncestor: boolean,
		private readonly renderChildren: RenderChildren
	) {}

	/** Serializes a component operation with asynchronous descendant support. */
	[exactComponentOperation](
		_operation: object,
		data: ExactComponentReceiptData
	): RenderValue<string> {
		return this.renderDirectServerComponent(data);
	}

	/** Serializes an intrinsic operation and any enhancement wrapper. */
	[exactIntrinsicOperation](
		operation: object,
		data: ExactIntrinsicReceiptData
	): RenderValue<string> {
		return renderOperationEnhancements(
			this.context,
			data.enhancement,
			() =>
				renderIntrinsicReceipt(
					this.context,
					data,
					this.parent,
					this.hasComponentAncestor,
					(target, children, owner, ancestor) =>
						this.renderChildren(target, children, owner, this.options, ancestor)
				),
			this.parent,
			this.options,
			this.renderChildren,
			withoutCompiledIntrinsicReceiptEnhancement(operation)
		);
	}

	/** Serializes one keyed child while preserving its marker identity. */
	[exactKeyedChildOperation](
		_operation: object,
		data: ExactKeyedChildReceiptData
	): RenderValue<string> {
		return this.renderKeyedChild(data);
	}

	/** Serializes one direct compiler-closed keyed server child. */
	renderDirectServerKeyedChild(data: ExactPreparedServerKeyedChild): RenderValue<string> {
		return this.renderKeyedChild(data);
	}

	private renderKeyedChild(
		data: ExactPreparedServerKeyedChild | ExactKeyedChildReceiptData
	): RenderValue<string> {
		const program = readPreparedServerRenderProgram(data.value);
		// The compiled program's single intrinsic root already owns this keyed item's boundary.
		// External scripts compile only on the server; their client intrinsic still claims the key range.
		if (program && program.program.ssrHost !== 'script')
			return this.renderPreparedServerProgram(program);
		return renderKeyedChildReceipt(
			this.context,
			data as ExactKeyedChildReceiptData,
			this.parent,
			this.options,
			this.hasComponentAncestor,
			this.renderChildren
		);
	}

	/** Serializes an asynchronously settling Suspense operation. */
	[exactSuspenseOperation](operation: object, data: ExactSuspenseReceiptData): RenderValue<string> {
		return renderOperationEnhancements(
			this.context,
			data.enhancement,
			() =>
				renderSuspenseReceipt(
					this.context,
					data,
					this.parent,
					this.options,
					this.hasComponentAncestor,
					this.renderChildren
				),
			this.parent,
			this.options,
			this.renderChildren,
			withoutCompiledSuspenseReceiptEnhancement(operation)
		);
	}

	/** Serializes the currently selected Activity content. */
	[exactActivityOperation](
		_operation: object,
		data: ExactActivityReceiptData
	): RenderValue<string> {
		return renderActivityReceipt(
			this.context,
			data,
			this.parent,
			this.options,
			this.hasComponentAncestor,
			this.renderChildren
		);
	}

	/** Serializes a transparent compiler-owned fragment range. */
	[exactFragmentOperation](operation: object, data: ExactFragmentReceiptData): RenderValue<string> {
		return renderOperationEnhancements(
			this.context,
			data.enhancement,
			() =>
				renderFragmentReceipt(
					this.context,
					data,
					this.parent,
					this.options,
					this.hasComponentAncestor,
					this.renderChildren
				),
			this.parent,
			this.options,
			this.renderChildren,
			withoutCompiledFragmentReceiptEnhancement(operation)
		);
	}

	/** Serializes the children selected by a semantic target operation. */
	[exactTargetOperation](_operation: object, data: ExactTargetReceiptData): RenderValue<string> {
		return renderTargetReceipt(
			this.context,
			data,
			this.parent,
			this.options,
			this.hasComponentAncestor,
			this.renderChildren
		);
	}

	/** Serializes a focused dynamic child range. */
	[exactChildRangeOperation](
		_operation: object,
		data: ExactChildRangeReceiptData
	): string | Promise<string> {
		if (data.dynamicComponent && data.markerId)
			registerDynamicComponentPreload(this.context, data.markerId);
		return this.renderChildRange(data, !!data.dynamicComponent);
	}

	/** Serializes one direct compiler-closed server child range. */
	renderDirectServerChildRange(data: ExactPreparedServerChildRange): string | Promise<string> {
		return this.renderChildRange(data, false, '');
	}

	private renderChildRange(
		data: ExactPreparedServerChildRange | ExactChildRangeReceiptData,
		dynamicComponent: boolean,
		compilerIdentity?: string
	): string | Promise<string> {
		const children = dynamicComponent
			? []
			: normalizeRenderResult(unwrap(data.value) as Child | Child[]);
		const identity =
			compilerIdentity ??
			(data.markerId
				? `dynamic:${exactMarkerId(data.markerId)}`
				: markerId(this.context, 'dynamic'));
		return markerPair(this.context, identity, () =>
			this.renderChildren(
				this.context,
				children,
				this.parent,
				this.options,
				this.hasComponentAncestor
			)
		);
	}

	/** Serializes audited raw HTML without reparsing it. */
	[exactUnsafeHtmlOperation](_operation: object, data: ExactUnsafeHtmlReceiptData): string {
		return markerPair(this.context, markerId(this.context, 'unsafe-html'), () =>
			renderUnsafeHtmlValue(this.context, data.value)
		);
	}

	/** Serializes a client-island publication boundary. */
	[exactServerBoundaryOperation](
		operation: object,
		data: ExactServerBoundaryReceiptData
	): RenderValue<string> {
		return renderServerBoundary(
			this.context,
			data,
			this.parent,
			this.options,
			isFiniteClientBoundary(operation)
		);
	}

	/** Serializes a retained server-owned child slot. */
	[exactServerSlotOperation](
		_operation: object,
		data: ExactServerSlotReceiptData
	): string | Promise<string> {
		return data.children.length
			? mapRenderValue(
					this.renderChildren(
						this.context,
						data.children,
						this.parent,
						this.options,
						this.hasComponentAncestor
					),
					(html) =>
						`${serverSlotOpening(serverSlotReceiptReference(data), this.context)}${html}</span>`
				)
			: '';
	}

	/** Serializes portal children in logical ownership order. */
	[exactPortalOperation](_operation: object, data: ExactPortalReceiptData): RenderValue<string> {
		return this.renderChildren(
			this.context,
			data.children,
			this.parent,
			this.options,
			this.hasComponentAncestor
		);
	}

	/** Serializes a compiler-closed server render program. */
	[exactRenderProgramOperation](
		operation: object,
		data: ExactRenderProgramReceiptData
	): RenderValue<string> {
		const program = readPreparedServerRenderProgram(data.invocation);
		if (!program)
			throw new TypeError('Server rendering received a client-only render-program operation');
		return renderOperationEnhancements(
			this.context,
			data.enhancement,
			() => this.renderPreparedServerProgram(program),
			this.parent,
			this.options,
			this.renderChildren,
			withoutRenderProgramReceiptEnhancement(operation)
		);
	}

	/** Serializes a compiler-issued direct server program nested inside another operation. */
	renderPreparedServerProgram(
		program: NonNullable<ReturnType<typeof readPreparedServerRenderProgram>>
	): RenderValue<string> {
		const planned = renderPreparedSsrProgram(this.context, program, this.parent);
		const preparation = prepareDirectScheduledSsrComponentReferences(
			this.context,
			planned.segments,
			this.parent,
			this.options
		);
		// Descendant rendering retains its own cleanup; this scope owns only prepared siblings.
		if (!preparation)
			return renderProgramOutput(
				this.context,
				planned.segments,
				(segment) => this.renderProgramSegment(segment),
				program.program.ssrHost
			);
		return withRenderCleanup(
			() =>
				renderProgramOutput(
					this.context,
					planned.segments,
					(segment) => this.renderProgramSegment(segment),
					program.program.ssrHost
				),
			() => (preparation ? Promise.resolve(preparation[Symbol.asyncDispose]()) : undefined)
		);
	}

	/** Serializes one direct server reference reached outside a prepared render-program segment. */
	renderDirectServerComponent(component: ServerComponentReference): RenderValue<string> {
		this.context.enhancementOperationComponentDepth =
			(this.context.enhancementOperationComponentDepth ?? 0) + 1;
		return withRenderCleanup(
			() =>
				renderComponentReference(
					this.context,
					component,
					this.parent,
					this.options,
					this.hasComponentAncestor
				),
			() => {
				this.context.enhancementOperationComponentDepth!--;
			}
		);
	}

	/** Serializes a compiler-proven root without its redundant outer component delimiter. */
	renderCompilerClosedRootComponent(component: ServerComponentReference): RenderValue<string> {
		return renderComponentReference(
			this.context,
			component,
			undefined,
			this.options,
			false,
			false,
			true
		);
	}

	/** Returns already serialized SSR output without reparsing it. */
	[exactSerializedSsrHtmlOperation](html: string): string {
		return html;
	}

	private renderProgramSegment(
		segment: readonly Child[] | ServerComponentReference
	): string | Promise<string> {
		if (Array.isArray(segment))
			return this.renderChildren(
				this.context,
				segment,
				this.parent,
				this.options,
				this.hasComponentAncestor
			);
		return renderComponentReference(
			this.context,
			segment as ServerComponentReference,
			this.parent,
			this.options,
			this.hasComponentAncestor,
			true
		);
	}
}
