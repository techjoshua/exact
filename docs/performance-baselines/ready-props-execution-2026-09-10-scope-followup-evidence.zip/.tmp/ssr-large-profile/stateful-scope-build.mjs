import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';
let code=fs.readFileSync(root+'direct-execution-integrated/server-entry.js','utf8');
assert.equal(createHash('sha256').update(code).digest('hex'),'2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18');
const start=code.indexOf('function executeDirectSsrComponent(');
const split=code.indexOf('\n\t\tconst frame = stateless ?',start);
const end=code.indexOf('\nfunction performanceNow()',split);
assert.ok(start>0&&split>start&&end>split);
const tail=code.slice(split,end);const suffix='\n\t});\n}';assert.ok(tail.endsWith(suffix));
const body=tail.slice(0,-suffix.length).replace(/^\t/gm,'');
code=code.slice(0,split)+`
  return executeStatefulComponentScope(context, contract, props, parent, options, sink, artifact, server, stateless);
 });
}
function executeStatefulComponentScope(context, contract, props, parent, options, sink, artifact, server, stateless) {${body}
}`+code.slice(end);
fs.mkdirSync(root+'stateful-scope',{recursive:true});fs.writeFileSync(root+'stateful-scope/server-entry.js',code);
const hash=createHash('sha256').update(code).digest('hex');console.log(hash);
let pressure=fs.readFileSync(root+'ready-props-split-pressure.mjs','utf8').replaceAll('ready-props-split-pressure','stateful-scope-pressure').replace("root+'ready-props-split/server-entry.js'","root+'stateful-scope/server-entry.js'");
fs.writeFileSync(root+'stateful-scope-pressure.mjs',pressure);
let screen=fs.readFileSync(root+'ready-props-split-screen.mjs','utf8');
screen=screen.replace("[['node','large'],['bun','assets']]","[['node','assets']]");
screen=screen.replace("variant==='split'?'ready-props-split':variant==='candidate'?'ready-props-stable'", "variant==='split'?'stateful-scope':variant==='candidate'?'ready-props-split'");
screen=screen.replace('a454621b5c878a28cbf574f54bc8b73d1cb026809ef24f421be9e61c6f13000d',hash).replace('99f76e4e06e41960c5a6da7a1a6669e197051160e5987f5ba6eefb17cbd9d3ba','a454621b5c878a28cbf574f54bc8b73d1cb026809ef24f421be9e61c6f13000d');
screen=screen.replaceAll('ready-props-split-screen','stateful-scope-screen').replaceAll('ready-props-split-worker','stateful-scope-worker');
fs.writeFileSync(root+'stateful-scope-screen.mjs',screen);
