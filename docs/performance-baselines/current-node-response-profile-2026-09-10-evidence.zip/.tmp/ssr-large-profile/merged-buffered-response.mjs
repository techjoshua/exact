import { attachSuppressedCleanupFailure } from '@exactjs/core';
import { AsyncProducedResponseBody } from "file:///C:/Users/techj/Projects/eXact/packages/server/dist/async-produced-response-body.js";
const utf8Encoder = new TextEncoder();
/** Identifies an eXact-owned response body that an adapter can consume without a Web stream. */
export const exactResponseBody = Symbol.for('@exactjs/server/response-body');
const responseTextDescriptor = { enumerable: true, get: readResponseText };
const responseStreamDescriptor = { enumerable: true, get: readResponseStream };
/** Shares lazy accessors across responses while each receiver retains its own single-consumer body. */
function readResponseText() {
    return this[exactResponseBody].toText();
}
/** Claims only the receiving response's stream, without allocating a getter closure per response. */
function readResponseStream() {
    return this[exactResponseBody].toReadableStream();
}
/** Creates a response whose buffered render is claimed only by the selected adapter path. */
export function createExactBufferedResponse(status, headers, body) {
    const source = new BufferedResponseBody(body);
    const response = source;
    response.status = status;
    response.headers = headers;
    Object.defineProperty(response, exactResponseBody, { value: source });
    Object.defineProperty(response, 'body', responseTextDescriptor);
    Object.defineProperty(response, 'stream', responseStreamDescriptor);
    return response;
}
/** Creates a response whose synchronous renderer runs only after an adapter claims the body. */
export function createExactProducedResponse(status, headers, produce) {
    const source = new ProducedResponseBody(produce);
    const response = {
        status,
        headers
    };
    Object.defineProperty(response, exactResponseBody, { value: source });
    Object.defineProperty(response, 'body', responseTextDescriptor);
    Object.defineProperty(response, 'stream', responseStreamDescriptor);
    return response;
}
/** Creates a response whose scheduled producer awaits transport backpressure. */
export function createExactAsyncProducedResponse(status, headers, produce) {
    const source = new AsyncProducedResponseBody(produce);
    const response = {
        status,
        headers,
        body: ''
    };
    Object.defineProperty(response, exactResponseBody, { value: source });
    Object.defineProperty(response, 'stream', responseStreamDescriptor);
    return response;
}
/** Returns an eXact-owned response body without observing a lazy stream getter. */
export function exactResponseBodyOf(response) {
    return response[exactResponseBody];
}
class BufferedResponseBody {
    get kind() { return 'buffered'; }
    #body;
    #text;
    #stream;
    constructor(body) {
        this.#body = body;
    }
    async writeTo(write) {
        const body = this.claim();
        if (typeof body === 'string') {
            const pending = write(body);
            if (pending)
                await pending;
            return;
        }
        for (const chunk of body) {
            const pending = write(chunk);
            if (pending)
                await pending;
        }
    }
    toText() {
        if (this.#text !== undefined)
            return this.#text;
        const body = this.claim();
        this.#text = typeof body === 'string' ? body : body.join('');
        return this.#text;
    }
    toReadableStream() {
        if (this.#stream)
            return this.#stream;
        const body = this.claim();
        const chunks = typeof body === 'string' ? undefined : body;
        let index = 0;
        this.#stream = new ReadableStream({
            pull(controller) {
                if (chunks ? index >= chunks.length : index > 0) {
                    controller.close();
                    return;
                }
                const chunk = chunks ? chunks[index++] : body;
                if (!chunks)
                    index++;
                controller.enqueue(utf8Encoder.encode(chunk));
            }
        }, { highWaterMark: 0 });
        return this.#stream;
    }
    toBlob() {
        const body = this.claim();
        return new Blob(typeof body === 'string' ? [body] : [...body]);
    }
    async cancel() {
        if (this.#stream) {
            await this.#stream.cancel();
            return;
        }
        this.#body = undefined;
    }
    claim() {
        if (this.#body === undefined)
            throw new TypeError('eXact response body was already claimed');
        const body = this.#body;
        this.#body = undefined;
        return body;
    }
}
class ProducedResponseBody {
    kind = 'produced';
    produce;
    release;
    signal;
    abort;
    completion;
    constructor(produce) {
        this.produce = produce;
    }
    retainRequestScope(release, signal) {
        if (this.release)
            throw new TypeError('eXact response body already owns a request scope');
        this.release = release;
        this.signal = signal;
        this.abort = () => {
            const reason = signal?.reason ?? new DOMException('eXact response body aborted', 'AbortError');
            void this.cancel(reason).catch((cleanup) => attachSuppressedCleanupFailure(reason, cleanup));
        };
        if (signal?.aborted)
            this.abort();
        else
            signal?.addEventListener('abort', this.abort, { once: true });
    }
    async writeTo(write) {
        const produce = this.claim();
        let pending;
        let failure;
        try {
            produce((chunk) => {
                if (pending) {
                    pending = pending.then(() => write(chunk));
                    return;
                }
                const result = write(chunk);
                if (result)
                    pending = Promise.resolve(result);
            });
            if (pending)
                await pending;
        }
        catch (error) {
            failure = { error };
            throw error;
        }
        finally {
            await this.finish(failure ? failure.error : 'eXact produced response complete', failure);
        }
    }
    writeSynchronously(write, environment) {
        const produce = this.claim();
        try {
            produce(write, environment);
        }
        catch (error) {
            const failure = { error };
            const completion = this.finish(error, failure);
            if (completion)
                return completion.then(() => {
                    throw error;
                });
            throw error;
        }
        return this.finish('eXact produced response complete');
    }
    toText() {
        this.assertNoRetainedScope('text');
        const produce = this.claim();
        let result = '';
        produce((chunk) => {
            result += chunk;
        });
        return result;
    }
    toReadableStream() {
        const produce = this.claim();
        const encoder = new TextEncoder();
        return new ReadableStream({
            start: async (controller) => {
                try {
                    produce((chunk) => controller.enqueue(encoder.encode(chunk)));
                    await this.finish('eXact produced response stream complete');
                    controller.close();
                }
                catch (error) {
                    await this.finish(error, { error });
                    controller.error(error);
                }
            },
            cancel: (reason) => this.finish(reason)
        });
    }
    toBlob() {
        this.assertNoRetainedScope('blob');
        const produce = this.claim();
        const chunks = [];
        produce((chunk) => chunks.push(chunk));
        return new Blob(chunks);
    }
    async cancel(reason) {
        this.produce = undefined;
        await this.finish(reason ?? 'eXact produced response cancelled');
    }
    claim() {
        if (!this.produce)
            throw new TypeError('eXact response body was already claimed');
        const produce = this.produce;
        this.produce = undefined;
        return produce;
    }
    assertNoRetainedScope(target) {
        if (this.release)
            throw new TypeError(`Request-owned eXact response body requires asynchronous ${target} consumption`);
    }
    finish(reason, failure) {
        if (this.completion)
            return this.completion;
        const release = this.release;
        this.release = undefined;
        if (this.abort)
            this.signal?.removeEventListener('abort', this.abort);
        this.abort = undefined;
        this.signal = undefined;
        if (!release)
            return undefined;
        this.completion = release(reason).catch((cleanup) => {
            if (failure) {
                attachSuppressedCleanupFailure(failure.error, cleanup);
                return;
            }
            throw cleanup;
        });
        return this.completion;
    }
}
//# sourceMappingURL=response-body.js.map