import fs from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
let s=fs.readFileSync('packages/server/dist/response-body.js','utf8');
s=s.replace("'./async-produced-response-body.js'",JSON.stringify(pathToFileURL(resolve('packages/server/dist/async-produced-response-body.js')).href));
const original=`const source = new BufferedResponseBody(body);
    const response = {
        status,
        headers
    };`;
assert.equal(s.split(original).length-1,1);
s=s.replace(original,`const source = new BufferedResponseBody(body);
    const response = source;
    response.status = status;
    response.headers = headers;`);
const a=s.indexOf('class BufferedResponseBody {'),b=s.indexOf('class ProducedResponseBody {');
let cls=s.slice(a,b).replace("kind = 'buffered';", "get kind() { return 'buffered'; }");
for(const field of ['body','text','stream'])cls=cls.replace(`    ${field};`,`    #${field};`).replaceAll(`this.${field}`,`this.#${field}`);
s=s.slice(0,a)+cls+s.slice(b);
fs.writeFileSync('.tmp/ssr-large-profile/merged-buffered-response.mjs',s);
