import fs from 'node:fs';import {spawnSync} from 'node:child_process';
const rows=[];for(const runtime of ['node','bun'])for(let round=0;round<4;round++)for(const variant of round%2?['candidate','current']:['current','candidate']){
 const path=variant==='current'?'packages/server/dist/response-body.js':'.tmp/ssr-large-profile/merged-buffered-response.mjs';
 const r=spawnSync(runtime,['.tmp/ssr-large-profile/merged-buffered-worker.mjs',path],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr+r.stdout);const row={runtime,round,variant,...JSON.parse(r.stdout)};rows.push(row);console.log(runtime,round,variant,row.us.toFixed(3));fs.writeFileSync('.tmp/ssr-large-profile/merged-buffered-results.json',JSON.stringify(rows,null,2));
}
