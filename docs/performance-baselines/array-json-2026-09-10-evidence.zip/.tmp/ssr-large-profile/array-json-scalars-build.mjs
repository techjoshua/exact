import fs from 'node:fs/promises';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'array-json-scalars',{recursive:true});
for(const file of ['server-entry.js','bun-server-entry.js']){
 let source=await fs.readFile(root+'array-json/'+file,'utf8');
 const old='if(!Array.isArray(value))return JSON.stringify(value);';
 if(source.split(old).length!==2)throw Error('Missing leaf branch');
 source=source.replace(old,`if(value===null)return 'null';
 if(typeof value==='string')return auditJsonStringEscape.test(value)?JSON.stringify(value):'"'+value+'"';
 if(typeof value==='number'||typeof value==='boolean')return String(value);
 if(!Array.isArray(value))return JSON.stringify(value);`);
 source+='\nconst auditJsonStringEscape=/["\\\\\\u0000-\\u001f\\ud800-\\udfff]/;\n';
 await fs.writeFile(root+'array-json-scalars/'+file,source);
}
for(const suffix of ['check.mjs','values.mjs','run.mjs']){
 const source=await fs.readFile(root+'array-json-'+suffix,'utf8');
 await fs.writeFile(root+'array-json-scalars-'+suffix,source.replaceAll('array-json','array-json-scalars'));
}
