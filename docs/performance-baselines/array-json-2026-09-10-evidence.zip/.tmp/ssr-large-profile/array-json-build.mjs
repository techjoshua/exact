import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'array-json',{recursive:true});
for(const file of ['server-entry.js','bun-server-entry.js']){
 let source=await fs.readFile(root+'conditional-emission/'+file,'utf8');
 const ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
 const serializer=ast.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text==='serializeJson');
 const expression=serializer.body.statements[0].expression.getText(ast);
 const escaped=expression.replace('JSON.stringify(payload, replacer)','auditArrayJson(payload)');
 const branch='if (!reactiveCollections) return serializeJson(payload);';
 if(source.split(branch).length!==2)throw Error('Unexpected validated serialization branch');
 source=source.replace(branch,'if (!reactiveCollections) return auditEscapedArrayJson(payload);');
 source+=`\nfunction auditEscapedArrayJson(payload){return ${escaped};}
function auditArrayJson(value){
 if(!Array.isArray(value))return JSON.stringify(value);
 let json='[';
 for(let i=0;i<value.length;i++){if(i)json+=',';json+=auditArrayJson(value[i])??'null';}
 return json+']';
}\n`;
 await fs.writeFile(root+'array-json/'+file,source);
}
for(const suffix of ['check.mjs','run.mjs']){
 const source=await fs.readFile(root+'writer-output-pool-'+suffix,'utf8');
 await fs.writeFile(root+'array-json-'+suffix,source.replaceAll('writer-output-pool','array-json'));
}
