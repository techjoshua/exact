import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const root='.tmp/ssr-large-profile/';const modules=[];
for(const name of ['conditional-emission','array-json-scalars']){
 const file=root+'array-json-scalars/'+name+'-values.js';
 await fs.writeFile(file,(await fs.readFile(root+name+'/server-entry.js','utf8'))+'\nexport function auditPayload(state,options={}){return renderHydrationScript({state,...options});}\n');
 modules.push(await import(pathToFileURL(resolve(file))));
}
let seed=731;const rand=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/4294967296);
const atoms=[null,true,false,0,-0,1.5,1e30,'','</script><script>alert(1)</script>','a'+String.fromCharCode(0,0x2028,0x2029,0xd800)+'🚀'];
function value(depth){if(!depth||rand()<0.5)return atoms[Math.floor(rand()*atoms.length)];if(rand()<0.7)return Array.from({length:Math.floor(rand()*5)},()=>value(depth-1));return {a:value(depth-1),b:value(depth-1)};}
const cases=Array.from({length:200},()=>({state:{value:value(5)}}));
const cyclic=[];cyclic.push(cyclic);
for(const state of [{value:cyclic},{value:Infinity},{value:NaN},{get value(){throw Error('Getter invoked');}}])cases.push({state});
for(const options of [{maxHydrationBytes:10},{maxHydrationDepth:1},{maxHydrationNodes:1}])cases.push({state:{value:[[1,2],'<script>']},options});
function result(mod,{state,options}){try{return {html:mod.auditPayload(state,options)};}catch(e){return {error:e.name,message:e.message};}}
for(const c of cases)assert.deepEqual(result(modules[1],c),result(modules[0],c));
const output={runtime:process.versions.bun?'bun':'node',matched:cases.length};
await fs.writeFile(root+'array-json-scalars/'+output.runtime+'-value-checks.json',JSON.stringify(output));console.log(output);
