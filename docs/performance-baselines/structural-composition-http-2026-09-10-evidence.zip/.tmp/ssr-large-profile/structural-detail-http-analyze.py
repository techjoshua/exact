import json
import statistics
from pathlib import Path

root=Path('.tmp/ssr-large-profile/structural-detail')
rows=json.loads((root/'http.json').read_text())
assert len(rows)==72
summary=[]
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  selected=[row for row in rows if row['runtime']==runtime and row['mode']==mode]
  assert len(selected)==18
  means={variant:statistics.mean(row['rps'] for row in selected if row['variant']==variant) for variant in ['baseline','compiled','react']}
  pairs=[]
  for block in range(6):
   values={row['variant']:row['rps'] for row in selected if row['block']==block}
   pairs.append((values['compiled']/values['baseline']-1)*100)
  total=sum(stage['valid'] for row in selected for result in row['results'] for stage in result['stages'])
  errors=sum(stage['errors'] for row in selected for result in row['results'] for stage in result['stages'])
  result={'runtime':runtime,'mode':mode,'rps':means,'meanChangePercent':(means['compiled']/means['baseline']-1)*100,'pairedChangePercent':pairs,'medianPairedChangePercent':statistics.median(pairs),'positivePairs':sum(value>0 for value in pairs),'candidateVsReactPercent':(means['compiled']/means['react']-1)*100,'valid':total,'errors':errors}
  summary.append(result);print(json.dumps(result))
(root/'http-summary.json').write_text(json.dumps(summary,indent=2))
