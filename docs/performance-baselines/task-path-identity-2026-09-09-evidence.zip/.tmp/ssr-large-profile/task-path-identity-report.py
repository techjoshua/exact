import pathlib,json,hashlib,zipfile
d=pathlib.Path('.tmp/ssr-large-profile')
result=json.loads((d/'task-path-identity-results.json').read_text(encoding='utf-8'))
assert len(result['summary'])==5 and len(result['checks'])==15
files=[d/'task-path-identity-audit.mjs',d/'task-path-identity-results.json',d/'task-path-identity-report.py',pathlib.Path('docs/performance-baselines/task-path-identity-2026-09-09.md')]
files += [pathlib.Path('native/typescript-go/overlay/internal/exactcompiler')/name for name in ['tasks.go','contracts.go','callable_direct_effects.go','callable_effect_resolution.go']]
manifest={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=pathlib.Path('docs/performance-baselines/task-path-identity-2026-09-09-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p).replace('\\','/'))
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified five cases, 15 assertions, and archive hashes.')
