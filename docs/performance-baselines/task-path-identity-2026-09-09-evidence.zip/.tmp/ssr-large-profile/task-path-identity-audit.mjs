import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const cases=[
 {name:'literal-dot',write:'this.state["page.title"]="ready";',read:'this.state["page.title"]'},
 {name:'nested-title',write:'this.state.page.title="ready";',read:'this.state.page.title'},
 {name:'literal-star',write:'this.state.page["*"]="ready";',read:'this.state.page["*"]'},
 {name:'computed-read',write:'this.state.page.title="ready";',read:'this.state.page[props.field]'},
 {name:'both-writes',write:'this.state["page.title"]="literal";this.state.page.title="nested";',read:'this.state["page.title"]+this.state.page.title'}
];
const requests=cases.map(c=>({id:'task-path-identity-'+c.name+'.tsx',kind:'compile',target:'server',source:`
import {TaskContext,type Component} from '@exactjs/core';
export function Document(this:Component<{"page.title":string;page:{title:string;"*":string}}>,props:{field:'title'|'*'}){
this.state["page.title"]='Initial';this.state.page={title:'Initial','*':'Initial'};
const load=async (_task:TaskContext=TaskContext.server().blocking())=>{await Promise.resolve();${c.write}};
load();return ()=><html><head><title>{${c.read}}</title></head><body>Body</body></html>;
}`}));
const executable='.tmp/native-compiler/exactc.exe';
const run=spawnSync(executable,[],{input:requests.map(r=>JSON.stringify(r)).join('\n')+'\n',encoding:'utf8',windowsHide:true,maxBuffer:16*1024*1024});
if(run.status!==0)throw Error(run.stderr||run.stdout);
const responses=run.stdout.trim().split('\n').map(JSON.parse);
if(responses.length!==cases.length)throw Error('Incomplete responses');
const summary=responses.map((r,i)=>({name:cases[i].name,error:r.error,diagnostics:r.diagnostics,reads:r.analysis?.stateReads,writes:r.analysis?.tasks.flatMap(t=>t.writes)}));
const checks=[];
function check(name,value){assert.ok(value,name);checks.push(name);}
for(const row of summary){check(row.name+': compiled',!row.error);check(row.name+': diagnostics characterized',row.name==='literal-star'?row.diagnostics.some(d=>d.code==='EXACT2001'):row.diagnostics.length===0);}
check('literal dotted read retains one segment',summary[0].reads.some(r=>r.path.length===1&&r.path[0]==='page.title'));
check('nested read retains two segments',summary[1].reads.some(r=>r.path.length===2&&r.path[0]==='page'&&r.path[1]==='title'));
check('distinct writes flatten to identical labels',summary[0].writes[0].path===summary[1].writes[0].path);
check('computed read remains broad',summary[3].reads.some(r=>r.confidence==='broad'));
check('two writes collapse into one task effect',summary[4].writes.length===1);
writeFileSync('.tmp/ssr-large-profile/task-path-identity-results.json',JSON.stringify({compilerSha256:createHash('sha256').update(readFileSync(executable)).digest('hex'),requests,responses,summary,checks},null,2));
console.log(JSON.stringify(summary,null,2));
