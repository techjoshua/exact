import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Writable } from 'node:stream';
import { once } from 'node:events';
import { DirectWriter } from './direct-writer.mjs';
import { readFile } from 'node:fs/promises';
import { renderParticipantToSink } from './hoisted-buffers.mjs';
import { renderParticipantToSink as originalRender } from '../../framework-comparison/participants/exact/dist-server/server-entry.js';

for (const threshold of [2048, 4096, 8192]) {
  test(`${threshold}: byte identity, Unicode, thresholds, retained buffers`, () => {
    for (const size of [4, 7, threshold]) {
      const chunks = [];
      const writer = new DirectWriter({ write(value) { chunks.push(value); return true; } }, { flushThresholdBytes: size });
      const values = ['<head></head>', 'a'.repeat(threshold - 1), '\ud83d', '', '\ude42', Buffer.from('<b>'), '水é'.repeat(10000), '</b>', '\ud800'];
      for (const value of values) writer.write(value);
      writer.finish();
      const output = Buffer.concat(chunks.map(value => typeof value === 'string' ? Buffer.from(value) : value));
      assert.equal(output.toString(), values.map(String).join('').replace(/\ud800$/, '\ufffd'));
      assert.equal(writer.buffer, undefined);
    }
  });

  test(`${threshold}: real Writable backpressure resumes between atomic writes`, async () => {
    const chunks = [];
    const destination = new Writable({ highWaterMark: 16, write(value, _encoding, callback) {
      chunks.push(value); setImmediate(callback);
    } });
    const writer = new DirectWriter(destination, { flushThresholdBytes: threshold });
    let pauses = 0;
    for (let i = 0; i < 20; i++) {
      if (!writer.write(`${i}:` + 'x'.repeat(threshold))) { pauses++; await once(destination, 'drain'); writer.resume(); }
    }
    if (!writer.finish()) { await once(destination, 'drain'); writer.resume(); }
    destination.end();
    await once(destination, 'finish');
    assert.ok(pauses > 0);
    assert.equal(Buffer.concat(chunks).toString(), Array.from({ length: 20 }, (_, i) => `${i}:` + 'x'.repeat(threshold)).join(''));
  });

  test(`${threshold}: compiled fixture produces unchanged HTML and hydration`, async () => {
    const data = JSON.parse(await readFile('.tmp/ssr-buffer-sizes/data.json', 'utf8'));
    let expected = '';
    originalRender(data, '/incidents/inc-101', value => expected += value, Buffer.byteLength);
    const chunks = [];
    const writer = new DirectWriter({ write(value) { chunks.push(Buffer.from(value)); return true; } }, { flushThresholdBytes: threshold });
    const publish = value => writer.write(value);
    publish.static = publish;
    renderParticipantToSink(data, '/incidents/inc-101', publish, Buffer.byteLength);
    writer.finish();
    assert.equal(Buffer.concat(chunks).toString(), expected);
  });
}

test('destruction releases staging and prevents further writes', () => {
  let destroyed = 0;
  const error = new Error('transport failed');
  const writer = new DirectWriter({ write() { return true; }, destroy(reason) { assert.equal(reason, error); destroyed++; } });
  writer.write('pending');
  writer.destroy(error);
  writer.destroy(error);
  assert.equal(writer.buffer, undefined);
  assert.equal(writer.tail, '');
  assert.equal(destroyed, 1);
  assert.throws(() => writer.write('later'), /destroyed/);
});

test('hybrid fills small spans and bypasses large values', () => {
  const chunks = [];
  const writer = new DirectWriter({ write(value) { chunks.push(value.toString()); return true; } }, { flushThresholdBytes: 8 });
  writer.write('123456'); writer.write('abcdef'); writer.write('x'.repeat(20)); writer.finish();
  assert.deepEqual(chunks, ['123456ab', 'cdef', 'x'.repeat(20)]);
});
