import { writeFile, readFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
import { DirectWriter } from './direct-writer.mjs';
import { renderParticipantToSink } from './hoisted-buffers.mjs';

const data = JSON.parse(await readFile('.tmp/ssr-buffer-sizes/data.json', 'utf8'));
const actual = [];
const capture = value => actual.push(value);
capture.static = capture;
renderParticipantToSink(data, '/incidents/inc-101', capture, Buffer.byteLength);
const cases = {
  'compiled-spans': actual,
  'many-small-64k': Array.from({ length: 512 }, (_, i) => i % 2 ? 'x'.repeat(112) + 'é水🙂' : Buffer.from('<div>' + 'y'.repeat(112) + '</div>')),
  'overflowing-values': ['x'.repeat(6000), 'é'.repeat(2500), Buffer.from('s'.repeat(5000)), '水'.repeat(1700)],
  'large-single-1m': ['<main>', 'x'.repeat(1024 * 1024), '</main>'],
  'large-many-1m': Array.from({ length: 8192 }, (_, i) => i % 2 ? 'x'.repeat(128) : Buffer.from('y'.repeat(128)))
};
const modes = [2048, 4096, 8192];
const results = [];
for (const [name, spans] of Object.entries(cases)) {
  const expected = Buffer.byteLength(spans.map(String).join(''));
  const iterations = expected > 200000 ? 100 : 2000;
  function sample(mode, count) {
    let writes = 0, bytes = 0;
    const destination = { write(value) {
      // Include UTF-8 materialization for bypassed strings, without socket syscalls.
      const buffer = typeof value === 'string' ? Buffer.from(value) : value;
      writes++; bytes += buffer.length; return true;
    } };
    const start = performance.now();
    for (let i = 0; i < count; i++) {
      const writer = new DirectWriter(destination, { flushThresholdBytes: mode });
      for (const value of spans) writer.write(value);
      writer.finish();
    }
    const nsPerOperation = (performance.now() - start) * 1e6 / count;
    assert.equal(bytes, expected * count);
    return { nsPerOperation, writesPerOperation: writes / count };
  }
  for (const mode of modes) sample(mode, 200);
  for (let round = 0; round < 12; round++) for (const mode of round % 2 ? [...modes].reverse() : modes)
    results.push({ name, thresholdBytes: mode, expectedBytes: expected, iterations, round, ...sample(mode, iterations) });
}
await writeFile('.tmp/ssr-buffer-sizes/cpu.json', JSON.stringify(results, null, 2));
for (const name of Object.keys(cases)) for (const mode of modes) {
  const rows = results.filter(r => r.name === name && r.thresholdBytes === mode);
  console.log(name, mode, Math.round(rows.reduce((sum, r) => sum + r.nsPerOperation, 0) / rows.length), rows[0].writesPerOperation);
}
