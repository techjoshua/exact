import pathlib,json,hashlib,zipfile
root=pathlib.Path('.tmp/ssr-large-profile');d=root/'direct-publication'
for runtime in ['node','bun']:
 rows=json.loads((d/f'{runtime}.json').read_text(encoding='utf-8'))
 assert len(rows)==2 and all(r['early'][0]['reason']=='head' and sorted(r['disposedIndices'])==[1,2] for r in rows)
files=list(d.glob('*.mjs'))+list(d.glob('*.json'))+[root/'direct-publication-build.mjs',root/'direct-publication-audit.mjs',root/'direct-publication-report.py',root/'direct-scope/direct-writer-siblings.mjs',pathlib.Path('docs/performance-baselines/direct-publication-2026-09-09.md')]
manifest={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=pathlib.Path('docs/performance-baselines/direct-publication-2026-09-09-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p).replace('\\','/'))
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified four publication cases and evidence hashes.')
