import {readFileSync,writeFileSync,mkdirSync,copyFileSync} from 'node:fs';
const prior='.tmp/ssr-large-profile/direct-scope/',dir='.tmp/ssr-large-profile/direct-publication/';
mkdirSync(dir,{recursive:true});
let source=readFileSync(prior+'direct-writer-siblings.mjs','utf8');
function replace(before,after){if(source.split(before).length!==2)throw Error('Missing unique site: '+before);source=source.replace(before,after);}
replace("if(context.experimentalSink&&!((boundary.documentProbe", "if(context.experimentalSink&&(context.markers||(boundary.hasComponentAncestor&&publication?.kind==='resumption'&&context.resumptionCapture===undefined))&&!((boundary.documentProbe");
replace('function appendSharedSink(context,sink,text){','function appendSharedSink(context,sink,text){\n if(sink.write){sink.write(text);return;}');
replace('return withRenderCleanup(()=>executeDirectWriter(invocation,output),()=>leaveHost(context,entered.tag));',`return withRenderCleanup(()=>mapRenderValue(executeDirectWriter(invocation,output),value=>{
  if(host==='head')output.sink.flush?.('head');
  return value;
 }),()=>leaveHost(context,entered.tag));`);
replace('if(rendered instanceof Promise)return rendered.then(html=>finishDirectDeferred(output,html,closing,next));',`if(rendered instanceof Promise){
  output.sink.flush?.('await');
  return rendered.then(html=>finishDirectDeferred(output,html,closing,next));
 }`);
source+='\nexport {renderDirectWriter,createSsrContext,SsrOperationTarget,renderChildren,createPreparedServerComponentReference,prepareCompiledRenderProgram,createPreparedServerRenderProgram};\n';
writeFileSync(dir+'entry.mjs',source);
copyFileSync(prior+'direct-writer-real-siblings-fixture.mjs',dir+'fixture.mjs');
