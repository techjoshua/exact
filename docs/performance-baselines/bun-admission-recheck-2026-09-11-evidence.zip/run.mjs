import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync} from 'node:fs';
const steps=[];const root='.tmp/bun-scheduling-current';
for(const mode of ['string','stream']){
 const step={mode,startedAt:new Date().toISOString()};steps.push(step);const save=()=>writeFileSync(root+'/execution.json',JSON.stringify(steps,null,2));save();
 const log=openSync(root+'/'+mode+'.log','w');console.log('START '+mode);
 try{await new Promise((yes,no)=>{const child=spawn(process.execPath,[root+'/runner.mjs',root+'/plan.json',root+'/'+mode+'.json','bun'],{env:{...process.env,NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:mode},windowsHide:true,stdio:['ignore',log,log]});step.pid=child.pid;save();child.once('error',no);child.once('exit',code=>{step.code=code;code===0?yes():no(Error(mode+' failed '+code));});});}finally{closeSync(log);step.endedAt=new Date().toISOString();save();}console.log('DONE '+mode);
}
