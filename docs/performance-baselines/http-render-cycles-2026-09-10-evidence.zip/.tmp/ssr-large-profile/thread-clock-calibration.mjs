import {performance} from 'node:perf_hooks';
import {setPriority} from 'node:os';
import {writeFileSync} from 'node:fs';
setPriority(0,10);
for(let i=0;i<10000;i++)process.threadCpuUsage();
const deltas=new Map();let previous=process.threadCpuUsage(),zero=0;const start=performance.now();
for(let i=0;i<200000;i++){const next=process.threadCpuUsage();const diff=next.user+next.system-previous.user-previous.system;if(diff===0)zero++;else deltas.set(diff,(deltas.get(diff)??0)+1);previous=next;}
const elapsed=performance.now()-start;
const segments=[];for(const targetMs of [1,5,20,100]){const c=process.threadCpuUsage(),t=performance.now();let n=0;while(performance.now()-t<targetMs)n++;const end=performance.now(),d=process.threadCpuUsage(c);segments.push({targetMs,wallMs:end-t,cpuUs:d.user+d.system,n});}
const result={node:process.version,calls:200000,zero,elapsedMs:elapsed,perCallUs:elapsed*1000/200000,positiveDeltas:[...deltas].sort((a,b)=>a[0]-b[0]),segments};
writeFileSync('.tmp/ssr-large-profile/thread-clock-calibration.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
