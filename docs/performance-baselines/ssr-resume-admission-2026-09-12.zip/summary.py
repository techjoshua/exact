import json
from pathlib import Path
for p in Path('.tmp/ssr-resume').glob('*.json'):
 d=json.loads(p.read_text())
 if not isinstance(d,dict) or 'blocks' not in d: continue
 print(p.name)
 for b in d['blocks']:
  ss=[r['stages'][-1] for r in b['results']]
  print(b['id'],round(sum(s['validRps'] for s in ss)),[s['distributions']['responseMs']['p99'] for s in ss],b['telemetry'][-1]['value'].get('resumeStats'))
