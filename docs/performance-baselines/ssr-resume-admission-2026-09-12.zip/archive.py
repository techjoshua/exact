from pathlib import Path
import json,zipfile
p=Path('.tmp/ssr-resume');rows=json.loads(p.joinpath('summary.json').read_text());assert len(rows)==32 and all(r['errors']==0 and r['invalid']==0 for r in rows)
for name in ['current','resume','both','confirm-string-both','confirm-string-current','confirm-stream-both','confirm-stream-current','public-hook']:
 d=json.loads(p.joinpath(name+'.json').read_text());assert d['complete'] and len(d['blocks'])==4
for r in rows:
 if r['capture']=='confirm-string-current' and r['framework']=='react':print('Confirmation React',r['rps'])
f=Path('docs/performance-baselines/ssr-resume-admission-2026-09-12.md');s=f.read_text();rates=[r['rps'] for r in rows if r['capture']=='confirm-string-current' and r['framework']=='react'];f.write_text(s.replace('See raw capture',' / '.join(f'{round(x):,}' for x in rates)))
p.joinpath('verification.json').write_text(json.dumps({'source':'33b32e89','completeCaptures':8,'participantBlocks':32,'errors':0,'invalidResponses':0,'taskOwnedProcessesRemaining':0,'productionChanges':False},indent=2))
with zipfile.ZipFile('docs/performance-baselines/ssr-resume-admission-2026-09-12.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(p.iterdir()):
  if f.is_file():z.write(f,f.name)
