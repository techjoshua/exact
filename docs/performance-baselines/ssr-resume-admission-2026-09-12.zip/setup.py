from pathlib import Path
import json
p=Path('.tmp/ssr-resume');s=Path('.tmp/ssr-data-path/worker.mjs').read_text()
s=s.replace("import { Readable }", "import { AdaptiveRequestGate } from '../../framework-adapters/node-adapter/dist/requests/adaptive-gate.js';\nimport { createNodeRenderScheduler } from '@exactjs/node-adapter';\nimport { Readable }")
pos=s.index("const documentOptions")
s=s[:pos]+'''const resumePolicy = process.env.RESUME_POLICY ?? 'current';
const resumeGate = new AdaptiveRequestGate();
const enqueueResume = createNodeRenderScheduler();
const resumeStats = { requests: 0, checks: 0, beforeFetchYields: 0, afterFetchYields: 0, queueMs: 0 };
function observeNodeResume(response, signal, work) {
 if (resumePolicy === 'current') return work();
 resumeStats.requests++;
 const epoch = resumeGate.observeRequest();
 if (epoch !== undefined) {
  const completed = () => {response.off('finish', completed);response.off('close', completed);if(response.writableFinished)resumeGate.observeCompletion(epoch);};
  response.once('finish',completed);response.once('close',completed);
 }
 if (resumePolicy === 'both' && resumeGate.shouldSchedule()) {resumeStats.beforeFetchYields++;return enqueueResume(signal).then(work);}
 return work();
}
function scheduleDataReady(signal) {
 if (resumePolicy === 'current') return;
 resumeStats.checks++;
 if (!resumeGate.shouldSchedule()) return;
 resumeStats.afterFetchYields++;
 const start=performance.now();
 return enqueueResume(signal).then(()=>{resumeStats.queueMs+=performance.now()-start;signal?.throwIfAborted();});
}

'''+s[pos:]
s=s.replace('participant.handle(request, response, signal),','observeNodeResume(response, signal, () => participant.handle(request, response, signal)),')
s=s.replace("{ adaptive: process.env.DATA_PATH_POLICY !== 'off' }", "{ adaptive: resumePolicy === 'current' }")
needle="\t\t\t\tif (renderMode === 'stream') {"
assert s.count(needle)>=1
s=s.replace(needle,"\t\t\t\tif (id === 'exact') { const pending = scheduleDataReady(signal); if(pending) await pending; }\n"+needle,1)
s=s.replace('\t\trequestErrors: requestErrors.snapshot(),', '\t\tresumePolicy, resumeStats: {...resumeStats},\n\t\trequestErrors: requestErrors.snapshot(),')
p.joinpath('worker.mjs').write_text(s)
r=Path('.tmp/ssr-data-path/capacity.mjs').read_text().replace('.tmp/ssr-data-path/worker.mjs','.tmp/ssr-resume/worker.mjs')
p.joinpath('capacity.mjs').write_text(r)
p.joinpath('plan.json').write_bytes(Path('.tmp/ssr-data-path/plan.json').read_bytes())

