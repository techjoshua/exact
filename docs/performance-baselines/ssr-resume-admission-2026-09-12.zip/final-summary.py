from pathlib import Path
import json
rows=[]
for p in Path('.tmp/ssr-resume').glob('*.json'):
 d=json.loads(p.read_text())
 if not isinstance(d,dict) or 'blocks' not in d:continue
 for b in d['blocks']:
  ss=[r['stages'][-1] for r in b['results']]
  row={'capture':p.stem,'population':b['population']+1,'framework':b['id'],'rps':sum(s['validRps'] for s in ss),'p99MinMs':min(s['distributions']['responseMs']['p99'] for s in ss),'p99MaxMs':max(s['distributions']['responseMs']['p99'] for s in ss),'errors':sum(s['errors'] for s in ss),'invalid':sum(s['invalid'] for s in ss),'resumeStats':b['telemetry'][-1]['value'].get('resumeStats')}
  rows.append(row)
  if b['id']=='exact':print(p.stem,round(row['rps']),row['p99MinMs'],row['p99MaxMs'])
Path('.tmp/ssr-resume/summary.json').write_text(json.dumps(rows,indent=2))
