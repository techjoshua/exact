from pathlib import Path
p=Path('.tmp/ssr-resume');s=p.joinpath('worker.mjs').read_text()
s=s.replace("if (id === 'exact') { const pending = scheduleDataReady(signal); if(pending) await pending; }", "const readyOptions = id === 'exact' && resumePolicy !== 'current' ? {...documentOptions, scheduleRender: () => scheduleDataReady(signal)} : documentOptions;")
s=s.replace("\t\t\t\t\t\tdocumentOptions,\n\t\t\t\t\t\tsignal", "\t\t\t\t\t\treadyOptions,\n\t\t\t\t\t\tsignal",1)
s=s.replace("\t\t\t\t\t\trenderParticipant\n", "\t\t\t\t\t\trenderParticipant, readyOptions\n",1)
s=s.replace('async function createExactBufferedDocument(initialData, path, payloadTarget, renderParticipant)', 'async function createExactBufferedDocument(initialData, path, payloadTarget, renderParticipant, readyOptions = documentOptions)')
s=s.replace('renderParticipant(initialData, path, documentOptions)', 'renderParticipant(initialData, path, readyOptions)')
p.joinpath('hook-worker.mjs').write_text(s)
r=p.joinpath('capacity.mjs').read_text().replace('.tmp/ssr-resume/worker.mjs','.tmp/ssr-resume/hook-worker.mjs');p.joinpath('hook-capacity.mjs').write_text(r)
