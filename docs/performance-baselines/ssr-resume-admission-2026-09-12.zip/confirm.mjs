import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync} from 'node:fs';
const rows=[];
for(const mode of ['string','stream'])for(const policy of ['both','current']){
 const name=`confirm-${mode}-${policy}`;
 console.log('START '+name);const row={mode,policy,startedAt:new Date().toISOString()};rows.push(row);
 const fd=openSync(`.tmp/ssr-resume/${name}.log`,'w');
 try{await new Promise((yes,no)=>{const c=spawn(process.execPath,['.tmp/ssr-resume/capacity.mjs','.tmp/ssr-resume/plan.json',`.tmp/ssr-resume/${name}.json`,'node'],{windowsHide:true,env:{...process.env,NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:mode,RESUME_POLICY:policy},stdio:['ignore',fd,fd]});row.pid=c.pid;c.once('error',no);c.once('exit',code=>{row.code=code;code===0?yes():no(Error(policy+' failed'));});});}
 finally{closeSync(fd);row.endedAt=new Date().toISOString();writeFileSync('.tmp/ssr-resume/confirmation-execution.json',JSON.stringify(rows,null,2));}console.log('DONE '+name);
}
