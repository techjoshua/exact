from pathlib import Path
p=Path('.tmp/ssr-resume');s=p.joinpath('run.mjs').read_text()
s=s.replace("for(const policy of ['current','resume','both']){", "for(const mode of ['string','stream'])for(const policy of ['both','current']){\n const name=`confirm-${mode}-${policy}`;")
s=s.replace("'START '+policy", "'START '+name").replace("'DONE '+policy", "'DONE '+name").replace('const row={policy,','const row={mode,policy,')
s=s.replace('${policy}.log','${name}.log').replace('${policy}.json','${name}.json').replace("COMPARISON_SSR_RENDER_MODE:'string'",'COMPARISON_SSR_RENDER_MODE:mode').replace('execution.json','confirmation-execution.json')
p.joinpath('confirm.mjs').write_text(s)
