import {spawn} from 'node:child_process';
import {openSync,closeSync,readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
const root=resolve('.'),dir=resolve('.tmp/node-misses');const steps=JSON.parse(readFileSync(dir+'/completion-checks.json')); 
process.env.npm_execpath='C:/Program Files/nodejs-v26.8.1/node_modules/npm/bin/npm-cli.js';
const completed=JSON.parse(readFileSync(dir+'/final-execution.json'));if(completed.length!==2||completed.some(s=>s.code!==0))throw Error('Measurements incomplete');
async function run(name,exe,args){
 if(steps.some(s=>s.name===name&&s.code===0)){console.log('RETAIN '+name);return;}
 const nodeEnv=['packages','comparison-tests','test-types','docs-types','docs-tests'].includes(name)?'test':'production';
 const step={name,args,nodeEnv,startedAt:new Date().toISOString()};steps.push(step);
 const save=()=>writeFileSync(dir+'/completion-checks.json',JSON.stringify(steps,null,2));save();
 console.log('START '+name);const log=openSync(dir+'/completion-'+name+'.log','w');
 try{await new Promise((yes,no)=>{const child=spawn(exe,args,{cwd:root,env:{...process.env,NODE_ENV:nodeEnv},windowsHide:true,stdio:['ignore',log,log]});step.pid=child.pid;save();child.once('error',no);child.once('exit',(code,signal)=>{step.code=code;step.signal=signal;code===0?yes():no(Error(name+' failed '+(code??signal)));});});}
 finally{closeSync(log);step.endedAt=new Date().toISOString();save();}console.log('DONE '+name);
}
const npm='C:/Program Files/nodejs-v26.8.1/node_modules/npm/bin/npm-cli.js';
await run('architecture',process.execPath,['scripts/check-source-architecture.mjs']);
await run('jsdoc',process.execPath,['scripts/check-jsdoc.mjs']);
await run('abi',process.execPath,['scripts/check-compiled-abi.mjs']);
await run('platform',process.execPath,[npm,'run','check:platform-boundaries']);
await run('package-contents',process.execPath,['scripts/check-package-contents.mjs']);
await run('docs-types',process.execPath,[npm,'run','typecheck','-w','@exactjs/docs']);
await run('docs-tests',process.execPath,[npm,'run','test','-w','@exactjs/docs']);
await run('docs-build',process.execPath,[npm,'run','build','-w','@exactjs/docs']);
await run('docs-browser',process.execPath,[dir+'/verify-docs.mjs']);
await run('diff','git',['diff','--check']);
