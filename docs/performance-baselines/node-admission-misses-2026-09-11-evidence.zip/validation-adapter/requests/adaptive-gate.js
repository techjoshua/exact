import { monitorEventLoopDelay, performance } from 'node:perf_hooks';
/**
 * Node-owned admission controller. Lag triggers a trial; completed-response capacity and lag
 * relative to surrounding immediate windows decide whether to retain it. Handler duration is
 * deliberately not treated as client latency because it excludes time before Node dispatch.
 * Sparse traffic creates no histogram or timer. Idle monitoring disables and releases its timer.
 */
export class AdaptiveRequestGate {
    delay;
    timer;
    lastRequest = -Infinity;
    recentRequests = 0;
    requests = 0;
    completions = 0;
    epoch = 0;
    started = 0;
    enabled = false;
    highSamples = 0;
    phase = 'baseline';
    nextPhase = 'trial';
    until = 0;
    cooldown = 0;
    backoff = 2000;
    baseline;
    trial;
    controlRate = 0;
    controlLag = 0;
    /** Begins one request; a returned epoch permits completion accounting for this window only. */
    observeRequest() {
        if (this.timer) {
            this.requests++;
            return this.epoch;
        }
        const now = performance.now();
        this.recentRequests = now - this.lastRequest > 250 ? 1 : this.recentRequests + 1;
        this.lastRequest = now;
        if (this.recentRequests < 4)
            return;
        this.delay ??= monitorEventLoopDelay({ resolution: 2 });
        this.delay.enable();
        this.resetWindow(now);
        this.timer = setInterval(() => this.sample(), 250);
        this.timer.unref();
        return this.epoch;
    }
    /** Records successful response completion only in the observation window that admitted it. */
    observeCompletion(epoch) {
        if (this.timer && epoch === this.epoch)
            this.completions++;
    }
    /** Whether the current request should enter the bounded render-start queue. */
    shouldSchedule() {
        if(this.enabled) globalThis.__scheduledRequests = (globalThis.__scheduledRequests ?? 0) + 1;
        return this.enabled;
    }
    resetWindow(now) {
        this.epoch++;
        this.started = now;
        this.completions = 0;
        this.delay.reset();
    }
    /** Reassesses capacity with immediate controls on both sides of a scheduled trial. */
    sample() {
        const before = this.phase, enabledBefore = this.enabled;
        const observed = {epochMs: Date.now(), phase:before, enabled:enabledBefore, requests:this.requests, completions:this.completions, duration:performance.now()-this.started, lag:this.delay?.percentile(95)/1e6};
        try { this.sampleImpl(); } finally { (globalThis.__gateTrace ??= []).push({...observed, nextPhase:this.phase, nextEnabled:this.enabled, cooldown:this.cooldown, baseline:this.baseline, trial:this.trial}); }
    }
    sampleImpl() {
        const now = performance.now();
        const requests = this.requests;
        this.requests = 0;
        if (requests < 4) {
            this.enabled = false;
            this.phase = 'baseline';
            this.nextPhase = 'trial';
            this.highSamples = 0;
            this.backoff = 2000;
            this.cooldown = 0;
            this.baseline = this.trial = undefined;
            if (!requests) {
                clearInterval(this.timer);
                this.timer = undefined;
                this.delay.disable();
                this.recentRequests = 0;
                this.lastRequest = -Infinity;
            }
            else
                this.resetWindow(now);
            return;
        }
        if (this.phase === 'settle') {
            if (now >= this.until) {
                this.phase = this.nextPhase;
                this.resetWindow(now);
            }
            return;
        }
        if (this.phase === 'enabled' && now >= this.until) {
            this.restartBaseline(now);
            return;
        }
        const elapsed = now - this.started;
        const shortControl = process.env.NODE_MISS_POLICY === 'candidate' && (this.phase === 'baseline' || this.phase === 'after');
        if (elapsed < (shortControl ? 250 : 750) || (shortControl && this.completions < 100 && elapsed < 750)) return;
        const sample = {
            lag: this.delay.percentile(95) / 1e6,
            rate: (this.completions * 1000) / (now - this.started),
            count: this.completions
        };
        if (this.phase === 'trial') {
            this.trial = sample;
            this.enabled = false;
            this.phase = 'settle';
            this.nextPhase = 'after';
            this.until = now + 250;
            this.resetWindow(now);
            return;
        }
        if (this.phase === 'after') {
            // A changing workload can make the mean control look artificially weak.
            // Require evidence against both controls before retaining the trial.
            const rate = Math.max(this.baseline.rate, sample.rate);
            const lag = Math.min(this.baseline.lag, sample.lag);
            this.enabled =
                this.trial.count >= 100 &&
                    sample.count >= 100 &&
                    this.trial.rate > rate &&
                    this.trial.lag < lag;
            if (this.enabled) {
                this.controlRate = rate;
                this.controlLag = lag;
                this.phase = 'enabled';
                this.until = now + (process.env.NODE_MISS_POLICY === 'candidate' ? 30000 : 5000);
                this.backoff = 2000;
            }
            else {
                this.phase = 'baseline';
                this.cooldown = now + this.backoff;
                this.backoff = Math.min(30_000, this.backoff * 2);
            }
            this.resetWindow(now);
            return;
        }
        if (this.phase === 'enabled') {
            // Recheck sooner when the observed benefit disappears, including a changed document mix.
            if (sample.rate <= this.controlRate || sample.lag >= this.controlLag)
                this.restartBaseline(now);
            else
                this.resetWindow(now);
            return;
        }
        this.highSamples = sample.lag > 3 ? this.highSamples + 1 : 0;
        if (now >= this.cooldown && this.highSamples >= 2 && sample.count >= 100) {
            this.baseline = sample;
            this.enabled = true;
            this.phase = 'settle';
            this.nextPhase = 'trial';
            this.until = now + 250;
            this.highSamples = 0;
        }
        this.resetWindow(now);
    }
    restartBaseline(now) {
        this.enabled = false;
        this.phase = 'baseline';
        this.cooldown = now;
        this.highSamples = 0;
        this.resetWindow(now);
    }
}
//# sourceMappingURL=adaptive-gate.js.map