import type { ServerResponse } from 'node:http';
/** Node host scheduling controls. Native Bun hosting retains immediate starts by default. */
export interface NodeSchedulingOptions {
    /** Enables automatic trials and reassessment. Defaults to true on Node and false on Bun. */
    adaptive?: boolean;
    /** Maximum queued starts released by one callback. Defaults to 32. */
    maxBatchSize?: number;
}
/**
 * Creates one host-owned admission policy. Completion listeners exist only while monitoring is
 * active and remove themselves on finish or cancellation. No response or rendering work is shared.
 */
export declare function createNodeRequestAdmission(options?: NodeSchedulingOptions): (response: ServerResponse, signal: AbortSignal) => void | Promise<void>;
//# sourceMappingURL=admission.d.ts.map