import { exactResponseBodyOf, handleExactRequest } from '@exactjs/server';
import { reportNodeError } from './error-reporting.js';
import { writeNodeError } from './requests/error.js';
import { createNodeRequestAdmission } from './requests/admission.js';
/** Node-owned immutable encoding capabilities used while consuming produced response bodies. */
const nodeSynchronousResponseEnvironment = Object.freeze({
    encodedByteLength: (value) => Buffer.byteLength(value)
});
/** Creates a Node endpoint handler with automatic adaptive admission and disconnect cancellation. */
export function createExactNodeHandler(context, options = {}) {
    const admit = createNodeRequestAdmission(options);
    return (request, response) => {
        const disconnect = new AbortController();
        const abort = () => disconnect.abort(new DOMException('Client disconnected', 'AbortError'));
        request.once('aborted', abort);
        response.once('close', abort);
        const cleanup = () => {
            request.off('aborted', abort);
            response.off('close', abort);
        };
        // Begin consuming the evented request body before asynchronous context
        // factories run so early data/end events cannot be missed.
        const body = readNodeRequestBody(request, requestLimit(context));
        // The server runtime may initialize asynchronous request contexts before it
        // asks for text. Observe an early transport rejection immediately while
        // preserving the original rejected promise for readBody().
        void body.catch(() => undefined);
        const execute = () => handleExactRequest({
            method: request.method ?? 'GET',
            url: request.url,
            headers: request.headers,
            text: () => body,
            signal: disconnect.signal,
            platformRequest: request
        }, context);
        let result;
        try {
            const pending = admit(response, disconnect.signal);
            result = pending ? pending.then(execute) : execute();
        }
        catch (error) {
            result = Promise.reject(error);
        }
        void result
            .then((result) => writeNodeResponse(response, result, disconnect.signal, context.logger).finally(cleanup))
            .catch((error) => {
            cleanup();
            if (disconnect.signal.aborted && error === disconnect.signal.reason)
                return;
            try {
                writeNodeError(response, error, context.logger);
            }
            catch (writeError) {
                reportNodeError(writeError, 'response', context.logger);
                if (!response.destroyed)
                    response.destroy();
            }
        });
    };
}
/** Reads a Node request body while enforcing the configured byte limit during transport. */
export function readNodeRequestBody(request, maxBytes = 4 * 1024 * 1024) {
    const declaredLength = Number(request.headers?.['content-length']);
    if (Number.isFinite(declaredLength) && declaredLength > maxBytes) {
        request.resume();
        return Promise.reject(new Error(`eXact request exceeded ${maxBytes} bytes`));
    }
    return new Promise((resolve, reject) => {
        const chunks = [];
        let bytes = 0;
        let settled = false;
        const cleanup = () => {
            request.off('data', onData);
            request.off('end', onEnd);
            request.off('error', onError);
        };
        const finish = (callback) => {
            if (settled)
                return;
            settled = true;
            cleanup();
            callback();
        };
        const onData = (chunk) => {
            const value = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
            bytes += value.byteLength;
            if (bytes > maxBytes) {
                finish(() => reject(new Error(`eXact request exceeded ${maxBytes} bytes`)));
                request.resume();
                return;
            }
            chunks.push(value);
        };
        const onEnd = () => finish(() => resolve(Buffer.concat(chunks).toString('utf8')));
        const onError = (error) => finish(() => reject(error));
        request.on('data', onData);
        request.on('end', onEnd);
        request.on('error', onError);
    });
}
function requestLimit(context) {
    const configured = context.limits?.maxRequestBytes;
    return typeof configured === 'number' && Number.isSafeInteger(configured) && configured > 0
        ? configured
        : 4 * 1024 * 1024;
}
/**
 * Writes an eXact response, reporting production, transport and cleanup failures through the
 * supplied logger or console. Error details never enter the generic failure response body.
 */
export async function writeNodeResponse(response, result, signal, logger) {
    response.statusCode = result.status;
    for (const [name, value] of Object.entries(result.headers))
        response.setHeader(name, value);
    const body = exactResponseBodyOf(result);
    if (body?.kind === 'produced' && body.writeSynchronously) {
        try {
            const collected = collectProducedBody(body, signal, response);
            const output = typeof collected === 'string' ? collected : await collected;
            throwIfAborted(signal);
            // Prepare known-length headers only after production and request-scope cleanup succeed.
            if (!response.headersSent && response.hasHeader('content-length'))
                response.writeHead(response.statusCode);
            response.end(output);
        }
        catch (error) {
            if (!signal?.aborted || error !== signal.reason)
                reportNodeError(error, 'response', logger);
            try {
                await body.cancel(error);
            }
            catch (cleanupError) {
                if (cleanupError !== error)
                    reportNodeError(cleanupError, 'cleanup', logger);
            }
            if (!response.headersSent) {
                for (const name of response.getHeaderNames())
                    response.removeHeader(name);
                response.statusCode = 500;
                response.setHeader('content-type', 'application/json; charset=utf-8');
                response.end(JSON.stringify({ error: 'internal_error' }));
            }
            else if (!response.destroyed)
                response.destroy(error);
        }
        return;
    }
    if (!body && !result.stream) {
        throwIfAborted(signal);
        response.end(result.body ?? '');
        return;
    }
    try {
        if (body?.kind === 'buffered') {
            throwIfAborted(signal);
            response.end(body.toText());
            return;
        }
        await writeNodeResponseBody(response, result, signal);
        throwIfAborted(signal);
        response.end();
    }
    catch (error) {
        if (!signal?.aborted || error !== signal.reason)
            reportNodeError(error, 'response', logger);
        try {
            await cancelNodeResponseBody(result, error);
        }
        catch (cleanupError) {
            if (cleanupError !== error)
                reportNodeError(cleanupError, 'cleanup', logger);
        }
        if (body?.kind === 'produced' && !response.headersSent) {
            for (const name of response.getHeaderNames())
                response.removeHeader(name);
            response.statusCode = 500;
            response.setHeader('content-type', 'application/json; charset=utf-8');
            response.end(JSON.stringify({ error: 'internal_error' }));
        }
        else if (!response.destroyed)
            response.destroy(error);
    }
}
/** Writes only an eXact response body, preserving Node backpressure without Web-stream allocation. */
export async function writeNodeResponseBody(response, result, signal) {
    const body = exactResponseBodyOf(result);
    if (body) {
        if (body.kind === 'produced' && body.writeSynchronously) {
            const collected = collectProducedBody(body, signal);
            const output = typeof collected === 'string' ? collected : await collected;
            throwIfAborted(signal);
            if (!response.write(output))
                await waitForDrain(response, signal);
            return;
        }
        await body.writeTo((chunk) => {
            throwIfAborted(signal);
            if (!response.write(chunk))
                return waitForDrain(response, signal);
        });
        return;
    }
    if (result.stream) {
        await pipeReadableStream(result.stream, response, signal);
        return;
    }
    throwIfAborted(signal);
    response.write(result.body ?? '');
}
/** Collects output and optional complete-body byte facts before commitment and scope cleanup. */
function collectProducedBody(body, signal, lengthResponse) {
    let output = '';
    const completion = body.writeSynchronously((chunk) => {
        throwIfAborted(signal);
        output += chunk;
    }, lengthResponse
        ? Object.freeze({
            ...nodeSynchronousResponseEnvironment,
            setBodyByteLength(bytes) {
                if (!Number.isSafeInteger(bytes) || bytes < 0)
                    throw new TypeError('Invalid produced body byte length');
                if (!lengthResponse.headersSent &&
                    lengthResponse.statusCode >= 200 &&
                    lengthResponse.statusCode !== 204 &&
                    lengthResponse.statusCode !== 304 &&
                    !lengthResponse.hasHeader('transfer-encoding'))
                    lengthResponse.setHeader('content-length', bytes);
            }
        })
        : nodeSynchronousResponseEnvironment);
    return completion ? completion.then(() => output) : output;
}
/** Cancels an unconsumed eXact response body without forcing lazy stream construction. */
export async function cancelNodeResponseBody(result, reason) {
    const body = exactResponseBodyOf(result);
    if (body)
        await body.cancel(reason);
    else if (result.stream)
        await result.stream.cancel(reason);
}
async function pipeReadableStream(stream, response, signal) {
    const reader = stream.getReader();
    try {
        while (true) {
            throwIfAborted(signal);
            const next = await reader.read();
            if (next.done)
                break;
            throwIfAborted(signal);
            if (!response.write(next.value))
                await waitForDrain(response, signal);
        }
    }
    catch (error) {
        try {
            await reader.cancel(error);
        }
        catch {
            /* preserve the transport failure */
        }
        throw error;
    }
    finally {
        try {
            reader.releaseLock();
        }
        catch {
            /* reader cleanup is best-effort */
        }
    }
}
function waitForDrain(response, signal) {
    return new Promise((resolve, reject) => {
        let settled = false;
        const cleanup = () => {
            response.off('drain', drain);
            signal?.removeEventListener('abort', abort);
        };
        const finish = (callback) => {
            if (settled)
                return;
            settled = true;
            cleanup();
            callback();
        };
        const drain = () => finish(resolve);
        const abort = () => finish(() => reject(signal?.reason ?? new DOMException('Client disconnected', 'AbortError')));
        if (signal?.aborted) {
            abort();
            return;
        }
        response.once('drain', drain);
        signal?.addEventListener('abort', abort, { once: true });
    });
}
function throwIfAborted(signal) {
    if (signal?.aborted)
        throw signal.reason ?? new DOMException('Client disconnected', 'AbortError');
}
//# sourceMappingURL=handler.js.map