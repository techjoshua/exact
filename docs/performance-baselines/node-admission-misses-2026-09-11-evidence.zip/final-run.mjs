import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync} from 'node:fs';
const steps=[];const root='.tmp/node-misses';
for(const mode of ['string','stream']){
 const step={mode,startedAt:new Date().toISOString()};steps.push(step);const save=()=>writeFileSync(root+'/final-execution.json',JSON.stringify(steps,null,2));save();
 const log=openSync(root+'/final-'+mode+'.log','w');console.log('START '+mode);
 try{await new Promise((yes,no)=>{const child=spawn(process.execPath,[root+'/final-runner.mjs',root+'/final-plan.json',root+'/final-'+mode+'.json','node'],{env:{...process.env,NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:mode},windowsHide:true,stdio:['ignore',log,log]});step.pid=child.pid;save();child.once('error',no);child.once('exit',code=>{step.code=code;code===0?yes():no(Error(mode+' failed '+code));});});}finally{closeSync(log);step.endedAt=new Date().toISOString();save();}console.log('DONE '+mode);
}
