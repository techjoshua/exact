import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/';
for(const [variant,path] of [['control','framework-comparison/participants/exact/dist-server/server-entry.js'],['candidate',d+'native-sink-application.mjs']]){
  const source=fs.readFileSync(path,'utf8')+'\nexport function auditRender(data,path,clientTags,options){return renderCompilerClosedToHydratableString(createPreparedServerComponentReference(Document,{initialData:data,path,clientTags}),{publishRootProps:true,...options});}\n';
  fs.writeFileSync(d+`native-sink-budget-${variant}-audit.mjs`,source);
}
let audit=fs.readFileSync(d+'application-string-audit.mjs','utf8')
  .replace("['current-production','string-sink-accounted','string-sink-deferred']","['native-sink-budget-control','native-sink-budget-candidate']")
  .replace("'./application-string/'","'./'")
  .replace("dir=d+'application-string/'","dir=d")
  .replace('`audit-${','`native-sink-budget-${');
fs.writeFileSync(d+'native-sink-budget-audit.mjs',audit);
for(const runtime of ['node','bun']){
  const result=spawnSync(runtime,[d+'native-sink-budget-audit.mjs'],{encoding:'utf8',windowsHide:true});
  console.log(runtime,result.stdout,result.stderr);assert.equal(result.status,0);
}
