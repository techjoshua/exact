import fs from 'node:fs';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {transform} from 'esbuild';
const d='.tmp/ssr-large-profile/';
const {request}=JSON.parse(fs.readFileSync(d+'compiled-stages-compile.json','utf8'));
const result=spawnSync('.tmp/native-sink-compiler/exactc.exe',[],{input:JSON.stringify(request)+'\n',encoding:'utf8',windowsHide:true,maxBuffer:32*1024*1024});
if(result.status!==0)throw Error(result.stderr+result.stdout);
const response=JSON.parse(result.stdout);
if(response.error||response.diagnostics.some(d=>d.severity==='error'))throw Error(JSON.stringify(response));
fs.writeFileSync(d+'native-sink-compile.json',JSON.stringify({request,response},null,2));
let fixture=(await transform(response.code,{loader:'ts',format:'esm',target:'esnext'})).code;
const issuer='issueServerComponentReceipt as __exactIssueServerComponent, ';
assert.equal(fixture.split(issuer).length,2);
fixture=fixture.replace(issuer,'');
fixture='import {issueServerComponentReceipt as __exactIssueServerComponent} from "./native-sink-entry.mjs";\n'+fixture;
// The existing publication harness owns hydration-tail interception. Native staging itself
// is emitted by Go, not reconstructed from JavaScript statement strings.
const close='__exactSsr.static(__exactOutput, "</body>")';
assert.equal(fixture.split(close).length,2);
fixture=fixture.replace(close,'(__exactOutput.sink.beginTail(), '+close+')');
fs.writeFileSync(d+'native-sink-fixture.mjs',fixture);
let runtime=fs.readFileSync(d+'publication-markers-candidate-entry.mjs','utf8');
function replace(before,after){assert.equal(runtime.split(before).length,2,before);runtime=runtime.replace(before,after);}
replace('var generatedSsrOperations = Object.freeze({','var generatedSsrOperations = Object.freeze({\n reference: createPreparedServerComponentReference,');
replace("sink:shared??{value:''}","sink:shared??{value:'',ready(){}}");
replace("{value:'',componentCapture:true}","{value:'',componentCapture:true,ready(){}}");
fs.writeFileSync(d+'native-sink-entry.mjs',runtime);
let audit=fs.readFileSync(d+'publication-markers-audit.mjs','utf8');
audit=audit.replace('const [variant]=process.argv.slice(2);',"const variant='candidate';");
audit=audit.replaceAll('./publication-markers-${variant}-entry.mjs','./native-sink-entry.mjs').replaceAll('./publication-markers-${variant}-fixture.mjs','./native-sink-fixture.mjs');
audit=audit.replace('publication-markers-${variant}-${','native-sink-${');
fs.writeFileSync(d+'native-sink-audit.mjs',audit);
let pressure=fs.readFileSync(d+'publication-markers-pressure-audit.mjs','utf8');
pressure=pressure.replaceAll('./publication-markers-candidate-entry.mjs','./native-sink-entry.mjs').replaceAll('./publication-markers-candidate-fixture.mjs','./native-sink-fixture.mjs').replaceAll('publication-markers-pressure-','native-sink-pressure-');
fs.writeFileSync(d+'native-sink-pressure-audit.mjs',pressure);
const rows=[];
for(const runtime of ['node','bun'])for(const script of ['native-sink-audit.mjs','native-sink-pressure-audit.mjs']) {
  const audit=spawnSync(runtime,[d+script],{encoding:'utf8',windowsHide:true});
  rows.push({runtime,script,status:audit.status,stdout:audit.stdout,stderr:audit.stderr});
  console.log(runtime,script,audit.status,audit.stdout,audit.stderr);
}
fs.writeFileSync(d+'native-sink-validation.json',JSON.stringify(rows,null,2));
assert.ok(rows.every(row=>row.status===0));
for(const runtime of ['node','bun']) {
  const control=JSON.parse(fs.readFileSync(d+`publication-markers-control-${runtime}.json`,'utf8'));
  const candidate=JSON.parse(fs.readFileSync(d+`native-sink-${runtime}.json`,'utf8'));
  assert.deepEqual(candidate,control);
}
console.log('Native-emitted fixture matches production with and without component markers.');
