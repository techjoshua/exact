import fs from 'node:fs';import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/',dir=d;
const variants=['native-sink-budget-control','native-sink-budget-candidate'];
const modules=await Promise.all(variants.map(v=>import('./'+v+'-audit.mjs')));
const source=JSON.parse(fs.readFileSync('.tmp/positional-leaves/data.json','utf8'));
const rows=[];
for(const unicode of [false,true]) {
 const data=structuredClone(source);
 if(unicode)for(const item of data.incidents)item.title+=' é中😀\ud800<script>\u2028\u2029';
 const baseline=await modules[0].auditRender(data,'/incidents/inc-101','',{});
 const bytes=Buffer.byteLength(baseline.htmlWithHydration);
 for(const maxOutputBytes of [1,2048,bytes-1,bytes,bytes+1]) {
  let control;
  for(let index=0;index<modules.length;index++) {
   let output;
   try {const result=await modules[index].auditRender(data,'/incidents/inc-101','',{maxOutputBytes});output={html:result.htmlWithHydration};}
   catch(error){output={error:error.name,message:error.message};}
   if(index===0)control=output;else assert.deepEqual(output,control);
   rows.push({unicode,maxOutputBytes,variant:variants[index],success:!output.error,error:output.error});
  }
 }
 const baselineStream=await new Response(await modules[0].renderParticipantStream(data,'/incidents/inc-101',{clientTags:''})).text();
 for(let index=0;index<modules.length;index++) {
  const html=await new Response(await modules[index].renderParticipantStream(data,'/incidents/inc-101',{clientTags:''})).text();
  const actual=html,expected=baselineStream;
  if(actual!==expected){let offset=0;while(actual[offset]===expected[offset])offset++;throw Error(`Stream difference at ${offset}: ${actual.slice(offset,offset+100)} versus ${expected.slice(offset,offset+100)}`);}
 }
}
fs.writeFileSync(dir+`native-sink-budget-${process.versions.bun?'bun':'node'}.json`,JSON.stringify({rows,streamCases:variants.length*2},null,2));
console.log(rows.length,'application budget cases and',variants.length*2,'consumed streams passed');
