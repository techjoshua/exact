import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {resolve} from 'node:path';
const file='.tmp/native-typescript-go/tsc/internal/exactcompiler/jsx_render_program_lowering.go';
const source=readFileSync(file,'utf8');
const before='lowering.directRenderProgramSsrWriter(build)';
if(source.split(before).length!==4)throw Error('Unexpected writer selection sites');
mkdirSync('.tmp/native-sink-compiler',{recursive:true});
try {
  writeFileSync(file,source.replaceAll(before,'lowering.directRenderProgramSsrSinkWriter(build)'));
  const result=spawnSync('go',['build','-buildvcs=false','-trimpath','-o',resolve('.tmp/native-sink-compiler/exactc.exe'),'./cmd/exactc'],{
    cwd:'.tmp/native-typescript-go/tsc',stdio:'inherit',windowsHide:true,env:{...process.env,CGO_ENABLED:'0',GOOS:'windows',GOARCH:'amd64'}});
  if(result.status!==0)throw Error(`Compiler build failed: ${result.status}`);
} finally {writeFileSync(file,source);}
console.log('Built isolated native sink compiler; production selection restored.');
