/** Prototype delaying compiler-identified document closing tags until hydration is serialized. */
export class HydrationTailSink {
 #sink;#tail;#closed=false;
 constructor(sink){this.#sink=sink;}
 beginTail(){if(this.#closed||this.#tail)throw Error('Invalid document tail boundary');this.#tail=[];}
 write(text){
  if(this.#closed)throw Error('Document sink is closed');
  if(this.#tail){this.#tail.push(text);return;}
  return this.#sink.write(text);
 }
 ready(){return this.#sink.ready();}
 flush(reason){return this.#sink.flush(reason);}
 async finishHydration(serialize){
  if(this.#closed||!this.#tail)throw Error('Missing document tail boundary');
  try{
   await this.#sink.ready();
   const script=serialize();
   await this.#sink.write('<!--exact:framework-body:start-->'+script+'<!--exact:framework-body:end-->');
   for(const part of this.#tail)await this.#sink.write(part);
   const bytes=await this.#sink.finish();this.#tail=undefined;this.#closed=true;return bytes;
  }catch(error){this.destroy(error);throw error;}
 }
 destroy(error){this.#closed=true;this.#tail=undefined;this.#sink.destroy(error);}
}
