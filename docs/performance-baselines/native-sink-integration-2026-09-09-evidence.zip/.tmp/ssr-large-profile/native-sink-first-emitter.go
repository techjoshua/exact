package exactcompiler

import (
	"strconv"

	"github.com/microsoft/TypeScript/tsc/internal/ast"
)

// directRenderProgramSsrSinkWriter lowers ordered writes into a fallthrough continuation.
// Synchronous writes stay in one invocation. Only pending operations and sink drains allocate
// callbacks. The caller owns output storage, cancellation, and error cleanup. Preparation timing
// is unchanged; runtime ABI selection remains separate until the sink contract is integrated.
func (lowering *jsxLowering) directRenderProgramSsrSinkWriter(build *renderProgramBuild) *ast.Node {
	plan := lowering.directRenderProgramSsrPlan(build)
	siblings := lowering.prepareSsrSinkSiblings(&plan)
	f := lowering.factory
	block := func(statements []*ast.Node) *ast.Node {
		return f.NewBlock(f.NewNodeList(statements), true)
	}
	property := func(receiver *ast.Node, name string) *ast.Node {
		return f.NewPropertyAccessExpression(receiver, nil, f.NewIdentifier(name), ast.NodeFlagsNone)
	}
	call := func(callee *ast.Node, args ...*ast.Node) *ast.Node {
		return f.NewCallExpression(callee, nil, nil, f.NewNodeList(args), ast.NodeFlagsNone)
	}
	number := func(value int) *ast.Node {
		return f.NewNumericLiteral(strconv.Itoa(value), ast.TokenFlagsNone)
	}
	parameters := func(names ...*ast.Node) *ast.NodeList {
		result := make([]*ast.Node, 0, len(names))
		for _, name := range names {
			result = append(result, f.NewParameterDeclaration(nil, nil, name, nil, nil, nil))
		}
		return f.NewNodeList(result)
	}
	stage := f.NewIdentifier("__exactStage")
	value := f.NewIdentifier("__exactSettled")
	resume := f.NewIdentifier("__exactResume")
	clauses := make([]*ast.Node, 0, 2*len(plan.writes)+1)
	for index, write := range plan.writes {
		expression := plan.statements[write.statement].AsExpressionStatement().Expression
		var settled []*ast.Node
		if write.assignsCharacters {
			assignment := expression.AsBinaryExpression()
			settled = append(settled, f.NewExpressionStatement(lowering.binary(assignment.Left, ast.KindEqualsToken, value)))
			expression = assignment.Right
		}
		callback := f.NewArrowFunction(nil, nil, parameters(value), nil, nil,
			f.NewToken(ast.KindEqualsGreaterThanToken), call(resume, number(index*2+1), value))
		invoke := []*ast.Node{
			f.NewExpressionStatement(lowering.binary(value, ast.KindEqualsToken, expression)),
			f.NewIfStatement(lowering.binary(value, ast.KindInstanceOfKeyword, f.NewIdentifier("Promise")),
				f.NewReturnStatement(call(property(value, "then"), callback)), nil),
		}
		clauses = append(clauses, f.NewCaseOrDefaultClause(ast.KindCaseClause, number(index*2), f.NewNodeList(invoke)))
		drain := f.NewIdentifier("__exactDrain_" + strconv.Itoa(index))
		settled = append(settled,
			f.NewVariableStatement(nil, f.NewVariableDeclarationList(f.NewNodeList([]*ast.Node{
				f.NewVariableDeclaration(drain, nil, nil, call(property(property(plan.output, "sink"), "ready"))),
			}), ast.NodeFlagsConst)),
			f.NewIfStatement(drain, f.NewReturnStatement(call(property(drain, "then"),
				lowering.arrow(call(resume, number(index*2+2))))), nil),
		)
		clauses = append(clauses, f.NewCaseOrDefaultClause(ast.KindCaseClause, number(index*2+1), f.NewNodeList(settled)))
	}
	clauses = append(clauses, f.NewCaseOrDefaultClause(ast.KindCaseClause, number(len(plan.writes)*2),
		f.NewNodeList([]*ast.Node{f.NewReturnStatement(plan.output)})))
	// Every nonterminal statement following preparation must be a recorded write. Fail
	// compilation if future lowering adds work that would otherwise be silently omitted.
	prefixEnd := len(plan.statements) - 1
	if len(plan.writes) > 0 {
		prefixEnd = plan.writes[0].statement
		for index, write := range plan.writes {
			if write.statement != prefixEnd+index {
				panic("SSR continuation plan contains an unclassified statement between writes")
			}
		}
		if prefixEnd+len(plan.writes) != len(plan.statements)-1 {
			panic("SSR continuation plan contains an unclassified statement after writes")
		}
	}
	// begin immediately precedes output allocation; sibling preparation follows all validation
	// and precedes the first context mutation, matching buffered traversal ownership.
	body := append([]*ast.Node{}, plan.statements[:plan.outputDeclaration-1]...)
	body = append(body, siblings...)
	body = append(body, plan.statements[plan.outputDeclaration-1])
	body = append(body, plan.statements[plan.outputDeclaration+1:prefixEnd]...)
	body = append(body,
		f.NewReturnStatement(call(resume, number(0))),
		f.NewFunctionDeclaration(nil, nil, resume, nil, parameters(stage, value), nil, nil,
			block([]*ast.Node{f.NewSwitchStatement(stage, f.NewCaseBlock(f.NewNodeList(clauses)))})),
	)
	return f.NewArrowFunction(nil, nil, parameters(plan.target, plan.context, plan.invocation, plan.output), nil, nil,
		f.NewToken(ast.KindEqualsGreaterThanToken), block(body))
}
