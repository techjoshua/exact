(__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
    const __exactValue_0 = __exactSsr.prepareChild(__exactInvocation, 0);
    if (__exactValue_0 === __exactSsr.unprepared)
        return;
    const __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
    if (__exactValue_1 === __exactSsr.unprepared)
        return;
    __exactSsr.begin(__exactContext, 0, 2, 14, 14);
    let __exactCharacters = 14;
    return __exactResume(0);
    function __exactResume(__exactStage, __exactSettled) {
        switch (__exactStage) {
            case 0: __exactSettled = __exactSsr.static(__exactOutput, "<main>");
            case 1:
                const __exactDrain_0 = __exactOutput.sink.ready();
                if (__exactDrain_0)
                    return __exactDrain_0.then(() => __exactResume(2));
            case 2:
                __exactSettled = __exactSsr.child(__exactContext, __exactOutput, __exactValue_0, "first", __exactCharacters);
                if (__exactSettled instanceof Promise)
                    return __exactSettled.then(__exactSettled => __exactResume(3, __exactSettled));
            case 3:
                __exactCharacters = __exactSettled;
                const __exactDrain_1 = __exactOutput.sink.ready();
                if (__exactDrain_1)
                    return __exactDrain_1.then(() => __exactResume(4));
            case 4: __exactSettled = __exactSsr.static(__exactOutput, "|");
            case 5:
                const __exactDrain_2 = __exactOutput.sink.ready();
                if (__exactDrain_2)
                    return __exactDrain_2.then(() => __exactResume(6));
            case 6:
                __exactSettled = __exactSsr.child(__exactContext, __exactOutput, __exactValue_1, "second", __exactCharacters);
                if (__exactSettled instanceof Promise)
                    return __exactSettled.then(__exactSettled => __exactResume(7, __exactSettled));
            case 7:
                __exactCharacters = __exactSettled;
                const __exactDrain_3 = __exactOutput.sink.ready();
                if (__exactDrain_3)
                    return __exactDrain_3.then(() => __exactResume(8));
            case 8: __exactSettled = __exactSsr.static(__exactOutput, "</main>");
            case 9:
                const __exactDrain_4 = __exactOutput.sink.ready();
                if (__exactDrain_4)
                    return __exactDrain_4.then(() => __exactResume(10));
            case 10: return __exactOutput;
        }
    }
}