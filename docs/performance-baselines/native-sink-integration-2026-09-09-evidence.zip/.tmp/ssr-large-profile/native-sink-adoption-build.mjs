import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
const source=fs.readFileSync(d+'publication-adoption-browser.mjs','utf8')
  .replace("['control','candidate']","['native']")
  .replace('publication-markers-${variant}-${runtime}.json','native-sink-${runtime}.json')
  .replace('publication-adoption-results.json','native-sink-adoption-results.json');
fs.writeFileSync(d+'native-sink-adoption.mjs',source);
