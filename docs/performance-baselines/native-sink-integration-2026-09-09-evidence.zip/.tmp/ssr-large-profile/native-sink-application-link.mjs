import ts from 'typescript';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/';
const native=fs.readFileSync(d+'native-sink-application/server-entry.js','utf8');
let candidate=fs.readFileSync(d+'application-string/target-methods.mjs','utf8');
function writers(source){
  const file=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
  const result=new Map();
  function visit(node){
    if(ts.isObjectLiteralExpression(node)){
      const properties=node.properties.filter(ts.isPropertyAssignment);
      const writer=properties.find(p=>p.name.getText(file)==='ssr');
      const id=properties.find(p=>p.name.getText(file)==='id');
      if(writer&&id&&ts.isStringLiteral(id.initializer)){
        assert.ok(!result.has(id.initializer.text));
        result.set(id.initializer.text,{start:writer.initializer.getStart(file),end:writer.initializer.end,code:writer.initializer.getText(file)});
      }
    }
    ts.forEachChild(node,visit);
  }
  visit(file);return result;
}
const emitted=writers(native),prior=writers(candidate);
assert.equal(emitted.size,25);assert.deepEqual([...emitted.keys()].sort(),[...prior.keys()].sort());
for(const [id,old] of [...prior].sort((a,b)=>b[1].start-a[1].start)){
  const replacement=emitted.get(id).code;
  // Ensure bundling has not renamed the component references differently between artifacts.
  const oldReferences=[...old.code.matchAll(/createPreparedServerComponentReference\((\w+),/g)].map(m=>m[1]);
  const newReferences=[...replacement.matchAll(/__exactSsr.reference\((\w+),/g)].map(m=>m[1]);
  assert.deepEqual(newReferences,oldReferences,id);
  candidate=candidate.slice(0,old.start)+replacement+candidate.slice(old.end);
}
function replace(before,after){assert.equal(candidate.split(before).length,2,before);candidate=candidate.replace(before,after);}
replace('var generatedSsrOperations = Object.freeze({','var generatedSsrOperations = Object.freeze({\n reference: createPreparedServerComponentReference,');
replace("sink:shared??{value:''}","sink:shared??{value:'',ready(){}}");
// Keep the sink module relative to the candidate's new location.
candidate=candidate.replace("from '../application-string-deferred-sink.mjs'","from './application-string-deferred-sink.mjs'");
fs.writeFileSync(d+'native-sink-application.mjs',candidate);
fs.writeFileSync(d+'native-sink-application-link.json',JSON.stringify({programs:emitted.size,ids:[...emitted.keys()]},null,2));
console.log('Linked all 25 native-emitted writers; component bindings matched.');
