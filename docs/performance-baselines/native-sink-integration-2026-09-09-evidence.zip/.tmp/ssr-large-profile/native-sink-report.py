import pathlib,json,hashlib,zipfile,statistics
d=pathlib.Path('.tmp/ssr-large-profile')
full=json.loads((d/'native-sink-application-results.json').read_text(encoding='utf8'))
refined=json.loads((d/'native-sink-refinement-results.json').read_text(encoding='utf8'))
pending=json.loads((d/'native-sink-pending-results.json').read_text(encoding='utf8'))
assert (len(full),len(refined),len(pending))==(64,48,16)
def mean(rows,runtime,mode,scenario,variant):
    values=[r['usPerRender'] for r in rows if (r['runtimeId'],r['mode'],r['scenario'],r['variant'])==(runtime,mode,scenario,variant)]
    assert len(values)==2
    return statistics.mean(values)
lines=['# Native sink integration measurements','',
'Date: 2026-09-09. Experimental compiler/runtime integration. Production selection unchanged.','',
'The native compiler now emits sibling reference preparation and conditional continuations. An',
'isolated compiler executable selects that emitter in its copied build tree; the production',
'selection is restored in a finally block. The actual comparison application builds with this',
'compiler through Vite. All 25 writer functions are linked by compiler program identity into the',
'existing target-methods sink prototype, with component binding equality checked before linking.',
'Writer statements are emitted by Go, not reconstructed by JavaScript regular expressions.','',
'This is still an integration experiment. The runtime retains prototype transforms and guards',
'around unsupported enhancement capture. The full-app streaming benchmark still uses its complete',
'document collector; it does not measure early-head delivery. The separate scheduled-component',
'fixture exercises actual progressive publication, task waits, and transport backpressure.','',
'## First complete comparison','',
'Microseconds per complete application document, lower is better. Each cell averages two fresh',
'production-mode processes with reversed variant ordering, 5,000 warmups and 12,000 measured',
'renders per process. Node 26.8.1 and Bun 1.4.2. Small has three incidents; large has 96. Both have',
'four assets and their framework-owned shell and hydration/bootstrap output. Streams are fully',
'consumed with Response.text. These are renderer measurements, not HTTP requests/s. React resolves',
'React DOM 19.2.0 from its participant directory. All samples are retained; no build or test ran',
'concurrently with timing. Complete eXact document hashes match across all paired variants.','',
'| Runtime | Mode | Document | Current eXact | Previous prototype | First native emitter | React |',
'| --- | --- | --- | ---: | ---: | ---: | ---: |']
for rt in ['node','bun']:
    for mode in ['string','stream']:
        for sc in ['assets','large']:
            v=[mean(full,rt,mode,sc,k) for k in ['production','previous','native','react']]
            lines.append(f"| {rt} | {mode} | {sc} | "+' | '.join(f'{x:.2f}' for x in v)+' |')
lines += ['',
'For large string rendering, the first native emitter widens Node\'s excess time over React from',
'22.6% to 35.8%, while narrowing Bun\'s from 19.5% to 15.7%. Its Bun large-stream result is only',
'0.7% below React, too close to establish a reliable throughput advantage. The dramatic isolated',
'writer gains from the preceding report did not translate into a dramatic application gain.','',
'## Removing unnecessary continuation work','',
'The hypothesis was that operation checks with impossible asynchronous outcomes, and continuation',
'state for a single synchronous terminal write, contributed avoidable overhead. Known synchronous',
'serialization operations now omit Promise checks. Other operations remain conservative. A lone',
'synchronous write skips continuation state but still waits for its final sink drain. This does',
'not introduce a separate traversal engine or discard backpressure.','',
'The next 48 processes compare the same preceding prototype, frozen first native emitter, and',
'refinement using the same protocol. These are a separate paired run from the React table above.','',
'| Runtime | Mode | Document | Previous prototype | First native emitter | Refined emitter | Refined vs first |',
'| --- | --- | --- | ---: | ---: | ---: | ---: |']
for rt in ['node','bun']:
    for mode in ['string','stream']:
        for sc in ['assets','large']:
            a,b,c=[mean(refined,rt,mode,sc,k) for k in ['previous','first','refined']]
            lines.append(f'| {rt} | {mode} | {sc} | {a:.2f} | {b:.2f} | {c:.2f} | {(c/b-1)*100:+.1f}% |')
lines += ['',
'The refinements recover part of the large-document regression on both runtimes. They do not',
'recover the previous prototype\'s large string result, and Bun\'s small cases regress slightly.',
'The refined emitter remains integration work, not a production performance win.','',
'## Pending-property experiment, rejected','',
'Replacing the 77 generated readiness calls with reads of a pending property tested whether',
'avoiding no-op method dispatch helps the non-suspending collector. Sixteen fresh string-rendering',
'processes used the same warmup and iteration counts. This was a complete-collector experiment,',
'not validation of a replacement backpressure protocol.','',
'| Runtime | Document | Pair 1: refined / property | Pair 2: refined / property |',
'| --- | --- | ---: | ---: |']
for rt in ['node','bun']:
    for sc in ['assets','large']:
        cells=[]
        for round in [0,1]:
            vals=[next(r['usPerRender'] for r in pending if (r['runtimeId'],r['scenario'],r['round'],r['variant'])==(rt,sc,round,k)) for k in ['refined','pending']]
            cells.append(' / '.join(f'{v:.2f}' for v in vals))
        lines.append(f'| {rt} | {sc} | '+' | '.join(cells)+' |')
lines += ['',
'Direction changes between pairs in both large cases. This experiment is not retained, and the',
'native emitter continues to use sink.ready().','',
'## Correctness and scope','',
'The native-generated scheduled document matches production HTML and hydration records both with',
'and without component markers on Node and Bun: 553 and 747 bytes respectively. Twelve transport',
'pressure/cancellation cases cover 1-, 8-, and 8,192-byte flush thresholds. Both child tasks must',
'start before their test gate opens; both children dispose, host ancestry unwinds, and hydration',
'is serialized once after success. The tests assert only one outstanding transport write.','',
'Real Chromium adopts the marked documents generated by Node and Bun. Elements, text nodes, and',
'the hydration script retain identity; restored child values are correct, server tasks do not',
'restart, and both children dispose. This is correctness coverage, not browser timing.','',
'The actual application passes 40 budget cases across ASCII/hostile Unicode and five byte limits,',
'plus eight fully consumed stream comparisons with production. Eleven low-level native-emitted',
'writer cases pass on each runtime, including the optimized terminal write with a pending drain.',
'Native tests cover empty and wide plans, sibling reference identity and preparation ordering.',
'The native compiler and command tests pass, as does the source-architecture check.','',
'The first isolated Vite attempt ran from the repository root and failed package authorization.',
'Running it from the comparison application\'s normal working directory succeeded. No package',
'authorization rule or manifest was weakened. A runtime-link assertion initially expected const',
'where the bundle emitted var; the corrected unique-site check passed. Neither failed attempt',
'was timed or counted as validation.','',
'Production ABI migration, broader runtime integration, early publication in the actual app, and',
'React parity remain unfinished. Current production package artifacts were not replaced by these',
'experimental compiler or runtime builds.','']
report=pathlib.Path('docs/performance-baselines/native-sink-integration-2026-09-09.md')
report.write_text('\n'.join(lines),encoding='utf8')
files=[p for p in d.glob('native-sink-*') if p.is_file()]
files += [p for p in (d/'native-sink-application').rglob('*') if p.is_file()]
files += [d/n for n in ['production-refresh-worker.mjs','application-string-deferred-sink.mjs','publication-string-sink.mjs','hydration-tail-sink.mjs','incremental-publication-pressure.mjs','incremental-publication-state-sink.mjs','publication-adoption-client.js','native-continuation-writer.js','native-continuation-terminal.js','native-continuation-audit.mjs','native-continuation-build.mjs','native-continuation-go.txt','native-continuation-node.json','native-continuation-bun.json']]
files += [d/'application-string/target-methods.mjs',pathlib.Path('.tmp/positional-leaves/data.json'),report,pathlib.Path('docs/ssr-hydration.md')]
files += [pathlib.Path('native/typescript-go/overlay/internal/exactcompiler')/n for n in ['jsx_render_program_ssr_lowering.go','jsx_render_program_ssr_plan.go','jsx_render_program_ssr_continuation.go','jsx_render_program_ssr_siblings.go','jsx_render_program_ssr_continuation_test.go']]
for variant,entry in [('production','framework-comparison/participants/exact/dist-server/server-entry.js'),('react','framework-comparison/participants/react/dist-server/server-entry.js')]:
    p=pathlib.Path(entry);digest=hashlib.sha256(p.read_bytes()).hexdigest()
    assert all(r['artifactSha256']==digest for r in full if r['variant']==variant)
    files.append(p)
assert all(r['status']==0 for r in json.loads((d/'native-sink-validation.json').read_text(encoding='utf8')))
assert all(r['result']['elementsRetained'] and not r['errors'] for r in json.loads((d/'native-sink-adoption-results.json').read_text(encoding='utf8')))
for rt in ['node','bun']:
    a=json.loads((d/f'native-sink-budget-{rt}.json').read_text(encoding='utf8'))
    assert len(a['rows'])==20 and a['streamCases']==4
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(report.with_name(report.stem+'-evidence.zip'),'w',zipfile.ZIP_DEFLATED) as archive:
    for name in manifest:archive.write(name,name)
    archive.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(report.with_name(report.stem+'-evidence.zip')) as archive:
    for name,digest in manifest.items():assert hashlib.sha256(archive.read(name)).hexdigest()==digest
print('Verified',len(manifest),'archive hashes and unchanged production/React artifacts.')
