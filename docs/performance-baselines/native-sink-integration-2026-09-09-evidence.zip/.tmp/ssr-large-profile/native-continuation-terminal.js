(__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
    __exactSsr.begin(__exactContext, 0, 0, 13, 13);
    let __exactCharacters = 13;
    __exactSsr.static(__exactOutput, "<main></main>");
    const __exactDrain = __exactOutput.sink.ready();
    if (__exactDrain)
        return __exactDrain.then(() => __exactOutput);
    return __exactOutput;
}