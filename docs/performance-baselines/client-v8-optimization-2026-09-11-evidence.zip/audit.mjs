import { chromium } from 'playwright';
import { mkdir, writeFile, readFile } from 'node:fs/promises';
import { startClientBenchmarkHarness } from '../../framework-comparison/src/client-benchmark-harness.mjs';
import { waitForSemanticReady } from '../../framework-comparison/src/client-profiling.mjs';
process.env.NODE_ENV='production';
const mode=process.argv[2]??'profile';
const ids=process.argv[3]?[process.argv[3]]:['exact','react'];
const root='.tmp/client-v8-optimization';
await mkdir(root,{recursive:true});
const participants=ids.map(id=>({id:id+'-controlled',directory:id,artifact:'dist',url:`http://127.0.0.1:${id==='exact'?4401:4402}`}));
const harness=await startClientBenchmarkHarness(participants);
let browser;
const records=[];
const variant=process.env.AUDIT_VARIANT??'baseline';
const captureName=`${mode}-${ids.join('-')}${variant==='baseline'?'':'-'+variant}${process.env.AUDIT_LABEL?'-'+process.env.AUDIT_LABEL:''}`;
try {
 const flags=mode==='trace'?'--trace-opt --trace-deopt --trace-turbo-inlining':mode==='bytecode'?`--print-bytecode --print-bytecode-filter=${process.argv[4]??'*'}`:'';
 browser=await chromium.launch({args:flags?['--js-flags='+flags]:[]});
 const version=browser.version();
 const rounds=Number(process.env.AUDIT_ROUNDS??(mode==='profile'?4:mode==='timing'||mode==='compare'?6:1));
 const plans=mode==='compare'||process.env.AUDIT_COMPARE_PROFILE?participants.flatMap(p=>p.directory==='exact'?['baseline','teardown','tracking'].map(variant=>({...p,variant})):[p]):participants;
 for(let round=0;round<rounds;round++)for(const participant of [...plans.slice(round%plans.length),...plans.slice(0,round%plans.length)]){
  const variant=participant.variant??process.env.AUDIT_VARIANT??'baseline';
  const context=await browser.newContext();
  const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
  if(participant.id==='exact-controlled')await page.route('**/assets/*.js',async route=>{
   try {
    const response=await route.fetch();
    const path=variant==='baseline'?'.tmp/client-v8/exact-mapped/assets/index-DqDy97bC.js':`${root}/${variant}.js`;
    await route.fulfill({response,body:await readFile(path,'utf8')});
   } catch(error){errors.push(String(error));await route.abort();}
  });
  const cdp=await context.newCDPSession(page);
  try{
   await cdp.send('Network.enable');await cdp.send('Network.setCacheDisabled',{cacheDisabled:true});
   await cdp.send('Profiler.enable');await cdp.send('HeapProfiler.enable');await cdp.send('Profiler.setSamplingInterval',{interval:100});
   const start=async()=>{if(mode==='profile'){await cdp.send('HeapProfiler.startSampling',{samplingInterval:1024,includeObjectsCollectedByMajorGC:true,includeObjectsCollectedByMinorGC:true});await cdp.send('Profiler.start');}};
   const stop=async()=>mode==='profile'?{cpu:(await cdp.send('Profiler.stop')).profile,heap:(await cdp.send('HeapProfiler.stopSampling')).profile}:{};
   await start();
   await page.goto(participant.url+'/incidents/inc-100',{waitUntil:'domcontentloaded'});await waitForSemanticReady(page);
   const startup={...await stop(),metrics:await page.evaluate(()=>({navigationMs:performance.getEntriesByType('navigation')[0].domContentLoadedEventEnd,rows:document.querySelectorAll('[data-testid="incident-row"]').length}))};
   await page.evaluate(installWorkload);
   const phases={startup};
   const work=[['filter',mode==='trace'?2000:400],['selection',100]];
   for(const [phase,count] of mode==='trace'?[...work,...work,...work]:work){
    await page.evaluate(async phase=>await window.auditClientWork(phase,20),phase);
    console.log(JSON.stringify({marker:'measured-start',mode,round,participant:participant.id,phase}));
    await page.evaluate(label=>console.log('AUDIT_PHASE '+label),phase);
    const countsBefore=await page.evaluate(()=>globalThis.__depCounts??globalThis.__lifecycleCounts);
    await start();const metrics=await page.evaluate(async ({phase,count})=>await window.auditClientWork(phase,count),{phase,count});
    phases[phase]={metrics,...await stop(),countsBefore,countsAfter:await page.evaluate(()=>globalThis.__depCounts??globalThis.__lifecycleCounts)};
    console.log(JSON.stringify({marker:'measured-end',mode,round,participant:participant.id,phase,meanMs:metrics.totalMs/count}));
   }
   if(errors.length)throw Error(errors.join('\n'));
   records.push({round,id:participant.id,variant,phases,errors,equalityCounts:await page.evaluate(()=>globalThis.__equalityCounts)});
   await writeFile(`${root}/${captureName}.json`,JSON.stringify({mode,variant,version,flags,complete:false,harness:harness.evidence(),records}));
  }finally{await context.close();}
 }
 await writeFile(`${root}/${captureName}.json`,JSON.stringify({mode,variant,version,complete:true,harness:harness.evidence(),records}));
}finally{try{await browser?.close();}finally{await harness.close();}}

function installWorkload(){
 window.auditClientWork=async function(phase,count){
  const samples=[];
  const retainedRow=document.querySelector('[data-testid="incident-row"]');
  for(let i=0;i<count;i++){
   let action,ready;
   if(phase==='filter'){
    const select=document.querySelector('select');const value=i%2?'all':'critical';const expected=i%2?3:1;
    action=()=>{select.value=value;select.dispatchEvent(new Event('change',{bubbles:true}));};
    ready=()=>document.querySelectorAll('[data-testid="incident-row"]').length===expected;
   }else{
    const row=document.querySelectorAll('[data-testid="incident-row"]')[i%2?0:1];const title=row.querySelector('strong').textContent;
    action=()=>row.click();ready=()=>document.querySelector('.detail-heading h2')?.textContent===title;
   }
   const begin=performance.now();
   await new Promise((resolve,reject)=>{
    const observer=new MutationObserver(()=>{if(ready()){clearTimeout(timer);observer.disconnect();resolve();}});
    const timer=setTimeout(()=>{observer.disconnect();reject(Error('Workload did not settle: '+phase));},5000);
    observer.observe(document.body,{subtree:true,childList:true,characterData:true,attributes:true});action();
    if(ready()){clearTimeout(timer);observer.disconnect();resolve();}
   });
   samples.push(performance.now()-begin);
   if(phase==='filter'&&document.querySelector('[data-testid="incident-row"]')!==retainedRow)throw Error('Filtering replaced the retained row');
  }
  return {count,totalMs:samples.reduce((a,b)=>a+b,0),samples,rows:document.querySelectorAll('[data-testid="incident-row"]').length};
 };
}
