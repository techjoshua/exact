Client V8 optimization evidence. Baseline commit: 5f6345b8ef4e922c49dffc0d27491de91e1002d8.
Extract into .tmp/client-v8-optimization at the repository root. The earlier client-v8 audit archive supplies .tmp/client-v8/exact-mapped.
Runtime build: npm run build -w @exactjs/reactive; npm run build -w @exactjs/dom; node scripts/compile-exact-package.mjs packages/dom; npm run build:exact -w @exactjs/framework-comparison-suite.
Use frozen baseline/reactive/teardown/tracking assets for comparing the captured variants. The final audit script compares baseline, teardown, tracking.
Set AUDIT_ROUNDS=9 and AUDIT_LABEL to a fresh name, then run node .tmp/client-v8-optimization/run-audit.mjs compare exact.
For profiles set AUDIT_ROUNDS=6 and AUDIT_COMPARE_PROFILE=1; run profile exact. Clear AUDIT_COMPARE_PROFILE afterward.
For bytecode/trace use AUDIT_VARIANT=tracking and a fresh AUDIT_LABEL. Do not run timing alongside builds, profiling or tests.
Corrected captures supersede the initial stale-teardown experiment. Old logs are retained, not silently removed.
Raw heap profiles include collected objects. The report JSON contains the final summary.
