#!/usr/bin/env bash
set -euo pipefail
ip link set lo up
source .tmp/wsl-benchmark-env.sh
export COMPARISON_SSR_RENDER_MODE=stream
for variant in before current; do
  export CONTROL_EXACT_ENTRY="$PWD/.tmp/ssr-hotspots-2026-09-20/$variant.mjs"
  node .tmp/ssr-hotspots-2026-09-20/namespace-capacity.mjs .tmp/ssr-hotspots-2026-09-20/plan.json ".tmp/ssr-hotspots-2026-09-20/http-residual-preloaded-$variant.json" node > ".tmp/ssr-hotspots-2026-09-20/residual-preloaded-$variant.log" 2>&1
done
for variant in current before; do
  export CONTROL_EXACT_ENTRY="$PWD/.tmp/ssr-hotspots-2026-09-20/$variant.mjs"
  node .tmp/ssr-hotspots-2026-09-20/namespace-capacity.mjs .tmp/native-loopback-2026-09-20/normal-plan.json ".tmp/ssr-hotspots-2026-09-20/http-residual-normal-$variant.json" node > ".tmp/ssr-hotspots-2026-09-20/residual-normal-$variant.log" 2>&1
done
