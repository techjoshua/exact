import { startBunEntryHost } from 'file:///home/techj/projects/exact/framework-comparison/src/ssr-bun-entry-host.mjs';
import { usesNativeBunServer } from 'file:///home/techj/projects/exact/framework-comparison/src/ssr-benchmark-transport.mjs';

/**
 * Starts the participant-declared HTTP host and owns its complete listener lifecycle.
 * Native Fetch and Node compatibility callbacks remain transport-specific by design.
 */
export async function startSsrBenchmarkHost(options) {
	if (usesNativeBunServer(options.transport))
		return options.loadEntry ? startBunEntryHost(options) : startBunHost(options);
	return startNodeHost(options);
}

/** Starts Bun's native Fetch server without importing Node's HTTP compatibility module. */
function startBunHost(options) {
	if (!globalThis.Bun?.serve) throw new Error('bun-fetch transport requires Bun.serve');
	const fetchHandler = async (request, server) => {
		const pathname = new URL(request.url).pathname;
		return pathname.startsWith('/__exact-benchmark/')
			? options.handleFetchControl(request)
			: options.handleFetchRequest(request, server);
	};
	const server = globalThis.Bun.serve({
		hostname: '::1',
		port: options.port,
		fetch: options.wrapFetchHandler ? options.wrapFetchHandler(fetchHandler) : fetchHandler
	});
	return {
		port: Number(server.port ?? new URL(server.url).port),
		close: () => server.stop(),
		forceClose: () => server.stop(true)
	};
}

/** Starts the Node HTTP host used by Node and compatibility-only Bun participants. */
async function startNodeHost(options) {
	const { createServer } = await import('node:http');
	const sockets = new Set();
	const server = createServer((request, response) => {
		const pathname = new URL(request.url ?? '/', 'http://localhost').pathname;
		if (pathname.startsWith('/__exact-benchmark/'))
			void options.handleNodeControl(request, response);
		else options.handleNodeRequest(request, response);
	});
	server.on('connection', (socket) => {
		sockets.add(socket);
		socket.on('error', (error) => options.onSocketError?.(error));
		socket.once('close', () => sockets.delete(socket));
	});
	await new Promise((resolveListen, reject) => {
		server.once('error', reject);
		server.listen(options.port, '::1', resolveListen);
	});
	const address = server.address();
	if (!address || typeof address === 'string') throw new Error('SSR worker has no TCP address');
	return {
		port: address.port,
		async close() {
			server.closeIdleConnections?.();
			await new Promise((resolveClose) => server.close(() => resolveClose()));
		},
		forceClose() {
			for (const socket of sockets) socket.destroy();
		}
	};
}
