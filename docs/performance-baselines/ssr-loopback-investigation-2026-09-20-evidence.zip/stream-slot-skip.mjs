//#region ../packages/core/dist/server/component-abi/server-child-range.js
var PreparedServerChildRange = Symbol.for("@exactjs/server/prepared-child-range");
/** Creates a direct server range without allocating an opaque operation or private payload. */
function createPreparedServerChildRange(value, markerId, mayReplaceSubtree = true) {
	return {
		[PreparedServerChildRange]: true,
		value,
		markerId,
		mayReplaceSubtree
	};
}
/** Reads only direct child ranges issued by compiler-closed server artifacts. */
function readPreparedServerChildRange(value) {
	return typeof value === "object" && value !== null && PreparedServerChildRange in value ? value : void 0;
}
//#endregion
//#region ../packages/core/dist/server/hydration-boundary.js
var finiteClientBoundaries = /* @__PURE__ */ new WeakSet();
/** Returns whether a boundary carries the module-private compiler proof. */
function isFiniteClientBoundary(boundary) {
	return finiteClientBoundaries.has(boundary);
}
//#endregion
//#region ../packages/core/dist/server/symbols.js
/** Framework-owned target metadata for properties that intentionally replace authored fallbacks. */
var TargetOverrides = Symbol.for("exact.target-overrides");
//#endregion
//#region ../packages/reactive/dist/internal/dependency-graph.js
var deps = /* @__PURE__ */ new WeakMap();
var depObservationHooks = /* @__PURE__ */ new WeakMap();
var reactionStack = [];
/** Contains only synchronous reruns; popped passes cannot retain disposed reactions. */
var trackingPasses = [];
var trackingPauseFloors = [];
var pendingObservationTransitions = [];
var publishingObservationTransitions = false;
/** Records that the active reaction depends on a target/key pair. */
function track(target, key) {
	const pauseFloor = trackingPauseFloors[trackingPauseFloors.length - 1];
	if (pauseFloor !== void 0 && reactionStack.length <= pauseFloor) return false;
	const reaction = reactionStack[reactionStack.length - 1];
	if (!reaction) return false;
	linkReaction(reaction, target, key);
	return true;
}
/** Registers lifecycle hooks for the observer count of one dependency source. */
function registerDependencyObservationHooks(target, key, hooks) {
	let targetHooks = depObservationHooks.get(target);
	if (!targetHooks) depObservationHooks.set(target, targetHooks = /* @__PURE__ */ new Map());
	targetHooks.set(key, hooks);
	return () => {
		const current = depObservationHooks.get(target);
		if (current?.get(key) !== hooks) return;
		current.delete(key);
		if (!current.size) depObservationHooks.delete(target);
	};
}
/** Adds a reaction to one dependency while preserving observer-count transitions. */
function linkReaction(reaction, target, key) {
	linkReactionToDependency(reaction, getDep(target, key));
}
/** Adds a reaction to an existing dependency set while preserving observer-count transitions. */
function linkReactionToDependency(reaction, dep) {
	const subscribers = dep.subscribers;
	const pass = trackingPasses[trackingPasses.length - 1];
	const collecting = pass?.reaction === reaction;
	if (subscribers === reaction || subscribers instanceof Set && subscribers.has(reaction)) {
		if (collecting && !pass.seen?.has(dep)) {
			(pass.seen ??= /* @__PURE__ */ new Set()).add(dep);
			reaction.deps.push(dep);
		}
		return;
	}
	if (collecting) (pass.seen ??= /* @__PURE__ */ new Set()).add(dep);
	const wasEmpty = subscribers === void 0;
	dep.subscribers = subscribers === void 0 ? reaction : subscribers instanceof Set ? subscribers.add(reaction) : /* @__PURE__ */ new Set([subscribers, reaction]);
	reaction.deps.push(dep);
	if (wasEmpty) publishObservationTransition(depObservationHooks.get(dep.target)?.get(dep.key)?.onObserved);
}
/** Returns immutable target/key descriptors for a reaction's current dependencies. */
function reactionDependencies(reaction) {
	return reaction.deps;
}
/** Returns the dependency set for a target/key pair, creating it on first use. */
function getDep(target, key) {
	let targetDeps = deps.get(target);
	if (!targetDeps) deps.set(target, targetDeps = /* @__PURE__ */ new Map());
	let dep = targetDeps.get(key);
	if (!dep) {
		dep = {
			target,
			key
		};
		targetDeps.set(key, dep);
	}
	return dep;
}
/** Removes a reaction from all dependency sets it currently belongs to. */
function cleanupReaction(reaction) {
	for (const pass of trackingPasses) if (pass.reaction === reaction) {
		for (const dep of pass.previous) detachDependency(reaction, dep);
		pass.previous = [];
	}
	for (const dep of reaction.deps) detachDependency(reaction, dep);
	reaction.deps.length = 0;
}
/** Removes a single membership and publishes a real last-observer transition. */
function detachDependency(reaction, dep) {
	const subscribers = dep.subscribers;
	if (subscribers === reaction) dep.subscribers = void 0;
	else if (subscribers instanceof Set && subscribers.delete(reaction)) {
		if (subscribers.size === 1) dep.subscribers = subscribers.values().next().value;
		else if (subscribers.size === 0) dep.subscribers = void 0;
	} else return;
	if (dep.subscribers === void 0) releaseEmptyDependency(dep);
}
/** Schedules one stable snapshot of the reactions subscribed to a dependency. */
function scheduleDependencyReactions(target, key) {
	const dep = deps.get(target)?.get(key);
	const subscribers = dep?.subscribers;
	if (subscribers instanceof Set) {
		for (const reaction of [...subscribers]) if (observesDuringTracking(reaction, dep)) reaction.schedule();
	} else if (subscribers && observesDuringTracking(subscribers, dep)) subscribers.schedule();
}
/** Schedules subscribers for an atomic trigger collection through the coalescing scheduler. */
function scheduleTriggeredReactions(triggers) {
	if (!triggers.size) return;
	const reactions = /* @__PURE__ */ new Set();
	for (const [target, keys] of triggers) {
		const targetDeps = deps.get(target);
		if (!targetDeps) continue;
		for (const key of keys) {
			const dep = targetDeps.get(key);
			const subscribers = dep?.subscribers;
			if (subscribers instanceof Set) {
				for (const reaction of subscribers) if (observesDuringTracking(reaction, dep)) reactions.add(reaction);
			} else if (subscribers && observesDuringTracking(subscribers, dep)) reactions.add(subscribers);
		}
	}
	for (const reaction of reactions) reaction.schedule();
}
/** Old memberships remain retained until exit but cannot invalidate an unread branch during execution. */
function observesDuringTracking(reaction, dep) {
	for (let i = trackingPasses.length - 1; i >= 0; i--) {
		const pass = trackingPasses[i];
		if (pass.reaction === reaction) return pass.seen?.has(dep) ?? false;
	}
	return true;
}
/**
* Collects replacement dependencies without tearing down memberships that the reaction rereads.
* Old memberships are ineligible to notify this execution until read again. Unused memberships
* are released on exit, including exceptional exits; disposal also releases reads made afterward.
*/
function runTracked(reaction, fn) {
	const pass = {
		reaction,
		previous: reaction.deps,
		seen: void 0
	};
	reaction.deps = [];
	trackingPasses.push(pass);
	reactionStack.push(reaction);
	try {
		fn();
	} finally {
		reactionStack.pop();
		trackingPasses.pop();
		for (const dep of pass.previous) if (!pass.seen?.has(dep)) detachDependency(reaction, dep);
		if (!reaction.active) cleanupReaction(reaction);
	}
}
/** Runs a function without linking its reads to the currently active reaction. */
function peek(fn) {
	trackingPauseFloors.push(reactionStack.length);
	try {
		return fn();
	} finally {
		trackingPauseFloors.pop();
	}
}
function releaseEmptyDependency(dep) {
	publishObservationTransition(depObservationHooks.get(dep.target)?.get(dep.key)?.onUnobserved);
	const targetDeps = deps.get(dep.target);
	if (targetDeps?.get(dep.key) === dep) targetDeps.delete(dep.key);
	if (targetDeps && !targetDeps.size) deps.delete(dep.target);
}
function publishObservationTransition(transition) {
	if (!transition) return;
	pendingObservationTransitions.push(transition);
	if (publishingObservationTransitions) return;
	publishingObservationTransitions = true;
	try {
		while (pendingObservationTransitions.length) pendingObservationTransitions.pop()();
	} finally {
		publishingObservationTransitions = false;
	}
}
//#endregion
//#region ../packages/reactive/dist/internal/deps.js
var transactions = [];
var mutationVersions = /* @__PURE__ */ new WeakMap();
var restorationVersion = 0;
/** Schedules every reaction currently subscribed to a target/key pair. */
function trigger(target, key) {
	const previousVersion = readMutationVersion(target, key);
	const nextVersion = incrementMutationVersion(target, key);
	const transaction = transactions[transactions.length - 1];
	if (transaction) {
		let keys = transaction.triggers.get(target);
		if (!keys) {
			keys = /* @__PURE__ */ new Set();
			transaction.triggers.set(target, keys);
		}
		keys.add(key);
		if (transaction.versionRanges) recordMutationVersionRange(transaction.versionRanges, target, key, previousVersion, nextVersion);
		return;
	}
	triggerNow(target, key);
}
/**
* Runs a group of writes as one atomic observable state transition.
* Reactive mutations are rolled back when the callback throws.
* The transaction covers synchronous callback execution only. If the callback
* returns a promise, synchronous writes are committed before that promise
* settles; use separate batches after awaits.
*/
function batch(fn) {
	const parent = transactions[transactions.length - 1];
	const transaction = createTransaction(true, Boolean(parent?.versionRanges));
	transactions.push(transaction);
	let result;
	try {
		result = fn();
	} catch (error) {
		transactions.pop();
		rollbackTransaction(transaction);
		throw error;
	}
	transactions.pop();
	publishTransaction(parent, transaction);
	return result;
}
/**
* Records an inverse operation for the currently active transaction.
*
* Supplying the mutated target and dependency key lets a retained optimistic
* journal preserve a newer authoritative write to that path during rollback.
*/
function recordTransactionUndo(undo, target, key) {
	transactions[transactions.length - 1]?.undos?.push({
		apply: undo,
		target,
		key
	});
}
/** Returns whether mutations currently need an inverse journal entry. */
function hasActiveTransaction() {
	return Boolean(transactions[transactions.length - 1]?.undos);
}
/** Returns whether target/key notifications are currently deferred by a reactive transaction. */
function hasActiveReactiveTransaction() {
	return transactions.length > 0;
}
function mergeTransaction(parent, child) {
	if (parent.undos && child.undos) parent.undos.push(...child.undos);
	mergeTriggers(parent.triggers, child.triggers);
	if (parent.versionRanges && child.versionRanges) mergeVersionRanges(parent.versionRanges, child.versionRanges);
}
function publishTransaction(parent, transaction) {
	if (parent) mergeTransaction(parent, transaction);
	else flushTriggers(transaction.triggers);
}
function mergeTriggers(parent, child) {
	for (const [target, keys] of child) {
		let pending = parent.get(target);
		if (!pending) {
			pending = /* @__PURE__ */ new Set();
			parent.set(target, pending);
		}
		for (const key of keys) pending.add(key);
	}
}
function rollbackTransaction(transaction, protectedVersions) {
	const undos = transaction.undos;
	if (!undos) return;
	const restored = /* @__PURE__ */ new Map();
	const restoration = {
		allows: (target, key, baseline = 0) => !protectedVersions || readMutationVersion(target, key) === (protectedVersions.get(target)?.get(key) ?? baseline),
		mark: (target, key) => recordRestoredDependency(restored, target, key)
	};
	for (let index = undos.length - 1; index >= 0; index--) {
		const undo = undos[index];
		if (undo.target && undo.key !== void 0 && !restoration.allows(undo.target, undo.key)) continue;
		undo.apply(restoration);
		if (undo.target && undo.key !== void 0) restoration.mark(undo.target, undo.key);
	}
	advanceRestoredDependencyVersions(restored);
}
function incrementMutationVersion(target, key) {
	let versions = mutationVersions.get(target);
	if (!versions) mutationVersions.set(target, versions = /* @__PURE__ */ new Map());
	const next = (versions.get(key) ?? 0) + 1;
	versions.set(key, next);
	return next;
}
/** Returns the current mutation generation for one dependency without tracking it. */
function readMutationVersion(target, key) {
	return mutationVersions.get(target)?.get(key) ?? 0;
}
/** Returns the generation of the most recent transaction restoration. */
function readReactiveRestorationVersion() {
	return restorationVersion;
}
function createTransaction(rollback, retainVersions = false) {
	return {
		...rollback ? { undos: [] } : {},
		triggers: /* @__PURE__ */ new Map(),
		...retainVersions ? { versionRanges: /* @__PURE__ */ new Map() } : {}
	};
}
function recordMutationVersionRange(versionRanges, target, key, start, end) {
	let ranges = versionRanges.get(target);
	if (!ranges) versionRanges.set(target, ranges = /* @__PURE__ */ new Map());
	const range = ranges.get(key);
	if (range) range.end = end;
	else ranges.set(key, {
		start,
		end
	});
}
function mergeVersionRanges(parent, child) {
	for (const [target, childRanges] of child) {
		let ranges = parent.get(target);
		if (!ranges) parent.set(target, ranges = /* @__PURE__ */ new Map());
		for (const [key, childRange] of childRanges) {
			const range = ranges.get(key);
			if (range) range.end = childRange.end;
			else ranges.set(key, { ...childRange });
		}
	}
}
function recordRestoredDependency(restored, target, key) {
	let keys = restored.get(target);
	if (!keys) restored.set(target, keys = /* @__PURE__ */ new Set());
	keys.add(key);
}
function advanceRestoredDependencyVersions(restored) {
	if (!restored.size) return;
	for (const [target, keys] of restored) for (const key of keys) incrementMutationVersion(target, key);
	restorationVersion++;
}
function flushTriggers(triggers) {
	scheduleTriggeredReactions(triggers);
}
function triggerNow(target, key) {
	scheduleDependencyReactions(target, key);
}
//#endregion
//#region ../packages/instrumentation/dist/index.js
/** Publishes an observation without allowing an instrumentation failure to affect framework work. */
function publishExactProfile(sink, event) {
	if (!sink) return;
	try {
		sink(event);
	} catch {}
}
/** Returns a monotonic high-resolution timestamp when the host provides one. */
function profileTimestamp() {
	return globalThis.performance?.now() ?? Date.now();
}
//#endregion
//#region ../packages/reactive/dist/internal/scheduler.js
var queuedReactions = /* @__PURE__ */ new Map();
var queuedComputations = /* @__PURE__ */ new Map();
var priorityStack = [];
var foregroundFlushScheduled = false;
var deferredFlushScheduled = false;
var consecutiveForegroundFlushes = 0;
var maxFlushPasses = 1e3;
var maxForegroundFlushesBeforeDeferred = 8;
var priorityOrder = {
	interactive: 0,
	normal: 1,
	deferred: 2
};
var settlementCallbacks = /* @__PURE__ */ new Set();
var settlementScheduled = false;
var settling = false;
/** Queues an arbitrary computation to run before reactions during the next flush. */
function queueComputation(computation, onError, priority = currentWorkPriority(), scope) {
	priority = constrainedPriority(scope, priority);
	const previous = queuedComputations.get(computation);
	if (!previous || isHigherWorkPriority(priority, previous.priority)) queuedComputations.set(computation, {
		priority,
		onError: onError ?? previous?.onError,
		scope: scope ?? previous?.scope
	});
	scheduleFlush(priority);
}
/** Removes a computation that was queued but has already been run synchronously. */
function removeQueuedComputation(computation) {
	queuedComputations.delete(computation);
}
/**
* Releases queued work for one stopped scope or a completed subtree in one queue traversal.
*
* Paused work is deliberately ineligible for ordinary draining, so scope teardown must remove it
* explicitly rather than relying on a later flush to observe that the scope is inactive.
*/
function discardScheduledScopeWork(scope, scopes) {
	for (const reaction of queuedReactions.keys()) if (scopes ? reaction.scope && scopes.has(reaction.scope) : reaction.scope === scope) {
		queuedReactions.get(reaction)?.context?.cancel();
		queuedReactions.delete(reaction);
	}
	for (const [computation, queued] of queuedComputations) if (scopes ? queued.scope && scopes.has(queued.scope) : queued.scope === scope) queuedComputations.delete(computation);
}
/** Allocates a subtree purge batch only when queue scanning can repeat across descendants. */
function createScheduledScopePurge() {
	return queuedReactions.size || queuedComputations.size ? /* @__PURE__ */ new Set() : void 0;
}
/** Returns the priority inherited by work scheduled in the current synchronous execution scope. */
function currentWorkPriority() {
	return priorityStack[priorityStack.length - 1] ?? "normal";
}
/** Runs synchronous work so its reactive invalidations inherit the requested priority. */
function runWithPriority(priority, work) {
	priorityStack.push(priority);
	try {
		return work();
	} finally {
		priorityStack.pop();
	}
}
/** Reschedules queued work whose owning scopes may just have become runnable. */
function resumeScheduledWork() {
	scheduleRemainingWork();
}
/**
* Drains pending work through a priority until the eligible scheduler reaches a stable state.
*
* The default drains every priority for deterministic SSR, testing, and explicit synchronous
* rendering. Passing `normal` leaves deferred work queued for its host turn.
*/
function flushSync(through = "deferred") {
	let passes = 0;
	let firstError;
	let hasError = false;
	let profileStarted;
	const profiledReactions = /* @__PURE__ */ new Map();
	try {
		while (hasEligibleWork(through)) {
			if (++passes > maxFlushPasses) {
				const overflow = /* @__PURE__ */ new Error("eXact reactive scheduler exceeded its flush limit; a reaction is repeatedly invalidating itself");
				if (settleOverflow(overflow)) return;
				throw overflow;
			}
			while (hasEligibleComputations(through)) {
				if (++passes > maxFlushPasses) {
					const overflow = /* @__PURE__ */ new Error("eXact reactive scheduler exceeded its flush limit; a computation is repeatedly invalidating itself");
					if (settleOverflow(overflow)) return;
					throw overflow;
				}
				const computations = takeEligibleComputations(through);
				for (const [computation, queued] of computations) {
					if (queued.scope && !queued.scope.active) continue;
					try {
						runWithPriority(queued.priority, computation);
					} catch (error) {
						if (queued.onError) try {
							queued.onError(error);
						} catch (handlerError) {
							if (!hasError) firstError = handlerError;
							hasError = true;
						}
						else {
							if (!hasError) firstError = error;
							hasError = true;
						}
					}
				}
			}
			const reactions = takeEligibleReactions(through);
			for (const [reaction, queued] of reactions) {
				if (!reaction.active || reaction.scope && (!reaction.scope.active || reaction.scope.paused)) {
					queued.context?.cancel();
					continue;
				}
				const profile = reaction.scope?.onProfile;
				if (profile) {
					profileStarted ??= profileTimestamp();
					profiledReactions.set(profile, (profiledReactions.get(profile) ?? 0) + 1);
				}
				try {
					if (queued.context) queued.context.run(() => runReactionWithPriority(queued.priority, reaction));
					else runReactionWithPriority(queued.priority, reaction);
				} catch (error) {
					if (!hasError) firstError = error;
					hasError = true;
				}
			}
		}
	} finally {
		if (through === "deferred") {
			foregroundFlushScheduled = false;
			deferredFlushScheduled = false;
		} else foregroundFlushScheduled = false;
		scheduleRemainingWork();
		if (!hasEligibleWork("deferred")) settleScheduler();
		if (profileStarted !== void 0) for (const [sink, reactions] of profiledReactions) publishExactProfile(sink, Object.freeze({
			subsystem: "reactive",
			phase: "flush",
			elapsedMs: profileTimestamp() - profileStarted,
			counts: Object.freeze({
				passes,
				reactions
			})
		}));
	}
	if (hasError) throw firstError;
}
function runReactionWithPriority(priority, reaction) {
	priorityStack.push(priority);
	try {
		reaction.run();
	} finally {
		priorityStack.pop();
	}
}
/** Publishes one stable settlement generation without admitting recursive reconciliation. */
function settleScheduler() {
	if (settling || hasEligibleWork("deferred")) return;
	settlementScheduled = false;
	if (!settlementCallbacks.size) return;
	const callbacks = [...settlementCallbacks];
	settlementCallbacks.clear();
	settling = true;
	try {
		for (const callback of callbacks) callback();
	} finally {
		settling = false;
		if (settlementCallbacks.size && !settlementScheduled) {
			settlementScheduled = true;
			queueMicrotask(settleScheduler);
		}
	}
}
/** Clears a runaway generation and reports it once to each owning scope. */
function settleOverflow(error) {
	const handlers = /* @__PURE__ */ new Set();
	for (const queued of queuedComputations.values()) if (queued.onError) handlers.add(queued.onError);
	for (const [reaction, queued] of queuedReactions) {
		reaction.scheduled = false;
		reaction.pendingPriority = void 0;
		queued.context?.cancel();
		if (reaction.scope?.onError) handlers.add(reaction.scope.onError);
	}
	queuedComputations.clear();
	queuedReactions.clear();
	if (!handlers.size) return false;
	let firstError;
	let failed = false;
	for (const handler of handlers) try {
		handler(error);
	} catch (handlerError) {
		if (!failed) firstError = handlerError;
		failed = true;
	}
	if (failed) throw firstError;
	return true;
}
function scheduleFlush(priority) {
	if (priority === "deferred") {
		if (foregroundFlushScheduled || deferredFlushScheduled) return;
		deferredFlushScheduled = true;
		scheduleDeferredFlush(() => {
			deferredFlushScheduled = false;
			consecutiveForegroundFlushes = 0;
			flushSync();
		});
		return;
	}
	if (foregroundFlushScheduled) return;
	foregroundFlushScheduled = true;
	queueMicrotask(() => {
		foregroundFlushScheduled = false;
		const drainDeferred = hasQueuedPriority("deferred") && ++consecutiveForegroundFlushes >= maxForegroundFlushesBeforeDeferred;
		if (drainDeferred) consecutiveForegroundFlushes = 0;
		flushSync(drainDeferred ? "deferred" : "normal");
	});
}
function scheduleRemainingWork() {
	const priority = highestQueuedPriority();
	if (priority) scheduleFlush(priority);
}
function highestQueuedPriority() {
	let selected;
	for (const [reaction, queued] of queuedReactions) {
		if (reaction.scope?.paused) continue;
		if (!selected || isHigherWorkPriority(queued.priority, selected)) selected = queued.priority;
	}
	for (const queued of queuedComputations.values()) {
		if (queued.scope?.paused) continue;
		if (!selected || isHigherWorkPriority(queued.priority, selected)) selected = queued.priority;
	}
	return selected;
}
function hasEligibleWork(through) {
	return hasEligibleComputations(through) || hasEligibleReactions(through);
}
function hasEligibleComputations(through) {
	for (const queued of queuedComputations.values()) {
		if (queued.scope?.paused) continue;
		if (isEligible(queued.priority, through)) return true;
	}
	return false;
}
function hasEligibleReactions(through) {
	for (const [reaction, queued] of queuedReactions) {
		if (reaction.scope?.paused) continue;
		if (isEligible(queued.priority, through)) return true;
	}
	return false;
}
function hasQueuedPriority(priority) {
	for (const [reaction, queued] of queuedReactions) if (!reaction.scope?.paused && queued.priority === priority) return true;
	for (const queued of queuedComputations.values()) if (!queued.scope?.paused && queued.priority === priority) return true;
	return false;
}
function takeEligibleComputations(through) {
	const selected = [];
	for (const [computation, queued] of queuedComputations) {
		if (queued.scope?.paused) continue;
		if (!isEligible(queued.priority, through)) continue;
		queuedComputations.delete(computation);
		selected.push([computation, queued]);
	}
	selected.sort((left, right) => priorityOrder[left[1].priority] - priorityOrder[right[1].priority]);
	return selected;
}
function takeEligibleReactions(through) {
	const selected = [];
	for (const [reaction, queued] of queuedReactions) {
		if (reaction.scope?.paused) continue;
		if (!isEligible(queued.priority, through)) continue;
		queuedReactions.delete(reaction);
		selected.push([reaction, queued]);
	}
	selected.sort((left, right) => priorityOrder[left[1].priority] - priorityOrder[right[1].priority] || (left[0].order ?? 1) - (right[0].order ?? 1));
	return selected;
}
function isEligible(priority, through) {
	return priorityOrder[priority] <= priorityOrder[through];
}
/** Reports whether candidate should run before current. */
function isHigherWorkPriority(candidate, current) {
	return priorityOrder[candidate] < priorityOrder[current];
}
function constrainedPriority(scope, requested) {
	let resolved = requested;
	for (let cursor = scope; cursor; cursor = cursor.parent) if (cursor.workPriority && isHigherWorkPriority(resolved, cursor.workPriority)) resolved = cursor.workPriority;
	return resolved;
}
function scheduleDeferredFlush(flush) {
	setTimeout(flush, 0);
}
//#endregion
//#region ../packages/reactive/dist/internal/scopes.js
var scopeStack = [];
var emptyScopes = /* @__PURE__ */ new Set();
var emptyReactions = /* @__PURE__ */ new Set();
var emptyCleanups = /* @__PURE__ */ new Set();
var emptyResumeWaiters = /* @__PURE__ */ new Set();
/**
* Stores reactive ownership with shared lifecycle methods and first-use collections.
*
* A scope participates in its parent's child collection immediately, but reactions, cleanups,
* descendants, and pause waiters do not allocate storage until their corresponding capability is
* used.
*/
var EffectScopeRecord = class {
	active = true;
	selfPaused = false;
	workPriority;
	parent;
	onError;
	onProfile;
	childrenValue;
	reactionsValue;
	cleanupsValue;
	resumeWaitersValue;
	constructor(parent, onError, onProfile) {
		this.parent = parent;
		this.onError = onError ?? parent?.onError;
		this.onProfile = onProfile ?? parent?.onProfile;
		parent?.children.add(this);
	}
	get paused() {
		return isEffectScopePaused(this);
	}
	get children() {
		return this.childrenValue ??= /* @__PURE__ */ new Set();
	}
	get reactions() {
		return this.reactionsValue ??= /* @__PURE__ */ new Set();
	}
	get cleanups() {
		return this.cleanupsValue ??= /* @__PURE__ */ new Set();
	}
	get resumeWaiters() {
		return this.resumeWaitersValue ??= /* @__PURE__ */ new Set();
	}
	pause() {
		this.selfPaused = true;
	}
	resume() {
		if (!this.selfPaused) return;
		this.selfPaused = false;
		notifyResumedSubtree(this);
		resumeScheduledWork();
	}
	stop() {
		stopEffectScope(this);
	}
	/** Returns descendants without materializing an empty child collection. */
	ownedChildren() {
		return this.childrenValue ?? emptyScopes;
	}
	/** Returns reactions without materializing an empty reaction collection. */
	ownedReactions() {
		return this.reactionsValue ?? emptyReactions;
	}
	/** Returns cleanups without materializing an empty cleanup collection. */
	ownedCleanups() {
		return this.cleanupsValue ?? emptyCleanups;
	}
	/** Returns pause waiters without materializing an empty waiter collection. */
	ownedResumeWaiters() {
		return this.resumeWaitersValue ?? emptyResumeWaiters;
	}
	/** Removes a child without allocating storage for a collection that cannot contain it. */
	removeChild(child) {
		this.childrenValue?.delete(child);
		if (this.childrenValue?.size === 0) this.childrenValue = void 0;
	}
	/** Removes a reaction and releases its now-empty backing collection. */
	removeReaction(reaction) {
		this.reactionsValue?.delete(reaction);
		if (this.reactionsValue?.size === 0) this.reactionsValue = void 0;
	}
	/** Removes a cleanup and releases its now-empty backing collection. */
	removeCleanup(cleanup) {
		this.cleanupsValue?.delete(cleanup);
		if (this.cleanupsValue?.size === 0) this.cleanupsValue = void 0;
	}
	/** Releases every settled pause waiter without retaining an empty set. */
	releaseResumeWaiters() {
		this.resumeWaitersValue = void 0;
	}
	/** Releases empty ownership collections after final disposal. */
	releaseCollections() {
		this.childrenValue = void 0;
		this.reactionsValue = void 0;
		this.cleanupsValue = void 0;
		this.resumeWaitersValue = void 0;
	}
};
/** Registers one reaction against a live scope using first-use ownership storage. */
function registerEffectScopeReaction(scope, reaction) {
	scope.reactions.add(reaction);
}
/** Releases one reaction and its empty scope storage after final disposal. */
function releaseEffectScopeReaction(scope, reaction) {
	scope.removeReaction(reaction);
}
/** Creates an effect scope that can stop all child scopes and reactions as one unit. */
function createEffectScope(parent = currentEffectScope(), onError, onProfile) {
	const parentScope = parent;
	if (parentScope && !parentScope.active) throw new Error("Cannot create an effect scope beneath an inactive parent scope");
	return new EffectScopeRecord(parentScope, onError, onProfile);
}
function stopEffectScope(root) {
	if (!root.active) return;
	const stopped = createScheduledScopePurge();
	const pending = [root];
	let firstError;
	let failed = false;
	while (pending.length) {
		const entry = pending.pop();
		const complete = entry === void 0;
		const scope = complete ? pending.pop() : entry;
		if (!complete) {
			if (!scope.active) continue;
			scope.active = false;
			for (const resume of scope.ownedResumeWaiters()) resume();
			scope.releaseResumeWaiters();
			const children = scope.ownedChildren();
			if (children.size) {
				pending.push(scope, void 0);
				const childStart = pending.length;
				for (const child of children) pending.push(child);
				for (let left = childStart, right = pending.length - 1; left < right; left++, right--) {
					const child = pending[left];
					pending[left] = pending[right];
					pending[right] = child;
				}
				continue;
			}
		}
		for (const reaction of [...scope.ownedReactions()]) try {
			reaction.stop();
		} catch (error) {
			if (!failed) firstError = error;
			failed = true;
		}
		for (const cleanup of [...scope.ownedCleanups()]) try {
			cleanup();
		} catch (error) {
			if (!failed) firstError = error;
			failed = true;
		}
		if (stopped) stopped.add(scope);
		else discardScheduledScopeWork(scope);
		scope.parent?.removeChild(scope);
		scope.parent = void 0;
		scope.releaseCollections();
	}
	if (stopped) discardScheduledScopeWork(void 0, stopped);
	resumeScheduledWork();
	if (failed) throw firstError;
}
/** Runs a function with the supplied scope as the current reactive ownership scope. */
function withEffectScope(scope, fn) {
	if (!scope) return fn();
	if (!scope.active) throw new Error("Cannot create reactive work inside an inactive effect scope");
	scopeStack.push(scope);
	try {
		return fn();
	} finally {
		scopeStack.pop();
	}
}
/** Returns the currently active effect scope, if code is executing inside one. */
function currentEffectScope() {
	return scopeStack[scopeStack.length - 1];
}
/** Resolves a requested priority through every effective ancestor constraint. */
function effectScopeWorkPriority(scope, requested) {
	let resolved = requested;
	for (let cursor = scope; cursor; cursor = cursor.parent) if (cursor.workPriority && isHigherWorkPriority(resolved, cursor.workPriority)) resolved = cursor.workPriority;
	return resolved;
}
function isEffectScopePaused(scope) {
	for (let cursor = scope; cursor; cursor = cursor.parent) if (cursor.selfPaused) return true;
	return false;
}
function notifyResumedSubtree(root) {
	const pending = [root];
	while (pending.length) {
		const scope = pending.pop();
		if (scope.active && !scope.paused && scope.ownedResumeWaiters().size) {
			for (const resume of scope.ownedResumeWaiters()) resume();
			scope.releaseResumeWaiters();
		}
		for (const child of scope.ownedChildren()) pending.push(child);
	}
}
//#endregion
//#region ../packages/reactive/dist/internal/symbols.js
/** Provides the canonical proxy marker value. */
var proxyMarker = Symbol.for("exact.reactive.proxy");
/** Provides the canonical reactive value marker value. */
var reactiveValueMarker = Symbol.for("exact.reactive.value");
/** Provides the canonical raw target value. */
var rawTarget = Symbol.for("exact.reactive.raw");
/** Provides the canonical reactive value ref value. */
var reactiveValueRef = Symbol.for("exact.reactive.valueRef");
/** Provides the canonical iterate key value. */
var iterateKey = Symbol.for("exact.reactive.iterate");
/** Separates authored length assignments from implicit length changes caused by array methods. */
var arrayLengthWriteKey = Symbol.for("exact.reactive.arrayLengthWrite");
//#endregion
//#region ../packages/reactive/dist/internal/values.js
/** Returns whether a value is an eXact reactive-value wrapper. */
function isReactiveValue(value) {
	return !!value && typeof value === "object" && reactiveValueMarker in value;
}
/** Returns whether a value is an eXact reactive proxy. */
function isReactive(value) {
	return !!value && typeof value === "object" && Boolean(value[proxyMarker]);
}
/**
* Returns the raw value behind a reactive proxy or reactive-value wrapper.
*
* Reactive-value reads remain tracked; proxy unwrapping only removes the proxy
* layer and does not recursively clone descendants.
*/
function unwrap(value) {
	if (value === null || typeof value !== "object") return value;
	if (isReactiveValue(value)) return value.get();
	if (isReactive(value)) return value[rawTarget];
	return value;
}
/** Rejects mutation through a readonly reactive-value reference. */
function rejectReadonlyReactiveValueWrite() {
	throw new TypeError("Cannot write to readonly reactive value");
}
//#endregion
//#region ../packages/reactive/dist/proxy/state.js
/** Provides the canonical default reactive options value. */
var defaultReactiveOptions = Object.freeze({});
/** Provides the canonical readonly reactive options key value. */
var readonlyReactiveOptionsKey = Object.freeze({ readonly: true });
/** Provides the canonical root proxy cache value. */
var rootProxyCache = /* @__PURE__ */ new WeakMap();
/** Provides the canonical sourced proxy cache value. */
var sourcedProxyCache = /* @__PURE__ */ new WeakMap();
/** Provides the canonical parent source cache value. */
var parentSourceCache = /* @__PURE__ */ new WeakMap();
/** Provides the canonical proxy refs value. */
var proxyRefs = /* @__PURE__ */ new WeakMap();
/** Provides the canonical reactive raw objects value. */
var reactiveRawObjects = /* @__PURE__ */ new WeakSet();
/** Provides the canonical list key extractors value. */
var listKeyExtractors = /* @__PURE__ */ new WeakMap();
/** Provides the canonical mutating array methods value. */
var mutatingArrayMethods = /* @__PURE__ */ new Set([
	"copyWithin",
	"fill",
	"pop",
	"push",
	"reverse",
	"shift",
	"sort",
	"splice",
	"unshift"
]);
//#endregion
//#region ../packages/reactive/dist/internal/objects.js
/** Returns whether a value is a plain object that can be structurally traversed. */
function isPlainObject(value) {
	if (!value || typeof value !== "object") return false;
	const prototype = Object.getPrototypeOf(value);
	return prototype === Object.prototype || prototype === null;
}
/** Returns whether an array key can affect iteration or length-sensitive dependencies. */
function isArrayStructureKey(target, key) {
	return Array.isArray(target) && (key === "length" || isArrayIndex(key));
}
function isArrayIndex(key) {
	if (typeof key === "number") return Number.isInteger(key) && key >= 0;
	if (typeof key !== "string" || key === "") return false;
	const index = Number(key);
	return Number.isInteger(index) && index >= 0 && String(index) === key;
}
//#endregion
//#region ../packages/reactive/dist/internal/equality.js
var exactOpaqueOperationIdentity$2 = Symbol.for("@exactjs/opaque-target-operation");
/** Returns whether two values differ after reactive wrappers and plain structures are compared. */
function hasChanged$1(previous, next, unwrap) {
	return !structurallyEqual(previous, next, unwrap);
}
/** Compares primitives, arrays, and plain objects after unwrapping reactive values. */
function structurallyEqual(left, right, unwrap) {
	if (Object.is(left, right)) return true;
	let leftToRight;
	let rightToLeft;
	const pending = [[left, right]];
	let visited = 0;
	while (pending.length) {
		if (++visited > 1e6) return false;
		const [rawLeft, rawRight] = pending.pop();
		if (Object.is(rawLeft, rawRight)) continue;
		const currentLeft = unwrap(rawLeft);
		const currentRight = unwrap(rawRight);
		if (Object.is(currentLeft, currentRight)) continue;
		if (!currentLeft || !currentRight || typeof currentLeft !== "object" || typeof currentRight !== "object") return false;
		if (exactOpaqueOperationIdentity$2 in currentLeft || exactOpaqueOperationIdentity$2 in currentRight) return false;
		leftToRight ??= /* @__PURE__ */ new WeakMap();
		rightToLeft ??= /* @__PURE__ */ new WeakMap();
		const priorRight = leftToRight.get(currentLeft);
		const priorLeft = rightToLeft.get(currentRight);
		if (priorRight || priorLeft) {
			if (priorRight !== currentRight || priorLeft !== currentLeft) return false;
			continue;
		}
		leftToRight.set(currentLeft, currentRight);
		rightToLeft.set(currentRight, currentLeft);
		const arrays = Array.isArray(currentLeft) && Array.isArray(currentRight);
		const objects = isPlainObject(currentLeft) && isPlainObject(currentRight);
		if (!arrays && !objects) return false;
		if (Object.getPrototypeOf(currentLeft) !== Object.getPrototypeOf(currentRight)) return false;
		if (arrays && currentLeft.length !== currentRight.length) return false;
		const leftKeys = Reflect.ownKeys(currentLeft).filter((key) => !arrays || key !== "length");
		const rightKeys = Reflect.ownKeys(currentRight).filter((key) => !arrays || key !== "length");
		if (leftKeys.length !== rightKeys.length) return false;
		for (const key of leftKeys) {
			if (!Object.prototype.hasOwnProperty.call(currentRight, key)) return false;
			const leftDescriptor = Reflect.getOwnPropertyDescriptor(currentLeft, key);
			const rightDescriptor = Reflect.getOwnPropertyDescriptor(currentRight, key);
			if (!leftDescriptor || !rightDescriptor) return false;
			if (!("value" in leftDescriptor) || !("value" in rightDescriptor)) {
				if (leftDescriptor.get !== rightDescriptor.get || leftDescriptor.set !== rightDescriptor.set || leftDescriptor.enumerable !== rightDescriptor.enumerable || leftDescriptor.configurable !== rightDescriptor.configurable) return false;
				continue;
			}
			if (leftDescriptor.enumerable !== rightDescriptor.enumerable || leftDescriptor.configurable !== rightDescriptor.configurable || leftDescriptor.writable !== rightDescriptor.writable) return false;
			pending.push([leftDescriptor.value, rightDescriptor.value]);
		}
	}
	return true;
}
//#endregion
//#region ../packages/reactive/dist/change-detection.js
var exactOpaqueOperationIdentity$1 = Symbol.for("@exactjs/opaque-target-operation");
/** Compares values after unwrapping reactive containers. */
function hasChanged(previous, next) {
	return hasChanged$1(previous, next, unwrap);
}
/** Compares computed results without treating distinct live references as interchangeable. */
function hasComputedResultChanged(previous, next) {
	return isReactive(previous) || isReactive(next) ? !Object.is(previous, next) : hasChanged(previous, next);
}
/** Identifies objects whose nested structure can participate in reactive reconciliation. */
function isReactiveContainer(value) {
	if (value && typeof value === "object" && Object.prototype.hasOwnProperty.call(value, exactOpaqueOperationIdentity$1)) return false;
	return Array.isArray(value) || value instanceof Map || value instanceof Set || isPlainObject(value);
}
//#endregion
//#region ../packages/reactive/dist/computation.js
var computedTargets = /* @__PURE__ */ new WeakMap();
var computedValues = /* @__PURE__ */ new WeakMap();
var maximumSettlementSteps = 1e5;
var cycleMessage = "eXact reactive computation cycle detected";
var nextSettlementGeneration = 0;
var activeSettlementGeneration = 0;
/** Creates a lazy, cached derived value with depth-independent synchronous freshness. */
function computed(compute) {
	const node = new ComputedNode(compute, currentEffectScope());
	const value = {
		[reactiveValueMarker]: true,
		[reactiveValueRef]: node,
		get: () => node.get(),
		toJSON: readComputedValue,
		toString: computedValueToString,
		valueOf: readComputedValue,
		[Symbol.toPrimitive]: readComputedValue
	};
	computedValues.set(value, node);
	return value;
}
function readComputedValue() {
	return this.get();
}
function computedValueToString() {
	return String(this.get());
}
var ComputedNode = class {
	compute;
	scope;
	active = true;
	scheduled = false;
	pendingPriority;
	deps = [];
	target = {};
	key = "value";
	state = "dirty";
	initialized = false;
	current;
	observed = false;
	failed = false;
	invalidatedWhileComputing = false;
	validatedGeneration = 0;
	restorationVersion = readReactiveRestorationVersion();
	dependencies = [];
	computedSources;
	computedSinks;
	releaseObservationHooks;
	settleScheduled = () => this.settle();
	constructor(compute, scope) {
		this.compute = compute;
		this.scope = scope;
		computedTargets.set(this.target, this);
		this.releaseObservationHooks = registerDependencyObservationHooks(this.target, this.key, {
			onObserved: () => this.becomeObserved(),
			onUnobserved: () => this.becomeUnobserved()
		});
		if (scope) registerEffectScopeReaction(scope, this);
	}
	set(_value) {
		rejectReadonlyReactiveValueWrite();
	}
	get() {
		if (this.state === "computing") throw new Error(cycleMessage);
		if (this.active && !this.scope?.paused && (activeSettlementGeneration === 0 || this.validatedGeneration !== activeSettlementGeneration)) this.settle();
		track(this.target, this.key);
		return this.current;
	}
	run() {
		this.scheduled = false;
		this.pendingPriority = void 0;
		if (!this.active || this.scope && !this.scope.active) {
			this.stop();
			return;
		}
		this.settle();
	}
	schedule() {
		if (!this.active || this.scope && !this.scope.active) {
			this.stop();
			return;
		}
		if (this.state !== "computing" && this.initialized && this.dependencies.every((dependency) => readMutationVersion(dependency.target, dependency.key) === dependency.version)) return;
		if (this.state === "computing") this.invalidatedWhileComputing = true;
		else this.state = "dirty";
		this.markSinksChecked();
		if (this.isRetained()) this.queue();
	}
	stop() {
		if (!this.active) return;
		this.active = false;
		this.state = "stopped";
		this.scheduled = false;
		this.pendingPriority = void 0;
		removeQueuedComputation(this.settleScheduled);
		cleanupReaction(this);
		this.detachComputedSources();
		this.releaseObservationHooks();
		if (this.scope) releaseEffectScopeReaction(this.scope, this);
	}
	inspect() {
		return Object.freeze({
			state: this.failed ? "failed" : this.scope?.paused ? "paused" : this.state,
			priority: this.pendingPriority ?? effectScopeWorkPriority(this.scope, currentWorkPriority()),
			observed: this.isRetained(),
			initialized: this.initialized,
			sources: this.dependencies.length,
			sinks: this.computedSinks?.size ?? 0
		});
	}
	settle() {
		if (!this.active || this.scope?.paused) return;
		const ownsGeneration = activeSettlementGeneration === 0;
		if (ownsGeneration) activeSettlementGeneration = ++nextSettlementGeneration;
		try {
			settleGraph(this);
		} finally {
			if (ownsGeneration) activeSettlementGeneration = 0;
		}
	}
	needsValidation() {
		return this.state !== "clean" || !this.isRetained() || hasActiveReactiveTransaction() || this.restorationVersion !== readReactiveRestorationVersion();
	}
	validateAndEvaluate() {
		if (!this.active || this.scope?.paused) return;
		if (this.state === "computing") throw new Error(cycleMessage);
		if (this.initialized && this.state !== "dirty") {
			if (!this.dependencies.some((dependency) => readMutationVersion(dependency.target, dependency.key) !== dependency.version)) {
				this.state = "clean";
				removeQueuedComputation(this.settleScheduled);
				this.scheduled = false;
				this.pendingPriority = void 0;
				this.validatedGeneration = activeSettlementGeneration;
				this.restorationVersion = readReactiveRestorationVersion();
				return;
			}
			this.state = "dirty";
		}
		if (this.state === "dirty" || !this.initialized) this.evaluate();
		this.validatedGeneration = activeSettlementGeneration;
		this.restorationVersion = readReactiveRestorationVersion();
	}
	evaluate() {
		const previousDependencies = this.dependencies;
		const previousValue = this.current;
		const hadValue = this.initialized;
		this.state = "computing";
		this.failed = false;
		this.invalidatedWhileComputing = false;
		removeQueuedComputation(this.settleScheduled);
		cleanupReaction(this);
		this.detachComputedSources();
		let next;
		try {
			withEffectScope(this.scope, () => runTracked(this, () => {
				const computedValue = this.compute();
				trackReturnedReference(computedValue);
				next = isReactiveValue(computedValue) ? computedValue.get() : computedValue;
			}));
		} catch (error) {
			this.recoverFromFailure(previousDependencies, error);
			return;
		}
		this.dependencies = snapshotDependencies(this);
		this.refreshComputedSources();
		if (!this.isRetained()) {
			cleanupReaction(this);
			this.detachComputedSources();
		}
		const changed = !hadValue || hasComputedResultChanged(previousValue, next);
		this.current = hadValue && !changed ? previousValue : next;
		this.initialized = true;
		this.state = this.invalidatedWhileComputing ? "dirty" : "clean";
		this.scheduled = false;
		this.pendingPriority = void 0;
		if (hadValue && changed) trigger(this.target, this.key);
		if (this.invalidatedWhileComputing) this.queue(true);
	}
	recoverFromFailure(previousDependencies, error) {
		const attemptedDependencies = snapshotDependencies(this);
		cleanupReaction(this);
		this.dependencies = mergeDependencies(previousDependencies, attemptedDependencies);
		if (this.isRetained()) this.attachDependencies();
		this.failed = true;
		this.state = "clean";
		this.validatedGeneration = activeSettlementGeneration;
		this.restorationVersion = readReactiveRestorationVersion();
		removeQueuedComputation(this.settleScheduled);
		this.scheduled = false;
		this.pendingPriority = void 0;
		const onError = this.scope?.onError;
		if (!onError) throw error;
		onError(error);
	}
	queue(force = false) {
		if (!force && !this.isRetained()) return;
		const priority = effectScopeWorkPriority(this.scope, currentWorkPriority());
		if (this.pendingPriority === void 0 || priority === "interactive" || this.pendingPriority === "deferred" && priority === "normal") this.pendingPriority = priority;
		this.scheduled = true;
		queueComputation(this.settleScheduled, void 0, priority, this.scope);
	}
	markSinksChecked() {
		const pending = this.computedSinks ? [...this.computedSinks] : [];
		const visited = /* @__PURE__ */ new Set();
		while (pending.length) {
			const sink = pending.pop();
			if (!visited.add(sink) || !sink.active) continue;
			if (sink.state === "clean") sink.state = "checked";
			if (sink.state === "computing") sink.invalidatedWhileComputing = true;
			if (sink.isRetained()) sink.queue();
			if (sink.computedSinks) for (const descendant of sink.computedSinks) pending.push(descendant);
		}
	}
	becomeObserved() {
		if (this.observed || !this.active) return;
		this.observed = true;
		this.attachDependencies();
		if (this.state !== "clean") this.queue();
	}
	becomeUnobserved() {
		if (!this.observed) return;
		this.observed = false;
		if (this.scope) return;
		cleanupReaction(this);
		this.detachComputedSources();
		removeQueuedComputation(this.settleScheduled);
		this.scheduled = false;
		this.pendingPriority = void 0;
	}
	attachDependencies() {
		for (const dependency of this.dependencies) linkReaction(this, dependency.target, dependency.key);
		this.refreshComputedSources();
	}
	refreshComputedSources() {
		this.detachComputedSources();
		if (!this.isRetained()) return;
		for (const dependency of this.dependencies) {
			if (!dependency.computed) continue;
			(this.computedSources ??= /* @__PURE__ */ new Set()).add(dependency.computed);
			(dependency.computed.computedSinks ??= /* @__PURE__ */ new Set()).add(this);
		}
	}
	detachComputedSources() {
		if (!this.computedSources) return;
		for (const source of this.computedSources) {
			source.computedSinks?.delete(this);
			if (source.computedSinks?.size === 0) source.computedSinks = void 0;
		}
		this.computedSources = void 0;
	}
	computedDependencies() {
		return this.dependencies;
	}
	isRetained() {
		return this.observed || Boolean(this.scope);
	}
};
function settleGraph(root) {
	const stack = [{
		node: root,
		leave: false
	}];
	const visiting = /* @__PURE__ */ new Set();
	let steps = 0;
	while (stack.length) {
		if (++steps > maximumSettlementSteps) throw new Error("eXact reactive computation graph exceeded its settlement limit");
		const frame = stack.pop();
		const node = frame.node;
		if (frame.leave) {
			visiting.delete(node);
			node.validateAndEvaluate();
			continue;
		}
		if (!node.needsValidation()) continue;
		if (visiting.has(node)) throw new Error(cycleMessage);
		visiting.add(node);
		stack.push({
			node,
			leave: true
		});
		const dependencies = node.computedDependencies();
		for (let index = dependencies.length - 1; index >= 0; index--) {
			const source = dependencies[index].computed;
			if (source) stack.push({
				node: source,
				leave: false
			});
		}
	}
}
function snapshotDependencies(reaction) {
	return reactionDependencies(reaction).map(({ target, key }) => ({
		target,
		key,
		version: readMutationVersion(target, key),
		computed: computedTargets.get(target)
	}));
}
function mergeDependencies(previous, attempted) {
	const merged = [...attempted];
	for (const dependency of previous) {
		if (merged.some((candidate) => candidate.target === dependency.target && candidate.key === dependency.key)) continue;
		merged.push({
			...dependency,
			version: readMutationVersion(dependency.target, dependency.key)
		});
	}
	return merged;
}
function trackReturnedReference(value) {
	if (isReactiveValue(value)) {
		value.get();
		return;
	}
	if (value && typeof value === "object") proxyRefs.get(value)?.get();
}
//#endregion
//#region ../packages/reactive/dist/proxy/property-descriptors.js
/** Unwraps data values while preserving accessor descriptors. */
function normalizeDescriptor(descriptor) {
	return "value" in descriptor ? {
		...descriptor,
		value: unwrap(descriptor.value)
	} : descriptor;
}
/** Compares descriptor semantics before emitting a reactive write. */
function samePropertyDescriptor(left, right) {
	if (!left) return false;
	if ("value" in left !== "value" in right) return false;
	if (left.configurable !== right.configurable || left.enumerable !== right.enumerable) return false;
	if ("value" in left && "value" in right) return left.writable === right.writable && !hasChanged(left.value, right.value);
	return left.get === right.get && left.set === right.set;
}
//#endregion
//#region ../packages/reactive/dist/internal/hash.js
var encoder = new TextEncoder();
/** Hashes strict JSON data with deterministic object ordering. This is not a security primitive. */
function hashCanonicalJson(value, domain) {
	const canonical = canonicalJson(value);
	return hashText(`${domain.length}:${domain}${canonical.length}:${canonical}`);
}
/** Hashes an ordered string sequence using unambiguous length framing. */
function hashStringSequence(values, domain) {
	let framed = `${domain.length}:${domain}${values.length}:`;
	for (const value of values) framed += `${value.length}:${value}`;
	return hashText(framed);
}
/** Performs the canonical json domain operation. */
function canonicalJson(value) {
	return encodeValue(value, /* @__PURE__ */ new WeakSet(), 0);
}
function encodeValue(value, active, depth) {
	if (depth > 100) throw new TypeError("Cannot hash JSON deeper than 100 levels");
	if (value === null) return "null";
	if (typeof value === "boolean") return value ? "true" : "false";
	if (typeof value === "string") return JSON.stringify(value);
	if (typeof value === "number") {
		if (!Number.isFinite(value)) throw new TypeError("Cannot hash non-finite JSON numbers");
		return Object.is(value, -0) ? "0" : JSON.stringify(value);
	}
	if (!value || typeof value !== "object") throw new TypeError(`Cannot hash non-JSON ${typeof value}`);
	if (active.has(value)) throw new TypeError("Cannot hash cyclic JSON");
	active.add(value);
	try {
		if (Array.isArray(value)) {
			if (Object.getPrototypeOf(value) !== Array.prototype) throw new TypeError("Cannot hash non-standard arrays");
			const keys = Object.keys(value);
			if (keys.length !== value.length || keys.some((key, index) => key !== String(index))) throw new TypeError("Cannot hash sparse arrays or arrays with enumerable properties");
			if (Object.getOwnPropertySymbols(value).some((symbol) => Object.prototype.propertyIsEnumerable.call(value, symbol))) throw new TypeError("Cannot hash arrays with enumerable symbols");
			const items = [];
			for (let index = 0; index < value.length; index++) {
				const descriptor = Object.getOwnPropertyDescriptor(value, String(index));
				if (!descriptor || !("value" in descriptor)) throw new TypeError("Cannot hash array accessors");
				items.push(encodeValue(descriptor.value, active, depth + 1));
			}
			return `[${items.join(",")}]`;
		}
		const prototype = Object.getPrototypeOf(value);
		if (prototype !== Object.prototype && prototype !== null) throw new TypeError("Cannot hash non-plain JSON objects");
		if (Object.getOwnPropertySymbols(value).some((symbol) => Object.prototype.propertyIsEnumerable.call(value, symbol))) throw new TypeError("Cannot hash objects with enumerable symbols");
		const descriptors = Object.getOwnPropertyDescriptors(value);
		const keys = Object.keys(descriptors).filter((key) => descriptors[key].enumerable).sort();
		const properties = [];
		for (const key of keys) {
			const descriptor = descriptors[key];
			if (!("value" in descriptor)) throw new TypeError("Cannot hash object accessors");
			properties.push(`${JSON.stringify(key)}:${encodeValue(descriptor.value, active, depth + 1)}`);
		}
		return `{${properties.join(",")}}`;
	} finally {
		active.delete(value);
	}
}
function hashText(value) {
	const bytes = encoder.encode(value);
	let a = 2166136261;
	let b = 2654435769;
	let c = 2246822507;
	let d = 3266489909;
	for (const byte of bytes) {
		a = Math.imul(a ^ byte, 16777619);
		b = Math.imul(b ^ byte, 668265261);
		c = Math.imul(c ^ byte, 374761393);
		d = Math.imul(d ^ byte, 2246822519);
	}
	a = avalanche(a ^ bytes.length);
	b = avalanche(b ^ a);
	c = avalanche(c ^ b);
	d = avalanche(d ^ c);
	return [
		a,
		b,
		c,
		d
	].map((part) => (part >>> 0).toString(16).padStart(8, "0")).join("");
}
function avalanche(value) {
	value ^= value >>> 16;
	value = Math.imul(value, 2146121005);
	value ^= value >>> 15;
	value = Math.imul(value, 2221713035);
	return value ^ value >>> 16;
}
//#endregion
//#region ../packages/reactive/dist/internal/keyed/protocol.js
/** Wraps already encoded items with one collection's stable reactive protocol metadata. */
function createKeyedCollectionEnvelope(metadata, items) {
	return {
		$exact: "keyed-collection",
		version: 1,
		keys: [...metadata.keys],
		keyHash: metadata.keyHash,
		itemHashes: [...metadata.itemHashes],
		itemsHash: metadata.itemsHash,
		items
	};
}
//#endregion
//#region ../packages/reactive/dist/internal/keyed-collections.js
var metadataByCollection = /* @__PURE__ */ new WeakMap();
var ownersByObject = /* @__PURE__ */ new WeakMap();
/** Performs the keyed collection metadata domain operation. */
function keyedCollectionMetadata(collection, key) {
	const metadata = metadataByCollection.get(collection);
	if (!metadata) return key ? rebuildMetadata(collection, key) : void 0;
	if (!metadata.structureDirty && metadata.dirtyKeys.size === 0) return metadata;
	if (!key) return void 0;
	if (metadata.structureDirty || keysChanged(collection, metadata.keys, key)) return rebuildMetadata(collection, key);
	try {
		const dirtyKeys = new Set(metadata.dirtyKeys);
		for (let index = 0; index < collection.length; index++) {
			const itemKey = metadata.keys[index];
			if (metadata.dirtyKeys.has(itemKey)) metadata.itemHashes[index] = hashItem(itemKey, collection[index]);
		}
		metadata.itemsHash = hashStringSequence(metadata.itemHashes, "exact:keyed-items:v1");
		metadata.dirtyKeys.clear();
		rebindOwners(metadata, collection, dirtyKeys);
		return metadata;
	} catch {
		clearMetadata(collection);
		return;
	}
}
/** Performs the mark reactive hash dirty domain operation. */
function markReactiveHashDirty(target) {
	const own = metadataByCollection.get(target);
	if (own) own.structureDirty = true;
	for (const owner of ownersByObject.get(target) ?? []) ownerMetadata(owner)?.dirtyKeys.add(owner.key);
}
/** Adds keyed-list metadata to array items serialized by a validated outer protocol traversal. */
function encodeValidatedReactiveCollectionInternal(collection, items, extractor) {
	const metadata = keyedCollectionMetadata(collection, extractor);
	return metadata ? createKeyedCollectionEnvelope(metadata, items) : items;
}
function rebuildMetadata(collection, key) {
	try {
		const keys = [];
		const itemHashes = [];
		const seen = /* @__PURE__ */ new Set();
		for (const item of collection) {
			const itemKey = String(key(item));
			if (seen.has(itemKey)) throw new Error(`Duplicate key "${itemKey}"`);
			seen.add(itemKey);
			keys.push(itemKey);
			itemHashes.push(hashItem(itemKey, item));
		}
		clearMetadata(collection);
		const metadata = {
			keys,
			keyHash: hashStringSequence(keys, "exact:keyed-keys:v1"),
			itemHashes,
			itemsHash: hashStringSequence(itemHashes, "exact:keyed-items:v1"),
			structureDirty: false,
			dirtyKeys: /* @__PURE__ */ new Set(),
			owners: []
		};
		metadataByCollection.set(collection, metadata);
		bindOwners(metadata, collection);
		return metadata;
	} catch {
		clearMetadata(collection);
		return;
	}
}
function keysChanged(collection, keys, key) {
	if (collection.length !== keys.length) return true;
	for (let index = 0; index < collection.length; index++) if (String(key(collection[index])) !== keys[index]) return true;
	return false;
}
function hashItem(key, value) {
	return hashCanonicalJson([key, value], "exact:keyed-item:v1");
}
function bindOwners(metadata, collection) {
	clearOwners(metadata);
	for (let index = 0; index < collection.length; index++) {
		const owner = createOwner(collection, metadata.keys[index], collection[index]);
		metadata.owners.push(owner);
	}
}
function rebindOwners(metadata, collection, keys) {
	for (let index = 0; index < metadata.keys.length; index++) {
		if (!keys.has(metadata.keys[index])) continue;
		const previous = metadata.owners[index];
		if (previous) clearOwner(previous);
		const owner = createOwner(collection, metadata.keys[index], collection[index]);
		metadata.owners[index] = owner;
	}
}
function createOwner(collection, key, value) {
	const nodes = [];
	collectJsonObjects(value, nodes, /* @__PURE__ */ new WeakSet(), 0);
	const owner = {
		collection,
		key,
		nodes
	};
	for (const node of nodes) {
		let owners = ownersByObject.get(node);
		if (!owners) ownersByObject.set(node, owners = /* @__PURE__ */ new Set());
		owners.add(owner);
	}
	return owner;
}
function collectJsonObjects(value, output, seen, depth) {
	if (!value || typeof value !== "object" || seen.has(value) || depth > 100) return;
	seen.add(value);
	output.push(value);
	if (Array.isArray(value)) for (const item of value) collectJsonObjects(item, output, seen, depth + 1);
	else for (const key of Object.keys(value)) {
		const descriptor = Object.getOwnPropertyDescriptor(value, key);
		if (descriptor && "value" in descriptor) collectJsonObjects(descriptor.value, output, seen, depth + 1);
	}
}
function clearMetadata(collection) {
	const metadata = metadataByCollection.get(collection);
	if (metadata) clearOwners(metadata);
	metadataByCollection.delete(collection);
}
function clearOwners(metadata) {
	for (const owner of metadata.owners) clearOwner(owner);
	metadata.owners = [];
}
function clearOwner(owner) {
	for (const node of owner.nodes) {
		const owners = ownersByObject.get(node);
		owners?.delete(owner);
		if (owners?.size === 0) ownersByObject.delete(node);
	}
}
function ownerMetadata(owner) {
	return metadataByCollection.get(owner.collection);
}
//#endregion
//#region ../packages/reactive/dist/array-property-undo.js
/** Captures a property inverse without giving an ordinary index write ownership of array length. */
function createPropertyUndo(target, key) {
	if (Array.isArray(target) && key === "length") return createArrayLengthUndo(target);
	const descriptor = Reflect.getOwnPropertyDescriptor(target, key);
	const array = Array.isArray(target) ? target : void 0;
	const index = array ? arrayIndex(key) : void 0;
	const oldLength = array?.length ?? 0;
	const lengthVersion = array ? readMutationVersion(array, arrayLengthWriteKey) : 0;
	return (restoration) => {
		const ownsLength = !array || restoration.allows(array, arrayLengthWriteKey, lengthVersion);
		if (array && index !== void 0 && index >= array.length && !ownsLength) return;
		if (descriptor) Reflect.defineProperty(target, key, descriptor);
		else Reflect.deleteProperty(target, key);
		if (array && index !== void 0 && index >= oldLength && ownsLength) {
			let retainedLength = oldLength;
			for (const name of Object.getOwnPropertyNames(array)) {
				const retainedIndex = arrayIndex(name);
				if (retainedIndex !== void 0) retainedLength = Math.max(retainedLength, retainedIndex + 1);
			}
			if (array.length > retainedLength) {
				array.length = retainedLength;
				restoration.mark(array, "length");
			}
		}
	};
}
/** Captures descriptors only for rollback-capable length writes; surviving slots are never restored. */
function createArrayLengthUndo(target) {
	const oldLength = target.length;
	const lengthVersion = readMutationVersion(target, arrayLengthWriteKey);
	const slots = Object.getOwnPropertyNames(target).flatMap((key) => {
		const index = arrayIndex(key);
		return index === void 0 ? [] : [{
			key,
			index,
			descriptor: Reflect.getOwnPropertyDescriptor(target, key),
			version: readMutationVersion(target, key)
		}];
	});
	return (restoration) => {
		const ownsLength = restoration.allows(target, arrayLengthWriteKey, lengthVersion);
		const currentLength = target.length;
		if (ownsLength && currentLength < oldLength) target.length = oldLength;
		for (const slot of slots) {
			if (!ownsLength && slot.index >= currentLength || !restoration.allows(target, slot.key, slot.version)) continue;
			const current = Reflect.getOwnPropertyDescriptor(target, slot.key);
			if (current && Object.is(current.value, slot.descriptor.value)) continue;
			Reflect.defineProperty(target, slot.key, slot.descriptor);
			restoration.mark(target, slot.key);
		}
		if (ownsLength && target.length > oldLength) {
			let retainedLength = oldLength;
			for (const key of Object.getOwnPropertyNames(target)) {
				const index = arrayIndex(key);
				if (index !== void 0) retainedLength = Math.max(retainedLength, index + 1);
			}
			target.length = retainedLength;
		}
		if (target.length !== currentLength) restoration.mark(target, "length");
	};
}
/** Recognizes actual array indices, excluding numeric-looking object properties and length itself. */
function arrayIndex(key) {
	if (typeof key === "symbol" || key === "") return void 0;
	const index = Number(key);
	return Number.isInteger(index) && index >= 0 && index < 4294967295 && String(index) === String(key) ? index : void 0;
}
//#endregion
//#region ../packages/reactive/dist/array-mutation.js
/** Applies a mutable array operation and journals its inverse during an optimistic transaction. */
function mutateArray(target, methodName, method, args, receiver, options) {
	if (options.readonly) {
		options.onReadonlyWrite?.(methodName);
		throw new TypeError(`Cannot call ${methodName} on a readonly array`);
	}
	if ((methodName === "push" || methodName === "pop") && method === Array.prototype[methodName]) return mutateArrayEnd(target, methodName, method, args, receiver, options);
	const previous = target.slice();
	let result;
	try {
		result = method.apply(target, args.map((arg) => unwrap(arg)));
	} finally {
		recordArrayMutationUndo(target, previous);
		batch(() => {
			const maxLength = Math.max(previous.length, target.length);
			let changed = previous.length !== target.length;
			for (let index = 0; index < maxLength; index++) {
				if (Reflect.has(previous, index) === Reflect.has(target, index) && Object.is(unwrap(previous[index]), unwrap(target[index]))) continue;
				changed = true;
				trigger(target, String(index));
			}
			if (previous.length !== target.length) trigger(target, "length");
			if (changed) {
				markReactiveHashDirty(target);
				trigger(target, iterateKey);
				notifyMutation$2(options, methodName);
			}
		});
	}
	return result === target ? receiver : result;
}
function notifyMutation$2(options, operation) {
	try {
		options.onMutation?.(void 0, operation);
	} catch {}
}
/**
* Records a sequence-aware inverse for an authored array method.
*
* The changed middle segment is replaced while any later authoritative prefix, suffix, or append
* remains in place. If authoritative work changed the optimistic segment itself, rollback falls
* back to restoring only positions that still contain the optimistic value.
*/
function recordArrayMutationUndo(target, previous) {
	if (!hasActiveTransaction()) return;
	const optimistic = target.slice();
	const lengthVersion = readMutationVersion(target, arrayLengthWriteKey);
	const versions = Array.from({ length: Math.max(previous.length, optimistic.length) }, (_, index) => readMutationVersion(target, String(index)));
	let prefix = 0;
	while (prefix < previous.length && prefix < optimistic.length && sameArraySlot(previous, optimistic, prefix, prefix)) prefix++;
	let suffix = 0;
	while (suffix < previous.length - prefix && suffix < optimistic.length - prefix && sameArraySlot(previous, optimistic, previous.length - suffix - 1, optimistic.length - suffix - 1)) suffix++;
	const previousEnd = previous.length - suffix;
	const optimisticEnd = optimistic.length - suffix;
	const removed = previous.slice(prefix, previousEnd);
	const inserted = optimistic.slice(prefix, optimisticEnd);
	recordTransactionUndo((restoration) => {
		const ownsLength = restoration.allows(target, arrayLengthWriteKey, lengthVersion);
		let segmentUnchanged = ownsLength;
		for (let offset = 0; offset < inserted.length; offset++) if (!restoration.allows(target, String(prefix + offset), versions[prefix + offset]) || !sameArraySlot(optimistic, target, prefix + offset, prefix + offset)) {
			segmentUnchanged = false;
			break;
		}
		if (segmentUnchanged) {
			const beforeLength = target.length;
			Array.prototype.splice.call(target, prefix, inserted.length, ...removed.map((value) => unwrap(value)));
			for (let offset = 0; offset < removed.length; offset++) {
				const previousIndex = prefix + offset;
				const targetIndex = prefix + offset;
				const descriptor = Reflect.getOwnPropertyDescriptor(previous, String(previousIndex));
				if (descriptor) Reflect.defineProperty(target, String(targetIndex), descriptor);
				else Reflect.deleteProperty(target, String(targetIndex));
			}
			for (let index = prefix; index < Math.max(beforeLength, target.length); index++) restoration.mark(target, String(index));
			if (beforeLength !== target.length) restoration.mark(target, "length");
			return;
		}
		const changedLength = Math.max(previousEnd, optimisticEnd);
		for (let index = prefix; index < changedLength; index++) {
			if (!ownsLength && index >= target.length || !restoration.allows(target, String(index), versions[index]) || !sameArraySlot(optimistic, target, index, index)) continue;
			if (Reflect.has(previous, index)) target[index] = previous[index];
			else Reflect.deleteProperty(target, index);
			restoration.mark(target, String(index));
		}
	});
}
function sameArraySlot(left, right, leftIndex, rightIndex) {
	const leftExists = Reflect.has(left, leftIndex);
	return leftExists === Reflect.has(right, rightIndex) && (!leftExists || Object.is(unwrap(left[leftIndex]), unwrap(right[rightIndex])));
}
function mutateArrayEnd(target, methodName, method, args, receiver, options) {
	const oldLength = target.length;
	const removed = methodName === "pop" && oldLength > 0 ? Reflect.getOwnPropertyDescriptor(target, String(oldLength - 1)) : void 0;
	const journaled = hasActiveTransaction();
	const lengthVersion = journaled ? readMutationVersion(target, arrayLengthWriteKey) : 0;
	const result = method.apply(target, args.map((arg) => unwrap(arg)));
	const newLength = target.length;
	if (newLength !== oldLength) {
		if (journaled) {
			if (methodName === "push") for (let index = oldLength; index < newLength; index++) {
				const insertedIndex = index;
				recordTransactionUndo((restoration) => {
					if (restoration.allows(target, arrayLengthWriteKey, lengthVersion)) {
						Array.prototype.splice.call(target, insertedIndex, 1);
						restoration.mark(target, "length");
					} else Reflect.deleteProperty(target, insertedIndex);
				}, target, String(insertedIndex));
			}
			else recordTransactionUndo((restoration) => {
				if (restoration.allows(target, arrayLengthWriteKey, lengthVersion)) {
					Array.prototype.splice.call(target, oldLength - 1, 0, void 0);
					restoration.mark(target, "length");
				} else if (oldLength > target.length) return;
				if (removed) Reflect.defineProperty(target, String(oldLength - 1), removed);
				else Reflect.deleteProperty(target, String(oldLength - 1));
			}, target, String(oldLength - 1));
		}
		batch(() => {
			markReactiveHashDirty(target);
			if (methodName === "push") for (let index = oldLength; index < newLength; index++) trigger(target, String(index));
			else trigger(target, String(oldLength - 1));
			trigger(target, "length");
			trigger(target, iterateKey);
		});
		notifyMutation$2(options, methodName);
	}
	return result === target ? receiver : result;
}
/** Journals one property only when an active transaction can roll it back. */
function recordPropertyUndo(target, key) {
	if (!hasActiveTransaction()) return;
	recordTransactionUndo(createPropertyUndo(target, key), target, key);
}
//#endregion
//#region ../packages/reactive/dist/proxy/create-base.js
/**
* Retains alias-specific proxy ownership while sharing the trap code across every nested proxy.
* A per-proxy record is required because one raw value may have several simultaneous parent paths.
*/
var reactiveProxyHandler = {
	get(target, key, receiver) {
		if (key === proxyMarker) return true;
		if (key === rawTarget) return target;
		const { collectionMember, options, proxy } = this.record;
		trackProxySources(proxy);
		if (target instanceof Map || target instanceof Set) {
			if (!collectionMember) throw new TypeError("Compiled object/array state received a Map or Set value");
			return collectionMember(target, key, proxy, options, (current, dependency) => {
				if (!current || typeof current !== "object" || !isReactiveContainer(unwrap(current))) return current;
				return sourcedReactive(unwrap(current), options, dependency === void 0 ? void 0 : createParentSource(target, dependency, options, collectionMember), collectionMember);
			});
		}
		const current = Reflect.get(target, key, receiver);
		if (current && typeof current === "object" && requiresExactProxyValue(target, key)) return current;
		if (Array.isArray(target) && mutatingArrayMethods.has(key) && typeof current === "function") return (...args) => mutateArray(target, String(key), current, args, receiver, options);
		if (options.passthroughKeys?.includes(key)) {
			track(target, key);
			return current;
		}
		if (isReactiveValue(current)) {
			track(target, key);
			const currentTarget = unwrap(current.get());
			return isReactiveContainer(currentTarget) ? sourcedReactive(currentTarget, options, createParentSource(target, key, options, collectionMember), collectionMember) : currentTarget;
		}
		if (current && typeof current === "object" && isReactiveContainer(unwrap(current))) {
			const currentTarget = unwrap(current);
			if (currentTarget === target) {
				track(target, key);
				return receiver;
			}
			return sourcedReactive(currentTarget, options, createParentSource(target, key, options, collectionMember), collectionMember);
		}
		track(target, key);
		return current;
	},
	set(target, key, next, receiver) {
		const { options } = this.record;
		if (options.readonly) {
			options.onReadonlyWrite?.(key);
			return false;
		}
		const previousLength = Array.isArray(target) ? target.length : void 0;
		const removedIndexes = Array.isArray(target) && key === "length" && typeof next === "number" && next < target.length ? Array.from({ length: target.length - next }, (_, offset) => next + offset).filter((index) => Reflect.has(target, index)) : [];
		const previous = Reflect.get(target, key, receiver);
		const unwrapped = unwrap(next);
		const hadKey = Object.prototype.hasOwnProperty.call(target, key);
		const changed = hasChanged(previous, unwrapped);
		const ownDescriptor = Reflect.getOwnPropertyDescriptor(target, key);
		if (!changed && ownDescriptor && "value" in ownDescriptor) {
			if (Array.isArray(target) && key === "length") trigger(target, arrayLengthWriteKey);
			return true;
		}
		const undo = hasActiveTransaction() ? createPropertyUndo(target, key) : void 0;
		this.record.forwardingSet = true;
		let ok;
		try {
			ok = Reflect.set(target, key, unwrapped, receiver);
		} finally {
			this.record.forwardingSet = false;
		}
		if (ok && undo && (!hadKey || !Object.is(previous, Reflect.get(target, key, receiver)))) recordTransactionUndo(undo, Array.isArray(target) && key === "length" ? void 0 : target, key);
		if (ok && changed) {
			if (Array.isArray(target) && key === "length") trigger(target, arrayLengthWriteKey);
			markReactiveHashDirty(target);
			trigger(target, key);
			for (const index of removedIndexes) trigger(target, String(index));
			if (previousLength !== void 0 && Array.isArray(target) && target.length !== previousLength && key !== "length") trigger(target, "length");
			if (!hadKey || isArrayStructureKey(target, key)) trigger(target, iterateKey);
			notifyMutation$1(options, key, "set");
		}
		return ok;
	},
	defineProperty(target, key, descriptor) {
		const { options } = this.record;
		if (this.record.forwardingSet) return Reflect.defineProperty(target, key, descriptor);
		if (options.readonly) {
			options.onReadonlyWrite?.(key);
			return false;
		}
		const previous = Reflect.getOwnPropertyDescriptor(target, key);
		if (samePropertyDescriptor(previous, descriptor)) {
			if (Array.isArray(target) && key === "length" && "value" in descriptor) trigger(target, arrayLengthWriteKey);
			return true;
		}
		const undo = hasActiveTransaction() ? createPropertyUndo(target, key) : void 0;
		const oldLength = Array.isArray(target) ? target.length : void 0;
		const previousIndexes = Array.isArray(target) && key === "length" ? Object.keys(target) : void 0;
		if (!Reflect.defineProperty(target, key, normalizeDescriptor(descriptor))) return false;
		if (Array.isArray(target) && key === "length") {
			trigger(target, arrayLengthWriteKey);
			for (const index of previousIndexes ?? []) if (!Reflect.has(target, index)) trigger(target, index);
		}
		if (undo) recordTransactionUndo(undo, Array.isArray(target) && key === "length" ? void 0 : target, key);
		markReactiveHashDirty(target);
		trigger(target, key);
		if (!previous || isArrayStructureKey(target, key)) trigger(target, iterateKey);
		if (oldLength !== void 0 && target.length !== oldLength && key !== "length") trigger(target, "length");
		notifyMutation$1(options, key, "define");
		return true;
	},
	deleteProperty(target, key) {
		const { options } = this.record;
		if (options.readonly) {
			options.onReadonlyWrite?.(key);
			return false;
		}
		const hadKey = Object.prototype.hasOwnProperty.call(target, key);
		const descriptor = hadKey && hasActiveTransaction() ? Reflect.getOwnPropertyDescriptor(target, key) : void 0;
		const ok = Reflect.deleteProperty(target, key);
		if (ok && hadKey) {
			if (descriptor) recordTransactionUndo(() => {
				Reflect.defineProperty(target, key, descriptor);
			}, target, key);
			markReactiveHashDirty(target);
			trigger(target, key);
			trigger(target, iterateKey);
			notifyMutation$1(options, key, "delete");
		}
		return ok;
	},
	ownKeys(target) {
		trackProxySources(this.record.proxy);
		track(target, iterateKey);
		return Reflect.ownKeys(target);
	},
	has(target, key) {
		track(target, key);
		return Reflect.has(target, key);
	}
};
/** Creates a reactive with an explicitly selected collection capability. */
function createReactiveBase(value, options, parentSource, collectionMember) {
	const reactiveTarget = isReactive(value) ? value[rawTarget] : value;
	const cached = getCachedProxy(reactiveTarget, options, parentSource);
	if (cached) {
		if (parentSource) registerProxySource(cached, parentSource);
		return cached;
	}
	const record = {
		options,
		collectionMember,
		forwardingSet: false
	};
	const handler = Object.create(reactiveProxyHandler);
	handler.record = record;
	const proxy = new Proxy(reactiveTarget, handler);
	record.proxy = proxy;
	cacheProxy(reactiveTarget, options, parentSource, proxy);
	if (parentSource) {
		reactiveRawObjects.add(reactiveTarget);
		registerProxySource(proxy, parentSource);
	}
	return proxy;
}
/** Preserves ECMAScript invariants for frozen object-valued data properties. */
function requiresExactProxyValue(target, key) {
	const descriptor = Reflect.getOwnPropertyDescriptor(target, key);
	return !!descriptor && "value" in descriptor && !descriptor.configurable && !descriptor.writable;
}
function createParentSource(target, key, options, collectionMember) {
	const optionKey = reactiveOptionsKey(options);
	let byKey = parentSourceCache.get(target);
	if (!byKey) parentSourceCache.set(target, byKey = /* @__PURE__ */ new Map());
	let byOptions = byKey.get(key);
	if (!byOptions) byKey.set(key, byOptions = /* @__PURE__ */ new WeakMap());
	const cached = byOptions.get(optionKey);
	if (cached) return cached;
	const source = {
		target,
		key,
		get() {
			track(target, key);
			const next = Reflect.get(target, key);
			if (isReactiveValue(next)) {
				const nextValue = next.get();
				return nextValue && typeof nextValue === "object" ? sourcedReactive(unwrap(nextValue), options, source, collectionMember) : nextValue;
			}
			return next && typeof next === "object" ? sourcedReactive(unwrap(next), options, source, collectionMember) : next;
		},
		set(value) {
			const previous = Reflect.get(target, key);
			const unwrapped = unwrap(value);
			if (!hasChanged(previous, unwrapped)) return;
			recordPropertyUndo(target, key);
			Reflect.set(target, key, unwrapped);
			markReactiveHashDirty(target);
			trigger(target, key);
			if (isArrayStructureKey(target, key)) trigger(target, iterateKey);
		}
	};
	byOptions.set(optionKey, source);
	return source;
}
/** Reuses the child proxy most recently resolved through one stable parent path. */
function sourcedReactive(raw, options, source, collectionMember) {
	if (!source) return createReactiveBase(raw, options, void 0, collectionMember);
	if (source.cachedRaw === raw && source.cachedProxy) {
		registerProxySource(source.cachedProxy, source);
		return source.cachedProxy;
	}
	const proxy = createReactiveBase(raw, options, source, collectionMember);
	source.cachedRaw = raw;
	source.cachedProxy = proxy;
	return proxy;
}
function getCachedProxy(raw, options, source) {
	const optionKey = reactiveOptionsKey(options);
	if (!source) return rootProxyCache.get(raw)?.get(optionKey);
	const bySource = sourcedProxyCache.get(raw)?.get(optionKey);
	const exact = bySource?.get(source);
	if (exact) return exact;
	if (bySource) for (const [oldSource, proxy] of bySource) {
		if (unwrap(Reflect.get(oldSource.target, oldSource.key)) === raw) continue;
		bySource.delete(oldSource);
		bySource.set(source, proxy);
		proxyRefs.set(proxy, source);
		return proxy;
	}
}
function cacheProxy(raw, options, source, proxy) {
	const optionKey = reactiveOptionsKey(options);
	if (source) {
		let byOptions = sourcedProxyCache.get(raw);
		if (!byOptions) sourcedProxyCache.set(raw, byOptions = /* @__PURE__ */ new WeakMap());
		let bySource = byOptions.get(optionKey);
		if (!bySource) byOptions.set(optionKey, bySource = /* @__PURE__ */ new Map());
		bySource.set(source, proxy);
		return;
	}
	let byOptions = rootProxyCache.get(raw);
	if (!byOptions) rootProxyCache.set(raw, byOptions = /* @__PURE__ */ new WeakMap());
	byOptions.set(optionKey, proxy);
}
function registerProxySource(proxy, source) {
	proxyRefs.set(proxy, source);
}
/** Observes the parent path owned by this proxy, including a migrated collection item. */
function trackProxySources(proxy) {
	const source = proxyRefs.get(proxy);
	if (source) track(source.target, source.key);
}
function reactiveOptionsKey(options) {
	if ("__exactCollectionCacheMode" in options) return options;
	if (!options.readonly && !options.onReadonlyWrite && !options.onMutation && !options.passthroughKeys?.length) return defaultReactiveOptions;
	if (options.readonly && !options.onReadonlyWrite && !options.onMutation && !options.passthroughKeys?.length) return readonlyReactiveOptionsKey;
	return options;
}
function notifyMutation$1(options, key, operation) {
	try {
		options.onMutation?.(key, operation);
	} catch {}
}
//#endregion
//#region ../packages/reactive/dist/reactive-record-slots.js
/** Resolves a compiler-known or instance-local dynamic property to its stable numeric slot. */
function indexedRecordIndex(record, key) {
	return record.layout.indexes.get(key) ?? record.dynamicIndexes?.get(key);
}
//#endregion
//#region ../packages/reactive/dist/indexed-base.js
var indexedRecords = /* @__PURE__ */ new WeakMap();
/** Reads an own field into a caller-owned cell without invoking an arbitrary accessor. */
function readReactiveOwnPropertyInto(value, key, cell) {
	const indexed = indexedRecords.get(value);
	if (indexed) {
		const index = indexedRecordIndex(indexed, key);
		if (index !== void 0 && indexed.initialized[index]) {
			cell.value = indexed.target[key];
			return true;
		}
		cell.value = void 0;
		return false;
	}
	const descriptor = Object.getOwnPropertyDescriptor(value, key);
	if (descriptor && "value" in descriptor) {
		cell.value = descriptor.value;
		return true;
	}
	cell.value = void 0;
	return false;
}
//#endregion
//#region ../packages/reactive/dist/protocol.js
/** Wraps encoded array items when their validated source owns compiler-registered list keys. */
function encodeValidatedReactiveCollection(source, items) {
	return encodeValidatedReactiveCollectionInternal(source, items, listKeyExtractors.get(source)?.key);
}
//#endregion
//#region ../packages/core/dist/server/component/domain.js
var componentDomainRuntimeStateKey = Symbol.for("@exactjs/component-domain.runtime-state");
var componentDomainRuntimeState = (() => {
	const scope = globalThis;
	return scope[componentDomainRuntimeStateKey] ??= {
		resumingDomains: /* @__PURE__ */ new WeakMap(),
		domainCapabilities: /* @__PURE__ */ new WeakMap(),
		wallClockUsedDomains: /* @__PURE__ */ new WeakSet()
	};
})();
var { domainCapabilities, resumingDomains, wallClockUsedDomains } = componentDomainRuntimeState;
var pageComponentDomainKey = Symbol.for("@exactjs/page-component-domain");
var sharedDomains = globalThis;
/** The default execution namespace for ordinary page-authored component instances. */
var pageComponentDomain = sharedDomains[pageComponentDomainKey] ??= constructComponentDomain({ executionRoot: "page" });
/** Creates a component domain with capabilities reserved for framework packages. */
function createFrameworkComponentDomain(options) {
	const domain = constructComponentDomain(options);
	const logging = Object.prototype.hasOwnProperty.call(options, "logger") ? {
		logger: options.logger,
		componentOverride: false
	} : void 0;
	const capabilities = Object.freeze({
		target: options.target ? options.target : void 0,
		dispatchContinuation: options.dispatchContinuation ? options.dispatchContinuation : void 0,
		resumeComponent: options.resumeComponent ? options.resumeComponent : void 0,
		inspection: options.inspection ? options.inspection : void 0,
		inspectionActivation: options.inspectionActivation ? options.inspectionActivation : void 0,
		wallClockSnapshot: options.wallClockSnapshot !== void 0 ? options.wallClockSnapshot : void 0,
		logging
	});
	domainCapabilities.set(domain, capabilities);
	return domain;
}
/** Selects generic context lookup after a component introduces a logger override. */
function markComponentDomainLoggerOverride(domain) {
	const logging = domainCapabilities.get(domain)?.logging;
	if (logging) logging.componentOverride = true;
}
/** Reports whether optional clock behavior consumed this framework domain's request sample. */
function componentDomainUsesWallClock(domain) {
	return wallClockUsedDomains.has(domain);
}
function constructComponentDomain(options) {
	if (!options.executionRoot) throw new Error("Component execution root must be a non-empty string");
	return Object.freeze({ executionRoot: options.executionRoot });
}
/** Runs synchronous operation creation with an explicit immutable component domain. */
function withComponentDomain(domain, work) {
	return withComponentDomainSnapshot(domain, work);
}
/** Restores captured receipt ownership, including an originally unowned creation scope. */
function withComponentDomainSnapshot(domain, work) {
	const previous = componentDomainRuntimeState.activeDomain;
	componentDomainRuntimeState.activeDomain = domain;
	try {
		return work();
	} finally {
		componentDomainRuntimeState.activeDomain = previous;
	}
}
/** Returns the domain currently responsible for authored operation creation. */
function currentComponentDomain() {
	return componentDomainRuntimeState.activeDomain;
}
//#endregion
//#region ../packages/core/dist/server/server-render-program.js
var PreparedServerRenderProgram = Symbol.for("@exactjs/prepared-server-render-program");
/**
* Captures compiler-known server slots while the enclosing component issuance scope is active.
* Ordinary invocations retain eager sibling issuance. A compiler-proven deferred region instead
* carries its task owner and a read that the SSR engine performs only after readiness. Neither
* creation nor recognition evaluates that read. Client artifacts retain their own lazy readers.
*/
function createPreparedServerRenderProgram(branded, eagerValues, enhancement, deferredValues) {
	const domain = enhancement ? currentComponentDomain() : void 0;
	const invocation = {
		[PreparedServerRenderProgram]: true,
		program: branded,
		eagerValues
	};
	if (enhancement) invocation.enhancement = enhancement;
	if (deferredValues) invocation.deferredValues = deferredValues;
	if (domain) invocation.domain = domain;
	return invocation;
}
/** Recognizes only the realm-stable compiler-issued direct server invocation shape. */
function readPreparedServerRenderProgram(value) {
	return typeof value === "object" && value !== null && PreparedServerRenderProgram in value ? value : void 0;
}
//#endregion
//#region ../packages/core/dist/server/component-abi/opaque-operation.js
/** Realm-stable identity marker for compiler-issued operations with WeakMap-private contents. */
var exactOpaqueOperationIdentity = Symbol.for("@exactjs/opaque-target-operation");
var exactOpaqueOperationExecution = Symbol.for("@exactjs/opaque-target-operation-execution");
var exactOpaqueOperationMetadata = Symbol.for("@exactjs/opaque-target-operation-metadata");
var emptyOperationPrototype = Object.freeze(Object.defineProperty({}, exactOpaqueOperationIdentity, { value: true }));
var operationPrototypes = /* @__PURE__ */ new WeakMap();
var domainOperationPrototypes = /* @__PURE__ */ new WeakMap();
/** Shares immutable dispatch descriptors while every receipt retains a distinct private identity. */
function operationPrototype(execute) {
	if (!execute) return emptyOperationPrototype;
	let prototype = operationPrototypes.get(execute);
	if (!prototype) {
		prototype = Object.freeze(Object.defineProperties({}, {
			[exactOpaqueOperationIdentity]: { value: true },
			[exactOpaqueOperationExecution]: { value: execute }
		}));
		operationPrototypes.set(execute, prototype);
	}
	return prototype;
}
/** Caches unkeyed ownership metadata weakly so releasing a domain also releases its shared descriptors. */
function domainOperationPrototype(prototype, domain) {
	let domains = domainOperationPrototypes.get(prototype);
	if (!domains) domainOperationPrototypes.set(prototype, domains = /* @__PURE__ */ new WeakMap());
	let owned = domains.get(domain);
	if (!owned) {
		const descriptors = Object.create(prototype);
		owned = Object.freeze(Object.defineProperty(descriptors, exactOpaqueOperationMetadata, { value: Object.freeze({ domain }) }));
		domains.set(domain, owned);
	}
	return owned;
}
/** Returns one private redemption table shared by every copy of the core runtime in this realm. */
function sharedOpaqueOperationStore(name) {
	const key = Symbol.for(`@exactjs/opaque-target-operation-store/${name}`);
	const scope = globalThis;
	const existing = scope[key];
	if (existing instanceof WeakMap) return existing;
	const store = /* @__PURE__ */ new WeakMap();
	scope[key] = store;
	return store;
}
/** Allocates an immutable identity whose contents remain private to its issuing target protocol. */
function createOpaqueOperation(execute, metadata) {
	const prototype = operationPrototype(execute);
	if (metadata?.key === void 0 && metadata?.domain) return Object.freeze(Object.create(domainOperationPrototype(prototype, metadata.domain)));
	const operation = Object.create(prototype);
	if (metadata && (metadata.key !== void 0 || metadata.domain !== void 0)) Object.defineProperty(operation, exactOpaqueOperationMetadata, { value: Object.freeze({ ...metadata }) });
	return Object.freeze(operation);
}
/** Invokes one compiler-issued operation without reading a kind, payload, or child topology. */
function executeOpaqueOperation(value, target) {
	if (typeof value !== "object" || value === null) return void 0;
	const execute = value[exactOpaqueOperationExecution];
	return typeof execute === "function" ? { value: Reflect.apply(execute, value, [target]) } : void 0;
}
//#endregion
//#region ../packages/core/dist/server/render-program.js
var renderProgramReceipts = sharedOpaqueOperationStore("render-program");
/** Dispatch key implemented by targets that execute compiler-closed render programs. */
var exactRenderProgramOperation = Symbol.for("@exactjs/target-operation/render-program");
function executeRenderProgramOperation(target) {
	const data = renderProgramReceipts.get(this);
	if (!data) throw new TypeError("Render-program operation lost its compiler-issued payload");
	return target[exactRenderProgramOperation](this, data);
}
/**
* Registers one compiler-emitted descriptor without copying its trusted executable data.
*
* The module-private weak identity is the renderer's authority boundary. Descriptors are emitted
* as module-local constants by the compiler, so recursively cloning and freezing their nested
* tables during browser startup adds allocation and traversal without validating an external
* input. Network and plugin payloads remain subject to their own boundary validation before they
* can reach this compiler-only operation.
*/
function prepareCompiledRenderProgram(program) {
	if (program.version !== 2) throw new TypeError(`Unsupported eXact render-program ABI; expected version 2`);
	return program;
}
/** Joins invocation-local readers to one compiler-hoisted immutable descriptor. */
function createPreparedRenderProgram(branded, readers, owner, propertyWriter, enhancement) {
	const domain = currentComponentDomain();
	const receipt = createOpaqueOperation(executeRenderProgramOperation, { ...domain ? { domain } : {} });
	renderProgramReceipts.set(receipt, {
		invocation: {
			program: branded,
			readers,
			owner,
			...propertyWriter ? { propertyWriter } : {}
		},
		...enhancement ? { enhancement } : {},
		...domain ? { domain } : {}
	});
	return receipt;
}
/** Reads only compiler-issued client render-program operations. */
function readRenderProgramReceipt(value) {
	return typeof value === "object" && value !== null ? renderProgramReceipts.get(value) : void 0;
}
/** Removes declaration metadata while preserving one compiler-owned render program invocation. */
function withoutRenderProgramReceiptEnhancement(value) {
	const data = readRenderProgramReceipt(value);
	if (!data) return void 0;
	if (!data.enhancement) return value;
	const receipt = createOpaqueOperation(executeRenderProgramOperation, data);
	const { enhancement: _enhancement, ...plain } = data;
	renderProgramReceipts.set(receipt, plain);
	return receipt;
}
/** Evaluates one invocation-local slot through per-slot readers or a combined dispatcher. */
function readRenderProgramSlot(invocation, index) {
	if (invocation.eagerValues) return invocation.eagerValues[index];
	return typeof invocation.readers === "function" ? invocation.readers(index) : invocation.readers[index]();
}
//#endregion
//#region ../packages/core/dist/server/component-contracts.js
/** Global property under which compiled artifacts carry their target-local contract. */
var exactComponentContract = Symbol.for("@exactjs/component-contract");
/** Global marker distinguishing a native eXact component from compatibility-owned functions. */
var exactComponentType = Symbol.for("@exactjs/component");
/** Reads build-validated compiler metadata without repeating recursive runtime validation. */
function readPreparedExactComponentContract(component) {
	const contract = component[exactComponentContract];
	if (contract && contract.artifact?.version !== 2) throw new TypeError(`Unsupported eXact component artifact version ${contract.artifact?.version}; expected 2. Recompile with the matching eXact compiler.`);
	return contract;
}
/** Reads a build-validated current executable target artifact. */
function readPreparedExactExecutableComponentContract(component) {
	const contract = readPreparedExactComponentContract(component);
	if (!contract?.artifact) throw new TypeError(`Native eXact component execution requires a compiled component artifact: ${component.name || "<anonymous>"}`);
	return contract;
}
/** Reads one build-validated server-target executable component contract. */
function readPreparedExactServerExecutableComponentContract(component) {
	const contract = readPreparedExactExecutableComponentContract(component);
	if (contract.artifact.target !== "server") throw new TypeError("Server execution requires a current server component artifact");
	return contract;
}
/** Returns the stable compiler identity used to pair SSR and client component boundaries. */
function exactComponentIdentity(component) {
	const identity = component[exactComponentType];
	if (typeof identity === "string" && identity) return identity;
	throw new Error("Native eXact components require compiler-owned identity");
}
//#endregion
//#region ../packages/core/dist/server/render-children.js
/** Flattens nested compiler-produced child arrays without assigning renderer topology. */
function normalizeChildren(children) {
	const normalized = [];
	appendNormalizedChildren(children, normalized);
	return normalized;
}
/** Appends descendants in order without temporary arrays or variadic argument limits. */
function appendNormalizedChildren(children, normalized) {
	for (const child of children) if (Array.isArray(child)) appendNormalizedChildren(child, normalized);
	else normalized.push(child);
}
/** Normalizes one component output into its owned child sequence. */
function normalizeRenderResult(result) {
	if (!Array.isArray(result)) return [result];
	for (const child of result) if (Array.isArray(child)) return normalizeChildren(result);
	return result;
}
//#endregion
//#region ../packages/core/dist/server/component-abi/receipt.js
var PreparedServerComponentReference = Symbol.for("@exactjs/prepared-server-component-reference");
var emptyServerComponentChildren = Object.freeze([]);
var receipts = sharedOpaqueOperationStore("component");
/** Dispatch key implemented by render targets that accept component operations. */
var exactComponentOperation = Symbol.for("@exactjs/target-operation/component");
function executeComponentOperation(target) {
	const data = receipts.get(this);
	if (!data) throw new TypeError("Component operation lost its compiler-issued payload");
	return target[exactComponentOperation](this, data);
}
/**
* Publishes a direct component-ABI operation without exposing component shape.
* The compiler selects this operation only after resolving the target artifact at build time.
*/
function createCompiledComponentReceipt(type, props, ...children) {
	const { key: authoredKey, __exactEnhancements: enhancement, ...componentProps } = props ?? {};
	const rawKey = unwrap(authoredKey);
	const domain = currentComponentDomain();
	const key = rawKey === null || rawKey === void 0 ? void 0 : String(rawKey);
	const receipt = createOpaqueOperation(executeComponentOperation, {
		...key === void 0 ? {} : { key },
		...domain ? { domain } : {}
	});
	receipts.set(receipt, {
		contract: readPreparedExactExecutableComponentContract(type),
		props: componentProps,
		children: normalizeRenderResult(children),
		...key === void 0 ? {} : { key },
		...domain ? { domain } : {},
		...enhancement ? { enhancement } : {}
	});
	return receipt;
}
/**
* Creates one direct server component reference without an opaque operation or WeakMap payload.
*
* The compiler emits this function only into server-target artifacts. The returned object remains
* request-local and is consumed directly by the server renderer; it must never cross a client or
* compatibility boundary.
*/
function createPreparedServerComponentReference(type, props, ...authoredChildren) {
	const source = props ?? {};
	const authoredKey = source.key;
	const enhancement = source.__exactEnhancements;
	const rawKey = unwrap(authoredKey);
	const key = rawKey === null || rawKey === void 0 ? void 0 : String(rawKey);
	const domain = currentComponentDomain();
	let componentProps = source;
	if (Object.hasOwn(source, "key") || Object.hasOwn(source, "__exactEnhancements")) {
		componentProps = { ...source };
		delete componentProps.key;
		delete componentProps.__exactEnhancements;
	}
	let children = emptyServerComponentChildren;
	if (authoredChildren.length > 0) children = normalizeRenderResult(authoredChildren);
	const reference = {
		[PreparedServerComponentReference]: true,
		contract: readPreparedExactExecutableComponentContract(type),
		props: componentProps,
		children
	};
	if (key !== void 0) reference.key = key;
	if (domain) reference.domain = domain;
	if (enhancement) reference.enhancement = enhancement;
	return reference;
}
/**
* Issues a reference for a compiler-proven fresh private data bag without reserved metadata.
* The caller must exclude own and inherited key/enhancement metadata and previous exposure.
* The bag is retained directly; ordinary reference construction handles all other inputs.
*/
function createPreparedServerComponentReferenceFromPlainProps(type, props) {
	const domain = currentComponentDomain();
	const reference = {
		[PreparedServerComponentReference]: true,
		contract: readPreparedExactExecutableComponentContract(type),
		props,
		children: emptyServerComponentChildren
	};
	if (domain) reference.domain = domain;
	return reference;
}
/** Reads only the direct reference representation issued by a compiler-closed server artifact. */
function readPreparedServerComponentReference(value) {
	return typeof value === "object" && value !== null && PreparedServerComponentReference in value ? value : void 0;
}
/** Reads a compiler-issued receipt; arbitrary objects never become component candidates. */
function readCompiledComponentReceipt(value) {
	return typeof value === "object" && value !== null ? receipts.get(value) : void 0;
}
/** Marks a renderer-injected provider without changing its semantic component parentage. */
function withTransparentComponentUpdateOwner(value) {
	const data = receipts.get(value);
	if (!data) throw new TypeError("Transparent update ownership requires a compiled component receipt");
	const receipt = createOpaqueOperation(executeComponentOperation, data);
	receipts.set(receipt, {
		...data,
		transparentUpdateOwner: true
	});
	return receipt;
}
/** Marks an already resolved fragment handoff without exposing renderer configuration as authored props. */
function withFragmentEnhancementTarget(value, supplied, tag = "span") {
	const data = receipts.get(value);
	if (!data) throw new TypeError("Fragment handoff requires a compiled component receipt");
	const receipt = createOpaqueOperation(executeComponentOperation, data);
	receipts.set(receipt, {
		...data,
		fragmentTarget: {
			supplied,
			tag
		}
	});
	return receipt;
}
//#endregion
//#region ../packages/core/dist/server/component-abi/server-keyed-child.js
var PreparedServerKeyedChild = Symbol.for("@exactjs/server/prepared-keyed-child");
/** Only compiler-proven program children may omit the wrapper; key validation and coercion remain. */
function createPreparedServerKeyedChild(value, authoredKey, program = false) {
	const key = unwrap(authoredKey);
	if (key === null || key === void 0) throw new Error("Compiled keyed lists require a key");
	const normalizedKey = String(key);
	if (program) return value;
	return {
		[PreparedServerKeyedChild]: true,
		value,
		key: normalizedKey
	};
}
/** Reads only direct keyed children issued by compiler-closed server artifacts. */
function readPreparedServerKeyedChild(value) {
	return typeof value === "object" && value !== null && PreparedServerKeyedChild in value ? value : void 0;
}
//#endregion
//#region ../packages/core/dist/server/protocol.js
var markerUtf8Encoder = new TextEncoder();
var markerHexBytes = Array.from({ length: 256 }, (_, byte) => byte.toString(16).padStart(2, "0"));
/** Encodes arbitrary UTF-8 data for use inside an eXact HTML comment marker. */
function encodeExactMarkerPart(value) {
	if (/^[A-Za-z0-9._-]+$/.test(value) && !value.includes("--")) return value;
	const bytes = markerUtf8Encoder.encode(value);
	let encoded = "~";
	for (let index = 0; index < bytes.length; index++) encoded += markerHexBytes[bytes[index]];
	return encoded;
}
sharedOpaqueOperationStore("server-boundary");
var slots = sharedOpaqueOperationStore("server-slot");
/** Dispatch key implemented by SSR targets that publish a client island. */
var exactServerBoundaryOperation = Symbol.for("@exactjs/target-operation/server-boundary");
/** Dispatch key implemented by SSR targets that retain a server-owned range. */
var exactServerSlotOperation = Symbol.for("@exactjs/target-operation/server-slot");
/** Reads a compiler-issued retained server-range operation without accepting arbitrary objects. */
function readServerSlotReceipt(value) {
	return typeof value === "object" && value !== null ? slots.get(value) : void 0;
}
//#endregion
//#region ../packages/core/dist/server/framework/server-render-structure.js
/** Evaluates a compiler-known expression directly in a compiler-closed server component. */
function createExpression(compute) {
	return compute();
}
/** Creates the eager server operation for one compiler-owned dynamic child range. */
function createCompiledChildRangeReceipt(compute, markerId, mayReplaceSubtree = true) {
	return createPreparedServerChildRange(compute(), markerId, mayReplaceSubtree);
}
//#endregion
//#region ../packages/server/dist/framework/render-scheduling.js
var schedulerRegistry = Symbol.for("@exactjs/server/request-render-schedulers");
var schedulers = globalThis[schedulerRegistry] ??= /* @__PURE__ */ new WeakMap();
/** Returns the adapter policy associated with this request's cancellation lifetime. */
function requestRenderScheduler(signal) {
	return signal ? schedulers.get(signal) : void 0;
}
/** Preserves the first host policy when a framework scope derives a cancellation signal. */
function inheritRequestRenderScheduler(source, target) {
	const schedule = requestRenderScheduler(source);
	if (schedule && !schedulers.has(target)) schedulers.set(target, schedule);
}
//#endregion
//#region ../packages/ssr/dist/render/utf8-encoding.js
/** Selects available host encoding capabilities, retaining standard TextEncoder support. */
function createSsrUtf8Codec(buffer) {
	const encoder = typeof buffer?.from === "function" ? void 0 : new TextEncoder();
	return {
		encode: encoder ? encoder.encode.bind(encoder) : buffer.from.bind(buffer),
		byteLength: typeof buffer?.byteLength === "function" ? buffer.byteLength.bind(buffer) : void 0
	};
}
var codec = createSsrUtf8Codec(globalThis.Buffer);
/** Encodes an independently owned output range using the current host's UTF-8 implementation. */
var encodeSsrUtf8 = codec.encode;
/** Native byte counting when provided by the host; portable callers retain their own fallback. */
var nativeUtf8ByteLength = codec.byteLength;
//#endregion
//#region ../packages/ssr/dist/render/utf8.js
var nonAsciiCodeUnit = /[\u0080-\uffff]/g;
/** Counts a string's encoded UTF-8 length without constructing an encoded buffer. */
function utf8ByteLength(value) {
	return nativeUtf8ByteLength ? nativeUtf8ByteLength(value) : portableUtf8ByteLength(value);
}
/** Counts UTF-8 bytes when the host does not supply a native counter, including unpaired surrogates. */
function portableUtf8ByteLength(value) {
	if (value.length >= 32) {
		let bytes = value.length;
		nonAsciiCodeUnit.lastIndex = 0;
		let windowStart = -1;
		let matches = 0;
		let nonAsciiUnits = 0;
		while (nonAsciiCodeUnit.test(value)) {
			const index = nonAsciiCodeUnit.lastIndex - 1;
			if (windowStart < 0) windowStart = index;
			const code = value.charCodeAt(index);
			nonAsciiUnits++;
			if (code <= 2047) bytes++;
			else {
				bytes += 2;
				if (isHighSurrogate(code) && isLowSurrogate(value.charCodeAt(index + 1))) {
					nonAsciiCodeUnit.lastIndex++;
					nonAsciiUnits++;
				}
			}
			if (++matches === 8) {
				const end = nonAsciiCodeUnit.lastIndex;
				if (nonAsciiUnits * 4 > end - windowStart) return bytes - (value.length - end) + countUtf8Suffix(value, end);
				windowStart = end;
				matches = 0;
				nonAsciiUnits = 0;
			}
		}
		return bytes;
	}
	return countUtf8Suffix(value, 0);
}
function countUtf8Suffix(value, start) {
	let bytes = 0;
	for (let index = start; index < value.length; index++) {
		const code = value.charCodeAt(index);
		if (code <= 127) bytes++;
		else if (code <= 2047) bytes += 2;
		else if (isHighSurrogate(code) && isLowSurrogate(value.charCodeAt(index + 1))) {
			bytes += 4;
			index++;
		} else bytes += 3;
	}
	return bytes;
}
/** Reports whether one UTF-16 code unit begins a surrogate pair. */
function isHighSurrogate(code) {
	return code >= 55296 && code <= 56319;
}
/** Reports whether one UTF-16 code unit completes a surrogate pair. */
function isLowSurrogate(code) {
	return code >= 56320 && code <= 57343;
}
//#endregion
//#region ../packages/core/dist/server/framework/protocol-records.js
/** Normalizes a positive safe-integer protocol resource limit. */
function normalizeProtocolLimit(value, fallback) {
	return typeof value === "number" && Number.isSafeInteger(value) && value > 0 ? value : fallback;
}
/** Validates the exact finite discriminator shape used by server slots and hydration. */
function isServerSlotDiscriminator(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	const discriminator = value;
	if (discriminator.kind === "single") return Object.keys(discriminator).length === 1;
	if (discriminator.kind === "branch") return Object.keys(discriminator).length === 2 && typeof discriminator.branch === "string" && !!discriminator.branch;
	return discriminator.kind === "keyed" && Object.keys(discriminator).length === 3 && typeof discriminator.list === "string" && !!discriminator.list && typeof discriminator.keyToken === "string" && !!discriminator.keyToken;
}
//#endregion
//#region ../packages/ssr/dist/render/limits.js
var DEFAULT_MAX_TREE_DEPTH = 512;
var HARD_MAX_TREE_DEPTH = 1024;
var DEFAULT_MAX_TREE_NODES = 1e5;
var DEFAULT_MAX_OUTPUT_BYTES = 16777216;
var DEFAULT_MAX_TASK_DURATION_MS = 3e4;
/** Signals that SSR traversal exceeded its configured nesting limit. */
var SsrTreeDepthError = class extends Error {
	constructor(limit) {
		super(`eXact SSR tree exceeds the configured maximum depth of ${limit}`);
		this.name = "SsrTreeDepthError";
	}
};
/** Signals that observed component tasks exceeded the request deadline. */
var SsrTaskDeadlineError = class extends Error {
	constructor() {
		super("SSR task duration limit exceeded");
		this.name = "SsrTaskDeadlineError";
	}
};
/** Signals that SSR traversal processed too many render values. */
var SsrTreeNodeError = class extends Error {
	constructor(limit) {
		super(`eXact SSR tree exceeds the configured maximum of ${limit} render values`);
		this.name = "SsrTreeNodeError";
	}
};
/** Signals that encoded SSR output exceeded its byte budget. */
var SsrOutputLimitError = class extends Error {
	constructor(limit) {
		super(`eXact SSR output exceeds the configured maximum of ${limit} bytes`);
		this.name = "SsrOutputLimitError";
	}
};
/** Default maximum number of render values processed by one SSR operation. */
var defaultMaxSsrTreeNodes = DEFAULT_MAX_TREE_NODES;
/** Default maximum encoded bytes produced by one SSR operation. */
var defaultMaxSsrOutputBytes = DEFAULT_MAX_OUTPUT_BYTES;
/** Normalizes a caller-provided depth limit and applies the hard safety cap. */
function normalizeSsrTreeDepth(value) {
	return Number.isSafeInteger(value) && value > 0 ? Math.min(value, HARD_MAX_TREE_DEPTH) : DEFAULT_MAX_TREE_DEPTH;
}
/** Charges one render value against the context's traversal budget. */
function countSsrNode(context) {
	countSsrNodes(context, 1);
}
/** Charges a compiler-proven finite group against the traversal budget in one operation. */
function countSsrNodes(context, count) {
	context.traversedNodes += count;
	if (context.traversedNodes > context.maxTreeNodes) throw new SsrTreeNodeError(context.maxTreeNodes);
}
/** Appends one output chunk while retaining the request's conservative character ceiling. */
function appendBoundedHtml(context, html, chunk) {
	const appended = html + chunk;
	assertOutputCharacterBound(context, appended);
	return appended;
}
/**
* Applies a constant-time conservative bound to a UTF-16 output string.
*
* UTF-8 is never shorter than its UTF-16 code-unit count. Exact byte counting
* is reserved for roots to avoid rescanning every descendant at each ancestor.
*/
function assertOutputCharacterBound(context, html) {
	if (html.length > context.maxOutputBytes) throw new SsrOutputLimitError(context.maxOutputBytes);
}
/** Verifies the exact UTF-8 byte length when non-ASCII output requires it. */
function assertOutputWithinLimit(context, html) {
	assertOutputCharacterBound(context, html);
	if (utf8ByteLength(html) > context.maxOutputBytes) throw new SsrOutputLimitError(context.maxOutputBytes);
}
/** Enters one traversal frame without allocating a callback closure. */
function enterSsrTreeDepth(context) {
	context.traversalDepth++;
	if (context.traversalDepth <= context.maxTreeDepth) return;
	context.traversalDepth--;
	throw new SsrTreeDepthError(context.maxTreeDepth);
}
/** Leaves a traversal frame entered by {@link enterSsrTreeDepth}. */
function leaveSsrTreeDepth(context) {
	context.traversalDepth--;
}
/** Adds one stable task deadline without extending an existing render deadline. */
function withTaskDeadline(options) {
	if (typeof options.taskDeadline === "number") return options;
	const duration = Number.isSafeInteger(options.maxTaskDurationMs) && options.maxTaskDurationMs > 0 ? options.maxTaskDurationMs : DEFAULT_MAX_TASK_DURATION_MS;
	return {
		...options,
		taskDeadline: Date.now() + duration
	};
}
//#endregion
//#region ../packages/ssr/dist/render/context.js
/** Performs the drain tasks domain operation. */
async function drainTasks(pending, maxPasses, signal, deadline) {
	for (let pass = 0; pending.size && pass < maxPasses; pass++) {
		if (signal?.aborted) throw signal.reason ?? new DOMException("SSR render aborted", "AbortError");
		await awaitWithAbort(Promise.all(pending), signal, deadline);
	}
	if (pending.size) throw new Error(`SSR task drain exceeded ${maxPasses} passes`);
}
/** Performs the await with abort domain operation. */
async function awaitWithAbort(promise, signal, deadline) {
	if (signal?.aborted) {
		promise.catch(() => {});
		throw signal.reason ?? new DOMException("SSR render aborted", "AbortError");
	}
	if (!signal && deadline === void 0) return promise;
	const remaining = deadline === void 0 ? void 0 : deadline - Date.now();
	if (remaining !== void 0 && remaining <= 0) {
		promise.catch(() => {});
		throw new SsrTaskDeadlineError();
	}
	let abort;
	let timer;
	const interrupted = new Promise((_, reject) => {
		if (signal) {
			abort = () => reject(signal.reason ?? new DOMException("SSR render aborted", "AbortError"));
			signal.addEventListener("abort", abort, { once: true });
		}
		if (remaining !== void 0) timer = setTimeout(() => reject(new SsrTaskDeadlineError()), remaining);
	});
	try {
		return await Promise.race([promise, interrupted]);
	} finally {
		if (signal && abort) signal.removeEventListener("abort", abort);
		if (timer) clearTimeout(timer);
	}
}
/** Creates request-owned render state; task scheduling is allocated on first use. */
function createSsrContext(options) {
	const wallClockSnapshot = Date.now();
	return {
		executionRoot: options.executionRoot ?? "page",
		buildKey: options.buildKey,
		markers: options.markers ?? true,
		textSeparators: options.textSeparators ?? false,
		reactMarkup: options.reactMarkup ?? false,
		nextId: 0,
		logger: options.logger,
		maxTaskPasses: normalizeProtocolLimit(options.maxTaskPasses, 10),
		maxTreeDepth: normalizeSsrTreeDepth(options.maxTreeDepth),
		traversalDepth: 0,
		maxTreeNodes: normalizeProtocolLimit(options.maxTreeNodes, defaultMaxSsrTreeNodes),
		traversedNodes: 0,
		maxOutputBytes: normalizeProtocolLimit(options.maxOutputBytes, defaultMaxSsrOutputBytes),
		dynamicComponentArtifacts: options.dynamicComponentArtifacts,
		maxDynamicComponentPreloads: normalizeProtocolLimit(options.maxDynamicComponentPreloads, 16),
		dynamicComponentPreloads: 0,
		onEarlyHints: options.onEarlyHints,
		allowUnsafeHtml: options.allowUnsafeHtml ?? false,
		onUnsafeHtml: options.onUnsafeHtml,
		documentProbe: true,
		documentRootSeen: false,
		documentHeadSeen: false,
		documentBodySeen: false,
		hostStack: [],
		enhancementCatalog: options.enhancementCatalog,
		componentContexts: options.contexts,
		componentDomain: createFrameworkComponentDomain({
			target: "server",
			executionRoot: options.inspection?.executionRoot ?? options.executionRoot ?? "page",
			...options.inspection ? { inspection: options.inspection } : {},
			wallClockSnapshot
		}),
		wallClockSnapshot,
		onComponentCreated: options.onComponentCreated,
		onComponentRendered: options.onComponentRendered,
		onComponentAttemptCheckpoint: options.onComponentAttemptCheckpoint,
		onComponentAttemptRollback: options.onComponentAttemptRollback,
		onDirectComponentCreated: options.onDirectComponentCreated,
		onDirectComponentRendered: options.onDirectComponentRendered
	};
}
//#endregion
//#region ../packages/ssr/dist/render/resume-scheduling.js
/** Resolves host policy once before rendering, retaining explicit caller overrides. */
function withRequestRenderScheduling(options) {
	if (options.scheduleRender) return options;
	const scheduleRender = requestRenderScheduler(options.signal);
	return scheduleRender ? {
		...options,
		scheduleRender
	} : options;
}
/** Consults host admission after actual data readiness; no promise is created for an immediate policy. */
function resumeSsrWork(options, resume) {
	options.signal?.throwIfAborted();
	const pending = options.scheduleRender?.(options.signal);
	if (!pending) return resume();
	return awaitWithAbort(pending, options.signal, options.taskDeadline).then(() => {
		options.signal?.throwIfAborted();
		return resume();
	});
}
/** Drains actual blocking generations, then rechecks readiness after conditional admission. */
function settleSsrReadiness(execution, options, maxPasses, pass = 0, admitted = false) {
	const pending = execution.blockingWork();
	if (!pending) {
		if (pass && !admitted) return resumeSsrWork(options, () => settleSsrReadiness(execution, options, maxPasses, pass, true));
		return;
	}
	if (pass === maxPasses) throw new Error(`SSR task drain exceeded ${maxPasses} passes`);
	return awaitWithAbort(pending, options.signal, options.taskDeadline).then(() => settleSsrReadiness(execution, options, maxPasses, pass + 1));
}
//#endregion
//#region ../packages/core/dist/server/component/element-identity.js
var identities = /* @__PURE__ */ new WeakMap();
var idToken = /^[^\t\n\f\r ]+$/u;
/** Returns a relationship-safe permanent ID for an already materialized element. */
function ensureElementId(element) {
	const authored = validElementId(element.id);
	if (authored) return authored;
	if (element.id) throw new TypeError("Element IDs cannot contain ASCII whitespace");
	const platformCrypto = globalThis.crypto;
	if (!platformCrypto?.randomUUID) throw new Error("Element identity requires the platform crypto.randomUUID() API");
	element.id = `exact-${platformCrypto.randomUUID()}`;
	return element.id;
}
/**
* Reserves a stable ID token for an element ref before its DOM node necessarily exists.
* Renderers use the reservation for SSR emission and hydration adoption.
*/
function reserveElementId(binding) {
	const current = binding.current;
	if (current) {
		const authored = validElementId(current.id);
		if (authored) {
			identities.set(binding, {
				id: authored,
				generated: false
			});
			return authored;
		}
	}
	const existing = identities.get(binding);
	if (existing) return existing.id;
	const id = ensureElementId({ id: "" });
	identities.set(binding, {
		id,
		generated: true
	});
	return id;
}
/** Adopts an emitted or authored ID for a ref during SSR planning or hydration. */
function adoptElementId(binding, id) {
	const token = validElementId(id);
	if (!token) return false;
	identities.set(binding, {
		id: token,
		generated: false
	});
	return true;
}
function validElementId(value) {
	return typeof value === "string" && idToken.test(value) ? value : void 0;
}
//#endregion
//#region ../packages/core/dist/server/class-values.js
/**
* Normalizes one compiler-authored class value into its DOM attribute representation.
*
* Arrays retain source order, objects contribute truthy keys in property order, and reactive
* values are unwrapped at every nesting level. Duplicate tokens are deliberately preserved:
* only the compiler can diagnose collisions that are statically provable without changing
* dynamic authored behavior.
*/
function normalizeClassValue(value) {
	return appendClassValue("", value);
}
function appendClassValue(output, candidate) {
	const actual = unwrap(candidate);
	if (actual === false || actual === null || actual === void 0) return output;
	if (Array.isArray(actual)) {
		for (const item of actual) output = appendClassValue(output, item);
		return output;
	}
	if (typeof actual === "object") {
		for (const name in actual) {
			if (!Object.hasOwn(actual, name)) continue;
			if (Boolean(unwrap(actual[name]))) output = appendClassToken(output, name);
		}
		return output;
	}
	return appendClassToken(output, String(actual));
}
function appendClassToken(output, token) {
	if (!token) return output;
	return output ? `${output} ${token}` : token;
}
//#endregion
//#region ../packages/core/dist/server/cleanup.js
/** Creates an empty collector for a failure-complete cleanup sequence. */
function createCleanupFailure() {
	return {
		failed: false,
		error: void 0
	};
}
/** Records the first cleanup error while retaining the fact that cleanup failed. */
function recordCleanupFailure(failure, error) {
	if (!failure.failed) failure.error = error;
	failure.failed = true;
}
/**
* Attempts one synchronous cleanup without interrupting subsequent cleanups.
*/
function attemptCleanup(failure, cleanup) {
	try {
		cleanup();
	} catch (error) {
		recordCleanupFailure(failure, error);
	}
}
/** Throws the first error recorded by a completed cleanup sequence. */
function throwCleanupFailure(failure) {
	if (failure.failed) throw failure.error;
}
/**
* Preserves an active primary failure while retaining cleanup diagnostics.
*
* Attaching diagnostic metadata is deliberately best-effort because a frozen
* or hostile primary value must never replace the error already in flight.
*/
function attachSuppressedCleanupFailure(primary, cleanup) {
	if (!primary || typeof primary !== "object" && typeof primary !== "function") return;
	try {
		const target = primary;
		const suppressed = Array.isArray(target.suppressed) ? target.suppressed : [];
		suppressed.push(cleanup);
		if (target.suppressed !== suppressed) Object.defineProperty(target, "suppressed", {
			configurable: true,
			value: suppressed
		});
	} catch {}
}
//#endregion
//#region ../packages/core/dist/server/activity.js
/** Validates and normalizes the authored mode of a native Activity boundary. */
function normalizeActivityMode(value) {
	if (value === void 0 || value === "active") return "active";
	if (value === "parked" || value === "background") return value;
	throw new TypeError(`Activity mode must be "active", "parked", or "background"; received ${String(value)}`);
}
//#endregion
//#region ../packages/core/dist/server/keys.js
/** Creates a context token; global tokens use Symbol.for so separate bundles can share identity. */
function createContext(description, options = false) {
	const global = typeof options === "boolean" ? options : options.global ?? false;
	const reactive = typeof options === "boolean" ? true : options.reactive ?? true;
	return {
		id: global ? Symbol.for(`exact.context:${description}`) : Symbol(description),
		description,
		global,
		reactive,
		keep: typeof options === "boolean" ? void 0 : options.keep,
		scope: typeof options === "boolean" ? "component" : options.scope ?? "component"
	};
}
//#endregion
//#region ../packages/core/dist/server/tasks/observers.js
var taskObserverStack = [];
/** Runs work with a task observer installed for nested component construction. */
function withTaskObserver(observer, fn) {
	if (!observer) return fn();
	taskObserverStack.push(observer);
	try {
		return fn();
	} finally {
		taskObserverStack.pop();
	}
}
//#endregion
//#region ../packages/core/dist/server/component/contexts.js
/** Provides the canonical logger context value. */
var LoggerContext = createContext("exact.logger", true);
/** Provides the canonical error context value. */
var ErrorContext = createContext("exact.error", {
	global: true,
	reactive: false
});
createContext("exact.suspension", true);
createContext("exact.readiness", true);
//#endregion
//#region ../packages/core/dist/server/logging.js
var logLevelOrder = {
	trace: 0,
	debug: 1,
	info: 2,
	warn: 3,
	error: 4
};
/** Creates a logger implementation that writes formatted eXact events to the console. */
function createConsoleLogger(options = {}) {
	const minimumLevel = options.level ?? "info";
	return {
		isEnabled(level) {
			return logLevelOrder[level] >= logLevelOrder[minimumLevel];
		},
		log(event) {
			const prefix = `${formatLogScope(event.scope)} ${event.message}`;
			const consoleMethod = getConsoleMethod(event.level);
			if (event.error !== void 0 && event.data !== void 0) consoleMethod(prefix, event.error, event.data);
			else if (event.error !== void 0) consoleMethod(prefix, event.error);
			else if (event.data !== void 0) consoleMethod(prefix, event.data);
			else consoleMethod(prefix);
		}
	};
}
/** Formats a structured log scope into the compact prefix used by framework logs. */
function formatLogScope(scope) {
	if (scope.source === "component" && scope.component) return `[exact] [component:${scope.component.name}#${scope.component.id}]`;
	return `[exact] [${[
		"framework",
		scope.packageName,
		scope.category
	].filter(Boolean).join(":")}]`;
}
function getConsoleMethod(level) {
	if (level === "trace") return console.trace?.bind(console) ?? console.debug.bind(console);
	if (level === "debug") return console.debug.bind(console);
	if (level === "info") return console.info.bind(console);
	if (level === "warn") return console.warn.bind(console);
	return console.error.bind(console);
}
//#endregion
//#region ../packages/core/dist/server/component/default-logger.js
/** Provides the canonical default console logger without linking component logging machinery. */
var defaultConsoleLogger = createConsoleLogger();
//#endregion
//#region ../packages/core/dist/server/component/log.js
/** Emits a framework-scoped log event through the supplied or default logger. */
function logFrameworkEvent(level, packageName, category, message, data, logger = defaultConsoleLogger) {
	const scope = {
		source: "framework",
		packageName,
		category
	};
	if (!isLogEnabled(logger, level, scope)) return;
	emitLogEvent(logger, {
		level,
		message: evaluateLogValue(message),
		data: data === void 0 ? void 0 : evaluateLogValue(data),
		scope
	});
}
Object.freeze({ source: "component" });
function isLogEnabled(logger, level, scope) {
	try {
		return !logger.isEnabled || logger.isEnabled(level, scope);
	} catch (error) {
		reportLoggerFailure(error);
		return false;
	}
}
function emitLogEvent(logger, event) {
	try {
		logger.log(event);
	} catch (error) {
		reportLoggerFailure(error);
	}
}
function reportLoggerFailure(error) {
	try {
		defaultConsoleLogger.log({
			level: "error",
			message: "logger failed while handling eXact log event",
			error,
			scope: {
				source: "framework",
				packageName: "core",
				category: "logger"
			}
		});
	} catch {}
}
function evaluateLogValue(value) {
	return typeof value === "function" ? value() : value;
}
//#endregion
//#region ../packages/core/dist/server/component-abi/intrinsic-receipt.js
var intrinsics = sharedOpaqueOperationStore("intrinsic");
var compositionViews = sharedOpaqueOperationStore("intrinsic-composition");
/** Redeems authored intrinsic structure only for explicit child inspection or derivation. */
function readComposableIntrinsicReceipt(value) {
	const direct = readCompiledIntrinsicReceipt(value);
	if (direct || typeof value !== "object" || value === null) return direct;
	const view = compositionViews.get(value);
	if (!view) return void 0;
	if (!view.data) {
		const data = readCompiledIntrinsicReceipt(withComponentDomainSnapshot(view.domain, view.factory));
		if (!data) throw new TypeError("An intrinsic composition view must describe an intrinsic receipt");
		view.data = data;
		view.factory = void 0;
		view.domain = void 0;
	}
	return view.data;
}
/** Dispatch key implemented by render targets that accept intrinsic operations. */
var exactIntrinsicOperation = Symbol.for("@exactjs/target-operation/intrinsic");
function executeIntrinsicOperation(target) {
	const data = intrinsics.get(this);
	if (!data) throw new TypeError("Intrinsic operation lost its compiler-issued payload");
	return target[exactIntrinsicOperation](this, data);
}
/** Issues a direct intrinsic operation. */
function createCompiledIntrinsicReceipt(tag, props, ...children) {
	if (typeof tag !== "string") throw new TypeError("Compiled intrinsic receipt requires an intrinsic tag");
	const { key: authoredKey, __exactEnhancements: enhancement, ...intrinsicProps } = props ?? {};
	const rawKey = unwrap(authoredKey);
	const domain = currentComponentDomain();
	const key = rawKey === null || rawKey === void 0 ? void 0 : String(rawKey);
	const receipt = createOpaqueOperation(executeIntrinsicOperation, {
		key,
		domain
	});
	intrinsics.set(receipt, {
		tag,
		props: intrinsicProps,
		children: normalizeRenderResult(children),
		key,
		domain,
		enhancement: enhancement ? enhancement : void 0
	});
	return receipt;
}
/** Reads only compiler-issued intrinsic operations. */
function readCompiledIntrinsicReceipt(value) {
	return typeof value === "object" && value !== null ? intrinsics.get(value) : void 0;
}
/** Derives an intrinsic while retaining every attribute and ownership capability by identity. */
function withIntrinsicReceiptChildren(value, children) {
	const data = readComposableIntrinsicReceipt(value);
	if (!data) throw new TypeError("withChildren requires a composable intrinsic element");
	const receipt = createOpaqueOperation(executeIntrinsicOperation, data);
	intrinsics.set(receipt, {
		...data,
		children
	});
	return receipt;
}
/** Removes declaration metadata while preserving one compiler-issued intrinsic operation. */
function withoutCompiledIntrinsicReceiptEnhancement(value) {
	const data = readCompiledIntrinsicReceipt(value);
	if (!data) return void 0;
	if (!data.enhancement) return value;
	const receipt = createOpaqueOperation(executeIntrinsicOperation, data);
	const { enhancement: _enhancement, ...plain } = data;
	intrinsics.set(receipt, plain);
	return receipt;
}
//#endregion
//#region ../packages/core/dist/server/tasks/dependency-provenance.js
var sources = /* @__PURE__ */ new WeakMap();
/** Returns the unresolved execution source propagated with a compiler-created value. */
function continuationDependencyForValue(value) {
	if (!(typeof value === "object" && value !== null || typeof value === "function")) return void 0;
	return sources.get(value);
}
//#endregion
//#region ../packages/core/dist/server/tasks/dependency-source.js
/** Returns only a compiler-propagated dependency source without evaluating an ordinary value. */
function plannedContinuationDependency(input) {
	return continuationDependencyForValue(input);
}
//#endregion
//#region ../packages/core/dist/server/component-abi/server.js
/** Request protocol key that creates and owns one request-local server frame. */
var exactServerIssue = Symbol.for("@exactjs/server-component-issue");
/** Writer protocol key that serializes one issued frame in authored output order. */
var exactServerWrite = Symbol.for("@exactjs/server-component-write");
/** Frame protocol key that releases request-local ownership exactly once. */
var exactServerDispose = Symbol.for("@exactjs/server-component-dispose");
//#endregion
//#region ../packages/core/dist/server/component-abi/server-runtime.js
/** Establishes request ownership through the request execution protocol. */
function issueExactServerComponent(request, parent, props) {
	return request[exactServerIssue](this, parent, props);
}
/** Publishes an issued frame through the writer protocol in authored order. */
function writeExactServerComponent(frame, output) {
	return output[exactServerWrite](this, frame);
}
/** Releases request-local frame ownership without storing request state on the artifact. */
function disposeExactServerComponent(frame, reason) {
	return frame[exactServerDispose](this, reason);
}
//#endregion
//#region ../packages/core/dist/server/component-abi/target-receipt.js
var targets = sharedOpaqueOperationStore("target");
/** Dispatch key implemented by render targets that accept semantic target ranges. */
var exactTargetOperation = Symbol.for("@exactjs/target-operation/target");
function executeTargetOperation(target) {
	const data = targets.get(this);
	if (!data) throw new TypeError("Target operation lost its compiler-issued payload");
	return target[exactTargetOperation](this, data);
}
/** Issues a semantic-target range operation directly. */
function createCompiledTargetReceipt(props, ...children) {
	const { key: authoredKey, __exactTargetHostProps, ...targetProps } = props ?? {};
	const rawKey = unwrap(authoredKey);
	const domain = currentComponentDomain();
	const key = rawKey === null || rawKey === void 0 ? void 0 : String(rawKey);
	const receipt = createOpaqueOperation(executeTargetOperation, {
		key,
		domain
	});
	targets.set(receipt, {
		props: targetProps,
		children: normalizeRenderResult(children),
		declaredHostProps: __exactTargetHostProps === true ? true : void 0,
		key,
		domain
	});
	return receipt;
}
/**
* Issues one target placement with separately owned layers, avoiding a rendered node per owner.
* Caller-provided identities are retained only for the lifetime of this operation and its mount.
* The target is already prepared; this helper does not evaluate children or choose enhancements.
*/
function createCompiledTargetContributions(contributions, target) {
	const identities = /* @__PURE__ */ new Set();
	for (const contribution of contributions) {
		if (identities.has(contribution.identity)) throw new TypeError("Duplicate target contribution owner");
		identities.add(contribution.identity);
	}
	const receipt = createCompiledTargetReceipt(null, target);
	targets.set(receipt, {
		...targets.get(receipt),
		contributions: Object.freeze([...contributions])
	});
	return receipt;
}
/** Reads only compiler-issued semantic-target operations. */
function readCompiledTargetReceipt(value) {
	return typeof value === "object" && value !== null ? targets.get(value) : void 0;
}
//#endregion
//#region ../packages/core/dist/server/component-abi/fragment-receipt.js
var fragments = sharedOpaqueOperationStore("fragment");
/** Dispatch key implemented by render targets that accept fragment ranges. */
var exactFragmentOperation = Symbol.for("@exactjs/target-operation/fragment");
function executeFragmentOperation(target) {
	const data = fragments.get(this);
	if (!data) throw new TypeError("Fragment operation lost its compiler-issued payload");
	return target[exactFragmentOperation](this, data);
}
/** Issues a transparent range operation directly. */
function createCompiledFragmentReceipt(props, ...children) {
	const { key: authoredKey, __exactEnhancements: enhancement, ...fragmentProps } = props ?? {};
	const rawKey = unwrap(authoredKey);
	const domain = currentComponentDomain();
	const key = rawKey === null || rawKey === void 0 ? void 0 : String(rawKey);
	const receipt = createOpaqueOperation(executeFragmentOperation, {
		key,
		domain
	});
	fragments.set(receipt, {
		props: fragmentProps,
		children: normalizeRenderResult(children),
		key,
		domain,
		enhancement: enhancement ? enhancement : void 0
	});
	return receipt;
}
/**
* Places an already selected fragment through a retained synthetic-host topology. Host identities
* are attachment-local and never serialized. SSR uses ordinary nested receipts; DOM updates retain
* the authored target when hosts appear, disappear, or change grouping. Does not discover targets.
*/
function createCompiledFragmentPresentation(target, hosts) {
	const identities = /* @__PURE__ */ new Set();
	for (const host of hosts) {
		if (identities.has(host.identity)) throw new TypeError("Duplicate fragment presentation host");
		identities.add(host.identity);
	}
	const retained = Object.freeze(hosts.map((host) => Object.freeze({
		...host,
		contributions: Object.freeze([...host.contributions])
	})));
	let output = target;
	for (let index = retained.length - 1; index >= 0; index--) {
		const host = retained[index];
		output = createCompiledTargetContributions(host.contributions, createCompiledIntrinsicReceipt(host.tag, null, output));
	}
	const receipt = createCompiledFragmentReceipt(null, output);
	fragments.set(receipt, {
		...fragments.get(receipt),
		presentation: Object.freeze({
			target,
			hosts: retained
		})
	});
	return receipt;
}
/** Reads only compiler-issued transparent range operations. */
function readCompiledFragmentReceipt(value) {
	return typeof value === "object" && value !== null ? fragments.get(value) : void 0;
}
/** Removes declaration metadata while preserving one compiler-issued transparent range. */
function withoutCompiledFragmentReceiptEnhancement(value) {
	const data = readCompiledFragmentReceipt(value);
	if (!data) return void 0;
	if (!data.enhancement) return value;
	const receipt = createOpaqueOperation(executeFragmentOperation, data);
	const { enhancement: _enhancement, ...plain } = data;
	fragments.set(receipt, plain);
	return receipt;
}
//#endregion
//#region ../packages/core/dist/server/document/output.js
/** Renderer dispatch for request-owned document output; browser rendering emits no new assets. */
var exactDocumentOutputOperation = Symbol.for("@exactjs/target-operation/document-output");
var empty$1 = createCompiledFragmentReceipt(null);
var markerKinds = sharedOpaqueOperationStore("document-output");
function marker(kind) {
	const operation = createOpaqueOperation(function(target) {
		const publish = target[exactDocumentOutputOperation];
		return publish ? publish.call(target, kind) : executeOpaqueOperation(empty$1, target)?.value;
	});
	markerKinds.set(operation, kind);
	return operation;
}
Object.freeze({
	styles: marker("styles"),
	headScripts: marker("headScripts"),
	hydrationData: marker("hydrationData"),
	bootstrap: marker("bootstrap")
});
//#endregion
//#region ../packages/core/dist/server/document/doctype.js
/** Renderer dispatch for an explicitly authored document declaration. */
var exactDoctypeOperation = Symbol.for("@exactjs/target-operation/doctype");
var declarations = sharedOpaqueOperationStore("doctype");
createCompiledFragmentReceipt(null);
/** Reads only framework-issued doctype declarations without executing them. */
function readDoctype(value) {
	return typeof value === "object" && value !== null ? declarations.get(value) : void 0;
}
//#endregion
//#region ../packages/core/dist/server/component-abi/child-range-receipt.js
var ranges = sharedOpaqueOperationStore("child-range");
/** Dispatch key implemented by render targets that accept focused child ranges. */
var exactChildRangeOperation = Symbol.for("@exactjs/target-operation/child-range");
function executeChildRangeOperation(target) {
	const data = ranges.get(this);
	if (!data) throw new TypeError("Child-range operation lost its compiler-issued payload");
	return target[exactChildRangeOperation](this, data);
}
/** Issues a focused child-range operation without exposing child topology. */
function createChildRangeReceipt(value, markerId, mayReplaceSubtree = true, dynamicComponent) {
	const domain = currentComponentDomain();
	const receipt = createOpaqueOperation(executeChildRangeOperation, { ...domain ? { domain } : {} });
	ranges.set(receipt, {
		value,
		mayReplaceSubtree,
		...markerId ? { markerId } : {},
		...domain ? { domain } : {},
		...dynamicComponent ? { dynamicComponent } : {}
	});
	return receipt;
}
/** Reads only compiler-issued range operations. */
function readChildRangeReceipt(value) {
	return typeof value === "object" && value !== null ? ranges.get(value) : void 0;
}
//#endregion
//#region ../packages/core/dist/server/component-abi/suspense-receipt.js
var suspenseReceipts = sharedOpaqueOperationStore("suspense");
/** Dispatch key implemented by render targets that accept Suspense operations. */
var exactSuspenseOperation = Symbol.for("@exactjs/target-operation/suspense");
function executeSuspenseOperation(target) {
	const data = suspenseReceipts.get(this);
	if (!data) throw new TypeError("Suspense operation lost its compiler-issued payload");
	return target[exactSuspenseOperation](this, data);
}
/** Reads only compiler-issued native readiness-boundary operations. */
function readCompiledSuspenseReceipt(value) {
	return typeof value === "object" && value !== null ? suspenseReceipts.get(value) : void 0;
}
/** Removes declaration metadata while preserving one compiler-issued readiness operation. */
function withoutCompiledSuspenseReceiptEnhancement(value) {
	const data = readCompiledSuspenseReceipt(value);
	if (!data) return void 0;
	if (!data.enhancement) return value;
	const receipt = createOpaqueOperation(executeSuspenseOperation, data);
	const { enhancement: _enhancement, ...plain } = data;
	suspenseReceipts.set(receipt, plain);
	return receipt;
}
sharedOpaqueOperationStore("activity");
/** Dispatch key implemented by render targets that accept Activity operations. */
var exactActivityOperation = Symbol.for("@exactjs/target-operation/activity");
//#endregion
//#region ../packages/core/dist/server/component-abi/keyed-child-receipt.js
var keyedChildren = sharedOpaqueOperationStore("keyed-child");
/** Dispatch key implemented by render targets that accept keyed-child operations. */
var exactKeyedChildOperation = Symbol.for("@exactjs/target-operation/keyed-child");
/** Reads only compiler-issued keyed sibling operations. */
function readCompiledKeyedChildReceipt(value) {
	return typeof value === "object" && value !== null ? keyedChildren.get(value) : void 0;
}
//#endregion
//#region ../packages/core/dist/server/component-abi/unsafe-html-receipt.js
var unsafeHtmlReceipts = sharedOpaqueOperationStore("unsafe-html");
/** Dispatch key implemented by render targets that accept audited raw HTML. */
var exactUnsafeHtmlOperation = Symbol.for("@exactjs/target-operation/unsafe-html");
/** Reads only compiler-authorized raw-HTML operations. */
function readUnsafeHtmlReceipt(value) {
	return typeof value === "object" && value !== null ? unsafeHtmlReceipts.get(value) : void 0;
}
sharedOpaqueOperationStore("portal");
/** Dispatch key implemented by render targets that accept portal operations. */
var exactPortalOperation = Symbol.for("@exactjs/target-operation/portal");
//#endregion
//#region ../packages/core/dist/server/component/direct-server-instance-construction.js
/** Rejects attempts to construct a durable instance from a compiler-closed direct SSR artifact. */
var rejectDirectServerComponentConstruction = function() {
	throw new TypeError(`Direct server component ${this.instantiate.name || "<anonymous>"} must execute through its compiled request-local frame`);
};
//#endregion
//#region ../packages/core/dist/server/enhancements.js
/** Global property carrying compiler-derived context effects needed before enhancement activation. */
var exactEnhancementContexts = Symbol.for("@exactjs/enhancement-contexts");
var exactEnhancementPassThroughBrand = Symbol.for("@exactjs/enhancement-pass-through");
Object.defineProperty(function ExactEnhancementPassThrough(_props) {
	return () => _props.children;
}, exactEnhancementPassThroughBrand, { value: true });
/** Reports whether a generated facade selected the shared zero-instance pass-through provider. */
function isExactEnhancementPassThrough(value) {
	return typeof value === "function" && value[exactEnhancementPassThroughBrand] === true;
}
/** Creates the opaque grouped marker used by compiler-owned JSX enhancement lowering. */
function createEnhancementNode(entries) {
	const identities = /* @__PURE__ */ new Set();
	const normalized = entries.map((entry) => {
		if (!entry.identity) throw new TypeError("An enhancement entry requires a canonical identity");
		if (identities.has(entry.identity)) throw new Error(`Duplicate enhancement identity "${entry.identity}" at one JSX boundary`);
		identities.add(entry.identity);
		const normalized = {
			identity: entry.identity,
			props: Object.freeze({ ...entry.props })
		};
		if (entry.intrinsicFragment !== void 0) Object.assign(normalized, { intrinsicFragment: entry.intrinsicFragment });
		if (entry.root !== void 0) Object.assign(normalized, { root: entry.root });
		return Object.freeze(normalized);
	});
	return Object.freeze({
		kind: "enhancement",
		entries: Object.freeze(normalized),
		fallback: "preserve-target"
	});
}
/** Reads the pre-activation context effects carried by one component value. */
function readExactEnhancementContexts(component) {
	return component[exactEnhancementContexts];
}
//#endregion
//#region ../packages/core/dist/server/url.js
var javascriptProtocol = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
var urlAttributes = /* @__PURE__ */ new Set([
	"action",
	"formaction",
	"href",
	"src",
	"xlink:href",
	"xlinkhref"
]);
/** Provides the canonical blocked javascript url value. */
var BLOCKED_JAVASCRIPT_URL = "javascript:throw new Error('eXact has blocked a javascript: URL as a security precaution.')";
/** Reports whether url attribute. */
function isUrlAttribute(name) {
	return urlAttributes.has(name.toLowerCase());
}
/** Applies the native eXact URL policy to one JSX/DOM attribute value. */
function sanitizeUrlAttribute(name, value) {
	if (!isUrlAttribute(name) || value === null || value === void 0) return value;
	const text = String(value);
	return javascriptProtocol.test(text) ? BLOCKED_JAVASCRIPT_URL : value;
}
//#endregion
//#region ../packages/ssr/dist/document.js
/** Returns whether rendered output is a normalized complete HTML document. */
function isExactDocumentHtml(html) {
	return html.startsWith("<!doctype ");
}
/** Finds the final body close without scanning canonical contents; preserves other closing-tag casing. */
function findDocumentBodyClose(html) {
	return html.endsWith("</body></html>") ? html.length - 14 : html.toLowerCase().lastIndexOf("</body>");
}
/** Inserts framework-owned nodes in the reserved region before </body>. */
function augmentDocumentBody(html, frameworkHtml) {
	if (!isExactDocumentHtml(html)) return `${html}${frameworkHtml}`;
	const bodyClose = findDocumentBodyClose(html);
	if (bodyClose < 0) throw new Error("Normalized eXact document output is missing its closing </body> element.");
	const augmentation = frameworkHtml ? `<!--exact:framework-body:start-->${frameworkHtml}<!--exact:framework-body:end-->` : "";
	return `${html.slice(0, bodyClose)}${augmentation}${html.slice(bodyClose)}`;
}
//#endregion
//#region ../packages/ssr/dist/html.js
/** Provides the canonical void elements value. */
var voidElements = /* @__PURE__ */ new Set([
	"area",
	"base",
	"br",
	"col",
	"embed",
	"hr",
	"img",
	"input",
	"link",
	"meta",
	"param",
	"source",
	"track",
	"wbr"
]);
/** Escapes text content for safe HTML output. */
function escapeText(value) {
	return /[&<>]/.test(value) ? value.replace(/[&<>]/g, escapeHtmlCharacter) : value;
}
/** Escapes an attribute value for safe HTML output. */
function escapeAttr(value) {
	return /[&<>"]/.test(value) ? value.replace(/[&<>"]/g, escapeHtmlCharacter) : value;
}
/** Returns a safe attribute name or a harmless placeholder when the name is invalid. */
function escapeAttrName(value) {
	return /^[A-Za-z_:][A-Za-z0-9_:.-]*$/.test(value) ? value : "data-exact-invalid-attr";
}
function escapeHtmlCharacter(character) {
	if (character === "&") return "&amp;";
	if (character === "<") return "&lt;";
	if (character === ">") return "&gt;";
	return "&quot;";
}
//#endregion
//#region ../packages/ssr/dist/render/capability-registry.js
/**
* Bundle-local SSR capabilities selected by compiler-emitted runtime imports. Request state never
* enters this registry. A server bundle owns exactly one @exactjs/ssr module graph; duplicate
* package copies are a build error rather than a reason to mutate globalThis.
*/
var ssrCapabilities = Object.create(null);
//#endregion
//#region ../packages/ssr/dist/hydration-encoding-capability.js
var capabilityName$4 = "hydration-protocol-encoder";
/** Encodes compiler-owned plain state or delegates to an installed generic reactive capability. */
function encodeHydrationProtocolValue(value) {
	return ssrCapabilities[capabilityName$4]?.(value) ?? value;
}
//#endregion
//#region ../packages/ssr/dist/runtime/positional-projection.js
var projectors = /* @__PURE__ */ new WeakMap();
/**
* Associates server-only generated code with an immutable schema without changing its tuple.
* Unknown versions remain inert, allowing the ordinary interpreter to handle their schemas.
*/
function registerPositionalProjector(schema, version, project) {
	if (schema !== 0) projectors.set(schema, {
		version,
		project
	});
	return schema;
}
/** Reads supported emitted code without exposing the registry's mutable storage. */
function readPositionalProjector(schema) {
	const entry = schema === 0 ? void 0 : projectors.get(schema);
	return entry?.version === 1 ? entry.project : void 0;
}
//#endregion
//#region ../packages/ssr/dist/hydration-json.js
/** Tracks shallow request-local ancestry without allocating and rehashing a Set's buckets. */
var HydrationAncestors = class {
	values = [];
	/** Tests only the active traversal path; shared siblings are not cycles. */
	has(value) {
		return this.values.includes(value);
	}
	/** Records a container after the validator has excluded active-path duplicates. */
	add(value) {
		this.values.push(value);
	}
	/** Unwinds the most recently entered container, including early validation failures. */
	delete(value) {
		if (this.values[this.values.length - 1] !== value) throw new Error("Unbalanced hydration ancestor");
		this.values.pop();
		return true;
	}
};
/**
* Validates a hydration graph without invoking accessors.
*
* The caller may synchronously read the graph after this succeeds because every enumerable value
* property and container prototype has already crossed the serialization trust boundary.
*/
function validateJsonSafeHydrationValue(value, limits) {
	const state = {
		active: new HydrationAncestors(),
		directResumptions: limits.directResumptions,
		positionalRoot: limits.positionalRoot,
		structurallyKnown: limits.structurallyKnown,
		structurallyKnownRoot: limits.structurallyKnownRoot,
		maxDepth: normalizeProtocolLimit(limits.maxDepth, 100),
		maxNodes: normalizeProtocolLimit(limits.maxNodes, 1e5),
		validate: validateValue,
		project: projectPositionalField,
		mismatch: positionalMismatch,
		unsafe: positionalUnsafe,
		onValidatedArray: limits.onValidatedArray,
		nodes: 0
	};
	try {
		if (validateValue(value, 0, state, value === state.structurallyKnownRoot ? 1 : 0)) return void 0;
		const diagnostic = {
			...state,
			active: new HydrationAncestors(),
			onValidatedArray: void 0,
			path: {
				arrays: [],
				keys: []
			},
			nodes: 0
		};
		return validateValue(value, 0, diagnostic, value === state.structurallyKnownRoot ? 1 : 0) ? "$" : formatValidationPath(diagnostic.path);
	} catch {
		return "$";
	}
}
function validateValue(value, depth, state, shape = 0) {
	if (++state.nodes > state.maxNodes || depth > state.maxDepth) return false;
	if (value === null || typeof value === "string" || typeof value === "boolean") return true;
	if (typeof value === "number") return Number.isFinite(value);
	if (typeof value !== "object" || state.active.has(value)) return false;
	if (shape === 0 && !state.structurallyKnown?.has(value) && !Array.isArray(value) && Object.getPrototypeOf(value) !== Object.prototype) return false;
	if (state.active instanceof HydrationAncestors && state.active.values.length >= 16) state.active = new Set(state.active.values);
	state.active.add(value);
	try {
		return validateContainer(value, depth, state, shape);
	} finally {
		state.active.delete(value);
	}
}
function validateContainer(source, depth, state, shape) {
	const array = Array.isArray(source);
	const structurallyKnown = shape !== 0 || (state.structurallyKnown?.has(source) ?? false);
	const path = state.path;
	if (shape >= 2 && !array) return false;
	if (shape === 1 && array) return validateDirectEnvelope(source, depth, state);
	if (array && structurallyKnown) {
		for (let index = 0; index < source.length; index++) {
			if (path) pushValidationPath(path, String(index), true);
			const childShape = shape === 2 ? 3 : shape === 4 ? 5 : shape === 3 && (index === 1 || index === 2) ? 4 : shape === 3 && index === 3 ? 6 : 0;
			if (!validateValue(source[index], depth + 1, state, childShape)) return false;
			if (path) popValidationPath(path);
		}
		if (shape === 0) state.onValidatedArray?.(source);
		return true;
	}
	for (const key of Object.keys(source)) {
		if (path) pushValidationPath(path, key, array);
		if (structurallyKnown) {
			const item = source[key];
			if (shape === 1 && key === "state" && state.positionalRoot) {
				const publication = state.positionalRoot;
				const encoded = validatePositionalValue(publication.props, publication.schema, depth + 2, state);
				if (encoded === positionalUnsafe) return false;
				if (encoded === positionalMismatch) {
					source[key] = publication.props;
					if (!validateValue(publication.props, depth + 1, state)) return false;
				} else {
					if (depth + 1 > state.maxDepth || state.nodes + 2 > state.maxNodes) return false;
					state.nodes += 2;
					source[key] = [publication.componentId, encoded];
				}
				if (path) popValidationPath(path);
				continue;
			}
			const childShape = shape === 1 && key === "resumptions" && item === state.directResumptions ? 2 : 0;
			if (!validateValue(item, depth + 1, state, childShape)) return false;
			if (path) popValidationPath(path);
			continue;
		}
		const descriptor = Object.getOwnPropertyDescriptor(source, key);
		if (!descriptor || !("value" in descriptor)) return false;
		if (!validateValue(descriptor.value, depth + 1, state)) return false;
		if (path) popValidationPath(path);
	}
	if (array) state.onValidatedArray?.(source);
	return true;
}
function validateDirectEnvelope(source, depth, state) {
	const version = source[0];
	const mask = source[1];
	if (version !== 1 || typeof mask !== "number" || !Number.isSafeInteger(mask) || mask < 0 || (mask & -16384) !== 0) return false;
	if (state.nodes + 2 > state.maxNodes || depth + 1 > state.maxDepth) return false;
	state.nodes += 2;
	let index = 2;
	let remaining = mask & -17;
	while (remaining !== 0) {
		const bit = remaining & -remaining;
		remaining &= remaining - 1;
		if (index >= source.length) return false;
		if (state.path) pushValidationPath(state.path, String(index), true);
		const item = source[index];
		if (bit === 8 && state.positionalRoot) {
			const publication = state.positionalRoot;
			const encoded = validatePositionalValue(publication.props, publication.schema, depth + 2, state);
			if (encoded === positionalUnsafe) return false;
			if (encoded === positionalMismatch) {
				source[index] = publication.props;
				if (!validateValue(publication.props, depth + 1, state)) return false;
			} else {
				if (depth + 1 > state.maxDepth || state.nodes + 2 > state.maxNodes) return false;
				state.nodes += 2;
				source[index] = [publication.componentId, encoded];
			}
		} else {
			const childShape = bit === 64 && item === state.directResumptions ? 2 : 0;
			if (!validateValue(item, depth + 1, state, childShape)) return false;
		}
		if (state.path) popValidationPath(state.path);
		index++;
	}
	return index === source.length;
}
var positionalMismatch = Symbol("positional-mismatch");
var positionalUnsafe = Symbol("positional-unsafe");
/** Dispatches a generated field through its compiler-owned nested schema. */
function projectPositionalField(value, schema, index, depth, state) {
	return validatePositionalValue(value, schema[index], depth, state);
}
/**
* Reads compiler-declared fields once while constructing their final positional cells.
*
* The schema fixes every visited key and the output contains only newly created arrays, so normal
* property access is sufficient here. Generic values outside this compiler-owned conversion keep
* the descriptor-safe validation path.
*/
function validatePositionalValue(value, schema, depth, state) {
	if (schema === 0) {
		if (value === null || typeof value !== "object") {
			if (++state.nodes > state.maxNodes || depth > state.maxDepth) return positionalUnsafe;
			return value === null || typeof value === "string" || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value) ? value : positionalUnsafe;
		}
		return validateValue(value, depth, state) ? value : positionalUnsafe;
	}
	if (++state.nodes > state.maxNodes || depth > state.maxDepth) return positionalUnsafe;
	if (!value || typeof value !== "object" || state.active.has(value)) return positionalMismatch;
	if (state.active instanceof HydrationAncestors && state.active.values.length >= 16) state.active = new Set(state.active.values);
	state.active.add(value);
	try {
		if (schema[0] === 2) {
			if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype || Object.keys(value).length !== value.length) return positionalMismatch;
			const output = new Array(value.length);
			const projector = value.length >= 16 && !state.path ? readPositionalProjector(schema[1]) : void 0;
			if (projector) {
				for (let index = 0; index < value.length; index++) {
					if (!Object.hasOwn(value, index)) return positionalMismatch;
					const encoded = projector(value[index], depth + 1, state, schema[1], Object, Array);
					if (encoded === positionalMismatch || encoded === positionalUnsafe) return encoded;
					output[index] = encoded;
				}
				return output;
			}
			for (let index = 0; index < value.length; index++) {
				if (!Object.hasOwn(value, index)) return positionalMismatch;
				if (state.path) pushValidationPath(state.path, String(index), true);
				const encoded = validatePositionalValue(value[index], schema[1], depth + 1, state);
				if (encoded === positionalMismatch || encoded === positionalUnsafe) return encoded;
				output[index] = encoded;
				if (state.path) popValidationPath(state.path);
			}
			return output;
		}
		if (Array.isArray(value) || Object.getPrototypeOf(value) !== Object.prototype) return positionalMismatch;
		const fieldCount = (schema.length - 1) / 2;
		if (Object.keys(value).length !== fieldCount) return positionalMismatch;
		const output = new Array(fieldCount);
		for (let schemaIndex = 1, outputIndex = 0; schemaIndex < schema.length; schemaIndex += 2) {
			const field = schema[schemaIndex];
			if (!Object.hasOwn(value, field)) return positionalMismatch;
			if (state.path) pushValidationPath(state.path, field, false);
			const encoded = validatePositionalValue(value[field], schema[schemaIndex + 1], depth + 1, state);
			if (encoded === positionalMismatch || encoded === positionalUnsafe) return encoded;
			output[outputIndex++] = encoded;
			if (state.path) popValidationPath(state.path);
		}
		return output;
	} finally {
		state.active.delete(value);
	}
}
function pushValidationPath(path, key, array) {
	path.keys.push(key);
	path.arrays.push(array);
}
function popValidationPath(path) {
	path.keys.pop();
	path.arrays.pop();
}
function formatValidationPath(pathValue) {
	let path = "$";
	for (let index = 0; index < pathValue.keys.length; index++) {
		const key = pathValue.keys[index];
		path += pathValue.arrays[index] ? `[${key}]` : `.${key}`;
	}
	return path;
}
//#endregion
//#region ../packages/plugin-host/dist/runtime.js
/** Performs the process exact output domain operation. */
async function processExactOutput(value, context, extensions) {
	let current = value;
	for (const extension of extensions) if (extension.transform) current = await extension.transform(current, context);
	const failures = [];
	for (const extension of extensions) {
		if (!extension.validate) continue;
		try {
			if (await extension.validate(current, context) !== void 0) failures.push(/* @__PURE__ */ new Error("Output validators must return undefined"));
		} catch (error) {
			failures.push(error);
		}
	}
	if (failures.length) throw new AggregateError(failures, `eXact ${context.kind} output validation failed`);
	return current;
}
/** Performs the process exact output sync domain operation. */
function processExactOutputSync(value, context, extensions) {
	let current = value;
	for (const extension of extensions) {
		if (!extension.transform) continue;
		const result = extension.transform(current, context);
		if (isPromiseLike(result)) throw new Error(`Async output transform cannot run in synchronous ${context.kind} output`);
		current = result;
	}
	const failures = [];
	for (const extension of extensions) {
		if (!extension.validate) continue;
		try {
			const result = extension.validate(current, context);
			if (isPromiseLike(result)) throw new Error(`Async output validator cannot run in synchronous ${context.kind} output`);
			if (result !== void 0) failures.push(/* @__PURE__ */ new Error("Output validators must return undefined"));
		} catch (error) {
			failures.push(error);
		}
	}
	if (failures.length) throw new AggregateError(failures, `eXact ${context.kind} output validation failed`);
	return current;
}
function isPromiseLike(value) {
	return !!value && (typeof value === "object" || typeof value === "function") && typeof value.then === "function";
}
//#endregion
//#region ../packages/ssr/dist/render/hydration-metadata.js
/** Constructs the already-final compiler-closed envelope without generic output transformation. */
function createDirectHydrationMetadata(options, resumptions) {
	const output = [1, 0];
	let mask = 0;
	if (options.pluginRegistryFingerprint !== void 0) {
		mask |= 1;
		output.push(options.pluginRegistryFingerprint);
	}
	if (options.endpoint !== void 0) {
		mask |= 2;
		output.push(options.endpoint);
	}
	if (options.endpoints) {
		const endpoints = compactEndpointRoutes(options.endpoints);
		if (Object.keys(endpoints).length) {
			mask |= 4;
			output.push(endpoints);
		}
	}
	if (options.state !== void 0) {
		mask |= 8;
		output.push(options.state);
	}
	if (options.markerlessRoot) mask |= 16;
	if (options.continuations) {
		mask |= 32;
		output.push(compactContinuations(options.continuations));
	}
	if (resumptions.length) {
		mask |= 64;
		output.push(resumptions);
	}
	if (options.publicContexts && !isEmptyRecord(options.publicContexts)) {
		mask |= 128;
		output.push(options.publicContexts);
	}
	if (options.wallClockSnapshot !== void 0) {
		mask |= 256;
		output.push(options.wallClockSnapshot);
	}
	if (options.hydrationTable !== void 0) {
		mask |= 512;
		output.push(options.hydrationTable);
	}
	if (options.executionRoot !== void 0) {
		mask |= 1024;
		output.push(options.executionRoot);
	}
	if (options.binding !== void 0) {
		mask |= 2048;
		output.push(options.binding);
	}
	if (options.buildKey !== void 0) {
		mask |= 4096;
		output.push(options.buildKey);
	}
	if (options.componentAuthorization !== void 0) {
		mask |= 8192;
		output.push(options.componentAuthorization);
	}
	output[1] = mask;
	return output;
}
/** Applies the explicit extension boundary before compacting authored hydration metadata. */
function createExtensibleHydrationMetadata(options, resumptionLayouts) {
	return compactHydrationMetadata(processExactOutputSync(omitUndefinedProperties({
		pluginRegistryFingerprint: options.pluginRegistryFingerprint,
		endpoint: options.endpoint,
		endpoints: options.endpoints,
		state: options.state,
		m: options.markerlessRoot ? 1 : void 0,
		continuations: options.continuations,
		resumptions: options.resumptions,
		publicContexts: options.publicContexts,
		wallClockSnapshot: options.wallClockSnapshot,
		h: options.hydrationTable,
		executionRoot: options.executionRoot,
		binding: options.binding,
		buildKey: options.buildKey,
		componentAuthorization: options.componentAuthorization
	}), { kind: "hydration" }, options.outputExtensions ?? []), resumptionLayouts);
}
function compactHydrationMetadata(value, resumptionLayouts) {
	const output = { ...value };
	compactOptionalRecord(output, "endpoints", compactEndpointRoutes);
	compactOptionalRecord(output, "continuations", compactContinuations);
	compactOptionalArray(output, "resumptions", (resumption) => compactResumption(resumption, resumptionLayouts));
	if (isEmptyRecord(output.publicContexts)) delete output.publicContexts;
	return output;
}
function compactEndpointRoutes(value) {
	const output = { ...value };
	for (const field of ["invocations", "boundaries"]) if (isEmptyRecord(output[field])) delete output[field];
	return output;
}
function compactContinuations(value) {
	return Object.fromEntries(Object.entries(value).map(([id, continuation]) => [id, isPlainRecord(continuation) ? compactContinuation(continuation) : continuation]));
}
function compactContinuation(value) {
	const output = omitEmptyArrays(value, [
		"dependencies",
		"stateReads",
		"stateWrites",
		"publicContexts",
		"contextWrites",
		"boundaries"
	]);
	delete output.serverContexts;
	delete output.serverContextWrites;
	return output;
}
function compactResumption(value, layouts) {
	if (!isPlainRecord(value)) return value;
	const output = omitEmptyArrays(value, ["settledContinuations"]);
	for (const field of ["values", "contexts"]) if (isEmptyRecord(output[field])) delete output[field];
	const componentId = output.componentId;
	const layout = typeof componentId === "string" ? layouts?.get(componentId) : void 0;
	if (typeof componentId !== "string") return output;
	const values = compactEntries(output.values, layout?.statePaths);
	const contexts = compactEntries(output.contexts, layout?.contexts);
	if (!values || !contexts) return output;
	const settled = Array.isArray(output.settledContinuations) ? output.settledContinuations : [];
	const tuple = [componentId];
	if (values.length || contexts.length || settled.length) tuple.push(values);
	if (contexts.length || settled.length) tuple.push(contexts);
	if (settled.length) tuple.push(settled);
	return tuple;
}
/** Replaces compiler-declared field names with their stable contract indexes. */
function compactEntries(value, fields) {
	if (value === void 0) return [];
	if (!isPlainRecord(value)) return void 0;
	const entries = [];
	for (const [field, item] of Object.entries(value)) {
		const index = fields?.indexOf(field);
		if (fields && index === -1) return void 0;
		entries.push([index ?? field, item]);
	}
	return entries;
}
function compactOptionalRecord(owner, field, compact) {
	const value = owner[field];
	if (!isPlainRecord(value)) return;
	const compacted = compact(value);
	if (Object.keys(compacted).length) owner[field] = compacted;
	else delete owner[field];
}
function compactOptionalArray(owner, field, compact) {
	const value = owner[field];
	if (!Array.isArray(value)) return;
	if (!value.length) delete owner[field];
	else owner[field] = value.map(compact);
}
function omitEmptyArrays(value, fields) {
	const output = { ...value };
	for (const field of fields) {
		const item = output[field];
		if (Array.isArray(item) && !item.length) delete output[field];
	}
	const invocation = output.invocation;
	if (isPlainRecord(invocation)) output.invocation = omitEmptyArrays(invocation, ["arguments"]);
	return output;
}
function isEmptyRecord(value) {
	return isPlainRecord(value) && Object.keys(value).length === 0;
}
function isPlainRecord(value) {
	return Boolean(value && typeof value === "object" && !Array.isArray(value));
}
function omitUndefinedProperties(value) {
	const output = {};
	for (const [key, item] of Object.entries(value)) if (item !== void 0) output[key] = item;
	return output;
}
//#endregion
//#region ../packages/ssr/dist/render/server-component-reference.js
/** Accepts only an issued native component operation. */
function readServerComponentReference(value) {
	return readPreparedServerComponentReference(value) ?? readCompiledComponentReceipt(value);
}
/** Builds construction props without materializing rendered topology. */
function serverComponentProps(reference) {
	if (reference.children.length === 0) return reference.props;
	const props = { ...reference.props };
	const children = normalizeChildren(reference.children.map((child) => unwrap(child)));
	if (children.length === 1) props.children = children[0];
	else if (children.length > 1) props.children = children;
	return props;
}
/** Resolves receipt-carried server facts without looking up a component type. */
function receiptExecutionBlueprint(receipt) {
	const contract = receiptExecutionContract(receipt);
	return {
		componentId: contract.artifact.id,
		contract
	};
}
/** Reads the immutable receipt-carried server contract without projecting a request object. */
function receiptExecutionContract(receipt) {
	if (receipt.contract.artifact.target !== "server") throw new TypeError("Server renderer received a client component receipt");
	return receipt.contract;
}
//#endregion
//#region ../packages/ssr/dist/render/root-props.js
var positionalRootPublication = Symbol("exact.positional-root-publication");
/** Resolves explicit root-prop publication once so render and resumption share one object graph. */
function rootPropsOptions(root, options) {
	if (!options.publishRootProps) return options;
	if (options.state !== void 0) throw new TypeError("publishRootProps cannot be combined with an explicit hydration state");
	const receipt = readServerComponentReference(root);
	if (receipt) {
		const props = { ...receipt.props };
		const schema = receipt.contract.artifact.serialization;
		if (schema && !options.outputExtensions?.length) {
			const state = {};
			Object.defineProperty(state, positionalRootPublication, { value: {
				componentId: receipt.contract.artifact.id,
				props,
				schema
			} });
			return {
				...options,
				state
			};
		}
		return {
			...options,
			state: props
		};
	}
	throw new TypeError("publishRootProps requires a compiler-issued component root operation");
}
/** Returns the request-local root publication source without exposing its marker to JSON. */
function readPositionalRootPublication(state) {
	return state && typeof state === "object" ? state[positionalRootPublication] : void 0;
}
/** Returns request-owned root props separately from their compact hydration representation. */
function rootPropsForCapture(root, options) {
	if (!options.publishRootProps) return void 0;
	return readServerComponentReference(root)?.props;
}
/** Returns compiler identity only for a native component root. */
function rootComponentIdentity(root) {
	return readServerComponentReference(root)?.contract.artifact.id;
}
//#endregion
//#region ../packages/ssr/dist/hydration.js
/** Renders the JSON script tag consumed by the hydration client. */
function renderHydrationScript(options = {}, resumptionLayouts, capturedResumptions) {
	return renderHydrationScriptValue(options, resumptionLayouts, capturedResumptions);
}
function renderHydrationScriptValue(options, resumptionLayouts, capturedResumptions, byteTarget, encodedByteLength = utf8ByteLength) {
	if (options.buildKey && options.componentAuthorization && options.componentAuthorization.buildKey !== options.buildKey) throw new Error("Component authorization identity does not match the hydration build key");
	const directMetadata = !options.outputExtensions?.length && capturedResumptions !== void 0 && (capturedResumptions.length > 0 || !options.resumptions?.length);
	const directResumptions = directMetadata ? capturedResumptions : void 0;
	const compacted = directMetadata ? createDirectHydrationMetadata(options, directResumptions) : createExtensibleHydrationMetadata(options, resumptionLayouts);
	let reactiveCollections;
	const unsafePath = validateJsonSafeHydrationValue(compacted, {
		maxDepth: options.maxHydrationDepth,
		maxNodes: options.maxHydrationNodes,
		onValidatedArray(value) {
			const encoded = encodeValidatedReactiveCollection(value, value);
			if (encoded === value) return;
			(reactiveCollections ??= /* @__PURE__ */ new WeakMap()).set(value, encoded);
		},
		directResumptions,
		positionalRoot: readPositionalRootPublication(options.state),
		structurallyKnownRoot: directMetadata ? compacted : void 0
	});
	if (unsafePath) throw new Error(`Hydration payload must be JSON-serializable at ${unsafePath}`);
	const payload = serializeValidatedHydrationPayload(compacted, reactiveCollections);
	const payloadBytes = encodedByteLength(payload);
	if (payloadBytes > normalizeProtocolLimit(options.maxHydrationBytes, 16777216)) throw new Error("Hydration payload exceeded maxHydrationBytes");
	const id = options.scriptId ?? "__exact_hydration";
	const nonce = options.nonce ? ` nonce="${escapeAttr(options.nonce)}"` : "";
	const prefix = `<script type="application/json" id="${escapeAttr(id)}"${nonce}>`;
	const suffix = "<\/script>";
	if (byteTarget) byteTarget.hydrationBytes = utf8ByteLength(prefix) + payloadBytes + 9;
	return `${prefix}${payload}${suffix}`;
}
/** Serializes hydration JSON while escaping script-breaking characters. */
function serializeHydrationPayload(payload) {
	return serializeEncodedHydrationPayload(encodeHydrationProtocolValue(payload));
}
function serializeEncodedHydrationPayload(payload) {
	return serializeJson(payload);
}
/** Encodes registered arrays as JSON visits them without cloning the validated payload graph. */
function serializeValidatedHydrationPayload(payload, reactiveCollections) {
	if (!reactiveCollections) return serializeJson(payload);
	const emittedCollections = /* @__PURE__ */ new WeakSet();
	return serializeJson(payload, function(_key, value) {
		if (!Array.isArray(value)) return value;
		if (emittedCollections.has(value)) return value;
		const encoded = reactiveCollections.get(value);
		if (encoded === void 0) return value;
		emittedCollections.add(value);
		return encoded;
	});
}
function serializeJson(payload, replacer) {
	return JSON.stringify(payload, replacer).replace(/</g, "\\u003C").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
}
/** Returns the first non-JSON-safe path in a value, or undefined when it is safe. */
function jsonUnsafePath(value, path = "$", seen = /* @__PURE__ */ new Set()) {
	return findJsonUnsafePath(value, path, seen, false, {});
}
function findJsonUnsafePath(value, path, seen, strict, limits) {
	const maxDepth = normalizeProtocolLimit(limits.maxDepth, 100);
	const maxNodes = normalizeProtocolLimit(limits.maxNodes, 1e5);
	const pending = [{
		value,
		path,
		depth: 0
	}];
	let nodes = 0;
	try {
		while (pending.length) {
			const current = pending.pop();
			if ("exit" in current) {
				seen.delete(current.exit);
				continue;
			}
			if (++nodes > maxNodes || current.depth > maxDepth) return current.path;
			const item = current.value;
			if (item === null || !strict && item === void 0) continue;
			if (typeof item === "string" || typeof item === "boolean") continue;
			if (typeof item === "number") {
				if (!Number.isFinite(item)) return current.path;
				continue;
			}
			if (typeof item !== "object" || seen.has(item)) return current.path;
			seen.add(item);
			if (!Array.isArray(item) && Object.getPrototypeOf(item) !== Object.prototype) return current.path;
			const keys = Object.keys(item);
			pending.push({
				exit: item,
				path: current.path,
				depth: current.depth
			});
			for (let index = keys.length - 1; index >= 0; index--) {
				const key = keys[index];
				const descriptor = Object.getOwnPropertyDescriptor(item, key);
				if (!descriptor || !("value" in descriptor)) return `${current.path}${Array.isArray(item) ? `[${key}]` : `.${key}`}`;
				pending.push({
					value: descriptor.value,
					path: `${current.path}${Array.isArray(item) ? `[${key}]` : `.${key}`}`,
					depth: current.depth + 1
				});
			}
		}
		return;
	} catch {
		return path;
	}
}
//#endregion
//#region ../packages/core/dist/server/tasks/server-task-readiness.js
/** Task-system-owned settlement state read by consumers without awaiting completed work. */
var ServerTaskReadiness = class {
	pending = /* @__PURE__ */ new Set();
	identities;
	failure;
	failures;
	selectedRevisions;
	revision = 0;
	/** Allocates identity lookup only for compiler plans that issue selected readiness queries. */
	constructor(trackIdentities = false) {
		if (trackIdentities) this.identities = /* @__PURE__ */ new WeakMap();
	}
	/** Counts completed blocking activations so consumers can detect changes during publication. */
	get version() {
		return this.revision;
	}
	/** Observes already-started work; this boundary never invokes or schedules a task. */
	observe(settlement, transitionId) {
		this.pending.add(settlement);
		this.identities?.set(settlement, transitionId);
		settlement.then(() => {
			this.pending.delete(settlement);
			this.revision++;
			this.advanceSelectedRevision(transitionId);
		}, (error) => {
			this.pending.delete(settlement);
			this.revision++;
			this.advanceSelectedRevision(transitionId);
			this.failure ??= { error };
			if (this.identities) {
				const failures = this.failures ??= /* @__PURE__ */ new Map();
				if (!failures.has(transitionId)) failures.set(transitionId, { error });
			}
		});
	}
	/**
	* Returns no wait for settled work, or waits for the currently pending selected activations.
	* Omitted selection includes all work. Unidentified work always participates because no caller
	* can prove it unrelated. Callers recheck after settlement to include subsequently issued work.
	*/
	wait(transitions) {
		if (!transitions) {
			if (this.failure) throw this.failure.error;
			if (!this.pending.size) return void 0;
			return Promise.all(this.pending).then(() => void 0);
		}
		if (!this.identities) throw new Error("Selected task readiness requires identity tracking");
		for (const [identity, failure] of this.failures ?? []) if (identity === void 0 || transitions.has(identity)) throw failure.error;
		let selected;
		for (const settlement of this.pending) {
			const identity = this.identities.get(settlement);
			if (identity === void 0 || transitions.has(identity)) (selected ??= []).push(settlement);
		}
		return selected ? Promise.all(selected).then(() => void 0) : void 0;
	}
	/**
	* Snapshots completion changes for compiler-selected identities. Tracking starts lazily on first
	* use; the number is a request-local change token, not an absolute activation count. Unknown
	* identities participate in every selection. Unrelated task completions do not change the token.
	*/
	versionFor(transitions) {
		if (!this.identities) throw new Error("Selected task readiness requires identity tracking");
		const revisions = this.selectedRevisions ??= /* @__PURE__ */ new Map();
		let version = revisions.get(void 0) ?? 0;
		for (const identity of transitions) version += revisions.get(identity) ?? 0;
		return version;
	}
	advanceSelectedRevision(identity) {
		const revisions = this.selectedRevisions;
		if (revisions) revisions.set(identity, (revisions.get(identity) ?? 0) + 1);
	}
};
//#endregion
//#region ../packages/core/dist/server/tasks/server-component-execution.js
/**
* Realm-stable protocol identities shared by separately evaluated copies of the core package.
* The frame remains owned by its request-local host and is removed when that request is disposed;
* dependency tokens carry only request-owned output slots.
*/
var serverExecutionFrame = Symbol.for("@exactjs/server-component-execution-frame");
var serverDependencyBrand = Symbol.for("@exactjs/server-component-dependency");
var activeComponentIssuer;
/**
* Installs the request renderer's synchronous child-issuance callback while compiled render code
* materializes its compiler-issued child operations. JavaScript cannot interleave another request during this synchronous
* extent, and nested renderers restore the preceding issuer in stack order.
*/
function withServerComponentIssuer(issuer, render) {
	const previous = activeComponentIssuer;
	activeComponentIssuer = issuer;
	try {
		return render();
	} finally {
		activeComponentIssuer = previous;
	}
}
/** Returns the request-local output source carried by a compiler-forwarded server value. */
function serverComponentDependencyForValue(value) {
	const slot = serverDependencySlot(value);
	if (!slot) return void 0;
	return {
		read() {
			switch (slot.status) {
				case "available": return {
					status: "available",
					generation: 1,
					version: 1,
					value: slot.value
				};
				case "failed": return {
					status: "failed",
					generation: 1,
					version: 1,
					error: slot.error
				};
				default: return {
					status: "pending",
					generation: 1,
					version: 0
				};
			}
		},
		subscribe(notify) {
			const subscribers = slot.subscribers ??= /* @__PURE__ */ new Set();
			subscribers.add(notify);
			return { [Symbol.dispose]: () => subscribers.delete(notify) };
		}
	};
}
function serverDependencySlot(value) {
	return value && typeof value === "object" && serverDependencyBrand in value ? value[serverDependencyBrand] : void 0;
}
/**
* Creates only the cancellation and port storage required by compiler-emitted task slices. It does
* not construct a task owner, prepare a component graph, subscribe reactive watchers, or allocate
* universal task lanes.
*/
function createServerComponentExecutionFrame(host, options) {
	const frame = {
		host,
		options,
		controller: new AbortController(),
		ports: [],
		paths: [],
		active: [],
		readiness: new ServerTaskReadiness(options.trackTaskIdentities),
		continuationContexts: /* @__PURE__ */ new Map(),
		settledContinuations: /* @__PURE__ */ new Set(),
		disposed: false
	};
	Object.defineProperty(host, serverExecutionFrame, {
		configurable: true,
		value: frame
	});
	return Object.freeze({
		get blockingVersion() {
			return frame.readiness.version;
		},
		blockingWork(transitions) {
			return frame.readiness.wait(transitions);
		},
		blockingVersionFor(transitions) {
			return frame.readiness.versionFor(transitions);
		},
		run(work) {
			if (frame.disposed) throw new Error("Server component execution frame has been disposed");
			return work();
		},
		async [Symbol.asyncDispose]() {
			if (frame.disposed) return;
			frame.disposed = true;
			const reason = new DOMException("Server component execution disposed", "AbortError");
			frame.controller.abort(reason);
			for (let port = 0; port < frame.ports.length; port++) if (frame.ports[port]?.status === "pending") failPort(frame, port, reason);
			await Promise.allSettled(frame.active);
			if (host[serverExecutionFrame] === frame) delete host[serverExecutionFrame];
			frame.ports.length = 0;
			frame.paths.length = 0;
			frame.active.length = 0;
			frame.continuationContexts.clear();
			frame.settledContinuations.clear();
		}
	});
}
/** Projects compiler-selected shared context values from one direct request-local frame. */
function serverComponentContinuationContextValuesForHost(host, names) {
	if (names.length === 0) return {};
	const frame = executionFrameForHost(host);
	if (!frame || frame.disposed) throw new Error("Compiled server context publication requires an active execution frame");
	const values = {};
	for (const name of names) {
		const token = frame.continuationContexts.get(name);
		if (!token) throw new Error(`Missing eXact server continuation context binding ${name}`);
		if (!frame.host.contexts?.has(token.id)) continue;
		const value = frame.host.contexts.get(token.id);
		if (value !== void 0) values[name] = value;
	}
	return values;
}
/** Lists direct server continuation generations that settled successfully in this request. */
function settledServerComponentContinuationIdsForHost(host) {
	const frame = executionFrameForHost(host);
	return frame && !frame.disposed ? [...frame.settledContinuations] : [];
}
/** Reads the request-owned frame without retaining the host outside its request lifetime. */
function executionFrameForHost(host) {
	return host[serverExecutionFrame];
}
/** Runs a deferred compiler output read through its existing live request owner. */
function readServerComponentOutputForHost(host, read) {
	const frame = executionFrameForHost(host);
	if (!frame || frame.disposed || !frame.options.prepareOutput) throw new TypeError("Deferred server output requires its live task owner");
	return frame.options.prepareOutput(read);
}
function outputSlot(frame, port) {
	let slot = frame.ports[port];
	if (!slot) {
		slot = { status: "pending" };
		frame.ports[port] = slot;
	}
	return slot;
}
function failPort(frame, port, error) {
	const slot = outputSlot(frame, port);
	slot.status = "failed";
	slot.error = error;
	for (const waiter of slot.waiters ?? []) waiter.reject(error);
	slot.waiters?.clear();
	for (const subscriber of slot.subscribers ?? []) subscriber();
}
//#endregion
//#region ../packages/ssr/dist/resumption-serialization.js
var resumptionSchemas = /* @__PURE__ */ new WeakMap();
/** Shared immutable empty indexed field collection. */
var emptyIndexedEntries = Object.freeze([]);
Object.freeze({});
/** Shared immutable empty settled-continuation collection. */
var emptyContinuationIds = Object.freeze([]);
/** Captures state from compiler-owned direct-executor storage without generic top-level reads. */
function captureDirectStateEntries(rootInput, state, props, schema, publishedRootProps, cell) {
	return captureStateEntriesWithRootReads(rootInput, state, props, schema, publishedRootProps, cell, true);
}
function captureStateEntriesWithRootReads(rootInput, state, props, schema, publishedRootProps, cell, directRoots) {
	const entries = [];
	try {
		for (const field of schema.state) {
			if (!readPath(state, field.segments, cell, directRoots) || cell.value === void 0) continue;
			const stateValue = cell.value;
			if (field.hasDefault && Object.is(stateValue, field.defaultValue)) continue;
			if (field.propSegments) {
				if (!readPath(props, field.propSegments, cell, directRoots)) {
					entries.push([field.index, stateValue]);
					continue;
				}
				const localValue = cell.value;
				if (Object.is(stateValue, localValue)) {
					if (!rootInput) continue;
					if (publishedRootProps && readPath(publishedRootProps, field.propSegments, cell) && Object.is(localValue, cell.value)) continue;
				}
			}
			entries.push([field.index, stateValue]);
		}
	} finally {
		cell.value = void 0;
	}
	return entries;
}
/** Converts named context values into compiler-indexed entries. */
function captureContextEntries(values, fields) {
	const entries = [];
	for (let index = 0; index < fields.length; index++) {
		const field = fields[index];
		if (Object.prototype.hasOwnProperty.call(values, field)) entries.push([index, values[field]]);
	}
	return entries;
}
/** Publishes optional tuple fields without allocating an intermediate record. */
function publishTuple(record, values, contexts, settled) {
	record.length = 1;
	if (values.length || contexts.length || settled.length) record[1] = values;
	if (contexts.length || settled.length) record[2] = contexts;
	if (settled.length) record[3] = settled;
}
/** Projects compact capture into the public observation shape only when requested. */
function projectActivation(record, schema) {
	return {
		componentId: record[0],
		values: projectEntries(record[1], schema.layout.statePaths),
		contexts: projectEntries(record[2], schema.layout.contexts),
		settledContinuations: record[3] ?? []
	};
}
function projectEntries(entries, fields) {
	const output = {};
	for (const [index, value] of entries ?? []) output[fields[index]] = value;
	return output;
}
/** Reads one own-property state path without invoking accessors. */
function readPath(value, segments, cell, directRoot = false) {
	let cursor = value;
	let index = 0;
	if (directRoot) {
		const segment = segments[0];
		if (!segment || !safeSegment(segment) || !cursor || typeof cursor !== "object") return false;
		cell.value = cursor[segment];
		cursor = cell.value;
		index = 1;
	}
	for (; index < segments.length; index++) {
		const segment = segments[index];
		if (!safeSegment(segment) || !cursor || typeof cursor !== "object") return false;
		if (!readReactiveOwnPropertyInto(cursor, segment, cell)) return false;
		cursor = cell.value;
	}
	cell.value = cursor;
	return true;
}
/** Returns the immutable schema cached for one compiler-owned contract. */
function resumptionSchema(contract) {
	const key = contract;
	const cached = resumptionSchemas.get(key);
	if (cached) return cached;
	const resumption = contract.resumption;
	const inputs = new Map(resumption.stateInputs);
	const defaults = new Map(resumption.stateDefaults ?? []);
	const schema = {
		layout: {
			statePaths: resumption.statePaths,
			contexts: resumption.contexts
		},
		state: resumption.statePaths.map((path, index) => {
			const propPath = inputs.get(path);
			const hasDefault = defaults.has(path);
			return {
				index,
				segments: path.split("."),
				...propPath ? { propSegments: propPath.split(".") } : {},
				...hasDefault ? {
					defaultValue: defaults.get(path),
					hasDefault: true
				} : {}
			};
		}),
		contexts: resumption.contexts,
		continuations: new Set(contract.continuations.map((continuation) => continuation.id))
	};
	resumptionSchemas.set(key, schema);
	return schema;
}
/** Rejects prototype-bearing path segments while inspecting component state. */
function safeSegment(segment) {
	return segment.length > 0 && segment !== "__proto__" && segment !== "prototype" && segment !== "constructor";
}
//#endregion
//#region ../packages/ssr/dist/resumption.js
/** Captures compiler-selected state directly in deterministic indexed construction order. */
function createSsrResumptionCapture(options, publishedRootProps, rootComponentId) {
	return new DirectSsrResumptionCapture(options, publishedRootProps, rootComponentId);
}
/** Request-owned direct capture whose fixed operations are shared through its prototype. */
var DirectSsrResumptionCapture = class {
	publishedRootProps;
	rootComponentId;
	options;
	records = [];
	schemas = [];
	pathReadCell = { value: void 0 };
	rootInputToken;
	projectedActivations;
	constructor(options, publishedRootProps, rootComponentId) {
		this.publishedRootProps = publishedRootProps;
		this.rootComponentId = rootComponentId;
		this.options = {
			...options,
			resumptionCapture: this,
			allowIndependentComponentObservation: !options.onComponentCreated && !options.onComponentRendered && !options.onDirectComponentCreated && !options.onDirectComponentRendered
		};
	}
	checkpoint() {
		return this.records.length;
	}
	rollback(checkpoint) {
		this.records.splice(checkpoint);
		this.schemas.splice(checkpoint);
		if (this.rootInputToken !== void 0 && this.rootInputToken >= checkpoint) this.rootInputToken = void 0;
		this.projectedActivations = void 0;
	}
	reserveDirect(componentId, contract) {
		if (!contract.resumption) return void 0;
		const token = this.records.length;
		this.records.push([componentId]);
		this.schemas.push(resumptionSchema(contract));
		if (this.rootInputToken === void 0 && componentId === this.rootComponentId) this.rootInputToken = token;
		this.projectedActivations = void 0;
		return token;
	}
	publishDirect(token, host, state, props) {
		const record = this.records[token];
		const schema = this.schemas[token];
		if (!record || !schema) return;
		publishTuple(record, captureDirectStateEntries(token === this.rootInputToken, state, props, schema, this.publishedRootProps, this.pathReadCell), schema.contexts.length ? captureContextEntries(serverComponentContinuationContextValuesForHost(host, schema.contexts), schema.contexts) : emptyIndexedEntries, schema.continuations.size ? settledServerComponentContinuationIdsForHost(host).filter((id) => schema.continuations.has(id)) : emptyContinuationIds);
		this.projectedActivations = void 0;
	}
	serializedRecords() {
		return this.records;
	}
	activations() {
		return this.projectedActivations ??= this.records.map((record, index) => projectActivation(record, this.schemas[index]));
	}
};
//#endregion
//#region ../packages/ssr/dist/render/document-hydration.js
/** Reports whether document streaming options require a hydration payload. */
function shouldEmitDocumentHydration(options) {
	if (options.hydration === false) return false;
	if (options.hydration === true) return true;
	return options.endpoint !== void 0 || options.endpoints !== void 0 || options.state !== void 0 || options.continuations !== void 0 || options.publicContexts !== void 0 || options.executionRoot !== void 0 || options.binding !== void 0 || options.buildKey !== void 0 || options.scriptId !== void 0 || options.nonce !== void 0;
}
//#endregion
//#region ../packages/ssr/dist/render/execution.js
/** Continues immediately for available work, preserving native promise settlement when pending. */
function mapRenderValue(value, read) {
	return value instanceof Promise ? value.then(read) : read(value);
}
/**
* Keeps cleanup attached to one render operation through synchronous and asynchronous completion.
* A cleanup failure is suppressed behind an existing primary failure, never substituted for it.
*/
function withRenderCleanup(render, cleanup) {
	let result;
	try {
		result = render();
	} catch (error) {
		return cleanupAfterFailure(error, cleanup);
	}
	if (result instanceof Promise) return result.then((value) => finishRender(value, cleanup), (error) => cleanupAfterFailure(error, cleanup));
	return finishRender(result, cleanup);
}
function finishRender(value, cleanup) {
	const disposal = cleanup();
	return disposal instanceof Promise ? disposal.then(() => value) : value;
}
/** Runs failure cleanup once and keeps the original failure authoritative. */
function cleanupAfterFailure(error, cleanup) {
	let disposal;
	try {
		disposal = cleanup();
	} catch (suppressed) {
		attachSuppressedCleanupFailure(error, suppressed);
		throw error;
	}
	if (disposal instanceof Promise) return disposal.then(() => {
		throw error;
	}, (suppressed) => {
		attachSuppressedCleanupFailure(error, suppressed);
		throw error;
	});
	throw error;
}
//#endregion
//#region ../packages/ssr/dist/render/hydration-options.js
/** Projects every hydration-publication option while replacing values captured during rendering. */
function hydrationScriptOptions(options, result, resumptions) {
	return hydrationScriptOptionsFromValues(options, result.state, result.wallClockSnapshot, result.hydrationTable, resumptions);
}
/** Projects hydration options directly from one completed request-owned render output. */
function hydrationScriptOptionsFromValues(options, state, wallClockSnapshot, hydrationTable, resumptions) {
	return {
		pluginRegistryFingerprint: options.pluginRegistryFingerprint,
		endpoint: options.endpoint,
		endpoints: options.endpoints,
		state,
		publishRootProps: void 0,
		markerlessRoot: options.markerlessRoot,
		continuations: options.continuations,
		resumptions,
		publicContexts: options.publicContexts,
		wallClockSnapshot,
		hydrationTable,
		executionRoot: options.executionRoot,
		binding: options.binding,
		buildKey: options.buildKey,
		componentAuthorization: options.componentAuthorization,
		scriptId: options.scriptId,
		nonce: options.nonce,
		maxHydrationDepth: options.maxHydrationDepth,
		maxHydrationNodes: options.maxHydrationNodes,
		maxHydrationBytes: options.maxHydrationBytes,
		outputExtensions: options.outputExtensions
	};
}
//#endregion
//#region ../packages/ssr/dist/render/document-output.js
/** Internal deferred publication boundary, retained until request resumption capture completes. */
var documentHydrationSlot = "<!--exact:document-hydration-->";
/** Resolves one output marker without capturing hydration state before its owner completes. */
function renderDocumentOutput(context, options, kind) {
	const head = kind === "styles" || kind === "headScripts";
	if (context.hostStack.at(-1) !== (head ? "head" : "body")) throw new Error(`documentOutput.${kind} must be an immediate ${head ? "head" : "body"} child`);
	const emitted = context.documentOutputs ??= /* @__PURE__ */ new Set();
	if (emitted.has(kind)) throw new Error(`Duplicate documentOutput.${kind} marker`);
	emitted.add(kind);
	const assets = options.documentAssets;
	if (kind === "styles") return region("head", (assets?.styles ?? []).map((href) => `<link rel="stylesheet" href="${escapeAttr(href)}">`).join(""));
	if (kind === "hydrationData") return documentHydrationSlot;
	if (kind === "bootstrap" && !emitted.has("hydrationData")) throw new Error("documentOutput.bootstrap must follow documentOutput.hydrationData");
	const scripts = kind === "headScripts" ? assets?.headScripts : assets?.bootstrap;
	return region(head ? "head" : "body", (scripts ?? []).map((script) => scriptTag(script, assets?.nonce)).join(""));
}
function scriptTag(script, nonce) {
	return `<script src="${escapeAttr(script.src)}"${script.type === "classic" ? " defer" : " type=\"module\""}${nonce ? ` nonce="${escapeAttr(nonce)}"` : ""}${script.integrity ? ` integrity="${escapeAttr(script.integrity)}"` : ""}${script.crossOrigin ? ` crossorigin="${escapeAttr(script.crossOrigin)}"` : ""}><\/script>`;
}
function region(location, html) {
	return html ? `<!--exact:framework-${location}:start-->${html}<!--exact:framework-${location}:end-->` : "";
}
/** Replaces the deferred slot after capture; legacy documents retain automatic body insertion. */
function fillDocumentHydration(html, hydration) {
	return html.replace(documentHydrationSlot, () => region("body", hydration));
}
//#endregion
//#region ../packages/ssr/dist/render/output-buffer.js
/** Internal ordered chunks behind a public SSR string result. */
var ssrHtmlChunks = Symbol("exact.ssr.html-chunks");
/** Internal ordered chunks behind a public hydratable SSR string result. */
var ssrHydratableChunks = Symbol("exact.ssr.hydratable-chunks");
/** Reads renderer-owned chunks without materializing the public HTML getter. */
function htmlChunksOf(value) {
	return value[ssrHtmlChunks];
}
//#endregion
//#region ../packages/ssr/dist/render/output-result.js
var resultStorage = Symbol("ssrResultStorage");
var documentHydrationPresence = Symbol("ssrDocumentHydrationPresence");
/** Shared own accessors preserve lazy reads without retaining request state in accessor closures. */
var hydratableResultDescriptors = {
	htmlWithHydration: {
		enumerable: true,
		configurable: true,
		get() {
			const data = this[resultStorage];
			return data.materialized ??= data.chunks.length === 1 ? data.chunks[0] : data.chunks.join("");
		}
	},
	resumptions: {
		enumerable: true,
		configurable: true,
		get() {
			const value = this[resultStorage].resumptions;
			return typeof value === "function" ? value() : value;
		}
	}
};
/** Publishes completed HTML while retaining request-owned chunks for hydration insertion. */
function createChunkedStringResult(chunks, state, hydrationTable, preloadLinks, wallClockSnapshot, hasHydrationSlot) {
	let html = "";
	for (const chunk of chunks) html += chunk;
	const result = {
		html,
		state
	};
	if (wallClockSnapshot !== void 0) result.wallClockSnapshot = wallClockSnapshot;
	if (hydrationTable) result.hydrationTable = hydrationTable;
	if (preloadLinks?.length) result.preloadLinks = Object.freeze([...preloadLinks]);
	Object.defineProperty(result, ssrHtmlChunks, { value: chunks });
	if (hasHydrationSlot ?? html.includes("<!--exact:document-hydration-->")) Object.defineProperty(result, documentHydrationPresence, { value: true });
	return result;
}
/** Uses renderer-owned slot provenance; foreign string results require a content scan. */
function hasDocumentHydrationSlot(result) {
	return htmlChunksOf(result) ? result[documentHydrationPresence] === true : result.html.includes(documentHydrationSlot);
}
/** Adds hydration output without flattening ordinary fragment-style HTML. */
function createChunkedHydratableResult(result, resumptions, hydrationScript) {
	const htmlChunks = htmlChunksOf(result);
	const hasSlot = hasDocumentHydrationSlot(result);
	const plainHtml = hasSlot ? fillDocumentHydration(result.html, "") : result.html;
	const chunks = hasSlot ? [fillDocumentHydration(result.html, hydrationScript)] : htmlChunks ? augmentChunkedBody(htmlChunks, hydrationScript) : [augmentDocumentBody(result.html, hydrationScript)];
	const hydratable = {
		resumptions: void 0,
		htmlWithHydration: void 0,
		html: plainHtml,
		state: result.state,
		hydrationScript
	};
	Object.defineProperty(hydratable, "resumptions", hydratableResultDescriptors.resumptions);
	Object.defineProperty(hydratable, "htmlWithHydration", hydratableResultDescriptors.htmlWithHydration);
	Object.defineProperty(hydratable, resultStorage, { value: {
		chunks,
		materialized: void 0,
		resumptions
	} });
	if (result.wallClockSnapshot !== void 0) hydratable.wallClockSnapshot = result.wallClockSnapshot;
	if (result.hydrationTable) hydratable.hydrationTable = result.hydrationTable;
	if (result.preloadLinks) hydratable.preloadLinks = result.preloadLinks;
	Object.defineProperty(hydratable, ssrHtmlChunks, { value: hasSlot ? [plainHtml] : htmlChunks ?? [result.html] });
	Object.defineProperty(hydratable, ssrHydratableChunks, { value: chunks });
	return hydratable;
}
/** Recognizes normalized document output across renderer chunk boundaries. */
function startsExactDocument(chunks) {
	const expected = "<!doctype ";
	let matched = 0;
	for (const chunk of chunks) {
		for (let index = 0; index < chunk.length && matched < 10; index++) if (chunk[index] !== expected[matched++]) return false;
		if (matched === 10) return true;
	}
	return false;
}
function augmentChunkedBody(chunks, hydrationScript) {
	if (!startsExactDocument(chunks)) return [...chunks, hydrationScript];
	const insertion = findLastBodyClose(chunks);
	if (!insertion) throw new Error("Normalized eXact document output is missing its closing </body> element.");
	const augmentation = hydrationScript ? `<!--exact:framework-body:start-->${hydrationScript}<!--exact:framework-body:end-->` : "";
	if (!augmentation) return chunks;
	const result = chunks.slice(0, insertion.chunkIndex);
	const chunk = chunks[insertion.chunkIndex];
	if (insertion.offset) result.push(chunk.slice(0, insertion.offset));
	result.push(augmentation, chunk.slice(insertion.offset));
	for (let index = insertion.chunkIndex + 1; index < chunks.length; index++) result.push(chunks[index]);
	return result;
}
/** Searches from the document tail, preserving tokens split across arbitrary renderer chunks. */
function findLastBodyClose(chunks) {
	const expected = "</body>";
	let matched = 0;
	for (let chunkIndex = chunks.length - 1; chunkIndex >= 0; chunkIndex--) {
		const chunk = chunks[chunkIndex];
		for (let index = chunk.length - 1; index >= 0; index--) {
			const code = asciiLower(chunk.charCodeAt(index));
			if (code === expected.charCodeAt(7 - matched - 1)) {
				matched++;
				if (matched === 7) return {
					chunkIndex,
					offset: index
				};
			} else matched = code === expected.charCodeAt(6) ? 1 : 0;
		}
	}
}
function asciiLower(code) {
	return code >= 65 && code <= 90 ? code + 32 : code;
}
//#endregion
//#region ../packages/ssr/dist/render/ownership.js
/** Creates a ssr owner. */
function createSsrOwner() {
	const pending = /* @__PURE__ */ new Set();
	const instances = /* @__PURE__ */ new Set();
	return {
		pending,
		observer: {
			register(promise) {
				const observed = promise.finally(() => pending.delete(observed));
				observed.catch(() => void 0);
				pending.add(observed);
			},
			retain(instance) {
				instances.add(instance);
			}
		},
		dispose(reason = "ssr render complete") {
			if (instances.size === 0) return;
			const failure = createCleanupFailure();
			for (const instance of [...instances].reverse()) attemptCleanup(failure, () => instance.unmount(String(reason)));
			instances.clear();
			throwCleanupFailure(failure);
		}
	};
}
/** Provides the canonical no primary failure value. */
var noPrimaryFailure = Symbol("no primary SSR failure");
/** Releases preserving primary and its owned resources. */
function disposePreservingPrimary(dispose, primary) {
	try {
		dispose();
	} catch (cleanup) {
		if (primary === noPrimaryFailure) throw cleanup;
		attachSuppressedCleanupFailure(primary, cleanup);
	}
}
/** Releases asynchronous ownership without replacing a render failure with cleanup failure. */
async function disposeAsyncPreservingPrimary(dispose, primary) {
	try {
		await dispose();
	} catch (cleanup) {
		if (primary === noPrimaryFailure) throw cleanup;
		attachSuppressedCleanupFailure(primary, cleanup);
	}
}
//#endregion
//#region ../packages/ssr/dist/render/suspense-streaming.js
/**
* Plans the smallest outermost Suspense replacements that transform a shell into settled HTML.
*
* Returns `undefined` when boundary-local replacements cannot explain every difference. The
* caller must then replace the root so updates outside Suspense are never silently omitted.
*/
function planSuspenseStreamReplacements(shell, settled) {
	if (shell === settled) return [];
	const shellRanges = suspenseRanges(shell);
	const settledByIdentity = new Map(suspenseRanges(settled).map((range) => [range.identity, range]));
	const changed = shellRanges.filter((range) => {
		const finalRange = settledByIdentity.get(range.identity);
		return !!finalRange && finalRange.html !== range.html;
	});
	const outermost = changed.filter((range) => !changed.some((candidate) => candidate !== range && candidate.start < range.start && candidate.end > range.end));
	let patched = shell;
	for (const range of [...outermost].sort((left, right) => right.start - left.start)) {
		const finalRange = settledByIdentity.get(range.identity);
		patched = patched.slice(0, range.start) + finalRange.html + patched.slice(range.end);
	}
	if (patched !== settled) return void 0;
	return outermost.map((range) => Object.freeze({
		id: range.id,
		html: settledByIdentity.get(range.identity).html
	}));
}
function suspenseRanges(html) {
	const marker = /<!--(\/?)exact:([^>]+)-->/g;
	const open = /* @__PURE__ */ new Map();
	const ranges = [];
	for (let match = marker.exec(html); match; match = marker.exec(html)) {
		const closing = match[1] === "/";
		const id = match[2];
		const identity = suspenseIdentity(id);
		if (!identity) continue;
		if (!closing) {
			open.set(identity, {
				start: match.index,
				id
			});
			continue;
		}
		const start = open.get(identity);
		if (!start) continue;
		open.delete(identity);
		const end = marker.lastIndex;
		ranges.push({
			id: start.id,
			identity,
			start: start.start,
			end,
			html: html.slice(start.start, end)
		});
	}
	return ranges;
}
function suspenseIdentity(id) {
	return /^suspense-(?:content|fallback)(:.*)$/.exec(id)?.[1];
}
//#endregion
//#region ../packages/ssr/dist/render/host.js
/** Captures document claims without changing the balanced intrinsic ancestry stack. */
function checkpointDocumentHost(context) {
	return {
		documentDoctypeSeen: context.documentDoctypeSeen,
		documentOutputs: context.documentOutputs ? new Set(context.documentOutputs) : void 0,
		documentProbe: context.documentProbe,
		documentRootSeen: context.documentRootSeen,
		documentHeadSeen: context.documentHeadSeen,
		documentBodySeen: context.documentBodySeen
	};
}
/** Restores claims after an attempt whose intrinsic traversal has already unwound. */
function restoreDocumentHost(context, checkpoint) {
	context.documentProbe = checkpoint.documentProbe;
	context.documentRootSeen = checkpoint.documentRootSeen;
	context.documentHeadSeen = checkpoint.documentHeadSeen;
	context.documentBodySeen = checkpoint.documentBodySeen;
	context.documentOutputs = checkpoint.documentOutputs;
	context.documentDoctypeSeen = checkpoint.documentDoctypeSeen;
}
/** Enters one already-normalized intrinsic operation. */
function enterHostTag(context, inputTag) {
	const tag = inputTag.toLowerCase();
	const parentTag = context.hostStack[context.hostStack.length - 1];
	if (tag === "html") {
		if (!context.documentProbe || context.hostStack.length || context.documentRootSeen) throw new Error("A root document may contain exactly one top-level <html> element; nested or duplicate <html> elements are not allowed.");
		context.documentProbe = false;
		context.documentRootSeen = true;
	} else if (!context.hostStack.length) {
		if (context.documentRootSeen) throw new Error("A root document cannot render host content outside its <html> element.");
		context.documentProbe = false;
	}
	if (context.documentRootSeen && (tag === "head" || tag === "body")) {
		if (parentTag !== "html") throw new Error(`<${tag}> is only valid as a direct child of the root <html> element.`);
		if (tag === "head") {
			if (context.documentHeadSeen) throw new Error("A root document may contain at most one <head> element.");
			context.documentHeadSeen = true;
		} else {
			if (context.documentBodySeen) throw new Error("A root document may contain at most one <body> element.");
			context.documentBodySeen = true;
		}
	}
	context.hostStack.push(tag);
	return {
		tag,
		prefix: tag === "html" && context.documentRootSeen && !context.documentDoctypeSeen ? "<!doctype html>" : ""
	};
}
/** Leaves one intrinsic host domain. */
function leaveHost(context, tag) {
	if (context.hostStack.pop() !== tag) throw new Error("eXact SSR host traversal became unbalanced.");
}
/** Claims scalar output in the root document domain. */
function claimRootText(context) {
	if (context.hostStack.length) return;
	if (context.documentRootSeen) throw new Error("A root document cannot render text outside its <html> element.");
	context.documentProbe = false;
}
/** Serializes one compiler-authorized raw HTML operation. */
function renderUnsafeHtmlValue(context, value) {
	if (!context.allowUnsafeHtml) throw new Error("unsafeHtml() requires allowUnsafeHtml: true on the native eXact SSR root.");
	const html = String(unwrap(value) ?? "");
	context.onUnsafeHtml?.({ characters: html.length });
	return html;
}
/** Serializes the scalar-only contents of script and style intrinsics. */
function primitiveText(children) {
	let output = "";
	for (const child of children) {
		const value = unwrap(child);
		if (value === null || value === void 0 || value === false || value === true) continue;
		if (typeof value === "object" || typeof value === "function") throw new TypeError("Text-only intrinsic content requires scalar compiler output");
		output += String(value);
	}
	return output;
}
//#endregion
//#region ../packages/ssr/dist/render/operation-enhancement-routes.js
/** Publishes route cut points declared by this operation to its active ancestor enhancements. */
function beginRoutes(context, enhancement) {
	const routes = enhancement.entries.filter((entry) => entry.root === void 0).map((entry) => ({
		identity: entry.identity,
		props: entry.props,
		componentDepth: context.enhancementOperationComponentDepth ?? 0,
		consumed: false,
		nested: false
	}));
	if (!routes.length) return [];
	(context.enhancementOperationRoutes ??= []).push(...routes);
	return routes;
}
/** Restores the route stack after its owning operation exits. */
function endRoutes(context, count) {
	if (count) context.enhancementOperationRoutes.splice(-count, count);
}
/** Finds the most recent unconsumed root route at the current component depth. */
function directRootRoute(context, enhancement) {
	const roots = new Set(enhancement.entries.filter((entry) => entry.root === true).map((entry) => entry.identity));
	const depth = context.enhancementOperationComponentDepth ?? 0;
	return [...context.enhancementOperationRoutes ?? []].reverse().find((route) => !route.consumed && route.componentDepth === depth && roots.has(route.identity));
}
/** Marks an ancestor route claimed by a nested component root. */
function markNestedRootRoute(context, enhancement) {
	const roots = new Set(enhancement.entries.filter((entry) => entry.root === true).map((entry) => entry.identity));
	const depth = context.enhancementOperationComponentDepth ?? 0;
	const route = [...context.enhancementOperationRoutes ?? []].reverse().find((candidate) => !candidate.consumed && candidate.componentDepth < depth && roots.has(candidate.identity));
	if (route) route.nested = true;
}
/** Transfers one accumulated string prefix to the first pending nested enhancement route. */
function captureNestedEnhancementStringPrefix(context, html) {
	if (html === "") return html;
	const depth = context.enhancementOperationComponentDepth ?? 0;
	for (const route of context.enhancementOperationRoutes ?? []) {
		if (!route.nested || route.consumed || route.nestedBefore !== void 0) continue;
		if (route.componentDepth !== depth) continue;
		route.nestedBefore = html;
		return "";
	}
	return html;
}
//#endregion
//#region ../packages/core/dist/server/native-props.js
/** Identifies event-shaped native props regardless of authored casing. */
function isNativeEventProp(name) {
	return name.length > 2 && (name[0] === "o" || name[0] === "O") && (name[1] === "n" || name[1] === "N");
}
/** Rejects HTML-writing properties that bypass receipt validation and renderer range ownership. */
function assertNativePropAllowed(name) {
	const first = name[0];
	if (first !== "i" && first !== "I" && first !== "o" && first !== "O" && first !== "d" && first !== "D") return;
	const lower = name.toLowerCase();
	if (lower === "innerhtml" || lower === "outerhtml" || lower === "dangerouslysetinnerhtml") throw new TypeError(`Native eXact does not support ${name}; use unsafeHtml() with explicit root opt-in.`);
}
/** Rejects inline code and non-callable event values before DOM mutation or HTML serialization. */
function assertNativeEventHandler(value) {
	if (value != null && value !== false && typeof value !== "function") throw new TypeError("Native eXact event handlers must be functions; inline event strings are not supported.");
}
/** Canonicalizes the HTML document attribute before checking its unsafeHtml capability. */
function isNativeSrcdocProp(name) {
	return name.length === 6 && name.toLowerCase() === "srcdoc";
}
//#endregion
//#region ../packages/core/dist/server/framework/prepared-target-output.js
/**
* Reads one prepared contribution boundary or transparent supplied-child placement. Never executes
* descendant components. A contribution must place the supplied logical child exactly once;
* structural output belongs to a separate preparation boundary rather than a descendant search.
*/
function readPreparedTargetOutput(output, supplied) {
	const value = singlePreparedValue(output, supplied);
	if (value === supplied) return void 0;
	const target = readCompiledTargetReceipt(value);
	if (!target) throw new TypeError("Fragment contribution preparation requires a single supplied-target placement");
	if (singlePreparedValue(target.children, supplied) !== supplied) throw new TypeError("An enhancement must place its supplied fragment exactly once");
	return target;
}
/** Retains the selected receipt itself while unwrapping transparent compiler expression ranges. */
function singlePreparedValue(output, supplied) {
	let value = output;
	for (;;) {
		if (value === supplied) return value;
		value = unwrap(value);
		if (value === supplied) return value;
		if (Array.isArray(value) && value.length === 1) {
			value = value[0];
			continue;
		}
		const range = readChildRangeReceipt(value);
		if (range && !range.dynamicComponent) {
			value = range.value;
			continue;
		}
		const serverRange = readPreparedServerChildRange(value);
		if (serverRange) {
			value = serverRange.value;
			continue;
		}
		return value;
	}
}
/** Reads a single supplied logical operation through transparent value containers, retaining fragments. */
function readSuppliedTargetValue(output) {
	return singlePreparedValue(output, void 0);
}
//#endregion
//#region ../packages/core/dist/server/framework/target-contributions.js
/** Merges ordered target class contributions with stable token de-duplication. */
function mergeTargetClassContributions(values) {
	return mergeTargetTokens(values, normalizeClassValue);
}
/** Merges ordered ARIA/token-list target contributions with stable de-duplication. */
function mergeTargetTokenContributions(values) {
	return mergeTargetTokens(values, String);
}
function mergeTargetTokens(values, normalize) {
	const tokens = [];
	let suppressed = false;
	for (const value of values) {
		const actual = unwrap(value);
		if (actual === void 0) continue;
		if (actual === null) {
			suppressed = true;
			continue;
		}
		for (const token of normalize(actual).split(/\s+/)) if (token && !tokens.includes(token)) tokens.push(token);
	}
	return tokens.length ? tokens.join(" ") : suppressed ? null : void 0;
}
var tokenListProps = /* @__PURE__ */ new Set([
	"aria-describedby",
	"aria-labelledby",
	"aria-controls",
	"aria-owns",
	"aria-flowto",
	"rel"
]);
/** Composes one semantic-target layer with authored and nearest-owner precedence. */
function composeTargetProps(base, layer) {
	const result = { ...base };
	delete result[TargetOverrides];
	const overrideValue = unwrap(layer[TargetOverrides]);
	const overrides = Array.isArray(overrideValue) && overrideValue.length ? new Set(overrideValue) : void 0;
	for (const key of /* @__PURE__ */ new Set([...Object.keys(base), ...Object.keys(layer)])) {
		if (key === "children" || key === "key" || key === "ref" || /^on[A-Z]/.test(key)) continue;
		const authored = unwrap(base[key]);
		const contributed = unwrap(layer[key]);
		if (overrides?.has(key)) result[key] = contributed;
		else if (key === "class" || key === "className") result[key] = mergeTargetClassContributions([authored, contributed]);
		else if (tokenListProps.has(key)) result[key] = mergeTargetTokenContributions([authored, contributed]);
		else if (key === "style" && isRecord(contributed) && isRecord(authored)) result[key] = {
			...contributed,
			...authored
		};
		else result[key] = authored !== void 0 ? authored : contributed;
	}
	return result;
}
function isRecord(value) {
	return !!value && typeof value === "object" && !Array.isArray(value);
}
//#endregion
//#region ../packages/core/dist/server/component-abi/text-projection-markup.js
/** Escapes one layer of literal markup content without allocating a DOM node. */
function escapeProjectedText(value) {
	return value.replace(/[&<>]/g, (character) => character === "&" ? "&amp;" : character === "<" ? "&lt;" : "&gt;");
}
/**
* Serializes native props into inert markup. Refs and renderer bookkeeping are not attributes;
* no element identity is reserved because this projection has no live element presentation.
*/
function projectedAttributes(props, tag, policy) {
	let result = "";
	for (const [key, raw] of Object.entries(props)) {
		assertNativePropAllowed(key);
		if (key === "ref" || key === "children" || key === "key" || key === "data-exact-id" || key.startsWith("__exact")) continue;
		if (isNativeEventProp(key)) {
			assertNativeEventHandler(unwrap(raw));
			continue;
		}
		let value = unwrap(raw);
		if (isNativeSrcdocProp(key)) {
			const receipt = readUnsafeHtmlReceipt(value);
			if (!receipt || !policy.allowUnsafeHtml) throw new TypeError("Projected srcdoc requires unsafeHtml() and allowUnsafeHtml root opt-in");
			value = String(unwrap(receipt.value) ?? "");
			policy.onUnsafeHtml?.({ characters: value.length });
		}
		if (key === "class" || key === "className") value = normalizeClassValue(value);
		if (key === "style") value = projectedStyle(value);
		if (key === "value" && tag === "input" && unwrap(props.type) === "date" && value instanceof Date) value = Number.isNaN(value.getTime()) ? "" : value.toISOString().slice(0, 10);
		value = sanitizeUrlAttribute(key, value);
		if (value == null || value === false || key === "style" && value === "") continue;
		const name = projectedAttributeName(key, tag);
		const safeName = /^[A-Za-z_:][A-Za-z0-9_:.-]*$/.test(name) ? name : "data-exact-invalid-attr";
		result += value === true ? ` ${safeName}` : ` ${safeName}="${escapeProjectedText(String(value)).replaceAll("\"", "&quot;")}"`;
	}
	return result;
}
function projectedStyle(value) {
	if (typeof value === "string") return value;
	if (!value || typeof value !== "object") return "";
	const declarations = [];
	for (const [name, raw] of Object.entries(value)) {
		const property = unwrap(raw);
		if (property == null || property === false) continue;
		const css = name.startsWith("--") ? name : (name.startsWith("ms") ? "-" : "") + name.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`);
		declarations.push(`${css}: ${String(property)};`);
	}
	return declarations.join(" ");
}
function projectedAttributeName(name, tag) {
	if (isNativeSrcdocProp(name)) return "srcdoc";
	if (name === "className") return "class";
	if (name === "commandFor") return "commandfor";
	if (tag === "script") switch (name) {
		case "crossOrigin":
		case "fetchPriority":
		case "noModule":
		case "referrerPolicy": return name.toLowerCase();
	}
	return name;
}
//#endregion
//#region ../packages/core/dist/server/framework/fragment-hosts.js
var bookkeeping = /* @__PURE__ */ new Set([
	"key",
	"children",
	"__exactEnhancements"
]);
/** Detects a host contribution without evaluating reactive prop values. */
function hasFragmentHostProps(props) {
	return Object.keys(props).some((key) => !bookkeeping.has(key));
}
/**
* Shared-host lifetime. Requirements latch for each active attachment and hosts retain
* identity while at least one owner survives. Removing a middle group does not compact other hosts.
* Tag configuration is static; replacing an owner must use a new opaque owner identity.
*/
var FragmentPresentationHosts = class {
	hosts = [];
	requirements = /* @__PURE__ */ new Map();
	/** Plans hosts in source order. Does not allocate DOM, execute components, or merge their props. */
	reconcile(owners) {
		const active = new Set(owners.map((owner) => owner.owner));
		if (active.size !== owners.length) throw new Error("Duplicate fragment contribution owner");
		const requirements = new Map(this.requirements);
		const existing = /* @__PURE__ */ new Map();
		for (const host of this.hosts) for (const owner of host.owners) existing.set(owner.owner, host);
		const next = [];
		const assigned = /* @__PURE__ */ new Set();
		let barrier = false;
		for (const owner of owners) {
			const tag = owner.tag ?? "span";
			const requirement = requirements.get(owner.owner);
			if (requirement !== void 0 && requirement !== tag) throw new Error("Fragment host tag must remain static for an attachment");
			barrier ||= owner.structuralBarrier === true;
			if (requirement === void 0 && !owner.declaredHostProps && !hasFragmentHostProps(owner.props)) continue;
			requirements.set(owner.owner, tag);
			const old = existing.get(owner.owner);
			const previous = next.at(-1);
			if (!barrier && previous?.tag === tag && (old === void 0 || old.identity === previous.identity)) previous.owners.push(owner);
			else {
				const identity = old && !assigned.has(old.identity) ? old.identity : Symbol("fragment host");
				assigned.add(identity);
				next.push({
					identity,
					tag,
					owners: [owner]
				});
			}
			barrier = owner.structuralBarrier === true;
		}
		this.requirements.clear();
		for (const [owner, tag] of requirements) if (active.has(owner)) this.requirements.set(owner, tag);
		this.hosts = next.map((host) => Object.freeze({
			...host,
			owners: Object.freeze(host.owners)
		}));
		return this.hosts;
	}
	/** Releases all retained host requirements when the owning fragment attachment ends. */
	dispose() {
		this.hosts = [];
		this.requirements.clear();
	}
};
//#endregion
//#region ../packages/core/dist/server/framework/enhancement-order.js
/**
* Validates source-ordered peers before constructing any owner. Providers in the same chain must
* precede their consumers; a conflict cannot be repaired by changing authored wrapper nesting.
* External providers remain the ordinary context resolver's responsibility. Cost is linear in
* entries and declared context effects, without constructing a dependency graph.
*/
function assertEnhancementSourceOrder(entries, catalog) {
	if (entries.length < 2) {
		if (entries.length && !catalog.has(entries[0].identity)) throw new Error(`Enhancement is unavailable: ${entries[0].identity}`);
		return;
	}
	const firstProvider = /* @__PURE__ */ new Map();
	const contracts = entries.map((entry, index) => {
		const component = catalog.get(entry.identity);
		if (!component) throw new Error(`Enhancement is unavailable: ${entry.identity}`);
		const contract = readExactEnhancementContexts(component);
		for (const token of contract?.provides ?? []) if (!firstProvider.has(token)) firstProvider.set(token, {
			index,
			identity: entry.identity
		});
		return contract;
	});
	for (let index = 0; index < entries.length; index++) for (const token of contracts[index]?.requires ?? []) {
		const provider = firstProvider.get(token);
		if (provider && provider.index > index) throw new Error(`Enhancement source order conflict: ${entries[index].identity} requires context from later provider ${provider.identity}`);
	}
}
//#endregion
//#region ../packages/core/dist/server/framework/fragment-target-projection.js
/**
* Projects only one enhancement owner's supplied placement, preserving its authored structure.
* Nested component implementations stay opaque. Each owner is a host-coalescing barrier; transparent
* consecutive owners are grouped before this path. Reactive ranges retain their existing invalidation.
*/
function createFragmentTargetProjection(supplied, tag, owner) {
	const identity = Symbol("fragment contribution");
	const hosts = new FragmentPresentationHosts();
	const cache = /* @__PURE__ */ new WeakMap();
	const map = (raw) => {
		const selected = typeof supplied === "function" ? supplied() : supplied;
		if (raw === selected) return raw;
		const value = unwrap(raw);
		if (value === selected) return value;
		if (Array.isArray(value)) return value.map(map);
		if (typeof value !== "object" || value === null) return value;
		const retained = cache.get(value);
		if (retained !== void 0) return retained;
		const target = readCompiledTargetReceipt(value);
		let result = value;
		if (target) {
			const contribution = readPreparedTargetOutput([value], selected);
			result = createCompiledTargetReceipt(null, createCompiledFragmentPresentation(selected, hosts.reconcile([{
				owner: identity,
				tag,
				props: contribution.props,
				declaredHostProps: contribution.declaredHostProps
			}]).map((host) => ({
				identity: host.identity,
				tag: host.tag,
				contributions: [{
					identity,
					props: contribution.props,
					owner
				}]
			}))));
		} else {
			const intrinsic = readCompiledIntrinsicReceipt(value);
			const fragment = readCompiledFragmentReceipt(value);
			const range = readChildRangeReceipt(value);
			const serverRange = readPreparedServerChildRange(value);
			const program = readRenderProgramReceipt(value);
			const serverProgram = readPreparedServerRenderProgram(value);
			if (intrinsic) result = withIntrinsicReceiptChildren(value, intrinsic.children.map((child) => map(child)));
			else if (fragment) result = createCompiledFragmentReceipt({
				...fragment.props,
				key: fragment.key,
				__exactEnhancements: fragment.enhancement
			}, ...fragment.children.map(map));
			else if (range && !range.dynamicComponent) result = createChildRangeReceipt(computed(() => map(range.value)), range.markerId, range.mayReplaceSubtree);
			else if (serverRange) result = createPreparedServerChildRange(map(serverRange.value), serverRange.markerId, serverRange.mayReplaceSubtree);
			else if (program) {
				const invocation = program.invocation;
				const slots = new Set(invocation.program.targetSlots ?? []);
				result = createPreparedRenderProgram(invocation.program, (index) => slots.has(index) ? map(readRenderProgramSlot(invocation, index)) : readRenderProgramSlot(invocation, index), invocation.owner, invocation.propertyWriter, program.enhancement);
			} else if (serverProgram) {
				const slots = new Set(serverProgram.program.targetSlots ?? []);
				const values = (input) => input.map((entry, index) => slots.has(index) ? map(entry) : entry);
				result = {
					...serverProgram,
					eagerValues: values(serverProgram.eagerValues),
					...serverProgram.deferredValues ? { deferredValues: {
						...serverProgram.deferredValues,
						read: () => values(serverProgram.deferredValues.read())
					} } : {}
				};
			}
		}
		cache.set(value, result);
		return result;
	};
	return (children) => children.map((child) => map(child));
}
//#endregion
//#region ../packages/core/dist/server/framework/fragment-enhancement-chain.js
/** Builds source-ordered fragment peers, grouping transparent runs without crossing authored structure. */
function createFragmentEnhancementChain(entries, target, catalog, transparentUpdates = false) {
	let chain = target;
	for (let index = entries.length - 1; index >= 0;) {
		const entry = entries[index];
		const component = catalog.get(entry.identity);
		if (readExactEnhancementContexts(component)?.transparentTarget) {
			let start = index;
			while (start > 0 && readExactEnhancementContexts(catalog.get(entries[start - 1].identity))?.transparentTarget) start--;
			chain = createCompiledFragmentReceipt({ __exactEnhancements: createEnhancementNode(entries.slice(start, index + 1)) }, chain);
			index = start - 1;
		} else {
			let receipt = withFragmentEnhancementTarget(createCompiledComponentReceipt(component, { ...entry.props }, chain), chain, entry.intrinsicFragment);
			if (transparentUpdates) receipt = withTransparentComponentUpdateOwner(receipt);
			chain = receipt;
			index--;
		}
	}
	return chain;
}
//#endregion
//#region ../packages/core/dist/server/framework/text-target-output.js
/** Identifies present scalar output without treating absent values as live targets. */
function isTextTargetOutput(value) {
	const actual = unwrap(value);
	if (Array.isArray(actual)) return actual.length > 0 && actual.every(isTextTargetOutput);
	return typeof actual === "string" || typeof actual === "number";
}
/** Gives scalar component output a request-local identity for namespace routing and adoption. */
function prepareTextTargetOutput(children) {
	return children.map((child) => isTextTargetOutput(child) ? createChildRangeReceipt(child) : child);
}
//#endregion
//#region ../packages/core/dist/server/framework/enhancement-fallback.js
var selections = /* @__PURE__ */ new WeakMap();
/** Shares one unresolved bounded fallback across sequential prepared sibling candidates. */
function fallbackEnhancementEntries(entry, count) {
	const selection = selections.get(entry) ?? { claimed: false };
	return Array.from({ length: count }, () => {
		const candidate = { ...entry };
		selections.set(candidate, selection);
		return candidate;
	});
}
/** A concrete target or authoritative explicit route prevents later sibling fallback. */
function claimEnhancementFallback(entry) {
	const selection = selections.get(entry);
	if (selection) selection.claimed = true;
	return { ...entry };
}
/** Tests eligibility without consuming an opaque component before it reveals any output. */
function enhancementFallbackAvailable(entry) {
	return !selections.get(entry)?.claimed;
}
/** Carries unresolved selection through normalized component markers without exposing metadata. */
function forwardEnhancementFallback(source, target) {
	const selection = selections.get(source);
	if (selection) selections.set(target, selection);
}
/** Restores shared fallback claims when an unpublished render or adoption attempt is retried. */
function checkpointEnhancementFallback(entries) {
	const snapshot = /* @__PURE__ */ new Map();
	for (const entry of entries) {
		const selection = selections.get(entry);
		if (selection) snapshot.set(selection, selection.claimed);
	}
	return () => {
		for (const [selection, claimed] of snapshot) selection.claimed = claimed;
	};
}
//#endregion
//#region ../packages/core/dist/server/framework/supplied-placement.js
/**
* Checks an owner's current structural output before placement. It follows compiler child slots,
* never executes a component, and ignores scalar ranges unrelated to placement. Mutually exclusive
* placements are evaluated from the same reactive snapshot so moving a child is not a duplicate.
* Returns the selected operation so a renderer can transfer its existing placement ownership.
*/
function assertSingleSuppliedPlacement(output, supplied) {
	let selected = unwrap(supplied);
	while (Array.isArray(selected) && selected.length === 1) selected = unwrap(selected[0]);
	if (selected == null || typeof selected === "boolean") return;
	let placements = 0;
	let placement;
	const place = (value) => {
		if (++placements > 1) throw new TypeError("A supplied target cannot be placed more than once by one component");
		placement = value;
	};
	const visit = (raw) => {
		const value = unwrap(raw);
		if (Array.isArray(value)) {
			for (const child of value) visit(child);
			return;
		}
		if (typeof value !== "object" || value === null) return;
		if (value === selected) {
			place(value);
			return;
		}
		const target = readCompiledTargetReceipt(value);
		if (target && target.children.length === 1 && unwrap(target.children[0]) === selected) {
			place(value);
			return;
		}
		const component = readCompiledComponentReceipt(value) ?? readPreparedServerComponentReference(value);
		const intrinsic = readCompiledIntrinsicReceipt(value);
		const fragment = readCompiledFragmentReceipt(value);
		const range = readChildRangeReceipt(value);
		const serverRange = readPreparedServerChildRange(value);
		const keyed = readCompiledKeyedChildReceipt(value);
		const program = readRenderProgramReceipt(value);
		const serverProgram = readPreparedServerRenderProgram(value);
		const children = target?.children ?? component?.children ?? intrinsic?.children ?? fragment?.children ?? (range ? range.mayReplaceSubtree ? [range.value] : [] : serverRange ? [serverRange.value] : keyed ? [keyed.value] : program ? (program.invocation.program.targetSlots ?? []).map((index) => readRenderProgramSlot(program.invocation, index)) : serverProgram ? (serverProgram.program.targetSlots ?? []).map((index) => serverProgram.eagerValues[index]) : []);
		for (const child of children) visit(child);
	};
	for (const child of output) visit(child);
	return placement;
}
//#endregion
//#region ../packages/ssr/dist/attribute-traversal.js
/** Reports whether an enumerable property belongs directly to its props object. */
function hasOwn(value, name) {
	return Object.prototype.hasOwnProperty.call(value, name);
}
/** Reports whether a JSX property uses the conventional event-handler spelling. */
function isEventProperty(name) {
	if (name.length < 3 || name.charCodeAt(0) !== 111 || name.charCodeAt(1) !== 110) return false;
	const first = name.charCodeAt(2);
	return first >= 65 && first <= 90;
}
/** Reports whether React 19 serializes an input property before ordinary properties. */
function isReactInputPriority(name) {
	return name === "type" || name === "disabled" || name === "name";
}
/** Reports whether React serializes an input property after ordinary properties. */
function isReactInputDeferred(name) {
	return name === "checked" || name === "defaultChecked" || name === "value" || name === "defaultValue";
}
/** Fixed React 19 input property prefix. */
var reactInputPriority = [
	"type",
	"disabled",
	"name"
];
/** Fixed React input property suffix. */
var reactInputDeferred = [
	"checked",
	"defaultChecked",
	"value",
	"defaultValue"
];
/** Fixed React option property suffix. */
var reactOptionDeferred = ["value", "selected"];
//#endregion
//#region ../packages/ssr/dist/react-attributes.js
var names = {
	acceptCharset: "accept-charset",
	autoCapitalize: "autoCapitalize",
	autoComplete: "autoComplete",
	className: "class",
	htmlFor: "for",
	httpEquiv: "http-equiv",
	charSet: "charset",
	crossOrigin: "crossorigin",
	defaultChecked: "checked",
	defaultValue: "value",
	fetchPriority: "fetchpriority",
	formAction: "formaction",
	formEncType: "formenctype",
	formMethod: "formmethod",
	formNoValidate: "formnovalidate",
	formTarget: "formtarget",
	referrerPolicy: "referrerpolicy",
	srcSet: "srcset",
	useMap: "usemap",
	viewBox: "viewBox",
	preserveAspectRatio: "preserveAspectRatio",
	xlinkHref: "xlink:href",
	xmlLang: "xml:lang",
	strokeWidth: "stroke-width",
	strokeLinecap: "stroke-linecap",
	strokeLinejoin: "stroke-linejoin",
	strokeMiterlimit: "stroke-miterlimit",
	strokeDasharray: "stroke-dasharray",
	strokeDashoffset: "stroke-dashoffset",
	fillRule: "fill-rule",
	clipPath: "clip-path",
	clipRule: "clip-rule"
};
/** React boolean attributes whose false value is omitted and true value is empty. */
var reactBooleanAttributes = /* @__PURE__ */ new Set([
	"allowfullscreen",
	"async",
	"autofocus",
	"autoplay",
	"checked",
	"controls",
	"default",
	"defer",
	"disabled",
	"download",
	"formnovalidate",
	"hidden",
	"inert",
	"ismap",
	"itemscope",
	"loop",
	"multiple",
	"muted",
	"nomodule",
	"novalidate",
	"open",
	"playsinline",
	"readonly",
	"required",
	"reversed",
	"scoped",
	"seamless",
	"selected"
]);
/** Resolves the React-compatible serialized name for one JSX property. */
function reactAttributeName(name, version, customElement) {
	if (name.startsWith("data-") || name.startsWith("aria-") || name.startsWith("--")) return name;
	if (customElement) return version === 19 && name === "className" ? "class" : name;
	if (version === 19 && (name === "spellCheck" || name === "contentEditable")) return name;
	if (version === 19 && name === "readOnly") return name;
	return names[name] ?? name.toLowerCase();
}
//#endregion
//#region ../packages/ssr/dist/render/output-attribute.js
var requiresAttributeEscaping = /[&<>\"]/;
/** Serializes one finalized attribute value and accounts its UTF-8 bytes without rescanning it. */
function renderAccountedAttribute(context, attributeName, value) {
	const output = context.outputSink;
	if (!output) return ` ${attributeName}="${escapeAttr(value)}"`;
	const rendered = ` ${attributeName}="${requiresAttributeEscaping.test(value) ? escapeAttr(value) : value}"`;
	output.account(rendered);
	return rendered;
}
//#endregion
//#region ../packages/ssr/dist/style.js
/** Serializes an owned native or React-compatible style value. */
function renderStyle(value, reactMarkup) {
	const actual = unwrap(value);
	if (!actual || actual === false) return "";
	if (typeof actual === "string") return actual;
	if (typeof actual !== "object") return "";
	let style = "";
	for (const name in actual) {
		if (!hasOwn(actual, name)) continue;
		const raw = actual[name];
		const styleValue = unwrap(raw);
		if (styleValue === null || styleValue === void 0 || styleValue === false) continue;
		const serialized = reactMarkup && typeof styleValue === "number" && styleValue !== 0 && !reactUnitlessStyles.has(name) ? `${styleValue}px` : String(styleValue);
		if (style) style += reactMarkup ? ";" : " ";
		style += reactMarkup ? `${toCssProperty(name)}:${serialized}` : `${toCssProperty(name)}: ${serialized};`;
	}
	return style;
}
function toCssProperty(name) {
	if (name.startsWith("--")) return name;
	let converted = "";
	for (let index = 0; index < name.length; index++) {
		const code = name.charCodeAt(index);
		converted += code >= 65 && code <= 90 ? `-${String.fromCharCode(code + 32)}` : name[index];
	}
	return name.startsWith("ms") ? `-${converted}` : converted;
}
var unitlessNames = [
	"animationIterationCount",
	"aspectRatio",
	"borderImageOutset",
	"borderImageSlice",
	"borderImageWidth",
	"boxFlex",
	"boxFlexGroup",
	"boxOrdinalGroup",
	"columnCount",
	"columns",
	"flex",
	"flexGrow",
	"flexPositive",
	"flexShrink",
	"flexNegative",
	"flexOrder",
	"gridArea",
	"gridColumn",
	"gridColumnEnd",
	"gridColumnSpan",
	"gridColumnStart",
	"gridRow",
	"gridRowEnd",
	"gridRowSpan",
	"gridRowStart",
	"fontWeight",
	"lineClamp",
	"lineHeight",
	"opacity",
	"order",
	"orphans",
	"scale",
	"tabSize",
	"widows",
	"zIndex",
	"zoom",
	"fillOpacity",
	"floodOpacity",
	"stopOpacity",
	"strokeDasharray",
	"strokeDashoffset",
	"strokeMiterlimit",
	"strokeOpacity",
	"strokeWidth"
];
var reactUnitlessStyles = new Set(unitlessNames);
for (const prefix of [
	"Webkit",
	"Moz",
	"ms",
	"O"
]) for (const name of unitlessNames) reactUnitlessStyles.add(`${prefix}${name[0].toUpperCase()}${name.slice(1)}`);
//#endregion
//#region ../packages/ssr/dist/render/program-sink.js
/** Flushes before actual suspension and retains descendant ownership through a failing drain. */
function awaitSsrProgramSink(sink, value) {
	if (!sink) return value;
	let drain;
	try {
		drain = sink.flush("await");
	} catch (error) {
		return value.then(() => {
			throw error;
		}, () => {
			throw error;
		});
	}
	return drain instanceof Promise ? settleProgramFlush(value, drain) : value;
}
/** A failed drain cannot unwind a parent's scope while its descendant still owns it. */
async function settleProgramFlush(value, drain) {
	try {
		const [result] = await Promise.all([value, drain]);
		return result;
	} finally {
		await value.then(() => void 0, () => void 0);
	}
}
//#endregion
//#region ../packages/ssr/dist/render/program-boundary.js
/**
* Publishes an ordered boundary through a shared sink. Opening pressure precedes child work;
* child rejection never emits the closing span. Pending descendants settle before flush failure
* unwinds their owner's scope. Completion includes the closing span's drain.
*/
function writeProgramBoundary(context, sink, opening, closing, render) {
	if (opening) {
		context.outputSink?.accountKnown(opening, opening.length);
		sink.write(opening);
	}
	const pending = sink.ready();
	return pending ? pending.then(() => renderBoundary(context, sink, closing, render)) : renderBoundary(context, sink, closing, render);
}
/** Keeps the synchronous path direct while flushing before pending descendants. */
function renderBoundary(context, sink, closing, render) {
	const rendered = render();
	return rendered instanceof Promise ? awaitSsrProgramSink(sink, rendered).then((html) => finishBoundary(context, sink, closing, html)) : finishBoundary(context, sink, closing, rendered);
}
/** Drains child output before publishing any closing marker. */
function finishBoundary(context, sink, closing, html) {
	if (html) sink.write(html);
	const pending = sink.ready();
	return pending ? pending.then(() => closeBoundary(context, sink, closing)) : closeBoundary(context, sink, closing);
}
/** An empty closing span creates no new pressure after the child has drained. */
function closeBoundary(context, sink, closing) {
	if (!closing) return "";
	context.outputSink?.accountKnown(closing, closing.length);
	sink.write(closing);
	const pending = sink.ready();
	return pending ? pending.then(() => "") : "";
}
/** Publishes a generated child/component position without collecting a deferred segment array. */
function writeProgramChild(context, output, value, id, characters, markerless = false) {
	const marked = context.markers && !markerless;
	const opening = marked ? `<!--x:${id}-->` : "";
	const closing = marked ? `<!--/x:${id}-->` : "";
	const nextCharacters = characters + opening.length + closing.length;
	if (nextCharacters > context.maxOutputBytes) throw new SsrOutputLimitError(context.maxOutputBytes);
	const completed = writeProgramBoundary(context, output.sink, opening, closing, () => output.render(value));
	return completed instanceof Promise ? completed.then(() => nextCharacters) : nextCharacters;
}
//#endregion
//#region ../packages/ssr/dist/markers.js
/**
* Renders a stable exact marker pair around available or pending HTML content.
* Shared sinks own the spans and may suspend even when the child renders synchronously.
* Opening pressure precedes child execution; closing pressure precedes completion.
*/
function markerPair(context, id, render) {
	if (!context.markers) return render();
	const itemKey = id.startsWith("item:") ? id.slice(5) : void 0;
	const opening = itemKey === void 0 ? id ? `<!--exact:${id}-->` : "<!--x-->" : `<!--i:${itemKey}-->`;
	const closing = itemKey === void 0 ? id ? `<!--/exact:${id}-->` : "<!--/x-->" : `<!--/i:${itemKey}-->`;
	const sink = context.writerSink;
	if (sink) return writeProgramBoundary(context, sink, opening, closing, render);
	context.outputSink?.accountKnown(opening, opening.length);
	const rendered = render();
	if (rendered instanceof Promise) return rendered.then((html) => {
		context.outputSink?.accountKnown(closing, closing.length);
		return `${opening}${html}${closing}`;
	});
	context.outputSink?.accountKnown(closing, closing.length);
	return `${opening}${rendered}${closing}`;
}
/** Wraps output that already completed inside its component-local rollback boundary. */
function finalizedMarkerPair(context, id, rendered) {
	if (!context.markers) return rendered;
	const opening = id ? `<!--exact:${id}-->` : "<!--x-->";
	const closing = id ? `<!--/exact:${id}-->` : "<!--/x-->";
	context.outputSink?.accountKnown(opening, opening.length);
	context.outputSink?.accountKnown(closing, closing.length);
	return `${opening}${rendered}${closing}`;
}
/** Allocates a marker id from render context, kind, optional name, and optional key. */
function markerId(context, kind, name, key) {
	return formatMarkerId(kind, context.nextId++, name, key);
}
/** Formats an already reserved identity without advancing the render context. */
function formatMarkerId(kind, ordinal, name, key) {
	return `${kind}:${ordinal}${name ? `:${encodeMarkerKey(name)}` : ""}${key ? `:${encodeMarkerKey(key)}` : ""}`;
}
/** Adds rendered Suspense status to a previously allocated stable boundary identity. */
function suspenseStatusMarkerId(identity, status) {
	if (!identity.startsWith("suspense:")) throw new Error("Suspense marker identity must use the suspense kind");
	return `suspense-${status}${identity.slice(8)}`;
}
/** Normalizes a compiler-provided exact marker id by removing a leading exact prefix. */
function exactMarkerId(id) {
	return id.startsWith("exact:") ? id.slice(6) : id;
}
/** Encodes arbitrary UTF-8 marker data without lossy HTML-comment sanitizing. */
function encodeMarkerKey(value) {
	if (isDirectMarkerPart(value)) return value;
	return encodeExactMarkerPart(value);
}
/** Proves the canonical unescaped marker grammar without allocating a regular-expression match. */
function isDirectMarkerPart(value) {
	if (!value.length) return false;
	let hyphen = false;
	for (let index = 0; index < value.length; index++) {
		const code = value.charCodeAt(index);
		if (code === 45) {
			if (hyphen) return false;
			hyphen = true;
			continue;
		}
		hyphen = false;
		if (code >= 48 && code <= 57 || code >= 65 && code <= 90 || code >= 97 && code <= 122 || code === 46 || code === 95) continue;
		return false;
	}
	return true;
}
//#endregion
//#region ../packages/ssr/dist/markup.js
/** Renders intrinsic-operation props as escaped HTML attributes. */
function renderAttrs(props, reactMarkup = false, tag, context, excludedNativeProps) {
	const boundDetails = !reactMarkup && tag === "details" && "__exactBindToggle" in props;
	let attrs = boundDetails ? ` data-exact-ssr-open="${unwrap(props.open) === true ? "true" : "false"}"` : "";
	if (!reactMarkup && props.ref) {
		const binding = unwrap(props.ref);
		const authoredId = unwrap(props.id);
		if (authoredId !== void 0) adoptElementId(binding, authoredId);
		else attrs += ` id="${escapeAttr(reserveElementId(binding))}"`;
	}
	const customElement = !!reactMarkup && !!tag?.includes("-");
	if (reactMarkup) {
		if (tag === "input") {
			if (reactMarkup === 19) for (let index = 0; index < reactInputPriority.length; index++) {
				const name = reactInputPriority[index];
				if (hasOwn(props, name)) attrs += renderAttribute(props[name], name, reactMarkup, tag, context, boundDetails, customElement, props.type);
			}
			for (const name in props) if (hasOwn(props, name) && !isReactInputDeferred(name) && (reactMarkup !== 19 || !isReactInputPriority(name))) attrs += renderAttribute(props[name], name, reactMarkup, tag, context, boundDetails, customElement, props.type);
			for (let index = 0; index < reactInputDeferred.length; index++) {
				const name = reactInputDeferred[index];
				if (hasOwn(props, name)) attrs += renderAttribute(props[name], name, reactMarkup, tag, context, boundDetails, customElement, props.type);
			}
		} else if (tag === "option") {
			for (const name in props) if (hasOwn(props, name) && name !== "value" && name !== "selected") attrs += renderAttribute(props[name], name, reactMarkup, tag, context, boundDetails, customElement, props.type);
			for (let index = 0; index < reactOptionDeferred.length; index++) {
				const name = reactOptionDeferred[index];
				if (hasOwn(props, name)) attrs += renderAttribute(props[name], name, reactMarkup, tag, context, boundDetails, customElement, props.type);
			}
		} else for (const name in props) if (hasOwn(props, name)) attrs += renderAttribute(props[name], name, reactMarkup, tag, context, boundDetails, customElement, props.type);
	} else for (const name in props) if (hasOwn(props, name) && !excludedNativeProps?.includes(name)) attrs += renderAttribute(props[name], name, reactMarkup, tag, context, boundDetails, customElement, props.type);
	return attrs;
}
function renderAttribute(rawValue, name, reactMarkup, tag, context, boundDetails, customElement, inputType) {
	if (!reactMarkup) {
		assertNativePropAllowed(name);
		if (isNativeEventProp(name)) {
			assertNativeEventHandler(unwrap(rawValue));
			return "";
		}
		if (isNativeSrcdocProp(name)) name = "srcdoc";
	}
	if (boundDetails && name === "data-exact-ssr-open" || name === "children" || name === "key" || name === "ref" || name === "__exactBindInput" || name === "__exactBindChange" || name === "__exactBindToggle" || name === "__exactModalOpen" || name === "__exactBindModalToggle" || name === "__exactBindModalClose" || name === "dangerouslySetInnerHTML" || isEventProperty(name)) return "";
	if (reactMarkup && (tag === "textarea" || tag === "select") && (name === "value" || name === "defaultValue")) return "";
	if (reactMarkup && tag === "option" && name === "children") return "";
	const unwrapped = !reactMarkup && (name === "srcdoc" || name === "srcDoc") ? unsafeHtmlAttribute(rawValue, context) : unwrap(rawValue);
	const normalized = !reactMarkup && (name === "className" || name === "class") ? normalizeClassValue(unwrapped) : name === "value" && tag === "input" && inputType === "date" && unwrapped instanceof Date ? Number.isNaN(unwrapped.getTime()) ? "" : unwrapped.toISOString().slice(0, 10) : unwrapped;
	const value = sanitizeUrlAttribute(name, normalized);
	const attrName = reactMarkup ? reactAttributeName(name, reactMarkup, customElement) : nativeAttributeName(name, tag);
	if (value === null || value === void 0) return "";
	if (value === false && (!reactMarkup || reactBooleanAttributes.has(attrName.toLowerCase()))) return "";
	if (attrName === "style") {
		const style = renderStyle(value, !!reactMarkup);
		return style ? ` style="${escapeAttr(style)}"` : "";
	}
	if (value === true) return reactMarkup ? reactBooleanAttributes.has(attrName.toLowerCase()) || reactMarkup === 19 && customElement ? ` ${escapeAttrName(attrName)}=""` : ` ${escapeAttrName(attrName)}="true"` : ` ${escapeAttrName(attrName)}`;
	return ` ${escapeAttrName(attrName)}="${escapeAttr(String(value))}"`;
}
/** Serializes one compiler-known native host value without allocating or scanning a prop bag. */
function renderNativeAttribute(value, name, tag, context) {
	return renderAttribute(value, name, false, tag, context, false, false);
}
/** Serializes one compiler-classified native attribute without rediscovering its behavior. */
function renderCompiledNativeAttribute(value, kind, name, attributeName, tag, context, accounted = false) {
	if (kind === 7 && typeof value === "string") {
		const html = ` ${attributeName}="${value}"`;
		if (accounted) context?.outputSink?.accountKnown(html, html.length);
		return html;
	}
	if (kind === 7) kind = 1;
	if (kind === 6) {
		const rendered = renderNativeAttribute(value, name, tag, context);
		if (accounted) context?.outputSink?.account(rendered);
		return rendered;
	}
	if ((kind === 0 || kind === 1) && typeof value === "string") return accounted && context ? renderAccountedAttribute(context, attributeName, value) : ` ${attributeName}="${escapeAttr(value)}"`;
	const unwrapped = kind === 4 ? unsafeHtmlAttribute(value, context) : unwrap(value);
	const normalized = kind === 1 ? normalizeClassValue(unwrapped) : kind === 5 && unwrapped instanceof Date ? Number.isNaN(unwrapped.getTime()) ? "" : unwrapped.toISOString().slice(0, 10) : unwrapped;
	const sanitized = kind === 3 ? sanitizeUrlAttribute(name, normalized) : normalized;
	if (sanitized === null || sanitized === void 0 || sanitized === false) return "";
	if (kind === 2) {
		const style = renderStyle(sanitized, false);
		return style ? accounted && context ? renderAccountedAttribute(context, "style", style) : ` style="${escapeAttr(style)}"` : "";
	}
	if (sanitized === true) {
		const rendered = ` ${attributeName}`;
		if (accounted) context?.outputSink?.accountKnown(rendered, rendered.length);
		return rendered;
	}
	return accounted && context ? renderAccountedAttribute(context, attributeName, String(sanitized)) : ` ${attributeName}="${escapeAttr(String(sanitized))}"`;
}
/** Serializes a compiler-owned root plan from its request-local prop values. */
function renderCompiledNativeAttributes(props, plan, tag, context, accounted = false) {
	let attributes = "";
	for (let index = 0; index < plan.length; index++) {
		const attribute = plan[index];
		const kind = attribute[0];
		const property = attribute[1];
		const attributeName = attribute[2];
		attributes += renderCompiledNativeAttribute(props[property], kind, property, attributeName, tag, context, accounted);
	}
	return attributes;
}
function unsafeHtmlAttribute(value, context) {
	const receipt = readUnsafeHtmlReceipt(unwrap(value));
	if (!receipt) throw new Error("Native eXact iframe srcdoc requires unsafeHtml() and explicit allowUnsafeHtml root opt-in.");
	if (!context?.allowUnsafeHtml) throw new Error("unsafeHtml() used for iframe srcdoc requires allowUnsafeHtml: true on the native eXact SSR root.");
	const html = String(unwrap(receipt.value) ?? "");
	context.onUnsafeHtml?.({ characters: html.length });
	return html;
}
function nativeAttributeName(name, tag) {
	if (name === "className") return "class";
	if (name === "commandFor") return "commandfor";
	if (tag !== "script") return name;
	switch (name) {
		case "crossOrigin": return "crossorigin";
		case "fetchPriority": return "fetchpriority";
		case "noModule": return "nomodule";
		case "referrerPolicy": return "referrerpolicy";
		default: return name;
	}
}
//#endregion
//#region ../packages/ssr/dist/render/server-list.js
var preparedServerList = Symbol.for("@exactjs/ssr/prepared-list");
/** Retains already-issued list children without a generic fragment receipt or private registration. */
function createServerList(children, authoredKey) {
	const key = unwrap(authoredKey);
	return {
		[preparedServerList]: true,
		children,
		key: key === null || key === void 0 ? void 0 : String(key)
	};
}
/** Recognizes the direct list carrier shared by server-runtime copies in the same realm. */
function readServerList(value) {
	return typeof value === "object" && value !== null && preparedServerList in value ? value : void 0;
}
//#endregion
//#region ../packages/ssr/dist/render/bound-enhancement-targets.js
/** Retains a scheduled component's incoming route until its output is finally published. */
function checkpointBoundEnhancementTarget(context, key) {
	const entries = context.boundEnhancementTargets?.get(key);
	const restore = checkpointEnhancementFallback(entries ?? []);
	return () => {
		restore();
		if (entries) context.boundEnhancementTargets.set(key, entries);
		else context.boundEnhancementTargets?.delete(key);
	};
}
/** Reads only compiler-owned child slots. Prop bags and nested component implementations stay opaque. */
function candidate(value) {
	if (typeof value !== "object" || value === null) return void 0;
	const component = readCompiledComponentReceipt(value) ?? readPreparedServerComponentReference(value);
	if (component) return {
		key: component,
		marker: component.enhancement,
		children: [],
		component: true,
		intrinsic: false
	};
	const intrinsic = readCompiledIntrinsicReceipt(value);
	if (intrinsic) return {
		key: value,
		marker: intrinsic.enhancement,
		children: intrinsic.children,
		component: false,
		intrinsic: true
	};
	const fragment = readCompiledFragmentReceipt(value);
	const list = readServerList(value);
	if (list) return {
		key: value,
		children: list.children,
		component: false,
		intrinsic: false
	};
	if (fragment) return {
		key: value,
		marker: fragment.enhancement,
		children: fragment.children,
		component: false,
		intrinsic: false
	};
	const program = readPreparedServerRenderProgram(value);
	if (program) return {
		key: value,
		marker: program.enhancement,
		component: false,
		intrinsic: true,
		children: (program.program.targetSlots ?? []).map((index) => program.eagerValues[index])
	};
	const target = readCompiledTargetReceipt(value);
	if (target) return {
		key: value,
		children: target.children,
		component: false,
		intrinsic: false
	};
	const range = readChildRangeReceipt(value) ?? readPreparedServerChildRange(value);
	const keyed = readCompiledKeyedChildReceipt(value) ?? readPreparedServerKeyedChild(value);
	if (range || keyed) return {
		key: value,
		children: [range ? unwrap(range.value) : keyed.value],
		component: false,
		intrinsic: false
	};
}
/** Selects each namespace in the current authored frame before any output from that frame commits. */
function selectSsrEnhancementTargets(output, entries, supplied = void 0) {
	const projected = new Set(Array.isArray(supplied) ? supplied : supplied === void 0 ? [] : [supplied]);
	const explicit = /* @__PURE__ */ new Map();
	const identities = new Set(entries.map((entry) => entry.identity));
	const fallbacks = [];
	let fragmentFallback;
	let textFallback;
	const visit = (raw, fallbackEligible, structured = false) => {
		const value = unwrap(raw);
		if (Array.isArray(value)) {
			for (const child of value) visit(child, fallbackEligible, structured);
			return;
		}
		if (structured && projected.has(value)) return;
		const node = candidate(value);
		const range = readChildRangeReceipt(value) ?? readPreparedServerChildRange(value);
		if (!textFallback && fallbackEligible && range && isTextTargetOutput(range.value)) textFallback = value;
		if (!node) return;
		for (const marker of node.marker?.entries ?? []) {
			if (!identities.has(marker.identity) || !unwrap(marker.root)) continue;
			if (explicit.has(marker.identity)) throw new Error(`Multiple active enhancement roots for ${marker.identity}`);
			explicit.set(marker.identity, node.key);
		}
		if (fallbackEligible && (node.intrinsic || node.component)) fallbacks.push(node.key);
		if (!fragmentFallback && fallbackEligible && readCompiledFragmentReceipt(value)) fragmentFallback = node.key;
		for (const child of node.children) visit(child, fallbackEligible && !node.intrinsic, structured || node.intrinsic || !!readCompiledFragmentReceipt(value));
	};
	for (const child of output) visit(child, true);
	const grouped = /* @__PURE__ */ new Map();
	for (const entry of entries) {
		if (!enhancementFallbackAvailable(entry)) continue;
		const selected = explicit.get(entry.identity);
		const keys = selected ? [selected] : fallbacks.length ? fallbacks : [fragmentFallback ?? textFallback].filter((key) => !!key);
		const routed = selected ? [claimEnhancementFallback(entry)] : fallbackEnhancementEntries(entry, keys.length);
		for (const [index, key] of keys.entries()) {
			const group = grouped.get(key) ?? [];
			group.push(routed[index]);
			grouped.set(key, group);
		}
	}
	return grouped;
}
/** Combines incoming declarations with nearer authored activators without making root markers activate. */
function boundOperationEnhancement(context, key, authored, delegate = false) {
	const incoming = context.boundEnhancementTargets?.get(key);
	if (!incoming) return authored;
	if (incoming.some(enhancementFallbackAvailable)) context.boundEnhancementTargets.delete(key);
	return combineBoundEnhancementEntries(incoming, authored, delegate);
}
/** Combines already selected entries, retaining delegated claims until a concrete target consumes them. */
function combineBoundEnhancementEntries(incoming, authored, delegate = false) {
	if (!authored && incoming?.length === 1) {
		const entry = incoming[0];
		if (!enhancementFallbackAvailable(entry)) return void 0;
		return Object.freeze({
			kind: "enhancement",
			entries: Object.freeze([delegate ? entry : claimEnhancementFallback(entry)]),
			fallback: "preserve-target"
		});
	}
	const bound = incoming.filter(enhancementFallbackAvailable);
	if (!bound?.length) return authored;
	const entries = new Map(bound.map((entry) => [entry.identity, delegate ? entry : claimEnhancementFallback(entry)]));
	for (const entry of authored?.entries ?? []) {
		const inherited = entries.get(entry.identity);
		if (inherited) entries.set(entry.identity, {
			...inherited,
			props: {
				...inherited.props,
				...entry.props
			},
			intrinsicFragment: entry.intrinsicFragment ?? inherited.intrinsicFragment
		});
		else entries.set(entry.identity, entry);
	}
	const marker = createEnhancementNode([...entries.values()]);
	if (delegate) for (const entry of marker.entries) {
		const source = bound.find((candidate) => candidate.identity === entry.identity);
		if (source) forwardEnhancementFallback(source, entry);
	}
	return marker;
}
//#endregion
//#region ../packages/reactive/dist/proxy/collections.js
var iterateDependency = Symbol("exact.collection.iterate");
var sizeDependency = Symbol("exact.collection.size");
var keyDependencies = /* @__PURE__ */ new WeakMap();
/**
* Implements the observable Map and Set surface without changing native
* collection identity, iteration order, or mutation return values.
*/
function reactiveCollectionMember(target, key, receiver, options, wrap) {
	if (key === "size") {
		track(target, sizeDependency);
		return target.size;
	}
	if (target instanceof Map) return reactiveMapMember(target, key, receiver, options, wrap);
	return reactiveSetMember(target, key, receiver, options, wrap);
}
function reactiveMapMember(target, key, receiver, options, wrap) {
	switch (key) {
		case "get": return (input) => {
			const rawKey = unwrap(input);
			const dependency = collectionKeyDependency(target, rawKey);
			track(target, dependency);
			return wrap(target.get(rawKey), dependency);
		};
		case "has": return (input) => {
			const rawKey = unwrap(input);
			track(target, collectionKeyDependency(target, rawKey));
			return target.has(rawKey);
		};
		case "set": return (input, value) => {
			assertWritable(options, "set");
			const rawKey = unwrap(input);
			const rawValue = unwrap(value);
			const had = target.has(rawKey);
			const previous = target.get(rawKey);
			if (had && !hasChanged(previous, rawValue)) return receiver;
			recordMapUndo(target, rawKey, had, previous);
			target.set(rawKey, rawValue);
			trigger(target, collectionKeyDependency(target, rawKey));
			trigger(target, iterateDependency);
			if (!had) trigger(target, sizeDependency);
			notifyMutation(options, rawKey, "map.set");
			return receiver;
		};
		case "delete": return (input) => {
			assertWritable(options, "delete");
			const rawKey = unwrap(input);
			if (!target.has(rawKey)) return false;
			const previous = target.get(rawKey);
			if (hasActiveTransaction()) {
				const following = followingCollectionKeys(target.keys(), rawKey);
				recordTransactionUndo(() => {
					if (!following.size) {
						target.set(rawKey, previous);
						return;
					}
					const entries = [...target.entries()];
					const before = entries.findIndex(([key]) => following.has(key));
					entries.splice(before < 0 ? entries.length : before, 0, [rawKey, previous]);
					restoreMap(target, entries);
				}, target, collectionKeyDependency(target, rawKey));
			}
			const deleted = target.delete(rawKey);
			if (deleted) {
				triggerCollectionRemoval(target, rawKey);
				notifyMutation(options, rawKey, "map.delete");
			}
			return deleted;
		};
		case "clear": return () => {
			assertWritable(options, "clear");
			if (!target.size) return void 0;
			const previous = [...target.entries()];
			if (hasActiveTransaction()) recordTransactionUndo(() => restoreMap(target, previous), target, iterateDependency);
			target.clear();
			for (const [entryKey] of previous) trigger(target, collectionKeyDependency(target, entryKey));
			trigger(target, iterateDependency);
			trigger(target, sizeDependency);
			notifyMutation(options, void 0, "map.clear");
		};
		case "keys": return () => mapIterator(target, "keys", wrap);
		case "values": return () => mapIterator(target, "values", wrap);
		case "entries":
		case Symbol.iterator: return () => mapIterator(target, "entries", wrap);
		case "forEach": return (callback, thisArg) => {
			track(target, iterateDependency);
			target.forEach((value, entryKey) => {
				const dependency = collectionKeyDependency(target, entryKey);
				callback.call(thisArg, wrap(value, dependency), wrap(entryKey), receiver);
			});
		};
		default: return Reflect.get(target, key, target);
	}
}
function reactiveSetMember(target, key, receiver, options, wrap) {
	switch (key) {
		case "has": return (input) => {
			const rawValue = unwrap(input);
			track(target, collectionKeyDependency(target, rawValue));
			return target.has(rawValue);
		};
		case "add": return (input) => {
			assertWritable(options, "add");
			const rawValue = unwrap(input);
			if (target.has(rawValue)) return receiver;
			if (hasActiveTransaction()) recordTransactionUndo(() => target.delete(rawValue), target, collectionKeyDependency(target, rawValue));
			target.add(rawValue);
			trigger(target, collectionKeyDependency(target, rawValue));
			trigger(target, iterateDependency);
			trigger(target, sizeDependency);
			notifyMutation(options, void 0, "set.add");
			return receiver;
		};
		case "delete": return (input) => {
			assertWritable(options, "delete");
			const rawValue = unwrap(input);
			if (!target.has(rawValue)) return false;
			if (hasActiveTransaction()) {
				const following = followingCollectionKeys(target.values(), rawValue);
				recordTransactionUndo(() => {
					if (!following.size) {
						target.add(rawValue);
						return;
					}
					const values = [...target.values()];
					const before = values.findIndex((value) => following.has(value));
					values.splice(before < 0 ? values.length : before, 0, rawValue);
					restoreSet(target, values);
				}, target, collectionKeyDependency(target, rawValue));
			}
			const deleted = target.delete(rawValue);
			if (deleted) {
				triggerCollectionRemoval(target, rawValue);
				notifyMutation(options, void 0, "set.delete");
			}
			return deleted;
		};
		case "clear": return () => {
			assertWritable(options, "clear");
			if (!target.size) return void 0;
			const previous = [...target.values()];
			if (hasActiveTransaction()) recordTransactionUndo(() => restoreSet(target, previous), target, iterateDependency);
			target.clear();
			for (const value of previous) trigger(target, collectionKeyDependency(target, value));
			trigger(target, iterateDependency);
			trigger(target, sizeDependency);
			notifyMutation(options, void 0, "set.clear");
		};
		case "keys":
		case "values":
		case Symbol.iterator: return () => setIterator(target, wrap);
		case "entries": return () => setEntryIterator(target, wrap);
		case "forEach": return (callback, thisArg) => {
			track(target, iterateDependency);
			target.forEach((value) => {
				const wrapped = wrap(value);
				callback.call(thisArg, wrapped, wrapped, receiver);
			});
		};
		default: return Reflect.get(target, key, target);
	}
}
function mapIterator(target, kind, wrap) {
	track(target, iterateDependency);
	return wrapIterator(target[kind](), (value) => {
		if (kind === "keys") return wrap(value);
		if (kind === "values") return wrap(value);
		const [entryKey, entryValue] = value;
		return [wrap(entryKey), wrap(entryValue, collectionKeyDependency(target, entryKey))];
	});
}
function setIterator(target, wrap) {
	track(target, iterateDependency);
	return wrapIterator(target.values(), (value) => wrap(value));
}
function setEntryIterator(target, wrap) {
	track(target, iterateDependency);
	return wrapIterator(target.values(), (value) => {
		const wrapped = wrap(value);
		return [wrapped, wrapped];
	});
}
function wrapIterator(iterator, wrap) {
	return {
		next() {
			const result = iterator.next();
			return result.done ? {
				done: true,
				value: void 0
			} : {
				done: false,
				value: wrap(result.value)
			};
		},
		[Symbol.iterator]() {
			return this;
		}
	};
}
function collectionKeyDependency(target, key) {
	let dependencies = keyDependencies.get(target);
	if (!dependencies) keyDependencies.set(target, dependencies = {
		primitives: /* @__PURE__ */ new Map(),
		objects: /* @__PURE__ */ new WeakMap()
	});
	const keys = key !== null && (typeof key === "object" || typeof key === "function") ? dependencies.objects : dependencies.primitives;
	let dependency = keys.get(key);
	if (!dependency) {
		dependency = Symbol("exact.collection.key");
		keys.set(key, dependency);
	}
	return dependency;
}
function triggerCollectionRemoval(target, value) {
	trigger(target, collectionKeyDependency(target, value));
	trigger(target, iterateDependency);
	trigger(target, sizeDependency);
}
function recordMapUndo(target, key, had, previous) {
	if (!hasActiveTransaction()) return;
	recordTransactionUndo(() => {
		if (had) target.set(key, previous);
		else target.delete(key);
	}, target, collectionKeyDependency(target, key));
}
function restoreMap(target, entries) {
	target.clear();
	for (const [key, value] of entries) target.set(key, value);
}
function restoreSet(target, values) {
	target.clear();
	for (const value of values) target.add(value);
}
function assertWritable(options, operation) {
	if (!options.readonly) return;
	options.onReadonlyWrite?.(operation);
	throw new TypeError(`Cannot call ${operation} on a readonly reactive collection`);
}
function notifyMutation(options, key, operation) {
	const propertyKey = typeof key === "string" || typeof key === "number" || typeof key === "symbol" ? key : void 0;
	try {
		options.onMutation?.(propertyKey, operation);
	} catch {}
}
/** Retains insertion-order anchors only for the lifetime of a rollback journal. */
function followingCollectionKeys(keys, removed) {
	const following = /* @__PURE__ */ new Set();
	let found = false;
	for (const key of keys) if (found) following.add(key);
	else if (key === removed || Object.is(key, removed)) found = true;
	return following;
}
//#endregion
//#region ../packages/reactive/dist/proxy/create.js
var collectionOptions = /* @__PURE__ */ new WeakMap();
/** Creates a general reactive proxy, including observable Map and Set members. */
function createReactive(value, options, parentSource) {
	const key = collectionOptionsKey(options);
	let selected = collectionOptions.get(key);
	if (!selected) {
		const created = Object.assign(Object.create(key), { __exactCollectionCacheMode: true });
		collectionOptions.set(key, created);
		selected = created;
	}
	return createReactiveBase(value, selected, parentSource, reactiveCollectionMember);
}
function collectionOptionsKey(options) {
	if (!options.readonly && !options.onReadonlyWrite && !options.onMutation && !options.passthroughKeys?.length) return defaultReactiveOptions;
	if (options.readonly && !options.onReadonlyWrite && !options.onMutation && !options.passthroughKeys?.length) return readonlyReactiveOptionsKey;
	return options;
}
//#endregion
//#region ../packages/reactive/dist/reactive.js
/** Creates a reactive proxy that tracks reads and notifies watchers when writable state changes. */
function reactive(value, options = defaultReactiveOptions, parentSource) {
	if (!isReactiveContainer(unwrap(value))) return value;
	return createReactive(value, options, parentSource);
}
//#endregion
//#region ../packages/ssr/dist/render/program-capture.js
/**
* Keeps a boundary's markup local until wrappers, routing, or render retries finish.
* Nested captures share the local mode. The outer destination is restored only after
* descendant rendering and cleanup settle, including rejection and cancellation.
*/
function captureSsrProgramOutput(context, render) {
	const sink = context.writerSink;
	if (!sink) return render();
	context.writerSink = void 0;
	return withRenderCleanup(render, () => {
		context.writerSink = sink;
	});
}
//#endregion
//#region ../packages/ssr/dist/render/prepared-fragment-enhancements.js
/**
* Buffers one prepared fragment chain while normal request-owned component execution supplies its
* contributions. Each sink retains its component until descendant output settles. No second
* component execution or DOM-shaped server tree is introduced; ordinary publication owns markers,
* resumptions, scheduled retries, and cleanup. Transparent contributors share planned hosts.
*/
function renderPreparedFragmentEnhancements(context, entries, target, parent, options, tags = /* @__PURE__ */ new Map()) {
	if (!readCompiledFragmentReceipt(target)) throw new TypeError("Prepared fragment attachment requires a resolved fragment");
	assertEnhancementSourceOrder(entries, context.enhancementCatalog ?? /* @__PURE__ */ new Map());
	const scope = createEffectScope();
	const hosts = new FragmentPresentationHosts();
	const owners = [];
	const records = [];
	const ownerInstances = /* @__PURE__ */ new Map();
	const generation = reactive({ value: 0 });
	const projections = context.preparedComponentOutputs ??= /* @__PURE__ */ new WeakMap();
	return withRenderCleanup(() => withEffectScope(scope, () => withComponentDomain(parent?.domain ?? pageComponentDomain, () => {
		let chain = createChildRangeReceipt(computed(() => {
			generation.value;
			return createCompiledFragmentPresentation(target, hosts.reconcile(owners.flatMap((owner) => owner.contribution ? [{
				owner: owner.identity,
				props: owner.contribution.props,
				declaredHostProps: owner.contribution.declaredHostProps,
				tag: owner.tag
			}] : [])).map((host) => ({
				identity: host.identity,
				tag: host.tag,
				contributions: host.owners.map((contribution) => ({
					identity: contribution.owner,
					props: contribution.props,
					owner: ownerInstances.get(contribution.owner)
				}))
			})));
		}));
		for (let index = entries.length - 1; index >= 0; index--) {
			const entry = entries[index];
			const component = context.enhancementCatalog?.get(entry.identity);
			if (!component) throw new Error(`Prepared enhancement is unavailable: ${entry.identity}`);
			const child = chain;
			chain = createCompiledComponentReceipt(component, { ...entry.props }, child);
			const receipt = readCompiledComponentReceipt(chain);
			const record = {
				identity: Symbol(entry.identity),
				tag: entry.intrinsicFragment ?? tags.get(entry.identity)
			};
			owners.unshift(record);
			records.push(receipt);
			projections.set(receipt, (content, owner) => {
				if (!content.children) throw new TypeError("Fragment contribution preparation requires ordinary prepared output");
				const contribution = readPreparedTargetOutput(content.children, child);
				record.contribution = contribution;
				ownerInstances.set(record.identity, owner);
				generation.value++;
				return { children: [createChildRangeReceipt(contribution ? createCompiledTargetReceipt(null, ...contribution.children) : content.children)] };
			});
		}
		return captureSsrProgramOutput(context, () => renderChildren(context, [createCompiledFragmentReceipt(null, chain)], parent, options, true));
	})), () => {
		for (const record of records) projections.delete(record);
		hosts.dispose();
		scope.stop();
	});
}
//#endregion
//#region ../packages/ssr/dist/render/serialized-html-operation.js
/** Dispatch key for SSR output that is already serialized and trusted by the renderer. */
var exactSerializedSsrHtmlOperation = Symbol.for("@exactjs/ssr-target-operation/serialized-html");
function executeSerializedHtml(target) {
	const html = serializedHtml.get(this);
	if (html === void 0) throw new TypeError("Serialized SSR HTML operation lost its payload");
	return target[exactSerializedSsrHtmlOperation](html);
}
function executeDeferredSerializedHtml(target) {
	const render = deferredSerializedHtml.get(this);
	if (!render) throw new TypeError("Deferred SSR HTML operation lost its renderer");
	const html = render();
	return html instanceof Promise ? html.then((value) => target[exactSerializedSsrHtmlOperation](value)) : target[exactSerializedSsrHtmlOperation](html);
}
var serializedHtml = /* @__PURE__ */ new WeakMap();
var deferredSerializedHtml = /* @__PURE__ */ new WeakMap();
/** Carries already-serialized child output through an enhancement without reparsing it. */
function createSerializedSsrHtmlOperation(html) {
	const operation = createOpaqueOperation(executeSerializedHtml);
	serializedHtml.set(operation, html);
	return operation;
}
/** Defers trusted child serialization until an enhancement has established its target layers. */
function createDeferredSerializedSsrHtmlOperation(render) {
	const operation = createOpaqueOperation(executeDeferredSerializedHtml);
	deferredSerializedHtml.set(operation, render);
	return operation;
}
//#endregion
//#region ../packages/ssr/dist/render/operation-enhancements.js
/** Renders enhancement output with request-local ownership, suspending only for pending work. */
function renderOperationEnhancements(context, enhancement, renderPlain, parent, options, renderChildren, plainOperation) {
	if (!enhancement) try {
		return renderPlain();
	} catch (error) {
		return Promise.reject(error);
	}
	if (context.writerSink) return captureSsrProgramOutput(context, () => renderEnhancementRoutes(context, enhancement, renderPlain, parent, options, renderChildren, plainOperation));
	return renderEnhancementRoutes(context, enhancement, renderPlain, parent, options, renderChildren, plainOperation);
}
/** Owns and restores routing scope for operations carrying enhancements. */
function renderEnhancementRoutes(context, enhancement, renderPlain, parent, options, renderChildren, plainOperation) {
	const isFragment = plainOperation !== void 0 && !!readCompiledFragmentReceipt(plainOperation);
	const active = isFragment || enhancement.entries.length > 1 ? enhancement.entries.filter((entry) => {
		const component = context.enhancementCatalog?.get(entry.identity);
		return component && !isExactEnhancementPassThrough(component) && entry.root === void 0;
	}) : enhancement.entries;
	if (active.length > 1) assertEnhancementSourceOrder(active, context.enhancementCatalog ?? /* @__PURE__ */ new Map());
	if (isFragment && active.length && active.every((entry) => readExactEnhancementContexts(context.enhancementCatalog.get(entry.identity))?.transparentTarget)) return renderPreparedFragmentEnhancements(context, active, plainOperation, parent, options);
	if (isFragment && active.length) return renderChildren(context, [createFragmentEnhancementChain(active, plainOperation, context.enhancementCatalog)], parent, options, true);
	if (enhancementUsesTargetReceipt(context, enhancement)) return renderEnhancementOperationChain(context, enhancement, createDeferredSerializedSsrHtmlOperation(renderPlain), parent, options, renderChildren);
	return renderLegacyEnhancementRoutes(context, enhancement, renderPlain, parent, options, renderChildren, plainOperation);
}
/** Keeps asynchronous legacy prefix routing out of direct supplied-target placement. */
async function renderLegacyEnhancementRoutes(context, enhancement, renderPlain, parent, options, renderChildren, plainOperation) {
	const routed = beginRoutes(context, enhancement);
	let output;
	try {
		const directRoot = directRootRoute(context, enhancement);
		if (directRoot && plainOperation !== void 0) {
			directRoot.consumed = true;
			return renderEnhancementOperation(context, directRoot.identity, directRoot.props, plainOperation, parent, options, renderChildren);
		}
		markNestedRootRoute(context, enhancement);
		output = plainOperation === void 0 ? await renderPlain() : await renderEnhancementOperationChain(context, enhancement, plainOperation, parent, options, renderChildren);
	} finally {
		endRoutes(context, routed.length);
	}
	if (plainOperation !== void 0) return output;
	for (const entry of [...enhancement.entries].reverse()) {
		if (entry.root !== void 0) continue;
		const route = routed.find((candidate) => candidate.identity === entry.identity);
		if (route?.consumed) continue;
		if (route?.nested) {
			output = `${await renderEnhancementComponent(context, entry.identity, entry.props, route.nestedBefore ?? "", parent, options, renderChildren)}${output}`;
			route.consumed = true;
		} else output = await renderEnhancementComponent(context, entry.identity, entry.props, output, parent, options, renderChildren);
	}
	return output;
}
async function renderEnhancementOperation(context, identity, props, operation, parent, options, renderChildren) {
	const component = enhancementComponent(context, identity);
	return renderChildren(context, [!component || isExactEnhancementPassThrough(component) ? operation : createCompiledComponentReceipt(component, { ...props }, operation)], parent, options, true);
}
function renderEnhancementOperationChain(context, enhancement, leaf, parent, options, renderChildren) {
	let chain = leaf;
	for (const entry of [...enhancement.entries].reverse()) {
		if (entry.root !== void 0) continue;
		const component = enhancementComponent(context, entry.identity);
		if (!component || isExactEnhancementPassThrough(component)) continue;
		chain = createCompiledComponentReceipt(component, { ...entry.props }, chain);
	}
	return renderChildren(context, [chain], parent, options, true);
}
async function renderEnhancementComponent(context, identity, props, html, parent, options, renderChildren) {
	const component = enhancementComponent(context, identity);
	if (!component || isExactEnhancementPassThrough(component)) return html;
	return renderChildren(context, [createCompiledComponentReceipt(component, { ...props }, createSerializedSsrHtmlOperation(html))], parent, options, true);
}
function enhancementComponent(context, identity) {
	const component = context.enhancementCatalog?.get(identity);
	if (component) return component;
	context.unavailableEnhancements ??= /* @__PURE__ */ new Set();
	if (!context.unavailableEnhancements.has(identity)) {
		context.unavailableEnhancements.add(identity);
		logFrameworkEvent("warn", "ssr", "enhancement", `Optional renderer enhancement "${identity}" is unavailable`, void 0, context.logger);
	}
}
function enhancementUsesTargetReceipt(context, enhancement) {
	return enhancement.entries.some((entry) => {
		const component = context.enhancementCatalog?.get(entry.identity);
		return !!component && !isExactEnhancementPassThrough(component) && readPreparedExactServerExecutableComponentContract(component).artifact.capabilities.includes("targets");
	});
}
//#endregion
//#region ../packages/ssr/dist/render/resource-hints.js
/** Adds one compiler-selected, build-authorized dynamic artifact to request-owned hints. */
function registerDynamicComponentPreload(context, boundaryId) {
	if (!boundaryId || context.dynamicComponentPreloads >= context.maxDynamicComponentPreloads || !context.dynamicComponentArtifacts) return;
	const artifact = artifactFor(context.dynamicComponentArtifacts, boundaryId);
	if (!validArtifact(artifact)) return;
	const key = `modulepreload:${artifact.url}:${artifact.integrity ?? ""}`;
	if (context.reactResourceKeys?.has(key)) return;
	(context.reactResourceKeys ??= /* @__PURE__ */ new Set()).add(key);
	context.dynamicComponentPreloads++;
	const attributes = htmlAttributes(artifact);
	(context.reactResourceHints ??= []).push(`<link rel="modulepreload" href="${escapeAttr(artifact.url)}"${attributes}/>`);
	const link = linkHeader(artifact);
	(context.resourceLinkHeaders ??= []).push(link);
	context.onEarlyHints?.(Object.freeze([link]));
}
function artifactFor(artifacts, id) {
	const map = artifacts;
	return typeof map.get === "function" ? map.get(id) : artifacts[id];
}
function validArtifact(value) {
	if (!value?.authorized || !value.immutable || !safeUrl(value.url)) return false;
	return value.integrity === void 0 || /^[A-Za-z0-9-]+-[A-Za-z0-9+/=]+(?:\s+[A-Za-z0-9-]+-[A-Za-z0-9+/=]+)*$/.test(value.integrity);
}
function safeUrl(url) {
	return !/[\u0000-\u0020\u007f]/.test(url) && (url.startsWith("/") && !url.startsWith("//") || url.startsWith("https://"));
}
function htmlAttributes(artifact) {
	return [
		artifact.integrity ? ` integrity="${escapeAttr(artifact.integrity)}"` : "",
		artifact.crossOrigin ? ` crossorigin="${artifact.crossOrigin}"` : "",
		artifact.referrerPolicy ? ` referrerpolicy="${artifact.referrerPolicy}"` : ""
	].join("");
}
function linkHeader(artifact) {
	return [
		`<${artifact.url}>`,
		"rel=modulepreload",
		artifact.integrity ? `integrity="${artifact.integrity}"` : "",
		artifact.crossOrigin ? `crossorigin=${artifact.crossOrigin}` : "",
		artifact.referrerPolicy ? `referrerpolicy=${artifact.referrerPolicy}` : ""
	].filter(Boolean).join("; ");
}
//#endregion
//#region ../packages/ssr/dist/render/bound-child-range.js
/** Serializes a retained text/range target with its request-local namespace binding. */
function renderBoundChildRange(context, operation, data, parent, options, ancestor, renderChildren, direct = false) {
	const dynamic = "dynamicComponent" in data && !!data.dynamicComponent;
	if (dynamic && data.markerId) registerDynamicComponentPreload(context, data.markerId);
	return renderOperationEnhancements(context, boundOperationEnhancement(context, operation), () => {
		const children = dynamic ? [] : normalizeRenderResult(unwrap(data.value));
		return markerPair(context, direct ? "" : data.markerId ? `dynamic:${exactMarkerId(data.markerId)}` : markerId(context, "dynamic"), () => renderChildren(context, children, parent, options, ancestor));
	}, parent, options, renderChildren, operation);
}
//#endregion
//#region ../packages/ssr/dist/render/document-doctype.js
/** Claims the document declaration and serializes its authored external identifiers. */
function renderDocumentDoctype(context, declaration) {
	if (!context.documentProbe || context.documentDoctypeSeen || context.hostStack.length) throw new Error("A doctype must occur exactly once before the root html element");
	context.documentDoctypeSeen = true;
	const external = declaration.publicId !== void 0 ? ` PUBLIC "${declaration.publicId}" "${declaration.systemId}"` : declaration.systemId !== void 0 ? ` SYSTEM "${declaration.systemId}"` : "";
	return `<!doctype ${declaration.name ?? "html"}${external}>`;
}
//#endregion
//#region ../packages/ssr/dist/render/component-props.js
/** Resolves pending values needed by component initialization while preserving planned task-input sources. */
function prepareComponentProps(props, deferredTaskProps, options) {
	let resolved;
	let pending;
	for (const key in props) {
		if (!Object.hasOwn(props, key) || deferredTaskProps?.includes(key)) continue;
		const value = props[key];
		if (value === null || typeof value !== "object" && typeof value !== "function") continue;
		const source = serverComponentDependencyForValue(value) ?? plannedContinuationDependency(value);
		if (!source) continue;
		const snapshot = source.read();
		if (snapshot.status === "pending") {
			(pending ??= []).push(availableSnapshot(source, options.signal).then((available) => [key, settledValue(key, available)]));
			continue;
		}
		if (!resolved) resolved = { ...props };
		resolved[key] = settledValue(key, snapshot);
	}
	if (pending) return Promise.all(pending).then((entries) => {
		const output = resolved ?? { ...props };
		for (const [key, value] of entries) output[key] = value;
		return resumeSsrWork(options, () => output);
	});
	return resolved ?? props;
}
function settledValue(key, snapshot) {
	if (snapshot.status === "failed") throw snapshot.error;
	if (snapshot.status === "cancelled") throw snapshot.reason ?? /* @__PURE__ */ new Error(`Component prop ${key} was cancelled before setup`);
	if (snapshot.status !== "available") throw new Error(`Component prop ${key} did not settle`);
	return snapshot.value;
}
function availableSnapshot(source, signal) {
	return new Promise((resolve, reject) => {
		if (signal?.aborted) {
			reject(signal.reason);
			return;
		}
		const subscription = {};
		let settled = false;
		const finish = () => {
			if (settled) return;
			const snapshot = source.read();
			if (snapshot.status === "pending") return;
			settled = true;
			subscription.current?.[Symbol.dispose]();
			signal?.removeEventListener("abort", abort);
			resolve(snapshot);
		};
		const abort = () => {
			settled = true;
			subscription.current?.[Symbol.dispose]();
			reject(signal?.reason);
		};
		signal?.addEventListener("abort", abort, { once: true });
		subscription.current = source.subscribe(finish);
		if (settled) subscription.current[Symbol.dispose]();
		finish();
	});
}
//#endregion
//#region ../packages/ssr/dist/render/resumption-boundary-capability.js
var capabilityName$3 = "resumption-boundary";
/** Installs resumption publication only for compiler artifacts that require it. */
function registerResumptionBoundaryCapability(next) {
	ssrCapabilities[capabilityName$3] = next;
}
/** Wraps a compiler-proven resumable component without reading its contract again. */
function renderPreparedResumableComponentBoundary(context, id, name, html, props, resumptions) {
	const capability = ssrCapabilities[capabilityName$3];
	return capability?.(context, id, name, html, props, resumptions) ?? finalizedMarkerPair(context, id, html);
}
//#endregion
//#region ../packages/ssr/dist/render/direct-component-output.js
/** Publishes a direct component from compiler-projected server facts only. */
function directComponentHtml(context, html, props, publication, boundary) {
	const resumable = publication?.kind === "resumption";
	if (boundary.documentProbe && context.documentRootSeen || boundary.omitRootBoundary || boundary.omitCompilerOwnedBoundary && (!resumable || boundary.capturesResumptions)) return html;
	const needsResumption = boundary.hasComponentAncestor && resumable && !boundary.capturesResumptions;
	if (!needsResumption && !context.markers) return html;
	const componentId = formatMarkerId("component", boundary.componentOrdinal, boundary.componentName, boundary.componentKey);
	if (!needsResumption) return finalizedMarkerPair(context, componentId, html);
	return renderPreparedResumableComponentBoundary(context, componentId, publication.name, html, props);
}
//#endregion
//#region ../packages/ssr/dist/render/receipt-target-contributions.js
/** Applies each active operation-owned target layer to the first intrinsic it reaches. */
function consumeTargetReceiptLayers(context, props) {
	const layers = context.targetReceiptLayers;
	if (!layers?.length) return props;
	let effective = props;
	for (let index = layers.length - 1; index >= 0; index--) {
		const layer = layers[index];
		if (layer.consumed) continue;
		layer.consumed = true;
		effective = composeTargetProps(effective, layer.props);
	}
	return effective;
}
/** Captures active target-layer consumption before a scheduled render attempt. */
function checkpointTargetReceiptLayers(context) {
	return (context.targetReceiptLayers ?? []).map((layer) => layer.consumed);
}
/** Restores target-layer consumption when a scheduled render attempt is retried or rejected. */
function restoreTargetReceiptLayers(context, checkpoint) {
	const layers = context.targetReceiptLayers ?? [];
	for (let index = 0; index < checkpoint.length && index < layers.length; index++) layers[index].consumed = checkpoint[index];
}
//#endregion
//#region ../packages/ssr/dist/render/render-program-attributes.js
/** Renders captured root attributes, reconstructing scalar inputs only for target composition. */
function renderSsrRootAttributes(context, value, tag, staticAttributes, accounted = false) {
	if (staticAttributes?.[3]) {
		if (!context.targetReceiptLayers?.some((layer) => !layer.consumed)) {
			const prefix = staticAttributes[0];
			if (accounted) context.outputSink?.account(prefix);
			const attribute = staticAttributes[2][0];
			return prefix + renderCompiledNativeAttribute(value, attribute[0], attribute[1], attribute[2], tag, context, accounted);
		}
		value = staticAttributes[3](value);
	}
	const props = value !== null && typeof value === "object" ? value : {};
	const effective = consumeTargetReceiptLayers(context, props);
	if (effective === props && staticAttributes?.[2]) {
		const prefix = staticAttributes[0] ?? "";
		if (accounted) context.outputSink?.account(prefix);
		return `${prefix}${renderCompiledNativeAttributes(props, staticAttributes[2], tag, context, accounted)}`;
	}
	const html = renderAttrs(effective, false, tag, context, effective === props ? staticAttributes?.[1] : void 0);
	const rendered = effective === props ? `${staticAttributes?.[0] ?? ""}${html}` : html;
	if (accounted) context.outputSink?.account(rendered);
	return rendered;
}
//#endregion
//#region ../packages/ssr/dist/render/render-program-values.js
/** Sentinel returned when a generated writer must reject a slot during its preparation prefix. */
var unpreparedSsrValue = Symbol("exact.ssr.unprepared");
/** Prepares one scalar text slot without admitting structural or pending values. */
function prepareSsrText(invocation, index) {
	const value = unwrap(invocation.eagerValues[index]);
	return value instanceof Promise || typeof value === "object" && value !== null ? unpreparedSsrValue : value;
}
/** Prepares one arbitrary child slot after its request-local source settles. */
function prepareSsrChild(invocation, index) {
	const value = unwrap(invocation.eagerValues[index]);
	return value instanceof Promise ? unpreparedSsrValue : value;
}
/** Prepares one general component slot while preserving its existing reference representation. */
function prepareSsrComponent(invocation, index) {
	const value = unwrap(invocation.eagerValues[index]);
	if (value instanceof Promise) return unpreparedSsrValue;
	return readServerComponentReference(value) ?? (readServerSlotReceipt(value) ? [value] : void 0) ?? unpreparedSsrValue;
}
/** Prepares finalized props for a compiler-selected component callable. */
function prepareSsrComponentProps(invocation, index) {
	const value = unwrap(invocation.eagerValues[index]);
	return value instanceof Promise || value !== null && typeof value !== "object" ? unpreparedSsrValue : value;
}
/** Prepares one host attribute slot without awaiting work during ordered publication. */
function prepareSsrAttribute(invocation, index) {
	const value = unwrap(invocation.eagerValues[index]);
	return value instanceof Promise ? unpreparedSsrValue : value;
}
/** Reserves compiler-owned identities and enforces the conservative character bound. */
function beginSsrProgram(context, nodeCount, slotCount, staticCharacters) {
	context.nextId += nodeCount;
	countSsrNodes(context, nodeCount - 1 + slotCount);
	if (staticCharacters > context.maxOutputBytes) throw new SsrOutputLimitError(context.maxOutputBytes);
}
//#endregion
//#region ../packages/ssr/dist/render/program-writer-output.js
/**
* Executes a caller-output writer within document ancestry and prepared-sibling ownership.
* The invocation is passed explicitly so callers can reuse an invoker across program positions.
* Shared destinations remain request-owned. Captured programs retain local text through the
* same writer operations, without exposing output before enhancement or retry boundaries commit.
*/
function renderProgramWriter(context, host, invocation, invoke, render, prepareReferences) {
	const local = context.writerSink ? void 0 : new CapturedProgramSink(context);
	const output = {
		context,
		sink: context.writerSink ?? local,
		target: typeof render === "function" ? void 0 : render,
		render: typeof render === "function" ? render : renderWriterTargetSegment,
		prepareReferences: typeof render === "function" ? prepareReferences : prepareWriterTargetReferences
	};
	if (host && (context.textProjectionDepth !== void 0 || host === "html" || host === "head" || host === "body" || context.documentRootSeen && context.hostStack.at(-1) === "html")) {
		const entered = enterHostTag(context, host);
		return withRenderCleanup(() => {
			if (entered.prefix) {
				output.sink.write(entered.prefix);
				output.sink.captureDocumentBoundary?.();
			}
			return mapRenderValue(output.sink.ready(), () => mapRenderValue(executeProgramWriter(output, invoke, local, invocation), (html) => mapRenderValue(host === "head" ? output.sink.flush("head") : void 0, () => html)));
		}, () => leaveHost(context, entered.tag));
	}
	if (host && !context.hostStack.length) claimRootText(context);
	return executeProgramWriter(output, invoke, local, invocation);
}
/** Installed only for target-backed output; the target retains the original child owner. */
function renderWriterTargetSegment(value) {
	return this.target.renderProgramSegment(value);
}
/** Preparation belongs to this output invocation even when its traversal target is shared. */
function prepareWriterTargetReferences(values) {
	return this.target.prepareProgramReferences(values);
}
/** Allocates completion callbacks only for pending work or owned sibling cleanup. */
function executeProgramWriter(output, invoke, local, invocation) {
	let completed;
	try {
		completed = invoke(output, invocation);
	} catch (error) {
		return failProgramWriter(output, error);
	}
	return completed instanceof Promise ? completed.then((value) => completeProgramWriter(output, value, local), (error) => failProgramWriter(output, error)) : completeProgramWriter(output, completed, local);
}
/** Validates ownership before releasing unused prepared siblings, preserving primary errors. */
function completeProgramWriter(output, completed, local) {
	if (completed !== output) return failProgramWriter(output, /* @__PURE__ */ new TypeError("Native server writer rejected its caller-owned output"));
	const html = local?.value ?? "";
	const preparation = output.preparation;
	return preparation ? withRenderCleanup(() => html, () => Promise.resolve(preparation[Symbol.asyncDispose]())) : html;
}
/** Keeps cleanup failures secondary when a generated writer rejects or throws. */
function failProgramWriter(output, error) {
	const preparation = output.preparation;
	if (!preparation) throw error;
	return withRenderCleanup(() => {
		throw error;
	}, () => Promise.resolve(preparation[Symbol.asyncDispose]()));
}
/** Local capture owns text only; the enclosing request retains exact byte validation. */
var CapturedProgramSink = class {
	context;
	value = "";
	constructor(context) {
		this.context = context;
	}
	/** Retains routed prefixes before appending the next completed span. */
	write(html) {
		this.value = appendBoundedHtml(this.context, captureNestedEnhancementStringPrefix(this.context, this.value), html);
	}
	/** Local text collection introduces no transport pressure. */
	ready() {}
	/** Captured markup stays private until its owning boundary commits. */
	flush() {}
};
//#endregion
//#region ../packages/ssr/dist/render/scalar-props-proof.js
var scalarPropsProof = Symbol.for("exact.ssr.scalar-props");
var scalarPropsAttempted = Symbol.for("exact.ssr.scalar-props-attempted");
/** Reports previous issuance, including failed proofs whose inputs may already be exposed. */
function hasScalarPropsAttempt(invocation) {
	return !!invocation[scalarPropsAttempted];
}
/**
* Retains a compiler proof for a fresh, private, entirely scalar prop bag.
* The compiler must establish the complete field set and check actual values. Types alone are
* insufficient. Normalization that replaced the input bag invalidates this proof immediately.
* Only the first attempt in one prepared program invocation may issue a proof, even if its
* predicate fails; later visits may observe inputs exposed by an earlier component execution.
*/
function markScalarPropsProof(reference, props, invocation, key, privateProps = true) {
	const owner = invocation;
	if (owner[scalarPropsAttempted]) return;
	owner[scalarPropsAttempted] = true;
	if (!privateProps || reference.props !== props) return;
	const value = key === null ? null : reference.props[key];
	if (value === null || typeof value !== "object" && typeof value !== "function") reference[scalarPropsProof] = reference.props;
}
/**
* Consumes a proof before component execution can expose its inputs. Replacement, retries, or
* reuse must take ordinary preparation after this single attempt, even when the attempt fails.
*/
function consumeScalarPropsProof(reference, props) {
	const prepared = reference;
	const proof = prepared[scalarPropsProof];
	if (proof === void 0) return false;
	prepared[scalarPropsProof] = void 0;
	return proof === props && reference.props === props;
}
//#endregion
//#region ../packages/ssr/dist/render/render-program.js
/** Executes a compiler-closed invocation directly into caller-owned output. */
function renderPreparedSsrProgram(context, invocation, render, prepareReferences) {
	if (invocation.deferredValues) {
		const { host, read } = invocation.deferredValues;
		return mapRenderValue(readServerComponentOutputForHost(host, read), (eagerValues) => renderPreparedSsrProgram(context, {
			...invocation,
			eagerValues,
			deferredValues: void 0
		}, render, prepareReferences));
	}
	if (context.reactMarkup) throw new TypeError("React markup cannot execute a native eXact render program");
	if (!invocation.program.ssr) throw new TypeError(`Client-only render program ${invocation.program.id} cannot execute during native SSR`);
	return renderProgramWriter(context, invocation.program.ssrHost, invocation, invokePreparedSsrProgram, render, prepareReferences);
}
/** Invokes a validated program without allocating a wrapper closure for each traversal position. */
function invokePreparedSsrProgram(output, invocation) {
	const writer = invocation.program.ssr;
	return writer(generatedSsrOperations, output.context, invocation, output);
}
/**
* Supplies stateless serialization operations to one compiler-generated server lane.
*
* A compiler-emitted preparation prefix validates slots before generated writes begin. Invalid
* preparation rejects the invocation; runtime helpers do not reconstruct a fallback tree from an
* operation table. The caller owns document ancestry and cleanup around the invocation.
*/
var generatedSsrOperations = Object.freeze({
	unprepared: unpreparedSsrValue,
	promise: Promise,
	reference(component, props, scalarPropKey, proofInvocation) {
		const privateProps = proofInvocation !== void 0 && !("key" in Object.prototype) && !("__exactEnhancements" in Object.prototype);
		const reference = privateProps && scalarPropKey !== void 0 && !hasScalarPropsAttempt(proofInvocation) ? createPreparedServerComponentReferenceFromPlainProps(component, props) : createPreparedServerComponentReference(component, props);
		if (proofInvocation && scalarPropKey !== void 0) markScalarPropsProof(reference, props, proofInvocation, scalarPropKey, privateProps);
		return reference;
	},
	prepareText: prepareSsrText,
	prepareChild: prepareSsrChild,
	prepareComponent: prepareSsrComponent,
	prepareComponentProps: prepareSsrComponentProps,
	prepareAttribute: prepareSsrAttribute,
	begin(opaqueContext, nodeCount, slotCount, staticCharacters, _staticBytes) {
		beginSsrProgram(opaqueContext, nodeCount, slotCount, staticCharacters);
	},
	static(output, value, bodyCloseOffset) {
		if (bodyCloseOffset !== void 0) {
			const target = output;
			if (target.context.documentRootSeen && target.context.hostStack.at(-1) === "body" && target.sink.captureDocumentBoundary) {
				if (!Number.isSafeInteger(bodyCloseOffset) || bodyCloseOffset < 0 || value.slice(bodyCloseOffset) !== "</body>") throw new TypeError("Invalid compiler body-closing boundary");
				if (bodyCloseOffset) target.sink.write(value.slice(0, bodyCloseOffset));
				target.sink.captureDocumentBoundary();
				target.sink.write(value.slice(bodyCloseOffset));
				return;
			}
		}
		if (value !== "") appendProgramText(output, value);
	},
	text(opaqueContext, output, value, id, characters, markerless, prefix = "", suffix = "") {
		const context = opaqueContext;
		const rendered = value === null || value === void 0 || value === false || value === true ? "" : escapeText(String(value));
		const dynamic = context.markers && !markerless ? `<!--x:${id}-->${rendered}<!--/x:${id}-->` : rendered;
		const html = `${prefix}${dynamic}${suffix}`;
		const nextCharacters = characters + dynamic.length;
		if (nextCharacters > context.maxOutputBytes) throw new SsrOutputLimitError(context.maxOutputBytes);
		if (html !== "") appendProgramText(output, html);
		return nextCharacters;
	},
	child(opaqueContext, output, value, id, characters) {
		return writeProgramChild(opaqueContext, output, normalizeRenderResult(value), id, characters);
	},
	keyedChild(output, value) {
		const target = output;
		return mapRenderValue(writeProgramChild(target.context, target, normalizeRenderResult(value), "", 0, true), () => void 0);
	},
	component(opaqueContext, output, value, id, characters, markerless) {
		return writeProgramChild(opaqueContext, output, value, id, characters, markerless);
	},
	directComponent(opaqueContext, output, component, props, id, characters, markerless) {
		const reference = createPreparedServerComponentReference(component, props);
		return generatedSsrOperations.component(opaqueContext, output, reference, id, characters, markerless);
	},
	attribute(opaqueContext, output, value, name, tag, characters) {
		const context = opaqueContext;
		const html = renderNativeAttribute(value, name, tag, context);
		const nextCharacters = characters + html.length;
		if (nextCharacters > context.maxOutputBytes) throw new SsrOutputLimitError(context.maxOutputBytes);
		if (html !== "") appendProgramText(output, html);
		return nextCharacters;
	},
	compiledAttribute(opaqueContext, output, value, kind, name, attributeName, tag, characters) {
		const context = opaqueContext;
		const html = renderCompiledNativeAttribute(value, kind, name, attributeName, tag, context);
		const nextCharacters = characters + html.length;
		if (nextCharacters > context.maxOutputBytes) throw new SsrOutputLimitError(context.maxOutputBytes);
		if (html !== "") appendProgramText(output, html);
		return nextCharacters;
	},
	attributes(opaqueContext, output, value, tag, characters) {
		const context = opaqueContext;
		const html = renderAttrs(value !== null && typeof value === "object" ? value : {}, false, tag, context);
		const nextCharacters = characters + html.length;
		if (nextCharacters > context.maxOutputBytes) throw new SsrOutputLimitError(context.maxOutputBytes);
		if (html !== "") appendProgramText(output, html);
		return nextCharacters;
	},
	rootOpening(opaqueContext, output, value, tag, prefix, suffix, characters, staticAttributes) {
		const context = opaqueContext;
		const rendered = renderSsrRootAttributes(context, value, tag, staticAttributes);
		const nextCharacters = characters + rendered.length;
		if (nextCharacters > context.maxOutputBytes) throw new SsrOutputLimitError(context.maxOutputBytes);
		appendProgramText(output, `${prefix}${rendered}${suffix}`);
		return nextCharacters;
	}
});
/** Publishes one completed span without allocating a deferred segment array. */
function appendProgramText(output, html) {
	output.sink.write(html);
}
//#endregion
//#region ../packages/ssr/dist/render/bound-program-output.js
/** Applies an already selected namespace binding around a compiler-closed intrinsic program. */
function renderBoundProgram(context, program, target, parent, options, renderChildren, selectedEntries) {
	const enhancement = selectedEntries ? combineBoundEnhancementEntries(selectedEntries, program.enhancement) : boundOperationEnhancement(context, program, program.enhancement);
	if (!enhancement) return renderPreparedSsrProgram(context, program, target);
	return renderOperationEnhancements(context, enhancement, () => renderPreparedSsrProgram(context, program, target), parent, options, renderChildren);
}
//#endregion
//#region ../packages/ssr/dist/render/direct-component-content.js
/** Classifies raw component output before generic child normalization loses its server ABI. */
function readDirectSsrContent(value) {
	const program = readPreparedServerRenderProgram(value);
	return program ? { program } : { children: normalizeRenderResult(value) };
}
/**
* Binds the selected owner to this component's execution before traversing its content.
* Descendants own separate executions. Scheduled retries await prior output and retain the same
* owner, so suspended programs never observe another component's owner through this target.
* Selected entries bypass routing tables only for an unprojected, compiler-closed intrinsic root.
*/
function renderDirectSsrContent(execution, content, owner, selectedEntries) {
	execution.renderOwner = owner;
	if (execution.prepareOutput) content = execution.prepareOutput(content, owner);
	if (content.children) return execution.renderChildren(content.children, owner);
	return renderBoundProgram(execution.context, content.program, execution, owner, execution.options, (_context, children, parent) => execution.renderChildren(children, parent), selectedEntries);
}
//#endregion
//#region ../packages/ssr/dist/render/async-scheduler.js
/** Request-owned FIFO scheduler for compiler-proven SSR work. */
var AsyncSsrScheduler = class {
	limit;
	active = 0;
	queued = [];
	/** Normalizes the request limit to the supported range of one through 32. */
	constructor(limit) {
		this.limit = typeof limit === "number" && Number.isSafeInteger(limit) && limit > 0 ? Math.min(limit, 32) : 4;
	}
	/** Starts ready work immediately when a slot is free; queued work waits for its FIFO permit. */
	async run(work, signal) {
		if (signal?.aborted) throw signal.reason ?? new DOMException("SSR render aborted", "AbortError");
		const pending = this.acquire(signal);
		if (pending) await pending;
		try {
			return await work();
		} finally {
			this.release();
		}
	}
	/** Temporarily yields a held permit while nested scheduled work settles. */
	async suspend(work) {
		this.release();
		try {
			return await work();
		} finally {
			const pending = this.acquire();
			if (pending) await pending;
		}
	}
	acquire(signal) {
		if (this.active < this.limit) {
			this.active++;
			return;
		}
		return new Promise((resolve, reject) => {
			let settled = false;
			const start = () => {
				if (settled) return;
				settled = true;
				signal?.removeEventListener("abort", abort);
				this.active++;
				resolve();
			};
			const abort = () => {
				if (settled) return;
				settled = true;
				const index = this.queued.indexOf(start);
				if (index >= 0) this.queued.splice(index, 1);
				reject(signal?.reason ?? new DOMException("SSR render aborted", "AbortError"));
			};
			this.queued.push(start);
			signal?.addEventListener("abort", abort, { once: true });
			if (signal?.aborted) abort();
		});
	}
	release() {
		if (this.active <= 0) throw new Error("eXact async SSR scheduler released an unowned slot");
		this.active--;
		this.queued.shift()?.();
	}
};
//#endregion
//#region ../packages/ssr/dist/render/context-publication-dependencies.js
var dependencies = /* @__PURE__ */ new WeakMap();
/**
* Capturing shared context requires its producer's completed continuation identity as well as its
* value. A context write can precede task completion; publishing it early would replay the task
* during hydration. Only writers of compiler-selected captured contexts become dependencies.
*/
function contextPublicationDependencies(contract) {
	const contexts = contract.resumption?.contexts;
	if (!contexts?.length) return void 0;
	let required = dependencies.get(contract);
	if (!required) {
		required = new Set(contract.continuations.filter((continuation) => continuation.contextWrites?.some((name) => contexts.includes(name))).map((continuation) => continuation.id));
		dependencies.set(contract, required);
	}
	return required;
}
//#endregion
//#region ../packages/ssr/dist/render/direct-component-support.js
/** Creates the request-local receiver shared by synchronous and scheduled direct lanes. */
function createDirectSsrComponentFrame() {
	return {
		state: {},
		map: directSsrMap
	};
}
/** Adapts a compiler-linked context frame to the renderer's logical ownership boundary. */
function directSsrContextOwner(frame) {
	return frame;
}
/** Executes component work in the request's error and inspection domain when present. */
function inComponentDomain(context, work) {
	return context.componentDomain ? withComponentDomain(context.componentDomain, work) : work();
}
/** Materializes a compiler-generated keyed-list fallback without retained registration. */
function directSsrMap(collection, key, render, id) {
	return createServerList([...unwrap(collection)].map((item) => createPreparedServerKeyedChild(render(item), key(item))), id);
}
/** Immutable value-free receiver shared only by compiler-proven stateless server artifacts. */
var statelessDirectSsrComponentFrame = Object.freeze({
	state: Object.freeze({}),
	map: directSsrMap
});
//#endregion
//#region ../packages/core/dist/server/component/direct-server-context-api.js
var requestErrorContexts = /* @__PURE__ */ new WeakMap();
var nextServerErrorId = 1;
/** Reports whether a direct server frame can resolve a context without allocating its value. */
function hasDirectServerContext(instance, ambientContexts, token) {
	for (let cursor = instance.parent; cursor; cursor = cursor.parent) if (cursor.contexts.has(token.id)) return true;
	return ambientContexts?.has(token.id) === true || token.id === LoggerContext.id || token.id === ErrorContext.id;
}
/** Resolves direct server context values without constructing client reactive ownership. */
function getDirectServerContext(instance, ambientContexts, token) {
	for (let cursor = instance.parent; cursor; cursor = cursor.parent) if (cursor.contexts.has(token.id)) return cursor.contexts.get(token.id);
	if (ambientContexts?.has(token.id)) return ambientContexts.get(token.id);
	if (token.id === LoggerContext.id) return defaultConsoleLogger;
	if (token.id === ErrorContext.id) return requestErrorContext(instance.domain);
	throw new Error(`Context "${token.description}" was not provided`);
}
/** Publishes a raw request-local value; direct SSR has no later reactive observation pass. */
function setDirectServerContext(instance, token, value) {
	if (token.id === LoggerContext.id) markComponentDomainLoggerOverride(instance.domain);
	instance.contexts.set(token.id, value);
}
function requestErrorContext(domain) {
	let context = requestErrorContexts.get(domain);
	if (context) return context;
	const errors = [];
	context = {
		errors,
		report(error, options = {}) {
			const report = isErrorReport(error) ? error : createDirectServerErrorReport(error, options);
			errors.push(report);
			if (errors.length > 100) errors.splice(0, errors.length - 100);
			return report;
		},
		clear(error) {
			const id = typeof error === "string" ? error : error.id;
			const index = errors.findIndex((item) => item.id === id);
			if (index >= 0) errors.splice(index, 1);
		},
		clearAll() {
			errors.splice(0, errors.length);
		}
	};
	requestErrorContexts.set(domain, context);
	return context;
}
function createDirectServerErrorReport(error, options) {
	return {
		id: `se${nextServerErrorId++}`,
		error,
		source: options.source ?? "component",
		component: options.component,
		phase: options.phase
	};
}
function isErrorReport(value) {
	return !!value && typeof value === "object" && "id" in value && "error" in value && "source" in value;
}
//#endregion
//#region ../packages/ssr/dist/runtime/direct-context-frame.js
/** Constructs the request-local frame emitted only for a context-bearing direct component. */
var createDirectSsrContextFrame = (context, type, componentId, parent) => {
	const frame = createDirectSsrComponentFrame();
	const contexts = /* @__PURE__ */ new Map();
	const contextTokens = /* @__PURE__ */ new Map();
	const owner = Object.assign(frame, {
		type,
		id: componentId,
		mounted: false,
		parent,
		domain: context.componentDomain,
		ambientContexts: context.componentContexts,
		contexts,
		contextTokens,
		hasContext(token) {
			contextTokens.set(token.id, token);
			return hasDirectServerContext(owner, owner.ambientContexts, token);
		},
		getContext(token) {
			contextTokens.set(token.id, token);
			return getDirectServerContext(owner, owner.ambientContexts, token);
		},
		setContext(token, value) {
			contextTokens.set(token.id, token);
			setDirectServerContext(owner, token, value);
		}
	});
	return owner;
};
//#endregion
//#region ../packages/ssr/dist/render/direct-frame-selection.js
/** Constructs the request-owned frame selected by immutable component capabilities. */
function createSelectedDirectSsrFrame(context, contract, parent) {
	const artifact = contract.artifact;
	const server = artifact.execution;
	const frame = (artifact.capabilities.includes("contexts") ? createDirectSsrContextFrame : server.frame ?? createDirectSsrComponentFrame)(context, artifact.instantiate, artifact.id, parent);
	if (context.onDirectComponentCreated || context.onDirectComponentRendered) Object.assign(frame, {
		parent,
		type: artifact.instantiate,
		id: artifact.id,
		domain: context.componentDomain,
		mounted: false,
		contexts: "contexts" in frame ? frame.contexts : /* @__PURE__ */ new Map(),
		ambientContexts: context.componentContexts
	});
	return frame;
}
/** Resolves logical ownership without projecting a temporary frame/owner pair. */
function selectedDirectSsrOwner(context, contract, frame, parent) {
	return context.onDirectComponentCreated || context.onDirectComponentRendered || contract.artifact.capabilities.includes("contexts") || contract.artifact.execution.frame ? directSsrContextOwner(frame) : parent;
}
//#endregion
//#region ../packages/ssr/dist/render/direct-component-scheduling.js
/**
* Constructs compiler-closed scheduled setup on a request-local frame. Task activations begin
* immediately, allowing the renderer to discover and start descendant work before awaiting the
* current component's blocking generations.
*/
function createDirectScheduledSsrComponent(context, blueprint, rawProps, parent, options) {
	const server = blueprint.contract.artifact.execution;
	if (server?.lane !== "direct" || server.classification !== "scheduled" || !server.render) return void 0;
	const preparedProps = prepareComponentProps(rawProps, server.deferredTaskProps, options);
	return preparedProps && typeof preparedProps.then === "function" ? Promise.resolve(preparedProps).then((props) => constructDirectScheduledSsrComponent(context, blueprint, props, parent, options)) : constructDirectScheduledSsrComponent(context, blueprint, preparedProps, parent, options);
}
/**
* Issues compiler-proven scheduled siblings before their serial HTML positions are written.
* Accepts ordered program values directly so callers need not allocate a filtered reference list.
* The returned boundary releases only frames that later rendering did not consume.
*/
function prepareDirectScheduledSsrComponentReferences(context, values, parent, options) {
	let prepared;
	for (const value of values) {
		if (typeof value === "string" || Array.isArray(value)) continue;
		const reference = value;
		if (context.preparedDirectScheduledComponents?.has(reference)) continue;
		let created;
		try {
			const contract = receiptExecutionContract(reference);
			if (contract.artifact.execution?.classification !== "scheduled") continue;
			created = createDirectScheduledSsrComponent(context, {
				componentId: contract.artifact.id,
				contract
			}, serverComponentProps(reference), parent, options);
		} catch (error) {
			created = Promise.reject(error);
		}
		if (!created) continue;
		const record = {
			component: created,
			consumed: false,
			reference
		};
		(prepared ??= []).push(record);
		(context.preparedDirectScheduledComponents ??= /* @__PURE__ */ new WeakMap()).set(reference, record);
	}
	const owned = prepared;
	return owned ? { [Symbol.asyncDispose]: () => disposePrepared(context, owned) } : void 0;
}
function constructDirectScheduledSsrComponent(context, blueprint, props, parent, options) {
	const server = blueprint.contract.artifact.execution;
	const frame = createSelectedDirectSsrFrame(context, blueprint.contract, parent);
	const owner = selectedDirectSsrOwner(context, blueprint.contract, frame, parent);
	const lifecycle = server.lifecycle;
	let renderedVersion = -1;
	const changed = () => renderedVersion !== execution.blockingVersion;
	const drain = () => {
		const pending = settleSsrReadiness(execution, options, context.maxTaskPasses);
		return pending instanceof Promise ? pending.then(changed) : changed();
	};
	const execution = createServerComponentExecutionFrame(frame, {
		...server.streamingDocument ? { prepareOutput(read) {
			const pending = options.streamingScheduledComponents && !options.settleDocumentShell ? void 0 : drain();
			const complete = () => {
				renderedVersion = execution.blockingVersion;
				return execution.run(() => inComponentDomain(context, read));
			};
			return pending instanceof Promise ? pending.then(complete) : complete();
		} } : {},
		publicationDependencies: options.resumptionCapture ? contextPublicationDependencies(blueprint.contract) : void 0,
		runTask: (work) => (context.asyncScheduler ??= new AsyncSsrScheduler(options.maxAsyncSsrConcurrency)).run(work, options.signal)
	});
	let render;
	try {
		render = execution.run(() => inComponentDomain(context, () => server.render.call(frame, props)));
	} catch (error) {
		return disposeFailedDirectScheduledConstruction(execution, frame, lifecycle, error);
	}
	if (typeof render !== "function") return disposeFailedDirectScheduledConstruction(execution, frame, lifecycle, /* @__PURE__ */ new TypeError("Compiled scheduled server component did not return its render function"));
	return Object.freeze({
		owner,
		...lifecycle ? { lifetime: {
			frame,
			lifecycle
		} } : {},
		props,
		snapshot: {
			componentId: blueprint.componentId,
			contract: blueprint.contract,
			host: frame,
			state: frame.state,
			props
		},
		render: () => {
			renderedVersion = execution.blockingVersion;
			const started = lifecycle ? performanceNow$1() : 0;
			const issued = renderIssuedServerComponentChildren(context, options, () => inComponentDomain(context, () => render()), owner);
			lifecycle?.rendered(frame, performanceNow$1() - started);
			return issued;
		},
		drain() {
			return drain();
		},
		async [Symbol.asyncDispose]() {
			let primary = noPrimaryFailure;
			try {
				await execution[Symbol.asyncDispose]();
			} catch (error) {
				primary = error;
				throw error;
			} finally {
				if (lifecycle) await disposeAsyncPreservingPrimary(() => Promise.resolve(disposeDirectSsrLifetime({
					frame,
					lifecycle
				}, "ssr render complete")), primary);
			}
		}
	});
}
async function disposeFailedDirectScheduledConstruction(execution, frame, lifecycle, primary) {
	try {
		await execution[Symbol.asyncDispose]();
	} catch (cleanup) {
		attachSuppressedCleanupFailure(primary, cleanup);
	}
	if (lifecycle) try {
		await lifecycle.dispose(frame, "ssr construction failed");
	} catch (cleanup) {
		attachSuppressedCleanupFailure(primary, cleanup);
	}
	throw primary;
}
/** Releases one compiler-linked direct lifetime after its complete component subtree. */
function disposeDirectSsrLifetime(lifetime, reason) {
	return lifetime.lifecycle.dispose(lifetime.frame, reason);
}
/** Claims one frame issued when compiler-generated parent render code created this component. */
function takePreparedDirectScheduledSsrComponent(context, component) {
	const prepared = context.preparedDirectScheduledComponents?.get(component);
	if (!prepared || prepared.consumed) return void 0;
	prepared.consumed = true;
	context.preparedDirectScheduledComponents?.delete(component);
	return prepared.component;
}
/** Captures compiler-issued direct child frames while one component materializes its render tree. */
function renderIssuedServerComponentChildren(context, options, render, owner) {
	const prepared = [];
	try {
		return {
			content: readDirectSsrContent(withServerComponentIssuer((candidate) => {
				const component = readServerComponentReference(candidate);
				if (!component) return;
				if (!prepareDirectScheduledSsrComponentReferences(context, [component], owner, options)) return;
				const record = context.preparedDirectScheduledComponents?.get(component);
				if (record) prepared.push(record);
			}, render)),
			...prepared.length ? { preparation: Object.freeze({ [Symbol.asyncDispose]: () => disposePrepared(context, prepared) }) } : {}
		};
	} catch (error) {
		return disposePrepared(context, prepared).then(() => Promise.reject(error), (cleanup) => {
			attachSuppressedCleanupFailure(error, cleanup);
			return Promise.reject(error);
		});
	}
}
async function disposePrepared(context, prepared) {
	const failures = [];
	for (const record of prepared) {
		context.preparedDirectScheduledComponents?.delete(record.reference);
		if (record.consumed) continue;
		try {
			const component = await record.component;
			if (component) await component[Symbol.asyncDispose]();
		} catch (error) {
			failures.push(error);
		}
	}
	if (failures.length) throw new AggregateError(failures, "Failed to dispose prepared SSR tasks");
}
function performanceNow$1() {
	return typeof globalThis.performance?.now === "function" ? globalThis.performance.now() : Date.now();
}
//#endregion
//#region ../packages/ssr/dist/render/direct-component.js
/** Executes available component work directly, suspending only preparation, descendants, or cleanup. */
function executeDirectSsrComponent(context, contract, rawProps, parent, options, sink, scalarPropsProven = false) {
	const artifact = contract.artifact;
	const server = artifact.execution;
	if (server?.lane !== "direct" || server.classification !== "synchronous" || !server.render) return void 0;
	return mapRenderValue(scalarPropsProven ? rawProps : prepareComponentProps(rawProps, server.deferredTaskProps, options), (props) => {
		const stateless = server.mode === "stateless" && !context.onDirectComponentCreated && !context.onDirectComponentRendered;
		if (stateless && !server.lifecycle && !context.onComponentAttemptCheckpoint && !context.onComponentAttemptRollback) {
			const frame = statelessDirectSsrComponentFrame;
			return mapRenderValue(renderIssuedServerComponentChildren(context, options, () => inComponentDomain(context, () => server.render.call(frame, props)), parent), (content) => {
				const snapshot = {
					componentId: artifact.id,
					contract,
					host: frame,
					state: frame.state,
					props
				};
				const preparation = content.preparation;
				if (!preparation) return sink(content.content, parent, props, snapshot);
				return withRenderCleanup(() => sink(content.content, parent, props, snapshot), () => Promise.resolve(preparation[Symbol.asyncDispose]()));
			});
		}
		const frame = stateless ? statelessDirectSsrComponentFrame : createSelectedDirectSsrFrame(context, contract, parent);
		const owner = stateless ? parent : selectedDirectSsrOwner(context, contract, frame, parent);
		const lifecycle = server.lifecycle;
		let preparation;
		let checkpoint;
		let resumptionCheckpoint;
		let attempted = false;
		let published = false;
		return withRenderCleanup(() => {
			let render;
			if (server.mode !== "direct" && server.mode !== "stateless") {
				render = inComponentDomain(context, () => server.render.call(frame, props));
				if (typeof render !== "function") throw new TypeError("Compiled synchronous server component did not return its render function");
			}
			const started = lifecycle ? performanceNow() : 0;
			return mapRenderValue(renderIssuedServerComponentChildren(context, options, () => inComponentDomain(context, () => server.mode === "direct" || server.mode === "stateless" ? server.render.call(frame, props) : render()), owner), (content) => {
				lifecycle?.rendered(frame, performanceNow() - started);
				preparation = content.preparation;
				const snapshot = {
					componentId: artifact.id,
					contract,
					host: frame,
					state: frame.state,
					props
				};
				checkpoint = context.onComponentAttemptCheckpoint?.();
				resumptionCheckpoint = stateless ? void 0 : options.resumptionCapture?.checkpoint();
				attempted = true;
				const token = stateless ? void 0 : options.resumptionCapture?.reserveDirect(artifact.id, contract);
				context.onDirectComponentCreated?.(snapshot);
				return mapRenderValue(sink(content.content, owner, props, snapshot), (output) => {
					if (token !== void 0) options.resumptionCapture?.publishDirect(token, frame, frame.state, props);
					context.onDirectComponentRendered?.(snapshot);
					published = true;
					return output;
				});
			});
		}, () => {
			if (attempted && !published) return withRenderCleanup(() => {
				if (resumptionCheckpoint !== void 0) options.resumptionCapture?.rollback(resumptionCheckpoint);
				context.onComponentAttemptRollback?.(checkpoint);
			}, () => withRenderCleanup(() => preparation ? Promise.resolve(preparation[Symbol.asyncDispose]()) : void 0, () => lifecycle?.dispose(frame, "ssr render complete")));
			return withRenderCleanup(() => preparation ? Promise.resolve(preparation[Symbol.asyncDispose]()) : void 0, () => lifecycle?.dispose(frame, "ssr render complete"));
		});
	});
}
function performanceNow() {
	return typeof globalThis.performance?.now === "function" ? globalThis.performance.now() : Date.now();
}
//#endregion
//#region ../packages/ssr/dist/render/component-enhancement-bindings.js
/**
* Binds incoming namespaces to prepared authored output for one request-owned component attempt.
* Descendant component implementations remain opaque until their own normal execution. Bindings
* are removed after completion, rejection, or retry, before the component's resources are released.
*/
function renderComponentEnhancementBindings(execution, reference, content, owner) {
	if (reference.contract.artifact.capabilities.includes("targets") && !readExactEnhancementContexts(reference.contract.artifact.instantiate)?.transparentTarget) assertSingleSuppliedPlacement(content.children ?? [content.program], reference.children.length ? reference.children : reference.props.children);
	const enhancement = boundOperationEnhancement(execution.context, reference, reference.enhancement, true);
	if (!enhancement) return renderDirectSsrContent(execution, content, owner);
	let entries = enhancement.entries;
	if (entries.length === 1) {
		const entry = entries[0];
		if (entry.root !== void 0 || isExactEnhancementPassThrough(execution.context.enhancementCatalog?.get(entry.identity))) return renderDirectSsrContent(execution, content, owner);
	} else entries = entries.filter((entry) => entry.root === void 0 && !isExactEnhancementPassThrough(execution.context.enhancementCatalog?.get(entry.identity)));
	if (!entries.length) return renderDirectSsrContent(execution, content, owner);
	if (entries.length > 1) assertEnhancementSourceOrder(entries.filter((entry) => execution.context.enhancementCatalog?.has(entry.identity)), execution.context.enhancementCatalog ?? /* @__PURE__ */ new Map());
	if (content.program && !content.program.program.targetSlots?.length) {
		if (!execution.prepareOutput) return renderDirectSsrContent(execution, content, owner, entries);
		const program = content.program;
		const bindings = execution.context.boundEnhancementTargets ??= /* @__PURE__ */ new WeakMap();
		const previous = bindings.get(program);
		bindings.set(program, entries);
		return withRenderCleanup(() => renderDirectSsrContent(execution, content, owner), () => {
			if (previous) bindings.set(program, previous);
			else bindings.delete(program);
		});
	}
	if (content.children) content = { children: prepareTextTargetOutput(content.children) };
	const targets = selectSsrEnhancementTargets(content.children ?? [content.program], entries, reference.children.length ? reference.children : reference.props.children);
	const bindings = execution.context.boundEnhancementTargets ??= /* @__PURE__ */ new WeakMap();
	const previous = new Map([...targets.keys()].map((key) => [key, bindings.get(key)]));
	for (const [key, selected] of targets) bindings.set(key, selected);
	return withRenderCleanup(() => renderDirectSsrContent(execution, content, owner), () => {
		for (const [key, value] of previous) if (value) bindings.set(key, value);
		else bindings.delete(key);
	});
}
//#endregion
//#region ../packages/ssr/dist/render/synchronous-artifact.js
/** Publishes a synchronous artifact directly, retaining continuations only for actual suspension. */
function executeSynchronousArtifact(execution, contract, reference, parent, props) {
	const output = executeDirectSsrComponent(execution.context, contract, props, parent, execution.options, (content, owner, preparedProps, snapshot) => {
		let html;
		try {
			html = !reference.enhancement && !execution.context.boundEnhancementTargets?.has(reference) && !contract.artifact.capabilities.includes("targets") ? renderDirectSsrContent(execution, content, owner) : renderComponentEnhancementBindings(execution, reference, content, owner);
		} catch (error) {
			return Promise.reject(error);
		}
		if (html instanceof Promise) return html.then((value) => execution.publish(execution.context, reference, parent, value, preparedProps, snapshot, execution.publication));
		return execution.publish(execution.context, reference, parent, html, preparedProps, snapshot, execution.publication);
	}, consumeScalarPropsProof(reference, props));
	return output instanceof Promise ? output.then(requireSynchronousArtifactOutput) : requireSynchronousArtifactOutput(output);
}
/** Rejects missing artifact output without capturing a callback for each completed component. */
function requireSynchronousArtifactOutput(value) {
	if (value === void 0) throw new TypeError("Synchronous server artifact did not execute its request-owned sink");
	return value;
}
//#endregion
//#region ../packages/ssr/dist/render/server-component-abi-execution.js
/**
* Executes one native server component exclusively through its target-local artifact methods.
* Issuance owns request state before serialization begins; disposal is attempted exactly once and
* cleanup failure never replaces the primary render failure.
*/
function renderServerComponentArtifactOutput(context, reference, parent, options, renderChildren, renderOwnedComponent, publish, publication) {
	const contract = receiptExecutionContract(reference);
	const artifact = contract.artifact;
	const props = serverComponentProps(reference);
	if (artifact.selection) return mapRenderValue(artifact.selection.resolve(), (selected) => renderServerComponentArtifactOutput(context, {
		...reference,
		contract: readPreparedExactServerExecutableComponentContract(selected)
	}, parent, options, renderChildren, renderOwnedComponent, publish, publication));
	if (artifact.execution.lane !== "direct") return void 0;
	const execution = {
		context,
		prepareOutput: context.preparedComponentOutputs?.get(reference),
		options,
		publication,
		publish,
		renderChildren,
		renderOwnedComponent,
		renderOwner: void 0,
		renderProgramSegment: renderExecutionProgramSegment,
		prepareProgramReferences: prepareExecutionProgramReferences
	};
	if (reference.fragmentTarget) {
		let project;
		execution.prepareOutput = (content, owner) => {
			project ??= createFragmentTargetProjection(reference.fragmentTarget.supplied, reference.fragmentTarget.tag, owner);
			const projected = project(content.children ?? [content.program]);
			return content.program ? readDirectSsrContent(projected[0]) : { children: projected };
		};
	}
	if (artifact.execution.classification === "synchronous") return executeSynchronousArtifact(execution, contract, reference, parent, props);
	return executeScheduledArtifact(execution, artifact, reference, parent, props);
}
/** Shared program forwarding retains the selected owner on this component's execution. */
function renderExecutionProgramSegment(value) {
	return Array.isArray(value) ? this.renderChildren(value, this.renderOwner) : this.renderOwnedComponent(value, this.renderOwner);
}
/** Prepares siblings under the same component owner without a per-content forwarding closure. */
function prepareExecutionProgramReferences(values) {
	return prepareDirectScheduledSsrComponentReferences(this.context, values, this.renderOwner, this.options);
}
async function executeScheduledArtifact(execution, artifact, reference, parent, props) {
	const context = execution.context;
	const blueprint = receiptExecutionBlueprint(reference);
	const frame = await artifact.issue.call(artifact, createRequestExecution(execution, blueprint, reference), parent, props);
	const output = createHtmlWriter(execution);
	let primary = noPrimaryFailure;
	try {
		await artifact.write.call(artifact, frame, output.writer);
		return output.read();
	} catch (error) {
		primary = error;
		if (frame.resumptionCheckpoint !== void 0) execution.options.resumptionCapture?.rollback(frame.resumptionCheckpoint);
		context.onComponentAttemptRollback?.(frame.checkpoint);
		throw error;
	} finally {
		await disposeAsyncPreservingPrimary(() => Promise.resolve(artifact.dispose.call(artifact, frame, primary === noPrimaryFailure ? "ssr render complete" : primary)), primary);
	}
}
function createRequestExecution(execution, blueprint, reference) {
	return { async [exactServerIssue](artifact, parent, props) {
		assertArtifact(artifact, blueprint.contract.artifact);
		const owner = parent;
		const scheduled = await (takePreparedDirectScheduledSsrComponent(execution.context, reference) ?? createDirectScheduledSsrComponent(execution.context, blueprint, props, owner, execution.options));
		if (!scheduled) throw new TypeError("Scheduled server artifact did not issue a request-local frame");
		const checkpoint = execution.context.onComponentAttemptCheckpoint?.();
		execution.context.onDirectComponentCreated?.(scheduled.snapshot);
		return createIssuedFrame({
			artifact,
			checkpoint,
			parent: owner,
			props: scheduled.props,
			scheduled,
			reference
		});
	} };
}
function createIssuedFrame(frame) {
	const issued = {
		...frame,
		disposed: false,
		async [exactServerDispose](artifact) {
			assertArtifact(artifact, frame.artifact);
			if (issued.disposed) return;
			issued.disposed = true;
			if (issued.preparation) {
				const preparation = issued.preparation;
				issued.preparation = void 0;
				await preparation[Symbol.asyncDispose]();
			}
			if (!issued.deferredScheduledDisposal) await frame.scheduled[Symbol.asyncDispose]();
		}
	};
	return issued;
}
function createHtmlWriter(execution) {
	let output;
	return {
		writer: { async [exactServerWrite](artifact, candidate) {
			const frame = candidate;
			assertArtifact(artifact, frame.artifact);
			if (frame.disposed) throw new Error("Cannot write a disposed server component frame");
			output = await writeScheduledFrame(execution, frame);
		} },
		read() {
			if (output === void 0) throw new Error("Server component artifact completed without output");
			return output;
		}
	};
}
async function writeScheduledFrame(execution, frame) {
	frame.resumptionCheckpoint = execution.options.resumptionCapture?.checkpoint();
	frame.resumptionToken = execution.options.resumptionCapture?.reserveDirect(frame.scheduled.snapshot.componentId, frame.scheduled.snapshot.contract);
	const scheduled = frame.scheduled;
	const settleDocument = execution.options.settleDocumentShell && (execution.context.documentRootSeen || frame.artifact.execution.documentRoot === true);
	if ((!execution.options.streamingScheduledComponents || settleDocument) && !frame.artifact.execution.streamingDocument) {
		const pending = scheduled.drain();
		if (pending instanceof Promise) await pending;
	}
	for (let pass = 0; pass < execution.context.maxTaskPasses; pass++) {
		const renderCheckpoint = execution.context.onComponentAttemptCheckpoint?.();
		const resumptionCheckpoint = execution.options.resumptionCapture?.checkpoint();
		const targetCheckpoint = checkpointTargetReceiptLayers(execution.context);
		const restoreEnhancementTarget = checkpointBoundEnhancementTarget(execution.context, frame.reference);
		const documentCheckpoint = checkpointDocumentHost(execution.context);
		const candidate = scheduled.render();
		const issued = candidate instanceof Promise ? await candidate : candidate;
		frame.preparation = issued.preparation;
		let primary = noPrimaryFailure;
		try {
			const rendered = renderComponentEnhancementBindings(execution, frame.reference, issued.content, scheduled.owner);
			const html = rendered instanceof Promise ? await rendered : rendered;
			if (execution.options.streamingScheduledComponents && !(settleDocument || execution.options.settleDocumentShell && execution.context.documentRootSeen)) {
				frame.deferredScheduledDisposal = true;
				execution.options.streamingScheduledComponents.push(scheduled);
				return publishFrame(execution, frame, html, scheduled.snapshot);
			}
			const readiness = scheduled.drain();
			if (readiness instanceof Promise ? await readiness : readiness) {
				if (resumptionCheckpoint !== void 0) execution.options.resumptionCapture?.rollback(resumptionCheckpoint);
				execution.context.onComponentAttemptRollback?.(renderCheckpoint);
				restoreTargetReceiptLayers(execution.context, targetCheckpoint);
				restoreEnhancementTarget();
				restoreDocumentHost(execution.context, documentCheckpoint);
				continue;
			}
			return publishFrame(execution, frame, html, scheduled.snapshot);
		} catch (error) {
			primary = error;
			if (resumptionCheckpoint !== void 0) execution.options.resumptionCapture?.rollback(resumptionCheckpoint);
			execution.context.onComponentAttemptRollback?.(renderCheckpoint);
			restoreTargetReceiptLayers(execution.context, targetCheckpoint);
			restoreEnhancementTarget();
			restoreDocumentHost(execution.context, documentCheckpoint);
			throw error;
		} finally {
			if (frame.preparation) await disposeFramePreparation(frame, primary);
		}
	}
	throw new Error(`eXact direct scheduled SSR component did not stabilize after ${execution.context.maxTaskPasses} render passes`);
}
function publishFrame(execution, frame, html, snapshot) {
	const output = execution.publish(execution.context, frame.reference, frame.parent, html, frame.props, snapshot, execution.publication);
	if (frame.resumptionToken !== void 0) execution.options.resumptionCapture?.publishDirect(frame.resumptionToken, snapshot.host, snapshot.state, frame.props);
	execution.context.onDirectComponentRendered?.(snapshot);
	return output;
}
async function disposeFramePreparation(frame, primary) {
	if (!frame.preparation) return;
	const preparation = frame.preparation;
	frame.preparation = void 0;
	await disposeAsyncPreservingPrimary(() => Promise.resolve(preparation[Symbol.asyncDispose]()), primary);
}
function assertArtifact(actual, expected) {
	if (actual !== expected) throw new TypeError("Server component ABI received a frame owned by another artifact");
}
//#endregion
//#region ../packages/ssr/dist/render/component.js
var publishComponent = (context, _component, _parent, html, props, snapshot, publication) => directComponentHtml(context, html, props, snapshot.contract.artifact.execution.publication, publication);
/** Renders one opaque component operation through its server artifact. */
function renderComponentReference(context, component, parent, options, hasComponentAncestor, omitCompilerOwnedBoundary = false, omitRootBoundary = false) {
	if (options.documentShellScope?.claim(component)) {
		options = options.documentShellScope.applicationOptions;
		hasComponentAncestor = false;
		omitRootBoundary = true;
		omitCompilerOwnedBoundary = true;
	}
	if (!hasComponentAncestor && options.resumptionCapture) options = {
		...options,
		clientResumptionOwner: component.contract.placement === "isomorphic" || component.contract.placement === "client"
	};
	const publication = component.contract.artifact.target === "server" ? component.contract.artifact.execution.publication : void 0;
	if (hasComponentAncestor && publication?.kind === "resumption" && !options.clientResumptionOwner) {
		const id = formatMarkerId("component", context.nextId++, component.contract.artifact.id, component.key);
		const capture = createSsrResumptionCapture({
			...options,
			clientResumptionOwner: true
		});
		return captureSsrProgramOutput(context, () => mapRenderValue(renderComponentReference(context, component, parent, capture.options, true, true), (html) => mapRenderValue(prepareComponentProps(component.props, void 0, capture.options), (props) => renderPreparedResumableComponentBoundary(context, id, publication.name, html, props, capture.serializedRecords()))));
	}
	if (context.writerSink && component.contract.artifact.target === "server" && !(component.contract.artifact.execution.streamingDocument && !component.enhancement && context.documentProbe && context.hostStack.length === 0) && (component.contract.artifact.execution.classification !== "synchronous" || context.markers && !omitRootBoundary && !omitCompilerOwnedBoundary || !options.resumptionCapture && hasComponentAncestor && component.contract.artifact.execution.publication?.kind === "resumption")) return captureSsrProgramOutput(context, () => renderComponentReference(context, component, parent, options, hasComponentAncestor, omitCompilerOwnedBoundary, omitRootBoundary));
	return mapRenderValue(renderServerComponentArtifactOutput(context, component, parent, options, renderArtifactChildren, renderArtifactComponent, publishComponent, {
		capturesResumptions: options.resumptionCapture !== void 0,
		componentName: component.contract.artifact.id,
		componentKey: component.key,
		componentOrdinal: context.nextId++,
		documentProbe: context.documentProbe && context.hostStack.length === 0,
		hasComponentAncestor,
		omitCompilerOwnedBoundary,
		omitRootBoundary
	}), (value) => {
		if (value === void 0) throw new TypeError("Native component operation selected a non-direct server artifact");
		return value;
	});
}
/** Shared forwarding reads the request from its execution instead of capturing it per component. */
function renderArtifactChildren(children, owner) {
	return renderChildren(this.context, children, owner, this.options, true);
}
/** Descendants retain their own execution and normal compiler-owned publication boundary. */
function renderArtifactComponent(child, owner) {
	return renderComponentReference(this.context, child, owner, this.options, true, true);
}
//#endregion
//#region ../packages/ssr/dist/render/text-host-output.js
/**
* Projects an ordinary request-owned render into literal title/textarea text. Native components,
* enhancements and pending work keep their normal execution and cleanup; only physical markup
* publication changes. Structural markers never become visible text. The enclosing host buffers
* this region until its text settles, and restores request state even when rendering rejects.
*/
function renderTextHostOutput(context, tag, render) {
	const previous = {
		depth: context.textProjectionDepth,
		markers: context.markers,
		separators: context.textSeparators
	};
	context.textProjectionDepth = context.hostStack.length;
	context.markers = false;
	context.textSeparators = false;
	return withRenderCleanup(() => mapRenderValue(render(), (text) => (tag === "textarea" && text.startsWith("\n") ? "\n" : "") + escapeText(text).replaceAll("\r", "&#13;")), () => {
		context.textProjectionDepth = previous.depth;
		context.markers = previous.markers;
		context.textSeparators = previous.separators;
	});
}
//#endregion
//#region ../packages/ssr/dist/render/intrinsic-receipt.js
function intrinsicHostProps(context, receipt) {
	if (receipt.tag !== "option" || context.selectValue === void 0) return receipt.props;
	const value = String(unwrap(receipt.props.value) ?? primitiveText(receipt.children));
	const selected = Array.isArray(context.selectValue) ? context.selectValue.some((item) => String(unwrap(item)) === value) : String(unwrap(context.selectValue)) === value;
	return {
		...receipt.props,
		selected
	};
}
/** Serializes an intrinsic while retaining host ownership through pending descendants. */
function renderIntrinsicReceipt(context, receipt, parent, hasComponentAncestor, renderChildren) {
	if (context.writerSink && [
		"html",
		"head",
		"body"
	].includes(receipt.tag)) {
		const sink = context.writerSink;
		const host = enterHostTag(context, receipt.tag);
		return withRenderCleanup(() => {
			const attrs = renderAttrs(consumeTargetReceiptLayers(context, receipt.props), false, host.tag, context);
			sink.write(`${host.prefix}<${host.tag}${attrs}>`);
			return mapRenderValue(sink.ready(), () => mapRenderValue(renderChildren(context, host.tag === "html" ? normalizeDocumentChildren(receipt.children) : receipt.children, parent, hasComponentAncestor), (html) => {
				if (html) sink.write(html);
				if (host.tag === "body") sink.captureDocumentBoundary?.();
				sink.write(`</${host.tag}>`);
				return mapRenderValue(host.tag === "head" ? sink.flush("head") : sink.ready(), () => "");
			}));
		}, () => leaveHost(context, host.tag));
	}
	if (context.writerSink) return captureSsrProgramOutput(context, () => renderIntrinsicReceipt(context, receipt, parent, hasComponentAncestor, renderChildren));
	const host = enterHostTag(context, receipt.tag);
	const tag = host.tag;
	return withRenderCleanup(() => {
		const contributedProps = consumeTargetReceiptLayers(context, intrinsicHostProps(context, receipt));
		const attrs = context.textProjectionDepth !== void 0 ? projectedAttributes(contributedProps, tag, context) : renderAttrs(contributedProps, false, tag, context);
		if (voidElements.has(tag)) return `${host.prefix}<${tag}${attrs}>`;
		let content;
		if (tag === "script" || tag === "style") content = primitiveText(receipt.children);
		else if (tag === "title" || tag === "textarea") content = renderTextHostOutput(context, tag, () => renderChildren(context, receipt.children, parent, hasComponentAncestor));
		else {
			const previousSelect = context.selectValue;
			if (tag === "select") context.selectValue = unwrap(receipt.props.value ?? receipt.props.defaultValue);
			content = withRenderCleanup(() => renderChildren(context, tag === "html" ? normalizeDocumentChildren(receipt.children) : receipt.children, parent, hasComponentAncestor), () => {
				context.selectValue = previousSelect;
			});
		}
		return mapRenderValue(content, (html) => `${host.prefix}<${tag}${attrs}>${html}</${tag}>`);
	}, () => leaveHost(context, tag));
}
/** Normalizes a compiler-issued document operation tree without reconstructing topology. */
function normalizeDocumentChildren(children) {
	if (children.length === 2 && documentChildTag(children[0]) === "head" && documentChildTag(children[1]) === "body") return children;
	const classified = children.map((child) => ({
		child,
		tag: documentChildTag(child)
	}));
	if (classified.some((entry) => entry.tag === void 0)) return children;
	const heads = classified.filter((entry) => entry.tag === "head");
	const bodies = classified.filter((entry) => entry.tag === "body");
	if (heads.length > 1) throw new Error("A root document may contain at most one <head> element.");
	if (bodies.length > 1) throw new Error("A root document may contain at most one <body> element.");
	const loose = classified.filter((entry) => entry.tag !== "head" && entry.tag !== "body");
	if (bodies.length && loose.length) throw new Error("A root document with an authored <body> cannot also contain ambiguous loose content.");
	return [heads[0]?.child ?? createCompiledIntrinsicReceipt("head", null), bodies[0]?.child ?? createCompiledIntrinsicReceipt("body", null, ...loose.map((entry) => entry.child))];
}
/** Recognizes document hosts across generic operations and compiler-owned server programs. */
function documentChildTag(child) {
	const program = readPreparedServerRenderProgram(child);
	return program ? program.program.ssrHost ?? "" : readCompiledIntrinsicReceipt(child)?.tag;
}
//#endregion
//#region ../packages/ssr/dist/render/server-boundary-capability.js
var capabilityName$2 = "server-boundary";
/** Renders an explicitly compiler-selected server boundary asynchronously. */
function renderServerBoundary(context, boundary, parent, options, finite = false) {
	const capability = ssrCapabilities[capabilityName$2];
	if (!capability) throw new TypeError("Server boundary rendering requires its compiler capability");
	return capability.renderAsync(context, boundary, parent, options, finite);
}
//#endregion
//#region ../packages/ssr/dist/render/server-slots.js
/** Validates one opaque compiler-owned retained server-range operation. */
function serverSlotReceiptReference(receipt) {
	if (!serverSlotReference({
		__exactServerSlot: receipt.id,
		planVersion: receipt.planVersion,
		buildKey: receipt.buildKey,
		planEdgeId: receipt.planEdgeId,
		ownerComponentId: receipt.ownerComponentId,
		discriminator: receipt.discriminator,
		generation: receipt.generation
	})) throw new Error("Compiler-planned server range has malformed runtime authority");
	return {
		id: receipt.id,
		planVersion: receipt.planVersion,
		buildKey: receipt.buildKey,
		planEdgeId: receipt.planEdgeId,
		ownerComponentId: receipt.ownerComponentId,
		discriminator: receipt.discriminator,
		generation: receipt.generation
	};
}
/** Reports whether a value carries a valid compiler-owned server-slot authority record. */
function serverSlotReference(value) {
	if (typeof value === "string") return value.length > 0;
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	const slot = value;
	return typeof slot.__exactServerSlot === "string" && slot.__exactServerSlot.length > 0 && slot.planVersion === 1 && typeof slot.buildKey === "string" && slot.buildKey.length > 0 && (slot.planEdgeId === slot.__exactServerSlot || isServerSlotDiscriminator(slot.discriminator) && slot.discriminator.kind === "keyed" && slot.__exactServerSlot.startsWith(`${slot.planEdgeId}:key:`)) && typeof slot.ownerComponentId === "string" && slot.ownerComponentId.length > 0 && isServerSlotDiscriminator(slot.discriminator) && Number.isSafeInteger(slot.generation) && slot.generation > 0;
}
/** Emits the compact runtime authority tuple on one retained server range. */
function serverSlotOpening(slot, context) {
	if (slot.buildKey && context.buildKey && slot.buildKey !== context.buildKey) throw new Error("Client boundary partition slot build does not match the SSR build");
	const discriminator = slot.discriminator;
	const authority = slot.planVersion === void 0 ? "" : ` data-exact-partition-version="${slot.planVersion}" data-exact-partition-build="${escapeAttr(slot.buildKey)}" data-exact-partition-root="${escapeAttr(context.executionRoot)}" data-exact-partition-edge="${escapeAttr(slot.planEdgeId)}" data-exact-partition-owner="${escapeAttr(slot.ownerComponentId)}" data-exact-partition-discriminator="${discriminator.kind}"${discriminator?.kind === "branch" ? ` data-exact-partition-branch="${escapeAttr(discriminator.branch)}"` : ""}${discriminator?.kind === "keyed" ? ` data-exact-partition-list="${escapeAttr(discriminator.list)}" data-exact-partition-key="${escapeAttr(discriminator.keyToken)}"` : ""} data-exact-partition-generation="${slot.generation}"`;
	return `<span data-exact-server-slot="${escapeAttr(slot.id)}"${authority} style="display: contents;">`;
}
//#endregion
//#region ../packages/ssr/dist/render/structural-boundary-capability.js
var capabilityName$1 = "structural-boundary";
/** Renders an asynchronous native Suspense boundary through its selected capability. */
function renderNativeSuspense(context, boundary, parent, options, renderChildren) {
	return requiredCapability().renderSuspense(context, boundary, parent, options, renderChildren);
}
function requiredCapability() {
	const capability = ssrCapabilities[capabilityName$1];
	if (!capability) throw new TypeError("SSR structural boundary execution requires its compiler-selected runtime capability");
	return capability;
}
//#endregion
//#region ../packages/ssr/dist/render/structural-receipts.js
/** Async keyed sibling serialization. */
function renderKeyedChildReceipt(context, receipt, parent, options, hasComponentAncestor, renderChildren) {
	return markerPair(context, markerId(context, "item", void 0, receipt.key), () => renderChildren(context, [receipt.value], parent, options, hasComponentAncestor));
}
/** Serializes one compiler-owned transparent range asynchronously. */
function renderFragmentReceipt(context, receipt, parent, options, hasComponentAncestor, renderChildren) {
	if (context.documentProbe && receipt.children.some((child) => readDoctype(child))) return renderChildren(context, receipt.children, parent, options, hasComponentAncestor);
	return markerPair(context, markerId(context, "fragment", void 0, receipt.key), () => renderChildren(context, receipt.children, parent, options, hasComponentAncestor));
}
/** Serializes a semantic target, retaining its request-local contributions until output settles. */
function renderTargetReceipt(context, receipt, parent, options, hasComponentAncestor, renderChildren) {
	const layers = (readCompiledFragmentReceipt(readSuppliedTargetValue(receipt.children)) ? [] : receipt.contributions ?? [{ props: receipt.props }]).map((layer) => ({
		props: layer.props,
		consumed: false
	}));
	(context.targetReceiptLayers ??= []).push(...layers);
	return withRenderCleanup(() => markerPair(context, markerId(context, "target", void 0, receipt.key), () => renderChildren(context, receipt.children, parent, options, hasComponentAncestor)), () => {
		if (layers.length) context.targetReceiptLayers.splice(-layers.length, layers.length);
	});
}
/** Serializes one compiler-issued retained Activity operation asynchronously. */
function renderActivityReceipt(context, receipt, parent, options, hasComponentAncestor, renderChildren) {
	return markerPair(context, markerId(context, "activity"), () => normalizeActivityMode(unwrap(receipt.props.mode)) === "active" ? renderChildren(context, receipt.children, parent, options, hasComponentAncestor) : Promise.resolve(""));
}
/** Serializes one compiler-issued readiness operation asynchronously. */
async function renderSuspenseReceipt(context, receipt, parent, options, hasComponentAncestor, renderChildren) {
	if (context.writerSink) return captureSsrProgramOutput(context, () => renderSuspenseReceipt(context, receipt, parent, options, hasComponentAncestor, renderChildren));
	const identity = markerId(context, "suspense");
	const rendered = await renderNativeSuspense(context, receipt, parent, options, (target, children, owner, renderOptions) => renderChildren(target, children, owner, renderOptions, hasComponentAncestor));
	return markerPair(context, suspenseStatusMarkerId(identity, rendered.status), () => rendered.html);
}
//#endregion
//#region ../packages/ssr/dist/render/operation-target.js
/** Shared SSR target selected directly by each opaque compiler-issued operation. */
var SsrOperationTarget = class {
	context;
	parent;
	options;
	hasComponentAncestor;
	renderChildren;
	constructor(context, parent, options, hasComponentAncestor, renderChildren) {
		this.context = context;
		this.parent = parent;
		this.options = options;
		this.hasComponentAncestor = hasComponentAncestor;
		this.renderChildren = renderChildren;
	}
	/** Publishes a request-owned document slot at its authored location. */
	[exactDocumentOutputOperation](kind) {
		return renderDocumentOutput(this.context, this.options, kind);
	}
	/** Emits an authored declaration before the root without generating a second default declaration. */
	[exactDoctypeOperation](declaration) {
		return renderDocumentDoctype(this.context, declaration);
	}
	/** Serializes a component operation with asynchronous descendant support. */
	[exactComponentOperation](_operation, data) {
		return this.renderDirectServerComponent(data);
	}
	/** Serializes an intrinsic operation and any enhancement wrapper. */
	[exactIntrinsicOperation](operation, data) {
		return renderOperationEnhancements(this.context, boundOperationEnhancement(this.context, operation, data.enhancement), () => renderIntrinsicReceipt(this.context, data, this.parent, this.hasComponentAncestor, (target, children, owner, ancestor) => this.renderChildren(target, children, owner, this.options, ancestor)), this.parent, this.options, this.renderChildren, withoutCompiledIntrinsicReceiptEnhancement(operation));
	}
	/** Serializes one keyed child while preserving its marker identity. */
	[exactKeyedChildOperation](_operation, data) {
		return this.renderKeyedChild(data);
	}
	/** Serializes one direct compiler-closed keyed server child. */
	renderDirectServerKeyedChild(data) {
		return this.renderKeyedChild(data);
	}
	renderKeyedChild(data) {
		const program = readPreparedServerRenderProgram(data.value);
		if (program && program.program.ssrHost !== "script") return this.renderPreparedServerProgram(program);
		return renderKeyedChildReceipt(this.context, data, this.parent, this.options, this.hasComponentAncestor, this.renderChildren);
	}
	/** Serializes an asynchronously settling Suspense operation. */
	[exactSuspenseOperation](operation, data) {
		return renderOperationEnhancements(this.context, boundOperationEnhancement(this.context, operation, data.enhancement), () => renderSuspenseReceipt(this.context, data, this.parent, this.options, this.hasComponentAncestor, this.renderChildren), this.parent, this.options, this.renderChildren, withoutCompiledSuspenseReceiptEnhancement(operation));
	}
	/** Serializes the currently selected Activity content. */
	[exactActivityOperation](_operation, data) {
		return renderActivityReceipt(this.context, data, this.parent, this.options, this.hasComponentAncestor, this.renderChildren);
	}
	/** Serializes a transparent compiler-owned fragment range. */
	[exactFragmentOperation](operation, data) {
		return renderOperationEnhancements(this.context, boundOperationEnhancement(this.context, operation, data.enhancement), () => renderFragmentReceipt(this.context, data, this.parent, this.options, this.hasComponentAncestor, this.renderChildren), this.parent, this.options, this.renderChildren, withoutCompiledFragmentReceiptEnhancement(operation));
	}
	/** Serializes the children selected by a semantic target operation. */
	[exactTargetOperation](_operation, data) {
		return renderTargetReceipt(this.context, data, this.parent, this.options, this.hasComponentAncestor, this.renderChildren);
	}
	/** Serializes a focused dynamic child range. */
	[exactChildRangeOperation](operation, data) {
		return renderBoundChildRange(this.context, operation, data, this.parent, this.options, this.hasComponentAncestor, this.renderChildren);
	}
	/** Serializes a direct list through the same fragment markers and child ownership. */
	renderServerList(data) {
		return renderFragmentReceipt(this.context, data, this.parent, this.options, this.hasComponentAncestor, this.renderChildren);
	}
	/** Serializes one direct compiler-closed server child range. */
	renderDirectServerChildRange(data) {
		return renderBoundChildRange(this.context, data, data, this.parent, this.options, this.hasComponentAncestor, this.renderChildren, true);
	}
	/** Serializes audited raw HTML without reparsing it. */
	[exactUnsafeHtmlOperation](_operation, data) {
		return markerPair(this.context, markerId(this.context, "unsafe-html"), () => renderUnsafeHtmlValue(this.context, data.value));
	}
	/** Serializes a client-island publication boundary. */
	[exactServerBoundaryOperation](operation, data) {
		return renderServerBoundary(this.context, data, this.parent, this.options, isFiniteClientBoundary(operation));
	}
	/** Serializes a retained server-owned child slot. */
	[exactServerSlotOperation](_operation, data) {
		if (this.context.writerSink) return captureSsrProgramOutput(this.context, () => this[exactServerSlotOperation](_operation, data));
		return data.children.length ? mapRenderValue(this.renderChildren(this.context, data.children, this.parent, this.options, this.hasComponentAncestor), (html) => `${serverSlotOpening(serverSlotReceiptReference(data), this.context)}${html}</span>`) : "";
	}
	/** Serializes portal children in logical ownership order. */
	[exactPortalOperation](_operation, data) {
		return this.renderChildren(this.context, data.children, this.parent, this.options, this.hasComponentAncestor);
	}
	/** Serializes a compiler-closed server render program. */
	[exactRenderProgramOperation](operation, data) {
		const program = readPreparedServerRenderProgram(data.invocation);
		if (!program) throw new TypeError("Server rendering received a client-only render-program operation");
		return renderOperationEnhancements(this.context, boundOperationEnhancement(this.context, operation, data.enhancement), () => this.renderPreparedServerProgram(program), this.parent, this.options, this.renderChildren, withoutRenderProgramReceiptEnhancement(operation));
	}
	/** Serializes a compiler-issued direct server program nested inside another operation. */
	renderPreparedServerProgram(program) {
		return renderBoundProgram(this.context, program, this, this.parent, this.options, this.renderChildren);
	}
	/** Prepares program siblings through this traversal target's existing owner and options. */
	prepareProgramReferences(values) {
		return prepareDirectScheduledSsrComponentReferences(this.context, values, this.parent, this.options);
	}
	/** Serializes one direct server reference reached outside a prepared render-program segment. */
	renderDirectServerComponent(component) {
		this.context.enhancementOperationComponentDepth = (this.context.enhancementOperationComponentDepth ?? 0) + 1;
		return withRenderCleanup(() => renderComponentReference(this.context, component, this.parent, this.options, this.hasComponentAncestor), () => {
			this.context.enhancementOperationComponentDepth--;
		});
	}
	/** Serializes a compiler-proven root without its redundant outer component delimiter. */
	renderCompilerClosedRootComponent(component) {
		return renderComponentReference(this.context, component, void 0, this.options, false, false, true);
	}
	/** Returns already serialized SSR output without reparsing it. */
	[exactSerializedSsrHtmlOperation](html) {
		return html;
	}
	/** Renders a prepared program segment without allocating a forwarding callback. */
	renderProgramSegment(segment) {
		if (Array.isArray(segment)) return this.renderChildren(this.context, segment, this.parent, this.options, this.hasComponentAncestor);
		return renderComponentReference(this.context, segment, this.parent, this.options, this.hasComponentAncestor, true);
	}
};
//#endregion
//#region ../packages/ssr/dist/render/children.js
/** Empty structural output carries no request state and cannot be mutated across traversals. */
var emptyChildResult = Object.freeze({
	html: "",
	text: false
});
/** Serializes native operations and scalar children, suspending only for pending output. */
function renderChildren(context, children, parent, options, hasComponentAncestor = false) {
	return new ChildrenOutput(context, children, new SsrOperationTarget(context, parent, options, hasComponentAncestor, renderChildren)).render();
}
/** Ordered child traversal retains continuation state only once per sibling group. */
var ChildrenOutput = class {
	context;
	children;
	target;
	sink;
	html = "";
	previousWasText = false;
	index = 0;
	constructor(context, children, target) {
		this.context = context;
		this.children = children;
		this.target = target;
		this.sink = context.writerSink;
	}
	render() {
		while (this.index < this.children.length) {
			const value = renderChildWithTarget(this.context, this.children[this.index++], this.target);
			if (value instanceof Promise) return awaitSsrProgramSink(this.sink, value).then((result) => {
				this.append(result);
				return mapRenderValue(this.sink?.ready(), () => this.render());
			});
			this.append(value);
			const pending = this.sink?.ready();
			if (pending instanceof Promise) return pending.then(() => this.render());
		}
		return this.html;
	}
	append(result) {
		if (this.sink) {
			let html = result.html;
			if (this.context.textSeparators && result.text && this.previousWasText) html = "<!-- -->" + html;
			if (html !== "") this.sink.write(html);
			this.previousWasText = result.text;
			return;
		}
		this.html = captureNestedEnhancementStringPrefix(this.context, this.html);
		if (this.context.textSeparators && result.text && this.previousWasText) this.html = appendBoundedHtml(this.context, this.html, "<!-- -->");
		if (result.html !== "") this.html = appendBoundedHtml(this.context, this.html, result.html);
		this.previousWasText = result.text;
	}
};
/** Holds tree depth until an actually pending child settles, without closures for completed work. */
function renderChildWithTarget(context, child, target) {
	countSsrNode(context);
	enterSsrTreeDepth(context);
	let output;
	try {
		output = renderChildValue(context, child, target);
	} catch (error) {
		leaveSsrTreeDepth(context);
		throw error;
	}
	if (output instanceof Promise) return output.finally(() => leaveSsrTreeDepth(context));
	leaveSsrTreeDepth(context);
	return output;
}
function renderChildValue(context, child, target) {
	const program = readPreparedServerRenderProgram(child);
	if (program) return mapRenderValue(target.renderPreparedServerProgram(program), operationResult);
	const component = readServerComponentReference(child);
	if (component) return mapRenderValue(target.renderDirectServerComponent(component), operationResult);
	const range = readPreparedServerChildRange(child);
	if (range) return mapRenderValue(target.renderDirectServerChildRange(range), operationResult);
	const list = readServerList(child);
	if (list) return mapRenderValue(target.renderServerList(list), operationResult);
	const keyed = readPreparedServerKeyedChild(child);
	if (keyed) return mapRenderValue(target.renderDirectServerKeyedChild(keyed), operationResult);
	const executed = executeOpaqueOperation(child, target);
	if (executed) return mapRenderValue(executed.value, operationResult);
	const value = unwrap(child);
	if (value === null || value === void 0 || value === false || value === true) return emptyChildResult;
	if (typeof value === "object" || typeof value === "function") throw new TypeError("Native SSR children require compiler-issued operations or scalar values");
	claimRootText(context);
	return {
		html: context.textProjectionDepth === context.hostStack.length ? String(value) : escapeText(String(value)),
		text: true
	};
}
function operationResult(html) {
	return html === "" ? emptyChildResult : {
		html,
		text: false
	};
}
//#endregion
//#region ../packages/ssr/dist/render/document-string-sink.js
/** Collects text while retaining document boundaries for hydration insertion without an HTML scan. */
var DocumentStringSink = class {
	maxBytes;
	value = "";
	parts = [];
	remainingCharacters;
	closed = false;
	constructor(maxBytes) {
		this.maxBytes = maxBytes;
		this.remainingCharacters = maxBytes;
	}
	/** Rejects the UTF-16 lower bound before retaining another complete span. */
	write(html) {
		if (this.closed) throw new Error("SSR string sink is closed");
		if (this.value.length + html.length > this.remainingCharacters) {
			this.destroy();
			throw new SsrOutputLimitError(this.maxBytes);
		}
		if (html) this.value += html;
	}
	/** Retains a compiler-known document edge without inspecting accumulated text. */
	captureDocumentBoundary() {
		if (this.closed) throw new Error("SSR string sink is closed");
		this.parts.push(this.value);
		this.remainingCharacters -= this.value.length;
		this.value = "";
	}
	/** Complete-string collection has no transport pressure. */
	ready() {}
	/** String publication remains deferred until the document is complete. */
	flush() {}
	/** Transfers completed chunks after checking their combined UTF-8 limit, including prefix hints. */
	finishChunks(prefix = []) {
		if (this.closed) throw new Error("SSR string sink is closed");
		let characters = this.maxBytes - this.remainingCharacters + this.value.length;
		for (const part of prefix) characters += part.length;
		if (characters > this.maxBytes) {
			this.destroy();
			throw new SsrOutputLimitError(this.maxBytes);
		}
		const chunks = [
			...prefix,
			...this.parts,
			this.value
		];
		this.destroy();
		if (characters > this.maxBytes / 3 && utf8ByteLength(chunks.join("")) > this.maxBytes) throw new SsrOutputLimitError(this.maxBytes);
		return chunks;
	}
	/** Releases request-owned text on success, failure, or cancellation. */
	destroy() {
		this.value = "";
		this.parts = [];
		this.closed = true;
	}
};
//#endregion
//#region ../packages/ssr/dist/render/document-shell.js
/** Request-local boundary between a server-only shell and its application hydration subtree. */
var DocumentShellScope = class {
	applicationOptions;
	visits = 0;
	reference;
	/** Shell snapshots track boundary visits for rollback but publish no shell state. */
	capture = {
		checkpoint: () => (this.applicationOptions.resumptionCapture?.checkpoint() ?? 0) * 2 + this.visits,
		rollback: (checkpoint) => {
			this.visits = checkpoint % 2;
			this.applicationOptions.resumptionCapture?.rollback(Math.floor(checkpoint / 2));
		},
		reserveDirect: () => void 0,
		publishDirect: () => {},
		serializedRecords: () => [],
		activations: () => []
	};
	constructor(root, applicationOptions) {
		this.applicationOptions = applicationOptions;
		const reference = readServerComponentReference(root);
		if (!reference) throw new TypeError("documentShell requires a compiler-issued application component");
		this.reference = reference;
	}
	/** Claims one application position; a shell cannot duplicate its hydration root. */
	claim(reference) {
		if (reference !== this.reference) return false;
		if (this.visits++) throw new Error("A document shell must render its application exactly once");
		return true;
	}
	/** Rejects a shell that dropped the application or did not render a document. */
	complete(documentRootSeen) {
		if (this.visits !== 1) throw new Error("A document shell must render its application exactly once");
		if (!documentRootSeen) throw new Error("A document shell must render a root html document");
	}
};
//#endregion
//#region ../packages/ssr/dist/render/document-stream-sink.js
var documentTail = "</body></html>";
/**
* Collects speculative document output until its head commits, then releases body spans.
* Buffer size is a flush threshold, not a maximum authored span size. Only a closing-tag
* lookbehind and the current buffer remain owned after each successful publication, until an
* explicit hydration slot retains the following document tail for final state publication.
*/
var DocumentStreamSink = class {
	maxBytes;
	destination;
	bufferSize;
	value = "";
	emittedBytes = 0;
	bufferedBytes = 0;
	lastCodeUnit = NaN;
	closed = false;
	committed = false;
	pending;
	constructor(maxBytes, destination, bufferSize = 8192) {
		this.maxBytes = maxBytes;
		this.destination = destination;
		this.bufferSize = bufferSize;
		if (!Number.isSafeInteger(bufferSize) || bufferSize < 1) throw new RangeError("streamBufferSize must be a positive safe integer");
	}
	/** Accepts a complete span; readiness owns any resulting transport pressure. */
	write(html) {
		this.assertOpen();
		if (!html) return;
		let bytes = utf8ByteLength(html);
		const previous = this.lastCodeUnit;
		const next = html.charCodeAt(0);
		if (previous >= 55296 && previous <= 56319 && next >= 56320 && next <= 57343) bytes -= 2;
		if (this.emittedBytes + this.bufferedBytes + bytes > this.maxBytes) return this.fail(new SsrOutputLimitError(this.maxBytes));
		this.bufferedBytes += bytes;
		this.value += html;
		this.lastCodeUnit = html.charCodeAt(html.length - 1);
	}
	/** Flushes a full buffer plus the accepted span, retaining the final document delimiter. */
	ready() {
		this.assertOpen();
		if (this.pending) return this.pending;
		if (this.committed && this.bufferedBytes >= this.bufferSize) return this.publishBody();
	}
	/** Commits a completed head once, and drains available body output before pending work. */
	flush(reason) {
		this.assertOpen();
		if (this.pending) return this.pending;
		if (reason === "head" && !this.committed && isExactDocumentHtml(this.value)) {
			const head = this.value;
			this.account(head);
			this.value = "";
			this.bufferedBytes = 0;
			this.lastCodeUnit = NaN;
			this.committed = true;
			return this.publish(head, true);
		}
		if (reason === "await" && this.committed) {
			let reserve = Math.min(14, this.value.length);
			while (reserve && !this.value.endsWith(documentTail.slice(0, reserve))) reserve--;
			return this.publishBody(reserve);
		}
	}
	/** Returns collected fallback markup or only the reserved closing tags after body delivery. */
	finish(prefix = []) {
		this.assertOpen();
		if (this.pending) return mapRenderValue(this.pending, () => this.finish(prefix));
		if (!this.committed) {
			const html = prefix.join("") + this.value;
			this.account(html);
			this.destroy();
			return {
				html,
				streamed: false
			};
		}
		const hints = prefix.join("");
		if (hints) {
			this.value = hints + this.value;
			this.bufferedBytes += utf8ByteLength(hints);
		}
		if (!this.value.endsWith(documentTail)) throw new Error("Streamed document output is missing its closing body/html elements");
		return mapRenderValue(this.publishBody(), () => {
			this.account(this.value);
			const html = this.value;
			this.destroy();
			return {
				html,
				streamed: true
			};
		});
	}
	/** Releases retained output on completion, cancellation, or failure. */
	destroy() {
		this.value = "";
		this.bufferedBytes = 0;
		this.lastCodeUnit = NaN;
		this.pending = void 0;
		this.closed = true;
	}
	publishBody(reserve = 14) {
		let end = this.value.length - reserve;
		const slot = this.value.indexOf(documentHydrationSlot);
		if (slot >= 0) end = Math.min(end, slot);
		if (end <= 0) return;
		const code = this.value.charCodeAt(end - 1);
		const next = this.value.charCodeAt(end);
		if (code >= 55296 && code <= 56319 && (end === this.value.length || next >= 56320 && next <= 57343)) end--;
		if (!end) return;
		const body = this.value.slice(0, end);
		this.bufferedBytes -= this.account(body);
		this.value = this.value.slice(end);
		return this.publish(body, false);
	}
	account(html) {
		const bytes = utf8ByteLength(html);
		this.emittedBytes += bytes;
		if (this.emittedBytes > this.maxBytes) this.fail(new SsrOutputLimitError(this.maxBytes));
		return bytes;
	}
	assertOpen() {
		if (this.closed) throw new Error("SSR document sink is closed");
	}
	publish(html, head) {
		try {
			const pending = head ? this.destination.head(html) : this.destination.body(html);
			if (!(pending instanceof Promise)) return pending;
			return this.pending = pending.then(() => {
				this.pending = void 0;
			}, (error) => this.fail(error));
		} catch (error) {
			return this.fail(error);
		}
	}
	fail(error) {
		this.destroy();
		this.destination.abort(error);
		throw error;
	}
};
//#endregion
//#region ../packages/ssr/dist/render/document-root-output.js
/**
* Issues a progressive root or explicit server shell before choosing document output or local capture.
* Component preparation, descendant traversal, resumption, and disposal use the shared executor.
* Scheduled, selected, and enhanced roots retain their existing publication boundary.
*/
function renderDocumentRootOutput(context, operation, options) {
	const reference = readServerComponentReference(operation);
	if (!reference) return renderChildren(context, [operation], void 0, options);
	const contract = receiptExecutionContract(reference);
	if (options.resumptionCapture) options = {
		...options,
		clientResumptionOwner: contract.placement === "client" || contract.placement === "isomorphic"
	};
	if (reference.enhancement || contract.artifact.selection || contract.artifact.execution.classification !== "synchronous") return renderChildren(context, [operation], void 0, options);
	countSsrNode(context);
	enterSsrTreeDepth(context);
	context.enhancementOperationComponentDepth = (context.enhancementOperationComponentDepth ?? 0) + 1;
	return withRenderCleanup(() => {
		const props = serverComponentProps(reference);
		const publication = {
			capturesResumptions: options.resumptionCapture !== void 0,
			componentName: contract.artifact.id,
			componentKey: reference.key,
			componentOrdinal: context.nextId++,
			documentProbe: true,
			hasComponentAncestor: false
		};
		return mapRenderValue(executeDirectSsrComponent(context, contract, props, void 0, options, (content, owner, preparedProps, snapshot) => {
			const target = new SsrOperationTarget(context, owner, options, true, renderChildren);
			const render = () => content.program ? target.renderPreparedServerProgram(content.program) : renderChildren(context, content.children, owner, options, true);
			return mapRenderValue(content.program?.program.ssrHost === "html" || content.children?.length === 1 && (readCompiledIntrinsicReceipt(content.children[0])?.tag === "html" || readCompiledFragmentReceipt(content.children[0])?.children.some(readDoctype)) ? render() : captureSsrProgramOutput(context, render), (value) => directComponentHtml(context, value, preparedProps, snapshot.contract.artifact.execution.publication, publication));
		}, consumeScalarPropsProof(reference, props)), (value) => {
			if (value === void 0) throw new TypeError("Document root selected a non-direct server artifact");
			return value;
		});
	}, () => {
		context.enhancementOperationComponentDepth--;
		leaveSsrTreeDepth(context);
	});
}
//#endregion
//#region ../packages/ssr/dist/render/root-execution-cache.js
var rootBlueprints = /* @__PURE__ */ new WeakMap();
/** Attaches the reusable blueprint for a component root after output extensions select it. */
function attachSsrRootExecutionBlueprint(context, root) {
	const receipt = readServerComponentReference(root);
	if (receipt) {
		context.rootExecutionBlueprint = ssrRootExecutionBlueprint(receipt.contract.artifact.instantiate);
		return;
	}
}
/** Returns the stable cache object owned by one root component function. */
function ssrRootExecutionBlueprint(root) {
	let blueprint = rootBlueprints.get(root);
	if (!blueprint) {
		const components = /* @__PURE__ */ new WeakMap();
		blueprint = { resolve(component) {
			const rawContract = attachedValue(component, exactComponentContract);
			const componentId = exactComponentIdentity(component);
			const cached = components.get(component);
			if (cached && cached.rawContract === rawContract && cached.componentId === componentId) return cached.blueprint;
			const prepared = prepareComponentBlueprint(component);
			components.set(component, {
				rawContract,
				componentId,
				blueprint: prepared
			});
			return prepared;
		} };
		rootBlueprints.set(root, blueprint);
	}
	return blueprint;
}
function prepareComponentBlueprint(component) {
	const contract = readPreparedExactServerExecutableComponentContract(component);
	const componentId = exactComponentIdentity(component);
	return Object.freeze({
		componentId,
		contract
	});
}
function attachedValue(component, key) {
	return component[key];
}
//#endregion
//#region ../packages/ssr/dist/render/tree-output.js
/** Renders one tree under its caller's owner, returning completed output without a promise hop. */
function renderTreeOutput(operation, options, omitRootBoundary, outputKind = "html", destination, streamBufferSize) {
	if (options.outputExtensions?.length) return processExactOutput(operation, {
		kind: "operation",
		signal: options.signal
	}, options.outputExtensions).then((value) => renderSelectedTree(value, options, omitRootBoundary, outputKind));
	return renderSelectedTree(operation, options, omitRootBoundary, outputKind, destination, streamBufferSize);
}
function renderSelectedTree(operation, options, omitRootBoundary, outputKind, destination, streamBufferSize) {
	let renderOptions = withTaskDeadline(options);
	if (options.documentShell) {
		const scope = new DocumentShellScope(operation, {
			...renderOptions,
			documentShell: void 0
		});
		operation = options.documentShell(operation);
		renderOptions = {
			...renderOptions,
			documentShell: void 0,
			documentShellScope: scope,
			resumptionCapture: scope.capture
		};
		omitRootBoundary = false;
	}
	const context = createSsrContext(renderOptions);
	const sink = destination ? new DocumentStreamSink(context.maxOutputBytes, destination, streamBufferSize) : new DocumentStringSink(context.maxOutputBytes);
	context.writerSink = sink;
	return withRenderCleanup(() => renderCollectedTree(context, sink, operation, options, renderOptions, omitRootBoundary, outputKind), () => sink.destroy());
}
/** The request owns its destination across descendant rendering and output extensions. */
function renderCollectedTree(context, sink, operation, options, renderOptions, omitRootBoundary, outputKind) {
	attachSsrRootExecutionBlueprint(context, operation);
	let rendered;
	if (sink instanceof DocumentStreamSink || renderOptions.documentShellScope) rendered = renderDocumentRootOutput(context, operation, renderOptions);
	else if (omitRootBoundary) {
		const component = readServerComponentReference(operation);
		if (!component) throw new TypeError("Compiler root proof requires a component operation");
		countSsrNode(context);
		rendered = new SsrOperationTarget(context, void 0, renderOptions, false, renderChildren).renderCompilerClosedRootComponent(component);
	} else rendered = renderChildren(context, [operation], void 0, renderOptions);
	return mapRenderValue(rendered, (html) => {
		renderOptions.documentShellScope?.complete(context.documentRootSeen);
		if (html) sink.write(html);
		const completed = sink instanceof DocumentStringSink ? {
			chunks: sink.finishChunks(context.reactResourceHints),
			streamed: false
		} : mapRenderValue(sink.finish(context.reactResourceHints), ({ html, streamed }) => ({
			chunks: [html],
			streamed
		}));
		const finish = (chunks, streamed = false) => {
			const result = createChunkedStringResult(chunks, options.state, context.hydrationTable?.value(), context.resourceLinkHeaders ?? [], context.componentDomain && componentDomainUsesWallClock(context.componentDomain) ? context.wallClockSnapshot : void 0, streamed ? false : options.outputExtensions?.length ? void 0 : context.documentOutputs?.has("hydrationData") ?? false);
			if (streamed) result.streamedDocument = true;
			return result;
		};
		return mapRenderValue(completed, ({ chunks, streamed }) => {
			if (!options.outputExtensions?.length) return finish(chunks, streamed);
			return processExactOutput(chunks.length === 1 ? chunks[0] : chunks.join(""), {
				kind: outputKind,
				signal: options.signal
			}, options.outputExtensions).then((value) => {
				const html = value;
				assertOutputWithinLimit(context, html);
				return finish([html]);
			});
		});
	});
}
//#endregion
//#region ../packages/ssr/dist/render/render-output.js
/** Retains one render owner across actual suspension and releases it before public completion. */
function renderOwnedOutput(operation, options, omitRootBoundary, outputKind = "html") {
	const started = options.onProfile ? performance.now() : void 0;
	const owner = createSsrOwner();
	return withRenderCleanup(() => withTaskObserver(owner.observer, () => renderTreeOutput(operation, options, omitRootBoundary, outputKind)), () => {
		try {
			owner.dispose("ssr render complete");
		} finally {
			if (started !== void 0) publishExactProfile(options.onProfile, Object.freeze({
				subsystem: "ssr",
				phase: "render-to-string",
				elapsedMs: performance.now() - started
			}));
		}
	});
}
/** Captures component state once through the shared renderer and creates its hydration publication. */
async function renderHydratableOutput(operation, options = {}, omitRootBoundary = false) {
	options = withRequestRenderScheduling(options);
	if (options.scheduleRender) {
		options.signal?.throwIfAborted();
		const scheduled = options.scheduleRender(options.signal);
		if (scheduled) await scheduled;
		options.signal?.throwIfAborted();
	}
	const prepared = rootPropsOptions(operation, options);
	const capture = createSsrResumptionCapture(prepared, rootPropsForCapture(operation, prepared), rootComponentIdentity(operation));
	const rendered = renderOwnedOutput(operation, capture.options, omitRootBoundary);
	const result = rendered instanceof Promise ? await rendered : rendered;
	const resumptions = capture.serializedRecords();
	const emittedResumptions = resumptions.length ? () => capture.activations() : prepared.resumptions;
	const publicationOptions = hydrationScriptOptions(prepared, result, resumptions.length && prepared.outputExtensions?.length ? capture.activations() : prepared.resumptions);
	if (omitRootBoundary || options.documentShell) publicationOptions.markerlessRoot = true;
	return createChunkedHydratableResult(result, emittedResumptions, renderHydrationScript(publicationOptions, void 0, resumptions));
}
/**
* Produces shell, settlement, and hydration events with request-owned task cleanup.
* HTML consumers set settleDocumentShell because a published full document cannot
* use the fragment replacement protocol. Event-stream consumers retain replacements.
*/
async function streamDocumentRender(operation, options, emit, settleDocumentShell = false, abort = () => {}) {
	options = withRequestRenderScheduling(options);
	if (options.scheduleRender) {
		options.signal?.throwIfAborted();
		const scheduled = options.scheduleRender(options.signal);
		if (scheduled) await scheduled;
		options.signal?.throwIfAborted();
	}
	options = withTaskDeadline(rootPropsOptions(operation, options));
	if (options.documentShell) options = {
		...options,
		markerlessRoot: true
	};
	const owner = createSsrOwner();
	const scheduledShellComponents = [];
	const disposedShellComponents = /* @__PURE__ */ new Set();
	let primary = noPrimaryFailure;
	try {
		await emit({
			event: "start",
			version: 1
		});
		let capture = createSsrResumptionCapture(options, rootPropsForCapture(operation, options), rootComponentIdentity(operation));
		const shellOptions = {
			...capture.options,
			streamingScheduledComponents: scheduledShellComponents,
			settleDocumentShell
		};
		const shell = await withTaskObserver(owner.observer, () => renderTreeOutput(operation, shellOptions, false, "html", settleDocumentShell ? {
			head: (html) => emit({
				event: "head",
				version: 1,
				html
			}),
			body: (html) => emit({
				event: "body",
				version: 1,
				html
			}),
			abort
		} : void 0, options.streamBufferSize));
		const deferShell = settleDocumentShell && isExactDocumentHtml(shell.html) && (owner.pending.size > 0 || scheduledShellComponents.length > 0);
		if (!deferShell) await emit({
			event: "shell",
			version: 1,
			html: shell.html,
			streamed: shell.streamedDocument
		});
		let final = shell;
		if (owner.pending.size || scheduledShellComponents.length) {
			if (shell.streamedDocument) throw new Error("A committed document cannot be rerendered after body publication");
			await drainTasks(owner.pending, options.maxTaskPasses ?? 10, options.signal, options.taskDeadline);
			for (const component of scheduledShellComponents) {
				const pending = component.drain();
				if (pending instanceof Promise) await pending;
			}
			for (const component of scheduledShellComponents) {
				await component[Symbol.asyncDispose]();
				disposedShellComponents.add(component);
			}
			capture = createSsrResumptionCapture(options, rootPropsForCapture(operation, options), rootComponentIdentity(operation));
			final = await withTaskObserver(owner.observer, () => renderTreeOutput(operation, capture.options, false));
			if (!deferShell && final.html !== shell.html) {
				const replacements = planSuspenseStreamReplacements(shell.html, final.html);
				if (replacements) for (const replacement of replacements) await emit({
					event: "replace",
					version: 1,
					...replacement
				});
				else await emit({
					event: "replace",
					version: 1,
					id: options.rootId ?? "document",
					html: final.html
				});
			}
		}
		if (deferShell) await emit({
			event: "shell",
			version: 1,
			html: final.html
		});
		if (shouldEmitDocumentHydration(options)) {
			const resumptions = capture.serializedRecords();
			await emit({
				event: "hydration",
				version: 1,
				html: renderHydrationScript(hydrationScriptOptions(options, final, resumptions.length > 0 && options.outputExtensions?.length ? capture.activations() : options.resumptions), void 0, resumptions)
			});
		}
		await emit({
			event: "complete",
			version: 1
		});
	} catch (error) {
		primary = error;
		throw error;
	} finally {
		for (const component of scheduledShellComponents) {
			if (disposedShellComponents.has(component)) continue;
			try {
				await component[Symbol.asyncDispose]();
			} catch (cleanup) {
				if (primary === noPrimaryFailure) throw cleanup;
			}
		}
		disposePreservingPrimary(() => owner.dispose(options.signal?.reason ?? "ssr stream complete"), primary);
	}
}
//#endregion
//#region ../packages/ssr/dist/compiler-closed.js
/** Hydration shares capture and execution with ordinary roots while omitting the proven root marker. */
function renderCompilerClosedToHydratableString(operation, options = {}) {
	return renderHydratableOutput(operation, options, true);
}
/** Application-bundle-local enhancement components observed by a build adapter. */
var exactEnhancementCatalog = /* @__PURE__ */ new Map();
/** Supplies the bundle catalog unless a renderer caller provided an explicit catalog. */
function withExactEnhancementCatalog(options) {
	return options?.enhancementCatalog ? options : {
		...options,
		enhancementCatalog: exactEnhancementCatalog
	};
}
//#endregion
//#region ../packages/ssr/dist/stream/protocol.js
/** Runs all stream cleanup callbacks while retaining the first failure as the primary error. */
function cleanupAll(...callbacks) {
	const failure = createCleanupFailure();
	for (const callback of callbacks) attemptCleanup(failure, callback);
	throwCleanupFailure(failure);
}
/** Forwards cancellation from the request signal into the progressive render controller. */
function forwardAbort(source, target) {
	inheritRequestRenderScheduler(source, target.signal);
	if (!source) return () => void 0;
	const abort = () => target.abort(source.reason);
	if (source.aborted) abort();
	else source.addEventListener("abort", abort, { once: true });
	return () => source.removeEventListener("abort", abort);
}
/** Encodes one progressive HTML payload with the protocol framing expected by hydration. */
function progressiveHtmlChunk(event, options, document) {
	switch (event.event) {
		case "start": return "";
		case "head":
			document.head = event.html;
			return event.html;
		case "body": return event.html;
		case "shell":
			if (event.streamed) {
				document.head = void 0;
				document.tail = event.html;
				return "";
			}
			if (isExactDocumentHtml(event.html)) {
				const slot = event.html.indexOf(documentHydrationSlot);
				const bodyClose = slot >= 0 ? slot : findDocumentBodyClose(event.html);
				if (bodyClose < 0) throw new Error("Normalized eXact document output is missing its closing </body> element.");
				document.tail = event.html.slice(bodyClose);
				const head = document.head ?? "";
				if (!event.html.startsWith(head)) throw new Error("A published document head changed during task settlement.");
				document.head = void 0;
				return event.html.slice(head.length, bodyClose);
			}
			return `<div id="${escapeAttr(progressiveRootId(options))}">${event.html}</div>`;
		case "replace":
			if (document.tail !== void 0) throw new Error("A published full document shell cannot be replaced.");
			return scopedReplacementScript(event.id, event.html, options, document);
		case "hydration":
			if (document.tail !== void 0) {
				document.hydration = event.html;
				return "";
			}
			return event.html;
		case "complete":
			if (document.tail !== void 0) {
				const tail = document.tail.includes("<!--exact:document-hydration-->") ? fillDocumentHydration(document.tail, document.hydration ?? "") : document.hydration ? `<!--exact:framework-body:start-->${document.hydration}<!--exact:framework-body:end-->${document.tail}` : document.tail;
				document.tail = void 0;
				document.hydration = void 0;
				return tail;
			}
			return "";
		case "error": return inlineScript(`console.error("eXact document stream failed");`, options);
	}
}
/** Performs the progressive root id domain operation. */
function progressiveRootId(options) {
	return options.rootId ?? "exact-root";
}
/** Serializes a progressive-render failure into a safe inline client notification script. */
function progressiveErrorScript(error, options) {
	if (options.progressiveMode === "inert") return `<template data-exact-progressive-error="true"></template>`;
	return inlineScript(`console.error("eXact document stream failed");`, options);
}
/** Emits the script that replaces one resolved server boundary without touching sibling ranges. */
function scopedReplacementScript(id, html, options, documentState) {
	if (options.progressiveMode === "inert") return `<template data-exact-progressive-payload="${escapeAttr(JSON.stringify({
		version: 1,
		operation: "replace",
		id,
		html
	}))}"></template>`;
	const rootId = inlineJsonString(progressiveRootId(options));
	const targetId = inlineJsonString(id);
	const content = inlineJsonString(html);
	if (documentState) {
		const reference = documentState.replacementHelper ??= progressiveHelperName(progressiveRootId(options));
		const call = `${reference}(${targetId},${content});`;
		if (documentState.helperEmitted) return inlineScript(call, options);
		documentState.helperEmitted = true;
		return inlineScript(`globalThis.${reference}=function(i,h){var r=document.getElementById(${rootId});if(!r||r.getAttribute("data-exact-hydrated")==="true"){delete globalThis.${reference};return}var e=document.getElementById(i),t=document.createElement("template");t.innerHTML=h;if(e&&(e===r||r.contains(e)))e.replaceChildren(t.content);else{var w=document.createTreeWalker(r,128),s=null,n;while(n=w.nextNode())if(n.data==="exact:"+i){s=n;break}if(s){var p=s.parentNode,x=s;while(x&&!(x.nodeType===8&&x.data==="/exact:"+i))x=x.nextSibling;if(x){var a=x.nextSibling;p.insertBefore(t.content,s);while(s!==a){var q=s.nextSibling;p.removeChild(s);s=q}}}}};` + call, options);
	}
	return inlineScript(`var r=document.getElementById(${rootId});if(r&&r.getAttribute("data-exact-hydrated")!=="true"){var i=${targetId},e=document.getElementById(i),t=document.createElement("template");t.innerHTML=${content};if(e&&(e===r||r.contains(e)))e.replaceChildren(t.content);else{var w=document.createTreeWalker(r,128),s=null,n;while(n=w.nextNode())if(n.data==="exact:"+i){s=n;break}if(s){var p=s.parentNode,x=s;while(x&&!(x.nodeType===8&&x.data==="/exact:"+i))x=x.nextSibling;if(x){var a=x.nextSibling;p.insertBefore(t.content,s);while(s!==a){var q=s.nextSibling;p.removeChild(s);s=q}}}}}`, options);
}
function progressiveHelperName(rootId) {
	let hash = 2166136261;
	for (let index = 0; index < rootId.length; index++) {
		hash ^= rootId.charCodeAt(index);
		hash = Math.imul(hash, 16777619);
	}
	return `__xR${(hash >>> 0).toString(36)}`;
}
/** Performs the inline script domain operation. */
function inlineScript(body, options) {
	return `<script${options.nonce === void 0 ? "" : ` nonce="${escapeAttr(options.nonce)}"`}>${body}<\/script>`;
}
/** Performs the inline json string domain operation. */
function inlineJsonString(value) {
	return JSON.stringify(value).replace(/</g, "\\u003C").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
}
new TextEncoder();
new TextEncoder();
//#endregion
//#region ../packages/ssr/dist/stream/creation.js
/** Creates a progressive html stream. */
function createProgressiveHtmlStream(render, options) {
	const bufferSize = options.streamBufferSize ?? 8192;
	if (!Number.isSafeInteger(bufferSize) || bufferSize < 1) throw new RangeError("streamBufferSize must be a positive safe integer");
	const streamOptions = {
		...options,
		rootId: progressiveRootId(options)
	};
	const abortController = new AbortController();
	const unlink = forwardAbort(options.signal, abortController);
	streamOptions.signal = abortController.signal;
	let closed = false;
	let resume;
	const maxEvents = normalizeProtocolLimit(options.maxStreamEvents, 1e5);
	const maxBytes = normalizeProtocolLimit(options.maxStreamBytes, 16777216);
	let events = 0;
	let bytes = 0;
	const documentState = {};
	let production;
	const wake = () => {
		const ready = resume;
		resume = void 0;
		ready?.();
	};
	abortController.signal.addEventListener("abort", wake, { once: true });
	const cleanup = () => cleanupAll(() => abortController.signal.removeEventListener("abort", wake), unlink);
	return new ReadableStream({
		start(controller) {
			const waitForDemand = () => {
				if (closed || abortController.signal.aborted) throw abortController.signal.reason ?? new DOMException("SSR stream aborted", "AbortError");
				if ((controller.desiredSize ?? 0) > 0) return;
				return new Promise((resolve) => {
					resume = resolve;
				}).then(waitForDemand);
			};
			const emit = (chunk) => {
				const encoded = encodeSsrUtf8(chunk);
				if (++events > maxEvents) throw new Error("SSR stream event limit exceeded");
				bytes += encoded.byteLength;
				if (bytes > maxBytes) throw new Error("SSR stream byte limit exceeded");
				const ready = waitForDemand();
				if (ready instanceof Promise) return ready.then(() => {
					controller.enqueue(encoded);
				});
				controller.enqueue(encoded);
			};
			production = Promise.resolve().then(() => render(streamOptions, (event) => {
				const chunk = progressiveHtmlChunk(event, streamOptions, documentState);
				return chunk ? emit(chunk) : waitForDemand();
			}, (reason) => abortController.abort(reason))).then(() => {
				if (closed) return;
				closed = true;
				try {
					cleanup();
					controller.close();
				} catch (cleanupError) {
					controller.error(cleanupError);
				}
			}).catch((error) => {
				if (closed) return;
				if (abortController.signal.aborted) {
					closed = true;
					const reason = abortController.signal.reason ?? new DOMException("SSR stream aborted", "AbortError");
					try {
						cleanup();
					} catch (cleanupError) {
						attachSuppressedCleanupFailure(reason, cleanupError);
					}
					controller.error(reason);
					return;
				}
				logFrameworkEvent("error", "ssr", "stream", "progressive document render failed", error, options.logger);
				return Promise.resolve().then(() => emit(progressiveErrorScript(error, streamOptions))).then(() => {
					if (!closed) {
						closed = true;
						try {
							cleanup();
							controller.close();
						} catch (cleanupError) {
							controller.error(cleanupError);
						}
					}
				}, (emitError) => {
					if (!closed) {
						closed = true;
						try {
							cleanup();
						} catch (cleanupError) {
							attachSuppressedCleanupFailure(emitError, cleanupError);
						}
						controller.error(emitError);
					}
				});
			});
		},
		pull() {
			const ready = resume;
			resume = void 0;
			ready?.();
		},
		cancel(reason) {
			closed = true;
			resume?.();
			resume = void 0;
			abortController.abort(reason);
			cleanup();
			return production;
		}
	}, {
		highWaterMark: bufferSize * 4,
		size: (chunk) => chunk.byteLength
	});
}
//#endregion
//#region ../packages/ssr/dist/render/entrypoints.js
/** Transforms to progressive html stream into its required representation. */
function renderToProgressiveHtmlStream(operation, options = {}) {
	return createProgressiveHtmlStream((streamOptions, emit, abort) => streamDocumentRender(operation, streamOptions, emit, true, abort), options);
}
/** Transforms to hydratable progressive html stream into its required representation. */
function renderToHydratableProgressiveHtmlStream$1(operation, options = {}) {
	return renderToProgressiveHtmlStream(operation, {
		...options,
		hydration: options.hydration ?? true
	});
}
//#endregion
//#region ../packages/ssr/dist/enhanced.js
/** Progressively streams hydratable HTML with application enhancement metadata. */
var renderToHydratableProgressiveHtmlStream = (operation, options) => renderToHydratableProgressiveHtmlStream$1(operation, withExactEnhancementCatalog(options));
//#endregion
//#region participants/exact/src/Document.tsx
var __exactComponentContract_1$3 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
var __exact_render_program_1$2 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xB6drRBHtavQ7vcct-kKyMj",
	namespace: "html",
	ssrRootStatic: [
		" data-exact-id=\"xxgDHyO_-_cdTqlyAzbxcza\" type=\"module\"",
		["data-exact-id", "type"],
		[[
			3,
			"src",
			"src"
		]],
		(__exactRootValue) => ({
			"data-exact-id": "xxgDHyO_-_cdTqlyAzbxcza",
			type: "module",
			src: __exactRootValue
		})
	],
	ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
		const __exactValue_0 = __exactInvocation.eagerValues[0];
		__exactSsr.begin(__exactContext, 1, 1, 17, 17);
		let __exactCharacters = 17;
		__exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "script", "<script", "><\/script>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
		const __exactDrain = __exactOutput.sink.ready();
		if (__exactDrain) return __exactDrain.then(() => __exactOutput);
		return __exactOutput;
	},
	ssrHost: "script"
});
var __exact_render_program_2$1 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xJd_ErUHsicehDOKXjF3Hqo",
	namespace: "html",
	ssrRootStatic: [
		" rel=\"stylesheet\"",
		["rel"],
		[[
			3,
			"href",
			"href"
		]],
		(__exactRootValue) => ({
			rel: "stylesheet",
			href: __exactRootValue
		})
	],
	ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
		const __exactValue_0 = __exactInvocation.eagerValues[0];
		__exactSsr.begin(__exactContext, 1, 1, 6, 6);
		let __exactCharacters = 6;
		__exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "link", "<link", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
		const __exactDrain = __exactOutput.sink.ready();
		if (__exactDrain) return __exactDrain.then(() => __exactOutput);
		return __exactOutput;
	},
	ssrHost: "link"
});
var __exact_render_program_3$2 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xuqT7xiu1CmGeHEuU1vVF0J",
	namespace: "html",
	ssrRootStatic: [
		" data-exact-id=\"xh58CxrcqvR7H0DFNXbaLz0\"",
		["data-exact-id"],
		[]
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactValue_2, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactValue_2 = __exactFrame[8];
			__exactCharacters = __exactFrame[9];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactValue_2 = __exactSsr.prepareChild(__exactInvocation, 2);
			if (__exactValue_2 === __exactSsr.unprepared) return;
			__exactSsr.begin(__exactContext, 5, 3, 190, 190);
			__exactCharacters = 190;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "head", "<head", "><meta charSet=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"><meta name=\"framework-participant\" content=\"exact\"><title>Incident Operations</title>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2:
				__exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_1);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 3;
					break;
				}
			case 3:
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4:
				__exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_2);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 5;
					break;
				}
			case 5:
				const __exactDrain_2 = __exactOutput.sink.ready();
				if (__exactDrain_2) {
					__exactPending = __exactDrain_2;
					__exactStage = 6;
					break;
				}
			case 6: __exactSettled = __exactSsr.static(__exactOutput, "</head>");
			case 7:
				const __exactDrain_3 = __exactOutput.sink.ready();
				if (__exactDrain_3) {
					__exactPending = __exactDrain_3;
					__exactStage = 8;
					break;
				}
			case 8: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactValue_2,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	targetSlots: [1, 2],
	ssrHost: "head"
});
var __exact_render_program_4$2 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xu40DJnkorcVJ_51p6hPEQo",
	namespace: "html",
	ssrRootStatic: [
		" id=\"app\" data-render-mode=\"ssr\"",
		["id", "data-render-mode"],
		[]
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactCharacters = __exactFrame[8];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactSsr.begin(__exactContext, 1, 2, 11, 11);
			__exactCharacters = 11;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "div", "<div", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2:
				__exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_1);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 3;
					break;
				}
			case 3:
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4: __exactSettled = __exactSsr.static(__exactOutput, "</div>");
			case 5:
				const __exactDrain_2 = __exactOutput.sink.ready();
				if (__exactDrain_2) {
					__exactPending = __exactDrain_2;
					__exactStage = 6;
					break;
				}
			case 6: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	targetSlots: [1],
	ssrHost: "div"
});
var __exact_render_program_5$1 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xNCu7a6e4phbj7F8rZJfv7y",
	namespace: "html",
	ssrRootStatic: [
		" data-exact-id=\"x4JAyb3vMKcSi3Allva9HnQ\"",
		["data-exact-id"],
		[]
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactCharacters = __exactFrame[8];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactSsr.begin(__exactContext, 1, 2, 13, 13);
			__exactCharacters = 13;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "body", "<body", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2:
				__exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_1);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 3;
					break;
				}
			case 3:
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4: __exactSettled = __exactSsr.static(__exactOutput, "</body>", 0);
			case 5:
				const __exactDrain_2 = __exactOutput.sink.ready();
				if (__exactDrain_2) {
					__exactPending = __exactDrain_2;
					__exactStage = 6;
					break;
				}
			case 6: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	targetSlots: [1],
	ssrHost: "body"
});
var __exact_render_program_6$2 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "x8Kqh7MrletfWdoQB7juXNl",
	namespace: "html",
	ssrRootStatic: [
		" data-exact-id=\"xmMnSkpjpiR226JKA1JFg4P\" lang=\"en\"",
		["data-exact-id", "lang"],
		[]
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactValue_2, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactValue_2 = __exactFrame[8];
			__exactCharacters = __exactFrame[9];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactValue_2 = __exactSsr.prepareChild(__exactInvocation, 2);
			if (__exactValue_2 === __exactSsr.unprepared) return;
			__exactSsr.begin(__exactContext, 1, 3, 13, 13);
			__exactCharacters = 13;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "html", "<html", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2:
				__exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_1);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 3;
					break;
				}
			case 3:
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4:
				__exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_2);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 5;
					break;
				}
			case 5:
				const __exactDrain_2 = __exactOutput.sink.ready();
				if (__exactDrain_2) {
					__exactPending = __exactDrain_2;
					__exactStage = 6;
					break;
				}
			case 6: __exactSettled = __exactSsr.static(__exactOutput, "</html>");
			case 7:
				const __exactDrain_3 = __exactOutput.sink.ready();
				if (__exactDrain_3) {
					__exactPending = __exactDrain_3;
					__exactStage = 8;
					break;
				}
			case 8: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactValue_2,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	targetSlots: [1, 2],
	ssrHost: "html"
});
var __exactImplementation_Document_1 = function Document(props) {
	return createPreparedServerRenderProgram(__exact_render_program_6$2, [
		{
			"data-exact-id": "xmMnSkpjpiR226JKA1JFg4P",
			lang: "en"
		},
		createPreparedServerRenderProgram(__exact_render_program_3$2, [
			{ "data-exact-id": "xh58CxrcqvR7H0DFNXbaLz0" },
			createCompiledChildRangeReceipt(() => this.map(scriptSources(props.clientTags), (__exactItem) => __exactItem, (src) => createPreparedServerRenderProgram(__exact_render_program_1$2, [src]), "xvf3T5HGIUrl40rMp5esMVu", void 0, void 0), "xzYyMFFNhALHUjacs3bHHDA"),
			createCompiledChildRangeReceipt(() => this.map(stylesheetSources(props.clientTags), (__exactItem) => __exactItem, (href) => createPreparedServerRenderProgram(__exact_render_program_2$1, [href]), "xyNx2cj5WuRp_jQVCOk3Abv", void 0, void 0), "xMNTPDImSpCs4pU81G7-A2Z")
		]),
		createPreparedServerRenderProgram(__exact_render_program_5$1, [{ "data-exact-id": "x4JAyb3vMKcSi3Allva9HnQ" }, createPreparedServerRenderProgram(__exact_render_program_4$2, [{
			id: "app",
			"data-render-mode": "ssr"
		}, props.children])])
	]);
};
var Document = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Document_1, {
	[Symbol.for("@exactjs/component")]: "xMvQadpMFn8GXwCStvpQyxw",
	[__exactComponentContract_1$3]: {
		version: 2,
		placement: "isomorphic",
		role: "render",
		implementations: [{
			id: "xbPmHTXZrWmswHPxTiPsdyn",
			name: "Document",
			role: "root",
			implementation: __exactImplementation_Document_1
		}],
		continuations: [],
		executors: [],
		boundaries: [],
		artifact: {
			version: 2,
			target: "server",
			id: "xMvQadpMFn8GXwCStvpQyxw",
			instantiate: __exactImplementation_Document_1,
			construct: rejectDirectServerComponentConstruction,
			abi: 1,
			capabilities: [],
			state: [],
			props: ["children", "clientTags"],
			issue: issueExactServerComponent,
			write: writeExactServerComponent,
			dispose: disposeExactServerComponent,
			execution: {
				version: 1,
				classification: "synchronous",
				lane: "direct",
				documentRoot: true,
				render: __exactImplementation_Document_1,
				mode: "stateless"
			}
		}
	}
}))();
function scriptSources(tags = "") {
	return Array.from(tags.matchAll(/<script\b[^>]*\bsrc="([^"]+)"/g), (match) => match[1]);
}
function stylesheetSources(tags = "") {
	return Array.from(tags.matchAll(/<link\b[^>]*\bhref="([^"]+)"/g), (match) => match[1]);
}
//#endregion
//#region ../packages/ssr/dist/render/client-boundary-validation.js
/** Describes a non-serializable value found in one compiler-owned client boundary payload. */
function clientBoundarySerializationMessage(name, id, unsafePath) {
	const label = name || id;
	const location = name && id ? `${label} (${id})` : label;
	const generatedBucket = clientBoundaryGeneratedBucket(unsafePath);
	return `Client boundary ${location} props must be JSON-serializable; non-serializable value at ${unsafePath}${generatedBucket ? ` in generated ${generatedBucket} payload` : ""}`;
}
/** Identifies which generated boundary payload bucket owns a rejected value. */
function clientBoundaryGeneratedBucket(path) {
	return /^\$\.(__exact[A-Za-z0-9_$]*)(?:\.|\[|$)/.exec(path)?.[1];
}
//#endregion
//#region ../packages/ssr/dist/render/reactive-tracking-capability.js
var capabilityName = "reactive-peek";
/** Reads plain compiler-owned props directly or suppresses tracking in a generic reactive lane. */
function withSsrReactivePeek(work) {
	return ssrCapabilities[capabilityName]?.(work) ?? work();
}
//#endregion
//#region ../packages/ssr/dist/render/prepared-resumption-boundary.js
/** Serializes a compiler-selected resumption boundary without reopening its component contract. */
function renderPreparedResumptionBoundary(context, id, name, html, props, resumptions) {
	const data = {
		props: withSsrReactivePeek(() => snapshotResumptionProps(props)),
		...resumptions ? { resumptions } : {}
	};
	const unsafePath = jsonUnsafePath(data);
	if (unsafePath) throw new Error(clientBoundarySerializationMessage(name, id, unsafePath));
	const payload = serializeHydrationPayload(data);
	const opening = `<div data-exact-client-boundary="${escapeAttr(id)}" data-exact-client-name="${escapeAttr(name)}" data-exact-client-props="${escapeAttr(payload)}" data-exact-client-resumption="true">`;
	context.outputSink?.account(opening);
	context.outputSink?.accountKnown("</div>", 6);
	const boundary = `${opening}${html}</div>`;
	return finalizedMarkerPair(context, markerId(context, "client-boundary", name, id), boundary);
}
/** Detaches resumable boundary props from reactive proxies without invoking accessors. */
function snapshotResumptionProps(value, seen = /* @__PURE__ */ new WeakMap()) {
	return snapshotResumptionValueWithPolicy(value, seen, true);
}
function snapshotResumptionValueWithPolicy(value, seen, evaluateReactiveValues) {
	if (isReactiveValue(value)) {
		if (!evaluateReactiveValues) return value;
		value = unwrap(value);
	}
	const raw = isReactive(value) ? unwrap(value) : value;
	if (!raw || typeof raw !== "object") return raw;
	if (!Array.isArray(raw) && Object.getPrototypeOf(raw) !== Object.prototype) return raw;
	const previous = seen.get(raw);
	if (previous) return previous;
	const output = Array.isArray(raw) ? [] : {};
	seen.set(raw, output);
	for (const key of Object.keys(raw)) {
		const descriptor = Object.getOwnPropertyDescriptor(raw, key);
		if (!descriptor) continue;
		if (!("value" in descriptor)) {
			Object.defineProperty(output, key, {
				configurable: true,
				enumerable: true,
				get: descriptor.get
			});
			continue;
		}
		Object.defineProperty(output, key, {
			configurable: true,
			enumerable: true,
			writable: true,
			value: snapshotResumptionValueWithPolicy(descriptor.value, seen, evaluateReactiveValues && key !== "children")
		});
	}
	return output;
}
//#endregion
//#region ../packages/ssr/dist/runtime/resumption-boundaries.js
registerResumptionBoundaryCapability(renderPreparedResumptionBoundary);
//#endregion
//#region participants/exact/src/IncidentQueue.tsx
var __exactComponentContract_1$2 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
Object.assign(SeverityBadge, {
	[Symbol.for("@exactjs/component")]: "xp_5xgm5Jp-BAVGSHYKaUb-",
	[__exactComponentContract_1$2]: {
		version: 2,
		placement: "isomorphic",
		role: "render",
		implementations: [{
			id: "xXoUt883ISzKmMPNwwPjeeI",
			name: "SeverityBadge",
			role: "root",
			implementation: SeverityBadge
		}],
		continuations: [],
		executors: [],
		boundaries: [],
		artifact: {
			version: 2,
			target: "server",
			id: "xp_5xgm5Jp-BAVGSHYKaUb-",
			instantiate: SeverityBadge,
			construct: rejectDirectServerComponentConstruction,
			abi: 1,
			capabilities: [],
			state: [],
			props: ["severity"],
			issue: issueExactServerComponent,
			write: writeExactServerComponent,
			dispose: disposeExactServerComponent,
			execution: {
				version: 1,
				classification: "synchronous",
				lane: "direct",
				render: SeverityBadge,
				mode: "stateless"
			}
		}
	}
});
var __exact_server_invocation_1$1 = /* @__PURE__ */ createPreparedServerRenderProgram(/* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "x0zD5X2abUEe2H7Wc2itVjW",
	namespace: "html",
	ssrRootStatic: [
		" class=\"empty\"",
		["className"],
		[]
	],
	ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
		const __exactValue_0 = __exactInvocation.eagerValues[0];
		__exactSsr.begin(__exactContext, 1, 1, 25, 27);
		let __exactCharacters = 25;
		__exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "p", "<p", ">Loading incidents…</p>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
		const __exactDrain = __exactOutput.sink.ready();
		if (__exactDrain) return __exactDrain.then(() => __exactOutput);
		return __exactOutput;
	},
	ssrHost: "p"
}), [{ className: "empty" }]);
var __exact_server_invocation_2$1 = /* @__PURE__ */ createPreparedServerRenderProgram(/* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "x46hB2XUY5_EpPBx0BBAMp_",
	namespace: "html",
	ssrRootStatic: [
		" class=\"empty\"",
		["className"],
		[]
	],
	ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
		const __exactValue_0 = __exactInvocation.eagerValues[0];
		__exactSsr.begin(__exactContext, 1, 1, 41, 41);
		let __exactCharacters = 41;
		__exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "p", "<p", ">No incidents match this workspace.</p>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
		const __exactDrain = __exactOutput.sink.ready();
		if (__exactDrain) return __exactDrain.then(() => __exactOutput);
		return __exactOutput;
	},
	ssrHost: "p"
}), [{ className: "empty" }]);
var __exact_render_program_3$1 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xw8aN1VhGL_JEF3Rl41fWuM",
	namespace: "html",
	ssrRootStatic: [
		" role=\"alert\"",
		["role"],
		[]
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactCharacters = __exactFrame[8];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactSsr.begin(__exactContext, 1, 2, 7, 7);
			__exactCharacters = 7;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "p", "<p", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "", "</p>");
			case 3:
				__exactCharacters = __exactSettled;
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	ssrHost: "p"
});
var __exact_render_program_4$1 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xTXYJaGtLJXrAC1QEguZSBY",
	namespace: "html",
	ssrRootStatic: [
		" data-exact-id=\"xVVmvtOyJ36sM7JInUkwKxI\" type=\"button\" data-testid=\"incident-row\"",
		[
			"data-exact-id",
			"type",
			"data-testid"
		],
		[[
			7,
			"className",
			"class"
		]],
		(__exactRootValue) => ({
			"data-exact-id": "xVVmvtOyJ36sM7JInUkwKxI",
			type: "button",
			className: __exactRootValue,
			"data-testid": "incident-row"
		})
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactValue_2, __exactValue_3, __exactValue_4, __exactSibling_0, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactValue_2 = __exactFrame[8];
			__exactValue_3 = __exactFrame[9];
			__exactValue_4 = __exactFrame[10];
			__exactSibling_0 = __exactFrame[11];
			__exactCharacters = __exactFrame[12];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareComponentProps(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactValue_2 = __exactSsr.prepareText(__exactInvocation, 2);
			if (__exactValue_2 === __exactSsr.unprepared) return;
			__exactValue_3 = __exactSsr.prepareText(__exactInvocation, 3);
			if (__exactValue_3 === __exactSsr.unprepared) return;
			__exactValue_4 = __exactSsr.prepareText(__exactInvocation, 4);
			if (__exactValue_4 === __exactSsr.unprepared) return;
			__exactSibling_0 = __exactSsr.reference(SeverityBadge, __exactValue_1, "severity", __exactInvocation);
			if (__exactOutput.prepareReferences) __exactOutput.preparation = __exactOutput.prepareReferences([__exactSibling_0]);
			__exactSsr.begin(__exactContext, 3, 5, 52, 53);
			__exactCharacters = 52;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "button", "<button", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2:
				__exactSettled = __exactSsr.component(__exactContext, __exactOutput, __exactSibling_0, "0", __exactCharacters, true);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 3;
					break;
				}
			case 3:
				__exactCharacters = __exactSettled;
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_2, "1", __exactCharacters, true, "<strong>", "</strong><small>");
			case 5:
				__exactCharacters = __exactSettled;
				const __exactDrain_2 = __exactOutput.sink.ready();
				if (__exactDrain_2) {
					__exactPending = __exactDrain_2;
					__exactStage = 6;
					break;
				}
			case 6: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_3, "2", __exactCharacters, true, "", " · ");
			case 7:
				__exactCharacters = __exactSettled;
				const __exactDrain_3 = __exactOutput.sink.ready();
				if (__exactDrain_3) {
					__exactPending = __exactDrain_3;
					__exactStage = 8;
					break;
				}
			case 8: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_4, "3", __exactCharacters, true, "", "</small></button>");
			case 9:
				__exactCharacters = __exactSettled;
				const __exactDrain_4 = __exactOutput.sink.ready();
				if (__exactDrain_4) {
					__exactPending = __exactDrain_4;
					__exactStage = 10;
					break;
				}
			case 10: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactValue_2,
				__exactValue_3,
				__exactValue_4,
				__exactSibling_0,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	targetSlots: [1],
	ssrHost: "button"
});
var __exact_render_program_5 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xTMh6_0H_XirlTRIIScMVHJ",
	namespace: "html",
	ssrRootStatic: [
		" class=\"queue-panel\" aria-labelledby=\"queue-title\"",
		["className", "aria-labelledby"],
		[]
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactValue_2, __exactValue_3, __exactValue_4, __exactValue_5, __exactValue_6, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactValue_2 = __exactFrame[8];
			__exactValue_3 = __exactFrame[9];
			__exactValue_4 = __exactFrame[10];
			__exactValue_5 = __exactFrame[11];
			__exactValue_6 = __exactFrame[12];
			__exactCharacters = __exactFrame[13];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareAttribute(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactValue_2 = __exactSsr.prepareAttribute(__exactInvocation, 2);
			if (__exactValue_2 === __exactSsr.unprepared) return;
			__exactValue_3 = __exactSsr.prepareChild(__exactInvocation, 3);
			if (__exactValue_3 === __exactSsr.unprepared) return;
			__exactValue_4 = __exactSsr.prepareChild(__exactInvocation, 4);
			if (__exactValue_4 === __exactSsr.unprepared) return;
			__exactValue_5 = __exactSsr.prepareChild(__exactInvocation, 5);
			if (__exactValue_5 === __exactSsr.unprepared) return;
			__exactValue_6 = __exactSsr.prepareChild(__exactInvocation, 6);
			if (__exactValue_6 === __exactSsr.unprepared) return;
			__exactSsr.begin(__exactContext, 20, 7, 643, 643);
			__exactCharacters = 643;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "section", "<section", "><div class=\"section-heading\"><div><span class=\"eyebrow\">Active response</span><h2 id=\"queue-title\">Incident queue</h2></div><button type=\"button\" class=\"quiet\">Refresh</button></div><div class=\"filters\"><label>Severity <select", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2: __exactSettled = __exactSsr.compiledAttribute(__exactContext, __exactOutput, __exactValue_1, 0, "value", "value", "select", __exactCharacters);
			case 3:
				__exactCharacters = __exactSettled;
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4: __exactSettled = __exactSsr.static(__exactOutput, "><option value=\"all\">All</option><option value=\"critical\">Critical</option><option value=\"high\">High</option><option value=\"medium\">Medium</option></select></label><label>Status <select");
			case 5:
				const __exactDrain_2 = __exactOutput.sink.ready();
				if (__exactDrain_2) {
					__exactPending = __exactDrain_2;
					__exactStage = 6;
					break;
				}
			case 6: __exactSettled = __exactSsr.compiledAttribute(__exactContext, __exactOutput, __exactValue_2, 0, "value", "value", "select", __exactCharacters);
			case 7:
				__exactCharacters = __exactSettled;
				const __exactDrain_3 = __exactOutput.sink.ready();
				if (__exactDrain_3) {
					__exactPending = __exactDrain_3;
					__exactStage = 8;
					break;
				}
			case 8: __exactSettled = __exactSsr.static(__exactOutput, "><option value=\"all\">All</option><option value=\"open\">Open</option><option value=\"investigating\">Investigating</option><option value=\"closed\">Closed</option></select></label></div>");
			case 9:
				const __exactDrain_4 = __exactOutput.sink.ready();
				if (__exactDrain_4) {
					__exactPending = __exactDrain_4;
					__exactStage = 10;
					break;
				}
			case 10:
				__exactSettled = __exactSsr.child(__exactContext, __exactOutput, __exactValue_3, "0", __exactCharacters);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 11;
					break;
				}
			case 11:
				__exactCharacters = __exactSettled;
				const __exactDrain_5 = __exactOutput.sink.ready();
				if (__exactDrain_5) {
					__exactPending = __exactDrain_5;
					__exactStage = 12;
					break;
				}
			case 12:
				__exactSettled = __exactSsr.child(__exactContext, __exactOutput, __exactValue_4, "1", __exactCharacters);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 13;
					break;
				}
			case 13:
				__exactCharacters = __exactSettled;
				const __exactDrain_6 = __exactOutput.sink.ready();
				if (__exactDrain_6) {
					__exactPending = __exactDrain_6;
					__exactStage = 14;
					break;
				}
			case 14:
				__exactSettled = __exactSsr.child(__exactContext, __exactOutput, __exactValue_5, "2", __exactCharacters);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 15;
					break;
				}
			case 15:
				__exactCharacters = __exactSettled;
				const __exactDrain_7 = __exactOutput.sink.ready();
				if (__exactDrain_7) {
					__exactPending = __exactDrain_7;
					__exactStage = 16;
					break;
				}
			case 16: __exactSettled = __exactSsr.static(__exactOutput, "<div class=\"incident-list\">");
			case 17:
				const __exactDrain_8 = __exactOutput.sink.ready();
				if (__exactDrain_8) {
					__exactPending = __exactDrain_8;
					__exactStage = 18;
					break;
				}
			case 18:
				__exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_6);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 19;
					break;
				}
			case 19:
				const __exactDrain_9 = __exactOutput.sink.ready();
				if (__exactDrain_9) {
					__exactPending = __exactDrain_9;
					__exactStage = 20;
					break;
				}
			case 20: __exactSettled = __exactSsr.static(__exactOutput, "</div></section>");
			case 21:
				const __exactDrain_10 = __exactOutput.sink.ready();
				if (__exactDrain_10) {
					__exactPending = __exactDrain_10;
					__exactStage = 22;
					break;
				}
			case 22: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactValue_2,
				__exactValue_3,
				__exactValue_4,
				__exactValue_5,
				__exactValue_6,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	targetSlots: [
		3,
		4,
		5,
		6
	],
	ssrHost: "section"
});
var __exact_render_program_6$1 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xvl_yj1OcUKmFPTiMXPL_-V",
	namespace: "html",
	ssrRootStatic: [
		"",
		[],
		[[
			7,
			"className",
			"class"
		]],
		(__exactRootValue) => ({ className: __exactRootValue })
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactCharacters = __exactFrame[8];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactSsr.begin(__exactContext, 1, 2, 13, 13);
			__exactCharacters = 13;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "span", "<span", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "", "</span>");
			case 3:
				__exactCharacters = __exactSettled;
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	ssrHost: "span"
});
var __exactImplementation_IncidentQueue_1 = function IncidentQueue(props) {
	this.state.severity = "all";
	this.state.status = "all";
	const filteredIncidents = props.incidents.filter((incident) => (this.state.severity === "all" || incident.severity === this.state.severity) && (this.state.status === "all" || incident.status === this.state.status));
	return createPreparedServerRenderProgram(__exact_render_program_5, [
		{
			className: "queue-panel",
			"aria-labelledby": "queue-title"
		},
		this.state.severity ?? "",
		this.state.status ?? "",
		props.loading ? __exact_server_invocation_1$1 : null,
		!props.loading && props.incidents.length === 0 && !props.error ? __exact_server_invocation_2$1 : null,
		props.error ? createPreparedServerRenderProgram(__exact_render_program_3$1, [{ role: "alert" }, props.error]) : null,
		filteredIncidents.map((incident) => createPreparedServerKeyedChild(createPreparedServerRenderProgram(__exact_render_program_4$1, [
			"incident" + (incident.id === props.selectedId ? " active" : ""),
			{ severity: incident.severity },
			incident.title,
			incident.ownerId ? "Assigned" : "Unassigned",
			incident.status
		]), incident.id, true))
	]);
};
var IncidentQueue = /* @__PURE__ */ (() => Object.assign(__exactImplementation_IncidentQueue_1, {
	[Symbol.for("@exactjs/component")]: "xpIJOILUNwd859VP0fMOQEe",
	[__exactComponentContract_1$2]: {
		version: 2,
		placement: "isomorphic",
		role: "render",
		implementations: [{
			id: "xq9ToWizWE-mJa6TdN74oGK",
			name: "IncidentQueue_ExactServer_1",
			role: "server-part",
			implementation: __exactImplementation_IncidentQueue_1
		}],
		continuations: [],
		executors: [],
		boundaries: [
			{
				id: "xnKUaFEZttgQhw5_RqWXKTS",
				componentId: "xpIJOILUNwd859VP0fMOQEe",
				ownerComponentId: "xpIJOILUNwd859VP0fMOQEe",
				kind: "client-island"
			},
			{
				id: "xl0WjRhLDFkLWbNkaL3wvd3",
				componentId: "xpIJOILUNwd859VP0fMOQEe",
				ownerComponentId: "xpIJOILUNwd859VP0fMOQEe",
				kind: "client-island"
			},
			{
				id: "xaJFYOml7BBY32yamPeScmY",
				componentId: "xpIJOILUNwd859VP0fMOQEe",
				ownerComponentId: "xpIJOILUNwd859VP0fMOQEe",
				kind: "client-island"
			},
			{
				id: "xYG0UXUvD9fULtJlawtSFLw",
				componentId: "xpIJOILUNwd859VP0fMOQEe",
				ownerComponentId: "xpIJOILUNwd859VP0fMOQEe",
				kind: "client-island"
			}
		],
		artifact: {
			version: 2,
			target: "server",
			id: "xpIJOILUNwd859VP0fMOQEe",
			instantiate: __exactImplementation_IncidentQueue_1,
			construct: rejectDirectServerComponentConstruction,
			abi: 1,
			capabilities: [],
			state: ["severity", "status"],
			props: [
				"error",
				"incidents",
				"loading",
				"onRefresh",
				"onSelectedIdChanged",
				"selectedId"
			],
			serialization: [
				1,
				"incidents",
				[2, registerPositionalProjector([
					1,
					"id",
					0,
					"title",
					0,
					"severity",
					0,
					"status",
					0,
					"ownerId",
					0,
					"version",
					0,
					"updatedAt",
					0,
					"comments",
					[2, registerPositionalProjector([
						1,
						"id",
						0,
						"authorId",
						0,
						"body",
						0,
						"createdAt",
						0
					], 1, (value, depth, state, schema, Object, Array) => {
						if (++state.nodes > state.maxNodes || depth > state.maxDepth) return state.unsafe;
						if (!value || typeof value !== "object" || state.active.has(value)) return state.mismatch;
						state.active.add(value);
						try {
							if (Array.isArray(value) || Object.getPrototypeOf(value) !== Object.prototype || Object.keys(value).length !== 4) return state.mismatch;
							const output = new Array(4);
							if (!Object.hasOwn(value, "id")) return state.mismatch;
							const cell0 = value["id"];
							if (!state.validate(cell0, depth + 1, state)) return state.unsafe;
							output[0] = cell0;
							if (!Object.hasOwn(value, "authorId")) return state.mismatch;
							const cell1 = value["authorId"];
							if (!state.validate(cell1, depth + 1, state)) return state.unsafe;
							output[1] = cell1;
							if (!Object.hasOwn(value, "body")) return state.mismatch;
							const cell2 = value["body"];
							if (!state.validate(cell2, depth + 1, state)) return state.unsafe;
							output[2] = cell2;
							if (!Object.hasOwn(value, "createdAt")) return state.mismatch;
							const cell3 = value["createdAt"];
							if (!state.validate(cell3, depth + 1, state)) return state.unsafe;
							output[3] = cell3;
							return output;
						} finally {
							state.active.delete(value);
						}
					})]
				], 1, (value, depth, state, schema, Object, Array) => {
					if (++state.nodes > state.maxNodes || depth > state.maxDepth) return state.unsafe;
					if (!value || typeof value !== "object" || state.active.has(value)) return state.mismatch;
					state.active.add(value);
					try {
						if (Array.isArray(value) || Object.getPrototypeOf(value) !== Object.prototype || Object.keys(value).length !== 8) return state.mismatch;
						const output = new Array(8);
						if (!Object.hasOwn(value, "id")) return state.mismatch;
						const cell0 = value["id"];
						if (!state.validate(cell0, depth + 1, state)) return state.unsafe;
						output[0] = cell0;
						if (!Object.hasOwn(value, "title")) return state.mismatch;
						const cell1 = value["title"];
						if (!state.validate(cell1, depth + 1, state)) return state.unsafe;
						output[1] = cell1;
						if (!Object.hasOwn(value, "severity")) return state.mismatch;
						const cell2 = value["severity"];
						if (!state.validate(cell2, depth + 1, state)) return state.unsafe;
						output[2] = cell2;
						if (!Object.hasOwn(value, "status")) return state.mismatch;
						const cell3 = value["status"];
						if (!state.validate(cell3, depth + 1, state)) return state.unsafe;
						output[3] = cell3;
						if (!Object.hasOwn(value, "ownerId")) return state.mismatch;
						const cell4 = value["ownerId"];
						if (!state.validate(cell4, depth + 1, state)) return state.unsafe;
						output[4] = cell4;
						if (!Object.hasOwn(value, "version")) return state.mismatch;
						const cell5 = value["version"];
						if (!state.validate(cell5, depth + 1, state)) return state.unsafe;
						output[5] = cell5;
						if (!Object.hasOwn(value, "updatedAt")) return state.mismatch;
						const cell6 = value["updatedAt"];
						if (!state.validate(cell6, depth + 1, state)) return state.unsafe;
						output[6] = cell6;
						if (!Object.hasOwn(value, "comments")) return state.mismatch;
						const cell7 = state.project(value["comments"], schema, 16, depth + 1, state);
						if (cell7 === state.mismatch || cell7 === state.unsafe) return cell7;
						output[7] = cell7;
						return output;
					} finally {
						state.active.delete(value);
					}
				})],
				"selectedId",
				0,
				"onSelectedIdChanged",
				0,
				"loading",
				0,
				"error",
				0,
				"onRefresh",
				0
			],
			issue: issueExactServerComponent,
			write: writeExactServerComponent,
			dispose: disposeExactServerComponent,
			execution: {
				version: 1,
				classification: "synchronous",
				lane: "direct",
				render: __exactImplementation_IncidentQueue_1,
				mode: "direct"
			}
		}
	}
}))();
/** Renders the finite severity vocabulary with compiler-visible conditional classes. */
function SeverityBadge(props) {
	return createPreparedServerRenderProgram(__exact_render_program_6$1, ["severity" + (props.severity === "critical" ? " critical" : "") + (props.severity === "high" ? " high" : "") + (props.severity === "medium" ? " medium" : "") + (props.severity === "low" ? " low" : ""), props.severity]);
}
//#endregion
//#region participants/exact/src/IncidentDetail.tsx
var __exactComponentContract_1$1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
var __exact_render_program_1$1 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xGn9yDMZByLcAkQszHhw73F",
	namespace: "html",
	ssrRootStatic: [
		" class=\"detail-heading\"",
		["className"],
		[]
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactValue_2, __exactValue_3, __exactSibling_0, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactValue_2 = __exactFrame[8];
			__exactValue_3 = __exactFrame[9];
			__exactSibling_0 = __exactFrame[10];
			__exactCharacters = __exactFrame[11];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareComponentProps(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactValue_2 = __exactSsr.prepareText(__exactInvocation, 2);
			if (__exactValue_2 === __exactSsr.unprepared) return;
			__exactValue_3 = __exactSsr.prepareText(__exactInvocation, 3);
			if (__exactValue_3 === __exactSsr.unprepared) return;
			__exactSibling_0 = __exactSsr.reference(SeverityBadge, __exactValue_1, "severity", __exactInvocation);
			if (__exactOutput.prepareReferences) __exactOutput.preparation = __exactOutput.prepareReferences([__exactSibling_0]);
			__exactSsr.begin(__exactContext, 4, 4, 68, 68);
			__exactCharacters = 68;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "div", "<div", "><div>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2:
				__exactSettled = __exactSsr.component(__exactContext, __exactOutput, __exactSibling_0, "0", __exactCharacters, true);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 3;
					break;
				}
			case 3:
				__exactCharacters = __exactSettled;
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_2, "1", __exactCharacters, true, "<h2>", "</h2></div><span class=\"version\">");
			case 5:
				__exactCharacters = __exactSettled;
				const __exactDrain_2 = __exactOutput.sink.ready();
				if (__exactDrain_2) {
					__exactPending = __exactDrain_2;
					__exactStage = 6;
					break;
				}
			case 6: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_3, "2", __exactCharacters, true, "Version ", "</span></div>");
			case 7:
				__exactCharacters = __exactSettled;
				const __exactDrain_3 = __exactOutput.sink.ready();
				if (__exactDrain_3) {
					__exactPending = __exactDrain_3;
					__exactStage = 8;
					break;
				}
			case 8: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactValue_2,
				__exactValue_3,
				__exactSibling_0,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	targetSlots: [1],
	ssrHost: "div"
});
var __exact_render_program_2 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xGoOzEstYGnlEqUeszguUUG",
	namespace: "html",
	ssrRootStatic: [
		" class=\"facts\"",
		["className"],
		[]
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactValue_2, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactValue_2 = __exactFrame[8];
			__exactCharacters = __exactFrame[9];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactValue_2 = __exactSsr.prepareText(__exactInvocation, 2);
			if (__exactValue_2 === __exactSsr.unprepared) return;
			__exactSsr.begin(__exactContext, 7, 3, 104, 104);
			__exactCharacters = 104;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "div", "<div", "><div><span>Owner</span><strong>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "", "</strong></div><div><span>Status</span><strong>");
			case 3:
				__exactCharacters = __exactSettled;
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_2, "1", __exactCharacters, true, "", "</strong></div></div>");
			case 5:
				__exactCharacters = __exactSettled;
				const __exactDrain_2 = __exactOutput.sink.ready();
				if (__exactDrain_2) {
					__exactPending = __exactDrain_2;
					__exactStage = 6;
					break;
				}
			case 6: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactValue_2,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	ssrHost: "div"
});
var __exact_render_program_3 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xR_nsA8G9g5QkLTvDkssOag",
	namespace: "html",
	ssrRootStatic: [
		" class=\"alert\" role=\"alert\"",
		["className", "role"],
		[]
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactCharacters = __exactFrame[8];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactSsr.begin(__exactContext, 1, 2, 7, 7);
			__exactCharacters = 7;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "p", "<p", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "", "</p>");
			case 3:
				__exactCharacters = __exactSettled;
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	ssrHost: "p"
});
var __exact_render_program_4 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xII-QrjF90NFixbndGlKNmL",
	namespace: "html",
	ssrRootStatic: [
		" class=\"alert\" role=\"alert\"",
		["className", "role"],
		[]
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactCharacters = __exactFrame[8];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactSsr.begin(__exactContext, 1, 2, 7, 7);
			__exactCharacters = 7;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "p", "<p", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "", "</p>");
			case 3:
				__exactCharacters = __exactSettled;
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	ssrHost: "p"
});
var __exact_server_invocation_1 = /* @__PURE__ */ createPreparedServerRenderProgram(/* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "x0fg8wh83aPSirY8CRuZhqv",
	namespace: "html",
	ssrRootStatic: [
		" data-exact-id=\"xU4UiFslRMHjxJIEx6EZQBm\" type=\"button\" class=\"primary\"",
		[
			"data-exact-id",
			"type",
			"className"
		],
		[]
	],
	ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
		const __exactValue_0 = __exactInvocation.eagerValues[0];
		__exactSsr.begin(__exactContext, 1, 1, 31, 31);
		let __exactCharacters = 31;
		__exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "button", "<button", ">Claim incident</button>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
		const __exactDrain = __exactOutput.sink.ready();
		if (__exactDrain) return __exactDrain.then(() => __exactOutput);
		return __exactOutput;
	},
	ssrHost: "button"
}), [{
	"data-exact-id": "xU4UiFslRMHjxJIEx6EZQBm",
	type: "button",
	className: "primary"
}]);
var __exact_render_program_6 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xSyX9yz6saYjNvlddpw2QRx",
	namespace: "html",
	ssrRootStatic: [
		"",
		[],
		[]
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactCharacters = __exactFrame[8];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactSsr.begin(__exactContext, 1, 2, 17, 17);
			__exactCharacters = 17;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "strong", "<strong", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "", "</strong>");
			case 3:
				__exactCharacters = __exactSettled;
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	ssrHost: "strong"
});
var __exact_render_program_7 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xGe3aQxoCh1SOPPjW3lbm4t",
	namespace: "html",
	ssrRootStatic: [
		" class=\"analysis-card\"",
		["className"],
		[]
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactValue_2, __exactValue_3, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactValue_2 = __exactFrame[8];
			__exactValue_3 = __exactFrame[9];
			__exactCharacters = __exactFrame[10];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactValue_2 = __exactSsr.prepareChild(__exactInvocation, 2);
			if (__exactValue_2 === __exactSsr.unprepared) return;
			__exactValue_3 = __exactSsr.prepareAttribute(__exactInvocation, 3);
			if (__exactValue_3 === __exactSsr.unprepared) return;
			__exactSsr.begin(__exactContext, 5, 4, 134, 134);
			__exactCharacters = 134;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "section", "<section", "><div><h3>Server analysis</h3><p role=\"status\">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "", "</p>");
			case 3:
				__exactCharacters = __exactSettled;
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4:
				__exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_2);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 5;
					break;
				}
			case 5:
				const __exactDrain_2 = __exactOutput.sink.ready();
				if (__exactDrain_2) {
					__exactPending = __exactDrain_2;
					__exactStage = 6;
					break;
				}
			case 6: __exactSettled = __exactSsr.static(__exactOutput, "</div><button type=\"button\" class=\"quiet\"");
			case 7:
				const __exactDrain_3 = __exactOutput.sink.ready();
				if (__exactDrain_3) {
					__exactPending = __exactDrain_3;
					__exactStage = 8;
					break;
				}
			case 8: __exactSettled = __exactSsr.compiledAttribute(__exactContext, __exactOutput, __exactValue_3, 0, "disabled", "disabled", "button", __exactCharacters);
			case 9:
				__exactCharacters = __exactSettled;
				const __exactDrain_4 = __exactOutput.sink.ready();
				if (__exactDrain_4) {
					__exactPending = __exactDrain_4;
					__exactStage = 10;
					break;
				}
			case 10: __exactSettled = __exactSsr.static(__exactOutput, ">Start analysis</button></section>");
			case 11:
				const __exactDrain_5 = __exactOutput.sink.ready();
				if (__exactDrain_5) {
					__exactPending = __exactDrain_5;
					__exactStage = 12;
					break;
				}
			case 12: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactValue_2,
				__exactValue_3,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	targetSlots: [2],
	ssrHost: "section"
});
var __exact_server_invocation_2 = /* @__PURE__ */ createPreparedServerRenderProgram(/* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xaj_rhxatb7hP9vTVlAUhLx",
	namespace: "html",
	ssrRootStatic: [
		" class=\"empty\"",
		["className"],
		[]
	],
	ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
		const __exactValue_0 = __exactInvocation.eagerValues[0];
		__exactSsr.begin(__exactContext, 1, 1, 23, 23);
		let __exactCharacters = 23;
		__exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "p", "<p", ">No comments yet.</p>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
		const __exactDrain = __exactOutput.sink.ready();
		if (__exactDrain) return __exactDrain.then(() => __exactOutput);
		return __exactOutput;
	},
	ssrHost: "p"
}), [{ className: "empty" }]);
var __exact_render_program_9 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xCddtsRpoqg03a8u6gE8m22",
	namespace: "html",
	ssrRootStatic: [
		"",
		[],
		[]
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactValue_2, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactValue_2 = __exactFrame[8];
			__exactCharacters = __exactFrame[9];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactValue_2 = __exactSsr.prepareText(__exactInvocation, 2);
			if (__exactValue_2 === __exactSsr.unprepared) return;
			__exactSsr.begin(__exactContext, 3, 3, 43, 43);
			__exactCharacters = 43;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "article", "<article", "><strong>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "", "</strong><p>");
			case 3:
				__exactCharacters = __exactSettled;
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_2, "1", __exactCharacters, true, "", "</p></article>");
			case 5:
				__exactCharacters = __exactSettled;
				const __exactDrain_2 = __exactOutput.sink.ready();
				if (__exactDrain_2) {
					__exactPending = __exactDrain_2;
					__exactStage = 6;
					break;
				}
			case 6: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactValue_2,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	ssrHost: "article"
});
var __exact_render_program_10 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "x7uTT_EjJQbMgnGpY7p6zhF",
	namespace: "html",
	ssrRootStatic: [
		" class=\"comments\"",
		["className"],
		[]
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactValue_2, __exactValue_3, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactValue_2 = __exactFrame[8];
			__exactValue_3 = __exactFrame[9];
			__exactCharacters = __exactFrame[10];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactValue_2 = __exactSsr.prepareChild(__exactInvocation, 2);
			if (__exactValue_2 === __exactSsr.unprepared) return;
			__exactValue_3 = __exactSsr.prepareAttribute(__exactInvocation, 3);
			if (__exactValue_3 === __exactSsr.unprepared) return;
			__exactSsr.begin(__exactContext, 6, 4, 185, 185);
			__exactCharacters = 185;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "section", "<section", "><h3>Response log</h3>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2:
				__exactSettled = __exactSsr.child(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 3;
					break;
				}
			case 3:
				__exactCharacters = __exactSettled;
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4:
				__exactSettled = __exactSsr.child(__exactContext, __exactOutput, __exactValue_2, "1", __exactCharacters);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 5;
					break;
				}
			case 5:
				__exactCharacters = __exactSettled;
				const __exactDrain_2 = __exactOutput.sink.ready();
				if (__exactDrain_2) {
					__exactPending = __exactDrain_2;
					__exactStage = 6;
					break;
				}
			case 6: __exactSettled = __exactSsr.static(__exactOutput, "<form><label>New comment <textarea");
			case 7:
				const __exactDrain_3 = __exactOutput.sink.ready();
				if (__exactDrain_3) {
					__exactPending = __exactDrain_3;
					__exactStage = 8;
					break;
				}
			case 8: __exactSettled = __exactSsr.compiledAttribute(__exactContext, __exactOutput, __exactValue_3, 0, "value", "value", "textarea", __exactCharacters);
			case 9:
				__exactCharacters = __exactSettled;
				const __exactDrain_4 = __exactOutput.sink.ready();
				if (__exactDrain_4) {
					__exactPending = __exactDrain_4;
					__exactStage = 10;
					break;
				}
			case 10: __exactSettled = __exactSsr.static(__exactOutput, " maxLength=\"2000\" required></textarea></label><button type=\"submit\" class=\"primary\">Add comment</button></form></section>");
			case 11:
				const __exactDrain_5 = __exactOutput.sink.ready();
				if (__exactDrain_5) {
					__exactPending = __exactDrain_5;
					__exactStage = 12;
					break;
				}
			case 12: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactValue_2,
				__exactValue_3,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	targetSlots: [1, 2],
	ssrHost: "section"
});
var __exact_server_invocation_3 = /* @__PURE__ */ createPreparedServerRenderProgram(/* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xw06nSmfiYtmyJ3t1pU0CDz",
	namespace: "html",
	ssrRootStatic: [
		" class=\"empty\"",
		["className"],
		[]
	],
	ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
		const __exactValue_0 = __exactInvocation.eagerValues[0];
		__exactSsr.begin(__exactContext, 1, 1, 58, 58);
		let __exactCharacters = 58;
		__exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "p", "<p", ">Select an incident to inspect its response history.</p>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
		const __exactDrain = __exactOutput.sink.ready();
		if (__exactDrain) return __exactDrain.then(() => __exactOutput);
		return __exactOutput;
	},
	ssrHost: "p"
}), [{ className: "empty" }]);
var __exact_render_program_12 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xNYAbAdcBmuwUKhO1B3gvS5",
	namespace: "html",
	ssrRootStatic: [
		" class=\"detail-panel\" aria-label=\"Incident detail\"",
		["className", "aria-label"],
		[]
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactCharacters = __exactFrame[8];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactSsr.begin(__exactContext, 1, 2, 19, 19);
			__exactCharacters = 19;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "section", "<section", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2:
				__exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_1);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 3;
					break;
				}
			case 3:
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4: __exactSettled = __exactSsr.static(__exactOutput, "</section>");
			case 5:
				const __exactDrain_2 = __exactOutput.sink.ready();
				if (__exactDrain_2) {
					__exactPending = __exactDrain_2;
					__exactStage = 6;
					break;
				}
			case 6: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	targetSlots: [1],
	ssrHost: "section"
});
var __exactImplementation_IncidentDetail_1 = function IncidentDetail(props) {
	this.state;
	this.state.draft = "";
	this.state.conflict = "";
	this.state.job = null;
	this.state.busy = false;
	this.state.error = "";
	this.state.viewedIncidentId = peek(() => props.incident?.id ?? "");
	this.state.viewedVersion = peek(() => props.incident?.version ?? 0);
	const ownerName = props.users.find((user) => user.id === props.incident?.ownerId)?.name ?? "Unassigned";
	return createPreparedServerRenderProgram(__exact_render_program_12, [{
		className: "detail-panel",
		"aria-label": "Incident detail"
	}, props.incident ? [
		createPreparedServerRenderProgram(__exact_render_program_1$1, [
			{ className: "detail-heading" },
			{ severity: props.incident.severity },
			props.incident.title,
			props.incident.version
		]),
		createPreparedServerRenderProgram(__exact_render_program_2, [
			{ className: "facts" },
			ownerName,
			props.incident.status
		]),
		createCompiledChildRangeReceipt(() => this.state.conflict ? createPreparedServerRenderProgram(__exact_render_program_3, [{
			className: "alert",
			role: "alert"
		}, this.state.conflict]) : null, "xFpzqHiTxJF1XQ5lMx6ma0m"),
		createCompiledChildRangeReceipt(() => this.state.error ? createPreparedServerRenderProgram(__exact_render_program_4, [{
			className: "alert",
			role: "alert"
		}, this.state.error]) : null, "xot5kEg25UbhIjs5KLC5E8g"),
		__exact_server_invocation_1,
		createPreparedServerRenderProgram(__exact_render_program_7, [
			{ className: "analysis-card" },
			this.state.job ? `Analysis ${this.state.job.status}` : "Analysis has not started",
			this.state.job?.result ? createPreparedServerRenderProgram(__exact_render_program_6, [{}, this.state.job.result.finding]) : null,
			this.state.busy
		]),
		createPreparedServerRenderProgram(__exact_render_program_10, [
			{ className: "comments" },
			props.incident.comments.length === 0 ? __exact_server_invocation_2 : null,
			props.incident.comments.map((comment) => createPreparedServerKeyedChild(createPreparedServerRenderProgram(__exact_render_program_9, [
				{},
				props.users.find((user) => user.id === comment.authorId)?.name,
				comment.body
			]), comment.id, true)),
			this.state.draft ?? ""
		])
	] : __exact_server_invocation_3]);
};
var IncidentDetail = /* @__PURE__ */ (() => Object.assign(__exactImplementation_IncidentDetail_1, {
	[Symbol.for("@exactjs/component")]: "xIK8_9cLJrLkOKRWpREglkO",
	[__exactComponentContract_1$1]: {
		version: 2,
		placement: "isomorphic",
		role: "render",
		implementations: [{
			id: "xr1M4hLL9yGEsh067uAjdKY",
			name: "IncidentDetail_ExactServer_1",
			role: "server-part",
			implementation: __exactImplementation_IncidentDetail_1
		}],
		continuations: [],
		executors: [],
		boundaries: [
			{
				id: "xUIC2e9TWx_YlcAiNkeKGCG",
				componentId: "xIK8_9cLJrLkOKRWpREglkO",
				ownerComponentId: "xIK8_9cLJrLkOKRWpREglkO",
				kind: "client-island"
			},
			{
				id: "xeSMvWtrDoZRzuzWBl4oEFT",
				componentId: "xIK8_9cLJrLkOKRWpREglkO",
				ownerComponentId: "xIK8_9cLJrLkOKRWpREglkO",
				kind: "client-island"
			},
			{
				id: "x2OhUPQovUzSbolXPx8HovZ",
				componentId: "xIK8_9cLJrLkOKRWpREglkO",
				ownerComponentId: "xIK8_9cLJrLkOKRWpREglkO",
				kind: "client-island"
			}
		],
		artifact: {
			version: 2,
			target: "server",
			id: "xIK8_9cLJrLkOKRWpREglkO",
			instantiate: __exactImplementation_IncidentDetail_1,
			construct: rejectDirectServerComponentConstruction,
			abi: 1,
			capabilities: [],
			state: [
				"busy",
				"conflict",
				"draft",
				"error",
				"job",
				"viewedIncidentId",
				"viewedVersion"
			],
			props: [
				"incident",
				"onIncident",
				"sessionUserId",
				"users"
			],
			serialization: [
				1,
				"incident",
				[
					1,
					"id",
					0,
					"title",
					0,
					"severity",
					0,
					"status",
					0,
					"ownerId",
					0,
					"version",
					0,
					"updatedAt",
					0,
					"comments",
					[2, registerPositionalProjector([
						1,
						"id",
						0,
						"authorId",
						0,
						"body",
						0,
						"createdAt",
						0
					], 1, (value, depth, state, schema, Object, Array) => {
						if (++state.nodes > state.maxNodes || depth > state.maxDepth) return state.unsafe;
						if (!value || typeof value !== "object" || state.active.has(value)) return state.mismatch;
						state.active.add(value);
						try {
							if (Array.isArray(value) || Object.getPrototypeOf(value) !== Object.prototype || Object.keys(value).length !== 4) return state.mismatch;
							const output = new Array(4);
							if (!Object.hasOwn(value, "id")) return state.mismatch;
							const cell0 = value["id"];
							if (!state.validate(cell0, depth + 1, state)) return state.unsafe;
							output[0] = cell0;
							if (!Object.hasOwn(value, "authorId")) return state.mismatch;
							const cell1 = value["authorId"];
							if (!state.validate(cell1, depth + 1, state)) return state.unsafe;
							output[1] = cell1;
							if (!Object.hasOwn(value, "body")) return state.mismatch;
							const cell2 = value["body"];
							if (!state.validate(cell2, depth + 1, state)) return state.unsafe;
							output[2] = cell2;
							if (!Object.hasOwn(value, "createdAt")) return state.mismatch;
							const cell3 = value["createdAt"];
							if (!state.validate(cell3, depth + 1, state)) return state.unsafe;
							output[3] = cell3;
							return output;
						} finally {
							state.active.delete(value);
						}
					})]
				],
				"users",
				[2, [
					1,
					"id",
					0,
					"name",
					0
				]],
				"sessionUserId",
				0,
				"onIncident",
				0
			],
			issue: issueExactServerComponent,
			write: writeExactServerComponent,
			dispose: disposeExactServerComponent,
			execution: {
				version: 1,
				classification: "synchronous",
				lane: "direct",
				render: __exactImplementation_IncidentDetail_1,
				mode: "direct"
			}
		}
	}
}))();
//#endregion
//#region participants/exact/src/IncidentApp.tsx
var __exactComponentContract_1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
var __exact_render_program_1 = /* @__PURE__ */ prepareCompiledRenderProgram({
	version: 2,
	id: "xQR7oz3Y2cAWzwxg19gqJCZ",
	namespace: "html",
	ssrRootStatic: [
		" class=\"app-shell\"",
		["className"],
		[]
	],
	ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
		let __exactValue_0, __exactValue_1, __exactValue_2, __exactValue_3, __exactSibling_0, __exactSibling_1, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
		if (__exactFrame) {
			__exactValue_0 = __exactFrame[6];
			__exactValue_1 = __exactFrame[7];
			__exactValue_2 = __exactFrame[8];
			__exactValue_3 = __exactFrame[9];
			__exactSibling_0 = __exactFrame[10];
			__exactSibling_1 = __exactFrame[11];
			__exactCharacters = __exactFrame[12];
			__exactStage = __exactFrame[4];
			__exactSettled = __exactFrame[5];
		} else {
			__exactValue_0 = __exactInvocation.eagerValues[0];
			__exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
			if (__exactValue_1 === __exactSsr.unprepared) return;
			__exactValue_2 = __exactSsr.prepareComponentProps(__exactInvocation, 2);
			if (__exactValue_2 === __exactSsr.unprepared) return;
			__exactValue_3 = __exactSsr.prepareComponentProps(__exactInvocation, 3);
			if (__exactValue_3 === __exactSsr.unprepared) return;
			__exactSibling_0 = __exactSsr.reference(IncidentQueue, __exactValue_2);
			__exactSibling_1 = __exactSsr.reference(IncidentDetail, __exactValue_3);
			if (__exactOutput.prepareReferences) __exactOutput.preparation = __exactOutput.prepareReferences([__exactSibling_0, __exactSibling_1]);
			__exactSsr.begin(__exactContext, 7, 4, 184, 184);
			__exactCharacters = 184;
		}
		switch (__exactStage) {
			case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "div", "<div", "><header class=\"masthead\"><div><span class=\"eyebrow\">Operations workspace</span><h1>Signal Desk</h1></div><span class=\"connection\" role=\"status\">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
			case 1:
				__exactCharacters = __exactSettled;
				const __exactDrain_0 = __exactOutput.sink.ready();
				if (__exactDrain_0) {
					__exactPending = __exactDrain_0;
					__exactStage = 2;
					break;
				}
			case 2: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "", "</span></header><main>");
			case 3:
				__exactCharacters = __exactSettled;
				const __exactDrain_1 = __exactOutput.sink.ready();
				if (__exactDrain_1) {
					__exactPending = __exactDrain_1;
					__exactStage = 4;
					break;
				}
			case 4:
				__exactSettled = __exactSsr.component(__exactContext, __exactOutput, __exactSibling_0, "1", __exactCharacters);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 5;
					break;
				}
			case 5:
				__exactCharacters = __exactSettled;
				const __exactDrain_2 = __exactOutput.sink.ready();
				if (__exactDrain_2) {
					__exactPending = __exactDrain_2;
					__exactStage = 6;
					break;
				}
			case 6:
				__exactSettled = __exactSsr.component(__exactContext, __exactOutput, __exactSibling_1, "2", __exactCharacters, true);
				if (__exactSettled instanceof __exactSsr.promise) {
					__exactPending = __exactSettled;
					__exactStage = 7;
					break;
				}
			case 7:
				__exactCharacters = __exactSettled;
				const __exactDrain_3 = __exactOutput.sink.ready();
				if (__exactDrain_3) {
					__exactPending = __exactDrain_3;
					__exactStage = 8;
					break;
				}
			case 8: __exactSettled = __exactSsr.static(__exactOutput, "</main></div>");
			case 9:
				const __exactDrain_4 = __exactOutput.sink.ready();
				if (__exactDrain_4) {
					__exactPending = __exactDrain_4;
					__exactStage = 10;
					break;
				}
			case 10: return __exactOutput;
		}
		{
			const __exactSaved = [
				__exactSsr,
				__exactContext,
				__exactInvocation,
				__exactOutput,
				__exactStage,
				void 0,
				__exactValue_0,
				__exactValue_1,
				__exactValue_2,
				__exactValue_3,
				__exactSibling_0,
				__exactSibling_1,
				__exactCharacters
			];
			return __exactPending.then((__exactResult) => {
				__exactSaved[5] = __exactResult;
				return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
			});
		}
	},
	targetSlots: [2, 3],
	ssrHost: "div"
});
var __exactImplementation_IncidentApp_1 = function IncidentApp(props) {
	this.state;
	this.state.incidents = props.initialData?.incidents ?? [];
	this.state.users = props.initialData?.users ?? [];
	this.state.sessionUserId = props.initialData?.sessionUserId ?? "";
	((__exactDependency, { signal: __exactSignal }) => {
		this.state.selectedId = incidentIdFromPath(__exactDependency) || props.initialData?.incidents[0]?.id || "";
	})(props.path, { signal: void 0 });
	this.state.error = "";
	this.state.loading = !props.initialData;
	this.state.connection = "Connecting";
	if (!props.initialData);
	const selectedIncident = this.state.incidents.find((incident) => incident.id === this.state.selectedId);
	return createPreparedServerRenderProgram(__exact_render_program_1, [
		{ className: "app-shell" },
		this.state.connection,
		{
			"data-exact-id": "xzBnigJvUmbhZhkpExcYnSs",
			incidents: this.state.incidents,
			selectedId: this.state.selectedId,
			loading: this.state.loading,
			error: this.state.error
		},
		{
			"data-exact-id": "xyy05gJM3UC-zaWkxu1OqIQ",
			incident: selectedIncident,
			users: this.state.users,
			sessionUserId: this.state.sessionUserId
		}
	]);
};
var IncidentApp = /* @__PURE__ */ (() => Object.assign(__exactImplementation_IncidentApp_1, {
	[Symbol.for("@exactjs/component")]: "xuAKzNckgPuCTsehVDjqI5P",
	[__exactComponentContract_1]: {
		version: 2,
		placement: "isomorphic",
		role: "render",
		implementations: [{
			id: "xVIE45jdG-x2T8Mb6Kk8DNi",
			name: "IncidentApp_ExactServer_1",
			role: "server-part",
			implementation: __exactImplementation_IncidentApp_1
		}],
		continuations: [
			{
				kind: "task",
				id: "x9OSBlbvG7T5qm7V4wdvrRM",
				componentId: "xuAKzNckgPuCTsehVDjqI5P",
				readiness: "nonblocking",
				concurrency: "latest",
				dependencies: [{
					index: 0,
					source: "props",
					path: "props"
				}],
				stateReads: [],
				stateWrites: [{
					path: "incidents",
					kind: "write",
					confidence: "exact"
				}],
				publicContexts: [],
				serverContexts: [],
				contextWrites: [],
				serverContextWrites: [],
				boundaries: ["xMu3fuNmRjc6dWpuERPXhmv", "xOHhVB9dGpmnZm5koclWhiP"]
			},
			{
				kind: "task",
				id: "xLxsg7iiG6CWRZ4usss86CE",
				componentId: "xuAKzNckgPuCTsehVDjqI5P",
				readiness: "nonblocking",
				concurrency: "latest",
				dependencies: [{
					index: 0,
					source: "props",
					path: "props"
				}],
				stateReads: [],
				stateWrites: [{
					path: "loading",
					kind: "write",
					confidence: "exact"
				}],
				publicContexts: [],
				serverContexts: [],
				contextWrites: [],
				serverContextWrites: [],
				boundaries: ["xMu3fuNmRjc6dWpuERPXhmv", "xOHhVB9dGpmnZm5koclWhiP"]
			},
			{
				kind: "task",
				id: "xOoPEOF6bUljr4Dw7OyOZU2",
				componentId: "xuAKzNckgPuCTsehVDjqI5P",
				readiness: "nonblocking",
				concurrency: "latest",
				dependencies: [{
					index: 0,
					source: "props",
					path: "props"
				}],
				stateReads: [],
				stateWrites: [{
					path: "users",
					kind: "write",
					confidence: "exact"
				}],
				publicContexts: [],
				serverContexts: [],
				contextWrites: [],
				serverContextWrites: [],
				boundaries: ["xMu3fuNmRjc6dWpuERPXhmv", "xOHhVB9dGpmnZm5koclWhiP"]
			},
			{
				kind: "task",
				id: "xXZi24SYWDEBktbZWAMOKt9",
				componentId: "xuAKzNckgPuCTsehVDjqI5P",
				readiness: "nonblocking",
				concurrency: "latest",
				dependencies: [{
					index: 0,
					source: "props",
					path: "props"
				}],
				stateReads: [],
				stateWrites: [{
					path: "sessionUserId",
					kind: "write",
					confidence: "exact"
				}],
				publicContexts: [],
				serverContexts: [],
				contextWrites: [],
				serverContextWrites: [],
				boundaries: ["xMu3fuNmRjc6dWpuERPXhmv", "xOHhVB9dGpmnZm5koclWhiP"]
			},
			{
				kind: "task",
				id: "xs4mKJpgQea0Nym7aei2uXA",
				componentId: "xuAKzNckgPuCTsehVDjqI5P",
				readiness: "nonblocking",
				concurrency: "latest",
				dependencies: [{
					index: 0,
					source: "props",
					path: "props"
				}],
				stateReads: [],
				stateWrites: [{
					path: "selectedId",
					kind: "write",
					confidence: "exact"
				}],
				publicContexts: [],
				serverContexts: [],
				contextWrites: [],
				serverContextWrites: [],
				boundaries: ["xMu3fuNmRjc6dWpuERPXhmv", "xOHhVB9dGpmnZm5koclWhiP"]
			}
		],
		executors: [],
		boundaries: [{
			id: "xMu3fuNmRjc6dWpuERPXhmv",
			componentId: "xuAKzNckgPuCTsehVDjqI5P",
			ownerComponentId: "xuAKzNckgPuCTsehVDjqI5P",
			kind: "client-island"
		}, {
			id: "xOHhVB9dGpmnZm5koclWhiP",
			componentId: "xuAKzNckgPuCTsehVDjqI5P",
			ownerComponentId: "xuAKzNckgPuCTsehVDjqI5P",
			kind: "client-island"
		}],
		artifact: {
			version: 2,
			target: "server",
			id: "xuAKzNckgPuCTsehVDjqI5P",
			instantiate: __exactImplementation_IncidentApp_1,
			construct: rejectDirectServerComponentConstruction,
			abi: 1,
			capabilities: ["resumption"],
			state: [
				"connection",
				"error",
				"incidents",
				"loading",
				"selectedId",
				"sessionUserId",
				"users"
			],
			props: ["initialData", "path"],
			serialization: [
				1,
				"initialData",
				[
					1,
					"incidents",
					[2, registerPositionalProjector([
						1,
						"id",
						0,
						"title",
						0,
						"severity",
						0,
						"status",
						0,
						"ownerId",
						0,
						"version",
						0,
						"updatedAt",
						0,
						"comments",
						[2, registerPositionalProjector([
							1,
							"id",
							0,
							"authorId",
							0,
							"body",
							0,
							"createdAt",
							0
						], 1, (value, depth, state, schema, Object, Array) => {
							if (++state.nodes > state.maxNodes || depth > state.maxDepth) return state.unsafe;
							if (!value || typeof value !== "object" || state.active.has(value)) return state.mismatch;
							state.active.add(value);
							try {
								if (Array.isArray(value) || Object.getPrototypeOf(value) !== Object.prototype || Object.keys(value).length !== 4) return state.mismatch;
								const output = new Array(4);
								if (!Object.hasOwn(value, "id")) return state.mismatch;
								const cell0 = value["id"];
								if (!state.validate(cell0, depth + 1, state)) return state.unsafe;
								output[0] = cell0;
								if (!Object.hasOwn(value, "authorId")) return state.mismatch;
								const cell1 = value["authorId"];
								if (!state.validate(cell1, depth + 1, state)) return state.unsafe;
								output[1] = cell1;
								if (!Object.hasOwn(value, "body")) return state.mismatch;
								const cell2 = value["body"];
								if (!state.validate(cell2, depth + 1, state)) return state.unsafe;
								output[2] = cell2;
								if (!Object.hasOwn(value, "createdAt")) return state.mismatch;
								const cell3 = value["createdAt"];
								if (!state.validate(cell3, depth + 1, state)) return state.unsafe;
								output[3] = cell3;
								return output;
							} finally {
								state.active.delete(value);
							}
						})]
					], 1, (value, depth, state, schema, Object, Array) => {
						if (++state.nodes > state.maxNodes || depth > state.maxDepth) return state.unsafe;
						if (!value || typeof value !== "object" || state.active.has(value)) return state.mismatch;
						state.active.add(value);
						try {
							if (Array.isArray(value) || Object.getPrototypeOf(value) !== Object.prototype || Object.keys(value).length !== 8) return state.mismatch;
							const output = new Array(8);
							if (!Object.hasOwn(value, "id")) return state.mismatch;
							const cell0 = value["id"];
							if (!state.validate(cell0, depth + 1, state)) return state.unsafe;
							output[0] = cell0;
							if (!Object.hasOwn(value, "title")) return state.mismatch;
							const cell1 = value["title"];
							if (!state.validate(cell1, depth + 1, state)) return state.unsafe;
							output[1] = cell1;
							if (!Object.hasOwn(value, "severity")) return state.mismatch;
							const cell2 = value["severity"];
							if (!state.validate(cell2, depth + 1, state)) return state.unsafe;
							output[2] = cell2;
							if (!Object.hasOwn(value, "status")) return state.mismatch;
							const cell3 = value["status"];
							if (!state.validate(cell3, depth + 1, state)) return state.unsafe;
							output[3] = cell3;
							if (!Object.hasOwn(value, "ownerId")) return state.mismatch;
							const cell4 = value["ownerId"];
							if (!state.validate(cell4, depth + 1, state)) return state.unsafe;
							output[4] = cell4;
							if (!Object.hasOwn(value, "version")) return state.mismatch;
							const cell5 = value["version"];
							if (!state.validate(cell5, depth + 1, state)) return state.unsafe;
							output[5] = cell5;
							if (!Object.hasOwn(value, "updatedAt")) return state.mismatch;
							const cell6 = value["updatedAt"];
							if (!state.validate(cell6, depth + 1, state)) return state.unsafe;
							output[6] = cell6;
							if (!Object.hasOwn(value, "comments")) return state.mismatch;
							const cell7 = state.project(value["comments"], schema, 16, depth + 1, state);
							if (cell7 === state.mismatch || cell7 === state.unsafe) return cell7;
							output[7] = cell7;
							return output;
						} finally {
							state.active.delete(value);
						}
					})],
					"users",
					[2, [
						1,
						"id",
						0,
						"name",
						0
					]],
					"sessionUserId",
					0
				],
				"path",
				0
			],
			issue: issueExactServerComponent,
			write: writeExactServerComponent,
			dispose: disposeExactServerComponent,
			execution: {
				version: 1,
				classification: "synchronous",
				lane: "direct",
				render: __exactImplementation_IncidentApp_1,
				mode: "direct",
				publication: {
					kind: "resumption",
					name: "IncidentApp"
				}
			}
		},
		resumption: {
			componentId: "xuAKzNckgPuCTsehVDjqI5P",
			statePaths: [
				"connection",
				"error",
				"incidents",
				"loading",
				"selectedId",
				"sessionUserId",
				"users"
			],
			stateInputs: [
				["incidents", "initialData.incidents"],
				["sessionUserId", "initialData.sessionUserId"],
				["users", "initialData.users"]
			],
			valueCaptures: ["state"],
			contexts: [],
			boundaries: ["xMu3fuNmRjc6dWpuERPXhmv", "xOHhVB9dGpmnZm5koclWhiP"],
			stateDefaults: [["connection", "Connecting"], ["error", ""]]
		}
	}
}))();
function incidentIdFromPath(path = typeof window === "undefined" ? "/" : window.location.pathname) {
	return path.match(/^\/incidents\/([^/]+)$/)?.[1] ?? "";
}
//#endregion
//#region participants/exact/src/server-entry.tsx
/** Uses the public progressive HTML API with the same authored document and root props. */
function renderParticipantStream(initialData, path, options, signal) {
	return renderToHydratableProgressiveHtmlStream(createPreparedServerComponentReference(IncidentApp, {
		initialData,
		path
	}), {
		publishRootProps: true,
		signal,
		scheduleRender: options?.scheduleRender,
		documentShell: (application) => createPreparedServerComponentReference(Document, { clientTags: options?.clientTags }, createExpression(() => application))
	});
}
/** Renders the authored document through eXact's normalization and hydration publication. */
async function renderParticipant(initialData, path, options) {
	return (await renderCompilerClosedToHydratableString(createPreparedServerComponentReference(IncidentApp, {
		initialData,
		path
	}), {
		publishRootProps: true,
		signal: options?.signal,
		scheduleRender: options?.scheduleRender,
		documentShell: (application) => createPreparedServerComponentReference(Document, { clientTags: options?.clientTags }, createExpression(() => application))
	})).htmlWithHydration;
}
//#endregion
export { renderParticipant, renderParticipantStream };
