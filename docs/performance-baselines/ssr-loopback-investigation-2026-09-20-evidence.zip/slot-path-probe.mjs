import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createComparisonService} from '../../framework-comparison/src/service.mjs';
const root=import.meta.dirname;
let source=await readFile(root+'/current.mjs','utf8');
source=source.replace('function createChunkedStringResult(chunks, state, hydrationTable, preloadLinks, wallClockSnapshot, hasHydrationSlot) {','function createChunkedStringResult(chunks, state, hydrationTable, preloadLinks, wallClockSnapshot, hasHydrationSlot) { globalThis.__slotProbe.completed.push({chunks: chunks.length, bytes: chunks.reduce((n,c)=>n+Buffer.byteLength(c),0),hasHydrationSlot});');
source=source.replace('function hasDocumentHydrationSlot(result) {','function hasDocumentHydrationSlot(result) { globalThis.__slotProbe.presenceReads++;');
source=source.replace('function createChunkedHydratableResult(result, resumptions, hydrationScript) {','function createChunkedHydratableResult(result, resumptions, hydrationScript) { globalThis.__slotProbe.hydratableResults++;');
await writeFile(root+'/slot-instrumented.mjs',source);
const module=await import('./slot-instrumented.mjs');
const fixture=JSON.parse(await readFile('framework-comparison/fixtures/baseline.json','utf8'));
const service=createComparisonService(fixture);
let data;
try{data=Object.assign({},...await Promise.all(['/api/session','/api/incidents'].map(async path=>(await service.fetch(new Request('http://local'+path))).json())));}finally{service.dispose();}
const evidence=[];
for(const mode of ['string','stream']){
 globalThis.__slotProbe={completed:[],presenceReads:0,hydratableResults:0};
 const html=mode==='stream'?await new Response(module.renderParticipantStream(data,'/incidents/inc-101',{clientTags:''})).text():await module.renderParticipant(data,'/incidents/inc-101',{clientTags:''});
 const hash=createHash('sha256').update(html).digest('hex');
 assert.equal(hash,'aa6a4b341872d5df753fbd53e0526b656b1f1abcb3f7be86b67c9ede34867294');
 evidence.push({mode,hash,...globalThis.__slotProbe});
}
await writeFile(root+'/slot-path-evidence.json',JSON.stringify(evidence,null,2)+'\n');
console.log(evidence);
