import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {createComparisonService} from '../../framework-comparison/src/service.mjs';
import {profileNodeCpu,profileNodeAllocations} from '../../framework-comparison/src/ssr-allocation-profiler.mjs';
const variant=process.argv[2]??'current',mode=process.argv[3]??'string';
const module=await import('./'+variant+'.mjs');
const fixture=JSON.parse(await readFile('framework-comparison/fixtures/baseline.json','utf8'));
const service=createComparisonService(fixture);
let data;
try{const records=await Promise.all(['/api/session','/api/incidents'].map(async path=>(await service.fetch(new Request('http://local'+path))).json()));data=Object.assign({},...records);}finally{service.dispose();}
const render=mode==='stream'?async()=>new Response(module.renderParticipantStream(data,'/incidents/inc-101',{clientTags:''})).text():()=>module.renderParticipant(data,'/incidents/inc-101',{clientTags:''});
const first=await render();
if(first.includes('exact:document-hydration'))throw Error('Slot present in no-slot fixture');
const evidence={runtime:globalThis.Bun?'bun':'node',variant,mode,bytes:Buffer.byteLength(first),hash:createHash('sha256').update(first).digest('hex')};
let bytes=0;
for(let i=0;i<3000;i++)bytes+=Buffer.byteLength(await render());
if(process.argv.includes('--profile')){
 const work=async()=>{for(let i=0;i<10000;i++)bytes+=Buffer.byteLength(await render());};
 evidence.cpu=await profileNodeCpu(work);
 evidence.allocations=await profileNodeAllocations(async()=>{for(let i=0;i<1000;i++)bytes+=Buffer.byteLength(await render());});
}else{
 const start=performance.now();let count=0;
 do{for(let i=0;i<32;i++){bytes+=Buffer.byteLength(await render());count++;}}while(performance.now()-start<1500);
 const elapsed=performance.now()-start;Object.assign(evidence,{count,elapsed,rps:count*1000/elapsed,msPerRender:elapsed/count});
}
evidence.consumedBytes=bytes;console.log(JSON.stringify(evidence));
