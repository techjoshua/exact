import json
from pathlib import Path
d=json.loads(Path('.tmp/ssr-large-profile/scheduler-large-profile/capture.json').read_text())
for b in d['blocks']:
 print(b['profile'],round(b['rps']), 'CPU us/request',round(b['cpuUs']/b['valid'],1),'GC',b['after']['telemetry'].get('garbageCollection'), 'audit',b['after']['audit'].get('renderInvocation'))
