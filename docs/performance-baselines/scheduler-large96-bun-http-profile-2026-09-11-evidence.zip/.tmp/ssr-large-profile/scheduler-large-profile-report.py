import json,hashlib,zipfile,collections
from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'scheduler-large-profile'
d=json.loads((root/'capture.json').read_text());assert d['complete'] and len(d['blocks'])==6
rows=[]
for b in d['blocks']:
 p=json.loads((root/b['profile']).read_text());counts=collections.Counter(p['samples']);group=collections.Counter()
 for n in p['nodes']:
  f=n['callFrame'];group[(f['functionName'],f['url'],f['lineNumber'])]+=counts[n['id']]
 total=sum(counts.values());blank=group[('','',-1)]
 rows.append(dict(profile=b['profile'],rps=b['rps'],cpuUsPerRequest=b['cpuUs']/b['valid'],samples=total,unattributedPct=blank/total*100,top=[dict(function=k[0],url=k[1],line=k[2],samples=v,pct=v/total*100) for k,v in group.most_common(15)]))
 assert b['after']['scheduleCalls']==(b['valid']+len(b['results']) if b['phase']=='scheduled' else 0)
 assert all(s['errors']==0 for r in b['results'] for s in r['stages'])
valid=sum(b['valid'] for b in d['blocks']);(root/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid),indent=2))
report=Path('docs/performance-baselines/scheduler-large96-bun-http-profile-2026-09-11.md')
lines=['# Large native Bun string HTTP profiles','',
'Hypothesis: the scheduling slowdown for 96 incidents includes extra runtime CPU or allocation-related work, rather than solely delayed socket delivery. Six fresh processes run immediate eXact, scheduled eXact and unchanged React, then reverse that order. Each uses Bun --cpu-prof for its entire process, five seconds of HTTP warmup and ten seconds of measurement at concurrency 32. Native Bun responses contain full authored documents and hydration.', '',
'| Profile | Measured RPS | Process CPU us/request | Samples without a named frame |',
'| --- | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['profile']} | {r['rps']:,.0f} | {r['cpuUsPerRequest']:.1f} | {r['unattributedPct']:.2f}% |")
lines+=['',
'The profiler perturbs throughput; these RPS values do not replace unprofiled benchmark results. Process CPU is measured over the HTTP block and includes runtime/background/profiling work. Sample percentages cover startup, warmup and measurement, and are sample-count proportions, not exclusive CPU percentages. Both scheduled profiles contain many leaf samples with an empty function and URL directly beneath the root. That stack supplies no evidence distinguishing garbage collection, scheduling, native work or waiting. The generic GC observer reports zero events here, which does not establish absence of Bun GC.', '',
'Immediate eXact attributes roughly 7-8% of samples to startsExactDocument and 9-10% to validatePositionalValue. These are named leads for focused experiments. React attributes about 18.5% to its native Response constructor; comparison by percentages alone is not a per-request cost estimate. The shared renderer is retained.', '',
f'{valid:,} complete measured responses validated with zero errors; invocation counts and artifact guards pass. The archive preserves all six raw profiles, HTTP captures, analysis and runner source. No production implementation changed for profiling.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(root.glob('*'))+[report]+[base/n for n in ('scheduler-large-profile-build.py','scheduler-large-profile-run.mjs','scheduler-large-profile-inspect.py','scheduler-large-profile-cpu.py','profile-blank-stacks.py','scheduler-large-profile-report.py')]
archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists();manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print(valid,'validated responses;',len(files),'files verified')
