import json,collections
from pathlib import Path
for path in Path('.tmp/ssr-large-profile/scheduler-large-profile').glob('exact-*.cpuprofile'):
 p=json.loads(path.read_text());nodes={n['id']:n for n in p['nodes']};parents={c:n['id'] for n in p['nodes'] for c in n.get('children',[])};counts=collections.Counter(p['samples']);found=[]
 for ident,c in counts.items():
  cf=nodes[ident]['callFrame']
  if cf['functionName'] or cf['url']:continue
  stack=[];current=ident
  while current in nodes:
   f=nodes[current]['callFrame'];stack.append((f['functionName'],f['url'],f['lineNumber']));current=parents.get(current)
  found.append((c,stack))
 print(path.name)
 for x in sorted(found,reverse=True)[:3]:print(x)
