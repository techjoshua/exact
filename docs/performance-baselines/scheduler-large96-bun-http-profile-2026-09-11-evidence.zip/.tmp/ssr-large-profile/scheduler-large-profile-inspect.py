import json,collections
from pathlib import Path
root=Path('.tmp/ssr-large-profile/scheduler-large-profile')
for path in sorted(root.glob('*.cpuprofile')):
 p=json.loads(path.read_text());nodes={n['id']:n for n in p['nodes']};counts=collections.Counter(p.get('samples',[]));times=collections.Counter()
 for sample,delta in zip(p.get('samples',[]),p.get('timeDeltas',[])):times[sample]+=delta
 grouped=collections.Counter();weighted=collections.Counter()
 for ident,n in nodes.items():
  cf=n['callFrame'];key=(cf.get('functionName',''),cf.get('url',''),cf.get('lineNumber',-1))
  grouped[key]+=counts[ident] if counts else n.get('hitCount',0);weighted[key]+=times[ident]
 total=sum(grouped.values());print(path.name,'samples',total,'durationUs',p['endTime']-p['startTime'])
 for key,value in grouped.most_common(14):print(round(value*100/total,2),value,key)
 print()
