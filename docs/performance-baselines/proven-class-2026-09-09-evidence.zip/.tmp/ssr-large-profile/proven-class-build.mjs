import ts from 'typescript';import {readFileSync,writeFileSync} from 'node:fs';import assert from 'node:assert/strict';
const dir='.tmp/ssr-large-profile/',source=readFileSync(dir+'marker-current.mjs','utf8');
const sf=ts.createSourceFile('input.mjs',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
function safe(node){if(ts.isParenthesizedExpression(node))return safe(node.expression);if(ts.isStringLiteral(node)||ts.isNoSubstitutionTemplateLiteral(node))return /^[A-Za-z0-9 _-]*$/.test(node.text);if(ts.isConditionalExpression(node))return safe(node.whenTrue)&&safe(node.whenFalse);return ts.isBinaryExpression(node)&&node.operatorToken.kind===ts.SyntaxKind.PlusToken&&safe(node.left)&&safe(node.right);}
for(const [code,expected]of [[`'a'+(unknown?' b':'')`,true],[`unknown`,false],[`'a'+unknown`,false],[`condition?'safe':'<bad>'`,false],[`condition?'safe':'a"b'`,false],[`'safe'+(sideEffect()?' yes':' no')`,true]]){const tree=ts.createSourceFile('test.js',code,ts.ScriptTarget.Latest,true);assert.equal(safe(tree.statements[0].expression),expected);}
const proofs=new Map();
function scan(node){if(ts.isCallExpression(node)&&ts.isIdentifier(node.expression)&&node.expression.text==='createPreparedServerRenderProgram'){
 const [program,values]=node.arguments;if(!ts.isIdentifier(program))throw Error('Dynamic program');const props=ts.isArrayLiteralExpression(values)?values.elements[0]:undefined;
 const cls=props&&ts.isObjectLiteralExpression(props)&&!props.properties.some(ts.isSpreadAssignment)?props.properties.find(p=>ts.isPropertyAssignment(p)&&p.name.getText(sf)==='className'):undefined;
 const proven=!!cls&&safe(cls.initializer);proofs.set(program.text,(proofs.get(program.text)??true)&&proven);
}ts.forEachChild(node,scan);}scan(sf);
let changed=0;const edits=[];
function visit(node){if(ts.isVariableDeclaration(node)&&ts.isIdentifier(node.name)&&proofs.get(node.name.text)&&node.initializer&&ts.isCallExpression(node.initializer)){
 const obj=node.initializer.arguments[0];if(obj&&ts.isObjectLiteralExpression(obj)){const root=obj.properties.find(p=>ts.isPropertyAssignment(p)&&p.name.getText(sf)==='ssrRootStatic');const plan=root&&ts.isArrayLiteralExpression(root.initializer)?root.initializer.elements[2]:undefined;if(plan&&ts.isArrayLiteralExpression(plan))for(const field of plan.elements){if(ts.isArrayLiteralExpression(field)&&field.elements[0]?.getText(sf)==='1'&&ts.isStringLiteral(field.elements[1])&&field.elements[1].text==='className'){edits.push([field.elements[0].getStart(sf),field.elements[0].end,'7']);changed++;}}}
}ts.forEachChild(node,visit);}visit(sf);
let output=source;for(const [a,b,text]of edits.sort((x,y)=>y[0]-x[0]))output=output.slice(0,a)+text+output.slice(b);
const signature='function renderCompiledNativeAttribute(value, kind, name, attributeName, tag, context, accounted = false) {';assert.ok(output.includes(signature));
output=output.replace(signature,signature+`\n if (kind === 7 && typeof value === 'string') {\n const html = ' ' + attributeName + '=\\"' + value + '\\"';\n if (accounted) context?.outputSink?.accountKnown(html, html.length);\n return html;\n }\n if (kind === 7) kind = 1;`);
assert.ok(changed>0);writeFileSync(dir+'proven-class.mjs',output);console.log('Safe class plans:',changed,'proof cases: 6');
