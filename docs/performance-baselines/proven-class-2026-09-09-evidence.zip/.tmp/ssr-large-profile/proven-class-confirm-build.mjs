import {readFileSync,writeFileSync} from 'node:fs';
writeFileSync('.tmp/ssr-large-profile/proven-class-confirm.mjs',readFileSync('.tmp/ssr-large-profile/leaf-direct-confirm.mjs','utf8').replaceAll('leaf-direct','proven-class'));
