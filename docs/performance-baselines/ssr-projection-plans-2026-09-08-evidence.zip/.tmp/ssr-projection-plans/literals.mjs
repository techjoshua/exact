import { readFile, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
const data = JSON.parse(await readFile('.tmp/ssr-projection-plans/data.json', 'utf8'));
const names = ['original-entry', 'literal-projectors'];
const entries = Object.fromEntries(await Promise.all(names.map(async name => [name, await import(`./${name}.mjs`)])));
const samples = [];
for (const count of [3, 20, 200]) {
 const value = structuredClone(data);
 value.incidents = Array.from({length: count}, (_,i) => ({...data.incidents[i % data.incidents.length], id: i < 3 ? data.incidents[i].id : 'inc-' + (100+i)}));
 function render(entry) { let output = ''; const bytes = entry.renderParticipantToSink(value, '/incidents/inc-101', v => output += v, Buffer.byteLength); return {output, bytes}; }
 const expected = render(entries['original-entry']);
 for (const entry of Object.values(entries)) { assert.deepEqual(render(entry), expected); for (let i = 0; i < 1000; i++) render(entry); }
 for (let round = 0; round < 12; round++) for (const name of round % 2 ? [...names].reverse() : names) {
  const start = performance.now(); for (let i = 0; i < 2000; i++) render(entries[name]);
  samples.push({name, count, round, microseconds: (performance.now() - start) / 2});
 }
 for (const name of names) console.log(count, name, samples.filter(s => s.count === count && s.name === name).reduce((n,s) => n+s.microseconds,0)/12);
}
await writeFile(`.tmp/ssr-projection-plans/literals-${globalThis.Bun ? 'bun' : 'node'}.json`, JSON.stringify(samples, null, 2));
