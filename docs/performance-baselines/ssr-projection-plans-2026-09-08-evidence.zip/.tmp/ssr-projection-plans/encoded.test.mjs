import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createExactProducedResponse } from '@exactjs/server';
import { writeNodeResponse as original } from '../../framework-adapters/node-adapter/dist/handler.js';
import { writeNodeResponse as encoded } from './node-encoded.mjs';
for (const chunks of [['plain'], ['\ud83d','\ude00'], ['\ud83d','x','\udc00'], ['\u00e9','\u6c34'], ['']]) {
 test('encoded final body matches string writer for ' + JSON.stringify(chunks), async () => {
  const results=[];
  for(const write of [original,encoded]) {
   const headers=new Map(); let bytes;
   const response={statusCode:0,setHeader:(k,v)=>headers.set(k,v),end:v=>{bytes=Buffer.isBuffer(v)?v:Buffer.from(v);}};
   await write(response,createExactProducedResponse(200,{'content-type':'text/html'},publish=>chunks.forEach(publish)));
   results.push({status:response.statusCode,headers,bytes});
  }
  assert.deepEqual(results[0],results[1]);
  assert.deepEqual(results[1].bytes,Buffer.from(chunks.join('')));
 });
}
