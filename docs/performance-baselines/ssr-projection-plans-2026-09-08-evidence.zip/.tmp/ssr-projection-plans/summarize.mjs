import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import { summarizeSsrCapacityCapture } from '../../framework-comparison/src/ssr-capacity-report.mjs';
const root = '.tmp/ssr-projection-plans/';
const summary = { renderer: {}, http: [] };
for (const name of ['candidates','projectors','diagnostics','text','attributes','literals']) for (const runtime of ['node','bun']) {
 const filename = `${name}-${runtime}.json`;
 const samples = JSON.parse(await readFile(root + filename, 'utf8'));
 const rows = [];
 for(const count of [...new Set(samples.map(s => s.count ?? 3))]) for(const variant of [...new Set(samples.map(s => s.name))]) {
  const matching = samples.filter(s => (s.count ?? 3) === count && s.name === variant);
  rows.push({ count, variant, microseconds: matching.reduce((n,s) => n+s.microseconds,0)/matching.length, rounds: matching.length });
 }
 summary.renderer[filename] = rows;
}
const capture = JSON.parse(await readFile(root + 'http.json', 'utf8'));
assert.equal(capture.complete, true);
for(const block of capture.blocks) for(const result of block.results) for(const stage of result.stages) assert.equal(stage.errors,0);
summary.environment = capture.environment;
for(const payloadBytes of [0,65536]) for(const variant of ['control','encoded','react']) {
 const blocks = capture.blocks.filter(b => b.variant === variant && b.payloadBytes === payloadBytes);
 const [row] = summarizeSsrCapacityCapture({...capture,blocks});
 const populations = blocks.map(block => {
  const stages=block.results.map(r => r.stages.find(s => !s.discard));
  const start=Math.min(...stages.map(s => Date.parse(s.startedAt)));
  const end=Math.max(...stages.map(s => Date.parse(s.startedAt)+s.elapsedMs));
  return {population:block.population,rps:1000*stages.reduce((n,s)=>n+s.valid,0)/(end-start)};
 });
 summary.http.push({payloadBytes,variant,...row,populations});
 console.log(payloadBytes,variant,Math.round(row.rps),populations.map(p=>Math.round(p.rps)).join('/'));
}
await writeFile('docs/performance-baselines/ssr-projection-plans-2026-09-08.json', JSON.stringify(summary,null,2)+'\n');
