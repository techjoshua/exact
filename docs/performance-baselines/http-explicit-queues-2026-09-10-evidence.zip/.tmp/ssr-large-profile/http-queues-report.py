import hashlib
import json
import zipfile
from pathlib import Path
from statistics import mean

base=Path('.tmp/ssr-large-profile');folder=base/'http-queues'
data=json.loads((folder/'capture.json').read_text());assert data['complete'] and len(data['blocks'])==14
def duration(audit,key):
    s=audit.get(key);return s['sumMs']/s['count']*1000 if s else 0
def response(b):
    values=[r['stages'][0]['distributions']['responseMs'] for r in b['results']]
    return sum(s['mean']*s['count'] for s in values)/sum(s['count'] for s in values)
rows=[]
for population in (0,1):
    blocks=[b for b in data['blocks'] if b['population']==population]
    expected=['normal','nextTick','normal','microtask','normal','immediate','normal']
    if population:expected=list(reversed(expected))
    assert [b['phase'] for b in blocks]==expected
    for index in (1,3,5):
        b=blocks[index];controls=[blocks[index-1],blocks[index+1]]
        assert b['id']=='exact' and b['before']['deferred']==b['phase']
        assert b['after']['audit']['renderQueue']['count']==b['after']['audit']['renderInvocation']['count']
        assert all('renderQueue' not in c['after']['audit'] for c in controls)
        for c in [*controls,b]:
            for k in ('loopBefore','loopAfter'):assert 'renderQueue' not in c[k]['audit']
        normal=mean(c['rps'] for c in controls)
        rows.append(dict(population=population+1,queue=b['phase'],normalRps=normal,queuedRps=b['rps'],gainPct=(b['rps']/normal-1)*100,
          controlsRps=[c['rps'] for c in controls],normalInvocationUs=mean(duration(c['after']['audit'],'renderInvocation') for c in controls),queuedInvocationUs=duration(b['after']['audit'],'renderInvocation'),
          queueUs=duration(b['after']['audit'],'renderQueue'),normalResponseMs=mean(response(c) for c in controls),queuedResponseMs=response(b)))
valid=sum(b['valid'] for b in data['blocks']);errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages']);assert errors==0
(folder/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid,errors=errors),indent=2))
report=Path('docs/performance-baselines/http-explicit-queues-2026-09-10.md')
lines=['# Explicit queue comparison for eXact HTTP rendering, 2026-09-10','',
'Hypothesis before measurement: nextTick and queueMicrotask deferral will produce little throughput improvement, whereas setImmediate will reproduce the earlier gain at concurrency 32. This tests the actual queue APIs rather than treating an earlier Promise deferral as a complete substitute.', '',
'A diagnostic worker schedules the same render callback through a Promise resolved by process.nextTick, queueMicrotask, or setImmediate. The unchanged control performs no added deferral. The queued modes all include the Promise continuation; this does not compare direct callback execution without that Promise. Queue wait is recorded separately from synchronous render invocation and remains included in complete-response latency. Isolated loops bypass queueing, verified by counters.', '',
'Only eXact is executed in this experiment. No React renderer, app, scheduling or production baseline is changed. The worker uses the retained compiled eXact artifact and unchanged response adapter. This is not a framework implementation or new full benchmark baseline.', '',
'Two fresh production Node 26.8.1 workers each warm HTTP for ten seconds. The first runs normal/nextTick/normal/microtask/normal/immediate/normal; the second reverses that order. Blocks last five seconds, with two fresh load drivers holding 16 requests each. Controls average the two adjacent normal blocks. Before/after isolated loops each warm and measure 10,000 renders. Workstation load can vary.', '',
'| Worker | Queue | Normal RPS | Queued RPS | Change | Invocation us, normal / queued | Response mean ms, normal / queued | Queue mean us |',
'| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for r in rows:
    lines.append(f"| {r['population']} | {r['queue']} | {r['normalRps']:,.0f} | {r['queuedRps']:,.0f} | {r['gainPct']:+.2f}% | {r['normalInvocationUs']:.2f} / {r['queuedInvocationUs']:.2f} | {r['normalResponseMs']:.3f} / {r['queuedResponseMs']:.3f} | {r['queueUs']:.1f} |")
lines+=['',f'All {valid:,} measured responses matched the complete 4,672-byte document, with zero errors. Queue counters match render invocations in each treatment, and are absent in controls and isolated loops. Artifact and adapter hash guards pass.', '',
'This measures a scheduling effect, not its underlying CPU or I/O mechanism. It does not prove that unconditional deferral is appropriate: earlier low-concurrency tests included a single-request regression. Production adoption still needs an actual framework-owned boundary, response ownership and cancellation coverage, and early streaming/browser validation.', '',
'The adjacent evidence archive includes raw blocks, summaries, worker and runner scripts, participant artifacts and verified SHA-256 inventory.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[report]+[base/n for n in ('http-queues-build.mjs','http-queues-run.mjs','http-queues-report.py','http-immediate-run.mjs','http-immediate/worker.mjs','component-forwarding-integrated/server-entry.js')]
files=sorted(set(p for p in files if p.is_file()));archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps(rows,indent=2));print(valid,'valid;',len(files),'verified files')
