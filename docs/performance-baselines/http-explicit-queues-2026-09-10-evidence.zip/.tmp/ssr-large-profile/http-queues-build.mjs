import fs from 'node:fs/promises';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'http-queues',{recursive:true});
let worker=(await fs.readFile(root+'http-immediate/worker.mjs','utf8')).replaceAll('\r\n','\n');
function replaceOnce(text,from,to){if(!text.includes(from))throw Error('Missing source: '+from);return text.replace(from,to);}
worker=replaceOnce(worker,'let auditDefer=false,','let auditDefer=\'normal\',');
worker=replaceOnce(worker,"name==='renderMs'&&auditDefer&&!auditLoopMode","name==='renderMs'&&auditDefer!=='normal'&&!auditLoopMode");
worker=replaceOnce(worker,'await new Promise(resolve=>setImmediate(resolve));',"await new Promise(resolve=>{if(auditDefer==='immediate')setImmediate(resolve);else if(auditDefer==='nextTick')process.nextTick(resolve);else queueMicrotask(resolve);});");
worker=replaceOnce(worker,"auditDefer=url.searchParams.get('defer')==='1';","auditDefer=url.searchParams.get('queue');if(!['normal','nextTick','microtask','immediate'].includes(auditDefer))throw Error('Invalid queue');");
await fs.writeFile(root+'http-queues/worker.mjs',worker);
let runner=(await fs.readFile(root+'http-immediate-run.mjs','utf8')).replaceAll('http-immediate/','http-queues/').replaceAll('same-worker-event-loop-deferral','same-worker-explicit-queue-comparison');
runner=replaceOnce(runner,"population?['react','exact']:['exact','react']","['exact']");
runner=replaceOnce(runner,"['normal','immediate','normal']","population?['normal','immediate','normal','microtask','normal','nextTick','normal']:['normal','nextTick','normal','microtask','normal','immediate','normal']");
runner=replaceOnce(runner,"'audit-mode?defer='+(phase==='immediate'?'1':'0')","'audit-mode?queue='+phase");
runner=runner.replaceAll("phase==='immediate'","phase");
runner=replaceOnce(runner,'report.blocks.length,12','report.blocks.length,14');
await fs.writeFile(root+'http-queues-run.mjs',runner);
console.log('Built explicit queue comparison, eXact only');
