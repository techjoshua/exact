import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {setTimeout as delay} from 'node:timers/promises';
import {createHash} from 'node:crypto';
const participants=[{id:'exact-immediate',port:4401},{id:'exact-scheduled',port:4406},{id:'react',port:4402}];
const report={complete:false,intervalMs:30000,rounds:3,rows:[]};
for(const runtime of ['node','bun']){
 process.env.COMPARISON_SSR_RENDER_MODE='string';
 const harness=await import(runtime==='bun'?'./scheduler-browser/bun-server.mjs':'./scheduler-browser/node-server.mjs');
 try{
  const hashes=new Map();
  for(let round=-1;round<3;round++){
   if(round>=0){console.log(runtime,'idle 30 seconds before round',round+1);await delay(30000);}
   const offset=(round+3)%3,order=[...participants.slice(offset),...participants.slice(0,offset)];
   for(const p of order){const start=performance.now();const response=await fetch(`http://127.0.0.1:${p.port}/incidents/inc-100`,{headers:{connection:'close'}});const headers=performance.now();assert.equal(response.status,200);const body=Buffer.from(await response.arrayBuffer());const end=performance.now();assert.match(body.toString(),/^<!doctype html>/i);assert.match(body.toString(),/<\/body><\/html>$/i);const hash=createHash('sha256').update(body).digest('hex');if(round===-1)hashes.set(p.id,hash);else{assert.equal(hash,hashes.get(p.id));report.rows.push({runtime,id:p.id,round,ttfbMs:headers-start,responseMs:end-start,bytes:body.length,hash});}}
   assert.equal(hashes.get('exact-immediate'),hashes.get('exact-scheduled'));
   await writeFile('.tmp/ssr-large-profile/scheduler-browser/sparse.json',JSON.stringify(report,null,2));
  }
 }finally{await harness.close();}
}
report.complete=true;await writeFile('.tmp/ssr-large-profile/scheduler-browser/sparse.json',JSON.stringify(report,null,2));console.log('Sparse Node/Bun checks complete');
