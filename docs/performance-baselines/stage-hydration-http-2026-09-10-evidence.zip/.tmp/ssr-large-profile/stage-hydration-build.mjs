import fs from 'node:fs';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';const hashes={};
for(const runtime of ['node','bun']){
 const entry='framework-comparison/participants/exact/'+(runtime==='node'?'dist-server/server-entry.js':'dist-bun-server/bun-server-entry.js');let code=fs.readFileSync(entry,'utf8');const expected=runtime==='node'?'2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18':'9adc04f4d5d6e78ad95730319a475918c3b4b045da9a93f812c81aa827d60d2e';assert.equal(createHash('sha256').update(code).digest('hex'),expected);
 const old='return renderHydrationScriptValue(options, resumptionLayouts, capturedResumptions);';assert.equal(code.split(old).length,2);code='let auditCachedHydrationScript;\n'+code.replace(old,'return auditCachedHydrationScript ??= renderHydrationScriptValue(options, resumptionLayouts, capturedResumptions);');const folder=root+'stage-hydration-'+runtime;fs.mkdirSync(folder,{recursive:true});fs.writeFileSync(folder+'/server-entry.js',code);hashes[runtime]=createHash('sha256').update(code).digest('hex');
}
fs.writeFileSync(root+'stage-hydration-build.json',JSON.stringify(hashes,null,2));
let driver=fs.readFileSync(root+'current-execution-http.mjs','utf8');driver=driver.replace("['string','stream']","['string']").replace("['react','candidate']:['candidate','react']","['react','diagnostic','candidate']:['candidate','diagnostic','react']");
const start=driver.indexOf(' const entry=resolve('),end=driver.indexOf('\n',start);assert.ok(start>0&&end>start);driver=driver.slice(0,start)+" const entry=resolve(variant==='diagnostic'?`.tmp/ssr-large-profile/stage-hydration-${runtime.id}/server-entry.js`:relative);"+driver.slice(end);
const marker=' await controlSsrWorker(worker,\'reset\');';assert.equal(driver.split(marker).length,2);driver=driver.replace(marker," if(id==='exact'){const key=runtime.id+'/exact-complete';const normalized=normalizeDocument(html.toString());if(documents.has(key))assert.equal(normalized,documents.get(key));else documents.set(key,normalized);}\n"+marker);
fs.writeFileSync(root+'stage-hydration-http.mjs',driver);console.log(hashes);
