import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
const source=readFileSync(dir+'tail-current.mjs','utf8');
const force='if (state.active instanceof HydrationAncestors) state.active = new Set(state.active.values);';
if(source.split(force).length!==2)throw Error('Expected single forced projector Set conversion');
writeFileSync(dir+'projector-stack.mjs',source.replace(force,''));
