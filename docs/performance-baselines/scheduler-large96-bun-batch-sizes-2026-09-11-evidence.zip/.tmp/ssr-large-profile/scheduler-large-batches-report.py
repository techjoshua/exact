import json,hashlib,zipfile
from pathlib import Path
from statistics import mean
base=Path('.tmp/ssr-large-profile');root=base/'scheduler-large-batches'
d=json.loads((root/'capture.json').read_text());assert d['complete'] and len(d['blocks'])==16
rows=[]
for pop in (0,1):
 bs=[b for b in d['blocks'] if b['population']==pop];e=[b for b in bs if b['id']=='exact']
 row=dict(population=pop+1,immediate=mean(b['rps'] for b in e if b['phase']=='normal'),react=next(b['rps'] for b in bs if b['id']=='react'))
 for size in (1,4,8,16,32):row[str(size)]=next(b['rps'] for b in e if b['phase']==f'scheduled-{size}')
 rows.append(row)
for b in d['blocks']:
 assert b['after']['scheduleCalls']==(b['valid']+len(b['results']) if b['phase'].startswith('scheduled') else 0)
 assert all(s['errors']==0 for r in b['results'] for s in r['stages'])
valid=sum(b['valid'] for b in d['blocks']);(root/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid),indent=2))
report=Path('docs/performance-baselines/scheduler-large96-bun-batch-sizes-2026-09-11.md')
lines=['# Large Bun string rendering: batch-size experiment','',
'Hypothesis: smaller render-start batches reduce the slowdown seen with 96 incidents and a batch limit of 32. Same current compiled participants and actual scheduler, native Bun transport. Each request renders its complete document and hydration. React is unchanged. All scheduled variants use scheduler.yield and the production cancellation implementation.', '',
'Fresh workers run eXact/React/React/eXact with ten-second warmup and five-second measurement blocks at concurrency 32. Immediate controls surround five sizes (1, 4, 8, 16, 32), with size order reversed in the second eXact worker. Control means are within-worker averages; machine workload may vary.', '',
'| Repeat | Immediate RPS | Batch 1 | Batch 4 | Batch 8 | Batch 16 | Batch 32 | React RPS |',
'| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for r in rows:lines.append('| '+ ' | '.join([str(r['population'])]+[f'{r[k]:,.0f}' for k in ('immediate','1','4','8','16','32','react')])+' |')
lines+=['',f'{valid:,} complete measured responses validated with zero errors. Invocation counts and artifact guards pass. No production configuration was changed in this experiment.','',
'The prior larger-workload capture and this size sweep are retained together. Smaller batches do not automatically solve the workload-dependent scheduling cost. The remaining gap requires investigation of the large native Bun string path; small-fixture scheduling results cannot justify a universal default.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(root.glob('*'))+[report,base/'scheduler-large-batches-build.py',base/'scheduler-large-batches-run.mjs',base/'scheduler-large-batches-report.py',Path('framework-adapters/node-adapter/dist/render-scheduler.js')]
archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists();manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print(json.dumps(rows,indent=2));print(valid,'validated responses')
