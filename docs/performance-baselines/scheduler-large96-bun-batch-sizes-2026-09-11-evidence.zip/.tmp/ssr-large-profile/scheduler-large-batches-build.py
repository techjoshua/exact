from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'scheduler-large-batches';root.mkdir(exist_ok=True)
w=(base/'source-scheduler-bun/worker.mjs').read_text()
w=w.replace('const sourceScheduler=createNodeRenderScheduler();','let sourceScheduler=createNodeRenderScheduler();')
t="auditScheduled=url.searchParams.get('defer')==='1';";assert t in w
w=w.replace(t,t+"if(auditScheduled)sourceScheduler=createNodeRenderScheduler({maxBatchSize:Number(url.searchParams.get('batch'))});")
w=w.replace('return { ...session, ...incidents };',"const data={ ...session, ...incidents }; data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)})); return data;")
(root/'worker.mjs').write_text(w)
r=(base/'source-scheduler-bun-run.mjs').read_text().replace('source-scheduler-bun/','scheduler-large-batches/').replace('actual-source-scheduler-native-bun','large96-bun-string-batch-sizes')
r=r.replace("['string','stream']","['string']")
r=r.replace("['normal','scheduled','normal']","(population?['normal','scheduled-32','scheduled-16','scheduled-8','scheduled-4','scheduled-1','normal']:['normal','scheduled-1','scheduled-4','scheduled-8','scheduled-16','scheduled-32','normal'])")
r=r.replace("phase==='scheduled'","phase.startsWith('scheduled')")
r=r.replace("'audit-mode?defer='+(phase.startsWith('scheduled')?'1':'0')","'audit-mode?defer='+(phase.startsWith('scheduled')?'1':'0')+'&batch='+phase.split('-')[1]")
(base/'scheduler-large-batches-run.mjs').write_text(r)
