import {readFileSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const checks=[
 ['ssr-tests',['run','test','-w','@exactjs/ssr']],
 ['node-adapter-tests',['run','test','-w','@exactjs/node-adapter']],
 ['bun-adapter-tests',['run','test','-w','@exactjs/bun-adapter']],
 ['bun-native-tests',['run','test:bun','-w','@exactjs/bun-adapter']],
 ['test-types',['run','typecheck:tests']],
 ['architecture',['run','check:source-architecture']],
 ['platform',['run','check:platform-boundaries']],
 ['docs',['run','verify','-w','@exactjs/docs']]
];
for(const [label,args] of checks){
 const result=spawnSync('npm.cmd',args,{shell:true,encoding:'utf8',windowsHide:true,env:process.env});
 writeFileSync(`.tmp/ssr-sinks/verified-${label}.log`,result.stdout+'\n'+result.stderr);
 console.log(label,result.status);if(result.status!==0){console.log((result.stdout+'\n'+result.stderr).slice(-7000));process.exit(1);}
}
