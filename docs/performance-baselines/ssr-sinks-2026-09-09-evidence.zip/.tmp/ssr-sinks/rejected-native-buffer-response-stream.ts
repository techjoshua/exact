import type { ExactResponseBody } from '@exactjs/server';

/** Configures native encoding buffers while retaining publication flush boundaries. */
export interface BunResponseOptions {
	/** Initial native buffer capacity in bytes. Defaults to 2,048. */
	streamBufferBytes?: number;
}

/** Narrow platform contract used only within the Bun adapter. */
interface NativeBufferSink {
	start(options: { stream: true; asUint8Array: true; highWaterMark: number }): void;
	write(chunk: string): number;
	flush(): Uint8Array;
	end(): Uint8Array;
}

/**
 * Uses Bun's native UTF-8 sink with adapter-owned demand, failure, and cancellation.
 * Each publication flushes independently. Native storage ends on every terminal path.
 */
export function createBunDirectResponseStream(body: ExactResponseBody, options: BunResponseOptions): ReadableStream<Uint8Array> {
	const highWaterMark = options.streamBufferBytes ?? 2_048;
	if (!Number.isSafeInteger(highWaterMark) || highWaterMark <= 0)
		throw new RangeError('streamBufferBytes must be a positive safe integer');
	const Bun = (globalThis as unknown as { Bun: { ArrayBufferSink: new () => NativeBufferSink } }).Bun;
	let sink: NativeBufferSink | undefined;
	let started = false;
	let closed = false;
	let demand = 0;
	let resume: (() => void) | undefined;
	let cancellation: unknown;
	const wake = () => { const ready = resume; resume = undefined; ready?.(); };
	const end = () => { const owned = sink; sink = undefined; owned?.end(); };
	return new ReadableStream<Uint8Array>({
		pull(controller) {
			demand++;
			wake();
			if (started) return;
			started = true;
			sink = new Bun.ArrayBufferSink();
			sink.start({ stream: true, asUint8Array: true, highWaterMark });
			void body.writeTo(async (chunk) => {
				while (!closed && demand <= 0) await new Promise<void>((resolve) => { resume = resolve; });
				if (closed) throw cancellation;
				demand--;
				sink!.write(chunk);
				controller.enqueue(sink!.flush());
			}).then(() => {
				if (closed) return;
				closed = true;
				end();
				controller.close();
			}, (error) => {
				if (closed) return;
				closed = true;
				end();
				controller.error(error);
			});
		},
		async cancel(reason) {
			closed = true;
			cancellation = reason ?? new DOMException('Bun response cancelled', 'AbortError');
			wake();
			try { end(); } finally { await body.cancel(cancellation); }
		}
	}, { highWaterMark: 0 });
}
