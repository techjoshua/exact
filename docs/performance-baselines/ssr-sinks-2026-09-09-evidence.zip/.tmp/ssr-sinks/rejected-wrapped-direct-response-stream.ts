import type { ExactResponseBody } from '@exactjs/server';

/** Configures the native Bun response sink independently of renderer output limits. */
export interface BunResponseOptions {
	/** Native buffering target in bytes. Defaults to 2,048; publication boundaries still flush. */
	streamBufferBytes?: number;
}

/** Bun owns encoding and transport buffering for this platform-specific controller. */
interface DirectController {
	write(chunk: string): number | Promise<number>;
	flush(): number | Promise<number>;
	end(): number | Promise<number>;
}

type DirectSource = {
	type: 'direct';
	pull(controller: DirectController): void | Promise<void>;
	close(reason?: unknown): void | Promise<void>;
};

const DirectReadableStream = ReadableStream as unknown as new (
	source: DirectSource,
	strategy: { highWaterMark: number }
) => ReadableStream<Uint8Array>;

/**
 * Claims a produced body on first demand and writes strings directly to Bun's native sink.
 * Every producer publication flushes before continuation; pending writes retain backpressure.
 * Rejecting pull propagates failures. Bun's direct controller.close(error) can lose the error.
 */
export function createBunDirectResponseStream(
	body: ExactResponseBody,
	options: BunResponseOptions
): ReadableStream<Uint8Array> {
	const highWaterMark = options.streamBufferBytes ?? 2_048;
	if (!Number.isSafeInteger(highWaterMark) || highWaterMark <= 0)
		throw new RangeError('streamBufferBytes must be a positive safe integer');
	let started = false;
	let finished = false;
	let cancelled = false;
	let cancellation: unknown;
	const native = new DirectReadableStream(
		{
			type: 'direct',
			pull(controller) {
				if (started || cancelled) return;
				started = true;
				return body.writeTo((chunk) => {
					if (cancelled) throw cancellation;
					const written = controller.write(chunk);
					return written instanceof Promise
						? written.then(() => settle(controller.flush()))
						: settle(controller.flush());
				}).then(() => {
					finished = true;
					if (!cancelled) return settle(controller.end());
				});
			},
			close(reason) {
				if (finished || cancelled) return;
				cancelled = true;
				cancellation = reason ?? new DOMException('Bun response cancelled', 'AbortError');
				return body.cancel(cancellation);
			}
		},
		{ highWaterMark }
	);
	const reader = native.getReader();
	// Bun 1.4.2 skips direct-source cancellation callbacks. The standard stream
	// owns cancellation explicitly, including cancellation before the first pull.
	let closed = false;
	return new ReadableStream<Uint8Array>({
		async pull(controller) {
			try {
				const next = await reader.read();
				if (closed) return;
				if (next.done) {
					closed = true;
					reader.releaseLock();
					controller.close();
				} else controller.enqueue(next.value);
			} catch (error) {
				if (closed) return;
				closed = true;
				reader.releaseLock();
				controller.error(error);
			}
		},
		async cancel(reason) {
			closed = true;
			cancelled = true;
			cancellation = reason ?? new DOMException('Bun response cancelled', 'AbortError');
			try {
				await body.cancel(cancellation);
			} finally {
				await reader.cancel(cancellation);
				reader.releaseLock();
			}
		}
	}, { highWaterMark: 0 });
}

function settle(result: number | Promise<number>): void | Promise<void> {
	if (result instanceof Promise) return result.then(() => undefined);
}
