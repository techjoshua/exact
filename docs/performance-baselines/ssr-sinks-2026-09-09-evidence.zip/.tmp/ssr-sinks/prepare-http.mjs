import {readFileSync,writeFileSync} from 'node:fs';
const input=readFileSync('.tmp/unified-ssr/http.mjs','utf8');
const output=input.replace("const root='.tmp/unified-ssr'","const root='.tmp/ssr-sinks'").replace("availableSsrRuntimes('node,bun')","availableSsrRuntimes('bun')").replace("for(const mode of ['string','stream'])","for(const mode of ['stream'])");
writeFileSync('.tmp/ssr-sinks/http-bun.mjs',output);
