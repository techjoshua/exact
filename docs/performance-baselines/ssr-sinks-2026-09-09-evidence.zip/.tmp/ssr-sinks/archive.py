from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib,json
root=Path.cwd();out=root/'docs/performance-baselines/ssr-sinks-2026-09-09-evidence.zip'
evidencePath=root/'docs/performance-baselines/ssr-sinks-2026-09-09.json'
evidence=json.loads(evidencePath.read_text(encoding='utf-8'))
artifact_paths=[
'.tmp/ssr-sinks/baseline/exact-node.mjs','.tmp/ssr-sinks/baseline/exact-bun.mjs',
'.tmp/ssr-sinks/reconstructed-renderer-candidate.mjs',
'framework-comparison/participants/exact/dist-server/server-entry.js',
'framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js',
'framework-comparison/participants/react/dist-server/server-entry.js',
'framework-comparison/participants/react/dist-bun-server/bun-server-entry.js',
'.tmp/ssr-sinks/legacy-worker.mjs','framework-comparison/src/ssr-benchmark-worker.mjs',
'framework-adapters/node-adapter/dist/handler.js','framework-adapters/bun-adapter/dist/index.js']
evidence['artifacts']=[{'path':p,'bytes':(root/p).stat().st_size,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in artifact_paths]
expected=next(r['artifactSha256'] for r in evidence['raw']['final-renderer.json'] if r['variant']=='candidate')
assert next(r['sha256'] for r in evidence['artifacts'] if r['path'].endswith('reconstructed-renderer-candidate.mjs'))==expected
evidence['artifactNotes']=['The renderer measurement candidate was restored byte-for-byte by putting back the subsequently removed benchmark-only renderParticipantToSink export; its SHA-256 matches the recorded measurement identity. Final SSR bundles differ only by removing that obsolete export.','Starting worker imports are rebased in legacy-worker.mjs so the frozen control code can execute from the evidence location.','Source cleanup rebuilt both final eXact SSR entries byte-identically.','source-changes.patch isolates changes for files with recorded starting-source snapshots. Other changed tests and docs are retained as final source snapshots.']
evidence['validation'].update({'productionBrowserChecks':56,'artifactChecks':'package contents, compiled ABI and release ABI passed','lint':'affected files passed','jsdoc':'passed','explicitAny':'73/73 ratchet passed','docsVerification':'final source typecheck and build passed','bunAdapterNodeTests':4})
evidence['evidenceArchive']={'path':str(out.relative_to(root)).replace('\\','/'),'format':'zip','includes':'Starting, measured and final artifacts; harness source; final SSR/adapter source; exploratory sink code, raw measurements, profiles and logs.'}
evidencePath.write_text(json.dumps(evidence,indent=2),encoding='utf-8')
files=set()
for directory in [root/'.tmp/ssr-sinks',root/'packages/ssr/src',root/'framework-adapters/node-adapter/src',root/'framework-adapters/bun-adapter/src',root/'framework-adapters/node-adapter/dist',root/'framework-adapters/bun-adapter/dist',root/'framework-comparison/src',root/'framework-comparison/participants/exact/src',root/'framework-comparison/participants/react/src',root/'framework-comparison/participants/exact/dist',root/'framework-comparison/participants/react/dist']:
 for p in directory.rglob('*'):
  if p.is_file() and p.suffix not in ['.tsbuildinfo']: files.add(p)
for p in artifact_paths+['.tmp/unified-ssr/render-worker.mjs','.tmp/positional-leaves/data.json','apps/docs/src/pages/AdvancedPage.tsx','apps/docs/src/pages/PerformancePage.tsx','docs/ssr-hydration.md','docs/ssr-load-testing.md','docs/performance.md','framework-adapters/node-adapter/README.md']:
 files.add(root/p)
files.add(evidencePath)
files.add(root/'docs/performance-baselines/ssr-sinks-2026-09-09.md')
manifest=[{'path':str(p.relative_to(root)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)]
with ZipFile(out,'w',ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files): z.write(p,str(p.relative_to(root)).replace('\\','/'))
 z.writestr('evidence-manifest.json',json.dumps(manifest,indent=2))
with ZipFile(out) as z:
 assert z.testzip() is None
 for entry in manifest: assert hashlib.sha256(z.read(entry['path'])).hexdigest()==entry['sha256'],entry['path']
print('Verified archive:',len(files),'files,',out.stat().st_size,'bytes')
