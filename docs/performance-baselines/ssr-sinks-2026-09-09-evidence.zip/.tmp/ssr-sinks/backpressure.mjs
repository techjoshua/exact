import {createExactAsyncProducedResponse} from '../../packages/server/dist/index.js';
import {exactResponseToBunResponse} from '../../framework-adapters/bun-adapter/dist/index.js';
let writes=0;
const response=exactResponseToBunResponse(createExactAsyncProducedResponse(200,{},async write=>{for(let i=0;i<1000;i++){await write('chunk'+i);writes++;}}));
const reader=response.body.getReader();await reader.read();
await new Promise(resolve=>setTimeout(resolve,20));
console.log('Producer writes after reading one chunk:',writes);
await reader.cancel();
