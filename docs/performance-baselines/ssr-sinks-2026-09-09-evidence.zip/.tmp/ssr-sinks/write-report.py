from pathlib import Path
import json,statistics,hashlib,random
root=Path('.tmp/ssr-sinks')
def read(name): return json.loads((root/name).read_text(encoding='utf-8'))
def means(rows): return {v:statistics.mean(x['rps'] for x in rows if x['variant']==v) for v in ['baseline','candidate']}
renderer=read('final-renderer.json');http=read('final-transport-http.json');browser=read('browser-performance.json')
render_table=[]
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['small','unicode','large']:
   rows=[r for r in renderer if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario]
   values=[statistics.median(r['usPerRender'] for r in rows if r['variant']==variant) for variant in ['baseline','candidate','react']]
   render_table.append(f"| {runtime.title()} | {mode} | {scenario} | "+' | '.join(f'{x:.2f}' for x in values)+' |')
http_table=[]
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  rows=[r for r in http if r['runtime']==runtime and r['mode']==mode]
  values=[statistics.mean(r['rps'] for r in rows if r['variant']==variant) for variant in ['baseline','candidate','react']]
  http_table.append(f"| {runtime.title()} | {mode} | "+' | '.join(f'{x:,.0f}' for x in values)+' |')
summary=[];random.seed(17)
for profile in ['local','constrained']:
 for name,get in [('First contentful paint',lambda r:r['navigation']['firstContentfulPaintMs']),('Navigation completion',lambda r:r['navigation']['durationMs']),('Semantic readiness',lambda r:r['readyMs']),('Optimistic feedback',lambda r:r['optimisticFeedbackMs'])]:
  groups={v:[get(r) for r in browser['rows'] if r['id']==v and r['profile']==profile] for v in ['baseline','candidate','react']}
  differences=[b-a for a,b in zip(groups['baseline'],groups['candidate'])]
  boot=sorted(statistics.mean(random.choices(differences,k=len(differences))) for _ in range(2000))
  summary.append({'profile':profile,'metric':name,'medianMs':{k:statistics.median(v) for k,v in groups.items()},'pairedMeanDifference95CI':[boot[50],boot[1949]]})
browser_table=[f"| {r['profile']} | {r['metric']} | "+' | '.join(f"{r['medianMs'][v]:.2f}" for v in ['baseline','candidate','react'])+' | '+', '.join(f'{x:.2f}' for x in r['pairedMeanDifference95CI'])+' |' for r in summary]
report='''# SSR sink investigation, September 9, 2026

One renderer remains responsible for string and streaming output. This investigation retains
small allocation and dispatch improvements in that renderer and improves Node's handling of
already-buffered responses. It does not establish parity with React's string renderer or native
Bun streaming throughput. The [full benchmark capture](post-shell-2026-09-09.md) remains unchanged.

## Retained changes

| Change | Hypothesis | Decision |
| --- | --- | --- |
| Define result getters in object literals; assign optional metadata without temporary spread objects | Approximately 2-5% less result-construction overhead | Retain lazy HTML materialization and eliminate redundant setup |
| Consume completed program strings directly, with a completed-span fast path | Approximately 5-10% on leaf-heavy trees | Retain simpler dispatch, enhancement capture, and output bounds; small fixture results alone were mostly neutral |
| Keep ordered continuation state in function parameters | Approximately 2-5% less allocation on component-heavy output | Allocate a continuation callback only when a segment actually suspends |
| Reuse freshly projected hydration options | Small reduction in object copying, particularly on Bun | Remove the extra spread without changing publication values or validation |
| End buffered Node responses with one `response.end(html)` | Avoid intermediate writes, adapter promise handoffs, and unnecessary chunked transfer framing | Retain; the isolated response-path comparison improved by 2.6% on average |
| Use a buffered response for the benchmark's completed string document | Remove an asynchronous producer wrapper that no longer produces incremental output | Retain the idiomatic public response pattern and remove the obsolete fixture sink helper |

The Node body-only writer still sends ordered chunks with backpressure and leaves the response
open. Progressive producers and Web Streams retain early shell publication, cancellation, and
error handling. Public string APIs remain promised. No compiler ABI or hydration representation
changed in this investigation.

## Complete-document renderer measurements

Node 26.8.1 and Bun 1.4.2, production mode. Three rotating rounds of starting eXact, current eXact,
and React per runtime, output mode, and scenario: 108 process samples. Each process performs
2,000 warmups and 6,000 measured renders. Streaming includes complete `Response.text()` consumption.
The Bun renderer probe imports the neutral server bundle; native Bun HTTP is measured separately.
Both frameworks construct their own complete document through their component trees. Values are
median microseconds per complete document, lower is better.

| Runtime | Mode | Scenario | Starting eXact | Current eXact | React |
| --- | --- | --- | ---: | ---: | ---: |
'''+ '\n'.join(render_table)+'''

The small workload has three incidents. The large workload has 96. The Unicode workload adds
100 repetitions of accented text, an astral character, and Japanese text to each incident title.
Starting and current eXact have identical complete-document bytes and hashes in every scenario.
The small document without client assets is 3,966 bytes for eXact and 3,457 bytes for React.

Bun string times improved in all nine paired samples: 4.9-8.4% for small, 3.2-3.9% for Unicode,
and 2.8-7.4% for large. Node samples varied substantially. Its Unicode string median worsened,
while the three large streaming pairs improved by 1.5-6.0%. These measurements support modest
shared-path gains, not a uniform improvement percentage across workloads and runtimes.

## HTTP results with the normal participant adapters

Two counterbalanced populations per runtime and mode. Each population starts a fresh service and
worker, with two independent load drivers at concurrency 16 each, two seconds of warmup, and four
measured seconds. Fixture data is preloaded. Every response must match its complete document
identity. Values are mean validated responses per second, higher is better. All 24 populations
completed with zero response errors. Starting eXact uses its frozen entry and the original worker;
current eXact uses the updated buffered string-response pattern and shared-renderer changes.

| Runtime | Mode | Starting eXact | Current eXact | React |
| --- | --- | ---: | ---: | ---: |
'''+ '\n'.join(http_table)+'''

These short samples are sensitive to other work on this PC. The nearly tied string HTTP averages
neither prove nor disprove the smaller improvements isolated below. The Bun streaming decline in
this capture was not reproduced by the longer paired follow-up.

### Node buffered response isolation

Four counterbalanced pairs used exactly the same current renderer. The old worker wrapped its
completed HTML in an asynchronous produced body; the new worker passes a buffered response to the
Node adapter's terminal-write path. Mean throughput increased from **6,627 to 6,798 RPS (+2.6%)**.
Individual improvements were approximately +4.4%, -0.4%, +1.1%, and +5.4%. All responses validated.
This is a response-path improvement, not a change to component rendering speed.

### Bun streaming follow-up

Four additional pairs used four seconds of warmup and ten measured seconds per worker. Current
eXact was faster in all four: approximately +4.1%, +2.3%, +1.4%, and +18.7%, with zero response
errors. Both builds slowed markedly during the fourth pair. The user reported starting their
browser during this period. That pair remains in the raw data and is annotated as externally
interfered; its 18.7% result is not used as an optimization estimate. The preceding three pairs
show the smaller 1.4-4.1% improvements and do not reproduce a persistent streaming regression.

## Why Node and Bun rank differently

The installed React Bun implementation of `renderToReadableStream()` writes strings to a native
`type: 'direct'` destination. eXact's current Bun path encodes byte chunks and uses a standard Web
Stream. Bun's direct API delegates encoding and queue management to its destination. See
[Bun's stream documentation](https://bun.sh/docs/runtime/streams).

On Node, the normal React benchmark bridges its Web Stream through `Readable.fromWeb()` and
`pipeline()`. eXact's adapter consumes the Web Stream directly. An isolated diagnostic sent the
unchanged React renderer through eXact's Node response adapter. Mean throughput rose from
**4,438 to 6,553 RPS (+47.7%)** across four paired rounds, with zero errors. This demonstrates an
eXact adapter advantage in this workload. It is not a renderer optimization, and React's normal
benchmark implementation was not changed. The ordinary HTTP comparison above includes each
participant's adapter costs; the diagnostic explains why it cannot alone rank renderer speed.

## Bun sink experiments and workarounds

The initial native-direct prototype was removed before adapter-level workarounds had been fully
investigated. The user requested that follow-up, and the following alternatives were tested.

| Variant | Measurement or behavior | Decision |
| --- | --- | --- |
| Native direct stream, 2 KB target | Approximately 7,000-7,300 RPS in an exploratory success-only capture; cancellation hooks failed to release the producer's request scope | Preserve prototype; do not enable |
| Standard wrapper around native direct stream | Approximately 6,100-6,200 RPS against approximately 6,700 for the starting path; cancellation fixed, but the inner stream completed 1,000 writes after one reader demand | Reject |
| Native `Bun.ArrayBufferSink`, standard byte stream, 2 KB initial buffer | Cancellation, producer failure, early shell, and paused demand passed; throughput approximately 6,461 and 6,742 RPS against 6,844 and 6,757 | Reject the extra encoding sink |
| Same native buffer sink, 8 KB | Initial comparison looked slightly favorable; a same-renderer ablation measured 6,797 RPS versus 7,002 for the standard byte stream, with the standard path winning all four pairs | Reject based on the controlled comparison |
| Standard string-valued stream | Approximately 7,045 versus 6,876 RPS (+2.5%) across two pairs, one improved and one tied; direct `Response.body` readers receive strings instead of byte arrays | Preserve experiment; retain the public byte-reader contract |
| Standard produced response to Bun adapter | Essentially tied with the existing public byte-stream entry point | Preserve existing fixture entry point |

These captures have different run times and sample populations; their absolute rates should not
be treated as one simultaneous ranking. Small correct improvements are acceptable. Native variants
were rejected because of specific behavior failures or unfavorable controlled measurements, not
because their gains missed an arbitrary threshold.

On installed Bun 1.4.2, neither the tested direct source cancellation hook nor the close hook
provided the required cleanup on reader cancellation. The matching runtime source closes the
readable state before invoking direct-controller closure, whose handler returns when the stream
is already closed. See [ReadableStreamOperations.cpp](https://github.com/oven-sh/bun/blob/bun-v1.4.2/src/jsc/bindings/webcore/streams/ReadableStreamOperations.cpp)
and [JSDirectStreamController.cpp](https://github.com/oven-sh/bun/blob/bun-v1.4.2/src/jsc/bindings/webcore/streams/JSDirectStreamController.cpp).
Rejecting the producer's pull propagated errors correctly; closing the direct controller with an
error did not reliably reject body consumption in the tested prototype.

## Other rejected experiments

Eager string concatenation in result objects did not reliably improve string throughput and was
sometimes slower on Node. Lazy materialization remains. A 36-sample comparison of `TextEncoder`
and `Buffer.from` across both runtimes and all three document scenarios was largely neutral on
Bun and mixed on Node; no encoder switch was adopted. Removing extra streaming promise wrappers
also produced mixed or worse Bun samples and was reverted.

Profiles guided these hypotheses: Node string rendering spent time in result construction,
program preparation, operation creation, hydration validation/serialization, and garbage
collection. Bun stream consumption exposed native byte accounting, buffer construction, and
standard-stream queue/consumption work. Encoder experiments showed why a hot sampled function
alone does not prove that replacing it will improve throughput.

## Browser follow-up

120 production streaming sessions: 20 samples per participant in each of two profiles, rotating
participant order with fresh cache-disabled contexts. The constrained profile uses 4x CPU
throttling, 40 ms network latency, and 10 Mbps throughput. Each navigation renders a fresh complete
document; both eXact builds use identical current client assets. All response identity, resource,
browser error, and interaction checks passed.

Values are median milliseconds. The final column is a 95% bootstrap interval for the paired mean
current-minus-starting eXact difference, using 2,000 resamples with seed 17.

| Profile | Metric | Starting eXact | Current eXact | React | Paired difference interval |
| --- | --- | ---: | ---: | ---: | --- |
'''+ '\n'.join(browser_table)+'''

Every interval includes zero. This capture establishes no clear paint, navigation, readiness, or
optimistic-feedback timing change. It does not replace the public full browser or heap charts.

## Validation and evidence

SSR tests (261), Node adapter tests (26), Bun native adapter checks (8), test type checking,
source architecture, platform boundaries, and the documentation application verification passed.
The comparison harness tests (83) also passed. Production Node/Bun string/stream browser checks
and final artifact checks are recorded in the accompanying evidence once complete.

The [JSON record](ssr-sinks-2026-09-09.json) contains raw measurements, browser summaries, artifact
identities, and validation status. The evidence archive contains frozen starting builds, the
hash-verified measured renderer build, final builds, experiment scripts and rejected sink sources,
profiles, and logs. Exploratory intermediate results remain distinct from final measurements.
'''
Path('docs/performance-baselines/ssr-sinks-2026-09-09.md').write_text(report,encoding='utf-8')
raw={p.name:read(p.name) for p in root.glob('*.json')}
evidence={'date':'2026-09-09','versions':{'node':'26.8.1','bun':'1.4.2','react':'19.2.0'},'raw':raw,'browserSummaries':summary,'interference':[{'capture':'bun-stream-confirmation-http.json','population':3,'note':'User reported starting their browser during the marked slowdown. Raw data retained; this pair is not used as an optimization estimate.'}],'validation':{'ssrTests':261,'nodeAdapterTests':26,'bunNativeTests':8,'comparisonTests':83,'typecheck':'passed','sourceArchitecture':'passed','platformBoundaries':'passed','docsVerification':'passed','productionBrowserChecks':'pending','artifactChecks':'pending'}}
Path('docs/performance-baselines/ssr-sinks-2026-09-09.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
print('Wrote investigation report and raw measurement record')
