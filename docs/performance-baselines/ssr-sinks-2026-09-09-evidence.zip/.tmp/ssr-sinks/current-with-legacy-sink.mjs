export * from '../../framework-comparison/participants/exact/dist-server/server-entry.js';
import {renderParticipant} from '../../framework-comparison/participants/exact/dist-server/server-entry.js';
export async function renderParticipantToSink(initialData,path,write,encodedByteLength,options){
 const html=await renderParticipant(initialData,path,options);const written=write(html);if(written instanceof Promise)await written;
 return encodedByteLength?encodedByteLength(html):new TextEncoder().encode(html).byteLength;
}
