import assert from 'node:assert/strict';
import {createExactAsyncProducedResponse,exactResponseBodyOf} from '../../packages/server/dist/index.js';
function direct(body){let started=false;return new ReadableStream({type:'direct',pull(controller){if(started)return;started=true;return body.writeTo(chunk=>{controller.write(chunk);return controller.flush();}).then(()=>{controller.end();});},cancel(reason){return body.cancel(reason);}},{highWaterMark:2048});}
let release;const gate=new Promise(r=>release=r);let started=0;
const body=exactResponseBodyOf(createExactAsyncProducedResponse(200,{},async(write,signal)=>{started++;await write('shell');await gate;if(signal.aborted)throw signal.reason;await write('hydration');}));
const stream=direct(body);assert.equal(started,0);
const reader=stream.getReader();assert.equal(new TextDecoder().decode((await reader.read()).value),'shell');release();assert.equal(new TextDecoder().decode((await reader.read()).value),'hydration');assert.equal((await reader.read()).done,true);
const bad=direct(exactResponseBodyOf(createExactAsyncProducedResponse(200,{},async()=>{throw Error('failure');})));
await assert.rejects(new Response(bad).text(),/failure/);
console.log('direct lazy, early flush, pending continuation, complete output and failure checks passed');
