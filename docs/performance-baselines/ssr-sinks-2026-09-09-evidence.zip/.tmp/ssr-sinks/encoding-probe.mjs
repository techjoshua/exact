import {readFileSync,writeFileSync} from 'node:fs';import {spawnSync} from 'node:child_process';
const source=readFileSync('framework-comparison/participants/exact/dist-server/server-entry.js','utf8');
const target='var codec = createSsrUtf8Codec(globalThis.Buffer);';if(!source.includes(target))throw Error('Missing codec selection');
writeFileSync('.tmp/ssr-sinks/encoding-buffer.mjs',source);
writeFileSync('.tmp/ssr-sinks/encoding-text.mjs',source.replace(target,'var codec = createSsrUtf8Codec({ byteLength: globalThis.Buffer.byteLength });'));
const rows=[];
for(const runtime of ['node','bun'])for(const scenario of ['small','unicode','large'])for(let round=0;round<3;round++)for(const variant of round%2?['text','buffer']:['buffer','text']){
 const result=spawnSync(runtime,['.tmp/unified-ssr/render-worker.mjs',`.tmp/ssr-sinks/encoding-${variant}.mjs`,'stream',scenario,'4000'],{env:{...process.env,NODE_ENV:'production'},encoding:'utf8',windowsHide:true});
 if(result.status!==0)throw Error(result.stderr||result.stdout);
 const row={variant,round,...JSON.parse(result.stdout)};rows.push(row);console.log(runtime,scenario,round,variant,row.usPerRender);
 writeFileSync('.tmp/ssr-sinks/encoding.json',JSON.stringify(rows,null,2));
}
