# SSR sink investigation, 2026-09-09

Keep one renderer. Baseline is the unified renderer frozen before this investigation in baseline/exact-node.mjs and baseline/exact-bun.mjs. Historical full benchmark baseline remains unchanged.

## Experiments completed

- Literal result getters instead of per-request accessor descriptors: hypothesis 2-5% from less result setup. Node string improved in three paired samples; Bun neutral. Retain lazy materialization.
- Consume completed program spans directly: hypothesis 5-10% in leaf-heavy output. Small fixture mostly neutral. Removes redundant callback dispatch; preserve enhancement capture and output bounds.
- Eager rope string results: hypothesis 2-5% by avoiding joins and getters. Node inconsistent/slower, Bun string neutral. Rejected; source archived in rejected-rope-output-result.ts.
- Bun native direct stream: hypothesis less encoding and queue overhead, following installed React Bun renderer. Successful HTTP approximately 7,000-7,300 RPS versus React 8,500, but cancellation tests fail on Bun 1.4.2. Rejected, source archived. Tagged Bun C++ confirms cancellation closes stream before invoking controller cleanup, so underlying callback is skipped. Keep cancellation/failure regression tests on standard adapter.
- TextEncoder versus Buffer.from: three paired rounds across Node/Bun and small/Unicode/large trees. Bun largely neutral, Node mixed. No encoder change adopted.
- Optional result metadata assigned without temporary spread objects, plus fewer stream callback promise wrappers: Node string small repeatable improvement; Bun neutral/mixed. lean-results-stream.json.

## In progress

- Compare safe produced-response Bun adaptation against frozen stream baseline and React using actual HTTP, two counterbalanced populations, total concurrency 32, production mode, full document identity checks.
- Remove unconditional per-program continuation closures while retaining one ordered traversal and allocating continuations only for pending work. Hypothesis 2-5% allocation reduction in component-heavy output.
- Final scenario comparisons, correctness tests, browser checks, documentation and durable evidence still required.

## Evidence

Raw paired samples: literal-results.json, completed-spans.json, rope-results.json, lean-results-stream.json, encoding.json.
Profiles: exact-string.cpuprofile, exact-stream-bun.cpuprofile, react-stream-bun.cpuprofile.
Never compare isolated profiles' absolute timings to HTTP throughput or claim microbench changes as measured browser gains.


## Adapter workarounds requested and tested

- Standard wrapper around native direct stream: cancellation fixed, but throughput 6,100-6,200 versus frozen 6,700, and a paused-reader probe allowed 1,000 producer writes after one read. Rejected.
- Bun.ArrayBufferSink in one adapter-owned standard byte stream: cancellation, error propagation, early shell and paused demand pass. 2 KB initial capacity neutral/slower; 8 KB initially looked modestly faster against frozen SSR.
- Controlled 8 KB native sink versus standard produced byte stream using the SAME shared renderer: standard wins all four pairs by approximately 2-4%. Native 8 KB sink rejected on measured performance/added code, not a minimum gain rule.
- Standard string-valued stream delegates encoding to Bun HTTP and recovers modest throughput, but Response.body.getReader() exposes strings rather than Uint8Array. Text/arrayBuffer consumption work. Preserve as experimental only; public byte-reader contract retained.
- All adapter prototypes archived, source and generated native sink removed. Bun benchmark fixture restored to its original public byte-stream entrypoint.
- Stream promise-wrapper experiment reverted because Bun samples were mixed/slower. Shared string metadata, completed span dispatch, continuation allocation and hydration options copy removal remain.
- SSR tests: 261 pass; test typecheck passed before final two Bun tests. Bun native tests now include binary reader and demand checks (eight total).
- Final renderer scenario comparison running: 108 populations across Node/Bun, string/stream, small/Unicode/large, three rotating rounds and baseline/current/React. HTTP, browser, final docs/evidence still pending.


## Additional Node findings and adopted changes

- Shared string renderer improvements alone remain modest. Final-renderer.json has all 108 complete-document populations; Bun string paired improvements 2.8-8.4% across small/Unicode/large, Node mixed. No output identity differences.
- Node benchmark string lane still used an async produced-body wrapper around already-complete HTML. Removed renderParticipantToSink from fixture, migrated worker to await renderParticipant and createExactBufferedResponse, retained all byte/identity telemetry. Removed obsolete accepted-response diagnostic branch.
- Node writeNodeResponse now ends buffered output with one response.end(body.toText()), preserving body-only chunk/backpressure APIs and live streaming paths. Node26 tests pass, comparison83 tests pass. Surrogate-pair and single-consumer regression coverage updated; backpressure test belongs to body-only API.
- Four paired Node string rounds, SAME renderer via current-with-legacy-sink.mjs: legacy wrapper average 6,627 RPS, buffered current 6,798 RPS (+2.6%), zero errors. Retained regardless of modest magnitude.
- React Node streaming transport diagnosis: standard worker uses Readable.fromWeb plus pipeline, eXact uses writeNodeResponse's direct Web reader. Same React renderer through eXact Node adapter: 4,438 -> 6,553 RPS (+47.7%) across four pairs, zero errors. This is adapter advantage, not evidence eXact renderer is faster. Diagnostic source shared-node-worker.mjs, default React benchmark remains unchanged.
- Latest user asked for experiment results after each variant. Reported exact Node/Bun string-stream numbers and React transport result in commentary. Continue reporting each completed experiment promptly.
- Bun workaround results retained only in .tmp archives; production adapter unchanged. 8 KB native sink averaged 6,797 vs standard7,001 (same renderer, four pairs). String chunks7,045 vs6,876 two pairs but violate byte-reader contract.

## Current validation / measurement state

- Source: shared output-result metadata/literal getters, program-output continuation refactor and completed-span fastpath, direct-component-content/operation-target callback cleanup, hydration options copy removal; Node buffered end fastpath; worker string sink migration; six new Bun regression tests (eight total); program-output three tests. Docs updates underway.
- Final combined HTTP with legacy worker + frozen SSR baseline versus current worker + current SSR running via final-transport-http.mjs, label final-transport. Earlier final-http.json is renderer changes with ORIGINAL transport and remains evidence.
- Legacy worker copied to .tmp/ssr-sinks/legacy-worker.mjs, relative imports rebased and suiteRoot corrected. Baseline source archived at baseline/ssr-benchmark-worker.mjs and baseline/node-handler.ts.
- Pending: final combined HTTP results; optional current exact/React string profiles; 120 streaming browser sessions with browser.mjs20; 56 Node/Bun x string/stream production browser checks; final type/docs/architecture checks; durable JSON/MD/evidence.zip report and process cleanup.
- Docs changed: docs/ssr-hydration.md, docs/ssr-load-testing.md, docs/performance.md, node-adapter/README.md, apps/docs AdvancedPage and PerformancePage. New ssr-sinks-2026-09-09 report not yet created. Existing full public charts preserved.


## Completed

- Combined final HTTP: Node string starting/current/React 7,158/7,183/11,102 RPS; Node stream5,475/5,933/4,249; Bun string9,129/9,145/11,092; Bun stream7,132/6,935/8,604. All24 populations zeroerrors; short noisy samples, no universal gain claimed.
- Longer Bun streaming check: four warmup seconds, ten measured seconds, four pairs. Current faster +4.1,+2.3,+1.4,+18.7%; zeroerrors. User reported starting their browser during marked last-pair slowdown. Retain but annotate fourth pair; do not use18.7% as optimization estimate.
- 120 browser sessions completed with zero browser, resource, response or interaction errors. All eight paired timing CIs includezero. Local median FCP48/48ms, navigation32.1/31.4; constrainedFCP256/260,navigation321.15/317.25.
- 56 production browser correctness checks passed: Node/Bun x string/stream x exact/React.
- 261SSR tests,26Nodeadapter,4BunadapterNode tests,8nativeBun,83comparison tests passed. Test types, architecture, platform, finaldocsverify, affectedlint, jsdoc,any73/73,packagecontents,compiledABI,andreleaseABI passed.
- Removed leftover unused SSR response import. Rebuilt Node/Bun participant artifacts and verified byte-identical outputs after cleanup.
- Normal React benchmark implementation remains unchanged. The faster React transport was a diagnostic only, per user clarification.
- Final report: docs/performance-baselines/ssr-sinks-2026-09-09.md, JSON, evidence.zip. Archive includes final source, raw experiments, rejected Bun workarounds, starting/current artifacts, profiles, logs, and partial isolated source patch. Hash verification confirms the exact measured renderer candidate was reconstructed by restoring only the removed benchmark helper export.
- No benchmark/test processes remain from this task. Full historical public charts preserved. React string/nativeBun throughput gap remains; this investigation did not claim performance parity or an exhausted list of all possible framework optimizations.
