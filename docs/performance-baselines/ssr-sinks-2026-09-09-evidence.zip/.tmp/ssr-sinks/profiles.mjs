import {readFileSync} from 'node:fs';
for(const name of ['exact-string','exact-stream-bun','react-stream-bun']){
 const profile=JSON.parse(readFileSync(`.tmp/ssr-sinks/${name}.cpuprofile`,'utf8'));const nodes=new Map(profile.nodes.map(n=>[n.id,n])),totals=new Map();
 for(let i=0;i<profile.samples.length;i++){const n=nodes.get(profile.samples[i]);const key=n.callFrame.functionName||'(anonymous)';totals.set(key,(totals.get(key)||0)+(profile.timeDeltas?.[i]??1000));}
 console.log(name,JSON.stringify([...totals].sort((a,b)=>b[1]-a[1]).slice(0,25)));
}
