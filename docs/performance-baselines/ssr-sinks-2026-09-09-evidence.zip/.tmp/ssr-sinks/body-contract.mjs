import {createExactAsyncProducedResponse} from '../../packages/server/dist/index.js';
import {exactResponseToBunResponse} from '../../framework-adapters/bun-adapter/dist/index.js';
const make=()=>exactResponseToBunResponse(createExactAsyncProducedResponse(200,{},async write=>{await write('caf\u00e9 \ud83d\ude80');}));
const response=make();const reader=response.body.getReader();const first=await reader.read();console.log('Reader chunk:',typeof first.value,first.value?.constructor?.name);await reader.cancel();
console.log('Text:',await make().text());console.log('Bytes:',new TextDecoder().decode(await make().arrayBuffer()));
