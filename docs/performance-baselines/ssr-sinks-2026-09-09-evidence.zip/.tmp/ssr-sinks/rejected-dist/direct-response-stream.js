/**
 * Uses Bun's native UTF-8 sink with adapter-owned demand, failure, and cancellation.
 * Each publication flushes independently. Native storage ends on every terminal path.
 */
export function createBunDirectResponseStream(body, options) {
    const highWaterMark = options.streamBufferBytes ?? 8_192;
    if (!Number.isSafeInteger(highWaterMark) || highWaterMark <= 0)
        throw new RangeError('streamBufferBytes must be a positive safe integer');
    const Bun = globalThis.Bun;
    let sink;
    let started = false;
    let closed = false;
    let demand = 0;
    let resume;
    let cancellation;
    const wake = () => { const ready = resume; resume = undefined; ready?.(); };
    const end = () => { const owned = sink; sink = undefined; owned?.end(); };
    return new ReadableStream({
        pull(controller) {
            demand++;
            wake();
            if (started)
                return;
            started = true;
            sink = new Bun.ArrayBufferSink();
            sink.start({ stream: true, asUint8Array: true, highWaterMark });
            void body.writeTo(async (chunk) => {
                while (!closed && demand <= 0)
                    await new Promise((resolve) => { resume = resolve; });
                if (closed)
                    throw cancellation;
                demand--;
                sink.write(chunk);
                controller.enqueue(sink.flush());
            }).then(() => {
                if (closed)
                    return;
                closed = true;
                end();
                controller.close();
            }, (error) => {
                if (closed)
                    return;
                closed = true;
                end();
                controller.error(error);
            });
        },
        async cancel(reason) {
            closed = true;
            cancellation = reason ?? new DOMException('Bun response cancelled', 'AbortError');
            wake();
            try {
                end();
            }
            finally {
                await body.cancel(cancellation);
            }
        }
    }, { highWaterMark: 0 });
}
//# sourceMappingURL=direct-response-stream.js.map