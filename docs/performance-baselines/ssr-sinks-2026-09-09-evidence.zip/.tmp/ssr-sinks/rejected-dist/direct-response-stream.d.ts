import type { ExactResponseBody } from '@exactjs/server';
/** Configures native encoding buffers while retaining publication flush boundaries. */
export interface BunResponseOptions {
    /** Initial native buffer capacity in bytes. Defaults to 2,048. */
    streamBufferBytes?: number;
}
/**
 * Uses Bun's native UTF-8 sink with adapter-owned demand, failure, and cancellation.
 * Each publication flushes independently. Native storage ends on every terminal path.
 */
export declare function createBunDirectResponseStream(body: ExactResponseBody, options: BunResponseOptions): ReadableStream<Uint8Array>;
//# sourceMappingURL=direct-response-stream.d.ts.map