import type { ExactResponseBody } from '@exactjs/server';

/** Configures native encoding buffers while retaining publication flush boundaries. */
export interface BunResponseOptions {
	/** Initial native buffer capacity in bytes. Defaults to 2,048. */
	streamBufferBytes?: number;
}

/**
 * Uses Bun's native UTF-8 sink with adapter-owned demand, failure, and cancellation.
 * Each publication flushes independently. Native storage ends on every terminal path.
 */
export function createBunDirectResponseStream(body: ExactResponseBody, options: BunResponseOptions): ReadableStream<string> {
	let started = false;
	let closed = false;
	let demand = 0;
	let resume: (() => void) | undefined;
	let cancellation: unknown;
	const wake = () => { const ready = resume; resume = undefined; ready?.(); };
	return new ReadableStream<string>({
		pull(controller) {
			demand++;
			wake();
			if (started) return;
			started = true;
			void body.writeTo(async (chunk) => {
				while (!closed && demand <= 0) await new Promise<void>((resolve) => { resume = resolve; });
				if (closed) throw cancellation;
				demand--;
				controller.enqueue(chunk);
			}).then(() => {
				if (closed) return;
				closed = true;
				controller.close();
			}, (error) => {
				if (closed) return;
				closed = true;
				controller.error(error);
			});
		},
		async cancel(reason) {
			closed = true;
			cancellation = reason ?? new DOMException('Bun response cancelled', 'AbortError');
			wake();
			await body.cancel(cancellation);
		}
	}, { highWaterMark: 0 });
}
