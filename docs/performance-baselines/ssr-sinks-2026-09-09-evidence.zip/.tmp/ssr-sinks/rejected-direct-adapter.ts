import {
	exactResponseBodyOf,
	handleExactFetchRequest,
	type ExactResponseLike,
	type ExactServerContext
} from '@exactjs/server';
import { createBunDirectResponseStream, type BunResponseOptions } from './direct-response-stream.js';

export type { BunResponseOptions } from './direct-response-stream.js';

const nativeBun = Boolean((globalThis as { Bun?: unknown }).Bun);

/** Converts buffered text and produced streams through Bun's native Fetch response body lanes. */
export function exactResponseToBunResponse(result: ExactResponseLike, options: BunResponseOptions = {}): Response {
	const body = exactResponseBodyOf(result);
	return new Response(
		body
			? body.kind === 'produced'
				? nativeBun ? createBunDirectResponseStream(body, options) : body.toReadableStream()
				: body.toText()
			: (result.stream ?? result.body ?? ''),
		{
			status: result.status,
			headers: result.headers
		}
	);
}

/** Creates a Bun.serve-compatible fetch handler for an eXact endpoint. */
export function createExactBunHandler(
	context: ExactServerContext
): (request: Request) => Promise<Response> {
	return async (request) => {
		const result = await handleExactFetchRequest(request, context);
		return exactResponseToBunResponse(result);
	};
}

export { createExactBunHandler as createBunHandler };
