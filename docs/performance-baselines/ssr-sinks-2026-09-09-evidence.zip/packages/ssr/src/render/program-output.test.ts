import { describe, expect, it } from 'vitest';
import { createSsrContext } from './context.js';
import { SsrOutputLimitError } from './limits.js';
import { renderProgramOutput } from './program-output.js';

describe('ordered SSR program output', () => {
	it('waits for pending segments before executing later work', async () => {
		const calls: number[] = [];
		let resolve!: (html: string) => void;
		const pending = new Promise<string>((ready) => {
			resolve = ready;
		});
		const result = renderProgramOutput(
			createSsrContext({}),
			['a', { id: 1 }, 'c', { id: 2 }],
			(segment) => {
				calls.push(segment.id);
				return segment.id === 1 ? pending : 'd';
			}
		);
		expect(calls).toEqual([1]);
		resolve('b');
		expect(await result).toBe('abcd');
		expect(calls).toEqual([1, 2]);
	});

	it('preserves output bounds for a completed span and after suspension', async () => {
		expect(() =>
			renderProgramOutput(createSsrContext({ maxOutputBytes: 3 }), ['abcd'], () => '')
		).toThrow(SsrOutputLimitError);
		await expect(
			renderProgramOutput(createSsrContext({ maxOutputBytes: 3 }), ['ab', {}], () =>
				Promise.resolve('cd')
			)
		).rejects.toThrow(SsrOutputLimitError);
	});

	it('does not execute later segments after a rejected component', async () => {
		const failure = new Error('component failed');
		const calls: number[] = [];
		await expect(
			renderProgramOutput(createSsrContext({}), [{ id: 1 }, { id: 2 }], (segment) => {
				calls.push(segment.id);
				return Promise.reject(failure);
			})
		).rejects.toBe(failure);
		expect(calls).toEqual([1]);
	});
});
