import type { Component } from '@exactjs/core';
import { Article } from './Article.jsx';
import { Callout } from './Callout.jsx';

type AdvancedCard = { /** @exact key */ title: string; text: string; packages: string };
const advancedCards: AdvancedCard[] = [
	{
		title: 'SSR and hydration',
		text: 'Render HTML on the server, adopt it in the browser, and defer eligible interactions.',
		packages: '@exactjs/ssr · @exactjs/hydrate'
	},
	{
		title: 'Server execution',
		text: 'Use server resources from component tasks while keeping private code out of the browser.',
		packages: '@exactjs/compiler · @exactjs/server'
	},
	{
		title: 'Streaming',
		text: 'Reveal ready Suspense content while the rest of the page continues loading.',
		packages: '@exactjs/ssr'
	},
	{
		title: 'React compatibility',
		text: 'Use supported React packages inside an eXact application.',
		packages: '@exactjs/react-compat'
	},
	{
		title: 'Build integrations',
		text: 'Compile eXact applications with Vite, Webpack, Bun, or exactc.',
		packages: '@exactjs/vite-plugin · @exactjs/webpack-plugin · @exactjs/bun-plugin'
	},
	{
		title: 'Microfrontends',
		text: 'Expose trusted component roots from independently deployed applications.',
		packages: '@exactjs/microfrontends'
	}
];

/** Introduces eXact features that span browser and server runtimes. */
export function AdvancedPage(this: Component<{}>) {
	return () => (
		<Article
			eyebrow="Explore"
			title="Beyond the browser"
			description="Add server rendering, server tasks, streaming, React packages, and microfrontends when your application needs them."
			previous={{ path: '/examples/logo-lab', label: 'Logo lab' }}
			next={{ path: '/packages', label: 'Package map' }}
		>
			<section>
				<h2>Choose the features you need</h2>
				<div className="card-grid advanced-grid">
					{advancedCards.map((card) => (
						<div theme:surface="raised" className="topic-card">
							<strong>{card.title}</strong>
							<p>{card.text}</p>
							<code>{card.packages}</code>
						</div>
					))}
				</div>
			</section>

			<section>
				<h2>Start with a client component</h2>
				<p>
					Build the component, add routing and forms, then test its behavior. Add server rendering
					or server tasks when they improve startup, data access, or security.
				</p>
			</section>

			<section>
				<h2>Server rendering and hydration</h2>
				<p>
					Await <code>renderToString()</code> or <code>renderToHydratableString()</code> before
					reading the result. String and streaming output share one renderer. Component tasks run
					through the task system; the renderer waits for pending work needed by the output and
					continues immediately when that work is already complete.
				</p>
				<p>
					In custom Node page handlers, pass complete SSR responses to
					<code>writeNodeResponse()</code> from <code>@exactjs/node-adapter</code>. The adapter
					sends buffered documents in one terminal write and preserves progressive publication for
					streaming responses. Use <code>writeNodeResponseBody()</code> when your handler needs to
					keep the response open for additional content.
				</p>
				<p>
					Server rendering produces HTML and public component state. Hydration adopts the existing
					DOM, preserves form state and focus, and continues the same component in the browser.
					Hydrate an embedded document from its own window; hydration does not transfer a root
					across document boundaries.
				</p>
				<p>
					For roots without server operations or client islands, <code>hydrateAfterNavigation</code>
					from <code>@exactjs/hydrate/root</code> accepts an element or the current{' '}
					<code>document</code>. It gives visible server HTML a rendering opportunity before
					hydration, while activating synchronously if a user interaction arrives first. This can
					improve initial paint while moving passive application readiness slightly later.
				</p>
				<p>
					Use <code>renderMode: 'hydrate'</code> for browser builds that adopt server HTML,
					<code>renderMode: 'client'</code> for client-only builds, or the default mode when one
					build must support both.
				</p>
				<p>
					Eligible controls can load their client code on first interaction. The compiler explains
					why a component must hydrate eagerly when it cannot be deferred safely.
				</p>
				<p>
					For request data passed into the root component, <code>publishRootProps</code> and
					<code>readPublishedRootProps</code> provide one bootstrap copy for both client
					construction and hydration. State derived directly from those inputs is not serialized a
					second time. Pass the compiled root component to <code>readPublishedRootProps</code> so a
					compact component-bound payload can be decoded against the matching client artifact.
					Compiler-declared fields are read once while constructing that payload, so use data
					properties rather than side-effecting getters for published inputs.
				</p>
				<p>
					Root-prop publication works with string and progressive HTML rendering. For an authored
					full document, progressive HTML sends the rendered head and body content before the
					hydration payload and closing tags. Browsers can discover resources before hydration
					finishes arriving. The full-document shell still waits for rendering and pending tasks
					that could change it; the head is not yet flushed during tree traversal.
				</p>
			</section>

			<Callout title="Prepare production controls" tone="warning">
				<p>
					Configure authorization, CSRF protection, CSP, request limits, deployment pinning,
					observability, and request context before production deployment. Check the relevant guide
					for current host and integration limits.
				</p>
			</Callout>
		</Article>
	);
}
