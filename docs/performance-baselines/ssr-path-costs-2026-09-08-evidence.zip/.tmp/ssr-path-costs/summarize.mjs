import { readFile, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
import { summarizeSsrCapacityCapture } from '../../framework-comparison/src/ssr-capacity-report.mjs';
const root = '.tmp/ssr-path-costs/';
const summary = { http: {}, phases: JSON.parse(await readFile(root + 'phases.json', 'utf8')), candidates: {} };
for (const filename of ['http.json', 'http-string.json']) {
 const capture = JSON.parse(await readFile(root + filename, 'utf8'));
 assert.equal(capture.complete, true);
 const rows = [];
 for (const block of capture.blocks) for (const result of block.results) for (const stage of result.stages) assert.equal(stage.errors, 0);
 for (const variant of [...new Set(capture.blocks.map(block => block.variant))]) {
  const blocks = capture.blocks.filter(block => block.variant === variant);
  const [row] = summarizeSsrCapacityCapture({ ...capture, blocks });
  const populations = blocks.map(block => {
   const stages = block.results.map(result => result.stages.find(stage => !stage.discard));
   const start = Math.min(...stages.map(stage => Date.parse(stage.startedAt)));
   const end = Math.max(...stages.map(stage => Date.parse(stage.startedAt) + stage.elapsedMs));
   return { population: block.population, rps: 1000 * stages.reduce((sum, stage) => sum + stage.valid, 0) / (end - start) };
  });
  rows.push({ variant, ...row, populations });
  console.log(filename, variant, Math.round(row.rps), populations.map(p => Math.round(p.rps)).join('/'));
 }
 summary.http[filename] = { createdAt: capture.createdAt, environment: capture.environment, rows };
}
for (const filename of ['candidates-node.json', 'json-candidates-node.json', 'projector-candidates-node.json']) {
 const samples = JSON.parse(await readFile(root + filename, 'utf8'));
 summary.candidates[filename] = [...new Set(samples.map(s => s.name))].map(name => {
  const rows = samples.filter(s => s.name === name);
  return {name, microseconds: rows.reduce((sum, row) => sum + row.microseconds, 0) / rows.length};
 });
}
await writeFile('docs/performance-baselines/ssr-path-costs-2026-09-08.json', JSON.stringify(summary, null, 2) + '\n');
