import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {installDevelopmentProcessLifecycle} from '../../scripts/development-process-lifecycle.mjs';
import {startSsrLoadProcess} from '../../framework-comparison/src/ssr-load-process-owner.mjs';
import {startSsrWorker,stopSsrWorker,controlSsrWorker} from '../../framework-comparison/src/ssr-worker-controller.mjs';
import {availableSsrRuntimes,measureSsrArtifact,ssrEnvironmentMetadata} from '../../framework-comparison/src/ssr-run-environment.mjs';
const plan=JSON.parse(await readFile(process.argv[2],'utf8')),output=process.argv[3];
const runtimeId=process.argv[4]; if(!['node','bun'].includes(runtimeId))throw Error('Invalid runtime'); const runtimes=availableSsrRuntimes('node,bun');
const artifacts={}; const identities={};
for(const id of ['exact','react']){
 const path=id==='exact' && process.env.SSR_EXACT_ENTRY ? resolve(process.env.SSR_EXACT_ENTRY) : resolve(`framework-comparison/participants/${id}/${runtimeId==='bun'?'dist-bun-server/bun-server-entry.js':'dist-server/server-entry.js'}`);
 const bytes=await readFile(path);artifacts[id]={path,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')};

}
for (const [id,path] of Object.entries({hoisted:resolve('.tmp/ssr-path-costs/hoisted-buffers.mjs'),writer:resolve('.tmp/ssr-path-costs/node-writer.mjs'),transport:resolve('.tmp/ssr-path-costs/direct-writer.mjs'),worker:resolve('.tmp/ssr-path-costs/worker.mjs'),stringWriter:resolve('.tmp/ssr-path-costs/node-string-writer.mjs'),stringTransport:resolve('.tmp/ssr-path-costs/string-writer.mjs')})) { const bytes=await readFile(path); artifacts[id]={path,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')}; }
artifacts.server=await measureSsrArtifact(resolve('packages/server/dist'));
artifacts[runtimeId==='bun'?'bunAdapter':'nodeAdapter']=await measureSsrArtifact(resolve(`framework-adapters/${runtimeId==='bun'?'bun':'node'}-adapter/dist`));
const prior={artifacts,environment:ssrEnvironmentMetadata(runtimes)};
const report={kind:'multi-driver-preloaded-ssr',complete:false,runtimeId,transports:{exact:runtimeId==='bun'?'bun-fetch':'node-http',react:runtimeId==='bun'?'bun-fetch':'node-http'},createdAt:new Date().toISOString(),plan,artifacts:prior.artifacts,environment:prior.environment,blocks:[],runner:await readFile(import.meta.filename,'utf8')};
const runtime=availableSsrRuntimes(runtimeId)[0];let service,worker,drivers=[],timer,polling;
async function close(){clearInterval(timer);const ds=drivers;drivers=[];const closed=await Promise.allSettled(ds.map(d=>d.close()));await polling;if(worker){const w=worker;worker=undefined;await stopSsrWorker(w);}if(service){const s=service;service=undefined;await s.close();}const failures=closed.filter(x=>x.status==='rejected');if(failures.length)throw new AggregateError(failures.map(x=>x.reason));}
async function verify(){for(const id of ['exact','react','hoisted','writer','transport','worker','stringWriter','stringTransport']){const a=report.artifacts[id];assert.equal(createHash('sha256').update(await readFile(a.path)).digest('hex'),a.sha256);}}
const lifecycle=installDevelopmentProcessLifecycle({label:'Multi-driver preloaded SSR',close});
try{await verify();for(const payloadBytes of [0])for(let population=0;population<2;population++)for(const variant of population?['react','string-nohead','string-head','original-nohead','control']:['control','original-nohead','string-head','string-nohead','react']){
 const id=variant==='react'?'react':'exact';
 const query='?__benchmarkPreloaded=true'+(payloadBytes?'&__benchmarkPayloadBytes='+payloadBytes:'');
 const entryPath=variant==='control'||variant.startsWith('original')||variant.startsWith('string')?report.artifacts.exact.path:report.artifacts.hoisted.path;
 const serviceIntervals=[],telemetry=[],telemetryErrors=[];
 service=await startSsrLoadProcess('service',{onInterval:r=>serviceIntervals.push(r)});
 worker=await startSsrWorker({runtime,participantId:id,transport:runtimeId==='bun'?'bun-fetch':'node-http',workerPath:resolve('.tmp/ssr-path-costs/worker.mjs'),workingDirectory:resolve('framework-comparison'),serviceUrl:service.url,environment:{COMPARISON_SSR_BOUNDED_TELEMETRY:'1',SSR_WRITER_ENTRY:variant==='control'?'@exactjs/node-adapter':new URL(variant.startsWith('string')?'./node-string-writer.mjs':'./node-writer.mjs',import.meta.url).href,SSR_FLUSH_THRESHOLD_BYTES:'8192',SSR_FLUSH_HEAD:variant.endsWith('nohead')?'0':'1',...(id==='exact'?{COMPARISON_EXACT_SERVER_ENTRY:entryPath}:{})}});
 const response=await fetch(worker.url+query); assert.equal(response.status,200); const body=Buffer.from(await response.arrayBuffer()); assert.ok(body.toString().includes('Delayed fulfillment events')); const identity={bytes:body.length,hash:createHash('sha256').update(body).digest('hex')}; const identityKey=payloadBytes+':'+id; if(identities[identityKey])assert.deepEqual(identity,identities[identityKey]);else identities[identityKey]=identity;
 await controlSsrWorker(worker,'reset');
 telemetry.push({epochMs:Date.now(),value:await controlSsrWorker(worker,'telemetry')});
 timer=setInterval(()=>{if(polling)return;polling=controlSsrWorker(worker,'telemetry').then(value=>telemetry.push({epochMs:Date.now(),value}),e=>telemetryErrors.push(e.message)).finally(()=>{polling=undefined;});},1000);
 for(let i=0;i<plan.drivers;i++)drivers.push(await startSsrLoadProcess('driver'));
 console.log('Payload',payloadBytes||'original','population',population+1,variant,'drivers',drivers.length);
 for(const d of drivers)d.run({url:worker.url+query,contains:'Delayed fulfillment events',expectedIdentity:identities[identityKey],maxInFlight:256,maxLagMs:50,timeoutMs:10000,stages:plan.stages});
 const results=await Promise.race([Promise.all(drivers.map(d=>d.result)),service.result]);
 for(const r of results)for(const s of r.stages){assert.equal(s.offered,s.started+s.missedLag+s.missedCapacity+s.missedDeadline);assert.equal(s.completed,s.valid+s.errors);assert.equal(s.started,s.completed);}
 clearInterval(timer);await polling;telemetry.push({epochMs:Date.now(),value:await controlSsrWorker(worker,'telemetry')});
 const block={population,id,variant,payloadBytes,workerPid:worker.child.pid,workerStderr:worker.stderr(),servicePid:service.pid,results,telemetry,telemetryErrors,serviceIntervals};report.blocks.push(block);
 for(let i=0;i<plan.stages.length;i++){const ss=results.map(r=>r.stages[i]);console.log(ss[0].name,JSON.stringify({rps:ss.reduce((n,s)=>n+s.validRps,0),errors:ss.reduce((n,s)=>n+s.errors,0),misses:ss.reduce((n,s)=>n+s.missedCapacity+s.missedLag+s.missedDeadline,0)}));}
 await close();await writeFile(output,JSON.stringify(report));
 }await verify();assert.deepEqual(await measureSsrArtifact(resolve('packages/server/dist')),artifacts.server);assert.deepEqual(await measureSsrArtifact(resolve(`framework-adapters/${runtimeId==='bun'?'bun':'node'}-adapter/dist`)),artifacts[runtimeId==='bun'?'bunAdapter':'nodeAdapter']);report.complete=true;await writeFile(output,JSON.stringify(report));
}finally{await close();lifecycle.dispose();}

