import { readFile, writeFile } from 'node:fs/promises';
import { Session } from 'node:inspector/promises';
import assert from 'node:assert/strict';
import { summarizeCpuProfile } from '../../framework-comparison/src/client-profile-analysis.mjs';
import * as original from './original-entry.mjs';
import * as hoisted from './hoisted-buffers.mjs';
import { DirectWriter } from './direct-writer.mjs';
const data = JSON.parse(await readFile('.tmp/ssr-path-costs/data.json', 'utf8'));
const spans = {};
for (const [name, entry] of Object.entries({original, hoisted})) {
  spans[name] = [];
  const publish = value => spans[name].push(value);
  publish.static = publish;
  entry.renderParticipantToSink(data, '/incidents/inc-101', publish, Buffer.byteLength);
}
assert.equal(spans.original.map(String).join(''), spans.hoisted.map(String).join(''));
console.log('Span counts', Object.fromEntries(Object.entries(spans).map(([key,value]) => [key, value.length])));
const sink = { write(value) { if (typeof value === 'string') Buffer.from(value); return true; } };
const render = entry => () => entry.renderParticipantToSink(data, '/incidents/inc-101', () => {}, Buffer.byteLength);
const encode = values => () => { const writer = new DirectWriter(sink); for (const value of values) writer.write(value); writer.finish(); };
const operations = { 'original-render': render(original), 'hoisted-render': render(hoisted), 'original-encode': encode(spans.original), 'hoisted-encode': encode(spans.hoisted) };
const profiles = {};
for (const [name, operation] of Object.entries(operations)) {
  for (let i = 0; i < 5000; i++) operation();
  const session = new Session(); session.connect();
  try {
    await session.post('Profiler.enable'); await session.post('Profiler.setSamplingInterval', { interval: 100 });
    await session.post('Profiler.start');
    for (let i = 0; i < 100000; i++) operation();
    const { profile } = await session.post('Profiler.stop');
    await writeFile(`.tmp/ssr-path-costs/${name}.cpuprofile`, JSON.stringify(profile));
    profiles[name] = summarizeCpuProfile(profile);
    console.log(name, JSON.stringify(profiles[name].topSites.slice(0, 10)));
  } finally { session.disconnect(); }
}
const timings = [];
for (let round = 0; round < 12; round++) for (const name of round % 2 ? Object.keys(operations).reverse() : Object.keys(operations)) {
  const start = performance.now(); for (let i = 0; i < 10000; i++) operations[name]();
  timings.push({ name, round, microseconds: (performance.now() - start) / 10 });
}
await writeFile('.tmp/ssr-path-costs/phases.json', JSON.stringify({ spanCounts: Object.fromEntries(Object.entries(spans).map(([key,value]) => [key,value.length])), profiles, timings }, null, 2));
for (const name of Object.keys(operations)) console.log(name, timings.filter(row => row.name === name).reduce((sum,row) => sum+row.microseconds,0)/12);
