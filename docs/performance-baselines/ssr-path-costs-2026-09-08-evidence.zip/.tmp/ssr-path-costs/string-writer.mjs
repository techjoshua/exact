/** Experimental string staging: one native UTF-8 encoding per published batch. */
export class DirectWriter {
  constructor(destination, { flushThresholdBytes = 8192 } = {}) {
    this.destination = destination;
    this.threshold = flushThresholdBytes;
    this.value = '';
    this.bytes = 0;
    this.tail = '';
    this.destroyed = false;
    this.capacity = true;
  }

  write(value) {
    this.assertOpen();
    if (!value.length) return this.capacity;
    if (typeof value !== 'string') {
      if (this.tail) { this.tail = ''; this.append('\ufffd'); }
      value = value.toString('utf8');
    } else {
      value = this.tail + value;
      this.tail = '';
      const last = value.charCodeAt(value.length - 1);
      if (last >= 0xd800 && last <= 0xdbff) { this.tail = value.slice(-1); value = value.slice(0,-1); }
    }
    if (value) this.append(value);
    return this.capacity;
  }

  append(value) {
    const bytes = Buffer.byteLength(value);
    if (bytes > this.threshold) { this.flush(); this.emit(value); return; }
    this.value += value;
    this.bytes += bytes;
    if (this.bytes >= this.threshold) this.flush();
  }

  flush() {
    this.assertOpen();
    if (this.value) { const value = this.value; this.value = ''; this.bytes = 0; this.emit(value); }
    return this.capacity;
  }

  finish() {
    if (this.tail) { this.tail = ''; this.append('\ufffd'); }
    return this.flush();
  }

  emit(value) { const capacity = this.destination.write(value); this.capacity = this.capacity && capacity; }
  resume() { this.assertOpen(); this.capacity = true; }
  assertOpen() { if (this.destroyed) throw new Error('Writer destroyed'); }
  destroy(error) {
    if (this.destroyed) return;
    this.destroyed = true;
    this.value = ''; this.bytes = 0; this.tail = '';
    this.destination.destroy(error);
  }
}
