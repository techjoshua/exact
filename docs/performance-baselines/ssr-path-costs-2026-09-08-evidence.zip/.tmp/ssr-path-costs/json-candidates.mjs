import { readFile, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
const data = JSON.parse(await readFile('.tmp/ssr-path-costs/data.json', 'utf8'));
const names = ['original-entry', 'json-gate', 'json-single'];
const entries = Object.fromEntries(await Promise.all(names.map(async name => [name, await import(`./${name}.mjs`)])));
function render(entry) {
  let output = '';
  const bytes = entry.renderParticipantToSink(data, '/incidents/inc-101', value => output += value, Buffer.byteLength);
  return { output, bytes };
}
const initialTitle = data.incidents[0].title;
for (const title of ['</script><script>alert(1)</script>', '\u2028\u2029<', '\u00e9\u6c34\ud83d\ude42', '<'.repeat(2000)]) {
  data.incidents[0].title = title;
  const expected = render(entries['original-entry']);
  for (const entry of Object.values(entries)) assert.deepEqual(render(entry), expected);
}
data.incidents[0].title = initialTitle;
const expected = render(entries['original-entry']);
for (const entry of Object.values(entries)) {
  assert.deepEqual(render(entry), expected);
  for (let i = 0; i < 3000; i++) render(entry);
}
const samples = [];
for (let round = 0; round < 12; round++) for (const name of round % 2 ? [...names].reverse() : names) {
  const start = performance.now(); for (let i = 0; i < 10000; i++) render(entries[name]);
  samples.push({ name, round, microseconds: (performance.now() - start) / 10 });
}
await writeFile(`.tmp/ssr-path-costs/json-candidates-${globalThis.Bun ? 'bun' : 'node'}.json`, JSON.stringify(samples, null, 2));
for (const name of names) console.log(name, samples.filter(row => row.name === name).reduce((sum,row) => sum + row.microseconds,0)/12);
