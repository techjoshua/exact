import {readFileSync,writeFileSync,copyFileSync,mkdirSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const prior='.tmp/ssr-large-profile/direct-current/',dir='.tmp/ssr-large-profile/direct-scope/';
mkdirSync(dir,{recursive:true});
let source=readFileSync(prior+'direct-writer-siblings.mjs','utf8');
const before=`function executeDirectWriter(invocation,output){
 return withRenderCleanup(()=>executePreparedDirectWriter(invocation,output),()=>output.preparation?.[Symbol.asyncDispose]());
}`;
if(source.split(before).length!==2)throw Error('Missing execution scope');
source=source.replace(before,`function executeDirectWriter(invocation,output){
 // Generated preparation precedes the first possible child suspension.
 let result;
 try { result=executePreparedDirectWriter(invocation,output); }
 catch(error){
  if(!output.preparation)throw error;
  return withRenderCleanup(()=>{throw error;},()=>output.preparation[Symbol.asyncDispose]());
 }
 if(!output.preparation)return result;
 return withRenderCleanup(()=>result,()=>output.preparation[Symbol.asyncDispose]());
}`);
writeFileSync(dir+'direct-writer-siblings.mjs',source);
copyFileSync(prior+'direct-writer-siblings.mjs',dir+'control.mjs');
copyFileSync(prior+'direct-map-worker.mjs',dir+'direct-map-worker.mjs');
for(const name of ['direct-writer-real-siblings-build','direct-writer-real-siblings-audit'])writeFileSync(dir+name+'.mjs',readFileSync(prior+name+'.mjs','utf8').replaceAll(prior,dir));
for(const [runtime,name] of [[process.execPath,'direct-writer-real-siblings-build'],['node','direct-writer-real-siblings-audit'],['bun','direct-writer-real-siblings-audit']]){
 const run=spawnSync(runtime,[dir+name+'.mjs'],{encoding:'utf8',windowsHide:true});
 if(run.status!==0)throw Error(run.stderr+run.stdout);
 console.log(run.stdout);
}
writeFileSync(dir+'run.mjs',readFileSync(prior+'run.mjs','utf8').replaceAll(prior,dir).replaceAll('current-production','control'));
