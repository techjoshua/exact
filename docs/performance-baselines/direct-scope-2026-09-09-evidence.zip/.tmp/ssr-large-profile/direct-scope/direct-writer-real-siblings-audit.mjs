import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import * as runtime from './direct-writer-real-siblings-entry.mjs';
import * as fixture from './direct-writer-real-siblings-fixture.mjs';
const rows=[];
for(const outcome of ['success','failure','abort']){
 const fail=outcome==='failure';
 fixture.reset();
 const controller=new AbortController();
 const options={markers:false,signal:controller.signal};
 const context=runtime.createSsrContext(options);
 const target=new runtime.SsrOperationTarget(context,undefined,options,false,runtime.renderChildren);
 const references=[1,2].map(index=>runtime.createPreparedServerComponentReference(fixture.ScheduledChild,{index}));
 const failure=new Error('stop before second child');
 const program=runtime.createPreparedServerRenderProgram(runtime.prepareCompiledRenderProgram({version:1,id:'real-siblings',namespace:'html',ssrHost:'section',ssr(ops,ctx,invocation,output){
  output.preparation=output.prepareReferences(references);
  ops.static(output,'<section>');
  const first=ops.component(ctx,output,references[0],'1',0,true);
  const next=()=>{
   if(fail)throw failure;
   const second=ops.component(ctx,output,references[1],'2',0,true);
   const finish=()=>{ops.static(output,'</section>');return output;};
   return second instanceof Promise?second.then(finish):finish();
  };
  return first instanceof Promise?first.then(next):next();
 }}),[]);
 let rendering;
 try{
  rendering=Promise.resolve(target.renderPreparedServerProgram(program));
  for(let turn=0;turn<15;turn++)await Promise.resolve();
  assert.equal(fixture.starts,2,'both actual tasks start before either gate releases');
  if(outcome==='abort')controller.abort();
 }finally{if(outcome!=='abort')fixture.settle();}
 if(outcome==='abort'){
  let timer;
  try{
   await assert.rejects(Promise.race([rendering,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Cancellation waited for task gate')),2000);})]),error=>error.name==='AbortError');
  }finally{clearTimeout(timer);fixture.settle();}
 }
 else if(fail)await assert.rejects(rendering,error=>error===failure);
 else assert.equal(await rendering,'<section><strong>Ready 1</strong><strong>Ready 2</strong></section>');
 assert.equal(fixture.disposals,2,'consumed and unconsumed scheduled children are disposed');
 assert.deepEqual([...fixture.disposedIndices].sort(),[1,2],'each distinct child is disposed once');
 assert.deepEqual(context.hostStack,[]);
 rows.push({outcome,starts:fixture.starts,disposals:fixture.disposals,disposedIndices:fixture.disposedIndices,hostDepth:context.hostStack.length});
}
writeFileSync('.tmp/ssr-large-profile/direct-scope/direct-writer-real-siblings-'+(process.versions.bun?'bun':'node')+'.json',JSON.stringify(rows,null,2));
console.log(JSON.stringify(rows));
