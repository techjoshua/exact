import pathlib,json,hashlib,zipfile
root=pathlib.Path('.tmp/ssr-large-profile');d=root/'direct-scope'
rows=json.loads((d/'direct-writer-siblings-results.json').read_text(encoding='utf-8'))
assert len(rows)==32
text='''# Conditional ownership in the direct writer

Date: 2026-09-09. Prototype experiment; production unchanged.

The previous rebased direct writer attached cleanup to every program. This candidate executes the
generated writer first, retains failure cleanup if it acquired sibling preparation, and returns
directly when no preparation exists. The generated preparation phase must run synchronously before
the first possible child suspension. This condition holds for the current transformed direct sites;
it is not a general guarantee for arbitrary future writer programs.

The hypothesis was that removing empty cleanup callbacks would recover some of the direct writer's
regression. The control is the rebased direct-writer prototype, not current production. Thirty-two
fresh production processes cover Node/Bun, string/consumed stream, small/large documents with four
assets, and two reversed-order pairs. Each has 5,000 warmups and 12,000 measured renders. Every paired
document hash matches, and no completed population was discarded. Positive means slower rendering.

| Runtime | Mode | Fixture | Pair 1 time change | Pair 2 time change |
| --- | --- | --- | ---: | ---: |
'''
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['small','large']:
   changes=[]
   for round in range(2):
    pair=[r for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['round']==round]
    assert len(pair)==2 and pair[0]['hash']==pair[1]['hash']
    old=next(r for r in pair if r['variant']=='control');new=next(r for r in pair if r['variant']=='direct-writer-siblings')
    changes.append((new['usPerRender']/old['usPerRender']-1)*100)
   text+=f'| {runtime} | {mode} | {scenario} | {changes[0]:+.2f}% | {changes[1]:+.2f}% |\n'
text+='''
The result is mixed and does not establish a generally faster direct writer. It does not justify
production adoption or a claim of React parity. Do not combine these percentages with a previous
run to derive current production or React throughput. The callback change is preserved as an
experimental variant; its value needs evaluation alongside a more substantial sink integration.

Six actual compiled sibling-task cases pass across Node/Bun: success, failure before the second
child, and abort with the task gate still closed. Both tasks start together and each distinct child
is disposed once. Eight additional cases without preparation cover synchronous/asynchronous child
success/failure and verify HTML, primary error identity, and document host cleanup. These tests
protect both branches of the new scope decision. They are not browser or full public API coverage.

The remaining prototype limitations from the direct-current report still apply: general component
slots, complete enhancement/boundary capture, selective task waiting, early shell publication, and
backpressure. This is renderer timing, not HTTP or browser timing. No new React run is claimed.

The archive contains both artifacts, builders, fixtures, tests, observations, fixed input, and a
verified SHA-256 manifest. The production unowned-program build and its retained improvements remain
unchanged. The broader goal remains incomplete.
'''
for runtime in ['node','bun']:
 owned=json.loads((d/f'direct-writer-real-siblings-{runtime}.json').read_text(encoding='utf-8'))
 unowned=json.loads((d/f'unowned-{runtime}.json').read_text(encoding='utf-8'))
 assert len(owned)==3 and len(unowned)==4
 assert all(sorted(r['disposedIndices'])==[1,2] for r in owned)
target=pathlib.Path('docs/performance-baselines/direct-scope-2026-09-09');target.with_suffix('.md').write_text(text,encoding='utf-8')
files=[p for p in d.glob('*') if p.is_file()]+[root/'direct-scope-build.mjs',root/'direct-scope-unowned-audit.mjs',root/'direct-scope-report.py',pathlib.Path('.tmp/positional-leaves/data.json'),target.with_suffix('.md')]
manifest={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=pathlib.Path(str(target)+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p).replace('\\','/'))
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(text)
