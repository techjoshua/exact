import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const dir='.tmp/ssr-large-profile/direct-scope/';
const entry=dir+'unowned-audit-entry.mjs';
writeFileSync(entry,readFileSync(dir+'direct-writer-siblings.mjs','utf8')+'\nexport {renderDirectWriter,createSsrContext};\n');
const {renderDirectWriter,createSsrContext}=await import(pathToFileURL(resolve(entry)));
const rows=[];
for(const pending of [false,true])for(const fail of [false,true]){
 const context=createSsrContext({markers:false});
 const error=new Error('unowned child failed');
 const invocation={program:{ssrHost:'html',ssr(ops,ctx,unused,out){
  ops.static(out,'<html>');
  const result=ops.child(ctx,out,'child','1',0);
  const finish=()=>{ops.static(out,'</html>');return out;};
  return result instanceof Promise?result.then(finish):finish();
 }}};
 const render=()=>{
  if(pending)return fail?Promise.reject(error):Promise.resolve('ready');
  if(fail)throw error;
  return 'ready';
 };
 const result=Promise.resolve().then(()=>renderDirectWriter(context,invocation,render));
 if(fail)await assert.rejects(result,value=>value===error);
 else assert.equal(await result,'<!doctype html><html>ready</html>');
 assert.deepEqual(context.hostStack,[]);
 rows.push({pending,fail,hostDepth:context.hostStack.length});
}
writeFileSync(dir+'unowned-'+(process.versions.bun?'bun':'node')+'.json',JSON.stringify(rows,null,2));
console.log(JSON.stringify(rows));
