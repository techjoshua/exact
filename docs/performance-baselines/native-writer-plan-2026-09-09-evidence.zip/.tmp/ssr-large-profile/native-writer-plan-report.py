import pathlib,json,hashlib,zipfile
d=pathlib.Path('.tmp/ssr-large-profile');rows=json.loads((d/'native-writer-plan-results.json').read_text())
assert len(rows)==3 and all(row['identical'] for row in rows)
entry=pathlib.Path('framework-comparison/participants/exact/dist-server/server-entry.js')
assert hashlib.sha256(entry.read_bytes()).hexdigest()=='3a0683d59c2264901d7e45eaf686e2d15b51e80eeaabc651f2062e77aea1bba2'
report=pathlib.Path('docs/performance-baselines/native-writer-plan-2026-09-09.md')
files=[pathlib.Path('native/typescript-go/overlay/internal/exactcompiler')/n for n in ['jsx_render_program_ssr_lowering.go','jsx_render_program_ssr_plan.go','jsx_render_program_ssr_plan_test.go']]
files += [d/n for n in ['native-writer-plan-audit.mjs','native-writer-plan-results.json','native-writer-plan-report.py','compiled-stages-compile.json','publication-large-stages-compile.json','publication-adoption-compile.json']]
files += [report,pathlib.Path('docs/ssr-hydration.md')]
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=report.with_name(report.stem+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name in manifest:z.write(name,name)
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified three identical compiler outputs, unchanged production entry, and',len(manifest),'archive hashes.')
