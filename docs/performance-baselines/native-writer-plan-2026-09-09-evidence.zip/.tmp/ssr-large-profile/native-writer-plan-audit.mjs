import fs from 'node:fs';import {spawnSync} from 'node:child_process';import {createHash} from 'node:crypto';
const d='.tmp/ssr-large-profile/',rows=[];
for(const name of ['compiled-stages-compile.json','publication-large-stages-compile.json','publication-adoption-compile.json']){
 const previous=JSON.parse(fs.readFileSync(d+name,'utf8'));
 const run=spawnSync('.tmp/native-compiler/exactc.exe',[],{input:JSON.stringify(previous.request)+'\n',encoding:'utf8',windowsHide:true,maxBuffer:32*1024*1024});
 if(run.status!==0)throw Error(run.stderr||run.stdout);
 const response=JSON.parse(run.stdout);
 if(response.error||response.code!==previous.response.code)throw Error('Emission changed: '+name);
 rows.push({fixture:name,target:previous.request.target,identical:true,codeSha256:createHash('sha256').update(response.code).digest('hex')});
}
fs.writeFileSync(d+'native-writer-plan-results.json',JSON.stringify(rows,null,2));console.log(rows);
