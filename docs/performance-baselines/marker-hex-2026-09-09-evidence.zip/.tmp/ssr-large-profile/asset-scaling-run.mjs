import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const dir='.tmp/ssr-large-profile/';
let worker=readFileSync(dir+'long-worker.mjs','utf8');
worker=worker.replace("const render=",`const [kind,countText]=scenario.split('-');\nconst assets=Array.from({length:Number(countText)},(_,i)=>kind==='scripts'?'<script type="module" src="/assets/'+i+'.js"></script>':'<link rel="stylesheet" href="/assets/'+i+'.css">');\nconst clientTags=assets.join('');\nconst render=`).replaceAll("clientTags:''",'clientTags');
worker=worker.replace('console.log(JSON.stringify(',`for(let i=0;i<assets.length;i++)if(!html.includes('/assets/'+i+(kind==='scripts'?'.js':'.css')))throw Error('Missing asset');\nconsole.log(JSON.stringify(`);
writeFileSync(dir+'asset-scaling-worker.mjs',worker);
const rows=[],scenarios=['scripts-0','scripts-1','scripts-4','styles-1','styles-4'];
for(const runtime of ['node','bun'])for(let round=0;round<2;round++)for(const scenario of round?[...scenarios].reverse():scenarios)for(const variant of round?['react','exact']:['exact','react']){
 const entry=variant==='exact'?dir+'compiled-script-current.mjs':'framework-comparison/participants/react/dist-server/server-entry.js';
 const result=spawnSync(runtime,[dir+'asset-scaling-worker.mjs',entry,'string',scenario,'12000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(result.status!==0)throw Error(result.stderr||result.stdout);
 const row={variant,round,runtimeId:runtime,artifactSha256:createHash('sha256').update(readFileSync(entry)).digest('hex'),...JSON.parse(result.stdout)};
 const peer=rows.find(x=>x.variant===variant&&x.scenario===scenario&&x.runtimeId===runtime);
 if(peer&&peer.hash!==row.hash)throw Error('Unstable output');
 rows.push(row);writeFileSync(dir+'asset-scaling-results.json',JSON.stringify(rows,null,2));console.log(runtime,round,scenario,variant,row.usPerRender.toFixed(2));
}
