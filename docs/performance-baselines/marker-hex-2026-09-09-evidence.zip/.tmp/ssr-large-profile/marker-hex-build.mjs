import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
let source=readFileSync(dir+'compiled-script-current.mjs','utf8');
const start=source.indexOf('function encodeExactMarkerPart('),end=source.indexOf('\n}',start)+2;
if(start<0||!source.slice(start,end).includes('new TextEncoder'))throw Error('Unexpected marker encoder');
source=source.slice(0,start)+`const markerUtf8Encoder=new TextEncoder();
const markerHexBytes=Array.from({length:256},(_,byte)=>byte.toString(16).padStart(2,'0'));
function encodeExactMarkerPart(value) {
 if(/^[A-Za-z0-9._-]+$/.test(value)&&!value.includes('--'))return value;
 const bytes=markerUtf8Encoder.encode(value);let output='~';
 for(let index=0;index<bytes.length;index++)output+=markerHexBytes[bytes[index]];
 return output;
}`+source.slice(end);
writeFileSync(dir+'marker-hex.mjs',source);
let runner=readFileSync(dir+'compiled-script-current-run.mjs','utf8').replaceAll("'direct-map-current'","'compiled-script-current'").replace("['compiled-script-current','compiled-script-current']","['marker-hex','compiled-script-current']").replace("['compiled-script-current','compiled-script-current']","['compiled-script-current','marker-hex']").replace('compiled-script-current-results.json','marker-hex-results.json');
writeFileSync(dir+'marker-hex-run.mjs',runner);
