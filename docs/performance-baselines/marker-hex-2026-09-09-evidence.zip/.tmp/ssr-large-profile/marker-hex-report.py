import hashlib,json,pathlib,statistics,zipfile
root=pathlib.Path('.');work=root/'.tmp/ssr-large-profile'
scaling=json.loads((work/'asset-scaling-results.json').read_text(encoding='utf-8'))
rows=json.loads((work/'marker-hex-current-results.json').read_text(encoding='utf-8'));summary=[]
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  changes=[]
  for round in range(2):
   group=[r for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['round']==round]
   a=next(r for r in group if r['variant']=='compiled-script-current');b=next(r for r in group if r['variant']=='marker-hex-current')
   assert a['hash']==b['hash'];changes.append((b['usPerRender']/a['usPerRender']-1)*100)
  summary.append(dict(runtime=runtime,mode=mode,changes=changes))
table='\n'.join(f"| {s['runtime']} | {s['mode']} | {s['changes'][0]:+.2f}% | {s['changes'][1]:+.2f}% |" for s in summary)
scaling_table=[]
for runtime in ['node','bun']:
 for scenario in ['scripts-0','scripts-1','scripts-4','styles-1','styles-4']:
  vals={v:statistics.median(r['usPerRender'] for r in scaling if r['runtimeId']==runtime and r['scenario']==scenario and r['variant']==v) for v in ['exact','react']}
  scaling_table.append(f"| {runtime} | {scenario} | {vals['exact']:.2f} | {vals['react']:.2f} |")
dest=root/'docs/performance-baselines/marker-hex-2026-09-09'
dest.with_suffix('.json').write_text(json.dumps(dict(summary=summary,rebuilt=rows,prototype=json.loads((work/'marker-hex-results.json').read_text()),assetScaling=scaling),indent=2)+'\n',encoding='utf-8')
doc='''# Retained marker-key hex encoding improvement

Date: 2026-09-09. Change retained; overall React parity remains unmet.

## Asset-list investigation

Forty fresh string-rendering populations compared the retained compiled-script build with React
using zero, one, and four scripts or stylesheets. Both scenario and framework order reverse in
the second round. Each uses the same three-incident data, complete authored document, production
environment, 5,000 warmups, and 12,000 measured renders. These are Node-target artifacts on both
runtimes, not HTTP capacity. Asset presence and stable per-framework output hashes are checked.

Median microseconds per string render:

| Runtime | Asset fixture | eXact before hex change | React |
| --- | --- | ---: | ---: |
'''+ '\n'.join(scaling_table)+'''

Node measurements varied considerably, including the zero-asset control. Bun showed clearer script
scaling than stylesheet scaling. This is diagnostic evidence, not an exact per-item cost estimate.
Scripts retain keyed item markers for client adoption. Stylesheet programs can use their own
element boundary. URL keys contain slashes and cross the UTF-8 hex marker encoder.

## Implementation

encodeExactMarkerPart previously allocated a TextEncoder and an array of individually formatted
hex strings per encoded key. Core now shares one stateless encoder and a private 256-entry hex
lookup table and concatenates the encoded bytes directly. Safe direct keys and the UTF-8 hex wire
format remain unchanged. Lone surrogates retain TextEncoder's replacement semantics. There is no
cross-request key cache and no relaxation of marker grammar or validation.

The hypothesis was that removing encoder/temporary-array construction and repeated byte formatting
would improve the affected keyed-list workload. No numerical gain was preregistered. This was
tested first in a frozen-bundle prototype, then implemented in core and rebuilt for both targets.

## Rebuilt comparison

Sixteen fresh processes per batch, Node/Bun and string/consumed stream, two reversed-order pairs
per cell. Three incidents, two module scripts and two stylesheets, complete authored documents,
NODE_ENV=production, 5,000 warmups and 12,000 measured renders. Response.text() consumes streams.
All full response hashes match the prior build; no ordinal normalization is needed for this change.

Positive means longer rendering time. Two local pairs are not confidence bounds.

| Runtime | Mode | Rebuilt pair 1 time change | Rebuilt pair 2 time change |
| --- | --- | ---: | ---: |
'''+table+'''

All eight prototype pairs favored the candidate. Rebuilt Bun strings and streams improved in both
pairs. Rebuilt Node strings and streams each had one gain and one regression. The implementation is
retained for the direct allocation reduction, unchanged encoding, and repeated affected-path gains,
with that Node uncertainty explicitly accepted. This does not establish a universal speedup or
close the overall React gap. These percentages cannot be multiplied into historical HTTP RPS.

## Validation and cost

Core suite: 50 files, 252 tests passed. New coverage checks fixed canonical keys and UTF-8 hex
equivalence over ASCII, Unicode, lone surrogates, and sampled UTF-16 combinations. Core build and
native package compilation passed. The comparison client and Node/Bun servers rebuilt. Test
typecheck, ESLint for changed modules, compiled ABI, and platform boundaries passed. All 56
Node/Bun string/stream eXact/React browser correctness checks passed with the rebuilt client.

The lookup table adds constant module-lifetime storage for 256 hex strings and the shared encoder.
The comparison client gzip size rose from 62.16 to 62.20 kB in build output. No browser performance
claim is made. Public API, artifact semantics, and wire bytes are unchanged, so no ABI epoch change
is required. Engineering documentation records the implementation; public setup remains unchanged.

The archive preserves scaling/prototype/rebuilt measurements, source, tests, artifacts, browser
logs, fixed input, runners, and hashes. Other passing validation commands are recorded in the tool
transcript rather than raw log files. All task-owned processes exited.
'''
dest.with_suffix('.md').write_text(doc,encoding='utf-8')
names=['compiled-script-current.mjs','marker-hex.mjs','marker-hex-current.mjs','marker-hex-build.mjs','marker-hex-run.mjs','marker-hex-current-run.mjs','marker-hex-results.json','marker-hex-current-results.json','marker-hex-report.py','marker-hex-browser.mjs','asset-scaling-run.mjs','asset-scaling-worker.mjs','asset-scaling-results.json','compiled-script-worker.mjs','compiled-script-current-run.mjs','long-worker.mjs']
files=[work/n for n in names]+list(work.glob('marker-hex-browser-*.log'))+[root/'.tmp/positional-leaves/data.json',root/'packages/core/src/protocol.ts',root/'packages/core/src/protocol-marker.test.ts',root/'docs/ssr-hydration.md',root/'framework-comparison/participants/react/dist-server/server-entry.js',root/'framework-comparison/node_modules/react/package.json',root/'framework-comparison/node_modules/react-dom/package.json',dest.with_suffix('.md'),dest.with_suffix('.json')]
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps({p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(table);print('Verified',archive)
