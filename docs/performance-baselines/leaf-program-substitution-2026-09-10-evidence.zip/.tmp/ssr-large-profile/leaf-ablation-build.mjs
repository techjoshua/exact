import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'leaf-ablation',{recursive:true});
const source=(await fs.readFile(root+'component-forwarding-integrated/server-entry.js','utf8')).replaceAll('\r\n','\n');
const ast=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const edits=[];let leaves=0,branching=0,hooks=0;
function visit(n){
 if(ts.isPropertyAssignment(n)&&n.name.getText(ast)==='ssr'&&(ts.isFunctionExpression(n.initializer)||ts.isArrowFunction(n.initializer))){
  let recurses=false,begin;
  function inspect(c){
   if(ts.isCallExpression(c)&&ts.isPropertyAccessExpression(c.expression)&&c.expression.expression.getText(ast)==='__exactSsr'){
    if(['child','keyedChild','component','directComponent'].includes(c.expression.name.text))recurses=true;
    if(c.expression.name.text==='begin')begin=c.arguments.slice(1,4).map(a=>a.getText(ast));
   }
   ts.forEachChild(c,inspect);
  }inspect(n.initializer);
  if(recurses)branching++;
  else{if(!begin)throw Error('Leaf without accounting');leaves++;edits.push({start:n.initializer.getStart(ast),end:n.initializer.getStart(ast),text:'Object.assign('},{start:n.initializer.end,end:n.initializer.end,text:',{auditBegin:['+begin.join(',')+']})'});}
 }
 if(ts.isFunctionDeclaration(n)&&n.name?.text==='renderHydratableOutput'){
  edits.push({start:n.body.getStart(ast)+1,end:n.body.getStart(ast)+1,text:'auditCursor=0;'});hooks++;
 }
 if(ts.isFunctionDeclaration(n)&&n.name?.text==='executeProgramWriter'){
  const body=n.body.getText(ast);if(!body.includes('invoke(output, invocation)'))throw Error('Missing invoke');
  edits.push({start:n.body.getStart(ast),end:n.body.end,text:body.replace('invoke(output, invocation)','auditInvoke(output, invocation, invoke)')});hooks++;
 }
 ts.forEachChild(n,visit);
}
visit(ast);if(leaves!==14||branching!==11||hooks!==2)throw Error('Unexpected program layout');
let output=source;for(const e of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,e.start)+e.text+output.slice(e.end);
output=`let auditStage='none',auditRecords=[],auditCursor=0,auditCounts={leaf:0,replay:0};\n`+output+`
function auditInvoke(output,invocation,invoke){
 const begin=invocation.program.ssr.auditBegin;
 if(!begin)return invoke(output,invocation);
 const context=output.context;
 if(context.targetReceiptLayers?.some(layer=>!layer.consumed))throw Error('Leaf diagnostic cannot replay target contributions');
 const index=auditCursor++,record=auditRecords[index];
 if(record&&record.id!==invocation.program.id)throw Error('Leaf order changed');
 if(auditStage==='leaf'){
  if(!record)throw Error('Leaf cache not primed');++auditCounts.replay;
  beginSsrProgram(context,...begin);
  for(const value of record.writes){output.sink.write(value);if(output.sink.ready() instanceof Promise)throw Error('Leaf replay requires synchronous sink');}
  return output;
 }
 ++auditCounts.leaf;
 if(record)return invoke(output,invocation);
 const sink=output.sink,writes=[],beforeId=context.nextId,beforeNodes=context.traversedNodes;
 output.sink={write(value){writes.push(value);sink.write(value);},ready(){return sink.ready();},flush(...args){return sink.flush(...args);}};
 try{
  const completed=invoke(output,invocation);
  if(completed!==output)throw Error('Leaf diagnostic requires completed writer');
  if(context.nextId-beforeId!==begin[0]||context.traversedNodes-beforeNodes!==begin[0]-1+begin[1])throw Error('Unexpected leaf accounting');
  auditRecords[index]={id:invocation.program.id,writes};return completed;
 }finally{output.sink=sink;}
}
export function auditClearCounts(){auditCounts={leaf:0,replay:0};}
export function auditReset(){auditStage='none';auditRecords=[];auditCursor=0;auditClearCounts();}
export function auditSelect(stage){if(!['none','leaf'].includes(stage))throw Error('Invalid stage');if(stage==='leaf'&&!auditRecords.length)throw Error('Not primed');auditStage=stage;}
export function auditRead(){return {stage:auditStage,counts:{...auditCounts},records:auditRecords.length,writes:auditRecords.reduce((n,r)=>n+r.writes.length,0),ready:!!auditRecords.length};}
`;
await fs.writeFile(root+'leaf-ablation/server-entry.js',output);
await fs.writeFile(root+'leaf-ablation/sites.json',JSON.stringify({leaves,branching,hooks}));
await fs.copyFile(root+'hydration-ablation/worker.mjs',root+'leaf-ablation/worker.mjs');
let runner=(await fs.readFile(root+'tree-ablation-run.mjs','utf8')).replaceAll('tree-ablation/','leaf-ablation/').replaceAll('within-worker-tree-substitution','within-worker-leaf-substitution').replaceAll("'none','tree','none'","'none','leaf','none'");
await fs.writeFile(root+'leaf-ablation-run.mjs',runner);
let check=(await fs.readFile(root+'tree-ablation-check.mjs','utf8')).replaceAll('tree-ablation/','leaf-ablation/').replace("['none','tree']","['none','leaf']").replace("assert.equal(snapshot.counts.tree,stage==='tree'?0:1);","assert.ok(snapshot.records>0);assert.equal(snapshot.counts.leaf===0,stage==='leaf');assert.equal(snapshot.counts.replay,stage==='leaf'?snapshot.records:0);");
await fs.writeFile(root+'leaf-ablation-check.mjs',check);
console.log({leaves,branching,hooks});
