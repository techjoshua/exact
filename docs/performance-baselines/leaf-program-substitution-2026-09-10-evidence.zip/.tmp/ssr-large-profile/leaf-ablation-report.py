import hashlib
import json
import zipfile
from pathlib import Path
from statistics import mean

base=Path('.tmp/ssr-large-profile');folder=base/'leaf-ablation'
data=json.loads((folder/'capture.json').read_text());assert data['complete']
rows=[]
for population in (0,1):
    blocks=[b for b in data['blocks'] if b['population']==population]
    assert [b['phase'] for b in blocks]==['none','leaf','none']
    controls=[blocks[0],blocks[2]];b=blocks[1]
    assert b['after']['ablation']['counts']['leaf']==0
    assert b['after']['ablation']['counts']['replay']>0
    def render(x):
        s=x['after']['telemetry']['statistics']['renderMs'];return s['sum']/s['count']*1000
    def loop(x):return mean(x[k]['meanMs'] for k in ('loopBefore','loopAfter'))*1000
    normal=mean(c['rps'] for c in controls)
    rows.append(dict(population=population+1,normalRps=normal,replayRps=b['rps'],gainPct=(b['rps']/normal-1)*100,
                     normalHttpUs=mean(render(c) for c in controls),replayHttpUs=render(b),normalLoopUs=mean(loop(c) for c in controls),replayLoopUs=loop(b)))
valid=sum(b['valid'] for b in data['blocks']);errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages']);assert errors==0
(folder/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid,errors=errors),indent=2))
report=Path('docs/performance-baselines/leaf-program-substitution-2026-09-10.md')
lines=['# Leaf program substitution, 2026-09-10','','## Scope and hypothesis','',
'After tree replay exposed a broad cost, isolate nonbranching compiled writers.',
'Hypothesis: leaf HTML generation contributes meaningful work beyond sink',
'accumulation. Preserve individual writes rather than batch them into one string.', '',
'An AST classification finds 14 nonbranching and 11 branching writer definitions.',
'The fixed fixture executes 11 leaf invocations producing 17 of its 89 sink writes.',
'The diagnostic records those writes during priming, keyed by occurrence and',
'verified program identity. Treatment invokes beginSsrProgram with the original',
'static arguments, then replays each write. Compiler IDs, node counts and static',
'limit checks remain active. Replay checks synchronous readiness after each write.', '',
'Component preparation, parent traversal, host entry/exit, program completion',
'and ownership remain active. Pending target attribute contributions cause a',
'diagnostic error rather than silently bypass their consumption. Priming verifies',
'expected ID/node deltas and synchronous completion. The fixture is fixed; dynamic',
'per-value rendering and its checks are intentionally replaced here. This is not',
'a general caching implementation or proof of safety for other applications.', '',
'The result covers only leaf writer invocation. Eager input evaluation, program',
'construction and branching writers still run. Most writes come from those',
'branching writers, so a small result cannot exclude broader compiled-render cost.', '',
'## Measurement','',
'Two fresh Node string workers each run normal/replay/normal, ten seconds HTTP',
'warmup and five seconds per block. Two fresh drivers per block each hold 16',
'requests in flight. Controls average adjacent normal blocks in the same worker.',
'Isolated loops before/after each block warm and measure 10,000 renders. Compare',
'within this diagnostic; instrumentation and workstation load affect controls.', '',
'| Worker | Normal RPS | Replay RPS | Change | Normal HTTP us | Replay HTTP us |',
'| --- | ---: | ---: | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['population']} | {r['normalRps']:,.0f} | {r['replayRps']:,.0f} | {r['gainPct']:+.2f}% | {r['normalHttpUs']:.2f} | {r['replayHttpUs']:.2f} |")
lines+=['',f'All {valid:,} measured responses match the complete 4,672-byte document,',
'zero errors. Four ordinary/escaped full-document parity cases pass. Counters',
'confirm replayed invocations. Artifact and adapter hashes are checked, and owned',
'worker/load processes close. Raw isolated durations remain in summary.json.', '',
'## Next boundary','',
'Inspect branching-writer work and the eager construction of render-program',
'invocations before considering a compiler/runtime redesign. State capture, prop',
'scanning and sink accumulation already have bounded substitution evidence. No',
'production optimization is accepted from this diagnostic, and the complete',
'Node/Bun string/stream performance objective remains open.', '',
'The adjacent archive includes raw blocks, summaries, source/check/runner scripts,',
'frozen current and diagnostic artifacts, fixture and a verified SHA-256 inventory.',
'Workspace dependencies are not included as a standalone distribution.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[report,Path('.tmp/positional-leaves/data.json')]+[base/n for n in ('leaf-ablation-build.mjs','leaf-ablation-check.mjs','leaf-ablation-run.mjs','leaf-ablation-report.py','tree-ablation-run.mjs','tree-ablation-check.mjs','hydration-ablation/worker.mjs','component-forwarding-integrated/server-entry.js')]
files=sorted(set(f for f in files if f.is_file()));archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={f.as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in files:z.write(f,f.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps(rows,indent=2));print(valid,'valid;',len(files),'verified files')
