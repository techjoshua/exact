from pathlib import Path

base = Path('.tmp/ssr-large-profile')
source = (base / 'inline-slot-frame-trace.mjs').read_text(encoding='utf-8')
source = source.replace("inline-slot-frame-trace/", "component-boundary-audit/")
source = source.replace("inline-slot-frame/server-entry.js", "conditional-emission/server-entry.js")
source = source.replace('i<1000', 'i<20')
old = "events[events.length-1].args={component:args[1]?.artifact?.id}"
new = "events[events.length-1].args={component:args[1]?.artifact?.id,classification:args[1]?.artifact?.execution?.classification,mode:args[1]?.artifact?.execution?.mode,scalarPropsProven:args[6]===true}"
assert source.count(old) == 1
source = source.replace(old, new)
source = source.replace('console.log(JSON.stringify(summary));', "console.log(JSON.stringify({mode,bytes:summary.bytes,hash:summary.hash,events:summary.events}));")
(base / 'component-boundary-audit.mjs').write_text(source, encoding='utf-8')
