import hashlib
import json
import zipfile
from pathlib import Path

base = Path('.tmp/ssr-large-profile')
report = Path('docs/performance-baselines/component-boundary-trace-2026-09-10.md')
destination = report.with_name(report.stem + '-evidence.zip')
assert not destination.exists()
original = base / 'conditional-emission/server-entry.js'
assert hashlib.sha256(original.read_bytes()).hexdigest() == '8ab1cfb4e475362dc59ab5c325ac29f093bfc6cdfd114e422dca7116832434f6'
files = [report, original, Path('.tmp/positional-leaves/data.json')]
files += [base / name for name in ['component-boundary-audit-build.py', 'component-boundary-audit.mjs', 'component-boundary-audit-analyze.py', 'archive-component-boundary-audit.py']]
files += sorted((base / 'component-boundary-audit').glob('*'))
manifest = {path.as_posix(): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
with zipfile.ZipFile(destination, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        archive.write(path, path.as_posix())
    archive.writestr('sha256-manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    for name, digest in manifest.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest
print(json.dumps({'archive': str(destination), 'verifiedFiles': len(files)}))
