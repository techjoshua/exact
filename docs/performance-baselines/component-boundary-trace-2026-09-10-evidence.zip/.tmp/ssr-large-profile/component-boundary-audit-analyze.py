import json
from collections import Counter
from pathlib import Path

root = Path('.tmp/ssr-large-profile/component-boundary-audit')
results = {}
for mode in ['string', 'stream', 'stream-pressure']:
    events = json.loads((root / f'{mode}.trace.json').read_text())['traceEvents']
    stack, components = [], []
    for event in events:
        if event['ph'] == 'B':
            name = event['name'].rsplit(':', 1)[0]
            component = None
            if name == 'executeDirectSsrComponent':
                component = dict(event['args'], counts=Counter())
                components.append(component)
            stack.append((event['id'], component))
            active = next((frame for _, frame in reversed(stack) if frame), None)
            if active:
                active['counts'][name] += 1
        elif event['ph'] == 'E':
            assert stack and stack[-1][0] == event['id']
            stack.pop()
    assert not stack
    results[mode] = components
(root / 'component-counts.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
keys = ['prepareComponentProps', 'renderIssuedServerComponentChildren',
        'createPreparedServerRenderProgram', 'renderProgramWriter',
        'prepareDirectScheduledSsrComponentReferences', 'ChildrenOutput.render',
        'StringProgramSink.write', 'HeadPublishingSink.write']
for frame in results['string']:
    print(json.dumps({key: value for key, value in frame.items() if key != 'counts'}))
    print(json.dumps({key: frame['counts'].get(key, 0) for key in keys}))
print('Counts attribute synchronous call-stack entry only; resumed callbacks need separate attribution.')
