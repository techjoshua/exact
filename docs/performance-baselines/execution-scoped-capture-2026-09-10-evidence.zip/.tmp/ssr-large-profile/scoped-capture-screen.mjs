import fs from 'node:fs/promises';import {spawn} from 'node:child_process';import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/',rows=[];
for(const runtime of ['node','bun'])for(const [round,order] of [['baseline','candidate'],['candidate','baseline']].entries())for(const variant of order){
 const entry=root+(variant==='baseline'?'direct-execution-integrated/':'scoped-capture/')+'server-entry.js';
 const result=await new Promise((resolve,reject)=>{const child=spawn(runtime,[root+'flat-invocation-large-worker.mjs',entry,'encoded','small','20000'],{windowsHide:true,env:{...process.env,NODE_ENV:'production'}});let stdout='',stderr='';child.stdout.on('data',d=>stdout+=d);child.stderr.on('data',d=>stderr+=d);child.on('error',reject);child.on('exit',code=>resolve({code,stdout,stderr}));});assert.equal(result.code,0,result.stderr);
 const row={round,variant,...JSON.parse(result.stdout.trim())};rows.push(row);console.log(runtime,round,variant,row.usPerRender.toFixed(2));await fs.writeFile(root+'scoped-capture/screen.json',JSON.stringify(rows,null,2));
}
assert.equal(new Set(rows.map(r=>r.hash)).size,1);
