import fs from 'node:fs/promises';
import { spawn } from 'node:child_process';
import assert from 'node:assert/strict';

for (const runtime of ['node', 'bun']) for (const mode of ['string', 'stream']) {
  const result = await new Promise((resolve, reject) => {
    const child = spawn(process.execPath, ['../node_modules/@playwright/test/cli.js', 'test', '-c', 'playwright.config.ts', '--grep', 'exact|react'], {
      cwd: 'framework-comparison', windowsHide: true,
      env: { ...process.env, NODE_ENV: 'production', COMPARISON_E2E_RUNTIME: runtime, COMPARISON_SSR_RENDER_MODE: mode }
    });
    let log = '';
    child.stdout.on('data', data => log += data);
    child.stderr.on('data', data => log += data);
    child.on('error', reject);
    child.on('exit', code => resolve({ code, log }));
  });
  await fs.writeFile(`.tmp/ssr-large-profile/scoped-capture/browser-${runtime}-${mode}.log`, result.log);
  assert.equal(result.code, 0, result.log.slice(-9000));
  console.log(runtime, mode, 'passed');
}
