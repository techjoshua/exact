import fs from 'node:fs/promises';
const base='.tmp/ssr-large-profile/';
let runner=await fs.readFile(base+'http-jit-context.mjs','utf8');
runner=runner.replaceAll('http-jit-context/','http-jit-origin/');
runner=runner.replace("service=await startSsrLoadProcess('service');lower(service.child);", "runtime.arguments=['--expose-gc','--log-code','--log-function-events','--no-logfile-per-isolate','--logfile='+resolve(root+id+'.v8.log')];\n service=await startSsrLoadProcess('service');lower(service.child);");
await fs.writeFile(base+'http-jit-origin.mjs',runner);
