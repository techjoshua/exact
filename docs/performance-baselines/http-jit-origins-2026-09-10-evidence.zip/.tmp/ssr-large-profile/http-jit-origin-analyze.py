from pathlib import Path
from collections import Counter,defaultdict
from urllib.parse import unquote,urlparse
import re,json
root=Path.cwd();base=root/'.tmp/ssr-large-profile/http-jit-origin'
results=[]
for id in ['exact','react']:
    mapping={}
    for line in (base/(id+'.v8.log')).read_text(encoding='utf-8').splitlines():
        if not line.startswith('code-creation,JS,'):continue
        fields=re.split(r'(?<!\\),',line)
        if len(fields)<8 or not fields[7].startswith('0x'):continue
        location=re.search(r'((?:file://|node:|[A-Z]:).*?):(\d+):(\d+)$',fields[6])
        if not location:continue
        mapping[int(fields[7],16)&~1]={'location':fields[6],'url':location[1],'line':int(location[2]),'column':int(location[3])}
    phase='startup';events=[];cache={}
    for line in (base/(id+'.jit.log')).read_text().splitlines():
        if line.startswith('DIAGNOSTIC_PHASE '):phase=line.split(' ',1)[1];continue
        if not line.startswith('[completed compiling '):continue
        sfi=re.search(r'sfi = ([0-9A-Fa-f]+)',line)
        times=re.search(r'took ([\d.]+), ([\d.]+), ([\d.]+) ms',line)
        origin=mapping.get(int(sfi[1],16)&~1) if sfi else None
        if origin:
            origin=origin.copy();url=origin['url'];origin['module']=url
            if url.startswith('file:'):
                path=unquote(urlparse(url).path).lstrip('/')
                if path not in cache:
                    lines=Path(path).read_text(encoding='utf-8').splitlines();region='';regions=[]
                    for source in lines:
                        if source.startswith('//#region '):region=source[10:]
                        if source.startswith('//#endregion'):region=''
                        regions.append(region)
                    cache[path]=(lines,regions)
                lines,regions=cache[path];at=origin['line']-1
                origin['module']=regions[at] or path
                origin['source']=lines[at]
        events.append({'phase':phase,'origin':origin,'compileMs':sum(float(v) for v in times.groups()) if times else None,'raw':line})
    summary={}
    for p in sorted({e['phase'] for e in events}):
        group=[e for e in events if e['phase']==p];modules=Counter(e['origin']['module'] if e['origin'] else 'UNMAPPED' for e in group)
        summary[p]={'compilations':len(group),'reportedCompileMs':sum(e['compileMs'] or 0 for e in group),'modules':dict(modules)}
    results.append({'id':id,'summary':summary,'events':events})
    print(id,json.dumps(summary.get('http-after-loop'),indent=2))
    counts=Counter(e['origin']['location'] if e['origin'] else 'UNMAPPED' for e in events if e['phase']=='http-after-loop')
    print('Repeated locations:',json.dumps({k:v for k,v in counts.items() if v>1}))
(base/'origins.json').write_text(json.dumps(results,indent=2))
