import pathlib,json,hashlib,zipfile
d=pathlib.Path('.tmp/ssr-large-profile')
rows=json.loads((d/'production-refresh-results.json').read_text());assert len(rows)==32
table=[]
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['assets','large']:
   cell=[r for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario]
   exact=[r for r in cell if r['variant']=='exact'];react=[r for r in cell if r['variant']=='react']
   assert len(exact)==len(react)==2
   assert len({r['hash'] for r in exact})==len({r['hash'] for r in react})==1
   assert all(r['reactResolution']['version']=='19.2.0' for r in react)
   e=sum(r['usPerRender'] for r in exact)/2;r=sum(r['usPerRender'] for r in react)/2
   table.append(f'| {runtime} | {mode} | {scenario} | {e:.2f} | {r:.2f} | {(e/r-1)*100:+.1f}% |')
report=pathlib.Path('docs/performance-baselines/production-refresh-2026-09-09.md')
report.write_text('''# Current production renderer comparison

Date: 2026-09-09. Refreshed after cancellation ownership and sibling hydration compiler fixes.

This measures the actual current production implementation, not the staged writer, byte sink,
string sink, or component-capture experiments. The frozen eXact entry SHA-256 is
`3a0683d59c2264901d7e45eaf686e2d15b51e80eeaabc651f2062e77aea1bba2`.
The React entry SHA-256 is
`44914942423c766956063c2d963b8f384b64470ce1da517c44ef66c6a46a754a`.

Thirty-two fresh processes use production mode, 5,000 warmups and 12,000 measured renders each.
Each runtime/mode/scenario has two reversed framework-order pairs; scenario order also reverses.
Node 26.8.1 and Bun 1.4.2. Both applications render their own full document shell. The assets
scenario has three incidents and four assets; large has 96 incidents and the same four assets.
Workers assert doctype, closing body/html tags, all asset references, and stable document hashes
within each framework. Frameworks have different hydration payloads, so cross-framework hashes
are not expected to match.

React runs from its participant directory and resolves React DOM 19.2.0, using its Node/Bun
conditional server entry. Both frameworks use the same public streaming API category, with full
stream consumption through Response.text. These are renderer measurements, not HTTP requests/s
or browser startup measurements. Each string result includes the framework's hydration/bootstrap
output. All completed samples are retained. No build or test workload ran concurrently.

Means of the two samples, in microseconds per complete render. Positive differences mean eXact
takes more time. Raw individual samples and package resolutions are retained in the archive.

| Runtime | Mode | Scenario | eXact us | React us | eXact time difference |
| --- | --- | --- | ---: | ---: | ---: |
'''+ '\n'.join(table)+'''

## What this establishes

eXact wins both Node streaming cases and Bun's smaller streaming case. React still wins all
string cases and Bun's large streaming case. The production performance objective is not met.
The recent correctness fixes did not turn the experimental sink gains into production gains.
Prior HTTP and browser results should not be relabeled with these renderer timings.

Inspection of hydration serialization confirms that the existing implementation already projects
compiler-owned values into positional cells and uses native JSON.stringify. The three script-safe
escape replacements and live own-property checks remain. Previous recorded experiments already
tested combined escape scans and stale-key reuse; repeating those approaches without a new
hypothesis is not warranted. The latter can also miss getter-induced ownership changes.

The staged traversal and sink-specialization work remains the integration candidate, with the
browser-adoption evidence now available. It still requires native compiler/runtime integration
and broader boundary coverage before it can replace this production baseline. This refresh adds
no production code change and claims no new optimization.

Evidence includes the runner, worker, fixed input, both frozen participant artifacts, raw timings,
and verified SHA-256 hashes. Reproduction must execute React from its participant directory to
preserve dependency resolution; the archived copy is for evidence, not an alternate module root.
''',encoding='utf8')
files=list(d.glob('production-refresh-*'))
files += [pathlib.Path('.tmp/positional-leaves/data.json'),pathlib.Path('framework-comparison/participants/react/dist-server/server-entry.js'),report]
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
archive=report.with_name(report.stem+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name in manifest:z.write(name,name)
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('\n'.join(table));print('Verified',len(rows),'samples and',len(manifest),'archive hashes.')
