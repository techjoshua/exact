import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,copyFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const dir='.tmp/ssr-large-profile/';
copyFileSync('framework-comparison/participants/exact/dist-server/server-entry.js',dir+'production-refresh-exact.mjs');
copyFileSync(dir+'text-surroundings-comparison-worker.mjs',dir+'production-refresh-worker.mjs');
const rows=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(let round=0;round<2;round++)for(const scenario of round?['large','assets']:['assets','large'])for(const variant of round?['react','exact']:['exact','react']){
 const entry=variant==='exact'?dir+'production-refresh-exact.mjs':'framework-comparison/participants/react/dist-server/server-entry.js';
 const result=spawnSync(runtime,[dir+'production-refresh-worker.mjs',entry,mode,scenario,'12000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(result.status!==0)throw Error(result.stderr||result.stdout);
 const row={variant,round,runtimeId:runtime,artifactSha256:createHash('sha256').update(readFileSync(entry)).digest('hex'),...JSON.parse(result.stdout)};
 const peer=rows.find(x=>x.variant===variant&&x.mode===mode&&x.scenario===scenario&&x.runtimeId===runtime);
 if(peer&&peer.hash!==row.hash)throw Error('Unstable output');
 rows.push(row);writeFileSync(dir+'production-refresh-results.json',JSON.stringify(rows,null,2));console.log(runtime,mode,scenario,round,variant,row.usPerRender.toFixed(2));
}
