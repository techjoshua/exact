import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const mod=await import(pathToFileURL(resolve(process.argv[2])));
const rows=[];
for(const scenario of ['small','large'])for(const mode of ['string','stream'])for(let repeat=0;repeat<3;repeat++){
 const data=JSON.parse(readFileSync('.tmp/positional-leaves/data.json','utf8'));
 if(scenario==='large')data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
 const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
 if(mod.sinkAudit)for(const key of Object.keys(mod.sinkAudit))mod.sinkAudit[key]=0;
 const html=mode==='string'?await mod.renderParticipant(data,'/incidents/inc-101',options):await new Response(await mod.renderParticipantStream(data,'/incidents/inc-101',options)).text();
 if(!/^<!doctype html>/i.test(html)||!/<\/body><\/html>\s*$/i.test(html))throw Error('Incomplete document');
 rows.push({scenario,mode,repeat,characters:html.length,bytes:Buffer.byteLength(html),hash:createHash('sha256').update(html).digest('hex'),counts:mod.sinkAudit?{...mod.sinkAudit}:undefined});
}
console.log(JSON.stringify({runtime:process.versions.bun??process.version,rows}));
