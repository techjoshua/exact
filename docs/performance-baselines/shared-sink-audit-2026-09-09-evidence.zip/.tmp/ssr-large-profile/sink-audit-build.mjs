import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
let source=readFileSync(dir+'marker-hex-current.mjs','utf8');
function replace(before,after){if(source.split(before).length!==2)throw Error('Unexpected site: '+before);source=source.replace(before,after);}
replace('const output = program.ssr(generatedSsrOperations, context, invocation);',`const output = program.ssr(generatedSsrOperations, context, invocation);
 sinkAudit.programs++;
 sinkAudit.segments+=output.length;
 for(const segment of output){if(typeof segment==='string'){sinkAudit.staticSegments++;sinkAudit.segmentCharacters+=segment.length;}else sinkAudit.deferredSegments++;}`);
replace('function appendProgramText(output, html) {','function appendProgramText(output, html) { sinkAudit.programWrites++; sinkAudit.programWriteCharacters+=html.length;');
replace('function appendBoundedHtml(context, html, chunk) {','function appendBoundedHtml(context, html, chunk) { sinkAudit.boundedAppends++; sinkAudit.appendedCharacters+=chunk.length; sinkAudit.prefixCharacters+=html.length;');
replace('function continueProgramOutput(context, segments, render, start, output) {','function continueProgramOutput(context, segments, render, start, output) { sinkAudit.programTraversals++;');
replace('function renderChildWithTarget(context, child, target) {','function renderChildWithTarget(context, child, target) { sinkAudit.childVisits++;');
replace('function renderHydrationScriptValue(options, resumptionLayouts, capturedResumptions, byteTarget, encodedByteLength = utf8ByteLength) {','function renderHydrationScriptValue(options, resumptionLayouts, capturedResumptions, byteTarget, encodedByteLength = utf8ByteLength) { sinkAudit.hydrationPublications++;');
source+='\nexport const sinkAudit={programs:0,segments:0,staticSegments:0,deferredSegments:0,segmentCharacters:0,programWrites:0,programWriteCharacters:0,boundedAppends:0,appendedCharacters:0,prefixCharacters:0,programTraversals:0,childVisits:0,hydrationPublications:0};\n';
writeFileSync(dir+'sink-audit.mjs',source);
