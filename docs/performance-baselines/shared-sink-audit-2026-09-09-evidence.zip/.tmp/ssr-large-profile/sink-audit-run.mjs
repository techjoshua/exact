import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const dir='.tmp/ssr-large-profile/',results=[];
for(const runtime of ['node','bun'])for(const variant of ['marker-hex-current','sink-audit']){
 const entry=dir+variant+'.mjs';
 const r=spawnSync(runtime,[dir+'sink-audit-worker.mjs',entry],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 const result={runtimeId:runtime,variant,sha256:createHash('sha256').update(readFileSync(entry)).digest('hex'),...JSON.parse(r.stdout)};
 if(variant==='sink-audit'){
  const baseline=results.find(x=>x.runtimeId===runtime);
  for(let i=0;i<result.rows.length;i++)if(result.rows[i].hash!==baseline.rows[i].hash)throw Error('Instrumentation changed output');
 }
 results.push(result);
}
writeFileSync(dir+'sink-audit-results.json',JSON.stringify(results,null,2));
for(const result of results.filter(x=>x.variant==='sink-audit'))for(const row of result.rows.filter(x=>x.repeat===0))console.log(result.runtimeId,JSON.stringify(row));
