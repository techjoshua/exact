import { writeFileSync } from 'node:fs';
import { expect, it } from 'vitest';
import { renderToHydratableProgressiveHtmlStream } from './index.js';
import { configureControlledText, ControlledText } from './streams.fixtures.test.js';
import { createOperation } from './test-support/native-operations.js';

it('characterizes full-document first output while a body task remains pending', async () => {
 let release!: () => void;
 const ready = new Promise<void>((resolve) => { release = resolve; });
 configureControlledText(ready);
 const document = createOperation('html', null,
  createOperation('head', null, createOperation('link', { rel: 'stylesheet', href: '/early.css' })),
  createOperation('body', null, createOperation(ControlledText, { initial: 'Loading', settled: 'Ready' }))
 );
 const reader = renderToHydratableProgressiveHtmlStream(document, { markers: false }).getReader();
 let arrived = false;
 const first = reader.read().then((result) => { arrived = true; return result; });
 let html = '';
 try {
  await new Promise((resolve) => setTimeout(resolve, 50));
  const beforeRelease = arrived;
  release();
  const chunk = await first;
  const decoder = new TextDecoder();
  html += decoder.decode(chunk.value, { stream: true });
  while (true) {
   const chunk = await reader.read();
   if (chunk.done) break;
   html += decoder.decode(chunk.value, { stream: true });
  }
  html += decoder.decode();
  expect(html).toContain('/early.css');
  expect(html).toContain('Ready');
  expect(html).toContain('</body></html>');
  writeFileSync('../../.tmp/ssr-large-profile/sink-first-output.json', JSON.stringify({ firstChunkBeforeTaskRelease: beforeRelease, observationMs: 50, finalCharacters: html.length, html }, null, 2));
 } finally {
  release();
  await reader.cancel();
 }
});
