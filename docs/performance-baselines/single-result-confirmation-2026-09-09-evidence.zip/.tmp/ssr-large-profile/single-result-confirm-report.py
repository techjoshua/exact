import hashlib,json,pathlib,statistics,zipfile
root=pathlib.Path('.');work=root/'.tmp/ssr-large-profile'
batches=[json.loads((work/name).read_text(encoding='utf-8')) for name in ['single-result-results.json','single-result-confirm-results.json']];summary=[]
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['small','large']:
   changes=[]
   for batch in batches:
    for round in range(2):
     group=[r for r in batch if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['round']==round]
     a=next(r for r in group if r['variant']=='callback-current');b=next(r for r in group if r['variant']=='single-result')
     assert a['hash']==b['hash'];changes.append((b['usPerRender']/a['usPerRender']-1)*100)
   summary.append(dict(runtime=runtime,mode=mode,scenario=scenario,changes=changes,median=statistics.median(changes)))
table='\n'.join(f"| {s['runtime']} | {s['mode']} | {s['scenario']} | {s['median']:+.2f}% | {sum(x<0 for x in s['changes'])}/4 |" for s in summary)
dest=root/'docs/performance-baselines/single-result-confirmation-2026-09-09'
dest.with_suffix('.json').write_text(json.dumps(dict(summary=summary,batches=batches),indent=2)+'\n',encoding='utf-8')
doc='''# Single-chunk result confirmation and ownership audit

Date: 2026-09-09. Decision: do not adopt this candidate globally.

The [initial experiment](single-result-2026-09-09.md) warranted confirmation because small Node
strings and small streams improved in both pairs. This adds 32 fresh processes with identical
settings and reversed pair order: Node/Bun, string/consumed stream, three/96 incidents, 5,000 warmups
and 12,000 measured renders per population, NODE_ENV=production, complete authored documents,
empty client tags, same portable artifact, Response.text() stream consumption. All paired document
hashes match. Together the two batches contain four pairs per cell.

## Ownership findings

The production caller is tree-output.ts. It appends/prepends all output before passing
SsrOutputBuffer.finish() to createChunkedStringResult. The buffer is local to that completion
callback and is not subsequently written. Output extensions receive a materialized string and
their completed result becomes a fresh single-element array. Chunk consumers in output-result,
output-stream, and entrypoints read the readonly sequence; hydration insertion creates a separate
array. The audit found no supported post-construction mutation on this path.

Immediate capture is therefore consistent with current chunk ownership. The separate public
property-descriptor change remains: a data property permits assignment, whereas the existing
getter does not. This is not adopted implicitly. No compiler or artifact ABI change is necessary
to optimize result construction, but any public result behavior change needs coordinated review.

## Combined observations

Positive means longer rendering time. Medians are descriptive within-pair changes, not confidence
bounds. No observations were discarded.

| Runtime | Mode | Fixture | Median time change | Faster pairs |
| --- | --- | --- | ---: | ---: |
'''+table+'''

Small Node streaming improved in all four pairs. However, the initial Node string improvement
did not repeat in the confirmation batch, and large Bun strings were slower in three of four pairs.
This is a runtime/mode tradeoff, not a universal gain. With string rendering still an explicit
unresolved goal, this version is not adopted globally. The evidence remains useful for a distinct
result-layout experiment; it does not justify platform detection or a second rendering engine.

Production remains unchanged and prior improvements remain retained. No package/browser tests
were run for the bundle-only candidate. Full output hashes do not prove failure/lifecycle behavior.
The overall React parity goal is unmet. The archive preserves both batches and their reproduction
inputs, including frozen artifacts and SHA-256 hashes.
'''
dest.with_suffix('.md').write_text(doc,encoding='utf-8')
files=[work/name for name in ['callback-current.mjs','single-result.mjs','single-result-build.mjs','single-result-run.mjs','single-result-confirm-run.mjs','single-result-results.json','single-result-confirm-results.json','single-result-confirm-report.py','long-worker.mjs','segments-only-run.mjs']]+[root/'.tmp/positional-leaves/data.json']
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps({p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(table);print('Verified',archive)
