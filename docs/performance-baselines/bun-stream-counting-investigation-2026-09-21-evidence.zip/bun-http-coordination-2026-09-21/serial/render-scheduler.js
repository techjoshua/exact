import { clearImmediate, setImmediate } from 'node:timers';
import * as timerPromises from 'node:timers/promises';

// Experimental single-owner queue: only one native yield can be pending at a time.
export function createBunRenderScheduler(options = {}) {
 const limit = options.maxBatchSize ?? 32;
 if (!Number.isSafeInteger(limit) || limit < 1) throw new RangeError('maxBatchSize must be a positive safe integer');
 const scheduler = timerPromises.scheduler;
 const yieldTask = typeof scheduler?.yield === 'function' ? () => scheduler.yield() : undefined;
 let head, tail, pending;
 const detach = node => {
  if (node.previous) node.previous.next = node.next; else head = node.next;
  if (node.next) node.next.previous = node.previous; else tail = node.previous;
  node.previous = node.next = undefined;
  node.signal?.removeEventListener('abort', node.abort);
 };
 const schedule = () => {
  if (pending || !head) return;
  const token = {}; pending = token;
  const release = () => {
   if (pending !== token) return;
   pending = undefined;
   for (let count = 0; count < limit && head; count++) {
    const node = head; detach(node); node.resolve();
   }
   schedule();
  };
  const fail = reason => {
   if (pending !== token) return;
   pending = undefined;
   while (head) { const node = head; detach(node); node.reject(reason); }
  };
  try {
   if (yieldTask) void yieldTask().then(release, fail);
   else token.timer = setImmediate(release);
  } catch (reason) { fail(reason); }
 };
 return signal => new Promise((resolve, reject) => {
  if (signal?.aborted) { reject(signal.reason); return; }
  const node = {signal, resolve, reject, previous: tail, next: undefined, abort: undefined};
  node.abort = () => {
   detach(node); reject(signal.reason);
   if (!head && pending) {
    if (pending.timer !== undefined) clearImmediate(pending.timer);
    pending = undefined;
   }
  };
  if (tail) tail.next = node; else head = node;
  tail = node;
  signal?.addEventListener('abort', node.abort, {once:true});
  schedule();
 });
}
