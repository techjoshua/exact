/** Limits how many render starts one event-loop callback releases. */
export interface BunRenderSchedulerOptions {
    /** Maximum starts per batch. Defaults to 32; must be a positive safe integer. */
    maxBatchSize?: number;
}
/**
 * Creates a host-owned queue for native Fetch admission. Share one
 * scheduler across requests to batch starts through scheduler.yield(), falling
 * back to setImmediate when that API is unavailable. Cancellation
 * rejects promptly and removes the queued continuation. Batches release at most
 * maxBatchSize starts; render work and response ownership remain with SSR. This low-level gate
 * always yields. Bun request handlers apply automatic adaptive admission around it.
 */
export declare function createBunRenderScheduler(options?: BunRenderSchedulerOptions): (signal?: AbortSignal) => Promise<void>;
//# sourceMappingURL=render-scheduler.d.ts.map