/**
 * Independently owned loop-interval sampler. Bun's monitorEventLoopDelay instances share native
 * observation lifetime: disabling one can stop unrelated monitors. Recording our own timer
 * intervals avoids that coupling. Values include the requested two-millisecond interval, matching
 * the admission controller's delay thresholds. Neither response bodies nor requests are retained.
 */
export declare class BunEventLoopObserver {
    private readonly histogram;
    private timer;
    private previous;
    /** Starts this observer's unreferenced timer once. */
    enable(): void;
    /** Stops only this observer's timer; unrelated native monitors remain active. */
    disable(): void;
    /** Begins a fresh sample window without changing timer ownership. */
    reset(): void;
    /** Returns a percentile of observed loop intervals in nanoseconds. */
    percentile(value: number): number;
}
//# sourceMappingURL=event-loop-observer.d.ts.map