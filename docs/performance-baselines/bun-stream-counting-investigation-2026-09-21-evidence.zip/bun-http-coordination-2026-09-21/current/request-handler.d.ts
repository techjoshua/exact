/** Native Bun host observation available to its Fetch callback. */
export interface BunRequestServer {
    readonly pendingRequests: number;
}
/** Automatic native Fetch admission controls. */
export interface BunSchedulingOptions {
    /** Trials scheduling under sustained load and retains observed benefits. Defaults to true. */
    adaptive?: boolean;
    /** Maximum starts released per scheduled callback. Defaults to 32. */
    maxBatchSize?: number;
}
/**
 * Wraps an entire Bun.serve Fetch dispatcher with automatic admission. Pass Bun's server argument
 * through wrappers and route all HTTP requests through this handler, rather than Bun's routes map:
 * request drain is derived from all observed starts and the host's native pendingRequests counter.
 * Each request still executes its own handler and owns its original Response. Calls without a
 * native server remain immediate. Sparse traffic creates no monitoring timer.
 */
export declare function createBunRequestHandler<S extends BunRequestServer = BunRequestServer>(handler: (request: Request, server?: S) => Response | Promise<Response>, options?: BunSchedulingOptions): (request: Request, server?: S) => Response | Promise<Response>;
//# sourceMappingURL=request-handler.d.ts.map