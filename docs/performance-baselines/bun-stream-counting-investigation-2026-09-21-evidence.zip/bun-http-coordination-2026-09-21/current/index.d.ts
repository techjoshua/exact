import { type ExactResponseLike, type ExactServerContext } from '@exactjs/server';
import { type BunRequestServer, type BunSchedulingOptions } from './request-handler.js';
export { createBunRequestHandler, type BunRequestServer, type BunSchedulingOptions } from './request-handler.js';
/** Converts buffered text and produced streams through Bun's native Fetch response body lanes. */
export declare function exactResponseToBunResponse(result: ExactResponseLike): Response;
/** Creates a Bun.serve-compatible fetch handler for an eXact endpoint. */
export declare function createExactBunHandler(context: ExactServerContext, options?: BunSchedulingOptions): (request: Request, server?: BunRequestServer) => Promise<Response>;
export { createExactBunHandler as createBunHandler };
//# sourceMappingURL=index.d.ts.map