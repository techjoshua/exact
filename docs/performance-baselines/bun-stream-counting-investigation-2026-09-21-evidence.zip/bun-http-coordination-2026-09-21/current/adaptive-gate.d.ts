/**
 * Bun-owned admission controller. Lag triggers a trial; native request drain and lag
 * relative to surrounding immediate windows decide whether to retain it. Native departures include
 * disconnects, not just successful responses. Handler duration is
 * deliberately not treated as client latency because it excludes native response transmission.
 * Demand-limited trials may retain lower lag when native departures keep up with arrivals
 * and the event-loop thread has CPU headroom. Unsupported thread counters keep capacity-based
 * selection. A responsive selected policy tolerates isolated unhealthy samples before reassessment.
 * Sparse traffic creates no histogram or timer. Idle monitoring disables and releases its timer.
 */
export declare class BunRequestGate {
    private readonly pendingRequests;
    private delay;
    private timer;
    private lastRequest;
    private recentRequests;
    private requests;
    private arrivals;
    private windowArrivals;
    private windowPending;
    private started;
    private enabled;
    private highSamples;
    private phase;
    private nextPhase;
    private until;
    private cooldown;
    private backoff;
    private baseline;
    private trial;
    private controlRate;
    private controlLag;
    private cpu;
    private hadHeadroom;
    private unhealthySamples;
    /** Reads the host-wide native in-flight counter without intercepting response bodies. */
    constructor(pendingRequests: () => number);
    /** Observes every Fetch dispatch owned by this host. */
    observeRequest(): void;
    /** Whether the current request should enter the bounded render-start queue. */
    shouldSchedule(): boolean;
    /** Starts a window while retaining native bodies that have not drained yet. */
    private resetWindow;
    /** Reassesses capacity with immediate controls on both sides of a scheduled trial. */
    private sample;
    /** Drops the selected policy and its transient grace without resetting trial backoff. */
    private restartBaseline;
}
//# sourceMappingURL=adaptive-gate.d.ts.map