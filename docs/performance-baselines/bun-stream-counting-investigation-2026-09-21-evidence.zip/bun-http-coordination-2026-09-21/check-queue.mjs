import assert from 'node:assert/strict';
import {setImmediate, clearImmediate} from 'node:timers';
for (const variant of ['current','serial','serial-batches']) {
 const {createBunRenderScheduler}=await import(`./${variant}/render-scheduler.js`);
 const schedule=createBunRenderScheduler();
 const order=[],turns=[];let turn=0,marker;
 const tick=()=>{turn++;marker=setImmediate(tick);};marker=setImmediate(tick);
 try {await Promise.all(Array.from({length:128},(_,i)=>schedule().then(()=>{order.push(i);turns.push(turn);})));
 assert.deepEqual(order,Array.from({length:128},(_,i)=>i));
 }finally{clearImmediate(marker);}
 const counts={};for(const n of turns)counts[n]=(counts[n]??0)+1;
 console.log(variant,'starts by marker interval',counts);
 const controllers=Array.from({length:10},()=>new AbortController());
 const canceled=controllers.map(c=>schedule(c.signal).catch(e=>e));controllers.forEach(c=>c.abort('canceled'));
 assert.deepEqual(await Promise.all(canceled),Array(10).fill('canceled'));
 await schedule();
 const c=new AbortController();c.abort('already aborted');await assert.rejects(schedule(c.signal),e=>e==='already aborted');
 const pending=new AbortController();const aborted=schedule(pending.signal).catch(e=>e);const next=schedule();pending.abort('only one');assert.equal(await aborted,'only one');await next;
 for(const maxBatchSize of [0,-1,1.5,Infinity,NaN])assert.throws(()=>createBunRenderScheduler({maxBatchSize}),RangeError);
 const many=Array.from({length:96},()=>new AbortController());
 const promises=many.map(c=>schedule(c.signal).then(()=>true,()=>false));
 for(let i=32;i<64;i++)many[i].abort('middle batch');
 assert.deepEqual(await Promise.all(promises),Array.from({length:96},(_,i)=>i<32||i>=64));
 console.log(variant,'order, cancellation, reuse and limits passed');
}
