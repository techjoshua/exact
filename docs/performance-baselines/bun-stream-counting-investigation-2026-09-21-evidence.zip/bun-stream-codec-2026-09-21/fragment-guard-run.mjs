import {spawn} from 'node:child_process';import {openSync,closeSync,writeFileSync,readFileSync} from 'node:fs';
const dir='.tmp/bun-stream-codec-2026-09-21',journal=[];
const previous=JSON.parse(readFileSync(dir+'/fragment-execution.json'));if(previous.length!==4||!previous.every(s=>s.code===0))throw Error('Previous timing still active');
const cases=[
 ...['current','fragment-counter'].map(v=>[`fragment-node-stream-${v}`,`${v}-matrix`,'matrix-preloaded','stream','node']),
 ...['fragment-counter','current'].map(v=>[`fragment-string-demand-10000-${v}`,`${v}-demand`,'demand-10000','string','bun']),
 ...['current','fragment-counter'].map(v=>[`fragment-stream-demand-10000-${v}`,`${v}-demand`,'demand-10000','stream','bun'])
];
for(const [name,runner,plan,mode,runtime] of cases){
 const args=[`${dir}/${runner}.mjs`,`${dir}/${plan}.json`,`${dir}/${name}.json`,runtime];
 const step={name,args,mode,startedAt:new Date().toISOString()};journal.push(step);const save=()=>writeFileSync(dir+'/fragment-guard-execution.json',JSON.stringify(journal,null,2));save();console.log('START',name);const fd=openSync(dir+'/'+name+'.log','w');
 try{await new Promise((done,fail)=>{const p=spawn(process.execPath,args,{env:{...process.env,COMPARISON_SSR_RENDER_MODE:mode},stdio:['ignore',fd,fd]});step.pid=p.pid;save();p.once('error',fail);p.once('exit',code=>{step.code=code;code===0?done():fail(Error(name+' '+code));});});}finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}console.log('DONE',name);
}
