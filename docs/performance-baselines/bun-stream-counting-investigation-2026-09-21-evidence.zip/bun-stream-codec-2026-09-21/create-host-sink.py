from pathlib import Path
p=Path('packages/ssr/src/render')
base=(p/'document-stream-sink.ts').read_text()
for name in ['value','emittedBytes','bufferedBytes','lastCodeUnit','committed','pending','readonly maxBytes','readonly bufferSize','publishBody','assertOpen','fail']:
 base=base.replace('private '+name,'protected '+name)
(p/'document-stream-sink.ts').write_text(base)
candidate=Path('.tmp/bun-stream-codec-2026-09-21/document-stream-sink.fragment-candidate.ts').read_text()
def method(name,nextname):
 start=candidate.index('\n\t'+name);end=candidate.index('\n\t'+nextname,start)
 s=candidate[start:end];return s[:s.rfind('\n\t/**')] if '\n\t/**' in s else s
write=method('write(', 'ready(').replace('\n\twrite(', '\n\toverride write(')
ready=method('ready(', 'flush(').replace('\n\tready(', '\n\toverride ready(')
collect=method('private collect(', 'private account(')
s="""import { DocumentStreamSink } from './document-stream-sink.js';
import { SsrOutputLimitError } from './limits.js';
import type { RenderValue } from './execution.js';
import { utf8ByteLength } from './utf8.js';

/**
 * Groups progressive output for hosts where counting individual spans is expensive.
 * The base sink retains publication, pressure, cancellation, and exact byte-limit ownership.
 */
export class FragmentDocumentStreamSink extends DocumentStreamSink {
	private readonly unmeasured: string[] = [];
	private unmeasuredCharacters = 0;

	/** Accepts a span using conservative bounds, counting exactly before a possible limit failure. */
"""+write+"\n\n\t/** Collects a pending group when the exact flush threshold may have been reached. */\n"+ready+"""

	/** Collects pending spans before the base destination handles head or suspension boundaries. */
	override flush(reason: 'head' | 'await'): RenderValue<void> {
		this.assertOpen();
		if (!this.pending) this.collect();
		return super.flush(reason);
	}

	/** Includes every accepted fragment before final output accounting and publication. */
	override finish(prefix: readonly string[] = []): RenderValue<{ html: string; streamed: boolean }> {
		this.assertOpen();
		if (!this.pending) this.collect();
		return super.finish(prefix);
	}

	/** Releases pending fragments on completion, cancellation, and destination failure. */
	override destroy(): void {
		this.unmeasured.length = 0;
		this.unmeasuredCharacters = 0;
		super.destroy();
	}

	/** Counts each pending group without slicing or repeatedly scanning the accumulated prefix. */
"""+collect+'\n}\n'
(p/'fragment-document-stream-sink.ts').write_text(s)
s=(p/'tree-output.ts').read_text().replace("import { renderDocumentRootOutput", "import { FragmentDocumentStreamSink } from './fragment-document-stream-sink.js';\nimport { renderDocumentRootOutput")
marker='/** Renders one tree'
s=s.replace(marker,"// Bun benefits from grouped UTF-8 counting; Node retains its faster per-span sink.\nconst HostDocumentStreamSink =\n\ttypeof (globalThis as { Bun?: unknown }).Bun === 'object'\n\t\t? FragmentDocumentStreamSink\n\t\t: DocumentStreamSink;\n\n"+marker).replace('new DocumentStreamSink(context.maxOutputBytes','new HostDocumentStreamSink(context.maxOutputBytes')
(p/'tree-output.ts').write_text(s)
s=(p/'document-stream-sink.test.ts').read_text().replace("{ expect, it, vi }", "{ describe, expect, it, vi }")
s=s.replace("import { SsrOutputLimitError", "import { FragmentDocumentStreamSink } from './fragment-document-stream-sink.js';\nimport { SsrOutputLimitError")
a=s.index("it('publishes")
s=s[:a]+"describe.each([DocumentStreamSink, FragmentDocumentStreamSink])('%s', (Sink) => {\n"+s[a:].replace('new DocumentStreamSink(', 'new Sink(')+Path('.tmp/bun-stream-codec-2026-09-21/bounded-counter-test.txt').read_text().replace('new DocumentStreamSink(', 'new Sink(')+'\n});\n'
(p/'document-stream-sink.test.ts').write_text(s)
