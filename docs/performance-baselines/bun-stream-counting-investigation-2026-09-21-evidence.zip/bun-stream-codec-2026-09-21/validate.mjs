import {spawn} from 'node:child_process';
import {openSync,closeSync,readFileSync,writeFileSync} from 'node:fs';
const root='.tmp/bun-stream-codec-2026-09-21';
const prior=JSON.parse(readFileSync(root+'/node-confirm-execution.json'));
if(prior.length!==2||!prior.every(s=>s.code===0))throw Error('Timing still active');
if(!readFileSync('packages/ssr/src/render/fragment-document-stream-sink.ts','utf8').includes('this.unmeasured.push(html)'))throw Error('Candidate not adopted in source');
const npm='/home/techj/.npm/_npx/3c6effcf97752e7c/node_modules/npm/bin/npm-cli.js';
const cases=[
 ['format',['node_modules/prettier/bin/prettier.cjs','--write','packages/ssr/src/render/document-stream-sink.ts','packages/ssr/src/render/document-stream-sink.test.ts','packages/ssr/src/render/fragment-document-stream-sink.ts','packages/ssr/src/render/tree-output.ts','docs/ssr-hydration.md']],
 ['ssr-build',[npm,'run','build','-w','@exactjs/ssr']],
 ['ssr-tests',[npm,'run','test','-w','@exactjs/ssr']],
 ['bun-adapter-tests',[npm,'run','test','-w','@exactjs/bun-adapter']],
 ['bun-native-tests',[npm,'run','test:bun','-w','@exactjs/bun-adapter']],
 ['release-abi',[npm,'run','check:release-abi']],
 ['package-contents',['scripts/check-package-contents.mjs']],
 ['platform-boundaries',[npm,'run','check:platform-boundaries']],
 ['source-architecture',[npm,'run','check:source-architecture']],
 ['docs-types',[npm,'run','typecheck','-w','@exactjs/docs']]
];
const journal=[];
for(const [name,args] of cases){
 const step={name,args,startedAt:new Date().toISOString()};journal.push(step);const save=()=>writeFileSync(root+'/validation-execution.json',JSON.stringify(journal,null,2));save();console.log('START',name);const fd=openSync(root+'/validate-'+name+'.log','w');
 try{await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{stdio:['ignore',fd,fd],env:process.env});step.pid=child.pid;save();child.once('error',fail);child.once('exit',code=>{step.code=code;code===0?done():fail(Error(name+' '+code));});});}finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}console.log('DONE',name);
}
