import {spawn} from 'node:child_process';import {openSync,closeSync,writeFileSync,readFileSync} from 'node:fs';
const dir='.tmp/bun-stream-codec-2026-09-21',journal=[];
const previous=JSON.parse(readFileSync(dir+'/validation-execution.json'));if(previous.length!==10||!previous.every(s=>s.code===0))throw Error('Validation not complete');
const cases=[
 ...['current','host-fragment'].map(v=>[`host-stream-8000-${v}`,`${v}-demand`,'demand-8000','stream','bun']),
 ...['host-fragment','current'].map(v=>[`host-large-stream-${v}`,`${v}-large-matrix`,'matrix-preloaded','stream','bun']),
 ...['current','host-fragment'].map(v=>[`host-stream-10000-${v}`,`${v}-demand`,'demand-10000','stream','bun'])
];

for(const [name,runner,plan,mode,runtime] of cases){
 const args=[`${dir}/${runner}.mjs`,`${dir}/${plan}.json`,`${dir}/${name}.json`,runtime];
 const step={name,args,mode,startedAt:new Date().toISOString()};journal.push(step);const save=()=>writeFileSync(dir+'/host-execution.json',JSON.stringify(journal,null,2));save();console.log('START',name);const fd=openSync(dir+'/'+name+'.log','w');
 try{await new Promise((done,fail)=>{const p=spawn(process.execPath,args,{env:{...process.env,COMPARISON_SSR_RENDER_MODE:mode},stdio:['ignore',fd,fd]});step.pid=p.pid;save();p.once('error',fail);p.once('exit',code=>{step.code=code;code===0?done():fail(Error(name+' '+code));});});}finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}console.log('DONE',name);
}
