import json,hashlib
from pathlib import Path
roots=[Path('.tmp/bun-http-coordination-2026-09-21'),Path('.tmp/bun-stream-codec-2026-09-21')]
rows=[]
for root in roots:
 for p in sorted(root.glob('*.json')):
  d=json.loads(p.read_text())
  if not isinstance(d,dict) or not isinstance(d.get('blocks'),list):continue
  row={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'complete':d.get('complete'),'runtime':d.get('runtimeId'),'mode':d.get('renderMode'),'responseIdentities':d.get('responseIdentities'),'stages':[]}
  for b in d['blocks']:
   for i,stage in enumerate(d['plan']['stages']):
    if stage.get('discard'):continue
    ss=[r['stages'][i] for r in b['results']]
    total=lambda k:sum(s.get(k,0) for s in ss)
    row['stages'].append({'framework':b['id'],'name':stage['name'],'validRps':total('validRps'),'errors':total('errors'),'invalid':total('invalid'),'capacityMissPercent':100*total('missedCapacity')/total('offered') if total('offered') else 0,'responseP99Ms':[s['distributions']['responseMs']['p99'] for s in ss]})
  rows.append(row)
Path('.tmp/bun-stream-codec-2026-09-21/capture-inventory.json').write_text(json.dumps(rows,indent=2)+'\n')
print('captures',len(rows),'complete',sum(r['complete'] is True for r in rows))
