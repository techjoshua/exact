import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const dir=import.meta.dirname;
const derived=readFileSync('packages/ssr/dist/render/fragment-document-stream-sink.js','utf8').replace(/^import .*;\n/gm,'').replace('export class FragmentDocumentStreamSink','class FragmentDocumentStreamSink').replace(/^\/\/# sourceMappingURL=.*$/gm,'');
for(const runtime of ['bun','node']){
 const suffix=runtime==='node'?'-node':'';
 let original=readFileSync(`${dir}/current${suffix}-entry.js`,'utf8');
 const a=original.indexOf('var DocumentStreamSink = class {');const end=original.indexOf('//#endregion',a);
 assert.ok(a>=0&&end>a);
 const insertion=derived+'\nvar HostDocumentStreamSink = typeof globalThis.Bun === "object" ? FragmentDocumentStreamSink : DocumentStreamSink;\n';
 const output=(original.slice(0,end)+insertion+original.slice(end)).replaceAll('new DocumentStreamSink(', 'new HostDocumentStreamSink(');
 assert.equal(output.slice(a,end),original.slice(a,end));
 writeFileSync(`${dir}/host-fragment${suffix}-entry.js`,output);
}
for(const kind of ['demand','matrix','large-matrix','reverse-matrix']){
 const template=readFileSync(`${dir}/current-${kind}.mjs`,'utf8');
 writeFileSync(`${dir}/host-fragment-${kind}.mjs`,template.replaceAll('/current-entry.js','/host-fragment-entry.js').replaceAll("/current'+","/host-fragment'+"));
}
console.log('Copied original sink unchanged; derived implementation comes from built production source.');
