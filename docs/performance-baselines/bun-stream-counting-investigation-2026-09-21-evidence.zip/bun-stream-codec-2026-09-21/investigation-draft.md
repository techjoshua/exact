# Progressive document output investigation

This investigation follows the [rejected scheduler experiments](bun-loop-interval-investigation-2026-09-21.md). It compares HTTP admission spacing, encoding, and progressive document buffering against revision `cbf96b235efcf106beb3d4c75a2e41b99623e775`. Measurements use serial private Linux loopback namespaces, Bun 1.4.2, Node v26.9.0, and workspace-resolved 0.6.0 participants. Focused bundles change only the named implementation. The published historical reference is the [September 20 full capture](bun-admission-final-2026-09-20.md).

## Coordination and profiling

Yielding can give native HTTP processing and other callbacks an opportunity to run, but callback count alone does not establish useful coordination. A queue probe observed 128 request starts within one immediate-marker interval with the existing independent 32-request batches. Two prototypes released only one batch per interval. Both preserved cancellation and request ownership. Neither established an offered-load improvement without hurting string throughput, so neither was adopted.

Separate CPU profiles compared fixed-concurrency streaming with scheduled demand. Both sampled approximately 22.5% of elapsed time in native stream completion, 6.4% in UTF-8 byte counting, and 5% in buffer creation. These are sampled attribution observations, not precise native CPU costs. Profiling perturbs throughput, so those runs are not capacity results. Substituting TextEncoder or portable byte counting did not establish a useful improvement.

## Buffering algorithm

The progressive document sink previously counted every small emitted span and appended it to an accumulated string. The candidate retains pending spans in a request-owned array. UTF-16 length supplies a lower bound and three bytes per pending code unit supplies a conservative UTF-8 upper bound. When exact accounting is needed for an output limit, flush threshold, or publication, the sink joins and counts the pending group once. A surrogate pair crossing the collected-prefix boundary receives the same correction as before.

Exact output limits still apply before subsequent authored work proceeds. Head publication, body flush thresholds, closing-tag retention, hydration placement, backpressure, cancellation, and cleanup retain their contracts. The final variant selects grouped buffering only on Bun. Node and other hosts retain the original per-span sink. Neither runtime's admission controller changes. String rendering uses its existing separate collecting sink.

An earlier implementation sliced the uncounted suffix from the growing string. It improved the small streaming fixture but reduced larger-document throughput. That implementation was rejected, and its unfinished Node capture is excluded. The fragment-array version avoids repeatedly materializing that growing prefix.

## Focused observations

At Bun streaming 8,000 offered RPS, the fragment-buffer candidate produced 6,766 valid RPS versus 6,491 for the fresh control, a 4.2% increase. At 10,000 offered RPS it produced 6,697 versus 6,614, a 1.3% increase. Capacity misses remained substantial under overload. These results do not establish complete recovery of scheduled-demand performance. Bun string at 10,000 offered RPS was effectively unchanged at 9,979 valid RPS for both variants.

The larger 96-row streaming fixture improved eXact/React throughput ratios by approximately 16% at c32 and 13% at c128. Node short-protocol results varied with run order. Two publication-protocol pairs subsequently showed consistent c16 losses of approximately 4%, and c32 losses of 3.4% and 6.4%. The universal implementation was rejected. The final Bun-only variant subclasses the existing sink to share publication and cleanup while leaving Node's per-span implementation unchanged. Individual pairs are screening evidence, not confidence intervals.

The private candidate passed 640 output-equivalence cases against the original sink, including split UTF-16 surrogates, output-limit rejection position, emitted chunks, pressure, cancellation, and cleanup. Production-source validation and the full benchmark are recorded separately after adoption.

The structured capture inventory retains every complete result and labels incomplete captures. Response hashes are recorded by the later runners; no response differences were observed in matching fixture variants. Fixed-concurrency results, independent scheduled arrivals, and instrumented profiles answer different questions and are not pooled into one throughput claim.
