from pathlib import Path
p=Path(__file__).parent
s=(p/'current-entry.js').read_text();a=s.index('var DocumentStreamSink = class {');b=s.index('//#endregion',a);c=s[a:b]
c=c.replace('lastCodeUnit = NaN;', 'lastCodeUnit = NaN;\n\tunmeasured = [];\n\tunmeasuredCharacters = 0;',1)
x=c.index('\twrite(html) {');y=c.index('\n\t/** Flushes a full buffer',x)
c=c[:x]+'''	write(html) {
		this.assertOpen();
		if (!html) return;
		if (this.emittedBytes + this.value.length + this.unmeasuredCharacters + html.length > this.maxBytes) return this.fail(new SsrOutputLimitError(this.maxBytes));
		this.unmeasured.push(html);
		this.unmeasuredCharacters += html.length;
		if (this.emittedBytes + this.bufferedBytes + 3 * this.unmeasuredCharacters > this.maxBytes) {
			this.collect();
			if (this.emittedBytes + this.bufferedBytes > this.maxBytes) return this.fail(new SsrOutputLimitError(this.maxBytes));
		}
	}
	collect() {
		if (!this.unmeasuredCharacters) return;
		const html = this.unmeasured.length === 1 ? this.unmeasured[0] : this.unmeasured.join("");
		this.unmeasured.length = 0;
		this.unmeasuredCharacters = 0;
		let bytes = utf8ByteLength(html);
		const previous = this.lastCodeUnit;
		const next = html.charCodeAt(0);
		if (previous >= 55296 && previous <= 56319 && next >= 56320 && next <= 57343) bytes -= 2;
		this.bufferedBytes += bytes;
		this.value += html;
		this.lastCodeUnit = html.charCodeAt(html.length - 1);
	}'''+c[y:]
c=c.replace('if (this.committed && this.bufferedBytes >= this.bufferSize) return this.publishBody();','''if (this.committed && this.bufferedBytes + 3 * this.unmeasuredCharacters >= this.bufferSize) {
			this.collect();
			if (this.bufferedBytes >= this.bufferSize) return this.publishBody();
		}''')
c=c.replace('if (reason === "head"', 'this.collect();\n\t\tif (reason === "head"',1)
c=c.replace('if (!this.committed) {','this.collect();\n\t\tif (!this.committed) {',1)
c=c.replace('destroy() {\n\t\tthis.value = "";', 'destroy() {\n\t\tthis.unmeasured.length = 0;\n\t\tthis.unmeasuredCharacters = 0;\n\t\tthis.value = "";')
c=c.replace('publishBody(reserve = documentTail.length) {', 'publishBody(reserve = documentTail.length) {\n\t\tthis.collect();')
assert 'this.unmeasured.length = 0;' in c
s=s[:a]+c+s[b:];(p/'fragment-counter-entry.js').write_text(s);(p/'fragment-counter-sink-test-entry.js').write_text(s+'\nexport { DocumentStreamSink as TestSink };\n')
n=(p/'current-node-entry.js').read_text();na=n.index('var DocumentStreamSink = class {');nb=n.index('//#endregion',na);(p/'fragment-counter-node-entry.js').write_text(n[:na]+c+n[nb:])
for kind in ['demand','matrix','large-matrix']:
 template='current-'+kind+'.mjs';s=(p/template).read_text().replace('/current-entry.js','/fragment-counter-entry.js').replace("/current'+","/fragment-counter'+");(p/('fragment-counter-'+kind+'.mjs')).write_text(s)
s=(p/'check-bounded-counter.mjs').read_text().replace('./bounded-counter-sink-test-entry.js','./fragment-counter-sink-test-entry.js');(p/'check-fragment-counter.mjs').write_text(s)
