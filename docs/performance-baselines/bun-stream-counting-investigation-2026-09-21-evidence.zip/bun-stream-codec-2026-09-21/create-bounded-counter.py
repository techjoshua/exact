from pathlib import Path
p=Path(__file__).parent
s=(p/'current-entry.js').read_text()
a=s.index('var DocumentStreamSink = class {');b=s.index('//#endregion',a)
c=s[a:b].replace('lastCodeUnit = NaN;', 'countedCharacters = 0;')
x=c.index('\twrite(html) {');y=c.index('\n\t/** Flushes a full buffer',x)
c=c[:x]+'''\twrite(html) {
		this.assertOpen();
		if (!html) return;
		if (this.emittedBytes + this.value.length + html.length > this.maxBytes) return this.fail(new SsrOutputLimitError(this.maxBytes));
		this.value += html;
		if (this.emittedBytes + this.bufferedBytes + 3 * (this.value.length - this.countedCharacters) > this.maxBytes) {
			this.measure();
			if (this.emittedBytes + this.bufferedBytes > this.maxBytes) return this.fail(new SsrOutputLimitError(this.maxBytes));
		}
	}
	measure() {
		if (this.countedCharacters === this.value.length) return;
		let bytes = utf8ByteLength(this.value.slice(this.countedCharacters));
		const previous = this.value.charCodeAt(this.countedCharacters - 1);
		const next = this.value.charCodeAt(this.countedCharacters);
		if (previous >= 55296 && previous <= 56319 && next >= 56320 && next <= 57343) bytes -= 2;
		this.bufferedBytes += bytes;
		this.countedCharacters = this.value.length;
	}'''+c[y:]
c=c.replace('if (this.committed && this.bufferedBytes >= this.bufferSize) return this.publishBody();', '''if (this.committed && this.bufferedBytes + 3 * (this.value.length - this.countedCharacters) >= this.bufferSize) {
			this.measure();
			if (this.bufferedBytes >= this.bufferSize) return this.publishBody();
		}''')
c=c.replace('this.lastCodeUnit = NaN;', 'this.countedCharacters = 0;')
c=c.replace('this.bufferedBytes += utf8ByteLength(hints);', 'this.bufferedBytes = 0;\n\t\t\tthis.countedCharacters = 0;')
c=c.replace('this.bufferedBytes -= this.account(body);\n\t\tthis.value = this.value.slice(end);', 'this.account(body);\n\t\tthis.value = this.value.slice(end);\n\t\tthis.bufferedBytes = utf8ByteLength(this.value);\n\t\tthis.countedCharacters = this.value.length;')
assert 'lastCodeUnit' not in c
s=s[:a]+c+s[b:];(p/'bounded-counter-entry.js').write_text(s)
for v in ['current','bounded-counter']:
 (p/f'{v}-sink-test-entry.js').write_text((p/f'{v}-entry.js').read_text()+'\nexport { DocumentStreamSink as TestSink };\n')
s=(p/'current-demand.mjs').read_text().replace('/current-entry.js','/bounded-counter-entry.js');(p/'bounded-counter-demand.mjs').write_text(s)
