import json,hashlib,zipfile,subprocess,shutil
from pathlib import Path
root=Path('.tmp/bun-stream-codec-2026-09-21')
steps=json.loads((root/'host-execution.json').read_text())
assert len(steps)==6 and all(s.get('code')==0 for s in steps)
subprocess.run(['python3',str(root/'summarize.py')],check=True)
rows=json.loads((root/'capture-inventory.json').read_text())
complete=[r for r in rows if r['complete']]
assert all(s['errors']==0 and s['invalid']==0 for r in complete for s in r['stages'])
prefix=Path('docs/performance-baselines/bun-stream-counting-investigation-2026-09-21')
summary={'referenceRevision':'cbf96b235efcf106beb3d4c75a2e41b99623e775','scope':'HTTP coordination, encoding and progressive-output buffering experiments','captures':rows,'validation':json.loads((root/'validation-execution.json').read_text()),'adopted':'Bun-only FragmentDocumentStreamSink; Node original sink and both admission policies retained','limitations':['Individual pairs are not confidence intervals.','CPU profiles are diagnostic, not throughput evidence.','Incomplete captures are excluded.']}
prefix.with_suffix('.json').write_text(json.dumps(summary,indent=2)+'\n')
s=(root/'investigation-draft.md').read_text()
s+='\n## Final implementation guards\n\nThe Bun-only implementation passed the shared sink contracts and 480 SSR tests, Bun adapter unit and native integration tests, ABI compatibility, package-content and platform checks, source architecture, and docs type checking. The Node sink methods retain their original executable behavior; the runtime selection occurs once at module load.\n\n| Case | Variant | Framework | Stage | Valid RPS | Capacity misses | Response p99 range, ms |\n| --- | --- | --- | --- | ---: | ---: | ---: |\n'
for r in rows:
 if not Path(r['path']).name.startswith('host-') or not r['complete']:continue
 for stage in r['stages']:
  tails=stage['responseP99Ms'];s+='| '+' | '.join([Path(r['path']).stem,'grouped' if 'host-fragment' in r['path'] else 'control',stage['framework'],stage['name'],f"{stage['validRps']:,.0f}",f"{stage['capacityMissPercent']:.2f}%",f'{min(tails):.2f}–{max(tails):.2f}'])+' |\n'
s+=f'\nThe [structured inventory]({prefix.name}.json) retains {len(complete)} completed focused captures and labels {len(rows)-len(complete)} incomplete captures. The [evidence archive]({prefix.name}-evidence.zip) contains profiles, plans, source variants, capture logs, and validation logs. Full-framework results are published separately after measurement.\n'
prefix.with_suffix('.md').write_text(s)
for source in ['document-stream-sink.ts','fragment-document-stream-sink.ts','document-stream-sink.test.ts','tree-output.ts']:
 target=root/'adopted-source'/source;target.parent.mkdir(exist_ok=True);shutil.copyfile(Path('packages/ssr/src/render')/source,target)
archive=Path(str(prefix)+'-evidence.zip')
manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for directory in [Path('.tmp/bun-http-coordination-2026-09-21'),root]:
  for p in sorted(directory.rglob('*')):
   if not p.is_file():continue
   name=str(p.relative_to('.tmp'));b=p.read_bytes();manifest[name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};z.writestr(name,b)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print('Archived',len(manifest),'files',archive.stat().st_size,'bytes')
