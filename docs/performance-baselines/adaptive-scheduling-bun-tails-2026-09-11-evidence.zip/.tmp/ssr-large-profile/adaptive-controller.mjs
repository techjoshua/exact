/** Diagnostic lag policy; the host owns sampling and request counting. */
export class AdaptiveController {
 constructor(){this.reset();}
 reset(){this.enabled=false;this.high=0;this.baseline=0;this.trial=[];this.cooldownUntil=0;this.backoff=2000;this.transitions=[];this.samples=[];this.trialUntil=0;}
 observe(lag,requests,now){
  this.samples.push({lag,requests,now,enabled:this.enabled});
  if(requests<4){if(this.enabled)this.switch(false,now,'quiet');this.high=0;return;}
  if(!Number.isFinite(lag))return;
  if(this.enabled){
   if(this.trialUntil){this.trial.push(lag);if(now>=this.trialUntil){
    const average=this.trial.reduce((a,b)=>a+b,0)/this.trial.length;this.trialUntil=0;
    if(average>=this.baseline){this.switch(false,now,'no lag improvement');this.cooldownUntil=now+this.backoff;this.backoff=Math.min(30000,this.backoff*2);}
   }}
   return;
  }
  if(now<this.cooldownUntil)return;
  this.high=lag>3?this.high+1:0;
  if(this.high>=2){this.baseline=lag;this.trial=[];this.trialUntil=now+750;this.switch(true,now,'sustained lag');this.high=0;}
 }
 switch(enabled,now,reason){this.enabled=enabled;this.transitions.push({enabled,now,reason});}
}
