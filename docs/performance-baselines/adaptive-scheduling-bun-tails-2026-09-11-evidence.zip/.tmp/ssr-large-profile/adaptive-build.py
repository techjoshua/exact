from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'adaptive-lag';root.mkdir(exist_ok=True)
for runtime in ('node','bun'):
 folder=root/runtime;folder.mkdir(exist_ok=True)
 (folder/'adaptive-controller.mjs').write_bytes((base/'adaptive-controller.mjs').read_bytes())
 w=(base/'source-scheduler-bun/worker.mjs').read_text().replace("'../../../framework-adapters/","'../../../../framework-adapters/")
 w="import {AdaptiveController} from './adaptive-controller.mjs';\nlet auditVariant='normal',windowRequests=0;const adaptive=new AdaptiveController();\n"+w
 old="get scheduleRender(){return participantId==='exact'&&auditScheduled&&!auditLoopMode?scheduleSourceRender:undefined;}"
 new="get scheduleRender(){if(participantId!=='exact')return undefined;windowRequests++;return auditScheduled&&!auditLoopMode&&(auditVariant!=='adaptive'||adaptive.enabled)?scheduleSourceRender:undefined;}"
 assert old in w;w=w.replace(old,new)
 marker='const participantId = process.argv[2];'
 w=w.replace(marker,marker+"\nconst adaptiveDelay=participantId==='exact'?monitorEventLoopDelay({resolution:2}):undefined;adaptiveDelay?.enable();\nconst adaptiveTimer=participantId==='exact'?setInterval(()=>{const requests=windowRequests;windowRequests=0;if(auditVariant==='adaptive')adaptive.observe(adaptiveDelay.percentile(95)/1e6,requests,performance.now());adaptiveDelay.reset();},250):undefined;adaptiveTimer?.unref();")
 w=w.replace("auditScheduled=url.searchParams.get('defer')==='1';","auditScheduled=url.searchParams.get('defer')==='1';auditVariant=url.searchParams.get('variant')??'normal';adaptive.reset();windowRequests=0;adaptiveDelay?.reset();")
 w=w.replace('scheduleCalls:auditScheduleCalls','scheduleCalls:auditScheduleCalls,adaptive:{transitions:adaptive.transitions,samples:adaptive.samples}')
 w=w.replace('eventLoopDelay?.disable();','eventLoopDelay?.disable();adaptiveDelay?.disable();clearInterval(adaptiveTimer);')
 if runtime=='bun':w=w.replace('return { ...session, ...incidents };',"const data={ ...session, ...incidents }; data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)})); return data;")
 (folder/'worker.mjs').write_text(w)
 r=(base/'source-scheduler-bun-run.mjs').read_text().replace('source-scheduler-bun/',f'adaptive-lag/{runtime}/').replace('actual-source-scheduler-native-bun',f'adaptive-lag-{runtime}')
 r=r.replace("['string','stream']","['string']").replace("['normal','scheduled','normal']","(population?['normal','forced','adaptive','normal']:['normal','adaptive','forced','normal'])").replace("phase==='scheduled'","phase!=='normal'")
 r=r.replace("'audit-mode?defer='+(phase!=='normal'?'1':'0')","'audit-mode?defer='+(phase!=='normal'?'1':'0')+'&variant='+phase").replace('durationMs:5000},identity','durationMs:8000},identity').replace('report.blocks.length,16','report.blocks.length,10')
 if runtime=='node':r=r.replace("availableSsrRuntimes('bun')","availableSsrRuntimes('node')").replace("transport:'bun-fetch'","transport:'node-http'").replace('dist-bun-server/bun-server-entry.js','dist-server/server-entry.js')
 (base/f'adaptive-{runtime}-run.mjs').write_text(r)
