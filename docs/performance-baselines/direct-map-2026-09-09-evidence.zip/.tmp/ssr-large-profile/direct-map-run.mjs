import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const rows=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(let round=0;round<2;round++)for(const variant of round%2?['direct-map','callback-current']:['callback-current','direct-map']){
 const entry=`.tmp/ssr-large-profile/${variant}.mjs`;
 const r=spawnSync(runtime,['.tmp/ssr-large-profile/direct-map-worker.mjs',entry,mode,'small','12000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 const row={variant,round,runtimeId:runtime,artifactSha256:createHash('sha256').update(readFileSync(entry)).digest('hex'),...JSON.parse(r.stdout)};
 const peer=rows.find(x=>x.runtimeId===runtime&&x.mode===mode);
 if(peer&&peer.hash!==row.hash)throw Error('Output changed');
 rows.push(row);writeFileSync('.tmp/ssr-large-profile/direct-map-results.json',JSON.stringify(rows,null,2));console.log(runtime,mode,round,variant,row.usPerRender.toFixed(2));
}
