import { type Child } from '@exactjs/core';
import { createCompiledIntrinsicReceipt } from '@exactjs/core/runtime/component-operations';
import { describe, expect, it } from 'vitest';
import { createDirectSsrComponentFrame } from './direct-component-support.js';
import { renderToString } from './render-output.js';

describe('direct server map', () => {
	it('renders keyed intrinsic children in order through the shared renderer', async () => {
		const frame = createDirectSsrComponentFrame();
		const reads: string[] = [];
		const output = frame.map(
			['first', 'second'],
			(value) => {
				reads.push(`key:${value}`);
				return value;
			},
			(value) => {
				reads.push(`render:${value}`);
				return createCompiledIntrinsicReceipt('span', null, value);
			},
			'items'
		);
		const result = await renderToString(output as Child);
		expect(reads).toEqual(['render:first', 'key:first', 'render:second', 'key:second']);
		expect(result.html).toContain('<span>first</span>');
		expect(result.html).toContain('<span>second</span>');
		expect(result.html.indexOf('first')).toBeLessThan(result.html.indexOf('second'));
	});
});
