import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
const rows=JSON.parse(await fs.readFile(root+'consume-result-http.json','utf8'));
assert.equal(rows.length,72);
const summary=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream']){
 const group=rows.filter(r=>r.runtime===runtime&&r.mode===mode);
 const means=Object.fromEntries(['baseline','candidate','react'].map(variant=>{const values=group.filter(r=>r.variant===variant);assert.equal(values.length,6);return [variant,values.reduce((sum,r)=>sum+r.rps,0)/values.length];}));
 const pairs=Array.from({length:6},(_,block)=>{
  const values=Object.fromEntries(group.filter(r=>r.block===block).map(r=>[r.variant,r.rps]));
  return {block,...values,candidateChangePercent:(values.candidate/values.baseline-1)*100,reactGapPercent:(values.candidate/values.react-1)*100};
 });
 summary.push({runtime,mode,means,candidateChangePercent:(means.candidate/means.baseline-1)*100,reactGapPercent:(means.candidate/means.react-1)*100,improvedBlocks:pairs.filter(p=>p.candidate>p.baseline).length,pairs});
}
let valid=0,errors=0;for(const row of rows)for(const driver of row.results)for(const stage of driver.stages){valid+=stage.valid;errors+=stage.errors;}
await fs.writeFile(root+'consume-result-http-summary.json',JSON.stringify({valid,errors,summary},null,2));
console.log(JSON.stringify({valid,errors,summary:summary.map(({pairs,...row})=>row)},null,2));
