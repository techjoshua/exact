import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';
for(const [path,hash] of [
 ['framework-comparison/participants/exact/dist-server/server-entry.js','a8b8db9c44f62d0f42c0ebd69d932c3e36ec6b77234f62ae102d1e09a4c4820b'],
 ['framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js','96d6af2a10b08f1f30f81bab130f6b56daa2671e68145c3dcef2a4cef0714eb2'],
 [root+'direct-execution-integrated/server-entry.js','2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18'],
 [root+'direct-execution-integrated/bun-server-entry.js','9adc04f4d5d6e78ad95730319a475918c3b4b045da9a93f812c81aa827d60d2e']
 ])assert.equal(createHash('sha256').update(await fs.readFile(path)).digest('hex'),hash);
let source=await fs.readFile(root+'stage-hydration-interleaved.mjs','utf8');
source=source.replaceAll("'normal'","'candidate'").replaceAll("'diagnostic'","'baseline'").replaceAll('Interleaved hydration cost diagnostic','Integrated result finalization HTTP comparison');
source=source.replace("root+'stage-hydration-'+runtime.id+'/server-entry.js'","root+'direct-execution-integrated/'+(runtime.id==='bun'?'bun-server-entry.js':'server-entry.js')");
source=source.replace("for(const runtime of availableSsrRuntimes('node,bun')){","for(const runtime of availableSsrRuntimes('node,bun'))for(const mode of ['string','stream']){").replace("COMPARISON_SSR_RENDER_MODE:'string'","COMPARISON_SSR_RENDER_MODE:mode");
source=source.replace('runtime:runtime.id,runtimeVersion','mode,runtime:runtime.id,runtimeVersion').replaceAll("console.log(runtime.id,","console.log(runtime.id,mode,").replaceAll('stage-hydration-interleaved.json','consume-result-http.json').replace('rows.length,36','rows.length,72');
await fs.writeFile(root+'consume-result-http.mjs',source);
console.log('Verified artifacts and prepared 72 interleaved blocks.');
