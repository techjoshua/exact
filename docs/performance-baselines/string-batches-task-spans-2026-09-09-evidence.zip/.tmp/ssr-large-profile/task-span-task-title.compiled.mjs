import { createPreparedServerRenderProgram as __exactPreparedServerRenderProgram, prepareCompiledRenderProgram as __exactPrepareRenderProgram } from "@exactjs/core/framework/server-render-structure";
import { awaitServerComponentTask as __exactServerTaskAwait, activateServerComponentTaskForHost as __exactActivateServerTask } from "@exactjs/core/framework/server-component-execution";
import { TaskContext, type Component } from '@exactjs/core';
import { issueExactServerComponent as __exactIssueServerComponent_1, writeExactServerComponent as __exactWriteServerComponent_1, disposeExactServerComponent as __exactDisposeServerComponent_1 } from "@exactjs/core/runtime/component-operations";
import { rejectDirectServerComponentConstruction as __exactRejectDirectServerConstruction_1 } from "@exactjs/core/runtime/component-construction/direct-server";
const __exactComponentContract_1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
const __exact_server_task_slice_1 = [[], [[0, ["title"]]], "blocking", "load"] as const;
const __exact_render_program_1 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xHXQhNTbC1y_VUu59XGLutW", namespace: "html", ssrRootStatic: ["", [], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
        const __exactValue_0 = __exactInvocation.eagerValues[0];
        const __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
        if (__exactValue_1 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 2, 15, 15);
        const __exactOutput = __exactSsr.output();
        let __exactCharacters = 15;
        __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "title", "<title", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
        __exactCharacters = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true);
        __exactSsr.static(__exactOutput, "</title>");
        return __exactOutput;
    }, ssrHost: "title" });
const __exact_render_program_2 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xWnLkB1KlW9ncUnZ3n_NKtx", namespace: "html", ssrRootStatic: [" data-exact-id=\"xgD2nE_9p2WumDdvTCeMNlc\"", ["data-exact-id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
        const __exactValue_0 = __exactInvocation.eagerValues[0];
        const __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
        if (__exactValue_1 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 2, 13, 13);
        const __exactOutput = __exactSsr.output();
        let __exactCharacters = 13;
        __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "head", "<head", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
        __exactSsr.keyedChild(__exactOutput, __exactValue_1);
        __exactSsr.static(__exactOutput, "</head>");
        return __exactOutput;
    }, ssrHost: "head" });
const __exact_render_program_3 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xxf6nDmcb_ePEr7ufchSTvS", namespace: "html", ssrRootStatic: ["", [], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
        const __exactValue_0 = __exactInvocation.eagerValues[0];
        const __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
        if (__exactValue_1 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 2, 13, 13);
        const __exactOutput = __exactSsr.output();
        let __exactCharacters = 13;
        __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "main", "<main", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
        __exactCharacters = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true);
        __exactSsr.static(__exactOutput, "</main>");
        return __exactOutput;
    }, ssrHost: "main" });
const __exact_render_program_4 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xjbjdY2t3jVM2fFWWc2JZ7n", namespace: "html", ssrRootStatic: [" data-exact-id=\"xrfrhWAbjwEGNChwOQ2N0FK\"", ["data-exact-id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
        const __exactValue_0 = __exactInvocation.eagerValues[0];
        const __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
        if (__exactValue_1 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 2, 13, 13);
        const __exactOutput = __exactSsr.output();
        let __exactCharacters = 13;
        __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "body", "<body", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
        __exactSsr.keyedChild(__exactOutput, __exactValue_1);
        __exactSsr.static(__exactOutput, "</body>");
        return __exactOutput;
    }, ssrHost: "body" });
const __exact_render_program_5 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xo952AB1LG2xdY1uhXU3XGi", namespace: "html", ssrRootStatic: [" data-exact-id=\"xTN2EkhR5P6sCcDpfT-MATI\"", ["data-exact-id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
        const __exactValue_0 = __exactInvocation.eagerValues[0];
        const __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
        if (__exactValue_1 === __exactSsr.unprepared)
            return;
        const __exactValue_2 = __exactSsr.prepareChild(__exactInvocation, 2);
        if (__exactValue_2 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 3, 13, 13);
        const __exactOutput = __exactSsr.output();
        let __exactCharacters = 13;
        __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "html", "<html", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
        __exactSsr.keyedChild(__exactOutput, __exactValue_1);
        __exactSsr.keyedChild(__exactOutput, __exactValue_2);
        __exactSsr.static(__exactOutput, "</html>");
        return __exactOutput;
    }, ssrHost: "html" });
const __exactImplementation_Document_1 = function Document(this: Component<{
    body: string;
    title: string;
    css: string;
    page: {
        title: string;
        body: string;
    };
}>, props: {
    css: string;
}) {
    this.state.body = 'loading';
    this.state.title = 'Initial';
    this.state.css = '/initial.css';
    this.state.page = { title: 'Initial', body: 'loading' };
    __exactActivateServerTask(this, __exact_server_task_slice_1, "x1YxJqf_lT2JMTZ8Vlbkn1-", async (_task: TaskContext) => { await __exactServerTaskAwait(_task.signal, Promise.resolve()); this.state.title = "ready"; });
    return () => __exactPreparedServerRenderProgram(__exact_render_program_5, [{ "data-exact-id": "xTN2EkhR5P6sCcDpfT-MATI" }, __exactPreparedServerRenderProgram(__exact_render_program_2, [{ "data-exact-id": "xgD2nE_9p2WumDdvTCeMNlc" }, __exactPreparedServerRenderProgram(__exact_render_program_1, [{}, this.state.title])]), __exactPreparedServerRenderProgram(__exact_render_program_4, [{ "data-exact-id": "xrfrhWAbjwEGNChwOQ2N0FK" }, __exactPreparedServerRenderProgram(__exact_render_program_3, [{}, this.state.body])])]);
};
export const Document = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Document_1, {
    [Symbol.for("@exactjs/component")]: "x64j1cFVFP06Lo_vxnYCfTh",
    [__exactComponentContract_1]: {
        version: 1,
        placement: "server",
        role: "executor",
        implementations: [
            { id: "xP63bCFOOO79tHdquoLNUVj", name: "Document", role: "root", implementation: __exactImplementation_Document_1 }
        ],
        continuations: [
            {
                kind: "task",
                id: "x1YxJqf_lT2JMTZ8Vlbkn1-",
                componentId: "x64j1cFVFP06Lo_vxnYCfTh",
                readiness: "blocking",
                concurrency: "latest",
                dependencies: [],
                stateReads: [],
                stateWrites: [
                    {
                        path: "title",
                        kind: "write",
                        confidence: "exact"
                    }
                ],
                publicContexts: [],
                serverContexts: [],
                contextWrites: [],
                serverContextWrites: [],
                boundaries: []
            }
        ],
        executors: [
            {
                id: "x1YxJqf_lT2JMTZ8Vlbkn1-",
                componentId: "x64j1cFVFP06Lo_vxnYCfTh",
                execute: async (__exactActivation_1: any, __exactExecution_1: any) => {
                    const __exactComponent_1 = { state: __exactActivation_1.state } as {
                        state: {
                            body: string;
                            title: string;
                            css: string;
                            page: {
                                title: string;
                                body: string;
                            };
                        };
                    };
                    const __exactContextWrites_1 = {};
                    await (async (_task: TaskContext) => { await __exactServerTaskAwait(_task.signal, Promise.resolve()); __exactComponent_1.state.title = "ready"; })(__exactExecution_1.task);
                    return { state: __exactComponent_1.state, contexts: __exactContextWrites_1 };
                }
            }
        ],
        boundaries: [],
        artifact: {
            version: 1,
            target: "server",
            id: "x64j1cFVFP06Lo_vxnYCfTh",
            instantiate: __exactImplementation_Document_1,
            construct: __exactRejectDirectServerConstruction_1,
            abi: 9,
            capabilities: [
                "tasks",
                "continuations"
            ],
            state: [
                "body",
                "css",
                "page",
                "title"
            ],
            props: [],
            issue: __exactIssueServerComponent_1,
            write: __exactWriteServerComponent_1,
            dispose: __exactDisposeServerComponent_1,
            execution: {
                version: 1,
                classification: "scheduled",
                lane: "direct",
                render: __exactImplementation_Document_1
            },
            tasks: [
                "x1YxJqf_lT2JMTZ8Vlbkn1-"
            ],
            reactive: [
                {
                    name: "load",
                    provenance: "unknown",
                    allocation: "constant",
                    dependencies: []
                },
                {
                    name: "props",
                    provenance: "props",
                    allocation: "live-slot",
                    dependencies: []
                },
                {
                    name: "this",
                    provenance: "state",
                    allocation: "live-slot",
                    dependencies: []
                }
            ],
            render: "returned-function"
        }
    }
}) as typeof __exactImplementation_Document_1)();
