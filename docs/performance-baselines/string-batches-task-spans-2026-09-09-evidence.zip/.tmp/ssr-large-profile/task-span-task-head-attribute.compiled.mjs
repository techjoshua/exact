import { createPreparedServerRenderProgram as __exactPreparedServerRenderProgram, prepareCompiledRenderProgram as __exactPrepareRenderProgram } from "@exactjs/core/framework/server-render-structure";
import { awaitServerComponentTask as __exactServerTaskAwait, activateServerComponentTaskForHost as __exactActivateServerTask } from "@exactjs/core/framework/server-component-execution";
import { TaskContext, type Component } from '@exactjs/core';
import { issueExactServerComponent as __exactIssueServerComponent_1, writeExactServerComponent as __exactWriteServerComponent_1, disposeExactServerComponent as __exactDisposeServerComponent_1 } from "@exactjs/core/runtime/component-operations";
import { rejectDirectServerComponentConstruction as __exactRejectDirectServerConstruction_1 } from "@exactjs/core/runtime/component-construction/direct-server";
const __exactComponentContract_1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
const __exact_server_task_slice_1 = [[], [[0, ["css"]]], "blocking", "load"] as const;
const __exact_render_program_1 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xSEsVE7XRQA57AXuWXAJN1y", namespace: "html", ssrRootStatic: [" rel=\"stylesheet\"", ["rel"], [[3, "href", "href"]], __exactRootValue => ({ rel: "stylesheet", href: __exactRootValue })], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
        const __exactValue_0 = __exactInvocation.eagerValues[0];
        __exactSsr.begin(__exactContext, 1, 1, 6, 6);
        const __exactOutput = __exactSsr.output();
        let __exactCharacters = 6;
        __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "link", "<link", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
        return __exactOutput;
    }, ssrHost: "link" });
const __exact_render_program_2 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xW9d5PgXlXhPaNtwOBsKamT", namespace: "html", ssrRootStatic: [" data-exact-id=\"xVJE6iAoUeHCDdfzSpDpgPB\"", ["data-exact-id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
        const __exactValue_0 = __exactInvocation.eagerValues[0];
        const __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
        if (__exactValue_1 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 2, 13, 13);
        const __exactOutput = __exactSsr.output();
        let __exactCharacters = 13;
        __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "head", "<head", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
        __exactSsr.keyedChild(__exactOutput, __exactValue_1);
        __exactSsr.static(__exactOutput, "</head>");
        return __exactOutput;
    }, ssrHost: "head" });
const __exact_render_program_3 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xozFDVvhxGPelHkhdDUAroU", namespace: "html", ssrRootStatic: ["", [], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
        const __exactValue_0 = __exactInvocation.eagerValues[0];
        const __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
        if (__exactValue_1 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 2, 13, 13);
        const __exactOutput = __exactSsr.output();
        let __exactCharacters = 13;
        __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "main", "<main", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
        __exactCharacters = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true);
        __exactSsr.static(__exactOutput, "</main>");
        return __exactOutput;
    }, ssrHost: "main" });
const __exact_render_program_4 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xwNoEP3XJFewA8xZ_G4pdb5", namespace: "html", ssrRootStatic: [" data-exact-id=\"xlbKkdeaW4PLTdEiNd0jGvq\"", ["data-exact-id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
        const __exactValue_0 = __exactInvocation.eagerValues[0];
        const __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
        if (__exactValue_1 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 2, 13, 13);
        const __exactOutput = __exactSsr.output();
        let __exactCharacters = 13;
        __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "body", "<body", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
        __exactSsr.keyedChild(__exactOutput, __exactValue_1);
        __exactSsr.static(__exactOutput, "</body>");
        return __exactOutput;
    }, ssrHost: "body" });
const __exact_render_program_5 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xcjc9Xo3G9E1xc2pj7vpIoV", namespace: "html", ssrRootStatic: [" data-exact-id=\"xPU2SWGZnDwG892D2KOrpX2\"", ["data-exact-id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
        const __exactValue_0 = __exactInvocation.eagerValues[0];
        const __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
        if (__exactValue_1 === __exactSsr.unprepared)
            return;
        const __exactValue_2 = __exactSsr.prepareChild(__exactInvocation, 2);
        if (__exactValue_2 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 3, 13, 13);
        const __exactOutput = __exactSsr.output();
        let __exactCharacters = 13;
        __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "html", "<html", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
        __exactSsr.keyedChild(__exactOutput, __exactValue_1);
        __exactSsr.keyedChild(__exactOutput, __exactValue_2);
        __exactSsr.static(__exactOutput, "</html>");
        return __exactOutput;
    }, ssrHost: "html" });
const __exactImplementation_Document_1 = function Document(this: Component<{
    body: string;
    title: string;
    css: string;
    page: {
        title: string;
        body: string;
    };
}>, props: {
    css: string;
}) {
    this.state.body = 'loading';
    this.state.title = 'Initial';
    this.state.css = '/initial.css';
    this.state.page = { title: 'Initial', body: 'loading' };
    __exactActivateServerTask(this, __exact_server_task_slice_1, "xAxjLb-TBRV5lIp1sBkMNNP", async (_task: TaskContext) => { await __exactServerTaskAwait(_task.signal, Promise.resolve()); this.state.css = "/ready.css"; });
    return () => __exactPreparedServerRenderProgram(__exact_render_program_5, [{ "data-exact-id": "xPU2SWGZnDwG892D2KOrpX2" }, __exactPreparedServerRenderProgram(__exact_render_program_2, [{ "data-exact-id": "xVJE6iAoUeHCDdfzSpDpgPB" }, __exactPreparedServerRenderProgram(__exact_render_program_1, [this.state.css])]), __exactPreparedServerRenderProgram(__exact_render_program_4, [{ "data-exact-id": "xlbKkdeaW4PLTdEiNd0jGvq" }, __exactPreparedServerRenderProgram(__exact_render_program_3, [{}, this.state.body])])]);
};
export const Document = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Document_1, {
    [Symbol.for("@exactjs/component")]: "xtsEWvTOFRDOjs278CHI2eC",
    [__exactComponentContract_1]: {
        version: 1,
        placement: "server",
        role: "executor",
        implementations: [
            { id: "xYjxJROfat41r4XhJ5tnbCq", name: "Document", role: "root", implementation: __exactImplementation_Document_1 }
        ],
        continuations: [
            {
                kind: "task",
                id: "xAxjLb-TBRV5lIp1sBkMNNP",
                componentId: "xtsEWvTOFRDOjs278CHI2eC",
                readiness: "blocking",
                concurrency: "latest",
                dependencies: [],
                stateReads: [],
                stateWrites: [
                    {
                        path: "css",
                        kind: "write",
                        confidence: "exact"
                    }
                ],
                publicContexts: [],
                serverContexts: [],
                contextWrites: [],
                serverContextWrites: [],
                boundaries: []
            }
        ],
        executors: [
            {
                id: "xAxjLb-TBRV5lIp1sBkMNNP",
                componentId: "xtsEWvTOFRDOjs278CHI2eC",
                execute: async (__exactActivation_1: any, __exactExecution_1: any) => {
                    const __exactComponent_1 = { state: __exactActivation_1.state } as {
                        state: {
                            body: string;
                            title: string;
                            css: string;
                            page: {
                                title: string;
                                body: string;
                            };
                        };
                    };
                    const __exactContextWrites_1 = {};
                    await (async (_task: TaskContext) => { await __exactServerTaskAwait(_task.signal, Promise.resolve()); __exactComponent_1.state.css = "/ready.css"; })(__exactExecution_1.task);
                    return { state: __exactComponent_1.state, contexts: __exactContextWrites_1 };
                }
            }
        ],
        boundaries: [],
        artifact: {
            version: 1,
            target: "server",
            id: "xtsEWvTOFRDOjs278CHI2eC",
            instantiate: __exactImplementation_Document_1,
            construct: __exactRejectDirectServerConstruction_1,
            abi: 9,
            capabilities: [
                "tasks",
                "continuations"
            ],
            state: [
                "body",
                "css",
                "page",
                "title"
            ],
            props: [],
            issue: __exactIssueServerComponent_1,
            write: __exactWriteServerComponent_1,
            dispose: __exactDisposeServerComponent_1,
            execution: {
                version: 1,
                classification: "scheduled",
                lane: "direct",
                render: __exactImplementation_Document_1
            },
            tasks: [
                "xAxjLb-TBRV5lIp1sBkMNNP"
            ],
            reactive: [
                {
                    name: "load",
                    provenance: "unknown",
                    allocation: "constant",
                    dependencies: []
                },
                {
                    name: "props",
                    provenance: "props",
                    allocation: "live-slot",
                    dependencies: []
                },
                {
                    name: "this",
                    provenance: "state",
                    allocation: "live-slot",
                    dependencies: []
                }
            ],
            render: "returned-function"
        }
    }
}) as typeof __exactImplementation_Document_1)();
