import { TaskContext, type Component } from '@exactjs/core';
export function Document(this: Component<{body:string;title:string;css:string;page:{title:string;body:string}}>, props:{css:string}) {
 this.state.body='loading';this.state.title='Initial';this.state.css='/initial.css';this.state.page={title:'Initial',body:'loading'};
 
 const load=async (_task:TaskContext=TaskContext.server().blocking())=>{ await Promise.resolve(); this.state.body = "ready"; };
 load();
 return ()=><html><head><title>Operations</title></head><body><main>{this.state.body}</main></body></html>;
}