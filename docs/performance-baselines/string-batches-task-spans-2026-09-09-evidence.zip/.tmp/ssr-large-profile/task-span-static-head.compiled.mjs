import { createPreparedServerRenderProgram as __exactPreparedServerRenderProgram, prepareCompiledRenderProgram as __exactPrepareRenderProgram } from "@exactjs/core/framework/server-render-structure";
import { awaitServerComponentTask as __exactServerTaskAwait, activateServerComponentTaskForHost as __exactActivateServerTask } from "@exactjs/core/framework/server-component-execution";
import { TaskContext, type Component } from '@exactjs/core';
import { issueExactServerComponent as __exactIssueServerComponent_1, writeExactServerComponent as __exactWriteServerComponent_1, disposeExactServerComponent as __exactDisposeServerComponent_1 } from "@exactjs/core/runtime/component-operations";
import { rejectDirectServerComponentConstruction as __exactRejectDirectServerConstruction_1 } from "@exactjs/core/runtime/component-construction/direct-server";
const __exactComponentContract_1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
const __exact_server_task_slice_1 = [[], [[0, ["body"]]], "blocking", "load"] as const;
const __exact_render_program_1 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "x9VbfBa1f_Eel1f9uHIMZqc", namespace: "html", ssrRootStatic: [" data-exact-id=\"xqvQ9eP8x2yvcTnzmxhabYL\"", ["data-exact-id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
        const __exactValue_0 = __exactInvocation.eagerValues[0];
        __exactSsr.begin(__exactContext, 2, 1, 38, 38);
        const __exactOutput = __exactSsr.output();
        let __exactCharacters = 38;
        __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "head", "<head", "><title>Operations</title></head>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
        return __exactOutput;
    }, ssrHost: "head" });
const __exact_render_program_2 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xnIWYIdsyBvDJHgZY1vS2ve", namespace: "html", ssrRootStatic: ["", [], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
        const __exactValue_0 = __exactInvocation.eagerValues[0];
        const __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
        if (__exactValue_1 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 2, 13, 13);
        const __exactOutput = __exactSsr.output();
        let __exactCharacters = 13;
        __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "main", "<main", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
        __exactCharacters = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true);
        __exactSsr.static(__exactOutput, "</main>");
        return __exactOutput;
    }, ssrHost: "main" });
const __exact_render_program_3 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xhruag-0aK1hiFSpFG5Mxtc", namespace: "html", ssrRootStatic: [" data-exact-id=\"xatX6QXhVIEKV3fGZSx-n43\"", ["data-exact-id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
        const __exactValue_0 = __exactInvocation.eagerValues[0];
        const __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
        if (__exactValue_1 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 2, 13, 13);
        const __exactOutput = __exactSsr.output();
        let __exactCharacters = 13;
        __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "body", "<body", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
        __exactSsr.keyedChild(__exactOutput, __exactValue_1);
        __exactSsr.static(__exactOutput, "</body>");
        return __exactOutput;
    }, ssrHost: "body" });
const __exact_render_program_4 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xobh03bObmOQAMT3Wr-5Waz", namespace: "html", ssrRootStatic: [" data-exact-id=\"xemCI5bbM2khRwDjjTKQQzW\"", ["data-exact-id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
        const __exactValue_0 = __exactInvocation.eagerValues[0];
        const __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
        if (__exactValue_1 === __exactSsr.unprepared)
            return;
        const __exactValue_2 = __exactSsr.prepareChild(__exactInvocation, 2);
        if (__exactValue_2 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 3, 13, 13);
        const __exactOutput = __exactSsr.output();
        let __exactCharacters = 13;
        __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "html", "<html", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
        __exactSsr.keyedChild(__exactOutput, __exactValue_1);
        __exactSsr.keyedChild(__exactOutput, __exactValue_2);
        __exactSsr.static(__exactOutput, "</html>");
        return __exactOutput;
    }, ssrHost: "html" });
const __exactImplementation_Document_1 = function Document(this: Component<{
    body: string;
    title: string;
    css: string;
    page: {
        title: string;
        body: string;
    };
}>, props: {
    css: string;
}) {
    this.state.body = 'loading';
    this.state.title = 'Initial';
    this.state.css = '/initial.css';
    this.state.page = { title: 'Initial', body: 'loading' };
    __exactActivateServerTask(this, __exact_server_task_slice_1, "xES4W_XGqMEhaFY6dv3b4VQ", async (_task: TaskContext) => { await __exactServerTaskAwait(_task.signal, Promise.resolve()); this.state.body = "ready"; });
    return () => __exactPreparedServerRenderProgram(__exact_render_program_4, [{ "data-exact-id": "xemCI5bbM2khRwDjjTKQQzW" }, __exactPreparedServerRenderProgram(__exact_render_program_1, [{ "data-exact-id": "xqvQ9eP8x2yvcTnzmxhabYL" }]), __exactPreparedServerRenderProgram(__exact_render_program_3, [{ "data-exact-id": "xatX6QXhVIEKV3fGZSx-n43" }, __exactPreparedServerRenderProgram(__exact_render_program_2, [{}, this.state.body])])]);
};
export const Document = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Document_1, {
    [Symbol.for("@exactjs/component")]: "x7w8tSs8lTjdD_hEuz7OxJb",
    [__exactComponentContract_1]: {
        version: 1,
        placement: "server",
        role: "executor",
        implementations: [
            { id: "xcTDj7qlSoQHhVjSdia9s42", name: "Document", role: "root", implementation: __exactImplementation_Document_1 }
        ],
        continuations: [
            {
                kind: "task",
                id: "xES4W_XGqMEhaFY6dv3b4VQ",
                componentId: "x7w8tSs8lTjdD_hEuz7OxJb",
                readiness: "blocking",
                concurrency: "latest",
                dependencies: [],
                stateReads: [],
                stateWrites: [
                    {
                        path: "body",
                        kind: "write",
                        confidence: "exact"
                    }
                ],
                publicContexts: [],
                serverContexts: [],
                contextWrites: [],
                serverContextWrites: [],
                boundaries: []
            }
        ],
        executors: [
            {
                id: "xES4W_XGqMEhaFY6dv3b4VQ",
                componentId: "x7w8tSs8lTjdD_hEuz7OxJb",
                execute: async (__exactActivation_1: any, __exactExecution_1: any) => {
                    const __exactComponent_1 = { state: __exactActivation_1.state } as {
                        state: {
                            body: string;
                            title: string;
                            css: string;
                            page: {
                                title: string;
                                body: string;
                            };
                        };
                    };
                    const __exactContextWrites_1 = {};
                    await (async (_task: TaskContext) => { await __exactServerTaskAwait(_task.signal, Promise.resolve()); __exactComponent_1.state.body = "ready"; })(__exactExecution_1.task);
                    return { state: __exactComponent_1.state, contexts: __exactContextWrites_1 };
                }
            }
        ],
        boundaries: [],
        artifact: {
            version: 1,
            target: "server",
            id: "x7w8tSs8lTjdD_hEuz7OxJb",
            instantiate: __exactImplementation_Document_1,
            construct: __exactRejectDirectServerConstruction_1,
            abi: 9,
            capabilities: [
                "tasks",
                "continuations"
            ],
            state: [
                "body",
                "css",
                "page",
                "title"
            ],
            props: [],
            issue: __exactIssueServerComponent_1,
            write: __exactWriteServerComponent_1,
            dispose: __exactDisposeServerComponent_1,
            execution: {
                version: 1,
                classification: "scheduled",
                lane: "direct",
                render: __exactImplementation_Document_1
            },
            tasks: [
                "xES4W_XGqMEhaFY6dv3b4VQ"
            ],
            reactive: [
                {
                    name: "load",
                    provenance: "unknown",
                    allocation: "constant",
                    dependencies: []
                },
                {
                    name: "props",
                    provenance: "props",
                    allocation: "live-slot",
                    dependencies: []
                },
                {
                    name: "this",
                    provenance: "state",
                    allocation: "live-slot",
                    dependencies: []
                }
            ],
            render: "returned-function"
        }
    }
}) as typeof __exactImplementation_Document_1)();
