import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const dir='.tmp/ssr-large-profile/';
const cases=[
 {name:'static-head',head:'<title>Operations</title>',write:'this.state.body = "ready";',body:'this.state.body',expectedWrite:'body'},
 {name:'settled-prop-head',head:'<link rel="stylesheet" href={props.css}/>',write:'this.state.body = "ready";',body:'this.state.body',expectedWrite:'body'},
 {name:'task-title',head:'<title>{this.state.title}</title>',write:'this.state.title = "ready";',body:'this.state.body',expectedWrite:'title'},
 {name:'task-head-attribute',head:'<link rel="stylesheet" href={this.state.css}/>',write:'this.state.css = "/ready.css";',body:'this.state.body',expectedWrite:'css'},
 {name:'nested-siblings',head:'<title>{this.state.page.title}</title>',write:'this.state.page.body = "ready";',body:'this.state.page.body',expectedWrite:'page.body'},
 {name:'head-helper',head:'<title>{readTitle()}</title>',helper:'const readTitle = () => this.state.title;',write:'this.state.title = "ready";',body:'this.state.body',expectedWrite:'title'}
];
const requests=cases.map(c=>({id:'task-span-'+c.name+'.tsx',kind:'compile',target:'server',source:`import { TaskContext, type Component } from '@exactjs/core';
export function Document(this: Component<{body:string;title:string;css:string;page:{title:string;body:string}}>, props:{css:string}) {
 this.state.body='loading';this.state.title='Initial';this.state.css='/initial.css';this.state.page={title:'Initial',body:'loading'};
 ${c.helper??''}
 const load=async (_task:TaskContext=TaskContext.server().blocking())=>{ await Promise.resolve(); ${c.write} };
 load();
 return ()=><html><head>${c.head}</head><body><main>{${c.body}}</main></body></html>;
}`}));
const executable='.tmp/native-compiler/exactc.exe';
const r=spawnSync(executable,[],{input:requests.map(r=>JSON.stringify(r)).join('\n')+'\n',encoding:'utf8',windowsHide:true,maxBuffer:16*1024*1024});
if(r.status!==0)throw Error(r.stderr||r.stdout);
const responses=r.stdout.trim().split('\n').map(line=>JSON.parse(line));
if(responses.length!==cases.length)throw Error('Incomplete compiler responses');
const summary=[];
for(let i=0;i<responses.length;i++){
 const response=responses[i],fixture=cases[i],request=requests[i];
 if(response.error)throw Error(response.error);
 const tasks=response.analysis.tasks;
 if(!tasks.some(t=>t.writes.some(w=>w.path===fixture.expectedWrite)))throw Error('Missing task write '+fixture.name);
 summary.push({name:fixture.name,diagnostics:response.diagnostics,tasks:tasks.map(t=>({id:t.id,placement:t.placement,readiness:t.readiness,writes:t.writes})),stateReads:response.analysis.stateReads.map(r=>({...r,source:request.source.slice(r.start,r.start+r.length)})),propsReads:response.analysis.propsReads,hasCompiledWriter:response.code.includes('ssr:')});
 writeFileSync(dir+'task-span-'+fixture.name+'.tsx',request.source);
 writeFileSync(dir+'task-span-'+fixture.name+'.compiled.mjs',response.code);
}
writeFileSync(dir+'task-span-audit-results.json',JSON.stringify({compilerSha256:createHash('sha256').update(readFileSync(executable)).digest('hex'),requests,responses,summary},null,2));
for(const row of summary)console.log(JSON.stringify(row));
