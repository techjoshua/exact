import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const dir='.tmp/ssr-large-profile/';
writeFileSync(dir+'string-batches-checkable.mjs',readFileSync(dir+'string-batches-2048.mjs','utf8')+'\nexport {appendSharedSink,finishStringBatches};\n');
const {appendSharedSink,finishStringBatches}=await import('./string-batches-checkable.mjs');
let checks=0;
for(const limit of [1,3,2048,8192])for(const fragments of [[],[''],['ab','c'],['ab','cd','e'],['x'.repeat(9000),'end'],['\ud83d','\ude80','<\u2028\u2029'],['a','b','c','d']]){
 const expected=fragments.join(''),sink={parts:[],chunks:[],buffered:0,characters:0,limit};
 const context={maxOutputBytes:expected.length};
 for(const fragment of fragments)appendSharedSink(context,sink,fragment);
 assert.equal(finishStringBatches(sink),expected);
 assert.equal(sink.parts.length,0);assert.equal(sink.chunks.length,0);
 checks++;
}
assert.throws(()=>appendSharedSink({maxOutputBytes:2},{parts:[],chunks:[],buffered:0,characters:0,limit:3},'abc'),/maximum of 2 bytes/);
checks++;
writeFileSync(dir+'string-batches-check-results.json',JSON.stringify({checks,runtime:process.version,scope:'Isolated prototype staging, joining, character ceiling, and released fragment references. Not streaming backpressure or lifecycle coverage.'},null,2));
console.log({checks});
