import json,hashlib,zipfile
from pathlib import Path
from collections import Counter
root=Path('.tmp/ssr-large-profile')
data=json.loads((root/'allocation-sites/results.json').read_text())
assert hashlib.sha256(Path(data['entry']).read_bytes()).hexdigest()==data['artifactSha256']
for row in data['rows']:
    kinds=Counter()
    for site in row['ranked']:kinds[site['kind']]+=site['count']
    assert sum(kinds.values())==row['total']
    print(row['scenario'],dict(kinds))
archive=Path('docs/performance-baselines/allocation-site-census-2026-09-10-evidence.zip')
assert not archive.exists()
files=[root/'allocation-site-audit.mjs',root/'allocation-site-report.py',root/'allocation-sites/results.json',root/'allocation-sites/server-entry.js',Path(data['entry']),Path('.tmp/positional-leaves/data.json')]
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified',len(files),'archived files')
