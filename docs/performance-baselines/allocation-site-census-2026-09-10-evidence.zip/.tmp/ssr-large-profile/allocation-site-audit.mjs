import fs from 'node:fs/promises';
import ts from 'typescript';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {setPriority} from 'node:os';
import {createHash} from 'node:crypto';
setPriority(0,10);
const root='.tmp/ssr-large-profile/allocation-sites/';
await fs.mkdir(root,{recursive:true});
const entry='framework-comparison/participants/exact/dist-server/server-entry.js';
const source=await fs.readFile(entry,'utf8');
const ast=ts.createSourceFile('server-entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const sites=[];
let owner='<module>';
const transformed=ts.transform(ast,[context=>{
 const factory=context.factory;
 function visit(node){
  const oldOwner=owner;
  if(ts.isFunctionLike(node))owner=node.name?.getText(ast)??(ts.isVariableDeclaration(node.parent)?node.parent.name.getText(ast):oldOwner+'/<callback>');
  const allocated=ts.isObjectLiteralExpression(node)||ts.isArrayLiteralExpression(node)||ts.isNewExpression(node)||ts.isArrowFunction(node)||ts.isFunctionExpression(node);
  const id=sites.length;
  if(allocated)sites.push({id,owner,kind:ts.SyntaxKind[node.kind],line:ast.getLineAndCharacterOfPosition(node.getStart(ast)).line+1,source:node.getText(ast).slice(0,160)});
  const visited=ts.visitEachChild(node,visit,context);
  owner=oldOwner;
  if(!allocated)return visited;
  return factory.createParenthesizedExpression(factory.createCommaListExpression([
   factory.createPostfixIncrement(factory.createElementAccessExpression(factory.createIdentifier('__allocationCounts'),id)),visited
  ]));
 }
 return node=>ts.visitNode(node,visit);
}]);
const printed=ts.createPrinter().printFile(transformed.transformed[0]);
transformed.dispose();
const file=root+'server-entry.js';
await fs.writeFile(file,`const __allocationCounts=new Float64Array(${sites.length});\n`+printed+'\nexport function allocationReset(){__allocationCounts.fill(0);}\nexport function allocationRead(){return Array.from(__allocationCounts);}\n');
const original=await import(pathToFileURL(resolve(entry)));
const instrumented=await import(pathToFileURL(resolve(file)));
const fixture=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));
const tags='<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">';
const rows=[];
for(const scenario of ['standard','large','empty-comments']){
 const data=structuredClone(fixture);
 if(scenario==='large')data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
 if(scenario==='empty-comments')data.incidents.find(item=>item.id==='inc-101').comments=[];
 const render=mod=>mod.renderParticipant(data,'/incidents/inc-101',{clientTags:tags});
 const expected=await render(original);
 for(let i=0;i<10;i++)assert.equal(await render(instrumented),expected);
 let first;
 for(let i=0;i<20;i++){
  instrumented.allocationReset();assert.equal(await render(instrumented),expected);
  const counts=instrumented.allocationRead();if(first)assert.deepEqual(counts,first);else first=counts;
 }
 const ranked=sites.map((site,i)=>({...site,count:first[i]})).filter(s=>s.count).sort((a,b)=>b.count-a.count);
 rows.push({scenario,bytes:Buffer.byteLength(expected),hash:createHash('sha256').update(expected).digest('hex'),total:first.reduce((a,b)=>a+b,0),ranked});
}
await fs.writeFile(root+'results.json',JSON.stringify({entry,artifactSha256:createHash('sha256').update(source).digest('hex'),sites:sites.length,rows},null,2));
for(const row of rows)console.log(JSON.stringify({scenario:row.scenario,total:row.total,top:row.ranked.slice(0,16)}));
