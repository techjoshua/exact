__declspec(dllimport) unsigned long __stdcall GetCurrentProcessorNumber(void);
typedef void* napi_env;
typedef void* napi_value;
typedef void* napi_callback_info;
typedef unsigned __int64 size_t;
typedef napi_value (*callback)(napi_env,napi_callback_info);
__declspec(dllimport) void* __stdcall GetModuleHandleA(const char*);
__declspec(dllimport) void* __stdcall GetProcAddress(void*,const char*);
__declspec(dllimport) int __stdcall QueryThreadCycleTime(void*,unsigned __int64*);
static int (*make_double)(napi_env,double,napi_value*);
static int (*make_function)(napi_env,const char*,size_t,callback,void*,napi_value*);
static int (*set_property)(napi_env,napi_value,const char*,napi_value);
static int (*throw_error)(napi_env,const char*,const char*);
int _fltused=0;
/** Samples the current calling thread only; values are cycles, never elapsed time. */
static napi_value read_cycles(napi_env env,napi_callback_info info){
 unsigned __int64 cycles=0;napi_value value=0;
 if(!QueryThreadCycleTime((void*)(__int64)-2,&cycles)){throw_error(env,0,"QueryThreadCycleTime failed");return 0;}
 if(make_double(env,(double)cycles,&value)!=0){throw_error(env,0,"Cannot create cycle number");return 0;}
 return value;
}
/** Captures the logical processor currently executing the calling thread. */
static napi_value read_processor(napi_env env,napi_callback_info info){napi_value value=0;if(make_double(env,(double)GetCurrentProcessorNumber(),&value)!=0)return 0;return value;}
/** Resolves Node's exported ABI without a generated import library. */
__declspec(dllexport) napi_value napi_register_module_v1(napi_env env,napi_value exports){
 void* host=GetModuleHandleA(0);napi_value fn=0;
 make_double=(void*)GetProcAddress(host,"napi_create_double");
 make_function=(void*)GetProcAddress(host,"napi_create_function");
 set_property=(void*)GetProcAddress(host,"napi_set_named_property");
 throw_error=(void*)GetProcAddress(host,"napi_throw_error");
 if(!make_double||!make_function||!set_property||!throw_error)return 0;
 if(make_function(env,"readCycles",10,read_cycles,0,&fn)!=0)return 0;
 if(set_property(env,exports,"readCycles",fn)!=0)return 0;
 if(make_function(env,"readProcessor",13,read_processor,0,&fn)!=0)return 0;
 if(set_property(env,exports,"readProcessor",fn)!=0)return 0;
 return exports;
}
int __stdcall DllMain(void* module,unsigned long reason,void* reserved){return 1;}
