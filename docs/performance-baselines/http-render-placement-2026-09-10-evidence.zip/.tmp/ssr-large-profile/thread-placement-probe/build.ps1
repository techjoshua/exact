$compiler = 'C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/cl.exe'
& $compiler /nologo /O2 /GS- /LD .tmp/ssr-large-profile/thread-placement-probe/probe.c /Fo:.tmp/ssr-large-profile/thread-placement-probe/probe.obj /Fe:.tmp/ssr-large-profile/thread-placement-probe/probe.node /link /NODEFAULTLIB /ENTRY:DllMain 'C:/Program Files (x86)/Windows Kits/10/Lib/10.0.26100.0/um/x64/kernel32.lib'
if ($LASTEXITCODE -ne 0) { throw 'Cycle probe build failed' }
