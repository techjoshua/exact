import ctypes,json,pathlib
from ctypes import wintypes
class Info(ctypes.Structure):
 _fields_=[('mask',ctypes.c_size_t),('relationship',ctypes.c_int),('reserved',ctypes.c_ulonglong*2)]
k=ctypes.WinDLL('kernel32',use_last_error=True);f=k.GetLogicalProcessorInformation;f.argtypes=[ctypes.c_void_p,ctypes.POINTER(wintypes.DWORD)];f.restype=wintypes.BOOL
n=wintypes.DWORD();f(None,ctypes.byref(n));assert ctypes.get_last_error()==122
buf=ctypes.create_string_buffer(n.value);assert f(buf,ctypes.byref(n))
rows=[]
for pos in range(0,n.value,ctypes.sizeof(Info)):
 x=Info.from_buffer_copy(buf.raw[pos:pos+ctypes.sizeof(Info)])
 if x.relationship==0:rows.append({'mask':x.mask,'processors':[i for i in range(64) if x.mask&(1<<i)]})
p=pathlib.Path('.tmp/ssr-large-profile/http-render-placement/core-topology.json');p.write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
