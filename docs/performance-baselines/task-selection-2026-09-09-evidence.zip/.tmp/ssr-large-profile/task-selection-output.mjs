import {readFileSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const dir='.tmp/ssr-large-profile/',results=[];
for(const runtime of ['node','bun'])for(const variant of ['marker-hex-current','task-selection-opt-in-current']){
 const entry=dir+variant+'.mjs';
 const r=spawnSync(runtime,[dir+'sink-audit-worker.mjs',entry],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 const result={runtimeId:runtime,variant,sha256:createHash('sha256').update(readFileSync(entry)).digest('hex'),...JSON.parse(r.stdout)};
 if(variant==='task-selection-opt-in-current'){
  const baseline=results.find(x=>x.runtimeId===runtime);
  for(let i=0;i<result.rows.length;i++)if(result.rows[i].hash!==baseline.rows[i].hash)throw Error('Readiness change affected output');
 }
 results.push(result);
}
writeFileSync(dir+'task-selection-output.json',JSON.stringify(results,null,2));
console.log('48 complete documents verified across Node/Bun, string/stream, small/large, control/current.');
