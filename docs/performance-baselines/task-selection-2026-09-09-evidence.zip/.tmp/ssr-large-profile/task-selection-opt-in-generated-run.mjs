import {readFileSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const dir='.tmp/ssr-large-profile/',rows=[];
for(const variant of ['marker-hex-current','task-selection-opt-in-current'])writeFileSync(dir+variant+'-readiness.mjs',readFileSync(dir+variant+'.mjs','utf8')+'\nexport {ServerTaskReadiness};\n');
for(const runtime of ['node','bun'])for(const tasks of [3,16])for(let round=0;round<2;round++)for(const variant of round?['task-selection-opt-in-current','marker-hex-current']:['marker-hex-current','task-selection-opt-in-current']){
 const r=spawnSync(runtime,[dir+'task-selection-worker.mjs',dir+variant+'-readiness.mjs',String(tasks)],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 const row={runtimeId:runtime,variant,round,...JSON.parse(r.stdout)};
 rows.push(row);writeFileSync(dir+'task-selection-opt-in-results.json',JSON.stringify(rows,null,2));console.log(runtime,tasks,round,variant,row.usPerFrame.toFixed(3));
}
