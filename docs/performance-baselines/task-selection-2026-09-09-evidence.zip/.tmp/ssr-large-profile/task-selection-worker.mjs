import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const [entry,taskCountText]=process.argv.slice(2);
const {ServerTaskReadiness}=await import(pathToFileURL(resolve(entry)));
const taskCount=Number(taskCountText),iterations=30000;
const identities=Array.from({length:taskCount},(_,i)=>'task-'+i);
async function run(){
 const state=new ServerTaskReadiness();
 for(let i=0;i<taskCount;i++)state.observe(Promise.resolve(i),identities[i]);
 await state.wait();
 if(state.wait()!==undefined||state.version!==taskCount)throw Error('Readiness did not settle');
}
for(let i=0;i<4000;i++)await run();
const start=performance.now();for(let i=0;i<iterations;i++)await run();
console.log(JSON.stringify({taskCount,iterations,usPerFrame:(performance.now()-start)*1000/iterations,runtime:process.versions.bun??process.version}));
