import hashlib,json,pathlib,zipfile
root=pathlib.Path('.');work=root/'.tmp/ssr-large-profile'
captures={name:json.loads((work/file).read_text(encoding='utf-8')) for name,file in [('map','task-selection-results.json'),('opt-in','task-selection-opt-in-results.json')]}
summary=[]
for implementation,rows in captures.items():
 assert len(rows)==16
 for runtime in ['node','bun']:
  for tasks in [3,16]:
   pairs=[]
   for round in range(2):
    group=[r for r in rows if r['runtimeId']==runtime and r['taskCount']==tasks and r['round']==round]
    control=next(r for r in group if r['variant']=='marker-hex-current');candidate=next(r for r in group if r['variant']!='marker-hex-current')
    pairs.append(dict(control=control['usPerFrame'],candidate=candidate['usPerFrame'],difference=candidate['usPerFrame']-control['usPerFrame']))
   summary.append(dict(implementation=implementation,runtime=runtime,tasks=tasks,pairs=pairs))
outputs=json.loads((work/'task-selection-output.json').read_text(encoding='utf-8'))
assert len(outputs)==4 and sum(len(r['rows']) for r in outputs)==48
current=root/'framework-comparison/participants/exact/dist-server/server-entry.js'
frozen=work/'task-selection-opt-in-current.mjs'
assert current.read_bytes()==frozen.read_bytes()
table='\n'.join(f"| {s['implementation']} | {s['runtime']} | {s['tasks']} | {s['pairs'][0]['control']:.3f} / {s['pairs'][0]['candidate']:.3f} | {s['pairs'][1]['control']:.3f} / {s['pairs'][1]['candidate']:.3f} |" for s in summary)
dest=root/'docs/performance-baselines/task-selection-2026-09-09'
validation={'coreTests':258,'ssrTests':284,'focusedFinalTests':16,'coreBuild':True,'compileExactCore':True,'comparisonClientNodeBunBuild':True,'typecheckTests':True,'eslint':True,'sourceArchitecture':True,'platformBoundaries':True,'compiledAbi':True,'releaseAbiEpoch':1,'packageContents':True,'outputChecks':48,'browserRerun':False}
dest.with_suffix('.json').write_text(json.dumps(dict(summary=summary,captures=captures,outputs=outputs,validation=validation,currentSha256=hashlib.sha256(frozen.read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8')
doc='''# Selected task readiness foundation for SSR output spans

Date: 2026-09-09. Implemented internal capability; compiler/span integration remains unfinished.

## Change

Compiler-guided output spans need to wait for task identities that can affect them, without waiting
for unrelated task activations. ServerTaskReadiness now supports selected pending-work queries and
request-local completion-change tokens. ServerComponentExecutionFrame exposes these through
blockingWork(selection) and blockingVersionFor(selection). Transition identities remain opaque.

Frames enable identity tracking explicitly with trackTaskIdentities. Existing SSR callers do not
enable it yet, so ordinary frames retain a pending-task Set without identity-lookup allocation.
Selected queries on an untracked frame fail explicitly. Revision tracking is also lazy: a selected
revision is a change token for a stable selection within one request, not an absolute task count.

The task system still starts and owns work. Selection only observes already-issued blocking work
and existing publication dependencies; it does not promote ordinary nonblocking tasks. Empty or
settled selections return undefined rather than creating a promise. Failed selected tasks retain
their failure. Unidentified work participates conservatively in every selection. Pending queries
cover current activations; consumers recheck after settlement to discover later activations.
Unrelated completions do not change a selected revision. Request disposal still cancels and cleans
up all owned work, including work outside the selected set.

The server execution types moved to server-component-execution-contracts.ts to preserve the source
architecture limit. Existing exports still expose the same contracts with the additive methods and
option. No emitted artifact or wire format changed, and frozen ABI fixtures passed without regeneration.
Engineering documentation describes the capability and explicitly states that SSR still uses
whole-component readiness. No application-facing streaming behavior or documentation claim changed.

## Avoiding unused tracking overhead

The first implementation replaced the pending Set with a Map. A focused microbenchmark found a
large Bun cost, so that implementation was replaced before acceptance. The final implementation
keeps the Set and adds a WeakMap only when the compiler-driven capability is enabled.

Each implementation was compared with the prior marker-hex artifact in sixteen fresh processes:
Node/Bun, three/sixteen immediately resolving tasks per frame, and two reversed-order pairs. Each
population warms 4,000 frames and measures 30,000. The check creates a readiness tracker, observes
the tasks, waits for all of them, verifies completion/version, and confirms no further wait is needed.
Both populations exercise the existing wait-for-all path. This is not an SSR or HTTP benchmark,
does not measure task bodies, and does not measure the new selected-query path's performance.

Microseconds per frame, control / candidate; lower is better:

| Implementation | Runtime | Tasks | Pair 1 | Pair 2 |
| --- | --- | ---: | ---: | ---: |
'''+table+'''

The opt-in design removes most of the measured regression. It retains a small positive overhead
in these short local observations; no zero-cost claim is made. This is an enabling capability for
the requested compiler/span architecture, not a throughput optimization by itself. Overall React
parity remains unmet, and earlier React comparisons must not be relabeled as measurements of this build.

## Validation

- Core: 258 tests across 50 files. SSR: 284 tests across 45 files.
- Focused readiness/frame coverage includes selected and unrelated pending work, revisions,
  repeated activations, retained failures, unidentified work, opt-in enforcement, and cancellation
  of a selected wait during request disposal. Existing lifecycle checks retain once-only cleanup.
- Core build and exact compilation, comparison client/Node/Bun builds, test type checking, lint,
  source architecture, platform boundaries, compiled ABI, initial release epoch, and package-content
  checks pass. The package-content check used npm exec's cached/downloaded Node 26.8.2; timed
  populations used the explicitly selected Node 26.8.1 and Bun 1.4.2 executables.
- Forty-eight complete documents across Node/Bun, string/stream, small/large, control/current match
  their paired full-body hashes. These are output checks, not new timing populations.
- Client asset hash remains index-CdIXDKwS.js. No browser suite was rerun for this internal task query
  capability; SSR/hydration ABI tests and package suites provide the current boundary validation.

The archived validation summary records completed commands, not raw transcripts. Raw timing
observations, frozen implementations, output observations, relevant source/tests, and hashes are
preserved separately in the evidence archive. The current frozen implementation is
task-selection-opt-in-current.mjs, verified byte-for-byte against the built Node participant.
task-selection-current.mjs in the archive is the rejected initial Map implementation, retained
under its original experiment identifier so its raw observations remain traceable.

## Remaining work

The compiler must derive transitive task dependencies for ordered SSR spans and defer reads of
affected values until those dependencies settle. The shared renderer must consume those spans,
flush a proven unaffected head before pending body work, preserve capture/rollback boundaries,
and let each sink own staging/backpressure. This capability is the readiness primitive for that
integration; it does not yet deliver early head bytes or improve the React comparison.
'''
dest.with_suffix('.md').write_text(doc,encoding='utf-8')
files=[work/n for n in ['marker-hex-current.mjs','task-selection-current.mjs','task-selection-opt-in-current.mjs','task-selection-worker.mjs','task-selection-run.mjs','task-selection-opt-in-run.mjs','task-selection-opt-in-generated-run.mjs','task-selection-results.json','task-selection-opt-in-results.json','task-selection-output.mjs','task-selection-output.json','sink-audit-worker.mjs','task-selection-report.py']]+[root/'.tmp/positional-leaves/data.json',dest.with_suffix('.md'),dest.with_suffix('.json')]
files += [root/p for p in ['packages/core/src/tasks/server-task-readiness.ts','packages/core/src/tasks/server-task-readiness.test.ts','packages/core/src/tasks/server-component-execution.ts','packages/core/src/tasks/server-component-execution-contracts.ts','packages/core/src/server-component-execution.test.ts','docs/ssr-hydration.md']]
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps({p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(table);print('Verified',archive)
