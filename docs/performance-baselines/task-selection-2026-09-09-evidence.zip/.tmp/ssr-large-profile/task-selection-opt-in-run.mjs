import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
writeFileSync(dir+'task-selection-opt-in-generated-run.mjs',readFileSync(dir+'task-selection-run.mjs','utf8').replaceAll('task-selection-current','task-selection-opt-in-current').replaceAll('task-selection-results.json','task-selection-opt-in-results.json'));
await import('./task-selection-opt-in-generated-run.mjs');
