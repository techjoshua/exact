import fs from 'node:fs';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
let code=fs.readFileSync(root+'proven-reference-integrated/server-entry.js','utf8');
assert.equal(code,fs.readFileSync('framework-comparison/participants/exact/dist-server/server-entry.js','utf8'));
const anchor='function renderComponentReference(context, component, parent, options, hasComponentAncestor, omitCompilerOwnedBoundary = false, omitRootBoundary = false) {';
assert.equal(code.split(anchor).length,2);
code=code.replace(anchor,`const childRendererCache = new WeakMap();
function sharedChildRenderers(context, options) {
 let cached = childRendererCache.get(context);
 if (!cached || cached.options !== options) {
  cached = {options,
   children: (children, owner) => renderChildren(context, children, owner, options, true),
   component: (child, owner) => renderComponentReference(context, child, owner, options, true, true)
  };
  childRendererCache.set(context, cached);
 }
 return cached;
}
${anchor}`);
const call='return mapRenderValue(renderServerComponentArtifactOutput(context, component, parent, options, (children, owner) => renderChildren(context, children, owner, options, true), (child, owner) => renderComponentReference(context, child, owner, options, true, true), publishComponent, {';
assert.equal(code.split(call).length,2);
code=code.replace(call,'const callbacks = sharedChildRenderers(context, options);\n\treturn mapRenderValue(renderServerComponentArtifactOutput(context, component, parent, options, callbacks.children, callbacks.component, publishComponent, {');
fs.mkdirSync(root+'shared-child-callback',{recursive:true});
fs.writeFileSync(root+'shared-child-callback/server-entry.js',code);
let runner=fs.readFileSync(root+'projector-warm50-large-run.mjs','utf8');
runner=runner.replace("candidate:d+'projector-inline-primitives-integrated/server-entry.js',react:'framework-comparison/participants/react/dist-server/server-entry.js'","candidate:d+'shared-child-callback/server-entry.js'")
 .replace("['string','encoded','stream']","['string']").replace("['large']","['assets','large']")
 .replace('projector-warm50-large-results.json','shared-child-callback-results.json');
fs.writeFileSync(root+'shared-child-callback-run.mjs',runner);
