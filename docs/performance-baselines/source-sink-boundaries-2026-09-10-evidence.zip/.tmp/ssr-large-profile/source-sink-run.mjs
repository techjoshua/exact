import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/';
const entries={before:d+'source-sink-before.mjs',source:d+'source-sink-application/server-entry.js'};
if(process.argv[2])entries.source=process.argv[2];
if(process.argv[4])entries.before=process.argv[4];
const resultsFile=process.argv[3]??'source-sink-results.json';
const rows=[];
for(const runtime of ['node','bun'])for(const scenario of ['assets','large'])for(const mode of ['string','stream'])for(let round=0;round<2;round++)for(const variant of round?['source','before']:['before','source']){
  const entry=entries[variant];
  const result=spawnSync(runtime,[d+'production-refresh-worker.mjs',entry,mode,scenario,'12000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
  if(result.status!==0)throw Error(result.stderr+result.stdout);
  const row={runtimeId:runtime,round,variant,artifactSha256:createHash('sha256').update(fs.readFileSync(entry)).digest('hex'),...JSON.parse(result.stdout)};
  const peer=rows.find(r=>r.scenario===scenario&&r.mode===mode);
  if(peer)assert.equal(row.hash,peer.hash,'Complete document changed');
  rows.push(row);fs.writeFileSync(d+resultsFile,JSON.stringify(rows,null,2));
  console.log(runtime,scenario,mode,round,variant,row.usPerRender.toFixed(2));
}
