from pathlib import Path
import hashlib,json,statistics,zipfile

root=Path.cwd(); d=root/'.tmp/ssr-large-profile'
report=root/'docs/performance-baselines/source-sink-boundaries-2026-09-10.md'
archive=report.with_name(report.stem+'-evidence.zip')
rows=json.loads((d/'source-sink-boundary-results.json').read_text())
assert len(rows)==32
for row in rows:
    assert hashlib.sha256((root/row['entry']).read_bytes()).hexdigest()==row['artifactSha256']
checks=json.loads((d/'source-sink-boundary-validation.json').read_text())
assert all(result['exit_code']==0 for result in checks.values())
assert '303 passed' in checks['fullSsrTests']['output']
lines=['# Source sink component and structural capture','',
'Date: 2026-09-10. Internal runtime integration following the',
'[ordered program sink foundation](source-program-sink-2026-09-10.md).','',
'## Failure and correction','',
'A compiler-backed document reproduced an ordering defect when the shared destination was',
'selected: `<em>Ready</em>` was written before its child-range and component opening markers.',
'The markers then enclosed an empty range. Hydration records alone still matched, showing why',
'record comparison does not replace checking the rendered DOM protocol.','',
'The source now uses one scoped capture helper for enhancement routing, marker wrappers,',
'ordinary intrinsic receipts, and components needing local publication. Scheduled components',
'capture their output because render attempts may retry; a discarded attempt cannot be retracted',
'from a response. Marked component output is captured until its publication wrapper is known.',
'Standalone resumption boundaries that embed component HTML also retain local output.',
'The same visitor performs captured and directly published rendering. The destination is',
'restored after descendant settlement on success, failure, or cancellation.','',
'Child traversal now writes scalar siblings in order before another child can publish directly.',
'It preserves adjacent-text separators and waits for destination readiness before advancing.',
'Program and child visitors share the pre-await flush helper, including its rule that a failed',
'drain must not release an ancestor while a descendant still owns its scope.','',
'## Validation','',
'The full SSR suite passed 303 tests after the source changes. The final focused compiler-backed',
'suite passed ten cases after adding cancellation, intrinsic capture, and routed-enhancement',
'coverage. These cases compare document HTML and hydration records with the existing local',
'collector, with markers enabled and disabled. They also verify scalar ordering, root-prefix',
'routing without duplicate construction, and cleanup ownership.','',
'A compiled authored document sends its stylesheet-bearing head to the internal destination',
'while its marked body component remains pending. A separate test aborts after head publication',
'and component setup, then verifies balanced setup/disposal, restored destination identity, empty',
'host scopes, and no closing body tag after cancellation. These boundary tests run under Node;',
'they are not browser benchmarks or a claim of public response behavior.','',
'SSR package build, test type checking, focused ESLint, source architecture, platform boundaries,',
'and package contents checks pass. Public entry points still do not install the destination, so',
'public documentation does not advertise progressive tree publication yet. Engineering guidance',
'describes the current integration boundary.','',
'## Overhead experiment','',
'Hypothesis: the added capture guards should have little cost when ordinary public rendering',
'does not select the shared destination. This compares the previous source integration artifact',
'with the new boundary integration artifact, not the native-writer prototype or React.','',
'Each cell averages two reversed-order fresh-process samples, with 5,000 warmups and 12,000',
'measured renders each. Node 26.8.1 and Bun 1.4.2 run in production mode. The authored document',
'shell, four assets, and hydration/bootstrap output are included; streams are fully consumed',
'through Response.text(). No build or test ran concurrently with timing. All complete document',
'hashes match their controls. Units are microseconds per document, not HTTP requests/s.','',
'| Runtime | Document | Mode | Before | Boundary integration | Change |',
'| --- | --- | --- | ---: | ---: | ---: |']
for rt in ['node','bun']:
    for scenario in ['assets','large']:
        for mode in ['string','stream']:
            a,b=[statistics.mean(r['usPerRender'] for r in rows if r['runtimeId']==rt and r['scenario']==scenario and r['mode']==mode and r['variant']==v) for v in ['before','source']]
            lines.append(f'| {rt} | {scenario} | {mode} | {a:.2f} | {b:.2f} | {(b/a-1)*100:+.1f}% |')
lines += ['',
'The small sample count and machine variation do not establish a throughput improvement.',
'This work removes correctness blockers for selecting the shared destination. React was not',
'rerun, and its previously reported string lead remains unresolved.','',
'## Remaining work','',
'Request-owned string and streaming destinations still need to be connected to public entry',
'points. Native compiler writer selection and its ABI migration remain separate unfinished',
'integration work. Other retry/replacement boundaries, hydration-tail publication, transport',
'cancellation, and browser adoption need validation with the complete public path enabled.',
'The new capture behavior is deliberately conservative; unnecessary component capture can be',
'reduced after the integrated path proves publication ownership and is measured.','',
'The [evidence archive](source-sink-boundaries-2026-09-10-evidence.zip) preserves the timed',
'artifacts, raw samples, source changes, compiler-backed fixtures, validation output, and',
'build/run scripts under a verified SHA-256 manifest.','']
report.write_text('\n'.join(lines),encoding='utf8')
files=[d/name for name in ['source-sink-boundary-results.json','source-sink-boundary-validation.json',
'source-sink-refined/server-entry.js','source-sink-boundaries/server-entry.js',
'source-sink-build.mjs','source-sink-run.mjs','production-refresh-worker.mjs','source-boundaries-report.py']]
files += [root/name for name in ['packages/ssr/src/render/program-capture.ts','packages/ssr/src/render/component.ts',
'packages/ssr/src/render/children.ts','packages/ssr/src/render/intrinsic-receipt.ts',
'packages/ssr/src/render/operation-enhancements.ts','packages/ssr/src/render/program-output.ts',
'packages/ssr/src/render/program-sink.ts','packages/ssr/src/markers.ts',
'packages/ssr/src/render/program-sink.fixtures.test.tsx','packages/ssr/src/render/program-sink-components.test.ts',
'packages/ssr/src/streams.fixtures.test.tsx','packages/ssr/src/streams-enhancement.fixtures.test.tsx',
'packages/ssr/src/stream-enhancements.fixtures.test.tsx','docs/ssr-hydration.md','.tmp/positional-leaves/data.json']]
files.append(report); manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for path in files:
        content=path.read_bytes();name=path.relative_to(root).as_posix()
        manifest[name]=hashlib.sha256(content).hexdigest();z.writestr(name,content)
    z.writestr('SHA256SUMS.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    for name,digest in manifest.items(): assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('\n'.join(line for line in lines if line.startswith('|')))
print(f'Wrote report; verified {len(manifest)} archive hashes.')
