import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync,readFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
const root=resolve('.'),output=resolve('.tmp/arrival-policy-final-2026-09-20'),suite=resolve('framework-comparison');
const journal=existsSync(`${output}/execution.json`)?JSON.parse(readFileSync(`${output}/execution.json`)):[];
process.env.NODE_ENV='production';process.env.COMPARISON_SSR_RENDER_MODE='string';
async function run(name,args,cwd=root,env={}) {
 if(journal.some(s=>s.name===name&&s.code===0)){console.log('RETAIN '+name);return;}
 const step={name,args,cwd,env,startedAt:new Date().toISOString()};journal.push(step);
 const save=()=>writeFileSync(`${output}/execution.json`,JSON.stringify(journal,null,2));save();console.log('START '+name);
 const log=openSync(`${output}/${name}.log`,'w');
 try{await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{cwd,env:{...process.env,...env},stdio:['ignore',log,log],windowsHide:true});step.pid=child.pid;save();child.once('error',fail);child.once('exit',(code,signal)=>{step.code=code;step.signal=signal;code===0?done():fail(Error(`${name} failed: ${code??signal}`));});});}
 finally{closeSync(log);step.endedAt=new Date().toISOString();save();}console.log('DONE '+name);
}
await run('controlled-build',[process.env.COMPARISON_NPM_CLI,'run','build','-w','@exactjs/framework-comparison-suite']);
await run('bun-build',['src/prepare-bun-measurement.mjs'],suite);
await run('native-correctness',[process.env.COMPARISON_NPM_CLI,'run','test:native','-w','@exactjs/framework-comparison-suite']);
// All measurements use freshly rebuilt workspace-resolved packages.
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])
 await run(`correctness-${runtime}-${mode}`,['../node_modules/@playwright/test/cli.js','test','-c','playwright.config.ts'],suite,{COMPARISON_E2E_RUNTIME:runtime,COMPARISON_SSR_RENDER_MODE:mode});
await run('source-snapshot',[output+'/source.mjs']);
await run('dependency-provenance',[root+'/framework-comparison/src/workspace-dependencies.mjs']);
await run('node-arrivals',[root+'/framework-comparison/src/measure-ssr-arrivals.mjs',output+'/arrivals-plan.json',output+'/node-arrivals.json','node'],root,{COMPARISON_SSR_RENDER_MODE:'string'});
await run('browser',['src/measure.mjs','--correctness-passed','--output='+output+'/browser.json'],suite,{COMPARISON_SAMPLES:'30',COMPARISON_MEASUREMENT_ROUND:'20'});
await run('startup',['src/measure-startup-cpu.mjs','--correctness-passed','--output='+output+'/startup.json'],suite,{COMPARISON_STARTUP_SAMPLES:'10',COMPARISON_CPU_RATES:'1,4,6',COMPARISON_MEASUREMENT_ROUND:'20'});
await run('heap',['src/measure-heap.mjs','--correctness-passed'],suite,{COMPARISON_HEAP_SAMPLES:'5',COMPARISON_HEAP_OUTPUT:`${output}/heap.json`});
for(const mode of ['string','stream'])for(const runtime of ['node','bun'])for(const lane of ['multi','normal','arrivals']) {
 const suffix=mode==='string'?'':'-stream';await run(runtime+suffix+'-'+lane,[lane==='arrivals'?root+'/framework-comparison/src/measure-ssr-arrivals.mjs':output+'/capacity-runner.mjs',output+'/'+lane+'-plan.json',output+'/'+runtime+suffix+'-'+lane+'.json',runtime],root,{COMPARISON_SSR_RENDER_MODE:mode});
}
for(const mode of ['string','stream'])await run(mode==='string'?'ssr':'ssr-stream',['src/measure-ssr.mjs','--correctness-passed'],suite,{
 COMPARISON_SSR_RENDER_MODE:mode,COMPARISON_SSR_OUTPUT:`${output}/${mode==='string'?'ssr':'ssr-stream'}.json`,COMPARISON_SSR_SAMPLES:'500',COMPARISON_SSR_WARMUPS:'100',COMPARISON_SSR_CONCURRENCY_WAVES:'500',COMPARISON_SSR_SATURATION_WINDOWS:'1',COMPARISON_SSR_SATURATION_WINDOW_MS:'1000',COMPARISON_SSR_SATURATION_CONCURRENCY:'32',COMPARISON_SSR_ATTRIBUTION_WINDOWS:'1',COMPARISON_SSR_ATTRIBUTION_CONCURRENCY:'32',COMPARISON_SSR_MEASUREMENT_ROUND:'20'
});
await run('native',['src/measure-native.mjs','--correctness-passed','--output='+output+'/native.json'],suite,{COMPARISON_SAMPLES:'7'});
console.log('COMPLETE framework measurements');
