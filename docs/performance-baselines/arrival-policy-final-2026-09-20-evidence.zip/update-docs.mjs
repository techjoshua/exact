import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
async function replace(path,before,after){const text=await readFile(path,'utf8');assert.ok(text.includes(before),path);await writeFile(path,text.replace(before,after));}
const path='docs/performance.md';let text=await readFile(path,'utf8');const start=text.indexOf('The [verified native-loopback capture]'),end=text.indexOf('The [routing investigation]');assert.ok(start>=0&&end>start);
text=text.slice(0,start)+`The [Node admission-policy follow-up](performance-baselines/arrival-policy-final-2026-09-20.md)
is the current framework comparison baseline. All 27 build, correctness, and measurement stages
passed, including browser, startup, heap, Node/Bun string and streaming, twelve sustained-load
captures, and the native track. The final Node string scheduled-demand results are 7,999 valid RPS
at 8,000 offered RPS (10.9–11.5 ms p99) and 9,990 valid RPS at 10,000 (24.8–29.4 ms p99), with
zero request errors. Saturated Node throughput remains close to the preceding full capture.

The [admission investigation](performance-baselines/ssr-arrival-investigation-2026-09-20.md)
records the demand-limited scheduling defect, the interrupted verification attempt, rejected broader
policies, and focused capacity guards. Each published offered-rate case now owns fresh worker,
service, and driver processes, with 30 seconds of target-rate warmup and 60 seconds of measurement.
Warmup failures and missed arrivals remain visible. The protocol change is separate from the
runtime correction; historical sequential-rate results are not a code-only comparison. Bun's
adapter, server, and participant entry artifacts are unchanged from the
[preceding native-loopback capture](performance-baselines/native-loopback-2026-09-20.md).

`+text.slice(end);await writeFile(path,text);
await replace('framework-comparison/README.md','The current [verified native-loopback capture](../docs/performance-baselines/native-loopback-2026-09-20.md)','The current [admission-policy follow-up](../docs/performance-baselines/arrival-policy-final-2026-09-20.md)');
await replace('framework-comparison/README.md','suite with workspace-resolved 0.6.0 packages. All participants retain the shared stylesheet and','suite with workspace-resolved 0.6.0 packages. Scheduled-demand cases use fresh processes per rate,\n30 seconds of target-rate warmup, and 60 seconds of measurement. The\n[admission investigation](../docs/performance-baselines/ssr-arrival-investigation-2026-09-20.md)\nrecords the Node correction and its focused controls. All participants retain the shared stylesheet and');
await replace('apps/docs/src/pages/FrameworkComparisonPage.tsx','separately. Aggregate RPS divides valid responses by elapsed time, including drain. Driver','separately. Each scheduled rate gets fresh worker, service, and driver processes, with\n\t\t\t\t\t30 seconds of target-rate warmup and 60 seconds of measurement. The second population\n\t\t\t\t\treverses framework and rate order. Aggregate RPS divides valid responses by elapsed time,\n\t\t\t\t\tincluding drain. Driver');
await replace('apps/docs/src/pages/SsrCapacity.tsx','\t\t\t<h3>Independently scheduled arrivals with preloaded data</h3>','\t\t\t<h3>Independently scheduled arrivals with preloaded data</h3>\n\t\t\t<p>\n\t\t\t\tEach offered rate uses fresh worker, service, and load-driver processes, with\n\t\t\t\t{report.arrivalsIsolation.warmupMs / 1000} seconds of warmup at that rate followed by\n\t\t\t\t{report.arrivalsIsolation.measurementMs / 1000} seconds of measurement. The second\n\t\t\t\tpopulation reverses framework and rate order.\n\t\t\t</p>');
await replace('apps/docs/src/pages/SsrCapacity.tsx','failed server responses. These overloaded rates do not establish the highest rate with zero','failed server responses. These fixed offered rates do not establish the highest rate with zero');
await replace('apps/docs/src/pages/SsrCapacity.tsx','excludes those errors; capacity misses count requests that were never admitted.','excludes those errors; capacity misses count requests that were never admitted. Unsent\n\t\t\t\trequests have no response latency, so read the p99 range alongside throughput and misses.\n\t\t\t\tThe table excludes warmup; its request errors remain in the validation summary below.');
await replace('apps/docs/src/pages/SsrCapacity.tsx','contains individual driver/population percentiles, not a pooled percentile.','contains individual driver/population percentiles, not a pooled percentile or confidence interval.');
await replace('apps/docs/src/pages/PerformancePage.tsx','Each chart retains its capture date and runtime identity.','Scheduled-demand comparisons use fresh processes and target-rate warmup for every offered\n\t\t\t\t\trate. Each chart retains its capture date and runtime identity.');
