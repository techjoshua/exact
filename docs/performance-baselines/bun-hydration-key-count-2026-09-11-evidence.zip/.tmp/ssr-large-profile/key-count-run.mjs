import {setPriority,getPriority} from 'node:os';
setPriority(0,10);function lower(child){setPriority(child.pid,10);assert.equal(getPriority(child.pid),10);}
import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {installDevelopmentProcessLifecycle} from '../../scripts/development-process-lifecycle.mjs';
import {startSsrLoadProcess} from '../../framework-comparison/src/ssr-load-process-owner.mjs';
import {startSsrWorker,stopSsrWorker,controlSsrWorker} from '../../framework-comparison/src/ssr-worker-controller.mjs';
import {availableSsrRuntimes,measureSsrArtifact,ssrEnvironmentMetadata} from '../../framework-comparison/src/ssr-run-environment.mjs';
const root='.tmp/ssr-large-profile/key-count/';
const runtime=availableSsrRuntimes('bun')[0];
const report={complete:false,kind:'large96-bun-key-count-without-key-array',createdAt:new Date().toISOString(),environment:ssrEnvironmentMetadata([runtime]),blocks:[],artifacts:{}};
const paths={current:root+'current.mjs',candidate:root+'candidate.mjs',react:'framework-comparison/participants/react/dist-bun-server/bun-server-entry.js',worker:root+'worker.mjs'};
for(const [name,path] of Object.entries(paths))report.artifacts[name]={path:resolve(path),sha256:createHash('sha256').update(await readFile(path)).digest('hex')};
report.artifacts.server=await measureSsrArtifact(resolve('packages/server/dist'));
report.artifacts.nodeAdapter=await measureSsrArtifact(resolve('framework-adapters/node-adapter/dist'));report.artifacts.bunAdapter=await measureSsrArtifact(resolve('framework-adapters/bun-adapter/dist'));
let worker,service,drivers=[];
async function closeDrivers(){const owned=drivers;drivers=[];const results=await Promise.allSettled(owned.map(d=>d.close()));for(const result of results)if(result.status==='rejected')throw result.reason;}
async function close(){await closeDrivers();if(worker){await stopSsrWorker(worker);worker=undefined;}if(service){await service.close();service=undefined;}}
const lifecycle=installDevelopmentProcessLifecycle({label:'Paired SSR CPU profiles',close});
async function startDrivers(concurrency=32){for(let i=0;i<(concurrency===1?1:2);i++){const driver=await startSsrLoadProcess('driver');drivers.push(driver);lower(driver.child);};}
async function run(stage,identity){
 for(const driver of drivers)driver.run({url:worker.url+'?__benchmarkPreloaded=true',contains:'Delayed fulfillment events',expectedIdentity:identity,maxInFlight:256,maxLagMs:50,timeoutMs:10000,stages:[stage]});
 const results=await Promise.race([Promise.all(drivers.map(d=>d.result)),service.result]);
 for(const result of results)for(const s of result.stages){assert.equal(s.errors,0);assert.equal(s.started,s.completed);assert.equal(s.completed,s.valid);assert.equal(s.offered,s.started+s.missedLag+s.missedCapacity+s.missedDeadline);}
 return results;
}
try{
 for(const mode of ['string'])for(let population=0;population<2;population++)for(const variant of population?['react','candidate','current']:['current','candidate','react']){
 const id=variant==='react'?'react':'exact';
  service=await startSsrLoadProcess('service');
  worker=await startSsrWorker({runtime,participantId:id,transport:'bun-fetch',workerPath:resolve(root+'worker.mjs'),workingDirectory:resolve('framework-comparison'),serviceUrl:service.url,environment:{COMPARISON_EXACT_SERVER_ENTRY:resolve(paths[variant]),COMPARISON_SSR_BOUNDED_TELEMETRY:'1',COMPARISON_SSR_RENDER_MODE:mode,COMPARISON_CLIENT_TAGS:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'}});
  lower(service.child);lower(worker.child);
  const response=await fetch(worker.url+'?__benchmarkPreloaded=true');assert.equal(response.status,200);
  const body=Buffer.from(await response.arrayBuffer());assert.match(body.toString(),/^<!doctype html>/i);assert.match(body.toString(),/<\/body><\/html>$/i);const identity={bytes:body.length,hash:createHash('sha256').update(body).digest('hex')};
  console.log('Warmup',mode,population+1,id,identity.bytes);
  await startDrivers();const warmup=await run({name:'warmup',mode:'concurrency',concurrency:16,durationMs:10000,discard:true},identity);await closeDrivers();
  for(const concurrency of [32])for(const phase of id==='exact'?['normal','scheduled','normal']:['normal']){
 const modeResult=await controlSsrWorker(worker,'audit-mode?defer='+(phase==='scheduled'?'1':'0'));assert.equal(modeResult.deferred,phase==='scheduled');
   await startDrivers(concurrency);const loopBefore=null;const before=await controlSsrWorker(worker,'audit-start');assert.equal(before.deferred,phase==='scheduled');
   const results=await run({name:phase,mode:'concurrency',concurrency:concurrency===1?1:16,durationMs:5000},identity);
   const after=await controlSsrWorker(worker,'audit-stop');const loopAfter=null;
   let filename;
   if(phase==='profile'){filename=`${id}-${population+1}.cpuprofile`;await writeFile(root+filename,JSON.stringify(after.profile));delete after.profile;}
   const valid=results.reduce((n,r)=>n+r.stages[0].valid,0),cpuUs=after.cpu.user+after.cpu.system-before.cpu.user-before.cpu.system;
   const stages=results.map(r=>r.stages[0]),begin=Math.min(...stages.map(s=>Date.parse(s.startedAt))),end=Math.max(...stages.map(s=>Date.parse(s.startedAt)+s.elapsedMs));
   const rps=valid/(end-begin)*1000;
   report.blocks.push({variant,mode,population,id,concurrency,phase,identity,loopBefore,loopAfter,before,after,results,profile:filename,cpuUs,valid,rps,workerPid:worker.child.pid});
   console.log(variant,population+1,concurrency,phase,JSON.stringify({rps,renderUs:after.telemetry.statistics.renderMs.sum*1000/after.telemetry.statistics.renderMs.count}));
   await closeDrivers();await writeFile(root+'capture.json',JSON.stringify(report,null,2));
  }
  await close();await writeFile(root+'capture.json',JSON.stringify(report,null,2));
 }
 for(const [name,path] of Object.entries(paths))assert.equal(createHash('sha256').update(await readFile(path)).digest('hex'),report.artifacts[name].sha256);
 assert.deepEqual(await measureSsrArtifact(resolve('packages/server/dist')),report.artifacts.server);
 assert.deepEqual(await measureSsrArtifact(resolve('framework-adapters/node-adapter/dist')),report.artifacts.nodeAdapter);
 assert.deepEqual(await measureSsrArtifact(resolve('framework-adapters/bun-adapter/dist')),report.artifacts.bunAdapter);assert.equal(report.blocks.length,14);report.complete=true;await writeFile(root+'capture.json',JSON.stringify(report,null,2));
}finally{await close();lifecycle.dispose();}
