from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'key-count';root.mkdir(exist_ok=True)
s=Path('framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js').read_text();(root/'current.mjs').write_text(s)
needle='Object.keys(value).length !==';assert s.count(needle)==9
helper='function countEnumerableOwnKeys(value, Object){let count=0;for(const key in value)if(Object.hasOwn(value,key))count++;return count;}\n'
c=helper+s.replace(needle,'countEnumerableOwnKeys(value, Object) !==')
(root/'candidate.mjs').write_text(c)
(root/'worker.mjs').write_bytes((base/'prefix-native/worker.mjs').read_bytes())
r=(base/'prefix-native-run.mjs').read_text().replace('prefix-native/','key-count/').replace('large96-bun-native-prefix-experiment','large96-bun-key-count-without-key-array')
(base/'key-count-run.mjs').write_text(r)
