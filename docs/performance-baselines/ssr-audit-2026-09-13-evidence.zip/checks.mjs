import { spawn } from 'node:child_process';
import { openSync, closeSync, writeFileSync, readFileSync, existsSync } from 'node:fs';
const root='.tmp/ssr-audit-2026-09-13';
const journal=root+'/checks.json';
const checks=existsSync(journal)?JSON.parse(readFileSync(journal,'utf8')):[];
const npm='C:/Program Files/nodejs-v26.8.1/node_modules/npm/bin/npm-cli.js';
async function run(name,exe,args) {
  if(checks.some(x=>x.name===name&&x.code===0))return;
  const row={name,exe,args,startedAt:new Date().toISOString()};checks.push(row);
  const save=()=>writeFileSync(journal,JSON.stringify(checks,null,2));save();console.log('START '+name);
  const log=openSync(root+'/check-'+name+'.log','w');
  try { await new Promise((yes,no)=> {
    const child=spawn(exe,args,{windowsHide:true,stdio:['ignore',log,log],env:{...process.env,NODE_ENV:'test',npm_execpath:npm}});
    row.pid=child.pid;child.once('error',no);child.once('exit',code=>{row.code=code;code===0?yes():no(new Error(name+' failed'));});
  }); } finally {closeSync(log);row.endedAt=new Date().toISOString();save();}
  console.log('DONE '+name);
}

await run('comparison',process.execPath,[npm,'run','test:framework-comparison']);
await run('build-scripts',process.execPath,[npm,'run','test:build-scripts']);
await run('compiled-abi',process.execPath,[npm,'run','check:compiled-abi']);
await run('platform-boundaries',process.execPath,[npm,'run','check:platform-boundaries']);
await run('docs-tests',process.execPath,[npm,'run','test','-w','@exactjs/docs']);
await run('docs-build',process.execPath,[npm,'run','verify','-w','@exactjs/docs']);
await run('docs-browser',process.execPath,[root+'/verify-docs.mjs']);
console.log('COMPLETE benchmark publication validation');
