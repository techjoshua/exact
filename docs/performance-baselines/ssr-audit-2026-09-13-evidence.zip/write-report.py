from pathlib import Path
import json
root=Path('.tmp/ssr-audit-2026-09-13')
commit=json.loads((root/'source-state.json').read_text())['baseCommit']
lines=['# Post-audit SSR benchmarks, September 13, 2026','',
'This capture repeats the production SSR sweep with bounded idle pooling in the load and burst',
'clients. Framework artifacts include the audit remediation and the benchmark-preflight compiler typing fix.',
'The previous results remain available as historical evidence. Measurements run sequentially on',
'the shared Windows PC using Node 26.8.1 and native Bun 1.4.2; foreground activity is uncontrolled.',
'The source snapshot identifies the uncommitted working tree and parent commit `'+commit+'`.','',
'Two fresh populations reverse framework order. Complete response bodies are validated and all',
'first-attempt errors remain counted. No retries, global fetch overrides, or timer patches are used.',
'The primary offered-load charts preserve abrupt connection growth. Gradually prepared connection',
'pools are measured separately and retain every setup error; they do not replace primary results.','',
'## Sustained capacity','',
'Preloaded capacity isolates rendering and HTTP delivery; normal loading includes fetching application data.',
'Both modes below use total concurrency 32. RPS counts valid completed responses. Tail ranges span drivers',
'and both populations.','',
'| Runtime | API | Loading | eXact RPS | React RPS | eXact driver p99 ms | React driver p99 ms |',
'| --- | --- | --- | ---: | ---: | --- | --- |']
captures={}
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for lane in ['multi','normal','arrivals']:
   name=runtime+('-stream' if mode=='stream' else '')+'-'+lane
   c=json.loads((root/(name+'.json')).read_text(encoding='utf8'));assert c['complete'];captures[name]=c
   if lane=='arrivals':continue
   values={}
   for id in ['exact','react']:
    rates=[];tails=[]
    for b in sorted((b for b in c['blocks'] if b['id']==id),key=lambda b:b['population']):
     ss=[next(s for s in r['stages'] if s['name']=='total-c32') for r in b['results']]
     rates.append(f'{sum(s["validRps"] for s in ss):,.0f}')
     tails.extend(s['distributions']['responseMs']['p99'] for s in ss)
    values[id]=(' / '.join(rates),f'{min(tails):.1f} to {max(tails):.1f}')
   lines.append(f'| {runtime.title()} | {mode} | {"preloaded" if lane=="multi" else "normal"} | {values["exact"][0]} | {values["react"][0]} | {values["exact"][1]} | {values["react"][1]} |')
lines+=['','## Scheduled demand','',
'Misses are requests the load generator could not start on schedule, distinct from response errors.',
'The public charts retain each runtime, API, offered rate, valid RPS, misses, errors, and response tails.',
 'Missed arrivals below include capacity, driver-lag, and end-of-stage misses across both populations.',
 'The capacity-only subset is shown separately; p99 ranges span individual drivers and populations.',
'',
'| Runtime/API | Framework | Offered RPS | Valid RPS, two populations | Errors | Missed arrivals | Capacity misses | Driver p99 ms |',
'| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |']
error_counts={};invalid=0;total_errors=0;warmup_errors=0
for name,c in captures.items():
 for b in c['blocks']:
  for r in b['results']:
   for s in r['stages']:
    if s['name']=='warmup':
     warmup_errors+=s['errors']
     continue
    invalid+=s.get('invalid',0);total_errors+=s['errors']
    for k,v in s.get('errorDetails',{}).get('counts',{}).items():error_counts[k]=error_counts.get(k,0)+v
 if not name.endswith('arrivals'):continue
 for id in ['exact','react']:
  for rate in [8000,10000]:
   rates=[];errors=misses=capacity_misses=0;tails=[]
   for b in sorted((b for b in c['blocks'] if b['id']==id),key=lambda b:b['population']):
    ss=[next(s for s in r['stages'] if s['name']==f'total-arrivals-{rate}') for r in b['results']]
    rates.append(f'{sum(s["validRps"] for s in ss):,.0f}')
    errors+=sum(s['errors'] for s in ss)
    misses+=sum(s['missedCapacity']+s['missedLag']+s['missedDeadline'] for s in ss)
    capacity_misses+=sum(s['missedCapacity'] for s in ss)
    tails.extend(s['distributions']['responseMs']['p99'] for s in ss)
   lines.append(f'| {c["runtimeId"].title()} {c["renderMode"]} | {"eXact" if id=="exact" else "React"} | {rate:,} | {" / ".join(rates)} | {errors:,} | {misses:,} | {capacity_misses:,} | {min(tails):.1f} to {max(tails):.1f} |')

lines+=['','### Request-error categories','',
'| Capture | Framework | Population | Stage | Error counts |',
'| --- | --- | ---: | --- | --- |']
for name,c in captures.items():
 for b in c['blocks']:
  by_stage={}
  for r in b['results']:
   for stage in r['stages']:
    for code,count in stage.get('errorDetails',{}).get('counts',{}).items():
     target=by_stage.setdefault(stage['name'],{})
     target[code]=target.get(code,0)+count
  for stage,counts in by_stage.items():
   lines.append(f"| {name} | {b['id']} | {b['population']+1} | {stage} | "+', '.join(f'{k}: {v:,}' for k,v in counts.items())+' |')

lines+=['',f'The capacity captures recorded {invalid:,} invalid responses and {total_errors:,} request errors.',
 f'Warmup stages, excluded from measured rates, recorded {warmup_errors:,} additional request errors.',
 'Error categories: '+(json.dumps(error_counts,sort_keys=True) if error_counts else 'none.'),'',
 'Missed arrivals and request errors remain visible in the published data. They are not removed',
 'to obtain a clean chart. These results reflect this PC during the capture; differences from older',
 'idle-PC runs are not attributed to the code change.','',
 '## Scope and verification','',
 'The primary sweep completed all 16 stages: 112 live Node/Bun string/stream browser correctness checks, twelve',
 'capacity captures, both full SSR diagnostic API modes, and the server performance suite.',
 'Capacity uses ten-second warmups, fifteen-second concurrency stages, twenty-second normal-loading',
 'stages, and twenty-second offered-load stages. Both populations are retained. Four additional captures test prepared pools. SSR diagnostics use',
 '500 sequential samples and 500 concurrency waves per supported framework and runtime: five frameworks for string, three for streaming.','',
 'The [post-audit client capture](client-audit-2026-09-13.md) separately refreshes browser timing,',
 'startup CPU, and heap charts. Both captures use the same measured source snapshot.',
 'The public documentation charts include both fresh client and SSR results.','',
 'The [structured capture](ssr-audit-2026-09-13.json) preserves raw-source identities, capacity',
 'summaries, execution commands and exit statuses, validation evidence, and separately identified',
 'client metadata. Per-driver tails are ranges, not averaged or pooled percentiles.','','']

lines += ['', '## Burst tails and preceding capture', '',
'The sixteen-request Node string burst tail remains: eXact p99 is 23.98 ms, versus 23.40 ms',
'in the preceding capture. React is 23.38 ms in this run. On Bun, eXact string burst p99 is',
'5.95 ms, versus 5.91 ms previously. These shared-PC samples do not show the Node tail resolved.', '',
'Bun streaming still favors React at preloaded concurrency 16 in both populations, while eXact',
'leads at concurrency 32. The normal-loading and offered-load streaming lanes favor React.',
'This sweep measures the production adaptive policy; it does not measure policy activation',
'or establish that a different scheduling threshold would improve the concurrency-16 result.', '',
'## Diagnostic distributions', '',
'| Runtime/API | Framework | Burst mean ms | Burst p99 ms | Previous burst p99 ms |',
'| --- | --- | ---: | ---: | ---: |']
for mode, name in [('string','ssr'),('stream','ssr-stream')]:
 raw=json.loads((root/(name+'.json')).read_text())
 old=json.loads((root/('before-performance-report.json' if mode=='string' else 'before-ssr-stream-report.json')).read_text())
 for runtime, participants in raw['runtimes'].items():
  oldserver=old['server'] if runtime=='node' else old['server']['bun']
  names={'exact':'Exact','react':'React','sveltekit':'SvelteKit','nuxt':'Nuxt','tanstack-start':'TanStack Start'}
  for id, result in participants.items():
   burst=result['concurrent']['burstElapsedMs']
   prev=next(s['stats'] for s in oldserver['burst']['series'] if s['name']==names[id])
   lines.append(f"| {runtime} {mode} | {names[id]} | {burst['mean']:.2f} | {burst['p99']:.2f} | {prev['p99']:.2f} |")

lines += ['', '## Gradual connection preparation controls', '',
'Each driver prepares its pool in increments of 16 connections up to 256 immediately before',
'offered load. Setup responses are validated and setup failures are reported separately.',
'This changes connection arrival shape and is a separate workload from the primary charts.', '',
'| Runtime/API | Framework | Population | Setup errors | Measured errors | 8,000 offered: valid RPS | 10,000 offered: valid RPS |',
'| --- | --- | ---: | ---: | ---: | ---: | ---: |']
for name in ['node-prepared','bun-prepared','node-stream-prepared','bun-stream-prepared']:
 c=json.loads((root/(name+'.json')).read_text());assert c['complete']
 for b in c['blocks']:
  setup=sum(len(p['errors']) for r in b['results'] for p in r['connectionPreparation'])
  errors=sum(s['errors'] for r in b['results'] for s in r['stages'] if s['mode']=='arrival')
  rates=[sum(next(s for s in r['stages'] if s['name']==f'total-arrivals-{rate}')['validRps'] for r in b['results']) for rate in [8000,10000]]
  lines.append(f"| {c['runtimeId']} {c['renderMode']} | {b['id']} | {b['population']+1} | {setup} | {errors} | {rates[0]:,.0f} | {rates[1]:,.0f} |")
lines += ['', 'All raw results, including failed setup attempts, are linked from the structured capture.', '']
Path('docs/performance-baselines/ssr-audit-2026-09-13.md').write_text('\n'.join(lines),encoding='utf8')
print(json.dumps({'invalidResponses':invalid,'requestErrors':total_errors,'errorCounts':error_counts}))
