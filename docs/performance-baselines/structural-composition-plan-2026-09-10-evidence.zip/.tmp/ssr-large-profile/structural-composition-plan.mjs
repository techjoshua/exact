import fs from 'node:fs/promises';
import ts from 'typescript';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';

const base='.tmp/ssr-large-profile/';
const source=await fs.readFile(base+'conditional-emission/server-entry.js','utf8');
const ast=ts.createSourceFile('server-entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const declarations=new Map();
function collect(node){
 if(ts.isVariableDeclaration(node)&&ts.isIdentifier(node.name))declarations.set(node.name.text,node.initializer);
 ts.forEachChild(node,collect);
}
collect(ast);
const owners=['Document','IncidentDetail'];
const plans=[];
for(const owner of owners){
 const implementation=declarations.get(`__exactImplementation_${owner}_1`);
 assert.ok(implementation&&ts.isFunctionExpression(implementation));
 const sites=[];
 function visit(node,functions=[]){
  if(node!==implementation&&(ts.isArrowFunction(node)||ts.isFunctionExpression(node)))functions=[...functions,node.getText(ast).slice(0,100)];
  if(ts.isCallExpression(node)&&node.expression.getText(ast)==='createPreparedServerRenderProgram'){
   const descriptor=node.arguments[0].getText(ast);
   const creation=declarations.get(descriptor);
   assert.ok(creation&&ts.isCallExpression(creation));
   const definition=creation.arguments[0];assert.ok(ts.isObjectLiteralExpression(definition));
   const properties=new Map(definition.properties.map(p=>[p.name?.getText(ast).replaceAll('"',''),p]));
   const writer=properties.get('ssr');assert.ok(writer);
   const operations={};let prepareReferences=0;
   function scan(node){
    if(ts.isCallExpression(node)&&ts.isPropertyAccessExpression(node.expression)){
     const target=node.expression.expression.getText(ast),name=node.expression.name.text;
     if(target==='__exactSsr')operations[name]=(operations[name]??0)+1;
     if(name==='prepareReferences')prepareReferences++;
    }
    ts.forEachChild(node,scan);
   }
   scan(writer);
   sites.push({descriptor,line:ast.getLineAndCharacterOfPosition(node.getStart(ast)).line+1,
    values:ts.isArrayLiteralExpression(node.arguments[1])?node.arguments[1].elements.length:null,
    nestedFunctions:functions,host:properties.get('ssrHost')?.initializer?.getText(ast),
    prepareReferenceCallSites:prepareReferences,operationCallSites:operations});
  }
  ts.forEachChild(node,child=>visit(child,functions));
 }
 visit(implementation);
 plans.push({owner,sites});
}
const result={inputSha256:createHash('sha256').update(source).digest('hex'),
 note:'Static call sites, not executed counts. A nested function can be invoked eagerly by map or deferred by a child range. No purity or scheduling proof is inferred.',plans};
await fs.writeFile(base+'structural-composition-plan.json',JSON.stringify(result,null,2));
for(const plan of plans)console.log(JSON.stringify({owner:plan.owner,sites:plan.sites.map(({descriptor,values,nestedFunctions,host,prepareReferenceCallSites})=>({descriptor,values,nestedFunctionDepth:nestedFunctions.length,host,prepareReferenceCallSites}))}));
