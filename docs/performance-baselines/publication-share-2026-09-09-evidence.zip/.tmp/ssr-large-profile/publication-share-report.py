import hashlib,json,pathlib,zipfile
root=pathlib.Path('.'); work=root/'.tmp/ssr-large-profile'
rows=json.loads((work/'publication-share-results.json').read_text(encoding='utf-8'))
controls=json.loads((work/'callback-current-results.json').read_text(encoding='utf-8'))
for r in rows:
 matches=[c for c in controls if c['mode']==r['mode'] and c['scenario']==r['scenario'] and c['entry'].endswith('/callback-current.mjs')]
 assert matches and all(c['hash']==r['hash'] for c in matches)
table='\n'.join(f"| {r['runtimeId']} | {r['mode']} | {r['scenario']} | {r['publicationTiming']['ms']/r['iterations']*1000:.2f} | {r['publicationTiming']['ms']/r['elapsedMs']*100:.1f}% |" for r in rows)
dest=root/'docs/performance-baselines/publication-share-2026-09-09'
dest.with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
doc='''# Current hydration publication cost

Date: 2026-09-09. Diagnostic measurement, no production change.

## Audit and hypothesis

The current positional validator creates final positional arrays; the ordinary serializer walks
them with JSON.stringify rather than cloning the graph. Reactive collection substitution has a
separate replacer only when needed. Removing positional arrays would therefore require fusing
projection and encoding, not simply deleting an existing duplicate copy.

Hypothesis: hydration publication still occupies at least 15% of large-fixture renderer time,
making it a more consequential optimization target than the isolated forwarding wrapper.

## Measurement

A frozen copy of the retained synchronous-callback bundle wraps renderHydrationScriptValue with
performance.now() and cumulative call/time counters. Each of eight fresh processes performs 5,000
warmups and 12,000 measured renders. Counters reset after warmup. Every measured render publishes
exactly once. Node and Bun use the same portable artifact with NODE_ENV=production. Small means
three incidents; large means 96. The application renders its complete document with empty client
tags. Streams are consumed with Response.text(). Full document hashes match the previously captured
control for both fixture sizes.

The timed publication scope includes metadata construction, validation/projection, JSON encoding,
script escaping, byte counting, and script markup. It excludes earlier component state capture and
later insertion into the document. This is one instrumented population per cell, not a paired
performance comparison or React benchmark. Clock calls, rest-argument forwarding, and changed JIT
decisions can perturb the measurement. Reported shares are approximate diagnostic evidence.

| Runtime | Mode | Fixture | Publication microseconds/render | Share of render time |
| --- | --- | --- | ---: | ---: |
'''+table+'''

The large-fixture results support the hypothesis. Publication remains worth investigating, but
eliminating all measured work would be an unattainable upper bound: state still needs validation,
encoding, and delivery. These timings do not show which publication substage dominates and do not
justify removing validation. The next useful measurement separates projection/validation from
JSON encoding and byte accounting before designing a fused encoder.

Production code and retained improvements are unchanged. No package/browser tests were run for
this diagnostic-only artifact. The React parity objective remains unmet. The archive preserves
control and instrumented bundles, builder, worker, runner, input, raw results, reporter, and hashes.
'''
dest.with_suffix('.md').write_text(doc,encoding='utf-8')
files=[work/name for name in ['callback-current.mjs','callback-current-results.json','publication-share.mjs','publication-share-build.mjs','publication-share-worker.mjs','publication-share-run.mjs','publication-share-results.json','publication-share-report.py']]+[root/'.tmp/positional-leaves/data.json']
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p))
 z.writestr('manifest.json',json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(table)
print('Verified',archive)
