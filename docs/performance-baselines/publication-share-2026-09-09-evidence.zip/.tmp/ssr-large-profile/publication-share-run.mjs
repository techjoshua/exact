import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const rows=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const scenario of ['small','large']){
 const entry='.tmp/ssr-large-profile/publication-share.mjs';
 const r=spawnSync(runtime,['.tmp/ssr-large-profile/publication-share-worker.mjs',entry,mode,scenario,'12000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 const row={runtimeId:runtime,artifactSha256:createHash('sha256').update(readFileSync(entry)).digest('hex'),...JSON.parse(r.stdout)};
 if(row.publicationTiming.calls!==row.iterations)throw Error('Unexpected publication count');
 rows.push(row);writeFileSync('.tmp/ssr-large-profile/publication-share-results.json',JSON.stringify(rows,null,2));console.log(runtime,mode,scenario,row.usPerRender.toFixed(2),(row.publicationTiming.ms/row.elapsedMs*100).toFixed(1)+'% publication');
}
