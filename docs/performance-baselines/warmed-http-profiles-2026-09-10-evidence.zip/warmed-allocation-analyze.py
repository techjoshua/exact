import json, pathlib, collections, urllib.parse
root = pathlib.Path('.tmp/ssr-large-profile/warmed-current-http-allocations')
capture = json.loads((root/'capture.json').read_text())
assert capture['complete']
regions = {}
for framework in ('exact', 'react'):
    path = pathlib.Path(capture['artifacts'][framework]['path'])
    current = ''; mapped = []
    for line in path.read_text(encoding='utf-8').splitlines():
        if line.startswith('//#region '): current = line[10:]
        if line.startswith('//#endregion'): current = ''
        mapped.append(current)
    regions[path.as_posix().lower()] = mapped
result = {'blocks': [], 'aggregate': {}}
for block in capture['blocks']:
    profile = json.loads((root/block['profile']).read_text())
    sites = collections.Counter(); modules = collections.Counter()
    def visit(node):
        frame = node['callFrame']; url = frame['url']; line = frame['lineNumber']
        path = urllib.parse.unquote(urllib.parse.urlparse(url).path).lstrip('/') if url.startswith('file:') else url
        mapped = regions.get(path.lower())
        module = mapped[line] if mapped and 0 <= line < len(mapped) else url
        key = (frame['functionName'] or '(anonymous)', module, line+1)
        sites[key] += node.get('selfSize', 0); modules[module] += node.get('selfSize', 0)
        for child in node.get('children', []): visit(child)
    visit(profile['head'])
    result['blocks'].append({'id': block['id'], 'population': block['population'], 'valid': block['valid'], 'estimatedBytesPerRequest': sum(sites.values())/block['valid']})
    aggregate = result['aggregate'].setdefault(block['id'], {'valid': 0, 'sites': collections.Counter(), 'modules': collections.Counter()})
    aggregate['valid'] += block['valid']; aggregate['sites'].update(sites); aggregate['modules'].update(modules)
for name, aggregate in result['aggregate'].items():
    valid = aggregate['valid']; total = sum(aggregate['sites'].values())
    aggregate['estimatedBytesPerRequest'] = total/valid
    aggregate['sites'] = [{'function': key[0], 'module': key[1], 'line': key[2], 'bytesPerRequest': value/valid} for key, value in aggregate['sites'].most_common() if value]
    aggregate['modules'] = [{'module': key, 'bytesPerRequest': value/valid} for key, value in aggregate['modules'].most_common() if value]
    print(name, valid, 'estimated bytes/request', round(total/valid))
    for row in aggregate['sites'][:25]: print(round(row['bytesPerRequest']), row['function'], row['module'], row['line'])
    print('MODULES', json.dumps(aggregate['modules'][:15]))
(root/'analysis.json').write_text(json.dumps(result, indent=2))
