import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';let source=readFileSync(dir+'callback-current.mjs','utf8');
function replace(before,after){if(source.split(before).length!==2)throw Error('Nonunique boundary: '+before);source=source.replace(before,after);}
replace('if (output instanceof Promise) return output.finally(() => leaveSsrTreeDepth(context));','if (output instanceof Promise) return finishPendingChildDepth(output, context);');
replace('if (value instanceof Promise) return value.then((html) => continueProgramOutput(context, segments, render, index + 1, appendBoundedHtml(context, captureNestedEnhancementStringPrefix(context, output), html)));','if (value instanceof Promise) return continuePendingProgramOutput(value, context, segments, render, index + 1, output);');
replace('const entered = enterHostTag(context, host);\n\t\treturn withRenderCleanup(() => mapRenderValue(renderProgramOutput(context, segments, render), (html) => entered.prefix ? appendBoundedHtml(context, entered.prefix, html) : html), () => leaveHost(context, entered.tag));','return renderDocumentHostOutput(context, segments, render, host);');
source+=`
function finishPendingChildDepth(output, context) {
 return output.finally(()=>leaveSsrTreeDepth(context));
}
function continuePendingProgramOutput(value, context, segments, render, next, output) {
 return value.then(html=>continueProgramOutput(context,segments,render,next,appendBoundedHtml(context,captureNestedEnhancementStringPrefix(context,output),html)));
}
function renderDocumentHostOutput(context, segments, render, host) {
 const entered=enterHostTag(context,host);
 return withRenderCleanup(()=>mapRenderValue(renderProgramOutput(context,segments,render),html=>entered.prefix?appendBoundedHtml(context,entered.prefix,html):html),()=>leaveHost(context,entered.tag));
}
`;
writeFileSync(dir+'pending-scope.mjs',source);
