import hashlib,json,pathlib,zipfile
root=pathlib.Path('.');work=root/'.tmp/ssr-large-profile'
rows=json.loads((work/'projector-small-results.json').read_text(encoding='utf-8'))
assert len(rows)==32
summary=[]
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['small','large']:
   changes=[]
   for round in range(2):
    group=[r for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['round']==round]
    a=next(r for r in group if r['variant']=='marker-hex-current');b=next(r for r in group if r['variant']=='projector-small')
    assert a['hash']==b['hash'];changes.append((b['usPerRender']/a['usPerRender']-1)*100)
   summary.append(dict(runtime=runtime,mode=mode,scenario=scenario,changes=changes))
table='\n'.join(f"| {s['runtime']} | {s['mode']} | {s['scenario']} | {s['changes'][0]:+.2f}% | {s['changes'][1]:+.2f}% |" for s in summary)
dest=root/'docs/performance-baselines/projector-small-2026-09-09'
dest.with_suffix('.json').write_text(json.dumps(dict(summary=summary,populations=rows),indent=2)+'\n',encoding='utf-8')
doc='''# Generated hydration projection for short arrays

Date: 2026-09-09. Rejected blanket cutoff change; production remains unchanged.

## Hypothesis

The current runtime selects compiler-generated record projectors for arrays of at least sixteen
elements. The prototype selects the same projectors for every nonempty array. The hypothesis was
a 2-5% small-document rendering-time improvement from avoiding schema interpretation. Generated
projectors retain all their existing validation and native Set ancestry requirements; the change
does not remove checks or alter serialization. Earlier studies described the cutoff as a heuristic.

## Method

Thirty-two fresh processes compare marker-hex-current and a frozen patched copy across Node/Bun,
string/consumed stream, small/large documents, and two reversed-order pairs per cell. Each population
uses NODE_ENV=production, 5,000 warmups and 12,000 measured renders. Small contains three incidents;
large contains 96. Both include two module scripts and two stylesheet links in their application-owned
document shell. Both runtimes use the same Node-target artifact; streams are consumed through
Response.text(). Every population completed, framing checks passed, and all paired full-body hashes
matched. No observation was discarded.

## Results

Positive means longer rendering time. These are descriptive local pairs, not confidence intervals,
HTTP throughput, browser timings, or a fresh React comparison.

| Runtime | Mode | Fixture | Pair 1 time change | Pair 2 time change |
| --- | --- | --- | ---: | ---: |
'''+table+'''

Large-document strings improve in both pairs on both runtimes, but small-document strings do not
show a repeatable gain. Small streaming is slower in both pairs on both runtimes. The blanket
cutoff change is not adopted.

One possible follow-up is to select short-array projectors only after ancestry already uses a
native Set, avoiding early promotion for small documents. A builder for that condition was prepared
but not executed in this capture. No timing or correctness claim is made for it. The current result
does not isolate ancestry setup as the cause of the regression.

## Related architecture audit

A subsequent user question prompted inspection of render-program.ts, program-output.ts,
direct-component-content.ts, tree-output.ts, output-stream.ts, and stream/production.ts. Compiled
programs create ordered arrays of HTML spans and deferred child references. Recursive rendering
generally returns subtree strings, which program-output concatenates before tree-output constructs
the final chunked result. Stream consumers can write multiple chunks, but the final request writer
is not passed directly through every component render.

A shared sink passed through traversal could avoid some intermediate arrays and subtree results,
and enable earlier publication within a document. This is a hypothesis requiring an experiment,
not a measured gain. JavaScript string concatenation can use ropes, so repeated concatenation must
not be described as repeated full-byte copying without evidence. Enhancements, output transforms,
document discovery, task scheduling, backpressure, error boundaries, and hydration placement need
explicit treatment before adopting such a design. Component closing markup must not terminate the
request-owned sink. No second rendering engine is proposed.

No production source changed, so no new package/browser suite was run. Fixture hash equality does
not replace general validation or lifecycle tests for an adopted change. Prior retained validation
remains documented in marker-hex-2026-09-09.md. Overall React parity remains unmet.

The archive preserves both artifacts, builder, runner, worker, fixed data, raw observations,
reporter, and SHA-256 manifest. Reproduction requires the workspace dependencies.
'''
dest.with_suffix('.md').write_text(doc,encoding='utf-8')
files=[work/n for n in ['marker-hex-current.mjs','projector-small.mjs','projector-small-build.mjs','projector-small-run.mjs','direct-map-worker.mjs','projector-small-results.json','projector-small-report.py','projector-warm-build.mjs']]+[root/'.tmp/positional-leaves/data.json',dest.with_suffix('.md'),dest.with_suffix('.json')]
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps({p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(table);print('Verified',archive)
