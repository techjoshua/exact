import {summarizeSsrCapacityCapture} from '../../framework-comparison/src/ssr-capacity-report.mjs';
import {readFile,writeFile} from 'node:fs/promises';
const dir='.tmp/wsl-workspace-2026-09-19',prefix='wsl-workspace-2026-09-19';
const json=async p=>JSON.parse(await readFile(p,'utf8'));
const report=await json(dir+'/report-data.json'),source=await json(dir+'/source-state.json');
const f=(v,n=2)=>Number(v).toLocaleString('en-US',{minimumFractionDigits:n,maximumFractionDigits:n});
const lines=['# WSL framework comparison, September 18, 2026','',
'This capture reruns the full framework comparison under WSL 2 using the last Windows capture’s workload plans and sample counts. The source is the uncommitted worktree based on '+source.commit+'. Source hashes and the worktree patch accompany the evidence.',
'',
'The production comparison covers five frameworks in the client and string SSR lanes. Streaming uses the three participants with an actual streaming renderer: eXact, React, and TanStack Start. Node and native Bun run separately. Sustained capacity uses eXact and React, two independent response-validating drivers, and two populations with reversed framework order.',
'',
'Client timing retains 30 samples per framework, startup ten samples at each of 1x/4x/6x CPU, and heap composition five samples per framework. Captured-page replay stops framework servers before timing. SSR diagnostics retain 500 sequential samples and 500 burst waves. Sustained capacity uses the same plans as the September 18 Windows baseline.',
'',
'## Client timing','',
'Each cell is mean / p95 / p99. Lower is better. Historical differences on this shared PC do not isolate the effect of a code change.','',
'| Metric | Unit | '+report.browserCharts[0].series.map(s=>s.name).join(' | ')+' |',
'| --- | --- | '+report.browserCharts[0].series.map(()=> '---:').join(' | ')+' |'];
for(const chart of report.browserCharts)lines.push('| '+chart.title+' | '+chart.unit+' | '+chart.series.map(s=>['mean','p95','p99'].map(k=>f(s.stats[k],3)).join(' / ')).join(' | ')+' |');
lines.push('','## Sustained SSR capacity','','Total concurrency is 32. Each cell contains the two independent populations. RPS counts valid completed responses. Driver p99 is the largest of the two drivers in that population.','','| Runtime | API | Loading | eXact valid RPS | React valid RPS | eXact p99 ms | React p99 ms |','| --- | --- | --- | ---: | ---: | ---: | ---: |');
let errors=0,invalid=0;const categories={};const captures=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const lane of ['multi','normal','arrivals']){
 const name=runtime+(mode==='stream'?'-stream':'')+'-'+lane,c=await json(dir+'/'+name+'.json');captures.push(c);
 for(const b of c.blocks)for(const r of b.results)for(const s of r.stages){errors+=s.errors??0;invalid+=s.invalid??s.invalidResponses??0;for(const [key,value] of Object.entries(s.errorDetails?.counts??{}))categories[key]=(categories[key]??0)+value;}
 if(lane==='arrivals')continue;
 const val=id=>c.blocks.filter(b=>b.id===id).sort((a,b)=>a.population-b.population).map(b=>{const stages=b.results.map(r=>r.stages.find(s=>s.name==='total-c32'));return {rps:stages.reduce((a,s)=>a+s.validRps,0),p99:Math.max(...stages.map(s=>s.distributions.responseMs.p99))};});
 const a=val('exact'),b=val('react');lines.push('| '+[runtime,mode,lane==='multi'?'preloaded':'normal',a.map(x=>f(x.rps,0)).join(' / '),b.map(x=>f(x.rps,0)).join(' / '),a.map(x=>f(x.p99)).join(' / '),b.map(x=>f(x.p99)).join(' / ')].join(' | ')+' |');
}
lines.push('','## Offered load','','Abrupt offered-load stages retain connection-growth pressure. Missed arrivals and request errors are included, including warmup errors in the total. No connection-preparation control replaces the primary results.','','| Runtime/API | Framework | Offered RPS | Valid RPS, two populations | Request errors | Missed arrivals |','| --- | --- | ---: | ---: | ---: | ---: |');
for(const c of captures.filter(c=>c.plan.stages.some(s=>s.mode==='arrival')))for(const id of ['exact','react'])for(const rate of [8000,10000]){let e=0,m=0;const rates=[];for(const b of c.blocks.filter(b=>b.id===id).sort((a,b)=>a.population-b.population)){const ss=b.results.map(r=>r.stages.find(s=>s.name==='total-arrivals-'+rate));rates.push(f(ss.reduce((a,s)=>a+s.validRps,0),0));for(const s of ss){e+=s.errors;m+=s.missedCapacity+s.missedLag+s.missedDeadline;}}lines.push('| '+[c.runtimeId+'/'+c.renderMode,id,f(rate,0),rates.join(' / '),e,m].join(' | ')+' |');}
lines.push('', 'Total capacity request errors: '+errors+'. Invalid responses: '+invalid+'. Error categories are retained in the raw driver results.', '', '## SSR completion tails', '', 'The burst metric measures completion of a 16-request wave, including data loading. Values are mean / p95 / p99 milliseconds.', '', '| Runtime/API | '+report.server.burst.series.map(s=>s.name).join(' | ')+' |', '| --- | '+report.server.burst.series.map(()=> '---:').join(' | ')+' |');
const stream=await json('apps/docs/src/data/ssr-stream-report.json');
for(const [mode,owner] of [['string',report.server],['stream',stream.server]])for(const runtime of ['node','bun']){const chart=(runtime==='node'?owner:owner.bun).burst;lines.push('| '+runtime+'/'+mode+' | '+report.server.burst.series.map(s=>{const row=chart.series.find(r=>r.name===s.name);return row?['mean','p95','p99'].map(k=>f(row.stats[k])).join(' / '):'unavailable';}).join(' | ')+' |');}

lines.push('','## Historical comparison','','The previous docs charts describe the [September 18 Windows capture](enhancement-framework-2026-09-18.md). This WSL capture uses the same CPU, but Node changed from 26.8.1 to 26.9.0, available memory changed, and source hashes and generated artifacts differ. Bun remains 1.4.2, with platform-specific connection settings. The differences do not isolate an operating-system effect.','','| eXact browser metric | Previous mean | Current mean | Change |','| --- | ---: | ---: | ---: |');
const previous=await json(dir+'/before-performance-report.json');
for(const c of report.browserCharts){const before=previous.browserCharts.find(x=>x.title===c.title).series.find(x=>x.name==='Exact').stats.mean,after=c.series.find(x=>x.name==='Exact').stats.mean;lines.push('| '+[c.title,f(before,3),f(after,3),f((after/before-1)*100,1)+'%'].join(' | ')+' |');}
const browser=await json(dir+'/browser.json'),oldBrowser=await json('docs/performance-baselines/enhancement-framework-2026-09-18-browser.json');
const currentArtifact=browser.complexity.find(x=>x.participantId==='exact-controlled').artifacts,oldArtifact=oldBrowser.complexity.find(x=>x.participantId==='exact-controlled').artifacts;
lines.push('','## Production client size','','The controlled eXact participant’s complete production client artifacts changed from '+f(oldArtifact.gzipBytes,0)+' to '+f(currentArtifact.gzipBytes,0)+' gzip bytes ('+f((currentArtifact.gzipBytes/oldArtifact.gzipBytes-1)*100,1)+'%). Raw bytes changed from '+f(oldArtifact.rawBytes,0)+' to '+f(currentArtifact.rawBytes,0)+'. This is a production-minified application measurement; it is distinct from the unminified dedicated enhancement fixture.');
lines.push('','## Validation and evidence','','Production Node and Bun targets passed 35 string-rendering browser contracts each and 21 streaming contracts each before measurement. Response identity, artifact identity, and load accounting are checked by the capture and publication tools. Error counts and missed arrivals remain visible.','','The [structured capture]('+prefix+'.json) retains raw source links, artifact hashes, source state, execution journal, runner source, and previous chart values. The public charts are generated from these measurements.','','The [September 18 Windows capture](enhancement-framework-2026-09-18.md) remains historical evidence. This is a framework benchmark refresh, not a new full release-validation run.','');

// Keep the matched before/after throughput comparison ahead of the detailed current-capture tables.
const throughputComparison=['## Windows-to-WSL sustained RPS','','Same workload plans, total concurrency 32, two independent drivers, and two reversed-order populations. Rates divide total valid responses by the union of simultaneous driver spans, summed across both populations and including drain, matching the public charts. These differences also include runtime, source, and generated-artifact changes; they do not isolate WSL.','','| Runtime/API | Loading | Framework | Windows RPS | WSL RPS | Change |','| --- | --- | --- | ---: | ---: | ---: |'];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const lane of ['multi','normal']){
 const name=runtime+(mode==='stream'?'-stream':'')+'-'+lane;
 const before=await json('docs/performance-baselines/enhancement-framework-2026-09-18-'+name+'.json');
 const after=await json(dir+'/'+name+'.json');
 for(const id of ['exact','react']){
  const rate=c=>summarizeSsrCapacityCapture(c).find(row=>row.name===(id==='exact'?'eXact':'React')&&row.concurrency===32).rps;
  const a=rate(before),b=rate(after);
  throughputComparison.push('| '+[runtime+'/'+mode,lane==='multi'?'preloaded':'normal',id,f(a,0),f(b,0),(b>=a?'+':'')+f((b/a-1)*100,1)+'%'].join(' | ')+' |');
 }
}
throughputComparison.push('');
const clientHeading=lines.indexOf('## Client timing');lines.splice(clientHeading,0,...throughputComparison);
const native=await json(dir+'/native.json');
lines.push('## Native full stack','','The separate native capture passed all eight acceptance tests and retained seven browser samples per participant. Its SSR and mutation results are in ['+prefix+'-native.json]('+prefix+'-native.json). Native and controlled-service results remain separate.','');


const oldDiagnostic=await json('docs/performance-baselines/enhancement-framework-2026-09-18-ssr.json'),newDiagnostic=await json(dir+'/ssr.json');
lines.push('## Five-framework diagnostic RPS','','These string-SSR diagnostic captures both use one 1,000 ms c32 window after the same 500-request and 500-burst populations. One window is weak evidence of steady-state capacity; use the independent-driver results above for the eXact/React throughput comparison.','','| Framework | Node Windows RPS | Node WSL RPS | Change | Bun Windows RPS | Bun WSL RPS | Change |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |');
for(const id of ['exact','react','sveltekit','nuxt','tanstack-start']){const cells=[id];for(const runtime of ['node','bun']){const a=oldDiagnostic.runtimes[runtime][id].saturation['32'].aggregateRequestsPerSecond,b=newDiagnostic.runtimes[runtime][id].saturation['32'].aggregateRequestsPerSecond;cells.push(f(a,0),f(b,0),(b>=a?'+':'')+f((b/a-1)*100,1)+'%');}lines.push('| '+cells.join(' | ')+' |');}lines.push('');

await writeFile('docs/performance-baselines/'+prefix+'.md',lines.join('\n'));
console.log(JSON.stringify({errors,invalid,categories}));
