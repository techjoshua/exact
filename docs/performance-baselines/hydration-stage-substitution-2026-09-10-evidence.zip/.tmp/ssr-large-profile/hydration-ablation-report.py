import hashlib
import json
import zipfile
from pathlib import Path
from statistics import mean

root = Path('.tmp/ssr-large-profile')
folder = root / 'hydration-ablation'
capture = json.loads((folder / 'capture.json').read_text())
assert capture['complete'] and len(capture['blocks']) == 18
rows = json.loads((folder / 'summary.json').read_text())
valid = sum(b['valid'] for b in capture['blocks'])
errors = sum(s['errors'] for b in capture['blocks'] for r in b['results'] for s in r['stages'])
assert errors == 0
report = Path('docs/performance-baselines/hydration-stage-substitution-2026-09-10.md')
lines = ['# Same-worker hydration stage substitution, 2026-09-10', '',
'## Finding', '',
'Replacing fixed hydration results improves Node string HTTP throughput in both',
'worker populations. JSON encoding is the strongest individual stage tested.',
'Whole hydration publication has additional headroom. This locates worthwhile',
'work but does not establish the dominant cause of the entire HTTP gap, nor that',
'an equivalent production optimization can recover the substitution gains.', '',
'## Method', '',
'Use the integrated current artifact, one shared renderer and the existing Node',
'HTTP adapter. The application component tree renders on every request. Each',
'worker switches between normal execution and a single precalculated stage,',
'using one fixed input. Each treatment is bracketed by normal execution. A second',
'fresh worker reverses treatment order. Compare treatments with the arithmetic',
'mean of their adjacent normal blocks, not another worker. Each block runs two',
'drivers with 16 concurrent requests each for three seconds, after ten seconds',
'of HTTP warmup per worker. Drivers restart between blocks.', '',
'Before and after each HTTP block, the same worker also performs isolated render',
'loops with 10,000 warmup and 10,000 measured renders. Cache priming is separate',
'for HTTP and isolated loops to preserve their different pathname string',
'representations. Stage counters verify which operations execute. Instrumentation',
'and reuse can affect optimization, allocation, GC and downstream costs, so these',
'are diagnostic results, not publishable framework comparison scores.', '',
'Substitutions:', '',
'- Validation/projection: reuse the projected compact payload at the validation boundary.',
'- JSON: reuse the JSON string; run normal projection and escaping.',
'- Escaping: reuse the escaped JSON; run normal projection and JSON encoding.',
'- Whole publication: reuse the complete hydration script; retain tree rendering,',
'  state capture, final document assembly and HTTP delivery.', '',
'No user input is cached in production. Cached validation is not a proposal to',
'remove framework validation. These diagnostic substitutions are valid only for',
'the fixed fixture. Ten parity checks cover ordinary and escaped script content.',
f'All {valid:,} measured HTTP responses match the complete 4,672-byte document',
'identity; zero errors. Artifact and adapter hashes are verified before/after.', '',
'## Paired HTTP results', '',
'| Stage | Worker | Normal RPS | Substituted RPS | Change |',
'| --- | ---: | ---: | ---: | ---: |']
for stage in ('json','escape','validation','hydration'):
    for r in rows:
        if r['stage']==stage:
            lines.append(f"| {stage} | {r['population']} | {r['controlRps']:,.0f} | {r['stubRps']:,.0f} | {r['gainPct']:+.2f}% |")
lines += ['', '## Render duration within each setting', '',
'Arithmetic means of both worker comparisons, microseconds per render. HTTP',
'figures use the benchmark render timer, not exclusive CPU samples.', '',
'| Stage | Normal isolated | Substituted isolated | Normal HTTP | Substituted HTTP |',
'| --- | ---: | ---: | ---: | ---: |']
for stage in ('json','escape','validation','hydration'):
    selected=[r for r in rows if r['stage']==stage]
    values=[mean(r[k] for r in selected) for k in ('controlLoopUs','stubLoopUs','controlHttpUs','stubHttpUs')]
    lines.append('| '+stage+' | '+' | '.join(f'{v:.2f}' for v in values)+' |')
lines += ['', 'The treatment savings are not additive. Whole-stage reuse changes more',
'allocation and string construction than its individual substitutions. It also',
'still leaves substantial HTTP-versus-isolated render overhead. Next, separate',
'metadata assembly/state capture from encoding, and use controlled substitutions',
'at the document rendering and response-adapter boundaries. Preserve complete',
'output and lifecycle ownership when isolating those stages.', '',
'## Previous shared-callback HTTP confirmation', '',
'The separately completed integrated callback screen produced the following',
'means. It uses separate workers per implementation and therefore remains',
'susceptible to the demonstrated worker bias. The Node regression signals below',
'must not be hidden by allocation reductions or treated as causal proof.', '',
'| Mode | Previous eXact RPS | Integrated eXact RPS | React RPS |',
'| --- | ---: | ---: | ---: |']
integrated=json.loads((root/'component-forwarding-integrated/http.json').read_text())
for runtime in ('node','bun'):
    for mode in ('string','stream'):
        values=[mean(b['rps'] for b in integrated if b['runtime']==runtime and b['mode']==mode and b['variant']==v) for v in ('baseline','compiled','react')]
        lines.append('| '+runtime+' '+mode+' | '+' | '.join(f'{v:,.0f}' for v in values)+' |')
lines += ['', 'The integrated change remains provisional. This screen does not resolve its',
'Node throughput tradeoff; it is not an accepted general HTTP improvement.',
'The hydration substitution experiment uses that integrated artifact consistently',
'and makes no comparison against React from a different run.', '',
'## Evidence', '',
'The adjacent ZIP includes raw results, scripts, diagnostic and current artifacts,',
'fixture, checks, prior integrated HTTP results and a verified SHA-256 inventory.',
'Dependencies are workspace-owned, not a standalone distribution.', '']
assert not report.exists()
report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[root/n for n in ('hydration-ablation-build.mjs','hydration-ablation-check.mjs','hydration-ablation-run.mjs','hydration-ablation-analyze.py','hydration-ablation-report.py','http-invocation-trace/worker.mjs','http-invocation-trace-run.mjs','component-forwarding-integrated/server-entry.js','component-forwarding-integrated/bun-server-entry.js','component-forwarding-integrated/http.json','component-forwarding-integrated/http.log','component-forwarding-integrated-http.mjs','component-forwarding-integrated-http-build.mjs')]+[Path('.tmp/positional-leaves/data.json'),report]
files=sorted(set(p for p in files if p.is_file()))
archive=report.with_name(report.stem+'-evidence.zip')
assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for p,digest in manifest.items():assert hashlib.sha256(z.read(p)).hexdigest()==digest
print(report, len(files), 'verified files')
