import json
from pathlib import Path
from statistics import mean

root = Path('.tmp/ssr-large-profile')
data = json.loads((root / 'hydration-ablation/capture.json').read_text())
rows = []
for population in (0, 1):
    blocks = [b for b in data['blocks'] if b['population'] == population]
    for i, b in enumerate(blocks):
        if b['phase'] == 'none' or i + 1 == len(blocks):
            continue
        neighbors = [blocks[i-1], blocks[i+1]]
        assert all(n['phase'] == 'none' for n in neighbors)
        def render(x):
            s = x['after']['telemetry']['statistics']['renderMs']
            return s['sum'] * 1000 / s['count']
        def loop(x):
            return mean(x[k]['meanMs'] for k in ('loopBefore', 'loopAfter')) * 1000
        counts = b['after']['ablation']['counts']
        for stage, count in counts.items():
            assert (count == 0) == (b['phase'] == 'hydration' or stage == b['phase']), (b['phase'], counts)
        control = mean(n['rps'] for n in neighbors)
        rows.append(dict(population=population+1, stage=b['phase'], controlRps=control,
                         stubRps=b['rps'], gainPct=(b['rps']/control-1)*100,
                         controlHttpUs=mean(render(n) for n in neighbors), stubHttpUs=render(b),
                         controlLoopUs=mean(loop(n) for n in neighbors), stubLoopUs=loop(b)))
print(json.dumps({'complete':data['complete'], 'rows':rows}, indent=2))
if data['complete']:
    assert len(rows) == 8
    (root / 'hydration-ablation/summary.json').write_text(json.dumps(rows, indent=2))
    print('VALID', sum(b['valid'] for b in data['blocks']))

integrated=json.loads((root/'component-forwarding-integrated/http.json').read_text())
for runtime in ('node','bun'):
    for mode in ('string','stream'):
        print(runtime, mode, {v:round(mean(b['rps'] for b in integrated if b['runtime']==runtime and b['mode']==mode and b['variant']==v),2) for v in ('baseline','compiled','react')})
