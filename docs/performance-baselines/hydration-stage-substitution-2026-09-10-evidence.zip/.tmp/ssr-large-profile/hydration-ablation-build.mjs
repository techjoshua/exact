import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'hydration-ablation',{recursive:true});
const source=(await fs.readFile(root+'component-forwarding-integrated/server-entry.js','utf8')).replaceAll('\r\n','\n');
const ast=ts.createSourceFile('server-entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);const edits=[];let replaced=0;
function visit(n){
 if(ts.isFunctionDeclaration(n)&&n.name?.text==='serializeJson'){
  edits.push({start:n.body.getStart(ast),end:n.body.end,text:`{
   if(replacer)throw Error('Ablation fixture unexpectedly needs a replacer');
   const raw=auditStage==='json'?auditCache.raw:(++auditCounts.json,JSON.stringify(payload,replacer));
   const escaped=auditStage==='escape'?auditCache.escaped:(++auditCounts.escape,raw.replace(/</g,'\\\\u003C').replace(/\\u2028/g,'\\\\u2028').replace(/\\u2029/g,'\\\\u2029'));
   if(auditCache.raw===undefined){auditCache.raw=raw;auditCache.escaped=escaped;}
   return escaped;
  }`});replaced++;
 }
 if(ts.isFunctionDeclaration(n)&&n.name?.text==='renderHydrationScript'){
  const original=n.body.statements[0].expression.getText(ast);
  edits.push({start:n.body.getStart(ast),end:n.body.end,text:`{
   if(auditStage==='hydration')return auditCache.script;
   auditCounts.hydration++;
   const script=${original};if(auditCache.script===undefined)auditCache.script=script;return script;
  }`});replaced++;
 }
 if(ts.isFunctionDeclaration(n)&&n.name?.text==='renderHydrationScriptValue'){
  function inspect(v){
   if(ts.isVariableDeclaration(v)&&v.name.getText(ast)==='compacted'){
    const list=v.parent;edits.push({start:list.getStart(ast),end:list.getStart(ast)+5,text:'let'});replaced++;
   }
   if(ts.isVariableDeclaration(v)&&v.name.getText(ast)==='unsafePath'){
    edits.push({start:v.initializer.getStart(ast),end:v.initializer.end,text:`auditStage==='validation'?(compacted=auditCache.projected,undefined):(++auditCounts.validation,${v.initializer.getText(ast)})`});
    const statement=v.parent.parent;
    edits.push({start:statement.end,end:statement.end,text:"\nif(reactiveCollections!==undefined)throw Error('Ablation fixture unexpectedly encodes collections');if(auditCache.projected===undefined)auditCache.projected=compacted;"});replaced++;
   }
   ts.forEachChild(v,inspect);
  }
  inspect(n.body);
 }
 ts.forEachChild(n,visit);
}
visit(ast);if(replaced!==4)throw Error('Missing stage boundaries');
let output=source;for(const e of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,e.start)+e.text+output.slice(e.end);
output=`let auditStage='none',auditCache={},auditCounts={hydration:0,validation:0,json:0,escape:0};\n`+output+`
export function auditClearCounts(){auditCounts={hydration:0,validation:0,json:0,escape:0};}
export function auditReset(){auditStage='none';auditCache={};auditClearCounts();}
export function auditSelect(stage){if(!['none','validation','json','escape','hydration'].includes(stage))throw Error('Invalid ablation stage');if(stage!=='none'&&Object.keys(auditCache).length!==4)throw Error('Ablation cache not primed');auditStage=stage;}
export function auditRead(){return {stage:auditStage,counts:{...auditCounts},ready:Object.keys(auditCache).length===4};}
`;
await fs.writeFile(root+'hydration-ablation/server-entry.js',output);
let worker=(await fs.readFile(root+'http-invocation-trace/worker.mjs','utf8')).replaceAll('\r\n','\n');
worker="const auditModule=await import(pathToFileURL(process.env.COMPARISON_EXACT_SERVER_ENTRY).href);\n"+worker;
const start=worker.indexOf(" if (pathname === '/__exact-benchmark/audit-start')");
const end=worker.indexOf("\n\tif (pathname === '/__exact-benchmark/reset')",start);
if(start<0||end<0)throw Error('Missing controls');
worker=worker.slice(0,start)+`
 if(pathname==='/__exact-benchmark/audit-reset'){auditModule.auditReset();writeJson(response,{ok:true});return;}
 if(pathname==='/__exact-benchmark/audit-select'){auditModule.auditSelect(url.searchParams.get('stage'));writeJson(response,auditModule.auditRead());return;}
 if(pathname==='/__exact-benchmark/audit-start'){resetTelemetry();audit={};auditModule.auditClearCounts();writeJson(response,{cpu:process.cpuUsage()});return;}
 if(pathname==='/__exact-benchmark/audit-loop'){
  auditModule.auditReset();await participant.renderOnly(10000);auditModule.auditSelect(url.searchParams.get('stage'));
  audit={};resetTelemetry();auditModule.auditClearCounts();const result=await participant.renderOnly(10000);
  const snapshot={audit,responseBytes:result.responseBytes,ablation:auditModule.auditRead(),meanMs:result.samplesMs.reduce((a,b)=>a+b,0)/result.samplesMs.length};
  auditModule.auditReset();writeJson(response,snapshot);return;
 }
 if(pathname==='/__exact-benchmark/audit-stop'){writeJson(response,{cpu:process.cpuUsage(),telemetry:telemetry(),audit,ablation:auditModule.auditRead()});return;}
`+worker.slice(end);
await fs.writeFile(root+'hydration-ablation/worker.mjs',worker);
let runner=(await fs.readFile(root+'http-invocation-trace-run.mjs','utf8')).replaceAll('\r\n','\n').replaceAll('http-invocation-trace/','hydration-ablation/');
runner=runner.replace("kind:'paired-steady-state-cpu-profile'","kind:'within-worker-hydration-stage-substitution'");
runner=runner.replace("exact:'framework-comparison/participants/exact/dist-server/server-entry.js'","exact:root+'server-entry.js'");
runner=runner.replace("population?['react','exact']:['exact','react']","['exact']");
runner=runner.replace("for(const phase of ['http'])","for(const phase of population?['none','hydration','none','validation','none','escape','none','json','none']:['none','json','none','escape','none','validation','none','hydration','none'])");
runner=runner.replace("await startDrivers();const loopBefore=await controlSsrWorker(worker,'audit-loop');const before=await controlSsrWorker(worker,'audit-start');",`
   const loopBefore=await controlSsrWorker(worker,'audit-loop?stage='+phase);
   const normalResponse=await fetch(worker.url+'?__benchmarkPreloaded=true');assert.equal(normalResponse.status,200);const normalBody=Buffer.from(await normalResponse.arrayBuffer());assert.deepEqual(normalBody,body);
   await controlSsrWorker(worker,'audit-select?stage='+phase);
   const selectedResponse=await fetch(worker.url+'?__benchmarkPreloaded=true');assert.equal(selectedResponse.status,200);assert.deepEqual(Buffer.from(await selectedResponse.arrayBuffer()),body);
   await startDrivers();const before=await controlSsrWorker(worker,'audit-start');`);
runner=runner.replace('durationMs:5000','durationMs:3000').replace("const loopAfter=await controlSsrWorker(worker,'audit-loop');","const loopAfter=await controlSsrWorker(worker,'audit-loop?stage='+phase);");
runner=runner.replace('report.complete=true;',"assert.equal(report.blocks.length,18);report.complete=true;");
await fs.writeFile(root+'hydration-ablation-run.mjs',runner);
console.log({replaced});
