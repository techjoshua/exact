import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'writer-start',{recursive:true});
const source=(await fs.readFile(root+'component-forwarding-integrated/server-entry.js','utf8')).replaceAll('\r\n','\n');
const ast=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const edits=[];let writers=0,hooks=0;
function visit(n){
 if(ts.isPropertyAssignment(n)&&n.name.getText(ast)==='ssr'&&ts.isFunctionExpression(n.initializer)){
  const fn=n.initializer,statements=fn.body.statements;
  if(statements.length!==4||!ts.isVariableStatement(statements[0])||!ts.isIfStatement(statements[1])||!ts.isSwitchStatement(statements[2])||!ts.isBlock(statements[3]))throw Error('Unexpected writer structure');
  const preparation=statements[1].elseStatement;
  if(!preparation||!ts.isBlock(preparation))throw Error('Missing preparation');
  const linear=statements[2].caseBlock.clauses.flatMap(c=>c.statements.map(s=>s.getText(ast))).join('\n').replaceAll('break;','break auditInitial;');
  const tail=statements[3];
  if(tail.statements.length!==2||!ts.isVariableStatement(tail.statements[0]))throw Error('Unexpected suspension');
  const saved=tail.statements[0].getText(ast);
  const hot=`function auditInitialWriter(${fn.parameters.map(p=>p.getText(ast)).join(',')}) {
   if(__exactFrame)throw Error('Initial writer received a resume frame');
   ${statements[0].getText(ast)}
   ${preparation.getText(ast)}
   auditInitial: {${linear}}
   ${saved}
   return auditResumeWriter(__exactPending,__exactSaved);
  }`;
  edits.push({start:fn.getStart(ast),end:fn.end,text:`Object.assign(${fn.getText(ast)},{auditInitial:${hot}})`});writers++;
 }
 if(ts.isFunctionDeclaration(n)&&n.name?.text==='invokePreparedSsrProgram'){
  edits.push({start:n.body.getStart(ast),end:n.body.end,text:`{
   const writer=invocation.program.ssr;
   if(auditStage==='initial'&&writer.auditInitial){++auditCounts.initial;return writer.auditInitial(generatedSsrOperations,output.context,invocation,output);}
   ++auditCounts.normal;return writer(generatedSsrOperations,output.context,invocation,output);
  }`});hooks++;
 }
 ts.forEachChild(n,visit);
}visit(ast);
if(writers!==18||hooks!==1)throw Error('Unexpected writer count '+writers);
let output=source;for(const e of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,e.start)+e.text+output.slice(e.end);
output=`let auditStage='none',auditCounts={normal:0,initial:0,resume:0};\n`+output+`
function auditResumeWriter(pending,saved){
 ++auditCounts.resume;
 return pending.then(value=>{saved[5]=value;return saved[2].program.ssr(saved[0],saved[1],saved[2],saved[3],saved);});
}
export function auditClearCounts(){auditCounts={normal:0,initial:0,resume:0};}
export function auditReset(){auditStage='none';auditClearCounts();}
export function auditSelect(stage){if(!['none','initial'].includes(stage))throw Error('Invalid stage');auditStage=stage;}
export function auditRead(){return {stage:auditStage,counts:{...auditCounts},ready:true};}
`;
await fs.writeFile(root+'writer-start/server-entry.js',output);
await fs.writeFile(root+'writer-start/sites.json',JSON.stringify({writers,hooks,originalBytes:source.length,prototypeBytes:output.length}));
await fs.copyFile(root+'hydration-ablation/worker.mjs',root+'writer-start/worker.mjs');
let runner=(await fs.readFile(root+'tree-ablation-run.mjs','utf8')).replaceAll('tree-ablation/','writer-start/').replaceAll('within-worker-tree-substitution','within-worker-initial-writer').replaceAll("'none','tree','none'","'none','initial','none'");
await fs.writeFile(root+'writer-start-run.mjs',runner);
let check=(await fs.readFile(root+'tree-ablation-check.mjs','utf8')).replaceAll('tree-ablation/','writer-start/').replace("['none','tree']","['none','initial']").replace("assert.equal(snapshot.counts.tree,stage==='tree'?0:1);","assert.equal(snapshot.counts.normal+snapshot.counts.initial,24);assert.equal(snapshot.counts.initial>0,stage==='initial');assert.equal(snapshot.counts.resume,0);");
await fs.writeFile(root+'writer-start-check.mjs',check);
let pressure=(await fs.readFile(root+'component-forwarding-integrated-pressure.mjs','utf8'))
 .replace("['conditional-emission','component-forwarding-integrated']","['component-forwarding-integrated','writer-start']")
 .replaceAll("root+'component-forwarding-integrated/'","root+'writer-start/'")
 .replaceAll('auditReset(failure)','pressureReset(failure)').replaceAll('auditRead(){return auditWrites','pressureRead(){return auditWrites')
 .replace('mod.auditReset(fail);','mod.pressureReset(fail);if(mod.auditSelect){mod.auditReset();mod.auditSelect(\'initial\');}')
 .replaceAll('mod.auditRead()','mod.pressureRead()');
await fs.writeFile(root+'writer-start-pressure.mjs',pressure);
console.log({writers,hooks});
