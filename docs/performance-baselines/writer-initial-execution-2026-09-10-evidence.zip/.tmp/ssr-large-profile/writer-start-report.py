import hashlib
import json
import zipfile
from pathlib import Path
from statistics import mean

base=Path('.tmp/ssr-large-profile');folder=base/'writer-start'
data=json.loads((folder/'capture.json').read_text());assert data['complete']
rows=[]
for population in (0,1):
    blocks=[b for b in data['blocks'] if b['population']==population]
    assert [b['phase'] for b in blocks]==['none','initial','none']
    controls=[blocks[0],blocks[2]];candidate=blocks[1]
    for b in blocks:
        counts=b['after']['ablation']['counts']
        assert (counts['initial']>0)==(b['phase']=='initial')
        assert counts['resume']==0
    def render(b):
        s=b['after']['telemetry']['statistics']['renderMs'];return s['sum']/s['count']*1000
    def loop(b):return mean(b[k]['meanMs'] for k in ('loopBefore','loopAfter'))*1000
    normal=mean(b['rps'] for b in controls)
    rows.append(dict(population=population+1,controlsRps=[b['rps'] for b in controls],normalRps=normal,initialRps=candidate['rps'],gainPct=(candidate['rps']/normal-1)*100,normalHttpUs=mean(render(b) for b in controls),initialHttpUs=render(candidate),normalLoopUs=mean(loop(b) for b in controls),initialLoopUs=loop(candidate)))
valid=sum(b['valid'] for b in data['blocks']);errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages']);assert errors==0
(folder/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid,errors=errors),indent=2))
report=Path('docs/performance-baselines/writer-initial-execution-2026-09-10.md')
lines=['# Straight-line initial writer execution, 2026-09-10','',
'Hypothesis: separating normal synchronous execution from restoration and switch dispatch may improve throughput by roughly 3 to 8 percent. This prototype preserves the existing renderer and sink API. It changes generated writer structure, not application content or the React baseline.', '',
'An AST transform adds a straight-line initial function to each of 18 resumable writer definitions. The seven existing arrow writers remain unchanged. Initial execution performs the original preparation and operation sequence in a labeled block. Every original sink readiness check and pending-child check remains. Actual suspension creates the original saved frame and calls the original resumable writer through one shared Promise helper. That original writer handles subsequent resumptions. No render-mode branch is introduced into the sink API.', '',
'The fixed fixture executes 18 transformed and six unchanged writer invocations. Both selections are present in the same worker; the invocation boundary selects the treatment. Duplicated generated code and selection overhead are part of this prototype. A production implementation would need compiler integration and broader semantics coverage before acceptance.', '',
'Four normal/escaped full-document parity cases pass. Twelve pressure/failure checks pass on Node and twelve on Bun using the portable artifact. These compare exact writes and errors against the retained build, including a pending sink after every string write and failures at selected write positions. They are focused correctness checks, not a complete compiler or browser validation.', '',
'Two fresh production Node 26.8.1 workers run normal/initial/normal, with ten seconds HTTP warmup and five-second blocks. Two fresh drivers each hold 16 requests in flight. Controls are averaged within each worker. Before/after isolated loops warm and measure 10,000 renders. Workstation load can vary; individual controls are shown to expose drift.', '',
'| Worker | Normal controls RPS | Initial RPS | Change vs control mean | HTTP us, normal / initial | Isolated us, normal / initial |',
'| --- | ---: | ---: | ---: | ---: | ---: |']
for r in rows:
    lines.append(f"| {r['population']} | {r['controlsRps'][0]:,.0f} / {r['controlsRps'][1]:,.0f} | {r['initialRps']:,.0f} | {r['gainPct']:+.2f}% | {r['normalHttpUs']:.2f} / {r['initialHttpUs']:.2f} | {r['normalLoopUs']:.2f} / {r['initialLoopUs']:.2f} |")
lines+=['',f'All {valid:,} measured responses passed complete 4,672-byte document validation, with zero errors. Runtime counters confirm treatment selection and zero suspension in measured string blocks. Artifact and adapter hash guards pass. No production change or new benchmark baseline is claimed.', '',
'Raw blocks, summaries, transformation/check/runner scripts, pressure artifacts and SHA-256 inventory are preserved in the adjacent evidence archive.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[report,Path('.tmp/positional-leaves/data.json')]+[base/n for n in ('writer-start-build.mjs','writer-start-check.mjs','writer-start-run.mjs','writer-start-pressure.mjs','writer-start-report.py','tree-ablation-run.mjs','tree-ablation-check.mjs','hydration-ablation/worker.mjs','component-forwarding-integrated/server-entry.js','component-forwarding-integrated-pressure.mjs')]
files=sorted(set(p for p in files if p.is_file()));archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps(rows,indent=2));print(valid,'valid;',len(files),'verified files')
