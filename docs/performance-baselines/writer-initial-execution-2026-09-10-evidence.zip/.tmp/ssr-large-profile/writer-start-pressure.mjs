import fs from 'node:fs/promises';
import ts from 'typescript';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const root='.tmp/ssr-large-profile/';const modules=[];
for(const name of ['component-forwarding-integrated','writer-start']){
 let source=await fs.readFile(root+name+'/server-entry.js','utf8');
 const ast=ts.createSourceFile('server-entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
 let cls;function findClass(n){if(ts.isVariableDeclaration(n)&&n.name.getText(ast)==='StringProgramSink'&&ts.isClassExpression(n.initializer))cls=n.initializer;ts.forEachChild(n,findClass);}findClass(ast);
 if(!cls)throw Error('Missing sink');
 const write=cls.members.find(n=>n.name?.getText(ast)==='write');const ready=cls.members.find(n=>n.name?.getText(ast)==='ready');
 const edits=[{start:ready.body.getStart(ast),end:ready.body.end,text:'{return this.auditPending;}'},{start:write.body.getStart(ast)+1,end:write.body.getStart(ast)+1,text:"if(this.auditPending)throw Error('write-before-drain');"},{start:write.body.end-1,end:write.body.end-1,text:"const ordinal=++auditWriteCount;auditWrites.push(html);this.auditPending=Promise.resolve().then(()=>{this.auditPending=undefined;if(ordinal===auditFailure)throw Error('audit-drain-failed');});"}];
 for(const e of edits.sort((a,b)=>b.start-a.start))source=source.slice(0,e.start)+e.text+source.slice(e.end);
 source='let auditWrites=[],auditWriteCount=0,auditFailure=0;\n'+source+'\nexport function pressureReset(failure){auditWrites=[];auditWriteCount=0;auditFailure=failure;}\nexport function pressureRead(){return auditWrites;}\n';
 const file=root+'writer-start/'+name+'-pressure.js';await fs.writeFile(file,source);modules.push(await import(pathToFileURL(resolve(file))));
}
const fixture=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));
const options={clientTags:'<script type="module" src="/assets/app.js"></script><link rel="stylesheet" href="/assets/app.css">'};
const rows=[];
for(const mode of ['string','stream'])for(const size of ['small','large'])for(const fail of mode==='string'?[0,1,3,15,35]:[0]){
 const data=structuredClone(fixture);if(size==='large')data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
 const results=[];
 for(const mod of modules){mod.pressureReset(fail);if(mod.auditSelect){mod.auditReset();mod.auditSelect('initial');}let html,error;try{html=mode==='string'?await mod.renderParticipant(data,'/incidents/inc-101',options):await new Response(await mod.renderParticipantStream(data,'/incidents/inc-101',options)).text();}catch(e){error={name:e.name,message:e.message};}results.push({html,error,writes:mod.pressureRead()});}
 assert.deepEqual(results[1],results[0]);assert.ok(results[0].writes.length>0);
 if(fail)assert.equal(results[0].error?.message,'audit-drain-failed');
 rows.push({mode,size,fail,writes:results[0].writes.length,error:results[0].error});
}
const runtime=process.versions.bun?'bun':'node';await fs.writeFile(root+'writer-start/'+runtime+'-pressure-checks.json',JSON.stringify(rows,null,2));console.log({runtime,matched:rows.length});
