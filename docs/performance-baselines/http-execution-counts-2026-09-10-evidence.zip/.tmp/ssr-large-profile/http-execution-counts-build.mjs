import fs from 'node:fs/promises';import ts from 'typescript';
const root='.tmp/ssr-large-profile/http-execution-counts/';await fs.mkdir(root,{recursive:true});
const source=await fs.readFile('framework-comparison/participants/exact/dist-server/server-entry.js','utf8');
const ast=ts.createSourceFile('server-entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);const edits=[],sites=[];
function visit(node){
 if(ts.isFunctionLike(node)&&node.body){
  const id=sites.length;const line=ast.getLineAndCharacterOfPosition(node.getStart(ast)).line+1;
  const name=node.name?.getText(ast)??(ts.isVariableDeclaration(node.parent)?node.parent.name.getText(ast):'<anonymous>');sites.push({id,name,line,kind:ts.SyntaxKind[node.kind]});
  if(ts.isBlock(node.body)){
   let pos=node.body.getStart(ast)+1;
   for(const statement of node.body.statements){if(ts.isExpressionStatement(statement)&&ts.isStringLiteral(statement.expression))pos=statement.end;else break;}
   edits.push({pos,text:`;__auditCounts[${id}]++;`});
  }else{edits.push({pos:node.body.getStart(ast),text:`{__auditCounts[${id}]++;return (`},{pos:node.body.end,text:');}'});}
 }
 ts.forEachChild(node,visit);
}
visit(ast);let output=source;for(const e of edits.sort((a,b)=>b.pos-a.pos))output=output.slice(0,e.pos)+e.text+output.slice(e.pos);
output=`let __auditCounts=new Float64Array(${sites.length});\n`+output+'\nexport function auditResetEntries(){__auditCounts.fill(0);}\nexport function auditReadEntries(){return Array.from(__auditCounts);}\n';
await fs.writeFile(root+'server-entry.js',output);await fs.writeFile(root+'sites.json',JSON.stringify(sites,null,2));console.log('Instrumented function entry sites:',sites.length);
