import fs from 'node:fs/promises';
const root='.tmp/ssr-large-profile/';
const pressure=await fs.readFile(root+'stateful-scope-pressure.mjs','utf8');
await fs.writeFile(root+'packed-publication-pressure.mjs',pressure.replaceAll('stateful-scope','packed-publication'));
