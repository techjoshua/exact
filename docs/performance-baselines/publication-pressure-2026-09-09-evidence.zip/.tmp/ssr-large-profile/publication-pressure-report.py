import pathlib,json,hashlib,zipfile
d=pathlib.Path('.tmp/ssr-large-profile')
for runtime in ['node','bun']:
 result=json.loads((d/f'publication-pressure-{runtime}.json').read_text(encoding='utf-8'))
 assert len(result['rows'])==3 and result['unguardedCapacityPause']=='rejected as expected'
 assert all(sorted(row['disposedIndices'])==[1,2] for row in result['rows'])
files=[d/n for n in ['publication-pressure-sink.mjs','publication-byte-sink.mjs','publication-pressure-build.mjs','publication-pressure-entry.mjs','publication-pressure-audit.mjs','publication-pressure-report.py','publication-pressure-node.json','publication-pressure-bun.json','direct-publication/entry.mjs','direct-publication/fixture.mjs']]
files += [pathlib.Path(n) for n in ['docs/performance-baselines/publication-pressure-2026-09-09.md','packages/ssr/src/render/output-buffer.ts']]
manifest={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=pathlib.Path('docs/performance-baselines/publication-pressure-2026-09-09-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p).replace('\\','/'))
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified six drain/lifecycle cases, two capacity probes, and archive hashes.')
