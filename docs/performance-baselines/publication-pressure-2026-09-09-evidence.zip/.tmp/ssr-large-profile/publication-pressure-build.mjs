import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
let code=readFileSync(dir+'direct-publication/entry.mjs','utf8');
const before="if(host==='head')output.sink.flush?.('head');\n  return value;";
if(code.split(before).length!==2)throw Error('Missing head publication');
code=code.replace(before,"const drained=host==='head'?output.sink.flush?.('head'):undefined;\n  return drained instanceof Promise?drained.then(()=>value):value;");
writeFileSync(dir+'publication-pressure-entry.mjs',code);
