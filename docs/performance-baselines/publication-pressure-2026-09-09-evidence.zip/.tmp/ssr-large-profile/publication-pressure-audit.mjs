import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {PublicationPressureSink} from './publication-pressure-sink.mjs';
import * as runtime from './publication-pressure-entry.mjs';
import * as fixture from './direct-publication/fixture.mjs';
const rows=[];
for(const outcome of ['success','abort','transport-error']){
 fixture.reset();const events=[];let release,reject;
 const transport=new Promise((resolve,fail)=>{release=resolve;reject=fail;});
 const controller=new AbortController(),options={markers:false,signal:controller.signal};
 const sink=new PublicationPressureSink((bytes,reason)=>{
  events.push({reason,text:new TextDecoder().decode(bytes)});
  return events.length===1?transport:undefined;
 },{threshold:8192,maxBytes:1024,signal:controller.signal});
 const context=runtime.createSsrContext(options);context.experimentalSink=sink;
 const target=new runtime.SsrOperationTarget(context,undefined,options,false,runtime.renderChildren);
 const refs=[1,2].map(index=>runtime.createPreparedServerComponentReference(fixture.ScheduledChild,{index}));
 const head={program:{ssrHost:'head',ssr(ops,ctx,invocation,out){ops.static(out,'<head><link rel="stylesheet" href="/app.css"></head>');return out;}}};
 const parent=runtime.createPreparedServerRenderProgram(runtime.prepareCompiledRenderProgram({version:1,id:'pressured-root',namespace:'html',ssrHost:'html',async ssr(ops,ctx,invocation,out){
  out.preparation=out.prepareReferences(refs);ops.static(out,'<html>');
  await runtime.renderDirectWriter(ctx,head,()=>{throw Error('unexpected child');});
  ops.static(out,'<body>');
  await ops.component(ctx,out,refs[0],'1',0,true);
  await ops.component(ctx,out,refs[1],'2',0,true);
  ops.static(out,'</body></html>');return out;
 }}),[]);
 const rendering=Promise.resolve(target.renderPreparedServerProgram(parent));
 let timer;
 try{
  for(let i=0;i<15;i++)await Promise.resolve();
  assert.equal(fixture.starts,2);assert.equal(sink.blocked,true);
  assert.deepEqual(events,[{reason:'head',text:'<!doctype html><html><head><link rel="stylesheet" href="/app.css"></head>'}]);
  const failure=new Error('transport rejected head');
  if(outcome==='abort')controller.abort();
  else if(outcome==='transport-error')reject(failure);
  else{fixture.settle();release();}
  const completed=Promise.race([rendering,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('renderer hung')),2000);})]);
  if(outcome==='success'){
   await completed;await sink.finish();
   assert.equal(events.map(e=>e.text).join(''),'<!doctype html><html><head><link rel="stylesheet" href="/app.css"></head><body><strong>Ready 1</strong><strong>Ready 2</strong></body></html>');
  }else{
   await assert.rejects(completed,error=>outcome==='abort'?error.name==='AbortError':error===failure);
   assert.equal(events.length,1);assert.equal(sink.pendingCharacters,0);
  }
  assert.deepEqual([...fixture.disposedIndices].sort(),[1,2]);assert.deepEqual(context.hostStack,[]);
  rows.push({outcome,events,disposedIndices:fixture.disposedIndices});
 }finally{clearTimeout(timer);fixture.settle();release();sink.destroy();}
}
// Capacity-triggered pauses need compiler guards after every output operation, not only the head.
const capacitySink=new PublicationPressureSink(()=>new Promise(()=>{}),{threshold:1});
const context=runtime.createSsrContext({markers:false});context.experimentalSink=capacitySink;
assert.throws(()=>runtime.renderDirectWriter(context,{program:{ssr(ops,ctx,invocation,out){ops.static(out,'a');ops.static(out,'b');return out;}}},()=>{}),/continued through backpressure/);
capacitySink.destroy();
writeFileSync('.tmp/ssr-large-profile/publication-pressure-'+(process.versions.bun?'bun':'node')+'.json',JSON.stringify({rows,unguardedCapacityPause:'rejected as expected'},null,2));
console.log(JSON.stringify({rows,unguardedCapacityPause:'rejected as expected'}));
