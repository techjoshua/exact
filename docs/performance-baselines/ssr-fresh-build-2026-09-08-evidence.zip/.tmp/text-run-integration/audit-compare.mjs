import {readFile,writeFile,readdir} from 'node:fs/promises';
import assert from 'node:assert/strict';
const root='.tmp/text-run-integration';
const manifests=await Promise.all(['marked','markerless'].map(async name=>JSON.parse(await readFile(`${root}/fresh-${name}/manifest.json`,'utf8'))));
for(const path of Object.keys(manifests[0].files)) if(!path.includes('packages/dom/')) assert.deepEqual(manifests[0].files[path],manifests[1].files[path],path);
const entries=await Promise.all(['marked','markerless'].map(name=>readFile(`${root}/fresh-${name}/dist-server/server-entry.js`,'utf8')));
const lines=entries.map(s=>s.split('\n'));
assert.equal(lines[0].length,lines[1].length);
const changes=[];
for(let i=0;i<lines[0].length;i++) if(lines[0][i]!==lines[1][i]) changes.push({line:i+1,marked:lines[0][i],markerless:lines[1][i]});
assert.equal(changes.length,2);
for(const change of changes){assert.ok(change.marked.includes('__exactSsr.text('));assert.equal(change.marked.replace(');',', true);'),change.markerless);}
const assets=await readdir(`${root}/fresh-markerless/dist/assets`);
const client=await readFile(`${root}/fresh-markerless/dist/assets/${assets.find(p=>p.endsWith('.js'))}`,'utf8');
assert.ok(client.includes('.splitText('));
assert.ok(client.includes('[8,['));
await writeFile(`${root}/fresh-build-audit.json`,JSON.stringify({manifests,changes,clientHasSplitText:true,clientHasTextRunClaim:true},null,2));
console.log({serverChangedLines:changes,clientHasSplitText:true,clientHasTextRunClaim:true});
