import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import * as before from './fresh-marked/dist-server/server-entry.js';
import * as after from './fresh-markerless/dist-server/server-entry.js';
import * as react from '../../framework-comparison/participants/react/dist-server/server-entry.js';
import {comparisonDocumentHtml} from '../../framework-comparison/src/ssr-response-breakdown.mjs';
const data=JSON.parse(await readFile('.tmp/ssr-paired-profile/data.json','utf8'));
const [prefix,suffix]=comparisonDocumentHtml('exact','__BODY__',data).split('__BODY__');
const exact=entry=>()=>{let body='';entry.renderParticipantToSink(data,'/incidents/inc-101',value=>body+=value,Buffer.byteLength);return prefix+body+suffix;};
const operations={before:exact(before),after:exact(after),react:()=>comparisonDocumentHtml('react',react.renderParticipant(data,'/incidents/inc-101'),data)};
const html=Object.fromEntries(Object.entries(operations).map(([name,op])=>[name,op()]));
const strip=s=>s.replace(/<!--[\s\S]*?-->/g,'');

assert.equal(Buffer.byteLength(html.before)-Buffer.byteLength(html.after),126);
assert.equal(strip(html.after),strip(html.before));

const samples=[];let consumed=0;const names=Object.keys(operations);
for(const op of Object.values(operations))for(let i=0;i<10000;i++)consumed+=op().length;
for(let round=0;round<24;round++)for(const name of round%2?[...names].reverse():names){const start=performance.now();for(let i=0;i<5000;i++)consumed+=operations[name]().length;samples.push({name,round,microseconds:(performance.now()-start)/5});}
const means=Object.fromEntries(names.map(name=>[name,samples.filter(s=>s.name===name).reduce((n,s)=>n+s.microseconds,0)/24]));
const bytes=Object.fromEntries(names.map(name=>[name,Buffer.byteLength(html[name])]));
console.log({means,bytes});
await writeFile('.tmp/text-run-integration/render-fresh-'+(globalThis.Bun?'bun':'node')+(process.env.TEXT_REPEAT?'-repeat':'')+'.json',JSON.stringify({means,bytes,samples,consumed},null,2));
