import { readFile, writeFile, mkdir, cp } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { transform } from 'esbuild';
import assert from 'node:assert/strict';
const variant = process.argv[2];
assert.ok(['marked','markerless'].includes(variant));
const root = `.tmp/text-run-integration/fresh-${variant}`;
await mkdir(root,{recursive:true});
for (const dir of ['dist','dist-server','dist-bun-server']) await cp(`framework-comparison/participants/exact/${dir}`,`${root}/${dir}`,{recursive:true});
const paths = ['packages/core/dist/server/render-program.js','packages/dom/dist/client/renderer/render-program.js','packages/ssr/dist/server/render/sync-render-program.js','packages/hydrate/dist/index.js','framework-adapters/vite-plugin/dist/index.js','framework-comparison/participants/react/dist-server/server-entry.js'];
const manifest = {variant,createdAt:new Date().toISOString(),files:{}};
for(const path of paths){const bytes=await readFile(path);manifest.files[path]={bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')};}
const entry=await readFile(`${root}/dist-server/server-entry.js`,'utf8');
const candidate=await readFile(`.tmp/text-run-integration/direct-${variant}-entry.js`,'utf8');
const minify=async code=>(await transform(code,{minify:true,legalComments:'none'})).code;
manifest.matchesEarlierDirectCandidate=(await minify(entry))===(await minify(candidate));
manifest.entrySha256=createHash('sha256').update(entry).digest('hex');
await writeFile(`${root}/manifest.json`,JSON.stringify(manifest,null,2));
console.log(manifest);
