import fs from 'node:fs/promises';import assert from 'node:assert/strict';import {resolve} from 'node:path';import {pathToFileURL} from 'node:url';
const root='.tmp/ssr-large-profile/',out=root+'application-hydration/';await fs.mkdir(out,{recursive:true});
for(const name of ['server-entry.js','bun-server-entry.js']){
 let source=await fs.readFile(root+'direct-execution-integrated/'+name,'utf8');
 for(const fn of ['rootPropsOptions','rootPropsForCapture','rootComponentIdentity']){
  const start=source.indexOf('function '+fn+'('),end=source.indexOf('\n}',start)+2;assert.ok(start>0&&end>start);
  const body=source.slice(start,end);assert.ok(body.includes('readServerComponentReference(root)'));
  let replacement=body.replaceAll('readServerComponentReference(root)','auditPublicationReference(root)');
  if(fn==='rootPropsOptions')replacement=replacement.replace('if (!options.publishRootProps) return options;','if (!options.publishRootProps) return options;\n if(readServerComponentReference(root)?.contract.artifact.id===Document[Symbol.for("@exactjs/component")])options={...options,markerlessRoot:true};');
  source=source.slice(0,start)+replacement+source.slice(end);
 }
 source+='\nfunction auditPublicationReference(root){const receipt=readServerComponentReference(root);if(receipt?.contract.artifact.id!==Document[Symbol.for("@exactjs/component")])return receipt;return {contract:readPreparedExactComponentContract(IncidentApp),props:{initialData:receipt.props.initialData,path:receipt.props.path}};}\n';
 await fs.writeFile(out+name,source);
}
const modules=await Promise.all([root+'direct-execution-integrated/server-entry.js',out+'server-entry.js'].map(p=>import(pathToFileURL(resolve(p)))));
const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
const rows=[];
for(const mode of ['string','stream'])for(let request=0;request<3;request++){
 const data=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));data.incidents[1].title='Publication '+request+' <safe>';
 const html=await Promise.all(modules.map(m=>mode==='string'?m.renderParticipant(data,'/incidents/inc-101',options):new Response(m.renderParticipantStream(data,'/incidents/inc-101',options)).text()));
 const expression=/<script type="application\/json" id="__exact_hydration">([\s\S]*?)<\/script>/;
 assert.equal(html[0].replace(expression,''),html[1].replace(expression,''));
 const payload=html[1].match(expression)[1];assert.ok(JSON.stringify(JSON.parse(payload)).includes(data.incidents[1].title));assert.ok(!payload.includes('/assets/'));
 rows.push({mode,request,oldBytes:Buffer.byteLength(html[0].match(expression)[1]),newBytes:Buffer.byteLength(payload),documentBytes:Buffer.byteLength(html[1])});
}
await fs.writeFile(out+'verification.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));
