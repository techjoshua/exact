import fs from 'node:fs/promises';import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/node-order-control/';const rows=JSON.parse(await fs.readFile(root+'http.json','utf8'));assert.equal(rows.length,18);
const exact=rows.filter(r=>r.variant!=='react');assert.equal(new Set(exact.map(r=>r.artifactSha256)).size,1);assert.equal(new Set(exact.map(r=>r.identity.hash)).size,1);
const rps=Object.fromEntries(['baseline','compiled','react'].map(v=>[v,rows.filter(r=>r.variant===v).reduce((n,r)=>n+r.rps,0)/6]));
const pairs=Array.from({length:6},(_,block)=>{const a=rows.find(r=>r.block===block&&r.variant==='baseline').rps,b=rows.find(r=>r.block===block&&r.variant==='compiled').rps;return {block,a,b,changePercent:(b/a-1)*100};});
const result={rps,changePercent:(rps.compiled/rps.baseline-1)*100,pairs,valid:rows.reduce((n,r)=>n+r.results.reduce((n,d)=>n+d.stages[0].valid,0),0),errors:rows.reduce((n,r)=>n+r.results.reduce((n,d)=>n+d.stages[0].errors,0),0)};await fs.writeFile(root+'summary.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
