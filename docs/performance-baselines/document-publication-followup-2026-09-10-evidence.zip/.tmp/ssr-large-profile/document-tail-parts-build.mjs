import fs from 'node:fs/promises';import assert from 'node:assert/strict';import {resolve} from 'node:path';import {pathToFileURL} from 'node:url';
const root='.tmp/ssr-large-profile/',out=root+'document-tail-parts/';await fs.mkdir(out,{recursive:true});
for(const name of ['server-entry.js','bun-server-entry.js']){
 let source=await fs.readFile(root+'direct-execution-integrated/'+name,'utf8');
 const start=source.indexOf('var StringProgramSink = class {'),end=source.indexOf('\n};',start)+3;assert.ok(start>0&&end>start);
 let sink=source.slice(start,end).replace('value = "";','value = "";\n bodyPrefix;\n prefixLength=0;');
 sink=sink.replace('this.value.length + html.length','this.prefixLength + this.value.length + html.length').replace('let characters = this.value.length;','let characters = this.prefixLength + this.value.length;');
 sink=sink.replace('const html = hints ? hints + this.value : this.value;','const parts=this.bodyPrefix===undefined?[hints? hints+this.value:this.value]:[hints? hints+this.bodyPrefix:this.bodyPrefix,this.value];');
 sink=sink.replace('utf8ByteLength(html)','utf8ByteLength(parts.join(""))').replace('return html;','return parts;');
 sink=sink.replace('destroy() {','beginDocumentTail(){if(this.bodyPrefix!==undefined)throw new Error("Duplicate document tail");this.bodyPrefix=this.value;this.prefixLength=this.value.length;this.value="";}\n destroy() {\n this.bodyPrefix=undefined;this.prefixLength=0;');
 source=source.slice(0,start)+sink+source.slice(end);
 source=source.replace('const chunks = [sink.finish(context.reactResourceHints)];','const chunks = sink.finish(context.reactResourceHints);');
 const close='__exactSsr.static(__exactOutput, "</body>")';assert.ok(source.includes(close));
 source=source.replaceAll(close,'(__exactOutput.sink.beginDocumentTail?.(), '+close+')');
 source=source.replace('html: chunks.length === 1 ? chunks[0] : chunks.join("")','html: chunks.length === 1 ? chunks[0] : chunks.length===2?chunks[0]+chunks[1]:chunks.join("")');
 const augment='function augmentChunkedBody(chunks, hydrationScript) {';assert.ok(source.includes(augment));
 source=source.replace(augment,augment+'\n if(chunks.length===2&&chunks[1]==="</body></html>")return hydrationScript?[chunks[0],"<!--exact:framework-body:start-->"+hydrationScript+"<!--exact:framework-body:end-->",chunks[1]]:chunks;');
 await fs.writeFile(out+name,source);
}
const modules=await Promise.all([root+'direct-execution-integrated/server-entry.js',out+'server-entry.js'].map(p=>import(pathToFileURL(resolve(p)))));
const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
const rows=[];
for(const mode of ['string','stream'])for(let request=0;request<3;request++){
 const data=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));data.incidents[1].title='Tail '+request+' <safe> 🚀';
 const html=await Promise.all(modules.map(m=>mode==='string'?m.renderParticipant(data,'/incidents/inc-101',options):new Response(m.renderParticipantStream(data,'/incidents/inc-101',options)).text()));assert.equal(html[0],html[1]);rows.push({mode,request,bytes:Buffer.byteLength(html[1])});
}
await fs.writeFile(out+'verification.json',JSON.stringify(rows,null,2));console.log('Six byte-identical changing Unicode request checks passed.');
