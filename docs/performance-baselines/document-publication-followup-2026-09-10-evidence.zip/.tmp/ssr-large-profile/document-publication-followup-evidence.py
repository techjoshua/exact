from pathlib import Path
import hashlib,json,zipfile
archive=Path('docs/performance-baselines/document-publication-followup-2026-09-10-evidence.zip')
assert not archive.exists()
files=[]
for name in ['application-hydration','document-tail-parts','node-order-control']:
 files.append(Path('docs/performance-baselines')/(name+'-2026-09-10.md'))
 files += list(Path('.tmp/ssr-large-profile').glob(name+'-*.mjs'))
 files += [p for p in (Path('.tmp/ssr-large-profile')/name).rglob('*') if p.is_file()]
files += [Path('.tmp/ssr-large-profile/direct-execution-integrated')/n for n in ['server-entry.js','bun-server-entry.js']]
files += [Path('.tmp/ssr-large-profile/flat-invocation-large-worker.mjs'),Path('.tmp/positional-leaves/data.json'),Path(__file__)]
files += [Path('framework-comparison/participants/react')/n for n in ['dist-server/server-entry.js','dist-bun-server/bun-server-entry.js']]
files=sorted(set(p.resolve().relative_to(Path.cwd()) for p in files))
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p,digest in manifest.items():assert hashlib.sha256(z.read(p)).hexdigest()==digest
assert Path('framework-comparison/participants/exact/src/main.tsx').read_bytes()==Path('.tmp/ssr-large-profile/application-hydration/main.original.tsx').read_bytes()
print(f'Verified {len(manifest)} archived files and restored browser source: {archive}')
