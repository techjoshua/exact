import {spawn} from 'node:child_process';
import {writeFile} from 'node:fs/promises';
const results=[];
for(const [round,variant] of ['current','slot-only','sync-stream'].entries()){
 const output=`.tmp/node-string-investigation/recovery-stream-${round}-${variant}.json`;
 console.log('START',round,variant);
 await new Promise((resolve,reject)=>{const child=spawn(process.execPath,['.tmp/node-string-investigation/control-capacity.mjs','.tmp/node-string-investigation/recovery-preloaded-plan.json',output,'node'],{env:{...process.env,NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:'stream',CONTROL_EXACT_ENTRY:`.tmp/node-string-investigation/${variant}.mjs`},stdio:'inherit'});child.once('error',reject);child.once('exit',code=>code===0?resolve():reject(Error(String(code))));});
 results.push({round,variant,output});await writeFile('.tmp/node-string-investigation/recovery-stream-index.json',JSON.stringify(results,null,2));
}
