const documentHydrationPresence = Symbol('ssrDocumentHydrationPresence');
const presentDescriptor = { value: true };
const absentDescriptor = { value: false };

type DocumentHydrationChunks = readonly string[] & {
	[documentHydrationPresence]?: boolean;
};

/** Records a completed string sink's slot knowledge without retaining its mutable request context. */
export function recordDocumentHydrationSlot(chunks: string[], present: boolean): void {
	Object.defineProperty(
		chunks,
		documentHydrationPresence,
		present ? presentDescriptor : absentDescriptor
	);
}

/** Unclassified chunks, including replacement output from extensions, require a content scan. */
export function readDocumentHydrationSlot(
	chunks: readonly string[] | undefined
): boolean | undefined {
	return (chunks as DocumentHydrationChunks | undefined)?.[documentHydrationPresence];
}
