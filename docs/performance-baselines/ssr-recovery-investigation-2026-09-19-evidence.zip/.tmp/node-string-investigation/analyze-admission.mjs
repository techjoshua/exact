import {readFile,writeFile} from 'node:fs/promises';
import {summarizeSsrCapacityCapture as summarize} from '../../framework-comparison/src/ssr-capacity-report.mjs';
const root=import.meta.dirname,index=JSON.parse(await readFile(root+'/recovery-admission-index.json'));
const report={createdAt:new Date().toISOString(),runs:[]};
for(const item of index){
 const capture=JSON.parse(await readFile(item.output));
 if(item.variant!=='observed'){
  const rows=summarize(capture).filter(r=>r.concurrency===32),exact=rows.find(r=>r.name==='eXact').rps,react=rows.find(r=>r.name==='React').rps;
  report.runs.push({...item,exact,react,ratio:exact/react});continue;
 }
 const block=capture.blocks[0],stage=block.results[0].stages.find(s=>s.name==='total-c32');
 const start=Date.parse(stage.startedAt),end=start+stage.elapsedMs;
 const samples=block.workerStderr.split('\n').filter(line=>line.startsWith('ADMISSION ')).map(line=>JSON.parse(line.slice(10)));
 const transitions=[];
 for(let i=0;i<samples.length-1;i++){
  const a=samples[i],b=samples[i+1];if(a.phase===b.phase&&a.enabled===b.enabled)continue;
  transitions.push({epochMs:a.epochMs,offsetFromC32Ms:a.epochMs-start,from:a.phase,to:b.phase,enabled:b.enabled,rate:a.completions*1000/(a.at-a.started),controlRate:a.controlRate,lag:a.lag,controlLag:a.controlLag,deadline:a.at>=a.until,until:a.until,at:a.at});
 }
 const measured=samples.filter(s=>s.epochMs>=start&&s.epochMs<=end);
 report.runs.push({...item,diagnostic:true,samples:samples.length,c32:{start,end,samples:measured.length,scheduledSamples:measured.filter(s=>s.enabled).length},transitions,samplesData:samples});
}
await writeFile(root+'/admission-analysis.json',JSON.stringify(report,null,2)+'\n');
for(const r of report.runs)console.log(r.diagnostic?{variant:r.variant,c32:r.c32,transitions:r.transitions}: {variant:r.variant,exact:r.exact,react:r.react,ratio:r.ratio});
