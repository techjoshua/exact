import {spawn} from 'node:child_process';import {readFile,writeFile} from 'node:fs/promises';import assert from 'node:assert/strict';
import {summarizeSsrCapacityCapture as summarize} from '../../framework-comparison/src/ssr-capacity-report.mjs';
const root='.tmp/node-string-investigation',results=[];
const probes=JSON.parse(await readFile(`${root}/stream-result-probes.json`));
for(const mode of ['stream','string'])assert.equal(JSON.parse(await readFile(`${root}/sink-owned-${mode}-probe.json`)).hash,probes.find(r=>r.mode===mode&&r.variant==='slot-only').hash);
for(const mode of ['stream','string']){
 for(const [round,variant] of ['slot-only','sink-owned-provenance','sink-owned-provenance','slot-only'].entries()){
  const output=`${root}/recovery-provenance-${mode}-${round}-${variant}.json`;console.log('START',mode,round,variant);
  await new Promise((resolve,reject)=>{const c=spawn(process.execPath,[`${root}/control-capacity.mjs`,`${root}/recovery-admission-plan.json`,output,'node'],{env:{...process.env,NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:mode,CONTROL_EXACT_ENTRY:`${root}/${variant}.mjs`},stdio:'inherit'});c.on('error',reject);c.on('exit',code=>code===0?resolve():reject(Error(String(code))));});
  const capture=JSON.parse(await readFile(output));if(!capture.complete)throw Error('Incomplete run');
  const rows=summarize(capture).filter(r=>r.concurrency===32),exact=rows.find(r=>r.name==='eXact').rps,react=rows.find(r=>r.name==='React').rps;
  results.push({mode,round,variant,output,exact,react,ratio:exact/react});await writeFile(`${root}/recovery-provenance-index.json`,JSON.stringify(results,null,2));
 }
 const average=variant=>{const r=results.filter(r=>r.mode===mode&&r.variant===variant);return r.reduce((s,r)=>s+r.ratio,0)/r.length;};
 const gain=average('sink-owned-provenance')/average('slot-only')-1;console.log('RATIO CHANGE',mode,gain);
 if(mode==='stream'&&gain<0.02){console.log('REJECT: no useful streaming gain established');break;}
}
