import {spawn} from 'node:child_process';
import {readFile,writeFile} from 'node:fs/promises';
const plan=JSON.parse(await readFile('.tmp/wsl-optimized-final-2026-09-19/multi-plan.json'));
plan.stages=plan.stages.slice(0,3);
plan.preloaded=false;
await writeFile('.tmp/node-string-investigation/recovery-normal-plan.json',JSON.stringify(plan));
const results=[];
for(const [round,variant] of ['current','slot-only','slot-only','current'].entries()){
 const output=`.tmp/node-string-investigation/recovery-normal-${round}-${variant}.json`;
 console.log('START',round,variant);
 await new Promise((resolve,reject)=>{const child=spawn(process.execPath,['.tmp/node-string-investigation/control-capacity.mjs','.tmp/node-string-investigation/recovery-normal-plan.json',output,'node'],{env:{...process.env,NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:'string',CONTROL_EXACT_ENTRY:`.tmp/node-string-investigation/${variant}.mjs`},stdio:'inherit'});child.once('error',reject);child.once('exit',code=>code===0?resolve():reject(Error(String(code))));});
 results.push({round,variant,output});await writeFile('.tmp/node-string-investigation/recovery-normal-index.json',JSON.stringify(results,null,2));
}
