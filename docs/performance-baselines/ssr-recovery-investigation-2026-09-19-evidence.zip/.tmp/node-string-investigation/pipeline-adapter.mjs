// <stdin>
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import {
  exactResponseBodyOf,
  handleExactRequest
} from "@exactjs/server";

// framework-adapters/node-adapter/src/error-reporting.ts
function reportNodeError(error, phase, logger) {
  const scope = { source: "framework", packageName: "node-adapter", category: phase };
  const message = `eXact Node ${phase} failed`;
  try {
    if (logger) {
      if (logger.isEnabled?.("error", scope) !== false)
        logger.log({ level: "error", message, error, scope });
      return;
    }
  } catch (loggingError) {
    console.error("[eXact node-adapter] Error logger failed", loggingError);
  }
  console.error(message, error);
}

// framework-adapters/node-adapter/src/requests/error.ts
function writeNodeError(response, error, logger) {
  reportNodeError(error, "request", logger);
  if (response.destroyed || response.writableEnded) return;
  if (response.headersSent) {
    response.destroy(
      error instanceof Error ? error : new Error("eXact request failed", { cause: error })
    );
    return;
  }
  for (const name of response.getHeaderNames()) response.removeHeader(name);
  response.statusCode = 500;
  response.setHeader("content-type", "application/json; charset=utf-8");
  response.end(JSON.stringify({ error: "internal_error" }));
}

// framework-adapters/node-adapter/src/requests/admission.ts
import {
  bindRequestRenderScheduler
} from "@exactjs/server/framework/render-scheduling";

// framework-adapters/node-adapter/src/requests/adaptive-gate.ts
import { monitorEventLoopDelay, performance } from "node:perf_hooks";
var AdaptiveRequestGate = class {
  delay;
  timer;
  lastRequest = -Infinity;
  recentRequests = 0;
  requests = 0;
  completions = 0;
  epoch = 0;
  started = 0;
  enabled = false;
  highSamples = 0;
  phase = "baseline";
  nextPhase = "trial";
  until = 0;
  cooldown = 0;
  backoff = 2e3;
  baseline;
  trial;
  controlRate = 0;
  controlLag = 0;
  /** Begins one request; a returned epoch permits completion accounting for this window only. */
  observeRequest() {
    if (this.timer) {
      this.requests++;
      return this.epoch;
    }
    const now = performance.now();
    this.recentRequests = now - this.lastRequest > 250 ? 1 : this.recentRequests + 1;
    this.lastRequest = now;
    if (this.recentRequests < 4) return;
    this.delay ??= monitorEventLoopDelay({ resolution: 2 });
    this.delay.enable();
    this.resetWindow(now);
    this.timer = setInterval(() => this.sample(), 250);
    this.timer.unref();
    return this.epoch;
  }
  /** Records successful response completion only in the observation window that admitted it. */
  observeCompletion(epoch) {
    if (this.timer && epoch === this.epoch) this.completions++;
  }
  /** Whether the current request should enter the bounded render-start queue. */
  shouldSchedule() {
    return this.enabled;
  }
  resetWindow(now) {
    this.epoch++;
    this.started = now;
    this.completions = 0;
    this.delay.reset();
  }
  /** Reassesses capacity with immediate controls on both sides of a scheduled trial. */
  sample() {
    const now = performance.now();
    const requests = this.requests;
    this.requests = 0;
    if (requests < 4) {
      this.enabled = false;
      this.phase = "baseline";
      this.nextPhase = "trial";
      this.highSamples = 0;
      this.backoff = 2e3;
      this.cooldown = 0;
      this.baseline = this.trial = void 0;
      if (!requests) {
        clearInterval(this.timer);
        this.timer = void 0;
        this.delay.disable();
        this.recentRequests = 0;
        this.lastRequest = -Infinity;
      } else this.resetWindow(now);
      return;
    }
    if (this.phase === "settle") {
      if (now >= this.until) {
        this.phase = this.nextPhase;
        this.resetWindow(now);
      }
      return;
    }
    if (this.phase === "enabled" && now >= this.until) {
      this.restartBaseline(now);
      return;
    }
    const elapsed = now - this.started;
    const control = this.phase === "baseline" || this.phase === "after";
    if (elapsed < (control ? 250 : 750)) return;
    if (control && this.completions < 100 && elapsed < 750) return;
    const sample = {
      lag: this.delay.percentile(95) / 1e6,
      rate: this.completions * 1e3 / (now - this.started),
      count: this.completions
    };
    if (this.phase === "trial") {
      this.trial = sample;
      this.enabled = false;
      this.phase = "settle";
      this.nextPhase = "after";
      this.until = now + 250;
      this.resetWindow(now);
      return;
    }
    if (this.phase === "after") {
      const rate = Math.max(this.baseline.rate, sample.rate);
      const lag = Math.min(this.baseline.lag, sample.lag);
      this.enabled = this.trial.count >= 100 && sample.count >= 100 && this.trial.rate > rate && this.trial.lag < lag;
      if (this.enabled) {
        this.controlRate = rate;
        this.controlLag = lag;
        this.phase = "enabled";
        this.until = now + 3e4;
        this.backoff = 2e3;
      } else {
        this.phase = "baseline";
        this.cooldown = now + this.backoff;
        this.backoff = Math.min(3e4, this.backoff * 2);
      }
      this.resetWindow(now);
      return;
    }
    if (this.phase === "enabled") {
      if (sample.rate <= this.controlRate || sample.lag >= this.controlLag)
        this.restartBaseline(now);
      else this.resetWindow(now);
      return;
    }
    this.highSamples = sample.lag > 3 ? this.highSamples + 1 : 0;
    if (now >= this.cooldown && this.highSamples >= 2 && sample.count >= 100) {
      this.baseline = sample;
      this.enabled = true;
      this.phase = "settle";
      this.nextPhase = "trial";
      this.until = now + 250;
      this.highSamples = 0;
    }
    this.resetWindow(now);
  }
  restartBaseline(now) {
    this.enabled = false;
    this.phase = "baseline";
    this.cooldown = now;
    this.highSamples = 0;
    this.resetWindow(now);
  }
};

// framework-adapters/node-adapter/src/render-scheduler.ts
import { clearImmediate, setImmediate } from "node:timers";
import * as timerPromises from "node:timers/promises";
function createNodeRenderScheduler(options = {}) {
  const limit = options.maxBatchSize ?? 32;
  if (!Number.isSafeInteger(limit) || limit < 1)
    throw new RangeError("maxBatchSize must be a positive safe integer");
  let pending;
  const scheduler2 = timerPromises.scheduler;
  const yieldTask = typeof scheduler2?.yield === "function" ? () => scheduler2.yield() : void 0;
  const enqueue = (signal) => new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(signal.reason);
      return;
    }
    const first = !pending;
    const batch = pending ?? {
      starts: [],
      failures: [],
      active: 0,
      timer: void 0
    };
    if (first) pending = batch;
    const index = batch.starts.length;
    batch.active++;
    if (signal) {
      const abort = () => {
        batch.starts[index] = void 0;
        batch.failures[index] = void 0;
        signal.removeEventListener("abort", abort);
        if (--batch.active === 0) {
          if (batch.timer !== void 0) clearImmediate(batch.timer);
          batch.timer = void 0;
          batch.starts = [];
          batch.failures = [];
          if (pending === batch) pending = void 0;
        }
        reject(signal.reason);
      };
      batch.starts.push(() => {
        signal.removeEventListener("abort", abort);
        resolve();
      });
      batch.failures.push((reason) => {
        signal.removeEventListener("abort", abort);
        reject(reason);
      });
      signal.addEventListener("abort", abort, { once: true });
    } else {
      batch.starts.push(resolve);
      batch.failures.push(reject);
    }
    if (batch.starts.length === limit) pending = void 0;
    if (first) {
      const release = () => {
        if (pending === batch) pending = void 0;
        batch.timer = void 0;
        for (const start of batch.starts) start?.();
        batch.starts = [];
        batch.failures = [];
      };
      const fail = (reason) => {
        if (pending === batch) pending = void 0;
        for (const rejectStart of batch.failures) rejectStart?.(reason);
        batch.starts = [];
        batch.failures = [];
      };
      try {
        if (yieldTask) void yieldTask().then(release, fail);
        else batch.timer = setImmediate(release);
      } catch (reason) {
        fail(reason);
      }
    }
  });
  return enqueue;
}

// framework-adapters/node-adapter/src/requests/admission.ts
var admissionOwner = /* @__PURE__ */ Symbol("exact.node.admission");
function createNodeRequestAdmission(options = {}) {
  const enqueue = createNodeRenderScheduler({ maxBatchSize: options.maxBatchSize });
  const gate = options.adaptive ?? !("bun" in process.versions) ? new AdaptiveRequestGate() : void 0;
  const checkpoint = (signal) => {
    signal?.throwIfAborted();
    return gate?.shouldSchedule() ? enqueue(signal) : void 0;
  };
  return (response, signal) => {
    if (signal.aborted) return Promise.reject(signal.reason);
    const owned = response;
    const existing = owned[admissionOwner];
    if (existing !== void 0) {
      if (existing) bindRequestRenderScheduler(signal, existing);
      return;
    }
    owned[admissionOwner] = gate ? checkpoint : false;
    if (!gate) return;
    bindRequestRenderScheduler(signal, checkpoint);
    const epoch = gate.observeRequest();
    if (epoch !== void 0) {
      const completed = () => {
        response.off("finish", completed);
        response.off("close", completed);
        if (response.writableFinished) gate.observeCompletion(epoch);
      };
      response.once("finish", completed);
      response.once("close", completed);
    }
    return gate.shouldSchedule() ? enqueue(signal) : void 0;
  };
}

// <stdin>
var nodeSynchronousResponseEnvironment = Object.freeze({
  encodedByteLength: (value) => Buffer.byteLength(value)
});
function createExactNodeHandler(context, options = {}) {
  const admit = createNodeRequestAdmission(options);
  return (request, response) => {
    const disconnect = new AbortController();
    const abort = () => disconnect.abort(new DOMException("Client disconnected", "AbortError"));
    request.once("aborted", abort);
    response.once("close", abort);
    const cleanup = () => {
      request.off("aborted", abort);
      response.off("close", abort);
    };
    const body = readNodeRequestBody(request, requestLimit(context));
    void body.catch(() => void 0);
    const execute = () => handleExactRequest(
      {
        method: request.method ?? "GET",
        url: request.url,
        headers: request.headers,
        text: () => body,
        signal: disconnect.signal,
        platformRequest: request
      },
      context
    );
    let result;
    try {
      const pending = admit(response, disconnect.signal);
      result = pending ? pending.then(execute) : execute();
    } catch (error) {
      result = Promise.reject(error);
    }
    void result.then(
      (result2) => writeNodeResponse(response, result2, disconnect.signal, context.logger).finally(cleanup)
    ).catch((error) => {
      cleanup();
      if (disconnect.signal.aborted && error === disconnect.signal.reason) return;
      try {
        writeNodeError(response, error, context.logger);
      } catch (writeError) {
        reportNodeError(writeError, "response", context.logger);
        if (!response.destroyed) response.destroy();
      }
    });
  };
}
function readNodeRequestBody(request, maxBytes = 4 * 1024 * 1024) {
  const declaredLength = Number(request.headers?.["content-length"]);
  if (Number.isFinite(declaredLength) && declaredLength > maxBytes) {
    request.resume();
    return Promise.reject(new Error(`eXact request exceeded ${maxBytes} bytes`));
  }
  return new Promise((resolve, reject) => {
    const chunks = [];
    let bytes = 0;
    let settled = false;
    const cleanup = () => {
      request.off("data", onData);
      request.off("end", onEnd);
      request.off("error", onError);
    };
    const finish = (callback) => {
      if (settled) return;
      settled = true;
      cleanup();
      callback();
    };
    const onData = (chunk) => {
      const value = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
      bytes += value.byteLength;
      if (bytes > maxBytes) {
        finish(() => reject(new Error(`eXact request exceeded ${maxBytes} bytes`)));
        request.resume();
        return;
      }
      chunks.push(value);
    };
    const onEnd = () => finish(() => resolve(Buffer.concat(chunks).toString("utf8")));
    const onError = (error) => finish(() => reject(error));
    request.on("data", onData);
    request.on("end", onEnd);
    request.on("error", onError);
  });
}
function requestLimit(context) {
  const configured = context.limits?.maxRequestBytes;
  return typeof configured === "number" && Number.isSafeInteger(configured) && configured > 0 ? configured : 4 * 1024 * 1024;
}
async function writeNodeResponse(response, result, signal, logger) {
  response.statusCode = result.status;
  for (const [name, value] of Object.entries(result.headers)) response.setHeader(name, value);
  if (result.setCookies?.length) response.setHeader("set-cookie", [...result.setCookies]);
  const body = exactResponseBodyOf(result);
  if (body?.kind === "produced" && body.writeSynchronously) {
    try {
      const collected = collectProducedBody(body, signal, response);
      const output = typeof collected === "string" ? collected : await collected;
      throwIfAborted(signal);
      if (!response.headersSent && response.hasHeader("content-length"))
        response.writeHead(response.statusCode);
      response.end(output);
    } catch (error) {
      if (!signal?.aborted || error !== signal.reason) reportNodeError(error, "response", logger);
      try {
        await body.cancel(error);
      } catch (cleanupError) {
        if (cleanupError !== error) reportNodeError(cleanupError, "cleanup", logger);
      }
      if (!response.headersSent) {
        for (const name of response.getHeaderNames()) response.removeHeader(name);
        response.statusCode = 500;
        response.setHeader("content-type", "application/json; charset=utf-8");
        response.end(JSON.stringify({ error: "internal_error" }));
      } else if (!response.destroyed) response.destroy(error);
    }
    return;
  }
  if (!body && !result.stream) {
    throwIfAborted(signal);
    response.end(result.body ?? "");
    return;
  }
  try {
    if (body?.kind === "buffered") {
      throwIfAborted(signal);
      response.end(body.toText());
      return;
    }
    await writeNodeResponseBody(response, result, signal);
    throwIfAborted(signal);
    response.end();
  } catch (error) {
    if (!signal?.aborted || error !== signal.reason) reportNodeError(error, "response", logger);
    try {
      await cancelNodeResponseBody(result, error);
    } catch (cleanupError) {
      if (cleanupError !== error) reportNodeError(cleanupError, "cleanup", logger);
    }
    if (body?.kind === "produced" && !response.headersSent) {
      for (const name of response.getHeaderNames()) response.removeHeader(name);
      response.statusCode = 500;
      response.setHeader("content-type", "application/json; charset=utf-8");
      response.end(JSON.stringify({ error: "internal_error" }));
    } else if (!response.destroyed) response.destroy(error);
  }
}
async function writeNodeResponseBody(response, result, signal) {
  const body = exactResponseBodyOf(result);
  if (body) {
    if (body.kind === "produced" && body.writeSynchronously) {
      const collected = collectProducedBody(body, signal);
      const output = typeof collected === "string" ? collected : await collected;
      throwIfAborted(signal);
      if (!response.write(output)) await waitForDrain(response, signal);
      return;
    }
    await body.writeTo((chunk) => {
      throwIfAborted(signal);
      if (!response.write(chunk)) return waitForDrain(response, signal);
    });
    return;
  }
  if (result.stream) {
    await pipeReadableStream(result.stream, response, signal);
    return;
  }
  throwIfAborted(signal);
  response.write(result.body ?? "");
}
function collectProducedBody(body, signal, lengthResponse) {
  let output = "";
  const completion = body.writeSynchronously(
    (chunk) => {
      throwIfAborted(signal);
      output += chunk;
    },
    lengthResponse ? Object.freeze({
      ...nodeSynchronousResponseEnvironment,
      setBodyByteLength(bytes) {
        if (!Number.isSafeInteger(bytes) || bytes < 0)
          throw new TypeError("Invalid produced body byte length");
        if (!lengthResponse.headersSent && lengthResponse.statusCode >= 200 && lengthResponse.statusCode !== 204 && lengthResponse.statusCode !== 304 && !lengthResponse.hasHeader("transfer-encoding"))
          lengthResponse.setHeader("content-length", bytes);
      }
    }) : nodeSynchronousResponseEnvironment
  );
  return completion ? completion.then(() => output) : output;
}
async function cancelNodeResponseBody(result, reason) {
  const body = exactResponseBodyOf(result);
  if (body) await body.cancel(reason);
  else if (result.stream) await result.stream.cancel(reason);
}
async function pipeReadableStream(stream, response, signal) {
  throwIfAborted(signal);
  await pipeline(Readable.fromWeb(stream), response, { end: false, signal });
}
function waitForDrain(response, signal) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const cleanup = () => {
      response.off("drain", drain);
      signal?.removeEventListener("abort", abort);
    };
    const finish = (callback) => {
      if (settled) return;
      settled = true;
      cleanup();
      callback();
    };
    const drain = () => finish(resolve);
    const abort = () => finish(() => reject(signal?.reason ?? new DOMException("Client disconnected", "AbortError")));
    if (signal?.aborted) {
      abort();
      return;
    }
    response.once("drain", drain);
    signal?.addEventListener("abort", abort, { once: true });
  });
}
function throwIfAborted(signal) {
  if (signal?.aborted) throw signal.reason ?? new DOMException("Client disconnected", "AbortError");
}
export {
  cancelNodeResponseBody,
  createExactNodeHandler,
  readNodeRequestBody,
  writeNodeResponse,
  writeNodeResponseBody
};
