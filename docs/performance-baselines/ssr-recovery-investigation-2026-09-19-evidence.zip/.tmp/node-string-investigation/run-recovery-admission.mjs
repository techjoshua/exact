import {spawn} from 'node:child_process';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const root='.tmp/node-string-investigation';
const plan=JSON.parse(await readFile('.tmp/wsl-recovery-2026-09-19/multi-plan.json'));
plan.stages=plan.stages.slice(0,3);
await writeFile(`${root}/recovery-admission-plan.json`,JSON.stringify(plan));
const results=[];
for(const [round,variant] of ['original-ssr','retained','admission-off','shared-completion','shared-lifecycle','retained','observed'].entries()){
 const output=`${root}/recovery-admission-${round}-${variant}.json`;
 const worker=variant==='shared-lifecycle'?`${root}/admission-lifecycle-worker.mjs`:variant==='shared-completion'?`${root}/admission-shared-worker.mjs`:variant==='admission-off'?`${root}/admission-off-worker.mjs`:variant==='observed'?`${root}/admission-observed-worker.mjs`:'framework-comparison/src/ssr-benchmark-worker.mjs';
 const runner=variant==='observed'?`${root}/observed-capacity.mjs`:`${root}/transport-capacity.mjs`;
 console.log('START',round,variant);
 await new Promise((resolve,reject)=>{const child=spawn(process.execPath,[runner,`${root}/recovery-admission-plan.json`,output,'node'],{env:{...process.env,NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:'stream',CONTROL_EXACT_ENTRY:`${root}/${variant==='original-ssr'?'current':'slot-only'}.mjs`,CONTROL_WORKER_PATH:worker},stdio:'inherit'});child.once('error',reject);child.once('exit',code=>code===0?resolve():reject(Error(String(code))));});
 const capture=JSON.parse(await readFile(output));if(!capture.complete)throw Error('Incomplete '+variant);
 results.push({round,variant,output,worker,workerSha256:createHash('sha256').update(await readFile(worker)).digest('hex'),...(variant==='observed'?{adapterSha256:createHash('sha256').update(await readFile(`${root}/admission-observed.mjs`)).digest('hex')}:{})});await writeFile(`${root}/recovery-admission-index.json`,JSON.stringify(results,null,2));
}
