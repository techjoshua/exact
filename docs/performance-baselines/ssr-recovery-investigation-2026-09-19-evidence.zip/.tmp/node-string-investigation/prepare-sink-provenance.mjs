import {readFile,writeFile} from 'node:fs/promises';
const root=import.meta.dirname;let source=await readFile(root+'/current.mjs','utf8');
function replace(a,b){if(!source.includes(a))throw Error('Missing '+a);source=source.replace(a,b);}
replace('var resultStorage = Symbol("ssrResultStorage");', `var resultStorage = Symbol("ssrResultStorage");
var documentHydrationPresence = Symbol("ssrDocumentHydrationPresence");
function hasDocumentHydrationSlot(result) {
 const chunks=htmlChunksOf(result);
 const known=chunks?.[documentHydrationPresence];
 return known ?? result.html.includes(documentHydrationSlot);
}`);
replace('const hasSlot = result.html.includes(documentHydrationSlot);','const hasSlot = hasDocumentHydrationSlot(result);');
replace('finishChunks(prefix = []) {','finishChunks(prefix = [], hasHydrationSlot) {');
replace('if (characters > this.maxBytes / 3 && utf8ByteLength(chunks.join("")) > this.maxBytes) throw new SsrOutputLimitError(this.maxBytes);\n\t\treturn chunks;', 'if (characters > this.maxBytes / 3 && utf8ByteLength(chunks.join("")) > this.maxBytes) throw new SsrOutputLimitError(this.maxBytes);\nif(hasHydrationSlot !== undefined) chunks[documentHydrationPresence] = hasHydrationSlot;\n\t\treturn chunks;');
replace('chunks: sink.finishChunks(context.reactResourceHints),','chunks: sink.finishChunks(context.reactResourceHints, context.documentOutputs?.has("hydrationData") ?? false),');
await writeFile(root+'/sink-provenance.mjs',source);
