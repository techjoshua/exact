import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {build} from 'esbuild';
const root=resolve('.tmp/node-string-investigation');
let worker=await readFile('framework-comparison/src/ssr-benchmark-worker.mjs','utf8');
worker=worker.replaceAll(/from '(\.[^']+)'/g,(_,p)=>`from '${pathToFileURL(resolve('framework-comparison/src',p)).href}'`);
worker=worker.replace("resolve(import.meta.dirname, '..')",JSON.stringify(resolve('framework-comparison')));
const off=worker.replace('participant.handle(request, response, signal)\n\t\t\t\t)', 'participant.handle(request, response, signal),\n{adaptive:false}\n\t\t\t\t)');
if(off===worker)throw Error('Admission replacement failed');
await writeFile(resolve(root,'admission-off-worker.mjs'),off);
await build({entryPoints:['framework-adapters/node-adapter/src/index.ts'],outfile:resolve(root,'admission-observed.mjs'),bundle:true,platform:'node',format:'esm',packages:'external',plugins:[{name:'observe-gate',setup(b){b.onLoad({filter:/adaptive-gate\.ts$/},async args=>{let contents=await readFile(args.path,'utf8');contents=contents.replace('private sample(): void {','private sample(): void {\nconsole.error("ADMISSION",JSON.stringify({epochMs:Date.now(),at:performance.now(),phase:this.phase,enabled:this.enabled,requests:this.requests,completions:this.completions,started:this.started,lag:this.delay?.percentile(95)/1e6,cooldown:this.cooldown,controlRate:this.controlRate,controlLag:this.controlLag,until:this.until}));');return{contents,loader:'ts'};});}}]});
const observed=worker.replace("import { createNodeHandler, writeNodeResponse } from '@exactjs/node-adapter';","import { createNodeHandler, writeNodeResponse } from './admission-observed.mjs';");
await writeFile(resolve(root,'admission-observed-worker.mjs'),observed);
await build({entryPoints:['framework-adapters/node-adapter/src/index.ts'],outfile:resolve(root,'admission-shared.mjs'),bundle:true,platform:'node',format:'esm',packages:'external',plugins:[{name:'share-completion',setup(b){b.onLoad({filter:/requests\/admission\.ts$/},async args=>{
let contents=await readFile(args.path,'utf8');
contents=contents.replace("type AdmittedResponse = ServerResponse & { [admissionOwner]?: RequestRenderScheduler | false };",`type AdmissionObservation = { scheduler: RequestRenderScheduler; gate: AdaptiveRequestGate; epoch: number | undefined };
type AdmittedResponse = ServerResponse & { [admissionOwner]?: AdmissionObservation | false };
function completeObservedResponse(this: AdmittedResponse): void {
 this.off('finish', completeObservedResponse);
 this.off('close', completeObservedResponse);
 const observation = this[admissionOwner];
 if (!observation) return;
 const epoch = observation.epoch;
 observation.epoch = undefined;
 if (epoch !== undefined && this.writableFinished) observation.gate.observeCompletion(epoch);
}`);
contents=contents.replace('bindRequestRenderScheduler(signal, existing);','bindRequestRenderScheduler(signal, existing.scheduler);');
const begin=contents.indexOf('\t\towned[admissionOwner] = gate ? checkpoint : false;');
const end=contents.indexOf('\n\t\treturn gate.shouldSchedule()',begin);
if(begin<0||end<0)throw Error('Missing admission block');
contents=contents.slice(0,begin)+`\t\tif (!gate) { owned[admissionOwner] = false; return; }
 bindRequestRenderScheduler(signal, checkpoint);
 const epoch = gate.observeRequest();
 owned[admissionOwner] = {scheduler:checkpoint, gate, epoch};
 if (epoch !== undefined) {
  response.on('finish', completeObservedResponse);
  response.on('close', completeObservedResponse);
 }
`+contents.slice(end);
await writeFile(resolve(root,'admission-shared-source.ts'),contents);
return {contents,loader:'ts'};
});}}]});
await writeFile(resolve(root,'admission-shared-worker.mjs'),worker.replace("import { createNodeHandler, writeNodeResponse } from '@exactjs/node-adapter';","import { createNodeHandler, writeNodeResponse } from './admission-shared.mjs';"));
await build({entryPoints:['framework-adapters/node-adapter/src/index.ts'],outfile:resolve(root,'admission-lifecycle.mjs'),bundle:true,platform:'node',format:'esm',packages:'external',plugins:[{name:'share-lifecycle',setup(b){
b.onLoad({filter:/requests\/admission\.ts$/},async()=>({contents:await readFile(resolve(root,'admission-shared-source.ts'),'utf8'),loader:'ts'}));
b.onLoad({filter:/requests\/handler\.ts$/},async args=>{
 let contents=await readFile(args.path,'utf8');
 contents=contents.replaceAll(".once('",".on('");
 contents=contents.replace("disconnect.abort(new DOMException('Client disconnected', 'AbortError'));\n\t\t\tcleanup();", "cleanup();\n\t\t\tdisconnect.abort(new DOMException('Client disconnected', 'AbortError'));");
 await writeFile(resolve(root,'admission-lifecycle-source.ts'),contents);
 return {contents,loader:'ts'};
});}}]});
await writeFile(resolve(root,'admission-lifecycle-worker.mjs'),worker.replace("import { createNodeHandler, writeNodeResponse } from '@exactjs/node-adapter';","import { createNodeHandler, writeNodeResponse } from './admission-lifecycle.mjs';"));
