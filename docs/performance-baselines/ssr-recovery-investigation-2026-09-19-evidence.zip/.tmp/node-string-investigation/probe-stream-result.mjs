import {spawn} from 'node:child_process';import {writeFile} from 'node:fs/promises';import assert from 'node:assert/strict';
const results=[];
for(let round=0;round<4;round++)for(const mode of ['stream','string'])for(const variant of round%2?['lean-stream-result','stream-original-result','slot-only']:['slot-only','stream-original-result','lean-stream-result']){
 const r=await new Promise((resolve,reject)=>{let out='';const c=spawn(process.execPath,['.tmp/node-string-investigation/probe.mjs',variant,mode],{env:{...process.env,NODE_ENV:'production'},stdio:['ignore','pipe','inherit']});c.stdout.on('data',b=>out+=b);c.on('error',reject);c.on('exit',code=>code===0?resolve(JSON.parse(out)):reject(Error(String(code))));});
 for(const old of results.filter(v=>v.mode===mode))assert.equal(old.hash,r.hash);
 results.push({round,...r});console.log(round,mode,variant,r.rps);await writeFile('.tmp/node-string-investigation/stream-result-probes.json',JSON.stringify(results,null,2));
}
