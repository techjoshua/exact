import {readFile,writeFile} from 'node:fs/promises';
const root=import.meta.dirname;let source=await readFile(root+'/current.mjs','utf8');
function replace(a,b){if(!source.includes(a))throw Error('Missing '+a);source=source.replace(a,b);}
replace('var resultStorage = Symbol("ssrResultStorage");', `var resultStorage = Symbol("ssrResultStorage");
var documentHydrationPresence = Symbol("ssrDocumentHydrationPresence");
function hasDocumentHydrationSlot(result) {
 const chunks=htmlChunksOf(result);
 const known=chunks?.[documentHydrationPresence];
 return known ?? result.html.includes(documentHydrationSlot);
}`);
replace('const hasSlot = result.html.includes(documentHydrationSlot);','const hasSlot = hasDocumentHydrationSlot(result);');
const start=source.indexOf('var DocumentStringSink = class');
const end=source.indexOf('//#endregion',start);
if(start<0||end<0)throw Error('Missing sink');
let sink=source.slice(start,end);
sink=sink.replace('constructor(maxBytes) {','constructor(maxBytes, context) {\nthis.outputContext = context;');
sink=sink.replace('this.destroy();\n\t\tif (characters >', 'if(this.outputContext) chunks[documentHydrationPresence] = this.outputContext.documentOutputs?.has("hydrationData") ?? false;\nthis.destroy();\n\t\tif (characters >');
sink=sink.replace('destroy() {','destroy() {\nthis.outputContext = undefined;');
source=source.slice(0,start)+sink+source.slice(end);
replace('new DocumentStringSink(context.maxOutputBytes)', 'new DocumentStringSink(context.maxOutputBytes, context)');
await writeFile(root+'/sink-owned-provenance.mjs',source);
