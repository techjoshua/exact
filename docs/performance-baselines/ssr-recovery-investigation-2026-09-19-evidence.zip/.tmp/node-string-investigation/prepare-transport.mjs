import {readFile,writeFile} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {pathToFileURL} from 'node:url';
import {build} from 'esbuild';
const root=resolve('.tmp/node-string-investigation');
let handler=await readFile('framework-adapters/node-adapter/src/handler.ts','utf8');
const start=handler.indexOf('async function pipeReadableStream('),end=handler.indexOf('\nfunction waitForDrain(',start);
handler="import { Readable } from 'node:stream';\nimport { pipeline } from 'node:stream/promises';\n"+handler.slice(0,start)+`async function pipeReadableStream(stream: ReadableStream<Uint8Array>,response: ServerResponse,signal?: AbortSignal): Promise<void> {
 throwIfAborted(signal);
 await pipeline(Readable.fromWeb(stream as never), response, {end:false,signal});
}
`+handler.slice(end);
await build({stdin:{contents:handler,loader:'ts',resolveDir:resolve('framework-adapters/node-adapter/src')},outfile:resolve(root,'pipeline-adapter.mjs'),bundle:true,platform:'node',format:'esm',packages:'external'});
let worker=await readFile('framework-comparison/src/ssr-benchmark-worker.mjs','utf8');
worker=worker.replaceAll(/from '(\.[^']+)'/g,(_,p)=>`from '${pathToFileURL(resolve('framework-comparison/src',p)).href}'`);
worker=worker.replace("import { createNodeHandler, writeNodeResponse } from '@exactjs/node-adapter';",`import { createNodeHandler } from '@exactjs/node-adapter';\nimport { writeNodeResponse } from './pipeline-adapter.mjs';`);
worker=worker.replace("resolve(import.meta.dirname, '..')",JSON.stringify(resolve('framework-comparison')));
await writeFile(resolve(root,'pipeline-worker.mjs'),worker);
let runner=await readFile(resolve(root,'control-capacity.mjs'),'utf8');
runner=runner.replace("workerPath:resolve('framework-comparison/src/ssr-benchmark-worker.mjs')","workerPath:resolve(process.env.CONTROL_WORKER_PATH || 'framework-comparison/src/ssr-benchmark-worker.mjs')");
await writeFile(resolve(root,'transport-capacity.mjs'),runner);
