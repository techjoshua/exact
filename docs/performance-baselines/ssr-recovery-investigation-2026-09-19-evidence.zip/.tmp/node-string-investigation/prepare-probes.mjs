import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const source=await readFile('framework-comparison/participants/exact/dist-server/server-entry.js','utf8');
assert.equal(/^import /m.test(source),false,'Probe bundle must retain its complete runtime');
const target='const hasSlot = result.html.includes(documentHydrationSlot);';
assert.equal(source.split(target).length,2);
await writeFile('.tmp/node-string-investigation/current.mjs',source);
await writeFile('.tmp/node-string-investigation/no-scan.mjs',source.replace(target,'const hasSlot = false;'));
