import {spawn} from 'node:child_process';
import {writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const results=[];
async function run(runtime,args){return new Promise((resolve,reject)=>{const child=spawn(runtime==='node'?process.execPath:'bun',['.tmp/node-string-investigation/probe.mjs',...args],{stdio:['ignore','pipe','pipe']});let out='',err='';child.stdout.on('data',s=>out+=s);child.stderr.on('data',s=>err+=s);child.once('error',reject);child.once('exit',code=>code===0?resolve(JSON.parse(out)):reject(Error(err||String(code))));});}
for(const runtime of ['node'])for(const mode of ['stream'])for(let round=0;round<(4);round++){
 for(const variant of round%2?['sync-stream','slot-only']:['slot-only','sync-stream']){
  const result=await run(runtime,[variant,mode]);results.push({...result,round});
  console.log(runtime,mode,round,variant,result.rps.toFixed(0));
  await writeFile('.tmp/node-string-investigation/sync-stream-probes.json',JSON.stringify(results,null,2));
 }
}
for(const mode of ['stream']){
 const rows=results.filter(r=>r.mode===mode);assert.equal(new Set(rows.map(r=>r.hash)).size,1,'Identical completed HTML across runtimes and variants');
}
const summary=[];const median=a=>{a=[...a].sort((a,b)=>a-b);return(a[Math.floor((a.length-1)/2)]+a[Math.floor(a.length/2)])/2;};
for(const runtime of ['node'])for(const mode of ['stream']){
 const rows=results.filter(r=>r.runtime===runtime&&r.mode===mode);
 const before=median(rows.filter(r=>r.variant==='slot-only').map(r=>r.rps)),after=median(rows.filter(r=>r.variant==='sync-stream').map(r=>r.rps));
 summary.push({runtime,mode,before,after,changePercent:100*(after/before-1)});
}
await writeFile('.tmp/node-string-investigation/sync-stream-summary.json',JSON.stringify(summary,null,2));console.log(JSON.stringify(summary));
