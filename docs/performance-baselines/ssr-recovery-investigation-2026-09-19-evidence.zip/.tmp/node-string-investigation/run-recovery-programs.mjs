import {spawn} from 'node:child_process';import {readFile,writeFile} from 'node:fs/promises';
const root='.tmp/node-string-investigation',results=[];
for(const [round,variant] of ['slot-only','class-retained','class-retained','slot-only'].entries()){
 const output=`${root}/recovery-programs-${round}-${variant}.json`;console.log('START',round,variant);
 await new Promise((resolve,reject)=>{const c=spawn(process.execPath,[`${root}/control-capacity.mjs`,`${root}/recovery-admission-plan.json`,output,'node'],{env:{...process.env,NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:'stream',CONTROL_EXACT_ENTRY:`${root}/${variant}.mjs`},stdio:'inherit'});c.on('error',reject);c.on('exit',code=>code===0?resolve():reject(Error(String(code))));});
 const capture=JSON.parse(await readFile(output));if(!capture.complete)throw Error('Incomplete run');
 results.push({round,variant,output});await writeFile(`${root}/recovery-programs-index.json`,JSON.stringify(results,null,2));
}
