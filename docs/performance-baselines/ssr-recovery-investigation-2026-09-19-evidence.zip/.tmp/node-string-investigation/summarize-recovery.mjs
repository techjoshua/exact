import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {summarizeSsrCapacityCapture} from '../../framework-comparison/src/ssr-capacity-report.mjs';
const root=import.meta.dirname;
const groups={};
for(const group of ['stream','bytes','transport','normal','programs','provenance','production']){
 let index;try{index=JSON.parse(await readFile(`${root}/recovery-${group}-index.json`));}catch{continue;}
 const runs=[];
 for(const item of index){
  let capture;try{capture=JSON.parse(await readFile(item.output));}catch{runs.push({...item,excluded:'No completed capture'});continue;}
  if(!capture.complete){runs.push({...item,excluded:'Incomplete capture'});continue;}
  const rates=summarizeSsrCapacityCapture(capture).filter(r=>r.concurrency===32);
  const exact=rates.find(r=>r.name==='eXact').rps,react=rates.find(r=>r.name==='React').rps;
  runs.push({...item,exact,react,ratio:exact/react,exactArtifact:capture.artifacts.exact.sha256,reactArtifact:capture.artifacts.react.sha256,errors:capture.blocks.flatMap(b=>b.results.flatMap(r=>r.stages)).reduce((n,s)=>n+s.errors,0)});
 }
 groups[group]=runs;
}
const admission=JSON.parse(await readFile(`${root}/admission-analysis.json`));
const report={createdAt:new Date().toISOString(),groups,admission};
await writeFile(`${root}/recovery-investigation.json`,JSON.stringify(report,null,2)+'\n');
for(const [group,runs] of Object.entries(groups))console.log(group,runs.map(r=>({round:r.round,variant:r.variant,exact:r.exact,react:r.react,ratio:r.ratio,excluded:r.excluded})));
