import {spawn} from 'node:child_process';import {writeFile} from 'node:fs/promises';import assert from 'node:assert/strict';
const results=[];
const variants=['slot-only','class-retained','class-sync'];
for(let round=0;round<4;round++)for(const variant of (round%2?[...variants].reverse():variants)){
 const result=await new Promise((resolve,reject)=>{const child=spawn(process.execPath,['.tmp/node-string-investigation/probe.mjs',variant,'stream'],{stdio:['ignore','pipe','pipe']});let out='',err='';child.stdout.on('data',s=>out+=s);child.stderr.on('data',s=>err+=s);child.once('error',reject);child.once('exit',c=>c===0?resolve(JSON.parse(out)):reject(Error(err)));});
 results.push({...result,round});console.log(round,variant,result.rps.toFixed(0));await writeFile('.tmp/node-string-investigation/class-stream-probes.json',JSON.stringify(results,null,2));
}
assert.equal(new Set(results.map(r=>r.hash)).size,1);
