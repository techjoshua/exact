from pathlib import Path
import json, hashlib, zipfile
root=Path('.tmp/ssr-fresh')
prefix=Path('docs/performance-baselines/ssr-fresh-2026-09-12')
def load(p): return json.loads(p.read_text())
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
checks=load(root/'checks.json')
assert all(c.get('code')==0 for c in checks)
capture=load(Path(str(prefix)+'.json'))
for name, source in capture['sources'].items():
 assert digest(Path(source['path']))==source['sha256']
 raw=load(Path(source['path']))
 assert raw['complete']
 for block in raw.get('blocks',[]):
  assert not block['telemetryErrors'] and not block['workerStderr']
  for result in block['results']:
   assert result['complete']
   for stage in result['stages']:
    assert stage['invalid']==0
    assert stage['started']==stage['completed']==stage['valid']+stage['errors']
    assert stage['offered']==stage['started']+stage['missedLag']+stage['missedCapacity']+stage['missedDeadline']
   for setup in result.get('connectionPreparation',[]):
    assert setup['valid']+len(setup['errors'])==setup['concurrency']
verification={'checks':checks,'browserCorrectness':{'count':112,'execution':capture['execution'][0]},'docsBrowser':load(root/'docs-verification.json'),'loadAccounting':'All complete; zero invalid responses; preparation accounting verified'}
capture['validation']=verification
(root/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
Path(str(prefix)+'-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
lines=['','## Warm response and 16-request burst diagnostics','','All five frameworks are retained. Values are milliseconds; each burst value measures completion','of the whole wave. Normal loading includes application data fetching.','', '| Runtime/API | Framework | Warm response p99 | Burst completion p99 | Previous burst p99 |','| --- | --- | ---: | ---: | ---: |']
for mode, filename in [('string','performance-report.json'),('stream','ssr-stream-report.json')]:
 current=load(Path('apps/docs/src/data')/filename)
 previous=load(root/('before-'+filename))
 for runtime in ['node','bun']:
  c=current['server'] if runtime=='node' else current['server']['bun']
  p=previous['server'] if runtime=='node' else previous['server']['bun']
  for burst in c['burst']['series']:
   name=burst['name']
   warm=next(s for s in c['sequential']['series'] if s['name']==name)
   old=next(s for s in p['burst']['series'] if s['name']==name)
   lines.append(f"| {runtime} {mode} | {name} | {warm['stats']['p99']:.2f} | {burst['stats']['p99']:.2f} | {old['stats']['p99']:.2f} |")
lines+=['','The previous column is historical context from the preceding capture on this shared PC.','Differences are not a controlled estimate of the pooling correction alone.','','## Validation and evidence','','The 90 comparison tests, documentation tests, docs typecheck and production build passed.','Desktop/mobile browser checks verified chart values, page errors, and horizontal overflow.','The [verification journal](ssr-fresh-2026-09-12-verification.json) records all fresh checks.','The [evidence archive](ssr-fresh-2026-09-12-evidence.zip) retains source snapshots, plans,','runner code, raw results, logs, and screenshots. Existing browser and heap measurements are unchanged.','']
report=Path(str(prefix)+'.md')
report.write_text(report.read_text()+'\n'.join(lines))
with zipfile.ZipFile(str(prefix)+'-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file(): z.write(p,p.relative_to(root).as_posix())
 for name, expected in capture['sourceState']['files'].items():
  p=Path(name)
  if name.startswith(('apps/docs/','docs/')) or name.endswith('README.md'): continue
  assert digest(p)==expected,name
  z.write(p,'sources/'+name)
capture['evidenceArchive']={'path':str(prefix).replace('\\','/')+'-evidence.zip','sha256':digest(Path(str(prefix)+'-evidence.zip'))}
Path(str(prefix)+'.json').write_text(json.dumps(capture,indent=2)+'\n')
print('Verified and archived fresh benchmark evidence')
