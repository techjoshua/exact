from pathlib import Path
p = Path('.tmp/ssr-fresh')
old = Path('.tmp/ssr-followup')
for n in ['driver.mjs', 'load-process.mjs', 'load-owner.mjs']:
    (p/n).write_bytes((old/n).read_bytes())
s = (p/'capacity-runner.mjs').read_text().replace('../../framework-comparison/src/ssr-load-process-owner.mjs', './load-owner.mjs')
(p/'prepared-capacity.mjs').write_text(s)
s = (p/'run.mjs').read_text()
s = s[:s.index("await run('browser-correctness'")] + """
for(const mode of ['string','stream'])for(const runtime of ['node','bun']) {
 const name=runtime+(mode==='stream'?'-stream':'')+'-prepared';
 await run(name,[output+'/prepared-capacity.mjs',output+'/arrivals-plan.json',output+'/'+name+'.json',runtime],root,{COMPARISON_SSR_RENDER_MODE:mode,PROBE_PREWARM:'gradual',PROBE_AGENT_TIMEOUT:'10000'});
}
console.log('COMPLETE prepared controls');
"""
(p/'prepared-run.mjs').write_text(s)
