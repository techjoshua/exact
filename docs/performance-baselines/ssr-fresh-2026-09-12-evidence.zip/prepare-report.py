from pathlib import Path
p = Path('.tmp/ssr-fresh')
old = Path('.tmp/ssr-production-checkpoint')
s = (old/'publish.mjs').read_text().replace('ssr-production-checkpoint', 'ssr-fresh')
s = s.replace("'control-on','control-off','control-bun-stream-on','control-bun-stream-off'", "'node-prepared','bun-prepared','node-stream-prepared','bun-stream-prepared'")
s = s.replace('assert.equal(stages.length,16)', 'assert.equal(stages.length,20)')
s = s.replace("controls:await json(root+'/control-execution.json')", "connectionPreparation:'Separate gradual preparation controls; primary arrival charts retain abrupt growth'")
(p/'publish.mjs').write_text(s)
(p/'verify-docs.mjs').write_text((old/'verify-docs.mjs').read_text().replace('ssr-production-checkpoint', 'ssr-fresh'))
s = (old/'write-report.py').read_text().replace('ssr-production-checkpoint', 'ssr-fresh')
start = s.index("lines=['#")
end = s.index("'## Sustained capacity'")
s = s[:start] + """lines=['# Fresh SSR benchmark capture, September 12, 2026','',
'This capture repeats the production SSR sweep with bounded idle pooling in the load and burst',
'clients. Framework runtime code and participant artifacts are unchanged from the previous capture.',
'The previous results remain available as historical evidence. Measurements run sequentially on',
'the shared Windows PC using Node 26.8.1 and native Bun 1.4.2; foreground activity is uncontrolled.',
'The source snapshot identifies the uncommitted working tree and parent commit `'+commit+'`.','',
'Two fresh populations reverse framework order. Complete response bodies are validated and all',
'first-attempt errors remain counted. No retries, global fetch overrides, or timer patches are used.',
'The primary offered-load charts preserve abrupt connection growth. Gradually prepared connection',
'pools are measured separately and retain every setup error; they do not replace primary results.','',
""" + s[end:]
s = s.replace(" 'An initial preloaded capture was interrupted to tighten readiness rechecking before this sweep.', 'It is retained separately and excluded from the final measurements.',", '')
# Additional control results use the same per-driver rate accounting.
idx = s.index("Path('docs/performance-baselines/")
s = s[:idx] + """
lines += ['', '## Gradual connection preparation controls', '',
'Each driver prepares its pool in increments of 16 connections up to 256 immediately before',
'offered load. Setup responses are validated and setup failures are reported separately.',
'This changes connection arrival shape and is a separate workload from the primary charts.', '',
'| Runtime/API | Framework | Population | Setup errors | Measured errors | 8,000 offered: valid RPS | 10,000 offered: valid RPS |',
'| --- | --- | ---: | ---: | ---: | ---: | ---: |']
for name in ['node-prepared','bun-prepared','node-stream-prepared','bun-stream-prepared']:
 c=json.loads((root/(name+'.json')).read_text());assert c['complete']
 for b in c['blocks']:
  setup=sum(len(p['errors']) for r in b['results'] for p in r['connectionPreparation'])
  errors=sum(s['errors'] for r in b['results'] for s in r['stages'] if s['mode']=='arrival')
  rates=[sum(next(s for s in r['stages'] if s['name']==f'total-arrivals-{rate}')['validRps'] for r in b['results']) for rate in [8000,10000]]
  lines.append(f"| {c['runtimeId']} {c['renderMode']} | {b['id']} | {b['population']+1} | {setup} | {errors} | {rates[0]:,.0f} | {rates[1]:,.0f} |")
lines += ['', 'All raw results, including failed setup attempts, are linked from the structured capture.', '']
""" + s[idx:]
(p/'write-report.py').write_text(s)
