import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const root='.tmp/ssr-large-profile/';
const extra=`
export async function auditWriterOwnership(fail){
 const events=[];const context=createSsrContext({});context.writerSink={write(value){events.push(value);},ready(){},flush(){}};
 let first,second,finish;let disposed=false;
 const pending=renderProgramWriter(context,undefined,undefined,output=>{
  first=output;output.preparation={[Symbol.asyncDispose]:()=>new Promise(resolve=>{finish=()=>{disposed=true;events.push('disposed');resolve();};})};
  events.push('first');if(fail)throw Error('writer-failed');return output;
 },()=> '');
 const sibling=renderProgramWriter(context,undefined,undefined,output=>{second=output;events.push('second');return output;},()=> '');
 if(first===second)throw Error('Reused pending owner');
 if(disposed)throw Error('Cleanup unexpectedly completed');
 finish();try{await pending;events.push('complete');}catch(e){events.push(e.message);}
 await sibling;
 renderProgramWriter(context,undefined,undefined,output=>{if(output.preparation)throw Error('Leaked preparation');events.push('third');return output;},()=> '');
 return events;
}
`;
const mods=[];
for(const name of ['conditional-emission','writer-output-pool']){
 const file=root+'writer-output-pool/'+name+'-ownership.js';
 await fs.writeFile(file,await fs.readFile(root+name+'/server-entry.js','utf8')+extra);
 mods.push(await import(pathToFileURL(resolve(file))));
}
const rows=[];
for(const fail of [false,true]){const current=await mods[0].auditWriterOwnership(fail);assert.deepEqual(await mods[1].auditWriterOwnership(fail),current);rows.push({fail,events:current});}
await fs.writeFile(root+'writer-output-pool/ownership-'+(process.versions.bun?'bun':'node')+'.json',JSON.stringify(rows,null,2));
console.log('Pending cleanup, concurrent sibling and failure ownership matched:',rows.length);
