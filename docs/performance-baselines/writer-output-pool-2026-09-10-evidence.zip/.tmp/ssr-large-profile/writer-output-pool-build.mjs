import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';
await fs.mkdir(root+'writer-output-pool',{recursive:true});
for(const name of ['server-entry.js','bun-server-entry.js']){
 const source=await fs.readFile(root+'conditional-emission/'+name,'utf8');
 const ast=ts.createSourceFile(name,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
 const node=ast.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text==='renderProgramWriter');
 if(!node)throw Error('Missing writer');
 const text=node.getText(ast);
 const start=text.indexOf('\n\tif (');
 if(start<0)throw Error('Missing host branch');
 const rest=text.slice(start,text.lastIndexOf('}'));
 const replacement=`function renderProgramWriter(context,host,invocation,invoke,render,prepareReferences){
 const local=context.writerSink?undefined:new CapturedProgramSink(context);
 const pool=context.auditWriterOutputs??=[];
 const output=pool.pop()??{context:undefined,sink:undefined,target:undefined,render:undefined,prepareReferences:undefined,preparation:undefined};
 output.context=context;output.sink=context.writerSink??local;
 output.target=typeof render==='function'?undefined:render;
 output.render=typeof render==='function'?render:renderWriterTargetSegment;
 output.prepareReferences=typeof render==='function'?prepareReferences:prepareWriterTargetReferences;
 let completed;
 try {completed=auditRunAcquiredWriter(context,host,invocation,invoke,local,output);}catch(error){auditReleaseWriter(pool,output);throw error;}
 if(completed instanceof Promise)return completed.then(value=>{auditReleaseWriter(pool,output);return value;},error=>{auditReleaseWriter(pool,output);throw error;});
 auditReleaseWriter(pool,output);return completed;
}
function auditReleaseWriter(pool,output){output.context=undefined;output.sink=undefined;output.target=undefined;output.render=undefined;output.prepareReferences=undefined;output.preparation=undefined;pool.push(output);}
function auditRunAcquiredWriter(context,host,invocation,invoke,local,output){${rest}}
`;
 await fs.writeFile(root+'writer-output-pool/'+name,source.slice(0,node.getStart(ast))+replacement+source.slice(node.end));
}
for(const suffix of ['check','limits','lifecycle','pending']){
 const source=await fs.readFile(root+'boundary-state-machine-'+suffix+'.mjs','utf8');
 await fs.writeFile(root+'writer-output-pool-'+suffix+'.mjs',source.replaceAll('boundary-state-machine','writer-output-pool'));
}
