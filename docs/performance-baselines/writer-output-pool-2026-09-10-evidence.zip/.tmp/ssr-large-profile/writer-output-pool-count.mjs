import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const root='.tmp/ssr-large-profile/';
let source=await fs.readFile(root+'writer-output-pool/server-entry.js','utf8');
assert.equal(source.split('pool.pop()??{').length,2);
source=source.replace('pool.pop()??{','pool.pop()??(auditCreated++,{').replace('prepareReferences:undefined,preparation:undefined};','prepareReferences:undefined,preparation:undefined});');
source='let auditCreated=0;\n'+source+'\nexport function auditReset(){auditCreated=0;}\nexport function auditRead(){return auditCreated;}\n';
const file=root+'writer-output-pool/counted.js';await fs.writeFile(file,source);
const mod=await import(pathToFileURL(resolve(file)));
const original=await import(pathToFileURL(resolve(root+'conditional-emission/server-entry.js')));
const rows=[];
for(const scenario of ['assets','large']){
 const data=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));
 if(scenario==='large')data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
 const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
 const expected=await original.renderParticipant(data,'/incidents/inc-101',options);
 mod.auditReset();assert.equal(await mod.renderParticipant(data,'/incidents/inc-101',options),expected);
 rows.push({scenario,created:mod.auditRead()});
}
await fs.writeFile(root+'writer-output-pool/creation-counts.json',JSON.stringify(rows,null,2));console.log(rows);
