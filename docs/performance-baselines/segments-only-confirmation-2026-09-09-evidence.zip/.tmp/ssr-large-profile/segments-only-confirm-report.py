import hashlib,json,pathlib,statistics,zipfile
root=pathlib.Path('.'); work=root/'.tmp/ssr-large-profile'
batches=[json.loads((work/name).read_text(encoding='utf-8')) for name in ['segments-only-results.json','segments-only-confirm-results.json']]
summary=[]
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  changes=[]
  for batch in batches:
   for round in sorted({r['round'] for r in batch}):
    a=next(r for r in batch if r['runtimeId']==runtime and r['mode']==mode and r['round']==round and r['variant']=='callback-current')
    b=next(r for r in batch if r['runtimeId']==runtime and r['mode']==mode and r['round']==round and r['variant']=='segments-only')
    assert a['hash']==b['hash']
    changes.append((b['usPerRender']/a['usPerRender']-1)*100)
  summary.append(dict(runtime=runtime,mode=mode,changes=changes,median=statistics.median(changes),faster=sum(x<0 for x in changes)))
dest=root/'docs/performance-baselines/segments-only-confirmation-2026-09-09'
dest.with_suffix('.json').write_text(json.dumps(dict(summary=summary,batches=batches),indent=2)+'\n',encoding='utf-8')
table='\n'.join(f"| {s['runtime']} | {s['mode']} | {s['median']:+.2f}% | {s['faster']}/6 |" for s in summary)
doc='''# SSR output wrapper confirmation

Date: 2026-09-09. Decision: retain current production implementation.

The [initial wrapper isolation experiment](segments-only-2026-09-09.md) showed consistent Bun
string gains in two pairs, mixed Node string results, and mixed stream results. Four additional
reversed-order pairs per runtime and mode tested whether that pattern persisted. The hypothesis
remained a small allocation-driven gain, likely under 2%, from removing only a forwarding object.

The confirmation adds 32 fresh processes to the original 16. Settings are unchanged: production
environment, 96 incidents, 5,000 warmups and 12,000 measured renders per process, complete authored
document, empty client tags, same portable bundle on Node and Bun, and Response.text() consumption
for streams. All paired full-document hashes match. Artifact hashes are recorded in every row.

## Combined results

Positive means longer rendering time. Medians summarize six within-pair percentage changes, not
pooled request counts. These are descriptive measurements on a variable-load workstation, not
confidence bounds or HTTP throughput claims.

| Runtime | Mode | Median time change | Candidate faster pairs |
| --- | --- | ---: | ---: |
'''+table+'''

All four additional Node string pairs favored the candidate, but three of four additional Bun
string pairs favored the control. Stream results remained mixed. The initial Bun string improvement
did not replicate reliably. A small forwarding object is therefore not a demonstrated solution to
the remaining cross-runtime gap. No production change was made, and no previous improvement was
removed. No package or browser validation was needed for this rejected bundle-only experiment;
fixture output equality does not establish lifecycle equivalence for a future implementation.

This closes the isolated wrapper experiment for now. Further optimization should target a larger
source of work rather than repeatedly tuning this wrapper against noisy timings. React was not
rerun, so this experiment makes no new claim about the current React gap. The overall goal remains
unmet.

The evidence archive includes both batches, both runners, builder, worker, fixed input, frozen
bundles, this reporter, and a SHA-256 manifest. The original report and archive are preserved.
'''
dest.with_suffix('.md').write_text(doc,encoding='utf-8')
files=[work/name for name in ['callback-current.mjs','segments-only.mjs','long-worker.mjs','segments-only-build.mjs','segments-only-run.mjs','segments-only-confirm-run.mjs','segments-only-results.json','segments-only-confirm-results.json','segments-only-confirm-report.py']]+[root/'.tmp/positional-leaves/data.json']
manifest={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p))
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(table)
print('Verified',archive)
