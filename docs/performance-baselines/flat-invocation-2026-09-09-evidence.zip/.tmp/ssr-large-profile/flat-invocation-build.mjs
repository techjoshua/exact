import ts from 'typescript';import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';const original=readFileSync(dir+'marker-current.mjs','utf8');
const names=['Text','Child','Component','ComponentProps','Attribute'];let source=original;
for(const name of names){const before=`function prepareSsr${name}(invocation, index) {\n\tconst value = unwrap(invocation.eagerValues[index]);`;if(!source.includes(before))throw Error('Missing '+name);source=source.replace(before,`function prepareSsr${name}(slotValue) {\n\tconst value = unwrap(slotValue);`);}
const sf=ts.createSourceFile('input.mjs',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
for(const flat of [false,true]){
 let invocations=0,preparations=0;
 const result=ts.transform(sf,[context=>{
  const f=context.factory;
  function visit(node){
   node=ts.visitEachChild(node,visit,context);
   if(ts.isCallExpression(node)&&ts.isIdentifier(node.expression)&&node.expression.text==='createPreparedServerRenderProgram'){
    if(flat){if(node.arguments.length!==2||!ts.isArrayLiteralExpression(node.arguments[1]))throw Error('Unsupported invocation');const values=node.arguments[1].elements;if(values.some(ts.isSpreadElement))throw Error('Spread slots');invocations++;
    return f.createObjectLiteralExpression([f.createPropertyAssignment(f.createComputedPropertyName(f.createIdentifier('PreparedServerRenderProgram')),f.createTrue()),f.createPropertyAssignment('program',node.arguments[0]),...values.map((v,i)=>f.createPropertyAssignment('v'+i,v))],false);}
   }
   if(ts.isElementAccessExpression(node)&&ts.isPropertyAccessExpression(node.expression)&&node.expression.name.text==='eagerValues'&&ts.isNumericLiteral(node.argumentExpression)&&flat)return f.createPropertyAccessExpression(node.expression.expression,'v'+node.argumentExpression.text);
   if(ts.isCallExpression(node)&&ts.isPropertyAccessExpression(node.expression)&&node.expression.expression.getText(sf)==='__exactSsr'&&names.some(n=>'prepare'+n===node.expression.name.text)){
    const [inv,index]=node.arguments;if(!index||!ts.isNumericLiteral(index))throw Error('Dynamic preparation');preparations++;
    const value=flat?f.createPropertyAccessExpression(inv,'v'+index.text):f.createElementAccessExpression(f.createPropertyAccessExpression(inv,'eagerValues'),index);
    return f.updateCallExpression(node,node.expression,node.typeArguments,[value]);
   }
   return node;
  }
  return root=>ts.visitNode(root,visit);
 }]);
 const output=ts.createPrinter().printFile(result.transformed[0]);writeFileSync(dir+(flat?'flat-invocation':'value-preparation')+'.mjs',output);result.dispose();console.log({flat,invocations,preparations});
}
