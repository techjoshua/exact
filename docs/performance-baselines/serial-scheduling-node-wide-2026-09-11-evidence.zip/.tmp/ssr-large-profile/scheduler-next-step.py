import json
from pathlib import Path
base=Path('.tmp/ssr-large-profile')
for name in ('serial-backlog-node','serial-wide-node'):
 d=json.loads((base/name/'capture.json').read_text());assert d['complete']
 print(name)
 for b in d['blocks']:
  ds=[r['stages'][0]['distributions']['responseMs'] for r in b['results']]
  loop=b['after']['telemetry']['eventLoopDelayMs']
  print(b['population']+1,b['id'],b['phase'],round(b['rps']), 'p95',[x['p95'] for x in ds],'p99',[x['p99'] for x in ds], 'loop p99',loop['p99'])
