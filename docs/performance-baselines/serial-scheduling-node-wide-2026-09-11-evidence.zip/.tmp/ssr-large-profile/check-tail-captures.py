import json
from pathlib import Path
base=Path('.tmp/ssr-large-profile')
for folder in ('adaptive-lag/node','adaptive-lag/bun','serial-scheduler','serial-backlog-node','serial-wide-node'):
 path=base/folder/'capture.json'
 if not path.exists():continue
 d=json.loads(path.read_text())
 if not d['complete']:continue
 for b in d['blocks']:
  actual=b['after']['scheduleCalls'];expected=b['valid']+len(b['results'])
  if b['id']=='react' or b['phase']=='normal':assert actual==0,(folder,b['phase'],actual)
  elif b['phase']=='adaptive':assert 0<actual<=expected,(folder,actual,expected)
  else:assert actual==expected,(folder,b['phase'],actual,expected)
  for r in b['results']:
   s=r['stages'][0];assert s['errors']==0 and s['started']==s['completed']==s['valid']
 print(folder, len(d['blocks']), 'blocks; invocation and response guards pass')
