from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'serial-wide-node';root.mkdir(exist_ok=True)
for name in ('worker.mjs','serial-scheduler.mjs'):(root/name).write_bytes((base/'serial-backlog-node'/name).read_bytes())
r=(base/'serial-backlog-node-run.mjs').read_text().replace('serial-backlog-node/','serial-wide-node/').replace('large96-node-backlog-serial-turns','large96-node-wide-serial-turns').replace('serial-32','serial-128').replace('serial-8','serial-64')
(base/'serial-wide-node-run.mjs').write_text(r)
