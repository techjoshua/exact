import json,hashlib,zipfile
from pathlib import Path
base=Path('.tmp/ssr-large-profile')
cases=[('adaptive-lag/node','adaptive-scheduling-node-tails','Small document, Node string. Adaptive policy trials scheduling after sustained lag and backs off if lag does not improve. Monitoring runs in both eXact controls. React is unchanged.'),('adaptive-lag/bun','adaptive-scheduling-bun-tails','Large document, native Bun string. Adaptive policy trials scheduling after sustained lag and backs off if lag does not improve. Monitoring runs in both eXact controls. React is unchanged.'),('serial-scheduler','serial-scheduling-bun-tails','Large document, native Bun string. Serial queue schedules only one pending callback and schedules the next bounded drain from inside it. Current queue can schedule several callbacks in one turn. React is unchanged.'),('serial-backlog-node','serial-scheduling-node-backlog','Large document, Node string, concurrency 256. Hypothesis: one pending callback, releasing at most 8 or 32 starts, lets networking progress under a backlog and may reduce tail latency; throughput may decrease. React is unchanged.')]
cases.append(('serial-wide-node','serial-scheduling-node-wide','Large document, Node string, concurrency 256. Hypothesis: bounded serial drains of 64 or 128 starts may recover throughput lost with 8 or 32 while retaining opportunities for other event-loop work. Compare the existing scheduler with unchanged React.'))
for folder,stem,intro in cases:
 root=base/folder
 if not (root/'capture.json').exists():continue
 d=json.loads((root/'capture.json').read_text())
 if not d['complete']:continue
 report=Path('docs/performance-baselines')/(stem+'-2026-09-11.md')
 if report.exists():continue
 lines=['# '+stem.replace('-',' ').capitalize(),'',intro,'','Diagnostic only, no production queue or adaptive policy change. Each response renders the application and authored shell with hydration; byte/hash identity is checked. Two load drivers report their own percentiles. The A / B values below are separate driver percentiles, not a pooled or averaged percentile. Repeated controls expose machine workload drift.','', '| Repeat | Framework | Policy | RPS | Response p95 A / B (ms) | Response p99 A / B (ms) | TTFB p99 A / B (ms) |','| --- | --- | --- | ---: | --- | --- | --- |']
 total=0
 for b in d['blocks']:
  total+=b['valid'];dist=[]
  for r in b['results']:
   s=r['stages'][0];assert s['errors']==0 and s['started']==s['completed']==s['valid'];dist.append(s['distributions'])
  def tails(key,p):return ' / '.join(f'{x[key][p]:.3f}' for x in dist)
  lines.append(f"| {b['population']+1} | {b['id']} | {b['phase']} | {b['rps']:,.0f} | {tails('responseMs','p95')} | {tails('responseMs','p99')} | {tails('ttfbMs','p99')} |")
 lines+=['',f'{total:,} complete measured responses, zero errors. Full capture includes mean, p50, max, CPU, event-loop metrics and telemetry. No percentile aggregation is possible from these summary-only captures.','']
 if folder=='adaptive-lag/node':lines+=['Adaptive scheduling improves throughput in both repeats, but this does not establish sparse-traffic overhead or sustained behavior under changing workloads. The prototype does not continuously reconsider a successful trial.','']
 if folder=='adaptive-lag/bun':lines+=['The controller disabled unsuccessful trials, but adaptive scheduling still lost throughput and worsened tails relative to immediate controls. Lag alone is insufficient to select the policy. Do not enable this prototype by default.','']
 if folder=='serial-scheduler':lines+=['Smaller serial batches reduce some p99 values relative to batches of 32, while losing throughput and increasing p95. Immediate rendering remains the better large-document Bun choice here. The signal-free prototype lacks production cancellation and scheduler-failure handling.','', 'Separate Node fairness probe: 1,024 queued starts, each doing approximately 0.05 ms of synchronous work. A timer armed by the first start ran after all 1,024 starts with the current scheduler, and after 32 with the serial prototype. This demonstrates timer fairness, not HTTP or socket latency.','']
 if folder=='serial-backlog-node':lines+=['Assess the bookended controls and both repeats before interpreting changes. This diagnostic stresses queue overflow that concurrency 32 cannot exercise for a 32-start limit. The prototype remains signal-free and cannot replace the production scheduler without lifecycle coverage.','']
 if folder=='serial-wide-node':lines+=['Serial 64 changes throughput by +1.55% and -5.84% relative to the current scheduler. Response p99 improves in repeat one and regresses in repeat two. Event-loop p99 consistently drops from roughly 63-64 ms to 26-27 ms. Serial 128 does not reliably improve response tails or event-loop delay. Neither variant is adopted.','', 'The separate 1,024-start timer probe observed 1,024 starts before the timer with the current scheduler, 64 with serial 64, and 128 with serial 128. This is timer fairness evidence, not measured network latency.','', 'Next investigation: separately measure scheduler queue wait and render/service time. A policy must account for end-to-end p95/p99 and throughput as well as loop lag. The current captures cannot identify each request\'s contribution to the latency tail.','']
 report.write_text('\n'.join(lines),encoding='utf8')
 files=[p for p in root.rglob('*') if p.is_file()]+[report,base/'scheduler-tail-report.py']
 extras={'adaptive-lag/node':['adaptive-controller.mjs','adaptive-build.py','adaptive-node-run.mjs'],'adaptive-lag/bun':['adaptive-controller.mjs','adaptive-build.py','adaptive-bun-run.mjs'],'serial-scheduler':['serial-build.py','serial-scheduler-run.mjs','serial-fairness.mjs'],'serial-backlog-node':['serial-backlog-build.py','serial-backlog-node-run.mjs'],'serial-wide-node':['serial-wide-build.py','serial-wide-node-run.mjs']}[folder]
 files += [base/p for p in extras]
 if folder=='serial-wide-node':files += [base/'serial-wide-fairness.mjs',base/'check-tail-captures.py',base/'scheduler-next-step.py']
 archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
 manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
  for p in files:z.write(p,p.as_posix())
  z.writestr('SHA256.json',json.dumps(manifest,indent=2))
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
 print(report,total,'responses, verified archive')
