import fs from 'node:fs';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';const hashes={};
for(const runtime of ['node','bun']){
 const path=`framework-comparison/participants/exact/${runtime==='node'?'dist-server/server-entry.js':'dist-bun-server/bun-server-entry.js'}`;const source=fs.readFileSync(path,'utf8');assert.equal(createHash('sha256').update(source).digest('hex'),runtime==='node'?'2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18':'9adc04f4d5d6e78ad95730319a475918c3b4b045da9a93f812c81aa827d60d2e');
 const start=source.indexOf('\tconst compacted =',source.indexOf('function renderHydrationScriptValue(')),end=source.indexOf('\n\tconst payload =',start);assert.ok(start>0&&end>start);
 const body=source.slice(start,end).replace('const compacted =','compacted =').replace('\n\tlet reactiveCollections;','');
 const front='let auditValidatedGraph;\n'+source.slice(0,start)+`let compacted, reactiveCollections;
 if(auditValidatedGraph!==undefined)compacted=auditValidatedGraph;
 else {${body}
 if(reactiveCollections!==undefined)throw new Error('Diagnostic requires no reactive collection encoding');
 auditValidatedGraph=compacted;
 }`+source.slice(end);
 const begin=source.indexOf('function renderHydrationScriptValue('),ret=source.indexOf('return `${prefix}${payload}${suffix}`;',begin);assert.ok(ret>begin);
 let tail=source.slice(0,ret)+source.slice(ret).replace('return `${prefix}${payload}${suffix}`;','return auditSerializedScript = `${prefix}${payload}${suffix}`;');
 tail='let auditSerializedScript;\n'+tail.slice(0,end)+'\n if(auditSerializedScript!==undefined)return auditSerializedScript;'+tail.slice(end);
 for(const [variant,code] of Object.entries({front,tail})){const folder=root+`stage-hydration-${variant}-${runtime}`;fs.mkdirSync(folder,{recursive:true});fs.writeFileSync(folder+'/server-entry.js',code);hashes[runtime+'-'+variant]=createHash('sha256').update(code).digest('hex');}
}
fs.writeFileSync(root+'stage-hydration-parts-build.json',JSON.stringify(hashes,null,2));
let driver=fs.readFileSync(root+'stage-hydration-interleaved.mjs','utf8');
const start=driver.indexOf('const orders='),end=driver.indexOf('\n',start);driver=driver.slice(0,start)+"const orders=[['normal','front','tail','diagnostic'],['diagnostic','tail','front','normal'],['front','diagnostic','normal','tail'],['tail','normal','diagnostic','front'],['normal','tail','front','diagnostic'],['diagnostic','front','tail','normal']];"+driver.slice(end);
driver=driver.replace("['normal','diagnostic','react']","['normal','front','tail','diagnostic']");driver=driver.replace("const id=variant==='react'?'react':'exact';","const id='exact';");driver=driver.replace("variant==='diagnostic'?root+'stage-hydration-'+runtime.id+'/server-entry.js':", "variant==='diagnostic'?root+'stage-hydration-'+runtime.id+'/server-entry.js':variant==='front'||variant==='tail'?root+`stage-hydration-${variant}-${runtime.id}/server-entry.js`:");driver=driver.replaceAll('stage-hydration-interleaved','stage-hydration-parts').replace('rows.length,36','rows.length,48');fs.writeFileSync(root+'stage-hydration-parts.mjs',driver);console.log(hashes);
