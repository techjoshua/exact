import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
const d='.tmp/ssr-large-profile/';
let audit=fs.readFileSync(d+'hydration-tail-audit.mjs','utf8');
audit=audit.replaceAll('./hydration-tail-entry.mjs','./publication-markers-candidate-entry.mjs').replaceAll('./hydration-tail-fixture.mjs','./publication-markers-candidate-fixture.mjs');
audit=audit.replace('./publication-stages-sink.mjs','./incremental-publication-pressure.mjs').replace('markers:false','markers:true');
audit=audit.replace("html.replace(envelope,'').replace(","html.replace(envelope,'').replace(/<!--\\/?exact:component:[^>]*-->/g,'').replace(");
audit=audit.replace("/hydration-tail-'","/publication-markers-pressure-'");
fs.writeFileSync(d+'publication-markers-pressure-audit.mjs',audit);
const rows=[];
for(const runtime of ['node','bun']) {
 const result=spawnSync(runtime,[d+'publication-markers-pressure-audit.mjs'],{encoding:'utf8',windowsHide:true});
 rows.push({runtime,status:result.status,stdout:result.stdout,stderr:result.stderr});
 console.log(runtime,result.status,result.stdout.trim());
}
fs.writeFileSync(d+'publication-markers-pressure-results.json',JSON.stringify(rows,null,2));
if(rows.some(row=>row.status!==0))throw Error('Marker pressure audit failed');
