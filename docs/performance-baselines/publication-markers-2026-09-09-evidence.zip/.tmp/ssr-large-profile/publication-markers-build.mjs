import fs from 'node:fs';
import {transform} from 'esbuild';
const d='.tmp/ssr-large-profile/';
const response=JSON.parse(fs.readFileSync(d+'compiled-stages-compile.json','utf8')).response;
let fixture=(await transform(response.code,{loader:'ts',format:'esm',target:'esnext'})).code;
const issuer='issueServerComponentReceipt as __exactIssueServerComponent, ';
if(!fixture.includes(issuer))throw Error('Missing issuer');
fixture=fixture.replace(issuer,'');
fixture='import {issueServerComponentReceipt as __exactIssueServerComponent} from "./publication-markers-control-entry.mjs";\n'+fixture;
fs.writeFileSync(d+'publication-markers-control-fixture.mjs',fixture);
const entry=fs.readFileSync('framework-comparison/participants/exact/dist-server/server-entry.js','utf8');
fs.writeFileSync(d+'publication-markers-control-entry.mjs',entry+'\nexport {createSsrContext,SsrOperationTarget,renderChildren,createPreparedServerComponentReference,createSsrResumptionCapture,renderHydrationScript};\nexport function issueServerComponentReceipt(component){activeComponentIssuer?.(component);return component;}\n');
// Reuse the cancellation-corrected experimental runtime, preserving the same fixture issuer.
fs.writeFileSync(d+'publication-markers-candidate-entry.mjs',fs.readFileSync(d+'publication-abort-entry.mjs','utf8'));
fs.writeFileSync(d+'publication-markers-candidate-fixture.mjs',fs.readFileSync(d+'hydration-tail-fixture.mjs','utf8').replace('./hydration-tail-entry.mjs','./publication-markers-candidate-entry.mjs'));
