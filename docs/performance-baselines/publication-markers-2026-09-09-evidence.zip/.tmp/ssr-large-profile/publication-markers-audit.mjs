import fs from 'node:fs';
import assert from 'node:assert/strict';
import {PublicationStringSink} from './publication-string-sink.mjs';
import {HydrationTailSink} from './hydration-tail-sink.mjs';
const [variant]=process.argv.slice(2);
const runtime=await import(`./publication-markers-${variant}-entry.mjs`);
const fixture=await import(`./publication-markers-${variant}-fixture.mjs`);
const rows=[];
for(const markers of [false,true]) {
 fixture.reset();fixture.settle();
 const capture=runtime.createSsrResumptionCapture({markers});
 const context=runtime.createSsrContext(capture.options);
 const collector=new PublicationStringSink();const sink=new HydrationTailSink(collector);
 if(variant==='candidate')context.experimentalSink=sink;
 const root=runtime.createPreparedServerComponentReference(fixture.StagedDocument,{});
 const target=new runtime.SsrOperationTarget(context,undefined,capture.options,false,runtime.renderChildren);
 let html,error;
 try {
  html=await target.renderCompilerClosedRootComponent(root);
  const script=()=>runtime.renderHydrationScript({state:{note:'test'}},undefined,capture.serializedRecords());
  if(variant==='candidate'){await sink.finishHydration(script);html=collector.value;}
  else html=html.replace('</body></html>','<!--exact:framework-body:start-->'+script()+'<!--exact:framework-body:end--></body></html>');
 } catch(reason){error={name:reason.name,message:reason.message};}
 finally{sink.destroy();fixture.settle();}
 assert.deepEqual([...fixture.disposedIndices].sort(),[1,2]);
 rows.push({markers,html,error,records:capture.serializedRecords()});
}
fs.writeFileSync(`.tmp/ssr-large-profile/publication-markers-${variant}-${process.versions.bun?'bun':'node'}.json`,JSON.stringify(rows,null,2));
console.log(JSON.stringify(rows.map(({markers,error,html})=>({markers,error,bytes:html?Buffer.byteLength(html):undefined}))));
