import {issueServerComponentReceipt as __exactIssueServerComponent} from "./publication-markers-control-entry.mjs";
import { createPreparedServerComponentReference as __exactComponentReceipt, createPreparedServerRenderProgram as __exactPreparedServerRenderProgram, prepareCompiledRenderProgram as __exactPrepareRenderProgram } from "@exactjs/core/framework/server-render-structure";
import { registerDirectSsrLifecycleHandler as __exactRegisterDirectSsrLifecycle } from "@exactjs/ssr/runtime/direct-lifecycle";
import { awaitServerComponentTask as __exactServerTaskAwait, activateServerComponentTaskForHost as __exactActivateServerTask } from "@exactjs/core/framework/server-component-execution";
import "@exactjs/ssr/runtime/resumption-boundaries";
import { issueExactServerComponent as __exactIssueServerComponent_1, writeExactServerComponent as __exactWriteServerComponent_1, disposeExactServerComponent as __exactDisposeServerComponent_1 } from "@exactjs/core/runtime/component-operations";
import { rejectDirectServerComponentConstruction as __exactRejectDirectServerConstruction_1 } from "@exactjs/core/runtime/component-construction/direct-server";
import { directSsrLifecycle as __exactDirectSsrLifecycle_1 } from "@exactjs/ssr/runtime/direct-lifecycle";
const __exactComponentContract_1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
const __exact_server_task_slice_1 = [[], [[0, ["ready"]]], "blocking", "load"];
const __exact_render_program_1 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xyda4TWT669byiGLD-mai3B", namespace: "html", ssrRootStatic: ["", [], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
  const __exactValue_0 = __exactInvocation.eagerValues[0];
  const __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
  if (__exactValue_1 === __exactSsr.unprepared)
    return;
  __exactSsr.begin(__exactContext, 1, 2, 17, 17);
  const __exactOutput = __exactSsr.output();
  let __exactCharacters = 17;
  __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "strong", "<strong", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
  __exactCharacters = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "", "</strong>");
  return __exactOutput;
}, ssrHost: "strong" });
const __exact_render_program_2 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xREvbf4MdoqzCYQNvHBD-zN", namespace: "html", ssrRootStatic: [' rel="stylesheet"', ["rel"], [[3, "href", "href"]], (__exactRootValue) => ({ rel: "stylesheet", href: __exactRootValue })], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
  const __exactValue_0 = __exactInvocation.eagerValues[0];
  __exactSsr.begin(__exactContext, 1, 1, 6, 6);
  const __exactOutput = __exactSsr.output();
  let __exactCharacters = 6;
  __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "link", "<link", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
  return __exactOutput;
}, ssrHost: "link" });
const __exact_render_program_3 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "x_jFG2fADUttvo4hq8wQSwF", namespace: "html", ssrRootStatic: [' data-exact-id="xJ7OubJrtYZA4m5kvKLxWBI"', ["data-exact-id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
  const __exactValue_0 = __exactInvocation.eagerValues[0];
  const __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
  if (__exactValue_1 === __exactSsr.unprepared)
    return;
  __exactSsr.begin(__exactContext, 1, 2, 13, 13);
  const __exactOutput = __exactSsr.output();
  let __exactCharacters = 13;
  __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "head", "<head", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
  __exactSsr.keyedChild(__exactOutput, __exactValue_1);
  __exactSsr.static(__exactOutput, "</head>");
  return __exactOutput;
}, ssrHost: "head" });
const __exact_render_program_4 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "x6mdj3UyMwtc8bFCtagnH42", namespace: "html", ssrRootStatic: [' data-exact-id="xLEWf_zC-gv8BLmuzjS4iJe"', ["data-exact-id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
  const __exactValue_0 = __exactInvocation.eagerValues[0];
  const __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
  if (__exactValue_1 === __exactSsr.unprepared)
    return;
  const __exactValue_2 = __exactSsr.prepareChild(__exactInvocation, 2);
  if (__exactValue_2 === __exactSsr.unprepared)
    return;
  __exactSsr.begin(__exactContext, 1, 3, 13, 13);
  const __exactOutput = __exactSsr.output();
  let __exactCharacters = 13;
  __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "body", "<body", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
  __exactSsr.keyedChild(__exactOutput, __exactValue_1);
  __exactSsr.keyedChild(__exactOutput, __exactValue_2);
  __exactSsr.static(__exactOutput, "</body>");
  return __exactOutput;
}, ssrHost: "body" });
const __exact_render_program_5 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xG4hWs454E7EWwAs1ePH84a", namespace: "html", ssrRootStatic: [' data-exact-id="xDRLUmQOyTZScXAxK5t7N4o"', ["data-exact-id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
  const __exactValue_0 = __exactInvocation.eagerValues[0];
  const __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
  if (__exactValue_1 === __exactSsr.unprepared)
    return;
  const __exactValue_2 = __exactSsr.prepareChild(__exactInvocation, 2);
  if (__exactValue_2 === __exactSsr.unprepared)
    return;
  __exactSsr.begin(__exactContext, 1, 3, 13, 13);
  const __exactOutput = __exactSsr.output();
  let __exactCharacters = 13;
  __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "html", "<html", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
  __exactSsr.keyedChild(__exactOutput, __exactValue_1);
  __exactSsr.keyedChild(__exactOutput, __exactValue_2);
  __exactSsr.static(__exactOutput, "</html>");
  return __exactOutput;
}, ssrHost: "html" });
let starts = 0;
let disposals = 0;
let disposedIndices = [];
let release;
let gate;
function reset() {
  starts = 0;
  disposals = 0;
  disposedIndices = [];
  gate = new Promise((resolve) => release = resolve);
}
function settle() {
  release();
}
const __exactImplementation_ScheduledChild_1 = function ScheduledChild(props) {
  this.state.ready = false;
  __exactActivateServerTask(this, __exact_server_task_slice_1, "x7U2kFAzuTZMP6bz-f8fCru", async (_task) => {
    starts++;
    await __exactServerTaskAwait(_task.signal, gate);
    this.state.ready = true;
  });
  __exactRegisterDirectSsrLifecycle(this, "unmount", () => {
    disposals++;
    disposedIndices.push(props.index);
  });
  return () => __exactPreparedServerRenderProgram(__exact_render_program_1, [{}, this.state.ready ? "Ready " + props.index : "Waiting"]);
};
const ScheduledChild2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_ScheduledChild_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "x2va5QIiamUg_0vL5O6m3oC",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "executor",
    implementations: [
      { id: "xkkR9iHTZF0YwZ3F_oThE-7", name: "ScheduledChild", role: "root", implementation: __exactImplementation_ScheduledChild_1 }
    ],
    continuations: [
      {
        kind: "task",
        id: "x7U2kFAzuTZMP6bz-f8fCru",
        componentId: "x2va5QIiamUg_0vL5O6m3oC",
        readiness: "blocking",
        concurrency: "latest",
        dependencies: [],
        stateReads: [],
        stateWrites: [
          {
            path: "ready",
            kind: "write",
            confidence: "exact"
          }
        ],
        publicContexts: [],
        serverContexts: [],
        contextWrites: [],
        serverContextWrites: [],
        boundaries: []
      }
    ],
    executors: [
      {
        id: "x7U2kFAzuTZMP6bz-f8fCru",
        componentId: "x2va5QIiamUg_0vL5O6m3oC",
        execute: async (__exactActivation_1, __exactExecution_1) => {
          const __exactComponent_1 = { state: __exactActivation_1.state };
          const __exactContextWrites_1 = {};
          await (async (_task) => {
            starts++;
            await __exactServerTaskAwait(_task.signal, gate);
            __exactComponent_1.state.ready = true;
          })(__exactExecution_1.task);
          return { state: __exactComponent_1.state, contexts: __exactContextWrites_1 };
        }
      }
    ],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "x2va5QIiamUg_0vL5O6m3oC",
      instantiate: __exactImplementation_ScheduledChild_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 11,
      capabilities: [
        "tasks",
        "continuations",
        "resumption"
      ],
      state: [
        "ready"
      ],
      props: [
        "index"
      ],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "scheduled",
        lane: "direct",
        render: __exactImplementation_ScheduledChild_1,
        lifecycle: __exactDirectSsrLifecycle_1,
        publication: {
          kind: "resumption",
          name: "ScheduledChild"
        }
      },
      tasks: [
        "x7U2kFAzuTZMP6bz-f8fCru"
      ],
      reactive: [
        {
          name: "load",
          provenance: "unknown",
          allocation: "constant",
          dependencies: []
        },
        {
          name: "props",
          provenance: "props",
          allocation: "live-slot",
          dependencies: []
        },
        {
          name: "this",
          provenance: "state",
          allocation: "live-slot",
          dependencies: []
        }
      ],
      render: "returned-function"
    },
    resumption: {
      componentId: "x2va5QIiamUg_0vL5O6m3oC",
      statePaths: [
        "ready"
      ],
      stateInputs: [],
      valueCaptures: [],
      contexts: [],
      boundaries: [],
      stateDefaults: [
        [
          "ready",
          false
        ]
      ]
    }
  }
}))();
const __exactImplementation_StagedDocument_1 = function StagedDocument() {
  return __exactPreparedServerRenderProgram(__exact_render_program_5, [{ "data-exact-id": "xDRLUmQOyTZScXAxK5t7N4o" }, __exactPreparedServerRenderProgram(__exact_render_program_3, [{ "data-exact-id": "xJ7OubJrtYZA4m5kvKLxWBI" }, __exactPreparedServerRenderProgram(__exact_render_program_2, ["/app.css"])]), __exactPreparedServerRenderProgram(__exact_render_program_4, [{ "data-exact-id": "xLEWf_zC-gv8BLmuzjS4iJe" }, __exactIssueServerComponent(__exactComponentReceipt(ScheduledChild2, { index: 1 })), __exactIssueServerComponent(__exactComponentReceipt(ScheduledChild2, { index: 2 }))])]);
};
const StagedDocument2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_StagedDocument_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "xqbcuAeJlheXbzwjrm7Dkfq",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "executor",
    implementations: [
      { id: "xMr9n2gCvCj_IuU54CDTpmh", name: "StagedDocument", role: "root", implementation: __exactImplementation_StagedDocument_1 }
    ],
    continuations: [],
    executors: [],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "xqbcuAeJlheXbzwjrm7Dkfq",
      instantiate: __exactImplementation_StagedDocument_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 1,
      capabilities: [],
      state: [],
      props: [],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "synchronous",
        lane: "direct",
        render: __exactImplementation_StagedDocument_1,
        mode: "stateless"
      },
      tasks: [],
      reactive: [],
      render: "returned-function"
    }
  }
}))();
export {
  ScheduledChild2 as ScheduledChild,
  StagedDocument2 as StagedDocument,
  disposals,
  disposedIndices,
  reset,
  settle,
  starts
};
