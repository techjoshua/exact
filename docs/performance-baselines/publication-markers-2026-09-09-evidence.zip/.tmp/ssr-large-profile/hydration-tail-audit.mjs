import {HydrationTailSink} from './hydration-tail-sink.mjs';
import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {PublicationPressureSink} from './publication-stages-sink.mjs';
import * as runtime from './hydration-tail-entry.mjs';
import * as fixture from './hydration-tail-fixture.mjs';
const rows=[];
for(const threshold of [1,8,8192])for(const abort of [false,true]){
 fixture.reset();const events=[];let release,done=false,resultError,outputBytes;
 const controller=new AbortController(),baseOptions={markers:false,signal:controller.signal};
 const capture=runtime.createSsrResumptionCapture(baseOptions);const options=capture.options;
 const bytesSink=new PublicationPressureSink((bytes,reason)=>{
  assert.equal(release,undefined,'only one outstanding transport write');
  events.push({reason,text:new TextDecoder().decode(bytes)});
  return new Promise(resolve=>{release=()=>{release=undefined;resolve();};});
 },{threshold,maxBytes:4096,signal:controller.signal});
 const sink=new HydrationTailSink(bytesSink);let hydrationScript,serializations=0;
 const context=runtime.createSsrContext(options);context.experimentalSink=sink;
 const target=new runtime.SsrOperationTarget(context,undefined,options,false,runtime.renderChildren);
 const root=runtime.createPreparedServerComponentReference(fixture.StagedDocument,{});
 const rendering=Promise.resolve(target.renderCompilerClosedRootComponent(root)).then(()=>sink.finishHydration(()=>{serializations++;hydrationScript=runtime.renderHydrationScript({state:{note:'</script><script>bad()</script>\u2028'}},undefined,capture.serializedRecords());return hydrationScript;})).then(bytes=>{outputBytes=bytes;done=true;},error=>{resultError=error;done=true;});
 let cancelled=false;
 try{
  for(let turn=0;turn<500&&!done;turn++){
   await Promise.resolve();
   if(fixture.starts===2)fixture.settle();
   if(release){
    if(abort&&fixture.starts===2&&!cancelled){cancelled=true;controller.abort();}
    else if(!cancelled)release();
   }
  }
  assert.equal(done,true,'drain protocol reaches completion');await rendering;
  if(abort){assert.equal(resultError?.name,'AbortError');assert.equal(cancelled,true);}
  else{
   assert.equal(resultError,undefined);
   const html=events.map(e=>e.text).join('');
   assert.equal(serializations,1);
   const envelope='<!--exact:framework-body:start-->'+hydrationScript+'<!--exact:framework-body:end-->';
   assert.ok(html.endsWith(envelope+'</body></html>'));
   assert.ok(!hydrationScript.includes('</script><script>bad()'));
   const payload=hydrationScript.match(/<script[^>]*>([\s\S]*)<\/script>/)[1];JSON.parse(payload);
   assert.equal(html.replace(envelope,'').replace(/ data-exact-id="[^"]+"/g,''),'<!doctype html><html><head><link rel="stylesheet" href="/app.css"></head><body><strong>Ready 1</strong><strong>Ready 2</strong></body></html>');
   assert.equal(outputBytes,Buffer.byteLength(html));
   assert.equal(capture.serializedRecords().length,2);
  }
  assert.deepEqual([...fixture.disposedIndices].sort(),[1,2]);assert.deepEqual(context.hostStack,[]);
  rows.push({serializations,threshold,abort,chunks:events.length,events,disposedIndices:fixture.disposedIndices});
 }finally{controller.abort();fixture.settle();release?.();sink.destroy();}
}
writeFileSync('.tmp/ssr-large-profile/hydration-tail-'+(process.versions.bun?'bun':'node')+'.json',JSON.stringify(rows,null,2));
console.log(rows.map(({threshold,abort,chunks})=>({threshold,abort,chunks})));
