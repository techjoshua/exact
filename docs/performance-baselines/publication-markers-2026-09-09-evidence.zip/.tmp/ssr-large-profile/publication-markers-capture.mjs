import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
let source=fs.readFileSync(d+'publication-markers-candidate-entry.mjs','utf8');
const signature='function renderComponentReference(context, component, parent, options, hasComponentAncestor, omitCompilerOwnedBoundary = false, omitRootBoundary = false) {';
if(source.split(signature).length!==2)throw Error('Missing component entry');
source=source.replace(signature,`${signature}
 if(context.markers&&context.experimentalSink&&!omitRootBoundary){
  const prior=context.experimentalSink;
  context.experimentalSink={value:'',componentCapture:true};
  const captured=context.experimentalSink;
  return withRenderCleanup(()=>mapRenderValue(renderCapturedComponentReference(context,component,parent,options,hasComponentAncestor,omitCompilerOwnedBoundary,omitRootBoundary),html=>captured.value+html),()=>{context.experimentalSink=prior;});
 }
 return renderCapturedComponentReference(context,component,parent,options,hasComponentAncestor,omitCompilerOwnedBoundary,omitRootBoundary);
}
function renderCapturedComponentReference(context, component, parent, options, hasComponentAncestor, omitCompilerOwnedBoundary, omitRootBoundary) {`);
source=source.replace('if(context.experimentalSink&&(context.markers||','if(context.experimentalSink&&!context.experimentalSink.componentCapture&&(context.markers||');
source=source.replace('const resumable = publication?.kind === "resumption";',`if(context.experimentalSink?.componentCapture){html=context.experimentalSink.value+html;context.experimentalSink.value='';}
 const resumable = publication?.kind === "resumption";`);
source=source.replace('sink.value=appendBoundedHtml(this.context,sink.value,result.html);','appendSharedSink(this.context,sink,result.html);');
source=source.replace("sink.value=appendBoundedHtml(this.context,sink.value,'<!-- -->');","appendSharedSink(this.context,sink,'<!-- -->');");
fs.writeFileSync(d+'publication-markers-candidate-entry.mjs',source);
