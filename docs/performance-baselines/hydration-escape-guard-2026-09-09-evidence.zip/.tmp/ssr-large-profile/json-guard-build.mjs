import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';const source=readFileSync(dir+'callback-current.mjs','utf8');
const start=source.indexOf('function serializeJson(payload, replacer) {'),end=source.indexOf('\n}',start)+2;
if(start<0||end<start)throw Error('Missing serializer');
const replacement=String.raw`const needsScriptEscaping = /[<\u2028\u2029]/;
function serializeJson(payload, replacer) {
 const json = JSON.stringify(payload, replacer);
 return needsScriptEscaping.test(json) ? json.replace(/</g, "\\u003C").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029") : json;
}`;
writeFileSync(dir+'json-guard.mjs',source.slice(0,start)+replacement+source.slice(end));
const worker=readFileSync(dir+'long-worker.mjs','utf8');
writeFileSync(dir+'json-guard-worker.mjs',worker.replace('const render=()=>',String.raw`if(scenario==='escaped')for(const row of data.incidents)row.title+=' </script><script>alert("x")</script>\u2028\u2029'.repeat(30);
const render=()=>`));
