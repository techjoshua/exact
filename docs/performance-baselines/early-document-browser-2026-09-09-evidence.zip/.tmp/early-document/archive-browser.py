from pathlib import Path
import hashlib
import json
import zipfile

root = Path.cwd()
report_path = root / 'docs/performance-baselines/early-document-browser-2026-09-09.json'
report = json.loads(report_path.read_text(encoding='utf-8'))
target = report_path.with_name('early-document-browser-2026-09-09-evidence.zip')
for ancestor in [target, target.parent, *target.parent.parents]:
    if ancestor.is_symlink() or ancestor.is_junction():
        raise RuntimeError(f'Linked evidence path: {ancestor}')
files = set()
for name in ['browser-benchmark.mjs', 'browser-benchmark-header.mjs',
             'prepare-browser-benchmark.mjs', 'summarize-browser.mjs',
             'browser-performance.json', 'browser-summary.json', 'archive-browser.py']:
    files.add(root / '.tmp/early-document' / name)
for entry in report['evidence']:
    path = root / entry['entry']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['entrySha256']
    files.add(path)
    participant = 'react' if entry['id'] == 'react' else 'exact'
    for asset in entry['assets']:
        path = root / 'framework-comparison/participants' / participant / 'dist' / asset['path'].lstrip('/')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == asset['sha256']
        files.add(path)
for name in ['browser-memory.mjs', 'browser-vitals.mjs', 'paint-timing.mjs', 'artifact-integrity.mjs']:
    files.add(root / 'framework-comparison/src' / name)
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(files):
        archive.write(path, path.relative_to(root).as_posix())
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
report['evidenceArchive'] = {'path': target.relative_to(root).as_posix(), 'bytes': target.stat().st_size,
    'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}
report_path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report['evidenceArchive']))
