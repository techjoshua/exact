import {readFile,writeFile,readdir} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {createServer} from 'node:http';
import {once} from 'node:events';
import assert from 'node:assert/strict';
import {chromium} from 'playwright';
import {startComparisonServer} from '../../framework-comparison/src/server.mjs';
import {measureRetainedMemory} from '../../framework-comparison/src/browser-memory.mjs';
import {waitForFirstContentfulPaint} from '../../framework-comparison/src/paint-timing.mjs';
import {installBrowserVitals,readBrowserVitals} from '../../framework-comparison/src/browser-vitals.mjs';
import {hashSemanticResponse} from '../../framework-comparison/src/artifact-integrity.mjs';
const samples=Number(process.argv[2]??50),rows=[],evidence=[];
const participants=[
 {id:'baseline',port:4401,root:'framework-comparison/participants/exact',entry:'.tmp/post-shell-final/current-exact-node.mjs'},
 {id:'candidate',port:4406,root:'framework-comparison/participants/exact',entry:'.tmp/early-document/current-node.mjs'},
 {id:'react',port:4402,root:'framework-comparison/participants/react',entry:'framework-comparison/participants/react/dist-server/server-entry.js'}
];
let service,browser;const servers=[],active=new Set(),errors=[];
async function resetService(body){const r=await fetch('http://127.0.0.1:4310/__benchmark/reset',{method:'POST',headers:{'content-type':'application/json','x-benchmark-control':'fixture-reset'},body:JSON.stringify(body)});if(!r.ok)throw Error('Reset failed');}
function installReadinessTiming(){globalThis.__focusedReadyMs=null;new MutationObserver(()=>{if(globalThis.__focusedReadyMs===null&&document.querySelector('.connection')?.textContent.includes('Live service'))globalThis.__focusedReadyMs=performance.now();}).observe(document,{childList:true,characterData:true,subtree:true});}
try {
 service=await startComparisonServer();const snapshot=service.service.store.snapshot();
 const data={incidents:snapshot.incidents,users:snapshot.users,sessionUserId:snapshot.sessionUserId};let expectedExact;
 for(const p of participants){
  p.url='http://127.0.0.1:'+p.port;const dir=resolve(p.root,'dist'),resources=new Map();
  const index=await readFile(dir+'/index.html','utf8');const clientTags=index.match(/(?:<script[^>]+src="[^"]+"[^>]*><\/script>|<link[^>]+href="[^"]+"[^>]*>)/g)?.join('\n')??'';
  const mod=await import(pathToFileURL(resolve(p.entry)));
  async function visit(path,prefix=''){for(const ent of await readdir(path,{withFileTypes:true})){if(ent.name.startsWith('.')||/\.(map|gz|br)$/.test(ent.name))continue;const key=prefix+'/'+ent.name;if(ent.isDirectory())await visit(path+'/'+ent.name,key);else resources.set(key,await readFile(path+'/'+ent.name));}}
  await visit(dir);
  const render=()=>mod.renderParticipantStream(data,'/incidents/inc-100',{clientTags});
  const html=Buffer.from(await new Response(await render()).arrayBuffer());
  assert.match(html.toString(),/^<!doctype html>/i);assert.match(html.toString(),/<\/body><\/html>$/i);
  if(p.id==='baseline')expectedExact=html;if(p.id==='candidate')assert.deepEqual(html,expectedExact);
  const record={id:p.id,entry:p.entry,entrySha256:createHash('sha256').update(await readFile(p.entry)).digest('hex'),htmlBytes:html.length,htmlSha256:createHash('sha256').update(html).digest('hex'),assets:[...resources].map(([path,body])=>({path,bytes:body.length,sha256:createHash('sha256').update(body).digest('hex')})),requests:[]};evidence.push(record);
  const server=createServer((req,res)=>{
   const path=new URL(req.url,p.url).pathname;
   if(path!=='/incidents/inc-100'){const body=resources.get(path);if(!body){errors.push('Missing resource '+path);res.writeHead(404);res.end();return;}res.writeHead(200,{'content-type':({'.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml'})[extname(path)]??'application/octet-stream','cache-control':'no-store','content-length':body.length});res.end(body);return;}
   const task=(async()=>{const reader=(await render()).getReader();const hash=createHash('sha256');let bytes=0,chunks=0;
    res.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-store'});
    try{while(true){const next=await reader.read();if(next.done)break;hash.update(next.value);bytes+=next.value.byteLength;chunks++;if(!res.write(next.value))await once(res,'drain');}res.end();
     const digest=hash.digest('hex');assert.equal(bytes,record.htmlBytes);assert.equal(digest,record.htmlSha256);record.requests.push({bytes,chunks,sha256:digest});
    }finally{await reader.cancel();}
   })();active.add(task);task.catch(e=>{errors.push(String(e));res.destroy(e);}).finally(()=>active.delete(task));
  });servers.push(server);await new Promise((r,j)=>{server.once('error',j);server.listen(p.port,'127.0.0.1',r);});
 }
 browser=await chromium.launch();
 for(const profile of ['local','constrained'])for(let round=-1;round<samples;round++){
  const offset=(round+3)%3;const order=[...participants.slice(offset),...participants.slice(0,offset)];
  for(const p of order){p.profile=profile;const result=await measureBrowserSample(browser,p);if(round>=0)rows.push({id:p.id,profile,round,...result});}
  assert.deepEqual(errors,[]);if(round>=0){console.log(profile,round+1);await writeFile('.tmp/early-document/browser-performance.json',JSON.stringify({samples,method:'Actual production streaming render per navigation; same transport for all participants; no artificial hydration delay; fresh contexts, disabled cache, rotating order. Constrained: 4x CPU, 40ms CDP latency, 10Mbps each direction.',rows,evidence},null,2));}
 }
} finally {await browser?.close();for(const server of servers)server.closeAllConnections();await Promise.allSettled([...active]);await Promise.all(servers.map(s=>new Promise(r=>s.close(r))));await service?.close();}
