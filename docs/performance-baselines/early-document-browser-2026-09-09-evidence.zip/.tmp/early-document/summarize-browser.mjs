import {readFile,writeFile,copyFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const capture=JSON.parse(await readFile('.tmp/early-document/browser-performance.json','utf8'));
const metrics={FCP:r=>r.navigation.firstContentfulPaintMs,LCP:r=>r.vitals.largestContentfulPaintMs,readiness:r=>r.readyMs,navigation:r=>r.navigation.durationMs,CSSstart:r=>Math.min(...r.navigation.resources.filter(v=>/\.css(?:$|\?)/.test(v.name)).map(v=>v.startTime)),responseEnd:r=>r.navigation.responseEndMs,optimistic:r=>r.optimisticFeedbackMs,settlement:r=>r.settlementMs};
const mean=a=>a.reduce((s,v)=>s+v,0)/a.length;
const stats=a=>{const sorted=[...a].sort((a,b)=>a-b);return {mean:mean(a),median:sorted[Math.floor(sorted.length/2)],p95:sorted[Math.ceil(sorted.length*.95)-1]};};
const summary=[];
for(const profile of ['local','constrained'])for(const [metric,read] of Object.entries(metrics)){
 const groups=Object.fromEntries(['baseline','candidate','react'].map(id=>[id,capture.rows.filter(r=>r.profile===profile&&r.id===id).sort((a,b)=>a.round-b.round)]));
 for(const rows of Object.values(groups)){assert.equal(rows.length,capture.samples);assert.ok(rows.every(r=>Number.isFinite(read(r))));}
 const diffs=groups.candidate.map((r,i)=>read(r)-read(groups.baseline[i]));const delta=mean(diffs),sd=Math.sqrt(diffs.reduce((s,d)=>s+(d-delta)**2,0)/(diffs.length-1)),margin=1.96*sd/Math.sqrt(diffs.length);
 summary.push({profile,metric,...Object.fromEntries(Object.entries(groups).map(([id,rows])=>[id,stats(rows.map(read))])),pairedCandidateMinusBaselineMs:{mean:delta,approximate95PercentInterval:[delta-margin,delta+margin]}});
}
assert.equal(new Set(capture.rows.map(r=>r.responseHash)).size,1);
const [baseline,candidate]=capture.evidence;assert.equal(baseline.htmlSha256,candidate.htmlSha256);assert.deepEqual(baseline.assets,candidate.assets);
for(const entry of capture.evidence)assert.equal(entry.requests.length,2*(capture.samples+1));
capture.summary=summary;
await writeFile('docs/performance-baselines/early-document-browser-2026-09-09.json',JSON.stringify(capture,null,2)+'\n');
const table=summary.filter(r=>['FCP','LCP','readiness','navigation','CSSstart'].includes(r.metric)).map(r=>`| ${r.profile} | ${r.metric} | ${r.baseline.mean.toFixed(2)} | ${r.candidate.mean.toFixed(2)} | ${r.react.mean.toFixed(2)} | ${r.pairedCandidateMinusBaselineMs.mean.toFixed(2)} |`).join('\n');
await writeFile('.tmp/early-document/browser-summary.json',JSON.stringify(summary,null,2));
console.log(table);
console.log(JSON.stringify(summary.filter(r=>['FCP','LCP','readiness'].includes(r.metric)).map(r=>({profile:r.profile,metric:r.metric,delta:r.pairedCandidateMinusBaselineMs})),null,2));
