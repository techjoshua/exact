import {readFile,writeFile} from 'node:fs/promises';
const old=await readFile('.tmp/post-shell-optimization/client-round.mjs','utf8');
let functions=old.slice(old.indexOf('async function measureBrowserSample'));
functions=functions.replace("await session.send('Performance.enable');", `await session.send('Performance.enable');
        if(participant.profile==='constrained') {
            await session.send('Emulation.setCPUThrottlingRate',{rate:4});
            await session.send('Network.emulateNetworkConditions',{offline:false,latency:40,downloadThroughput:1250000,uploadThroughput:1250000});
        }`);
functions=functions.replace('durationMs: entry?.duration ?? null,', `durationMs: entry?.duration ?? null,
                responseStartMs: entry?.responseStart ?? null,
                responseEndMs: entry?.responseEnd ?? null,
                resources: performance.getEntriesByType('resource').filter(r=> /\\.(css|js)(?:$|\\?)/.test(r.name)).map(r=>({name:r.name,startTime:r.startTime,responseEnd:r.responseEnd})),`);
const header=await readFile('.tmp/early-document/browser-benchmark-header.mjs','utf8');
await writeFile('.tmp/early-document/browser-benchmark.mjs',header+'\n'+functions);
