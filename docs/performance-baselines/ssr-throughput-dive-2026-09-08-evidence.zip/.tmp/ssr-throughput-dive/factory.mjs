import {createExactProducedResponse as before,exactResponseBodyOf} from '../../packages/server/dist/response-body.js';
import {createExactProducedResponse as grouped} from './grouped-response.mjs';
import {writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const headers={'content-type':'text/html'};
const produce=write=>write('hello');
const operations={before,grouped};
for(const make of Object.values(operations)){
 const value=make(200,headers,produce);
 assert.deepEqual(Object.keys(value),['status','headers','body','stream']);
 assert.equal(exactResponseBodyOf(value).toText(),'hello');
}
let consumed=0;const samples=[];
for(let round=0;round<12;round++)for(const name of round%2?['grouped','before']:['before','grouped']){
 const begin=performance.now();for(let i=0;i<100000;i++){const value=operations[name](200,headers,produce);consumed+=exactResponseBodyOf(value).toText().length;}
 samples.push({round,name,us:(performance.now()-begin)/100});
}
const means=Object.fromEntries(Object.keys(operations).map(name=>[name,samples.filter(s=>s.name===name).reduce((sum,s)=>sum+s.us,0)/12]));
console.log(means);
await writeFile('.tmp/ssr-throughput-dive/factory.json',JSON.stringify({means,samples,consumed},null,2));
