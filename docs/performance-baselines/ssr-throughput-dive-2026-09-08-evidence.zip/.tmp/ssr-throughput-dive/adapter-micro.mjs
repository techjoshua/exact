import {readFile,writeFile} from 'node:fs/promises';
import {renderParticipantToSink} from './exact-before.js';
import {createExactProducedResponse} from '../../packages/server/dist/response-body.js';
import {writeNodeResponse as original} from '../../framework-adapters/node-adapter/dist/handler.js';
import {writeNodeResponse as synchronous} from './sync-adapter.mjs';
const data=JSON.parse(await readFile('.tmp/ssr-paired-profile/data.json','utf8'));
let consumed=0;
const response={statusCode:200,setHeader(){},end(value){consumed+=value.length;}};
const headers={'content-type':'text/html'};
const produce=(write,environment)=>{write('<html>');renderParticipantToSink(data,'/incidents/inc-101',write,environment?.encodedByteLength);write('</html>');};
const operations={
 original:()=>original(response,createExactProducedResponse(200,headers,produce)),
 synchronous:()=>synchronous(response,createExactProducedResponse(200,headers,produce)),
 direct:()=>{let value='<html>';renderParticipantToSink(data,'/incidents/inc-101',chunk=>value+=chunk,Buffer.byteLength);response.end(value+'</html>');},
 wrappedCounter:()=>{let value='<html>';renderParticipantToSink(data,'/incidents/inc-101',chunk=>value+=chunk,s=>Buffer.byteLength(s));response.end(value+'</html>');}
};
const samples=[];const names=Object.keys(operations);
for(const op of Object.values(operations))for(let i=0;i<10000;i++)await op();
for(let round=0;round<12;round++)for(const name of round%2?[...names].reverse():names){const start=performance.now();for(let i=0;i<5000;i++)await operations[name]();samples.push({round,name,us:(performance.now()-start)/5});}
const means=Object.fromEntries(names.map(name=>[name,samples.filter(s=>s.name===name).reduce((sum,s)=>sum+s.us,0)/12]));
console.log(means);
await writeFile('.tmp/ssr-throughput-dive/adapter-micro.json',JSON.stringify({means,samples,consumed},null,2));
