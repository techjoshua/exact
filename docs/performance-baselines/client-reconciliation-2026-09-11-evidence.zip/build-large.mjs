﻿import {createRequire} from 'node:module';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {exact} from '@exactjs/vite-plugin';
const require=createRequire(resolve('framework-comparison/package.json'));const {build}=await import(pathToFileURL(require.resolve('vite')).href);
for(const variant of ['claims-only','template']){
 let changed=0;
 await build({configFile:false,logLevel:'warn',plugins:[{name:'template-experiment',enforce:'pre',transform(code,id){if(variant==='claims-only'&&id.replaceAll('\\','/').endsWith('/dom/dist/client/renderer/render-program-template.js')){if(!code.includes('state.uses > 0'))throw Error('Unexpected template source');changed++;return code.replace('state.uses > 0','state.uses > 1');}}},exact({target:'client',renderMode:'client'})],build:{outDir:resolve('.tmp/client-membership/large-'+variant),emptyOutDir:true,minify:false,target:'es2022',rollupOptions:{input:resolve('scripts/performance-fixtures/client-scenarios.tsx'),preserveEntrySignatures:'strict',output:{entryFileNames:'fixture.js'}}}});
 if(variant==='claims-only'&&changed!==1)throw Error('Expected one template override, got '+changed);
}
