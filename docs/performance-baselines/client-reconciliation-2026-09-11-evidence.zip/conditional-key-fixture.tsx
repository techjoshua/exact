import type { Component, RootLifecycle } from '@exactjs/core';

let owner: Component<{ links: boolean; reversed: boolean }>;
let lifecycle: RootLifecycle<Element>;

/** Exercises component-root publication after several keyed ranges change together. */
export function KeyedRoot(this: Component<{ links: boolean; reversed: boolean }>) {
	owner = this;
	this.state.links = false;
	this.state.reversed = false;
	lifecycle = this.refs.root();
	return () =>
		this.map(
			this.state.reversed ? ['b', 'a'] : ['a', 'b'],
			(id) => id,
			(id) => (this.state.links ? <a>{id}</a> : <button>{id}</button>),
			'root-rows'
		);
}

/** Returns the mounted fixture's state and observable root lifecycle. */
export function keyedRootState() {
	return { owner, lifecycle };
}
