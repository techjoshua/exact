import {spawn} from 'node:child_process';
import {openSync,closeSync} from 'node:fs';
const args=process.argv.slice(2);const mode=args[0]??'profile';
const log=openSync(`.tmp/client-membership/${args.join('-').replaceAll('*','all')||mode}${process.env.AUDIT_VARIANT?'-'+process.env.AUDIT_VARIANT:''}${process.env.AUDIT_LABEL?'-'+process.env.AUDIT_LABEL:''}.log`,'w');
try{await new Promise((yes,no)=>{const p=spawn(process.execPath,['.tmp/client-membership/audit.mjs',...args],{env:{...process.env,NODE_ENV:'production',...(mode==='trace'||mode==='bytecode'?{DEBUG:'pw:browser'}:{})},windowsHide:true,stdio:['ignore',log,log]});console.log('Audit process',p.pid,mode);p.once('error',no);p.once('exit',c=>c===0?yes():no(Error('Audit failed '+c)));});}finally{closeSync(log);}
console.log('Complete',mode);
