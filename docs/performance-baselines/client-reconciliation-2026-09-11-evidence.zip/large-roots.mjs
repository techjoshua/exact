import {createServer} from 'node:http';
import {readFile,writeFile} from 'node:fs/promises';
import {chromium} from 'playwright';
const root='.tmp/client-membership';const variants=['claims-only','roots'];
const bodies=Object.fromEntries(await Promise.all(variants.map(async v=>[v,await readFile(`${root}/large-${v}/fixture.js`)])));
const server=createServer((req,res)=>{const data=bodies[req.url.slice(1)];res.setHeader('content-type','text/javascript');res.setHeader('access-control-allow-origin','*');res.end(data??'');});
await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;const records=[];
try{
 browser=await chromium.launch();
 for(let round=0;round<10;round++)for(const v of round%2?[...variants].reverse():variants)for(const scenario of ['client.static-mount','client.dynamic-mount','client.keyed-list-mutations']){
  const context=await browser.newContext();try{
   const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
   const values=await page.evaluate(async ({url,scenario})=>{const m=await import(url);const samples=[];for(let i=0;i<4;i++)samples.push(await m.runClientScenario(scenario,{iterations:1000}));return samples;},{url:`http://127.0.0.1:${server.address().port}/${v}`,scenario});
   if(errors.length)throw Error(errors.join('\n'));records.push({round,variant:v,scenario,values});
  }finally{await context.close();}
 }
 await writeFile(`${root}/large-roots.json`,JSON.stringify({complete:true,version:browser.version(),records}));
}finally{await browser?.close();await new Promise(r=>server.close(r));}
