Client reconciliation evidence, baseline dca8dca3. Extract into .tmp/client-membership.
Frozen JS: baseline=current prior commit; membership=rejected small subscriber arrays; claims=membership plus claim cursor result; claims-only=claim cursor result with baseline membership; template=claims-only plus rejected eager cache; roots=claims-only plus per-child completion removal; keyed=retained final code including nested keyed completion deferral.
Small replay: AUDIT_LABEL=newname AUDIT_ROUNDS=10 node .tmp/client-membership/run-audit.mjs compare exact.
Profile separately: AUDIT_COMPARE_PROFILE=1 AUDIT_ROUNDS=6, run profile exact. Clear AUDIT_COMPARE_PROFILE afterward.
Bytecode: AUDIT_VARIANT=keyed AUDIT_ROUNDS=1 run bytecode exact *.
Large: node .tmp/client-membership/large-keyed.mjs replays frozen claims-only/keyed compiled fixtures. large-roots.mjs replays intermediate and large.mjs the rejected template experiment. Each owns and closes its HTTP server/browser. Scripts overwrite matching raw reports; copy evidence or change output labels first.
Production build requires tsc plus node scripts/compile-exact-package.mjs packages/dom, then npm run build:exact -w @exactjs/framework-comparison-suite.
The baseline fixture key inference failure was reproduced before source changes; final root regression uses explicit this.map(). Historical diagnostic failures and their logs are retained.
See committed report for measurement limits and validation.
