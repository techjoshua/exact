import json,hashlib,zipfile
from pathlib import Path
from statistics import mean
base=Path('.tmp/ssr-large-profile');root=base/'large-primitive'
d=json.loads((root/'capture.json').read_text());assert d['complete'] and len(d['blocks'])==10
rows=[]
for pop in (0,1):
 bs=[b for b in d['blocks'] if b['population']==pop];e=[b for b in bs if b['id']=='exact']
 rows.append(dict(population=pop+1,immediate=mean(b['rps'] for b in e if b['phase']=='normal'),oldImmediate=next(b['rps'] for b in e if b['phase']=='scheduled'),yieldRps=next(b['rps'] for b in e if b['phase']=='preferred'),react=next(b['rps'] for b in bs if b['id']=='react')))
for b in d['blocks']:
 assert b['after']['scheduleCalls']==(b['valid']+len(b['results']) if b['phase']!='normal' else 0)
 assert all(s['errors']==0 for r in b['results'] for s in r['stages'])
valid=sum(b['valid'] for b in d['blocks']);(root/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid),indent=2))
report=Path('docs/performance-baselines/large-bun-scheduling-primitives-2026-09-11.md')
lines=['# Large Bun strings: scheduling primitive comparison','',
'Hypothesis: if the preferred yield primitive is responsible for the large-document loss, the prior batched setImmediate scheduler may recover roughly 15-20% throughput. Compare both against immediate rendering, with unchanged React controls. Both schedulers retain their production cancellation implementations; the old implementation is restored from the previously verified archive.', '',
'Native Bun string transport, 96 incidents, concurrency 32, ten-second warmup and five-second blocks. Fresh eXact/React/React/eXact workers. Immediate controls bracket old-immediate and preferred-yield blocks; their order reverses on repeat. Each request independently renders its full document and hydration.', '',
'| Repeat | Immediate RPS | Batched setImmediate RPS | Batched yield RPS | React RPS |',
'| --- | ---: | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['population']} | {r['immediate']:,.0f} | {r['oldImmediate']:,.0f} | {r['yieldRps']:,.0f} | {r['react']:,.0f} |")
lines+=['',f'{valid:,} complete measured responses validated with zero errors. Artifact and invocation-count guards pass.', '',
'Both scheduled variants lose to immediate rendering. The old primitive does not consistently outperform yield. This does not support reverting the primitive preference as a solution. The next diagnostic batches execution of render callbacks rather than only releasing readiness promises, to test whether promise-job transitions contribute.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(root.glob('*'))+[report,base/'large-primitive-build.py',base/'large-primitive-run.mjs',base/'large-primitive-report.py']
archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists();manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print(json.dumps(rows,indent=2));print(valid,'validated responses')
