from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'large-primitive';root.mkdir(exist_ok=True)
w=(base/'source-scheduler-preferred/worker.mjs').read_text()
w=w.replace('return { ...session, ...incidents };',"const data={ ...session, ...incidents }; data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)})); return data;")
(root/'worker.mjs').write_text(w);(root/'old-scheduler.mjs').write_bytes((base/'source-scheduler-preferred/old-scheduler.mjs').read_bytes())
r=(base/'source-scheduler-preferred-run.mjs').read_text().replace('source-scheduler-preferred/','large-primitive/').replace('preferred-yield-production-bun','large96-bun-scheduling-primitives')
r=r.replace("['string','stream']","['string']").replace("['scheduled','preferred','scheduled']","(population?['normal','preferred','scheduled','normal']:['normal','scheduled','preferred','normal'])").replace('report.blocks.length,16','report.blocks.length,10')
(base/'large-primitive-run.mjs').write_text(r)
