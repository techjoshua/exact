from pathlib import Path
from statistics import median
import hashlib, json, zipfile

root = Path.cwd()
base = root / '.tmp/ssr-large-profile'
folder = base / 'keyed-program'
rows = json.loads((folder / 'screen.json').read_text())
assert len(rows) == 72
summary = []
for runtime in ('node', 'bun'):
    for mode in ('encoded', 'stream'):
        selected = [r for r in rows if r['runtimeName'] == runtime and r['mode'] == mode]
        exact = [r for r in selected if r['variant'] != 'gated']
        assert len({r['hash'] for r in exact}) == 1
        assert all(r['processPriority'] == 10 and r['iterations'] == 20000 for r in selected)
        times = {v: median(r['usPerRender'] for r in selected if r['variant'] == v) for v in ('baseline', 'initial', 'gated')}
        improved = sum(next(r['usPerRender'] for r in selected if r['variant'] == 'initial' and r['round'] == i) < next(r['usPerRender'] for r in selected if r['variant'] == 'baseline' and r['round'] == i) for i in range(6))
        summary.append(dict(runtime=runtime, mode=mode, us=times, improved=improved,
                            changePercent=(times['initial'] / times['baseline'] - 1) * 100))
(folder / 'summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, indent=2))
