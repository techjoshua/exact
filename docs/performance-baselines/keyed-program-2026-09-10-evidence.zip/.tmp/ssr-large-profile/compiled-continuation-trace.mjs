import fs from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import ts from 'typescript';
import assert from 'node:assert/strict';
import {setPriority} from 'node:os';
import {createHash} from 'node:crypto';
setPriority(0,10);
const root='.tmp/ssr-large-profile/compiled-continuation-trace/';await fs.mkdir(root,{recursive:true});
const originalPath='.tmp/ssr-large-profile/conditional-emission/server-entry.js';
let source=await fs.readFile(originalPath,'utf8');
const ast=ts.createSourceFile('server-entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const edits=[],sites=[];
const selected=/^(__exactRun$|render|execute|prepare|createPrepared|createChunked|writeProgram|beginSsr|serialize|validatePositional|rootProps|rootComponent|augment|startsExact|streamDocument|scriptSources|stylesheetSources|Document$|Incident)/;
function visit(node){
 if(ts.isVariableStatement(node)&&node.declarationList.declarations.some(d=>ts.isIdentifier(d.name)&&d.name.text==='__exactSaved'))edits.push({pos:node.getStart(ast),text:"globalThis.__exactTrace.note('compiled continuation snapshot',{});"});
 if(ts.isArrowFunction(node)&&ts.isBlock(node.body)&&ts.isVariableDeclaration(node.parent)&&node.parent.name.getText(ast)==='waitForDemand'){edits.push({pos:node.body.getStart(ast)+1,text:"globalThis.__exactTrace.note('waitForDemand entry',{demand,closed});"});}
 if((ts.isFunctionDeclaration(node)||ts.isFunctionExpression(node)||ts.isMethodDeclaration(node))&&node.body&&ts.isBlock(node.body)){
  const name=node.name?.getText(ast)??'';
  let owner=node.parent;
  while(owner&&!ts.isClassDeclaration(owner)&&!ts.isClassExpression(owner))owner=owner.parent;
  const className=owner?.name?.getText(ast)??(owner&&ts.isVariableDeclaration(owner.parent)?owner.parent.name.getText(ast):undefined);
  const sink=className&&/Sink|Capture/.test(className)&&/^(write|flush|finish|destroy|reserveDirect|publishDirect|serializedRecords)$/.test(name);
  if(selected.test(name)||sink||name==='ssr'){
   const line=ast.getLineAndCharacterOfPosition(node.getStart(ast)).line+1;
   const label=(className?className+'.':'')+name+':'+line;
   const async=!!node.modifiers?.some(m=>m.kind===ts.SyntaxKind.AsyncKeyword);
   const start=node.body.getStart(ast)+1,end=node.body.end-1;
   const prefix=async?`const __traceSpan=globalThis.__exactTrace.begin(${JSON.stringify(label)},true);try{`:`return globalThis.__exactTrace.invoke(${JSON.stringify(label)},()=>{`;
   const suffix=async?'}finally{globalThis.__exactTrace.end(__traceSpan);}':'},arguments);';
   if(start===end)edits.push({pos:start,text:prefix+suffix});else edits.push({pos:start,text:prefix},{pos:end,text:suffix});sites.push({label,line,async});
  }
 }
 ts.forEachChild(node,visit);
}
visit(ast);for(const e of edits.sort((a,b)=>b.pos-a.pos))source=source.slice(0,e.pos)+e.text+source.slice(e.pos);
await fs.writeFile(root+'server-entry.js',source);await fs.writeFile(root+'sites.json',JSON.stringify(sites,null,2));
let enabled=false,forcePause=false,id=0,events=[],counts={},origin=0,stack=[];
const now=()=> (performance.now()-origin)*1000;
globalThis.__exactTrace={
 note(name,args){if(enabled)events.push({name,args,ph:'i',s:'t',pid:1,tid:1,ts:now()});},
 begin(name,async=false){if(!enabled)return;const span={name,id:++id,start:now(),async};counts[name]=(counts[name]??0)+1;events.push({name,cat:async?'async-function':'call',ph:async?'b':'B',id:span.id,pid:1,tid:1,ts:span.start});if(!async)stack.push(span);return span;},
 end(span){if(!span)return;events.push({name:span.name,cat:span.async?'async-function':'call',ph:span.async?'e':'E',id:span.id,pid:1,tid:1,ts:now()});if(!span.async)assert.equal(stack.pop(),span);},
 invoke(name,fn,args){if(!enabled)return fn();const span=this.begin(name);if(name.startsWith('executeDirectSsrComponent:'))events[events.length-1].args={component:args[1]?.artifact?.id};if(/Sink\.write:/.test(name))events[events.length-1].args={characters:args[0]?.length};if(/Sink\.flush:/.test(name))events[events.length-1].args={reason:args[0]};let value;try{value=fn();if(forcePause&&name.startsWith('HeadPublishingSink.flush:')&&args[0]==='head'){forcePause=false;value=Promise.resolve(value);}if(value instanceof Promise){const pending=this.begin(name+' pending',true);value.then(()=>this.end(pending),()=>this.end(pending));}return value;}finally{this.end(span);}}
};
const [control,probe]=await Promise.all([originalPath,root+'server-entry.js'].map(p=>import(pathToFileURL(resolve(p)))));
const data=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));
const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
for(const mode of ['string','stream','stream-pressure']){
 const run=async mod=>mode==='string'?new Response(await mod.renderParticipant(data,'/incidents/inc-101',options)).text():new Response(await mod.renderParticipantStream(data,'/incidents/inc-101',options)).text();
 const expected=await run(control);for(let i=0;i<1000;i++)await run(probe);
 events=[];counts={};id=0;stack=[];origin=performance.now();forcePause=mode==='stream-pressure';enabled=true;
 const consumption=globalThis.__exactTrace.begin('request and response consumption',true);
 const actual=await run(probe);globalThis.__exactTrace.end(consumption);await Promise.resolve();await Promise.resolve();enabled=false;
 assert.equal(actual,expected);assert.equal(stack.length,0);
 const summary={mode,bytes:Buffer.byteLength(actual),hash:createHash('sha256').update(actual).digest('hex'),events:events.length,counts};
 await fs.writeFile(root+mode+'.trace.json',JSON.stringify({traceEvents:events},null,2));await fs.writeFile(root+mode+'.summary.json',JSON.stringify(summary,null,2));console.log(JSON.stringify(summary));
}
