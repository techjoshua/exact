import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const root = '.tmp/ssr-large-profile/';
const folder = root + 'keyed-program';
await fs.mkdir(folder, { recursive: true });
const before = 'keyedChild(output, value) {\n\t\tconst target = output;';
const after = `keyedChild(output, value) {
        const prepared = output.target && output.context.writerSink && readPreparedServerRenderProgram(value);
        if (prepared) return mapRenderValue(writeProgramBoundary(output.context, output.sink, '', '', () => auditKeyedProgram(output, prepared)), () => void 0);
        const target = output;`;
const helper = `
function auditKeyedProgram(output, invocation) {
    const context = output.context;
    countSsrNode(context);
    enterSsrTreeDepth(context);
    let result;
    try { result = renderPreparedSsrProgram(context, invocation, output.target); }
    catch (error) { leaveSsrTreeDepth(context); throw error; }
    if (result instanceof Promise) return result.finally(() => leaveSsrTreeDepth(context));
    leaveSsrTreeDepth(context);
    return result;
}
`;
for (const name of ['server-entry.js', 'bun-server-entry.js']) {
    let source = await fs.readFile(root + 'conditional-emission/' + name, 'utf8');
    assert.equal(source.split(before).length, 2);
    await fs.writeFile(folder + '/' + name, source.replace(before, after) + helper);
}
const modules = await Promise.all(['conditional-emission', 'keyed-program'].map(dir => import(pathToFileURL(resolve(root + dir + '/server-entry.js')))));
const rows = [];
for (const mode of ['string', 'stream']) for (let request = 0; request < 3; request++) {
    const data = JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json', 'utf8'));
    data.incidents[1].title = `Request ${request} <script> café 🚀`;
    const options = { clientTags: `<script type="module" src="/assets/app${request}.js"></script><link rel="stylesheet" href="/assets/theme${request}.css">` };
    const results = await Promise.all(modules.map(async mod => mode === 'string' ? mod.renderParticipant(data, '/incidents/inc-101', options) : new Response(await mod.renderParticipantStream(data, '/incidents/inc-101', options)).text()));
    assert.equal(results[0], results[1]);
    rows.push({ mode, request, bytes: Buffer.byteLength(results[1]) });
}
await fs.writeFile(folder + '/verification.json', JSON.stringify(rows, null, 2));
console.log('Six changing-request full-output comparisons passed.');
let runner = await fs.readFile(root + 'direct-document-host-screen.mjs', 'utf8');
runner = runner.replace("baseline: 'shared-head-string', initial: 'direct-document-host'", "baseline: 'conditional-emission', initial: 'keyed-program'")
    .replace("const rows = JSON.parse(await fs.readFile(root+'direct-document-host/screen.json','utf8'));", 'const rows = [];')
    .replaceAll("root+'direct-document-host/screen.json'", "root+'keyed-program/screen.json'");
await fs.writeFile(root + 'keyed-program-screen.mjs', runner);
