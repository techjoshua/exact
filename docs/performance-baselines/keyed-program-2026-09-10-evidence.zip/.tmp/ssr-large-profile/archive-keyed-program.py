from pathlib import Path
import hashlib, json, zipfile
root = Path.cwd()
base = root / '.tmp/ssr-large-profile'
report = root / 'docs/performance-baselines/keyed-program-2026-09-10.md'
files = {report, Path(__file__).resolve(), root / '.tmp/positional-leaves/data.json'}
for name in ('keyed-program', 'keyed-program-trace', 'compiled-continuation-trace'):
    files.update(f for f in (base / name).iterdir() if f.is_file())
files.update(f for f in base.glob('keyed-program-*') if f.is_file())
for name in ('flat-invocation-large-worker.mjs', 'direct-document-host-bun-worker.mjs', 'compiled-continuation-trace.mjs'):
    files.add(base / name)
for filename, sub in [('server-entry.js', 'dist-server'), ('bun-server-entry.js', 'dist-bun-server')]:
    retained = base / 'conditional-emission' / filename
    current = root / 'framework-comparison/participants/exact' / sub / filename
    assert retained.read_bytes() == current.read_bytes()
    files.update([retained, current, root / 'framework-comparison/participants/react' / sub / filename])
archive = report.with_name('keyed-program-2026-09-10-evidence.zip')
assert not archive.exists()
manifest = {f.relative_to(root).as_posix(): hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(files)}
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as output:
    for f in sorted(files): output.write(f, f.relative_to(root).as_posix())
    output.writestr('SHA256.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None
    for name, digest in manifest.items(): assert hashlib.sha256(output.read(name)).hexdigest() == digest
print('Verified', len(files), 'files and unchanged production bundles')
