import hashlib
import json
import zipfile
from pathlib import Path
from statistics import mean

base=Path('.tmp/ssr-large-profile');folder=base/'issuer-ablation'
data=json.loads((folder/'capture.json').read_text());assert data['complete']
rows=[]
for population in (0,1):
    blocks=[b for b in data['blocks'] if b['population']==population]
    assert [b['phase'] for b in blocks]==['none','issuer','none']
    controls=[blocks[0],blocks[2]];candidate=blocks[1]
    for b in blocks:
        counts=b['after']['ablation']['counts']
        selected=b['phase']=='issuer'
        assert counts['normal' if selected else 'bypass']==0
        assert counts['bypass' if selected else 'normal']>0
    def render(b):
        s=b['after']['telemetry']['statistics']['renderMs'];return s['sum']/s['count']*1000
    def loop(b):return mean(b[k]['meanMs'] for k in ('loopBefore','loopAfter'))*1000
    normal=mean(b['rps'] for b in controls)
    rows.append(dict(population=population+1,normalRps=normal,bypassRps=candidate['rps'],gainPct=(candidate['rps']/normal-1)*100,normalHttpUs=mean(render(b) for b in controls),bypassHttpUs=render(candidate),normalLoopUs=mean(loop(b) for b in controls),bypassLoopUs=loop(candidate)))
valid=sum(b['valid'] for b in data['blocks']);errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages']);assert errors==0
(folder/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid,errors=errors),indent=2))
report=Path('docs/performance-baselines/issuer-boundary-substitution-2026-09-10.md')
lines=['# Child issuer boundary substitution, 2026-09-10','','## Hypothesis and scope','',
'Hypothesis before measurement: removing the task-issuer boundary from this task-free fixture will improve HTTP throughput by roughly 2 to 5 percent. Earlier experiments changed empty-array allocation; this diagnostic removes the entire boundary to measure its potential contribution.', '',
'The ordinary path invokes the original renderIssuedServerComponentChildren and asserts that it returns synchronously without preparation. The treatment calls the same render callback and readDirectSsrContent directly, returning the same content wrapper. Component execution, state, props, publication, child traversal, sink writes and surrounding ownership remain active. The issuer callback, prepared list, issuer scope and issuer-specific failure cleanup are bypassed.', '',
'This is a fixed-fixture diagnostic, not a valid general optimization. An authored call or getter can issue a scheduled child even if its final HTML is a leaf. General removal would require a compiler effect proof or equivalent guarantees. Successful output parity does not establish cancellation or failure safety for this bypass.', '',
'Two fresh production Node 26.8.1 string workers each run normal/bypass/normal after ten seconds of HTTP warmup. Five-second blocks use two fresh drivers with 16 requests each. Adjacent controls are averaged within each worker. Isolated loops before and after each block warm and measure 10,000 renders. Workstation load can vary. Compare only within this instrumented experiment.', '',
'| Worker | Normal RPS | Bypass RPS | Change | HTTP us, normal / bypass | Isolated us, normal / bypass |',
'| --- | ---: | ---: | ---: | ---: | ---: |']
for r in rows:
    lines.append(f"| {r['population']} | {r['normalRps']:,.0f} | {r['bypassRps']:,.0f} | {r['gainPct']:+.2f}% | {r['normalHttpUs']:.2f} / {r['bypassHttpUs']:.2f} | {r['normalLoopUs']:.2f} / {r['bypassLoopUs']:.2f} |")
lines+=['',f'All {valid:,} measured responses matched the complete 4,672-byte document, with zero errors. Four ordinary/escaped document parity cases pass; each exercises eight issuer boundaries. Counters verify treatment selection. Artifact and adapter hash guards pass. No production code changed.', '',
'This isolates a portion of component preparation, not the entire cost of ownership or compiled program construction. Gains cannot be added to previous substitutions. Raw results and a verified SHA-256 inventory are preserved in the adjacent archive. This is not a new full benchmark baseline.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[report,Path('.tmp/positional-leaves/data.json')]+[base/n for n in ('issuer-ablation-build.mjs','issuer-ablation-check.mjs','issuer-ablation-run.mjs','issuer-ablation-report.py','tree-ablation-run.mjs','tree-ablation-check.mjs','hydration-ablation/worker.mjs','component-forwarding-integrated/server-entry.js')]
files=sorted(set(p for p in files if p.is_file()));archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps(rows,indent=2));print(valid,'valid;',len(files),'verified files')
