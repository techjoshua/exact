import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';
await fs.mkdir(root+'issuer-ablation',{recursive:true});
let source=(await fs.readFile(root+'component-forwarding-integrated/server-entry.js','utf8')).replaceAll('\r\n','\n');
const ast=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
let target;
for(const node of ast.statements)if(ts.isFunctionDeclaration(node)&&node.name?.text==='renderIssuedServerComponentChildren')target=node;
if(!target)throw Error('Missing issuer boundary');
source=source.slice(0,target.name.getStart(ast))+'auditOriginalIssuer'+source.slice(target.name.end);
source=`let auditStage='none',auditCounts={normal:0,bypass:0},auditVerified=false;\n`+source+`
function renderIssuedServerComponentChildren(context,options,render,owner){
 if(auditStage==='issuer'){
  if(!auditVerified)throw Error('Unverified fixture');
  ++auditCounts.bypass;
  return {content:readDirectSsrContent(render())};
 }
 ++auditCounts.normal;
 const result=auditOriginalIssuer(context,options,render,owner);
 if(result instanceof Promise||result.preparation)throw Error('Diagnostic requires synchronous components without issued tasks');
 auditVerified=true;
 return result;
}
export function auditClearCounts(){auditCounts={normal:0,bypass:0};}
export function auditReset(){auditStage='none';auditVerified=false;auditClearCounts();}
export function auditSelect(stage){if(!['none','issuer'].includes(stage))throw Error('Invalid stage');if(stage==='issuer'&&!auditVerified)throw Error('Not primed');auditStage=stage;}
export function auditRead(){return {stage:auditStage,counts:{...auditCounts},ready:auditVerified};}
`;
await fs.writeFile(root+'issuer-ablation/server-entry.js',source);
await fs.copyFile(root+'hydration-ablation/worker.mjs',root+'issuer-ablation/worker.mjs');
let runner=(await fs.readFile(root+'tree-ablation-run.mjs','utf8')).replaceAll('tree-ablation/','issuer-ablation/').replaceAll('within-worker-tree-substitution','within-worker-issuer-substitution').replaceAll("'none','tree','none'","'none','issuer','none'");
await fs.writeFile(root+'issuer-ablation-run.mjs',runner);
let check=(await fs.readFile(root+'tree-ablation-check.mjs','utf8')).replaceAll('tree-ablation/','issuer-ablation/').replace("['none','tree']","['none','issuer']").replace("assert.equal(snapshot.counts.tree,stage==='tree'?0:1);","assert.equal(snapshot.counts.normal,stage==='issuer'?0:8);assert.equal(snapshot.counts.bypass,stage==='issuer'?8:0);");
await fs.writeFile(root+'issuer-ablation-check.mjs',check);
console.log('Built issuer boundary substitution');
