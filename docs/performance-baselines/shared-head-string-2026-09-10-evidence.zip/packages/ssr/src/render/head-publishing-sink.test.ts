import { expect, it, vi } from 'vitest';
import { HeadPublishingSink } from './head-publishing-sink.js';
import { SsrOutputLimitError } from './limits.js';

it('publishes the head once while retaining the complete document', async () => {
	const head = '<!doctype html><html><head><title>Ready</title></head>';
	const tail = '<body>Content</body></html>';
	const publish = vi.fn(async () => {});
	const sink = new HeadPublishingSink(1024, publish);
	sink.write(head);
	await sink.flush('head');
	sink.write(tail);
	await sink.flush('head');
	expect(publish).toHaveBeenCalledExactlyOnceWith(head);
	expect(sink.finish()).toBe(head + tail);
	expect(() => sink.write('later')).toThrow('closed');
});

it('checks the exact UTF-8 limit before publishing a multibyte head', () => {
	const head = '<!doctype html><html><head>' + '🚀'.repeat(40) + '</head>';
	const publish = vi.fn(async () => {});
	const sink = new HeadPublishingSink(head.length, publish);
	sink.write(head);
	expect(() => sink.flush('head')).toThrow(SsrOutputLimitError);
	expect(publish).not.toHaveBeenCalled();
	expect(() => sink.write('tail')).toThrow('closed');
});
