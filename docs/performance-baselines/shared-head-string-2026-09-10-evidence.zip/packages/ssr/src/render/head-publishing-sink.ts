import { isExactDocumentHtml } from '../document.js';
import { StringProgramSink } from './string-program-sink.js';
import { SsrOutputLimitError } from './limits.js';
import { utf8ByteLength } from './utf8.js';

/** Retains the final document while publishing its committed head through the same writer. */
export class HeadPublishingSink extends StringProgramSink {
	private published = false;
	constructor(
		private readonly maxHeadBytes: number,
		private readonly publish: (html: string) => Promise<void>
	) {
		super(maxHeadBytes);
	}
	/** Applies transport pressure before rendering can proceed past the committed head. */
	override flush(reason?: 'head' | 'await'): Promise<void> | undefined {
		if (reason !== 'head' || this.published || !isExactDocumentHtml(this.value)) return;
		this.published = true;
		const head = this.value;
		if (head.length > this.maxHeadBytes / 3 && utf8ByteLength(head) > this.maxHeadBytes) {
			this.destroy();
			throw new SsrOutputLimitError(this.maxHeadBytes);
		}
		return this.publish(head);
	}
}
