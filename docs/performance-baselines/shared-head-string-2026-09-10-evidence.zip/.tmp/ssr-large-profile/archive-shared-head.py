from pathlib import Path
import json, hashlib, zipfile
root=Path.cwd()
base=root/'.tmp/ssr-large-profile'
report=root/'docs/performance-baselines/shared-head-string-2026-09-10.md'
sections=[]
for name,title in [('root-document-probe','Root-only document recognition'),('shared-head-string','Reuse the collecting sink string')]:
 rows=json.loads((base/name/'http.json').read_text())
 assert len(rows)==72
 for row in rows:
  artifact=Path(row['entry'])
  assert hashlib.sha256(artifact.read_bytes()).hexdigest()==row['artifactSha256']
 summary=json.loads((base/name/'summary.json').read_text())
 assert summary['errors']==0
 for runtime in ('node','bun'):
  for mode in ('string','stream'):
   exact=[r for r in rows if r['runtime']==runtime and r['mode']==mode and r['variant']!='react']
   assert len({r['identity']['hash'] for r in exact})==1
 table='\n'.join(f"| {r['runtime'].title()} {r['mode']} | {r['rps']['baseline']:,.0f} | {r['rps']['compiled']:,.0f} | {r['rps']['react']:,.0f} | {r['changePercent']:+.1f}% | {r['improvedBlocks']}/6 |" for r in summary['summary'])
 sections.append(f"## {title}\n\n| Runtime/output | Prior eXact requests/s | Candidate eXact requests/s | React requests/s | Change | Positive blocks |\n| --- | ---: | ---: | ---: | ---: | ---: |\n{table}\n\n{summary['valid']:,} valid responses, zero errors.\n")
report.write_text("""# Root document recognition and shared head string, September 10, 2026

Two sequential experiments retain the shared component executor and descendant writer. The first
moves progressive root recognition out of ordinary component execution. The second removes the
head sink's duplicate string accumulation and write/destroy overrides. The head is an immutable
reference to the collecting sink's existing output at the flush boundary. Later appends preserve
that prefix. Byte limits remain enforced before head publication and at final completion.

Hypotheses: restricting document recognition should remove irrelevant work from ordinary rendering;
reusing the existing string should modestly improve streaming by removing duplicate prefix writes
and their wrapper calls. Neither change alone is expected to close the Node string gap.

"""+ '\n'.join(sections)+"""
## Interpretation and validation

The root-only experiment did not establish a consistent throughput improvement. Its Node string
result was neutral, Node streaming and Bun string were lower, and Bun streaming was slightly higher.
Do not describe this isolation as a proven speedup. The shared-string round suffered pronounced workload interruptions: unchanged React Node-stream
blocks fell as low as roughly 600 requests/s, and a Bun-string control block fell to roughly 1,200.
No slow blocks were removed. These data cannot establish a causal throughput benefit or regression
for the sink change. It is retained as simpler ownership with fewer duplicate writes and passing
behavioral checks, not as a measured speedup. The second table measures the incremental sink
change against that root-only build, not against the original early-head build.

Every cell uses all six three-variant orders, ten seconds of worker warmup, 1.5-second measured
blocks, and two drivers at concurrency 16 each. Node 26.8.1 and Bun 1.4.2 run production builds at
below-normal process priority. Each framework renders its full application-owned document.
React is unchanged. No builds, tests, or profilers run during timing. The user may use the PC;
short local measurements and cross-round absolute rates must not be treated as stable capacity.
Every response is validated, and eXact outputs are byte-identical within each cell in both rounds.

The root-only build passed 369 SSR tests and all 56 browser checks across Node/Bun string/stream.
The shared-string build passed 370 SSR tests, all 56 browser checks, test type checking, and focused
ESLint, source architecture, JSDoc, frozen and initial ABI checks, and package-content checks.
Direct package-check invocation first failed with Windows spawn EINVAL; rerunning with the npm CLI
path supplied through npm_execpath passed. Both logs are retained. Tests cover consumer-visible head delivery before pending body tasks, cancellation and
single disposal, UTF-8 limits before publication, one-time head delivery, and complete final output.

This retains full-body collection after early head commitment; it does not establish a fully
incremental body writer. Application-only hydration and generalized shell compilation remain
separate unfinished work. React parity in all four cells is not established.

Raw results, scripts, frozen build artifacts, source files, and validation logs are preserved in
[the evidence archive](shared-head-string-2026-09-10-evidence.zip).
""",encoding='utf-8')
files={report}
for name in ('root-document-probe','shared-head-string'):
 files.update(p for p in (base/name).rglob('*') if p.is_file())
 files.update(p for p in base.glob(name+'-*') if p.is_file())
files.update((base/'early-head-gated'/n) for n in ('server-entry.js','bun-server-entry.js'))
for n in ('document-root-output.ts','tree-output.ts','component.ts','synchronous-artifact.ts','head-publishing-sink.ts','head-publishing-sink.test.ts','string-program-sink.ts'):
 files.add(root/'packages/ssr/src/render'/n)
files.add(root/'packages/ssr/src/types.ts')
files.add(root/'docs/performance-baselines/document-hydration-ownership-audit-2026-09-10.md')
for sub in ('dist-server/server-entry.js','dist-bun-server/bun-server-entry.js'):
 files.add(root/'framework-comparison/participants/react'/sub)
for name in ('ssr-load-process-owner.mjs','ssr-worker-controller.mjs','ssr-run-environment.mjs','ssr-benchmark-worker.mjs'):
 files.add(root/'framework-comparison/src'/name)
files.add(root/'docs/ssr-hydration.md')
files.add(Path(__file__).resolve())
archive=report.with_name('shared-head-string-2026-09-10-evidence.zip')
assert not archive.exists()
manifest={str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files): z.write(p,str(p.relative_to(root)).replace('\\','/'))
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,digest in manifest.items(): assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(f'Archived and verified {len(files)} files: {archive}')
