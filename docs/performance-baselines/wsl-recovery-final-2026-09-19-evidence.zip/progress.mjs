import {readFile} from 'node:fs/promises';
import {summarizeSsrCapacityCapture as summarize} from '../../framework-comparison/src/ssr-capacity-report.mjs';
for(const runtime of ['node','bun'])for(const mode of ['','-stream'])for(const lane of ['multi','normal']){
 const name=runtime+mode+'-'+lane;let current;try{current=JSON.parse(await readFile(import.meta.dirname+'/'+name+'.json'));}catch{continue;}if(!current.complete)continue;
 const baseline=JSON.parse(await readFile('docs/performance-baselines/wsl-workspace-2026-09-19-'+name+'.json'));
 const rates=c=>{const rows=summarize(c).filter(r=>r.concurrency===32);return {exact:rows.find(r=>r.name==='eXact').rps,react:rows.find(r=>r.name==='React').rps};};
 const a=rates(baseline),b=rates(current);console.log(name,JSON.stringify({...b,ratio:b.exact/b.react,change:100*((b.exact/b.react)/(a.exact/a.react)-1)}));
}
