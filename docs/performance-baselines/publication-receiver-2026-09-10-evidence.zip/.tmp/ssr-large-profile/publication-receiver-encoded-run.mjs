import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/';
const entries={current:d+'completed-html-result-integrated/server-entry.js',candidate:d+'publication-receiver/server-entry.js'};
const rows=[];
for(const runtime of ['node','bun'])for(const mode of ['encoded'])for(const scenario of ['assets'])for(let round=0;round<2;round++){
 const order=Object.keys(entries);if(round)order.reverse();
 for(const variant of order){
  const entry=entries[variant];
  const result=spawnSync(runtime,[d+'projector-warm50-worker.mjs',entry,mode,scenario,'20000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
  if(result.status!==0)throw Error(result.stderr+result.stdout);
  const row={runtimeId:runtime,round,variant,artifactSha256:createHash('sha256').update(fs.readFileSync(entry)).digest('hex'),...JSON.parse(result.stdout)};
  const peer=rows.find(r=>r.scenario===scenario&&r.mode===mode&&(r.variant==='react')===(variant==='react'));
  if(peer)assert.equal(row.hash,peer.hash,'Complete document changed');
  rows.push(row);fs.writeFileSync(d+'publication-receiver-encoded-results.json',JSON.stringify(rows,null,2));
  console.log(runtime,mode,scenario,round,variant,row.usPerRender.toFixed(2));
 }
}














