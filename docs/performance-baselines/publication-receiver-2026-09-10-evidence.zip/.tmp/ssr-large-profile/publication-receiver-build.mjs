import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';
let code=fs.readFileSync(root+'completed-html-result-integrated/server-entry.js','utf8');
assert.equal(createHash('sha256').update(code).digest('hex'),'9093d5a3f3fdc1df26aa016be083964eace4f50ddb87766312e813331dd235b3');
const callbackStart=code.indexOf('(content, owner, preparedProps, snapshot) => {',code.indexOf('function executeSynchronousArtifact('));
const callbackEnd=code.indexOf('}, consumeScalarPropsProof(reference, props));',callbackStart);
assert.ok(callbackStart>0&&callbackEnd>callbackStart);
const body=code.slice(callbackStart+'(content, owner, preparedProps, snapshot) => {'.length,callbackEnd);
code=code.slice(0,callbackStart)+'publishSynchronousComponent, consumeScalarPropsProof(reference, props), execution);'+code.slice(callbackEnd+'}, consumeScalarPropsProof(reference, props));'.length);
code=`function publishSynchronousComponent(content, owner, preparedProps, snapshot) {
 const execution=this; const reference=execution.reference; const parent=execution.parent;
 ${body}
}\n`+code;
const start=code.indexOf('function executeDirectSsrComponent('),end=code.indexOf('\nfunction performanceNow()',start);
assert.ok(start>0&&end>start);
let direct=code.slice(start,end);
assert.equal(direct.split('sink(content.content,').length,4);
direct=direct.replace('scalarPropsProven = false)', 'scalarPropsProven = false, sinkReceiver)');
direct=direct.replaceAll('sink(content.content,','sink.call(sinkReceiver, content.content,');
code=code.slice(0,start)+direct+code.slice(end);
const execution='const execution = {\n\t\tcontext,\n\t\toptions,\n\t\tpublication,';
assert.equal(code.split(execution).length,2);
code=code.replace(execution,'const execution = {\n\t\treference,\n\t\tparent,\n\t\tcontext,\n\t\toptions,\n\t\tpublication,');
fs.mkdirSync(root+'publication-receiver',{recursive:true});
fs.writeFileSync(root+'publication-receiver/server-entry.js',code);
const runner=fs.readFileSync(root+'completed-html-result-allocations.mjs','utf8').replaceAll('completed-html-result','publication-receiver').replaceAll('individual-result-integrated','completed-html-result-integrated');
fs.writeFileSync(root+'publication-receiver-allocations.mjs',runner);
