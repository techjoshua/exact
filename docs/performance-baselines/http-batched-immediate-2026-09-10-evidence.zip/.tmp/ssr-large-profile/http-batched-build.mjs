import fs from 'node:fs/promises';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'http-batched',{recursive:true});
function replaceOnce(text,from,to){if(!text.includes(from))throw Error('Missing source: '+from);return text.replace(from,to);}
let worker=(await fs.readFile(root+'http-queues/worker.mjs','utf8')).replaceAll('\r\n','\n');
worker=`let auditPendingBatch;
let auditBatchStats={batches:0,requests:0,max:0};
function auditQueueBatch(resolve){
 if(auditPendingBatch){auditPendingBatch.push(resolve);return;}
 auditPendingBatch=[resolve];
 setImmediate(()=>{
  const batch=auditPendingBatch;auditPendingBatch=undefined;
  ++auditBatchStats.batches;auditBatchStats.requests+=batch.length;auditBatchStats.max=Math.max(auditBatchStats.max,batch.length);
  for(const resolve of batch)resolve();
 });
}
`+worker;
worker=replaceOnce(worker,"if(auditDefer==='immediate')setImmediate(resolve);","if(auditDefer==='batch')auditQueueBatch(resolve);else if(auditDefer==='immediate')setImmediate(resolve);");
worker=replaceOnce(worker,"['normal','nextTick','microtask','immediate']","['normal','nextTick','microtask','immediate','batch']");
worker=replaceOnce(worker,"if (pathname === '/__exact-benchmark/audit-start') { resetTelemetry(); audit={};","if (pathname === '/__exact-benchmark/audit-start') { resetTelemetry(); audit={};auditBatchStats={batches:0,requests:0,max:0};");
worker=replaceOnce(worker,'telemetry:telemetry(),audit});','telemetry:telemetry(),audit,batchStats:auditBatchStats});');
await fs.writeFile(root+'http-batched/worker.mjs',worker);
let runner=(await fs.readFile(root+'http-queues-run.mjs','utf8')).replaceAll('http-queues/','http-batched/').replaceAll('same-worker-explicit-queue-comparison','same-worker-batched-immediate');
runner=replaceOnce(runner,"population?['normal','immediate','normal','microtask','normal','nextTick','normal']:['normal','nextTick','normal','microtask','normal','immediate','normal']","['normal','immediate','batch','immediate','normal']");
runner=replaceOnce(runner,'report.blocks.length,14','report.blocks.length,10');
await fs.writeFile(root+'http-batched-run.mjs',runner);
console.log('Built shared immediate batch experiment');
