import hashlib
import json
import zipfile
from pathlib import Path
from statistics import mean

base=Path('.tmp/ssr-large-profile');folder=base/'http-batched'
data=json.loads((folder/'capture.json').read_text());assert data['complete'] and len(data['blocks'])==10
def duration(audit,key):
    s=audit.get(key);return s['sumMs']/s['count']*1000 if s else 0
def response(b):
    values=[r['stages'][0]['distributions']['responseMs'] for r in b['results']]
    return sum(s['mean']*s['count'] for s in values)/sum(s['count'] for s in values)
rows=[]
for population in (0,1):
    blocks=[b for b in data['blocks'] if b['population']==population]
    assert [b['phase'] for b in blocks]==['normal','immediate','batch','immediate','normal']
    for b in blocks:
        audit=b['after']['audit'];stats=b['after']['batchStats']
        if b['phase']=='normal':assert 'renderQueue' not in audit
        else:assert audit['renderQueue']['count']==audit['renderInvocation']['count']
        if b['phase']=='batch':assert stats['requests']==audit['renderInvocation']['count'] and stats['batches']>0
        else:assert stats['requests']==0 and stats['batches']==0
        for k in ('loopBefore','loopAfter'):assert 'renderQueue' not in b[k]['audit']
    groups={phase:[b for b in blocks if b['phase']==phase] for phase in ('normal','immediate','batch')}
    r=dict(population=population+1)
    for phase,group in groups.items():
        r[phase]=dict(rps=mean(b['rps'] for b in group),controlsRps=[b['rps'] for b in group],invocationUs=mean(duration(b['after']['audit'],'renderInvocation') for b in group),afterReturnUs=mean(duration(b['after']['audit'],'renderAfterReturn') for b in group),queueUs=mean(duration(b['after']['audit'],'renderQueue') for b in group),responseMs=mean(response(b) for b in group))
    r['gainVsNormalPct']=(r['batch']['rps']/r['normal']['rps']-1)*100
    r['gainVsImmediatePct']=(r['batch']['rps']/r['immediate']['rps']-1)*100
    stats=blocks[2]['after']['batchStats'];r['batchStats']=stats;r['meanBatchSize']=stats['requests']/stats['batches'];rows.append(r)
valid=sum(b['valid'] for b in data['blocks']);errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages']);assert errors==0
(folder/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid,errors=errors),indent=2))
report=Path('docs/performance-baselines/http-batched-immediate-2026-09-10.md')
lines=['# Batched immediate scheduling, 2026-09-10','',
'Hypothesis before measurement: sharing one setImmediate callback across waiting render requests may improve throughput by another 3 to 10 percent over one callback per request. It reduces callback count and changes interleaving between rendering and response publication. This experiment does not independently isolate those two effects.', '',
'The diagnostic worker queues Promise resolvers in an array. The first resolver schedules setImmediate; subsequent resolvers join that batch. The callback detaches the pending batch, then resolves every Promise. The waiting render continuations execute afterward. Each request still renders its full document using the retained eXact renderer and unchanged output adapter. This is eXact-only; no React behavior or baseline changes.', '',
'Two fresh production Node 26.8.1 workers each run normal/immediate/batch/immediate/normal. Normal has no added deferral; immediate schedules one callback per request. Workers warm HTTP for ten seconds; each measured block lasts five seconds with two fresh drivers holding 16 requests each. Controls are averaged within each worker. Isolated before/after loops each warm and measure 10,000 renders and bypass queueing. Workstation load can vary.', '',
'| Worker | Normal RPS | Per-request immediate RPS | Batched RPS | Batch gain vs normal | Batch gain vs immediate | Mean requests per batch |',
'| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for r in rows:
    lines.append(f"| {r['population']} | {r['normal']['rps']:,.0f} | {r['immediate']['rps']:,.0f} | {r['batch']['rps']:,.0f} | {r['gainVsNormalPct']:+.2f}% | {r['gainVsImmediatePct']:+.2f}% | {r['meanBatchSize']:.2f} |")
lines+=['', '| Worker | Scheduling | Synchronous invocation us | Await after invocation us | Initial queue us | Complete response mean ms |','| --- | --- | ---: | ---: | ---: | ---: |']
for r in rows:
    for phase in ('normal','immediate','batch'):
        v=r[phase];lines.append(f"| {r['population']} | {phase} | {v['invocationUs']:.2f} | {v['afterReturnUs']:.2f} | {v['queueUs']:.2f} | {v['responseMs']:.3f} |")
lines+=['',
'The render timer spans synchronous invocation and awaiting its returned value. Under batching, that await can include other requests running before this continuation resumes. It is not an exclusive CPU-time measure. Initial scheduling wait is separately excluded from that timer but included in response latency. Per-stage durations across concurrently active requests cannot be added as exclusive work.', '',
f'All {valid:,} measured responses matched the full 4,672-byte document, with zero errors. Batch request counters match render-invocation counters only in batch blocks. Queue counters match invocation counts in queued blocks, and are absent from normal blocks and isolated loops. Artifact and adapter hash guards pass.', '',
'No production scheduling change is adopted from this diagnostic. It still needs a framework-owned scheduling boundary, cancellation and ownership coverage, low-concurrency behavior, bounded batching/fairness, and early streaming/browser validation. These results are not a full Node/Bun string/stream benchmark baseline.', '',
'Raw blocks, scripts, summaries and participant artifacts are in the adjacent evidence archive with a verified SHA-256 inventory.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[report]+[base/n for n in ('http-batched-build.mjs','http-batched-run.mjs','http-batched-report.py','http-queues-run.mjs','http-queues/worker.mjs','component-forwarding-integrated/server-entry.js')]
files=sorted(set(p for p in files if p.is_file()));archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps(rows,indent=2));print(valid,'valid;',len(files),'verified files')
