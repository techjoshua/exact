import {readFile,writeFile} from 'node:fs/promises';
import {Server} from 'node:http';
import assert from 'node:assert/strict';
import {chromium} from 'playwright';
import {startClientBenchmarkHarness} from '../../framework-comparison/src/client-benchmark-harness.mjs';
import {waitForFirstContentfulPaint} from '../../framework-comparison/src/paint-timing.mjs';
import {assertComparisonNetwork} from '../../framework-comparison/src/network-environment.mjs';
let requests=[];
const emit=Server.prototype.emit;
Server.prototype.emit=function(name,...args){if(name==='request'&&args[0].socket.localPort===4310&&args[0].url.endsWith('/claim'))requests.push({method:args[0].method,url:args[0].url});return emit.call(this,name,...args);};
const network=assertComparisonNetwork();
const source=await readFile('framework-comparison/src/measure.mjs','utf8');
const timing=source.slice(source.indexOf('function installInteractionTiming()'),source.indexOf('\nasync function measureControlledService()'));
const participants=[{id:'exact-controlled',directory:'exact',artifact:'dist',url:'http://127.0.0.1:4401'},{id:'react-controlled',directory:'react',artifact:'dist',url:'http://127.0.0.1:4402'}];
const reset=async()=>{const r=await fetch('http://127.0.0.1:4310/__benchmark/reset',{method:'POST',headers:{'content-type':'application/json','x-benchmark-control':'fixture-reset'},body:'{}'});assert.equal(r.status,200);await r.json();};
const harness=await startClientBenchmarkHarness(participants);let browser;const samples=[];
try{
 browser=await chromium.launch();
 for(let round=0;round<20;round++){
  for(const participant of round%2?[...participants].reverse():participants){
   await reset();const context=await browser.newContext();
   try{
    const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
    await page.addInitScript({content:`(${timing})();document.addEventListener('click',e=>{if(e.target?.closest('button')?.textContent?.trim()==='Claim incident')globalThis.__frameworkComparisonTiming.trusted=e.isTrusted;},true);`});
    const cdp=await context.newCDPSession(page);await cdp.send('Network.enable');await cdp.send('Network.setCacheDisabled',{cacheDisabled:true});
    await page.goto(participant.url+'/incidents/inc-100',{waitUntil:'domcontentloaded'});
    await page.getByRole('heading',{name:'Checkout authorization failures'}).waitFor();
    await page.evaluate(waitForFirstContentfulPaint);await page.waitForLoadState('load');
    await page.locator('.connection').getByText('Live service',{exact:true}).waitFor();
    const timeOrigin=await page.evaluate(()=>performance.timeOrigin);
    for(let iteration=0;iteration<6;iteration++){
     const incidentId=iteration%2?'inc-102':'inc-100';const title=iteration%2?'Search index freshness warning':'Checkout authorization failures';
     if(iteration>=2){
      await reset();
      const refreshed=page.waitForResponse(r=>r.url()==='http://127.0.0.1:4310/api/incidents'&&r.request().method()==='GET');
      await page.getByRole('button',{name:'Refresh',exact:true}).click();const response=await refreshed;assert.equal(response.status(),200);await response.json();
     }
     if(iteration>0){await page.getByTestId('incident-row').filter({hasText:title}).click();}
     await page.getByRole('heading',{name:title,exact:true}).waitFor();
     await page.waitForFunction(()=>document.querySelector('.version')?.textContent.trim()==='Version 1'&&document.querySelector('.facts > div:first-child strong')?.textContent.trim()==='Unassigned'&&document.querySelector('.facts > div:nth-child(2) strong')?.textContent.trim()==='open');
     await page.evaluate(()=>Object.assign(globalThis.__frameworkComparisonTiming,{startedAt:null,optimisticFeedbackMs:null,settlementMs:null,phasesMs:{},trusted:null}));
     requests=[];
     const completed=page.waitForResponse(r=>r.url().endsWith('/'+incidentId+'/claim')&&r.request().method()==='POST');
     await page.getByRole('button',{name:'Claim incident'}).click();
     await page.getByText('Version 2',{exact:true}).waitFor();await page.getByText('Alex Chen',{exact:true}).waitFor();
     await page.waitForFunction(()=>globalThis.__frameworkComparisonTiming.phasesMs['http-json-decoded']!==undefined);
     const response=await completed;assert.equal(response.status(),200);const payload=await response.json();assert.equal(payload.incident.version,2);assert.equal(payload.incident.ownerId,'user-alex');assert.equal(payload.incident.status,'investigating');
     assert.deepEqual(errors,[]);assert.equal(await page.evaluate(()=>performance.timeOrigin),timeOrigin);
     const result=await page.evaluate(()=>globalThis.__frameworkComparisonTiming);assert.equal(result.trusted,true);assert.ok(result.optimisticFeedbackMs!==null);assert.equal(requests.filter(r=>r.method==='POST').length,1);
     samples.push({round,id:participant.id,iteration,incidentId,timing:result,requests});
    }
   }finally{await context.close();}
  }
  console.log('Round',round+1,'/20');
 }
 await writeFile('.tmp/warm-page-2026-09-22/results-repeat.json',JSON.stringify({network,harness:harness.evidence(),samples},null,2));
}finally{try{await browser?.close();}finally{await harness.close();Server.prototype.emit=emit;}}
