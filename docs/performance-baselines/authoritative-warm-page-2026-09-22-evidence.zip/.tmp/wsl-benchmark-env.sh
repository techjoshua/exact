# Source from the repository root before running comparison commands in WSL.
export PATH="/home/techj/.bun/bin:/home/techj/.local/lib/go/bin:$PATH"
export LD_LIBRARY_PATH="/home/techj/.local/lib/exact-browser-deps/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
