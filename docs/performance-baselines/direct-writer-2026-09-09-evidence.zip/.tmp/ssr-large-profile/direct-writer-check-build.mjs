import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
for(const variant of ['direct-writer','direct-writer-continuation','direct-writer-batches-8192','direct-writer-current-node','direct-writer-current-bun','direct-writer-handle-node','direct-writer-handle-bun']){
 let source=readFileSync(dir+variant+'.mjs','utf8');
 const replace=(before,after)=>{if(source.split(before).length!==2)throw Error(before);source=source.replace(before,after);};
 replace('function renderDirectWriter(context,invocation,render){','function renderDirectWriter(context,invocation,render){\n directWriterAuditContexts.add(context);');
 const handle=variant.startsWith('direct-writer-handle');
 replace(handle?'const rendered=render(value);':'const rendered=output.render(value);',`const invoke=()=>{
  if(++directWriterAuditVisits===directWriterAuditFailureAt)throw directWriterAuditFailure;
  return ${handle?'render(value)':'output.render(value)'};
 };
 const rendered=directWriterAuditDelay?Promise.resolve().then(invoke):invoke();`);
 source+=`
let directWriterAuditDelay=false,directWriterAuditFailureAt=-1,directWriterAuditVisits=0;
let directWriterAuditFailure=new Error('Injected direct writer failure');
const directWriterAuditContexts=new Set();
export function configureDirectWriterAudit(delay,failAt=-1){
 directWriterAuditDelay=delay;directWriterAuditFailureAt=failAt;directWriterAuditVisits=0;
 directWriterAuditContexts.clear();
}
export function inspectDirectWriterAudit(){return {
 visits:directWriterAuditVisits,
 contexts:[...directWriterAuditContexts].map(context=>({hosts:[...context.hostStack],depth:context.traversalDepth}))
};}
`;
 writeFileSync(dir+variant+'-check.mjs',source);
}
