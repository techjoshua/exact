import {readFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const data=JSON.parse(readFileSync('.tmp/positional-leaves/data.json','utf8'));
const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
const results=[];
const controls=JSON.parse(readFileSync('.tmp/ssr-large-profile/direct-writer-results.json','utf8'));
for(const variant of ['direct-writer','direct-writer-continuation','direct-writer-batches-8192','direct-writer-current-node','direct-writer-current-bun','direct-writer-handle-node','direct-writer-handle-bun']){
 const mod=await import(pathToFileURL(resolve('.tmp/ssr-large-profile/'+variant+'-check.mjs')));
 for(const mode of ['string','stream'])for(const delay of [false,true])for(const failAt of [-1,1,5]){
  mod.configureDirectWriterAudit(delay,failAt);
  let html,error,timer;
  const operation=async()=>mode==='string'?await mod.renderParticipant(data,'/incidents/inc-101',options):await new Response(await mod.renderParticipantStream(data,'/incidents/inc-101',options)).text();
  try{html=await Promise.race([operation(),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Direct writer operation timed out')),5000);})]);}
  catch(caught){error=caught;}
  finally{clearTimeout(timer);}
  const state=mod.inspectDirectWriterAudit();
  assert.ok(state.visits>0);
  assert.ok(state.contexts.length>0);
  assert.ok(state.contexts.every(context=>context.hosts.length===0&&context.depth===0),'Host/depth ownership did not unwind');
  let hash;
  if(failAt<0){
   if(error)throw error;
   hash=createHash('sha256').update(html).digest('hex');
   assert.equal(hash,controls.find(r=>r.variant==='marker-hex-current'&&r.mode===mode&&r.scenario==='small').hash);
  }else{
   if(mode==='string')assert.equal(error?.message,'Injected direct writer failure');
   else{
    assert.equal(error,undefined);
    assert.match(html,/console\.error\("eXact document stream failed"\)/);
    assert.ok(!html.includes('<html'),'Failed document must not be published as a complete shell');
   }
   assert.equal(state.visits,failAt,'Traversal continued after failure');
  }
  results.push({variant,mode,delay,failAt,hash,error:error?.message,errorBody:failAt>0&&mode==='stream'?html:undefined,...state});
 }
}
console.log(JSON.stringify({runtime:process.versions.bun??process.version,results}));
