import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
const current=readFileSync(dir+'task-selection-opt-in-current.mjs','utf8');
const prior=readFileSync(dir+'marker-hex-current.mjs','utf8');
const modules=['server-task-readiness','server-component-execution'];
function region(source,name){
 const start=source.indexOf('//#region ../packages/core/dist/server/tasks/'+name+'.js');
 const end=source.indexOf('//#endregion',start)+'//#endregion'.length;
 if(start<0||end<11)throw Error('Missing module '+name);
 return source.slice(start,end);
}
let strippedPrior=prior,strippedCurrent=current;
for(const name of modules){
 strippedPrior=strippedPrior.replace(region(prior,name),'');
 strippedCurrent=strippedCurrent.replace(region(current,name),'');
}
if(strippedPrior!==strippedCurrent)throw Error('Unaccounted current-build change');
for(const runtime of ['node','bun']){
 const input=runtime==='node'?'direct-writer-continuation':'direct-writer-batches-8192';
 let source=readFileSync(dir+input+'.mjs','utf8');
 for(const name of modules)source=source.replace(region(source,name),region(current,name));
 writeFileSync(dir+'direct-writer-current-'+runtime+'.mjs',source);
}
writeFileSync(dir+'direct-writer-current-build.json',JSON.stringify({rebasedModules:modules,unaccountedChanges:false,node:'direct-writer-continuation',bun:'direct-writer-batches-8192'},null,2));
