import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
for(const runtime of ['node','bun']){
 let source=readFileSync(dir+'direct-writer-current-'+runtime+'.mjs','utf8');
 function replace(before,after){if(source.split(before).length!==2)throw Error('Unexpected site: '+before);source=source.replace(before,after);}
 const signature='function(__exactSsr, __exactContext, __exactInvocation, __exactOutput)';
 if(source.split(signature).length!==26)throw Error('Unexpected writer count');
 source=source.replaceAll(signature,'function(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactRender)');
 source=source.replaceAll('__exactSsr.static(__exactOutput,','__exactSsr.static(__exactContext, __exactOutput,');
 source=source.replaceAll('__exactSsr.keyedChild(__exactOutput,','__exactSsr.keyedChild(__exactContext, __exactOutput, __exactRender,');
 for(const name of ['child','component','directComponent'])source=source.replaceAll('__exactSsr.'+name+'(__exactContext, __exactOutput,','__exactSsr.'+name+'(__exactContext, __exactOutput, __exactRender,');
 replace('static(output, value) {','static(context, output, value) {');
 source=source.replaceAll('appendProgramText(output,','appendProgramText(context,output,');
 replace('appendSharedSink(output.context,output.sink,html)','appendSharedSink(context,output,html)');
 for(const name of ['child','component'])replace(name+'(context,output,value,',name+'(context,output,render,value,');
 replace('directComponent(context,output,component,','directComponent(context,output,render,component,');
 replace('keyedChild(output,value){','keyedChild(context,output,render,value){');
 replace("writeDirectDeferred(output.context,output,normalizeRenderResult(value),'',0,true)","writeDirectDeferred(context,output,normalizeRenderResult(value),'',0,true)");
 source=source.replaceAll('writeDirectDeferred(context,output,','writeDirectDeferred(context,output,render,');
 replace('const rendered=output.render(value);','const rendered=render(value);');
 source=source.replaceAll('finishDirectDeferred(output,','finishDirectDeferred(context,output,');
 replace("const output={context,sink:shared??{value:''},render,shared:!!shared};","const output=shared??{value:''};");
 source=source.replaceAll('executeDirectWriter(invocation,output)','executeDirectWriter(context,invocation,output,render,!!shared)');
 const start=source.indexOf('function executeDirectWriter(context,invocation,output,render,!!shared){');
 const end=source.indexOf('function writeDirectDeferred(',start);
 if(start<0||end<0)throw Error('Missing execution driver');
 source=source.slice(0,start)+`
function executeDirectWriter(context,invocation,output,render,shared){
 const result=invocation.program.ssr(generatedSsrOperations,context,invocation,output,render);
 if(result instanceof Promise)return result.then(value=>{
  if(value!==output)throw Error('Generated direct writer rejected its input');
  return shared?'':output.value;
 });
 if(result!==output)throw Error('Generated direct writer rejected its input');
 return shared?'':output.value;
}
`+source.slice(end);
 writeFileSync(dir+'direct-writer-handle-'+runtime+'.mjs',source);
}
writeFileSync(dir+'direct-writer-handle-run.mjs',readFileSync(dir+'direct-writer-current-run.mjs','utf8')
 .replaceAll("'direct-writer-current-'+runtime","'direct-writer-handle-'+runtime")
 .replaceAll("'task-selection-opt-in-current'","'direct-writer-current-'+runtime")
 .replace('direct-writer-current-results.json','direct-writer-handle-results.json'));
