import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
for(const limit of [8192]){
 let source=readFileSync(dir+'direct-writer-continuation.mjs','utf8');
 const replace=(before,after)=>{if(source.split(before).length!==2)throw Error('Unexpected site: '+before);source=source.replace(before,after);};
 replace('context.experimentalSink={value:""};',`context.experimentalSink={parts:[],chunks:[],buffered:0,characters:0,limit:${limit}};`);
 replace('html=context.experimentalSink.value+html;','html=finishStringBatches(context.experimentalSink)+html;');
 replace("sink.value=appendBoundedHtml(this.context,sink.value,'<!-- -->');","appendSharedSink(this.context,sink,'<!-- -->');");
 replace('sink.value=appendBoundedHtml(this.context,sink.value,result.html);','appendSharedSink(this.context,sink,result.html);');
 replace('function appendSharedSink(context,sink,text){',`function appendSharedSink(context,sink,text){
 if(sink.parts){
  if(text==='')return;
  sink.characters+=text.length;
  if(sink.characters>context.maxOutputBytes)throw new SsrOutputLimitError(context.maxOutputBytes);
  if(sink.buffered+text.length>sink.limit)flushStringBatch(sink);
  if(text.length>=sink.limit){sink.chunks.push(text);return;}
  sink.parts.push(text);sink.buffered+=text.length;
  if(sink.buffered===sink.limit)flushStringBatch(sink);
  return;
 }`);
 source+=`
function flushStringBatch(sink){
 if(!sink.parts.length)return;
 sink.chunks.push(sink.parts.length===1?sink.parts[0]:sink.parts.join(''));
 sink.parts=[];sink.buffered=0;
}
function finishStringBatches(sink){
 flushStringBatch(sink);
 const html=sink.chunks.length===1?sink.chunks[0]:sink.chunks.join('');
 sink.chunks=[];
 return html;
}
`;
 const variant='direct-writer-batches-'+limit;
 writeFileSync(dir+variant+'.mjs',source);
 writeFileSync(dir+variant+'-run.mjs',readFileSync(dir+'map-fragment-run.mjs','utf8').replaceAll('map-fragment',variant).replaceAll('marker-hex-current','direct-writer-continuation'));
}
