import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const results=[];
for(const runtime of ['node','bun']){
 const r=spawnSync(runtime,['.tmp/ssr-large-profile/direct-writer-validation-worker.mjs'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 const result=JSON.parse(r.stdout);
 writeFileSync('.tmp/ssr-large-profile/direct-writer-validation-'+runtime+'.log',r.stderr);
 results.push(result);
 console.log(runtime,result.results.length,'ordering/failure cases passed');
}
writeFileSync('.tmp/ssr-large-profile/direct-writer-validation-results.json',JSON.stringify(results,null,2));
