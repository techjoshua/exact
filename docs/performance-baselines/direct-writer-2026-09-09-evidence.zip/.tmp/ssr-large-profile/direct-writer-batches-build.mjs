import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
let builder=readFileSync(dir+'string-batches-build.mjs','utf8')
 .replace('for(const limit of [2048,8192])','for(const limit of [8192])')
 .replaceAll('shared-accumulator-ranges','direct-writer-continuation')
 .replace("const variant='string-batches-'+limit;","const variant='direct-writer-batches-'+limit;")
 .replace(".replaceAll('map-fragment',variant)",".replaceAll('map-fragment',variant).replaceAll('marker-hex-current','direct-writer-continuation')");
writeFileSync(dir+'direct-writer-batches-generated-build.mjs',builder);
await import('./direct-writer-batches-generated-build.mjs');
