import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
const worker=root+'ready-props-stable-timing-worker.mjs';
let source=fs.readFileSync(root+'projector-warm50-worker.mjs','utf8');
source="import os from 'node:os';\nos.setPriority(0,os.constants.priority.PRIORITY_BELOW_NORMAL);\n"+source;
source=source.replace('runtime:process.versions.bun??process.version','runtime:process.versions.bun??process.version,processPriority:os.getPriority()');
fs.writeFileSync(worker,source);
const rows=[];
for(const scenario of ['assets','large'])for(const runtime of ['node','bun'])for(let round=0;round<2;round++)for(const variant of round?['candidate','integrated']:['integrated','candidate']){
 const entry=root+(variant==='candidate'?'ready-props-stable':'direct-execution-integrated')+'/server-entry.js';
 const artifactSha256=createHash('sha256').update(fs.readFileSync(entry)).digest('hex');
 assert.equal(artifactSha256,variant==='candidate'?'99f76e4e06e41960c5a6da7a1a6669e197051160e5987f5ba6eefb17cbd9d3ba':'2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18');
 const run=spawnSync(runtime,[worker,entry,'encoded',scenario,'20000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 assert.equal(run.status,0,run.stderr+run.stdout);
 const row={runtimeId:runtime,variant,round,artifactSha256,...JSON.parse(run.stdout)};
 assert.ok(row.processPriority>0);
 const peer=rows.find(r=>r.scenario===scenario);if(peer)assert.equal(row.hash,peer.hash);
 rows.push(row);fs.writeFileSync(root+'ready-props-stable-timing.json',JSON.stringify(rows,null,2));
 console.log(runtime,variant,scenario,round,row.usPerRender.toFixed(2),'us; priority',row.processPriority);
}
assert.equal(rows.length,16);
