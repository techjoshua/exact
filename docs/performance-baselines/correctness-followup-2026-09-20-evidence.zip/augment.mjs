import {readFileSync,writeFileSync} from 'node:fs';
import {summarizeSsrCapacityCapture} from '../../framework-comparison/src/ssr-capacity-report.mjs';
const root=import.meta.dirname,prefix='docs/performance-baselines/correctness-followup-2026-09-20';
const read=p=>JSON.parse(readFileSync(p));
const ratios=read(root+'/ratio-comparison.json');
const rows=[];
for(const r of ratios){const name=r.runtime+(r.mode==='stream'?'-stream':'')+'-'+r.lane;const prev=summarizeSsrCapacityCapture(read('docs/performance-baselines/wsl-recovery-final-2026-09-19-'+name+'.json')).filter(x=>x.concurrency===32);const ratio=prev.find(x=>x.name==='eXact').rps/prev.find(x=>x.name==='React').rps; r.recoveryReference={ratio,changePercent:100*(r.after.ratio/ratio-1)}; rows.push(`| ${r.runtime}/${r.mode} | ${r.lane==='multi'?'preloaded':'normal'} | ${ratio.toFixed(3)}× | ${r.recoveryReference.changePercent.toFixed(1)}% |`);}
const bun=summarizeSsrCapacityCapture(read(root+'/bun-multi.json')).filter(x=>x.name==='eXact');const c64=bun.find(x=>x.concurrency===64).rps,c128=bun.find(x=>x.concurrency===128).rps;
const extra=['## Interpretation and older reference','',
'Results after the latest correctness fixes do not show a uniform throughput change. Against the preceding capture, four c32 eXact/React ratios improve and four decline. These ratios are the requested control-normalized performance measure; they do not independently establish which code or host behavior caused a change. No optimization was made during this measurement run.','',
'Node eXact and React server entry artifacts, the server package, and the Node adapter are byte-identical to the preceding capture. On Bun, the eXact server entry changed to supply the required empty response body; React, the server package, and the Bun adapter remain identical. Therefore Node differences cannot be attributed to changed measured server code. The small Bun streaming declines require a controlled paired experiment before attributing them to the body field.','',
'The older [September 19 recovery capture](wsl-recovery-final-2026-09-19.md) remains the performance reference below. These gaps remain unresolved; this publication does not claim full recovery.','',
'| Runtime/API | Loading | September 19 ratio | Current ratio change |','| --- | --- | ---: | ---: |',...rows,'',
`Bun preloaded string throughput is ${Math.round(c64).toLocaleString('en-US')} RPS at c64 and ${Math.round(c128).toLocaleString('en-US')} RPS at c128, a ${(100*(1-c128/c64)).toFixed(1)}% decline. This run does not reproduce the earlier sharp concurrency-128 drop, but does not establish its underlying cause.`,'',
'eXact FCP is 50.53 ms mean / 48 ms p50, versus 51.47 / 48 ms in the preceding capture. All five controlled frameworks have 48 ms p50 in this run with the shared presentation workload. Earlier styling-mismatched captures remain unsuitable for isolating framework paint overhead.','',
'All 740 request errors in the sustained matrix occurred in React Node streaming scheduled-load stages: 545 at 8,000 offered RPS and 195 at 10,000. All other capacity stages had zero request errors; invalid responses were zero. Missed arrivals are retained separately.','',
'An earlier observation of five pixels of horizontal overflow on the Tasks documentation page at a 390-pixel viewport remains outside this benchmark work.',''];
writeFileSync(prefix+'.md',readFileSync(prefix+'.md','utf8')+'\n'+extra.join('\n'));
const archive=read(prefix+'.json');archive.ratioComparison=ratios;archive.artifactComparison=read(root+'/artifact-comparison.json');archive.bunStringConcurrency={c64,c128,changePercent:100*(c128/c64-1)};writeFileSync(prefix+'.json',JSON.stringify(archive,null,2)+'\n');
writeFileSync(root+'/previous-publication-comparison.json',JSON.stringify(ratios,null,2)+'\n');
console.log(JSON.stringify({ratios,bun:{c64,c128}},null,2));
