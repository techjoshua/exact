import { writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
import { StagingReadable } from './staging-readable.mjs';

const samples = [];
const staticPart = Buffer.from('<p class="row">');
for (const rows of [32, 512, 8192]) {
  const dynamic = 'é水' + 'x'.repeat(100) + '</p>';
  const expectedBytes = rows * (staticPart.length + Buffer.byteLength(dynamic));
  const produce = async writer => {
    for (let i = 0; i < rows; i++) {
      const stat = writer.static(staticPart);
      if (stat) await stat;
      const value = writer.write(dynamic);
      if (value) await value;
    }
  };
  async function run(threshold, iterations) {
    const start = performance.now();
    for (let i = 0; i < iterations; i++) {
      const source = new StagingReadable(produce, { flushThresholdBytes: threshold });
      let bytes = 0;
      await new Promise((resolve, reject) => {
        source.on('data', chunk => { bytes += chunk.length; });
        source.once('error', reject);
        source.once('end', resolve);
      });
      assert.equal(bytes, expectedBytes);
    }
    return (performance.now() - start) * 1e6 / iterations;
  }
  for (const threshold of [4096, 8192, 16384]) await run(threshold, 30);
  for (let round = 0; round < 10; round++) {
    for (const threshold of round % 2 ? [16384, 8192, 4096] : [4096, 8192, 16384]) {
      const iterations = rows > 1000 ? 40 : 400;
      samples.push({ rows, expectedBytes, threshold, round, iterations, nsPerOperation: await run(threshold, iterations) });
    }
  }
}
await writeFile('.tmp/ssr-throughput/staging-size-results.json', JSON.stringify(samples, null, 2));
for (const bytes of [...new Set(samples.map(s => s.expectedBytes))]) {
  for (const threshold of [4096, 8192, 16384]) {
    const group = samples.filter(s => s.expectedBytes === bytes && s.threshold === threshold);
    console.log(bytes, threshold, Math.round(group.reduce((sum, s) => sum + s.nsPerOperation, 0) / group.length));
  }
}
