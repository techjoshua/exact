import { Readable } from 'node:stream';

const encoder = new TextEncoder();

/** Experimental pull-started producer with bounded byte batches and request-owned staging. */
export class StagingReadable extends Readable {
  constructor(produce, { flushThresholdBytes = 8192, cancel = () => {}, signal } = {}) {
    if (!Number.isSafeInteger(flushThresholdBytes) || flushThresholdBytes < 4)
      throw new RangeError('flushThresholdBytes must be a safe integer of at least 4');
    super({ highWaterMark: flushThresholdBytes });
    this.produce = produce;
    this.cancel = cancel;
    this.controller = new AbortController();
    this.staging = undefined;
    this.offset = 0;
    this.parts = [];
    this.bytes = 0;
    this.pendingSurrogate = '';
    this.waiter = undefined;
    this.started = false;
    this.completed = false;
    this.threshold = flushThresholdBytes;
    this.signal = signal;
    this.abort = () => this.destroy(asError(signal.reason));
    if (signal?.aborted) queueMicrotask(this.abort);
    else signal?.addEventListener('abort', this.abort, { once: true });
  }

  /** Starts once; later demand releases a producer suspended by push(false). */
  _read() {
    const waiter = this.waiter;
    this.waiter = undefined;
    waiter?.resolve();
    if (this.started) return;
    this.started = true;
    const produce = this.produce;
    this.produce = undefined;
    const writer = {
      write: value => this.writeText(value),
      static: value => this.writeStatic(value),
      flush: () => this.flush(),
      beforeAwait: async work => {
        // Work is a thunk: a failed flush cannot leave a newly created rejection unobserved.
        await this.flush();
        this.assertOpen();
        return work();
      }
    };
    void (async () => {
      try {
        this.assertOpen();
        await produce(writer, this.controller.signal);
        if (this.pendingSurrogate) {
          this.pendingSurrogate = '';
          await this.writeText('\ufffd');
        }
        await this.flush();
        this.assertOpen();
        this.completed = true;
        this.push(null);
      } catch (error) {
        this.destroy(asError(error));
      }
    })();
  }

  /** Encodes dynamic spans directly into unused staging space, preserving split UTF-16 pairs. */
  writeText(value) {
    this.assertOpen();
    if (!value) return;
    value = this.pendingSurrogate + value;
    this.pendingSurrogate = '';
    const last = value.charCodeAt(value.length - 1);
    if (last >= 0xd800 && last <= 0xdbff) {
      this.pendingSurrogate = value.slice(-1);
      value = value.slice(0, -1);
    }
    return this.encodeDynamic(value, 0);
  }

  /** Continues encoding only when transport demand allows it. */
  encodeDynamic(value, index) {
    while (index < value.length) {
      this.assertOpen();
      if (!this.staging) this.staging = Buffer.allocUnsafe(this.threshold);
      const space = Math.min(this.threshold - this.bytes, this.threshold - this.offset);
      const { read, written } = encoder.encodeInto(
        value.slice(index), this.staging.subarray(this.offset, this.offset + space)
      );
      if (!read) {
        const pending = this.flush();
        if (pending) return pending.then(() => this.encodeDynamic(value, index));
        continue;
      }
      this.parts.push(this.staging.subarray(this.offset, this.offset + written));
      this.offset += written;
      this.bytes += written;
      index += read;
      if (this.bytes === this.threshold) {
        const pending = this.flush();
        if (pending) return pending.then(() => this.encodeDynamic(value, index));
      }
    }
  }

  /** Accepts complete immutable UTF-8 constants; string fallbacks preserve split surrogate semantics. */
  writeStatic(value) {
    if (!Buffer.isBuffer(value)) return this.writeText(value);
    this.assertOpen();
    if (value.length === 0) return;
    if (this.pendingSurrogate) {
      this.pendingSurrogate = '';
      const pending = this.writeText('\ufffd');
      if (pending) return pending.then(() => this.appendStatic(value, 0));
    }
    return this.appendStatic(value, 0);
  }

  /** Splits static spans without copying their immutable backing memory. */
  appendStatic(value, index) {
    while (index < value.length) {
      this.assertOpen();
      const count = Math.min(value.length - index, this.threshold - this.bytes);
      this.parts.push(value.subarray(index, index + count));
      this.bytes += count;
      index += count;
      if (this.bytes === this.threshold) {
        const pending = this.flush();
        if (pending) return pending.then(() => this.appendStatic(value, index));
      }
    }
  }

  /** Publishes a nonempty batch and relinquishes staging ownership before downstream observes it. */
  flush() {
    this.assertOpen();
    if (this.bytes === 0) return;
    const chunk = this.parts.length === 1 ? this.parts[0] : Buffer.concat(this.parts, this.bytes);
    this.parts = [];
    this.bytes = 0;
    this.staging = undefined;
    this.offset = 0;
    if (!this.push(chunk)) {
      this.assertOpen();
      return new Promise((resolve, reject) => { this.waiter = { resolve, reject }; }).then(() => this.assertOpen());
    }
  }

  /** Rejects resumed work after cancellation instead of allocating new buffers. */
  assertOpen() {
    if (this.signal?.aborted) throw asError(this.signal.reason);
    if (this.destroyed) throw this.controller.signal.reason ?? new Error('SSR stream destroyed');
  }

  /** Drops owned memory, wakes blocked production, removes listeners, and cancels the body once. */
  _destroy(error, callback) {
    this.produce = undefined;
    this.parts = [];
    this.bytes = 0;
    this.offset = 0;
    this.staging = undefined;
    this.pendingSurrogate = '';
    this.signal?.removeEventListener('abort', this.abort);
    this.signal = undefined;
    this.abort = undefined;
    const reason = error ?? new Error('SSR stream destroyed');
    this.controller.abort(reason);
    const waiter = this.waiter;
    this.waiter = undefined;
    waiter?.reject(reason);
    const cancel = this.cancel;
    this.cancel = undefined;
    Promise.resolve().then(() => this.completed ? undefined : cancel(reason)).then(
      () => callback(error),
      cleanup => callback(error ? new AggregateError([error, cleanup], error.message) : asError(cleanup))
    );
  }
}

function asError(value) {
  return value instanceof Error ? value : new Error('SSR stream failed', { cause: value });
}
