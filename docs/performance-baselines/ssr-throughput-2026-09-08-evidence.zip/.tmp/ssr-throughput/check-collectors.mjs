import assert from 'node:assert/strict';
import {createByteCollector,poolStats} from './byte-collector.mjs';
for(const mode of ['concat','pool']){
 for(const parts of [['hello'],['caf\u00e9','<&'],['\ud83d','','\ude80'],['\ud83d','x'],['\ud83d','\ud83d','\ude80'],['\ude80'],['x'.repeat(100000),'\ud83d','\ude80']]){
 const c=createByteCollector(mode);for(const p of parts)c.write(p);assert.deepEqual(c.finish(),Buffer.from(parts.join('')));c.release();c.release();
 }
 const live=Array.from({length:50},(_,i)=>{const c=createByteCollector(mode);const v='secret-'+i;c.write(v);return {c,v,buffer:c.finish()};});
 for(const {c,v,buffer} of live){assert.equal(buffer.toString(),v);c.release();}
}
assert.ok(poolStats().retained<=16);assert.ok(poolStats().reused>0);
console.log('Unicode, growth, in-flight isolation, and bounded pool checks passed',poolStats());
