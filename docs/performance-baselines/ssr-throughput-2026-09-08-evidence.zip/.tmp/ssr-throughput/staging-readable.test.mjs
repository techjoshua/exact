import assert from 'node:assert/strict';
import { test } from 'node:test';
import { once } from 'node:events';
import { setImmediate as tick } from 'node:timers/promises';
import { StagingReadable } from './staging-readable.mjs';
import { Writable } from 'node:stream';
import { pipeline } from 'node:stream/promises';

async function collect(stream) {
  const parts = [];
  for await (const chunk of stream) parts.push(chunk);
  return Buffer.concat(parts);
}

test('threshold batches preserve Unicode, static bytes, hydration, and closing tags', async () => {
  for (const threshold of [4, 7, 4096, 8192, 16384]) {
    const chunks = [];
    const stream = new StagingReadable(async writer => {
      await writer.static(Buffer.from('<html><head></head>'));
      await writer.flush();
      await writer.write('<body>\ud83d');
      await writer.flush();
      await writer.write('\ude42' + 'é水'.repeat(20000));
      await writer.write('\ud800');
      await writer.static(Buffer.from('<script>{"state":1}</script></body></html>'));
    }, { flushThresholdBytes: threshold });
    stream.on('data', chunk => { assert.ok(chunk.length <= threshold); chunks.push(chunk); });
    await once(stream, 'end');
    assert.equal(Buffer.concat(chunks).toString(), '<html><head></head><body>🙂' + 'é水'.repeat(20000) + '\ufffd<script>{"state":1}</script></body></html>');
  }
});

test('head and pre-task flushes publish small batches before task completion', async () => {
  let release;
  const task = new Promise(resolve => { release = resolve; });
  const parts = [];
  const stream = new StagingReadable(async writer => {
    await writer.write('<head></head>');
    await writer.flush();
    await writer.write('<body>ready');
    await writer.beforeAwait(() => task);
    await writer.write('done</body>');
  });
  stream.on('data', chunk => parts.push(chunk.toString()));
  await tick();
  assert.deepEqual(parts, ['<head></head>', '<body>ready']);
  release();
  await once(stream, 'end');
  assert.equal(parts.join(''), '<head></head><body>readydone</body>');
});

test('backpressure pauses production and never overwrites previously published bytes', async () => {
  let writes = 0;
  const stream = new StagingReadable(async writer => {
    for (let i = 0; i < 100; i++) {
      writes++;
      await writer.write(String(i % 10).repeat(16));
    }
  }, { flushThresholdBytes: 16 });
  stream.read(0);
  await tick();
  assert.equal(writes, 1);
  assert.equal(stream.readableLength, 16);
  const output = await collect(stream);
  assert.equal(output.toString(), Array.from({ length: 100 }, (_, i) => String(i % 10).repeat(16)).join(''));
});

test('producer failure destroys the stream, discards staging, and cancels once', async () => {
  const failure = new Error('producer failed');
  let cancelled = 0;
  const stream = new StagingReadable(async writer => {
    await writer.write('unflushed');
    throw failure;
  }, { cancel(reason) { assert.equal(reason, failure); cancelled++; } });
  await assert.rejects(collect(stream), error => error === failure);
  assert.equal(stream.destroyed, true);
  assert.equal(stream.staging, undefined);
  assert.equal(stream.parts.length, 0);
  assert.equal(stream.produce, undefined);
  stream.destroy();
  assert.equal(cancelled, 1);
});

test('abort while backpressured wakes production and releases retained buffers', async () => {
  const controller = new AbortController();
  let exited = false;
  let cancelled = 0;
  const stream = new StagingReadable(async writer => {
    try { await writer.write('x'.repeat(1024)); } finally { exited = true; }
  }, { flushThresholdBytes: 8, signal: controller.signal, cancel() { cancelled++; } });
  const closed = new Promise(resolve => stream.once('close', resolve));
  const failures = [];
  stream.on('error', error => failures.push(error));
  stream.read(0);
  await tick();
  controller.abort(new Error('disconnected'));
  await closed;
  assert.equal(exited, true);
  assert.equal(cancelled, 1);
  assert.equal(failures.length, 1);
  assert.equal(stream.waiter, undefined);
  assert.equal(stream.staging, undefined);
  assert.deepEqual(stream.parts, []);
});

test('cleanup failure remains observable alongside the producer error', async () => {
  const failure = new Error('producer');
  const cleanup = new Error('cleanup');
  const stream = new StagingReadable(async () => { throw failure; }, { cancel() { throw cleanup; } });
  await assert.rejects(collect(stream), error => error instanceof AggregateError && error.errors[0] === failure && error.errors[1] === cleanup);
});

test('pre-aborted streams do not invoke producers and trailing surrogate is encoded at EOF', async () => {
  let started = false;
  const stream = new StagingReadable(async () => { started = true; }, { signal: AbortSignal.abort(new Error('already aborted')) });
  await assert.rejects(collect(stream), /already aborted/);
  assert.equal(started, false);
  assert.equal((await collect(new StagingReadable(writer => writer.write('\ud800')))).toString(), '\ufffd');
});

test('reject invalid thresholds before allocating memory', () => {
  for (const value of [0, -1, 3, 3.5, NaN, Infinity]) assert.throws(() => new StagingReadable(() => {}, { flushThresholdBytes: value }), RangeError);
});

test('destination failure destroys the producer and releases request-owned staging', async () => {
  let cancelled = 0;
  const failure = new Error('socket write failed');
  const stream = new StagingReadable(async writer => {
    for (let i = 0; i < 100; i++) await writer.write('rendered output'.repeat(100));
  }, { cancel() { cancelled++; } });
  const destination = new Writable({ write(_chunk, _encoding, done) { done(failure); } });
  await assert.rejects(pipeline(stream, destination), error => error === failure);
  assert.equal(stream.destroyed, true);
  assert.equal(destination.destroyed, true);
  assert.equal(stream.staging, undefined);
  assert.equal(stream.parts.length, 0);
  assert.equal(cancelled, 1);
});

test('concurrent requests share immutable static bytes without sharing dynamic output', async () => {
  const staticPart = Buffer.from('<section>');
  const outputs = await Promise.all(Array.from({ length: 24 }, (_, id) => collect(new StagingReadable(async writer => {
    for (let i = 0; i < 10; i++) {
      await writer.static(staticPart);
      await writer.write(`request-${id}</section>`);
    }
  }, { flushThresholdBytes: 32 }))));
  for (let id = 0; id < outputs.length; id++) assert.equal(outputs[id].toString(), `<section>request-${id}</section>`.repeat(10));
  assert.equal(staticPart.toString(), '<section>');
});
