import {exactResponseBodyOf} from '@exactjs/server';
import {writeNodeResponse as originalWriter} from '@exactjs/node-adapter';
import {createByteCollector} from './byte-collector.mjs';
const environment=Object.freeze({encodedByteLength:Buffer.byteLength});
export async function writeNodeResponse(response,result,signal,logger){
 const body=exactResponseBodyOf(result);
 if(body?.kind!=='produced'||!body.writeSynchronously)return originalWriter(response,result,signal,logger);
 response.statusCode=result.status;
 for(const [name,value] of Object.entries(result.headers))response.setHeader(name,value);
 const collector=createByteCollector(process.env.SSR_BUFFER_MODE);
 let handedOff=false; let text="";
 try{
  const completion=body.writeSynchronously(chunk=>{if(signal?.aborted)throw signal.reason;text+=chunk;},environment);
  if(completion)await completion;
  collector.write(text); const output=collector.finish();
  if(signal?.aborted)throw signal.reason;
  response.end(output,()=>collector.release());
  handedOff=true;
 }catch(error){
  if(!signal?.aborted||error!==signal.reason)console.error(error);
  try{await body.cancel(error);}catch(cleanup){console.error(cleanup);}
  if(!response.headersSent){for(const name of response.getHeaderNames())response.removeHeader(name);response.statusCode=500;response.setHeader('content-type','application/json; charset=utf-8');response.end(JSON.stringify({error:'internal_error'}));}
  else if(!response.destroyed)response.destroy(error);
 }finally{if(!handedOff)collector.release();}
}
