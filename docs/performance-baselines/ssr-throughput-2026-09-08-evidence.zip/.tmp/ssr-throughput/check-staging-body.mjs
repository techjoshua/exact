import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createExactProducedResponse, exactResponseBodyOf } from '@exactjs/server';
import * as baseline from './baseline.mjs';
import * as hoisted from './hoisted-buffers.mjs';
import { createStagedBodyReadable } from './staging-writer.mjs';
const data = JSON.parse(await readFile('.tmp/ssr-throughput/data.json', 'utf8'));
for (const threshold of [4096, 8192, 16384]) {
  let expected = '';
  baseline.renderParticipantToSink(data, '/incidents/inc-101', span => expected += span, Buffer.byteLength);
  const response = createExactProducedResponse(200, {}, write => {
    hoisted.renderParticipantToSink(data, '/incidents/inc-101', write, Buffer.byteLength);
  });
  const chunks = [];
  for await (const chunk of createStagedBodyReadable(exactResponseBodyOf(response), { flushThresholdBytes: threshold })) chunks.push(chunk);
  assert.equal(Buffer.concat(chunks).toString(), expected);
}
console.log('Actual compiled fixture output matches at 4, 8, and 16 KiB.');
