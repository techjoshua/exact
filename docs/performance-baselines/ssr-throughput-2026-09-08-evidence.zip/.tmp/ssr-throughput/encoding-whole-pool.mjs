import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createByteCollector,poolStats} from './byte-collector.mjs';
import {renderParticipantToSink} from '../../framework-comparison/participants/exact/dist-server/server-entry.js';
const data=JSON.parse(await readFile('.tmp/ssr-throughput/data.json','utf8'));
const spans=[];renderParticipantToSink(data,'/incidents/inc-101',s=>spans.push(s),Buffer.byteLength);
const cases=[{name:'actual-rendered-page',spans,iterations:20000},...[65536,1048576].map(size=>({name:size+'-bytes',spans:Array.from({length:32},()=>('x'.repeat(size/32-4)+'🚀')),iterations:size===65536?2000:100}))];
const methods={
 wholePool(parts){let text="";for(const p of parts)text+=p;const c=createByteCollector("pool");c.write(text);const b=c.finish();c.release();return b;},
 string(parts){let text='';for(const p of parts)text+=p;return Buffer.from(text);},
 concat(parts){const c=createByteCollector('concat');for(const p of parts)c.write(p);const b=c.finish();c.release();return b;},
 pool(parts){const c=createByteCollector('pool');for(const p of parts)c.write(p);const b=c.finish();c.release();return b;}
};
const results=[];let checksum=0;
for(const c of cases){
 const expected=Buffer.from(c.spans.join(''));
 for(const fn of Object.values(methods)){assert.deepEqual(fn(c.spans),expected);for(let i=0;i<1000;i++)checksum+=fn(c.spans).length;}
 for(let round=0;round<10;round++)for(const name of round%2?Object.keys(methods).reverse():Object.keys(methods)){
  const start=performance.now();for(let i=0;i<c.iterations;i++)checksum+=methods[name](c.spans).length;
  results.push({case:c.name,name,round,iterations:c.iterations,nsPerOperation:(performance.now()-start)*1e6/c.iterations});
 }
}
await writeFile('.tmp/ssr-throughput/encoding-whole-pool.json',JSON.stringify({results,checksum,pool:poolStats()}));
for(const c of cases)for(const name of Object.keys(methods)){const rows=results.filter(x=>x.case===c.name&&x.name===name);console.log(c.name,name,Math.round(rows.reduce((s,x)=>s+x.nsPerOperation,0)/rows.length));}
