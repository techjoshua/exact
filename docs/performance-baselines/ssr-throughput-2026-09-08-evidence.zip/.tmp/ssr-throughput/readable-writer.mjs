import {Readable} from 'node:stream';
import {exactResponseBodyOf} from '@exactjs/server';
import {writeNodeResponse as originalWriter} from '@exactjs/node-adapter';
const environment=Object.freeze({encodedByteLength:Buffer.byteLength});
const staticBuffers=new Map();let staticBytes=0;
const stats={hits:0,misses:0,dynamic:0};
export const bufferStats=()=>({...stats,entries:staticBuffers.size,bytes:staticBytes});
function staticBuffer(value){
 const prior=staticBuffers.get(value);if(prior){stats.hits++;return prior;}
 stats.misses++;const buffer=Buffer.from(value);
 if(staticBuffers.size<4096&&staticBytes+buffer.length<=4*1024*1024){staticBuffers.set(value,buffer);staticBytes+=buffer.length;}
 return buffer;
}
export class ProducedReadable extends Readable {
 constructor(body,signal){super();this.body=body;this.signal=signal;this.started=false;this.ready=false;this.chunks=[];this.index=0;}
 _read(){
  if(!this.started){
   this.started=true;let pending='';
   const write=(value)=>{
    if(this.signal?.aborted)throw this.signal.reason;
    if(!value)return;
    if(pending){value=pending+value;pending='';}
    const last=value.charCodeAt(value.length-1);
    if(last>=0xd800&&last<=0xdbff){pending=value.slice(-1);value=value.slice(0,-1);}
    if(value){stats.dynamic++;this.chunks.push(Buffer.from(value));}
   };
   write.static=value=>{
    if(this.signal?.aborted)throw this.signal.reason;
    if(!value)return;
    const last=value.charCodeAt(value.length-1);
    if(pending||(last>=0xd800&&last<=0xdbff)){write(value);return;}
    this.chunks.push(staticBuffer(value));
   };
   const finish=()=>{if(pending)this.chunks.push(Buffer.from(pending));this.ready=true;this._read();};
   try{const completion=this.body.writeSynchronously(write,environment);if(completion)completion.then(finish,error=>this.destroy(error));else finish();}catch(error){this.destroy(error);}
   return;
  }
  if(!this.ready)return;
  while(this.index<this.chunks.length){const value=this.chunks[this.index];this.chunks[this.index++]=undefined;if(!this.push(value))return;}
  this.chunks=[];this.push(null);
 }
 _destroy(error,done){this.chunks=[];this.body.cancel(error).then(()=>done(error),cleanup=>done(error??cleanup));}
}
export async function writeNodeResponse(response,result,signal,logger){
 const body=exactResponseBodyOf(result);
 if(body?.kind!=='produced'||!body.writeSynchronously)return originalWriter(response,result,signal,logger);
 response.statusCode=result.status;
 for(const [name,value] of Object.entries(result.headers))response.setHeader(name,value);
 const source=new ProducedReadable(body,signal);
 await new Promise(resolve=>{
  const abort=()=>source.destroy(signal?.reason??new Error('Client disconnected'));
  const close=()=>{if(!source.destroyed)source.destroy();cleanup();resolve();};
  const cleanup=()=>{signal?.removeEventListener('abort',abort);response.off('close',close);response.off('finish',close);};
  source.once('error',error=>{
   if(!response.headersSent){for(const name of response.getHeaderNames())response.removeHeader(name);response.statusCode=500;response.setHeader('content-type','application/json; charset=utf-8');response.end(JSON.stringify({error:'internal_error'}));}
   else if(!response.destroyed)response.destroy(error);
   cleanup();resolve();
  });
  response.once('close',close);response.once('finish',close);signal?.addEventListener('abort',abort,{once:true});
  source.pipe(response);
 });
}
