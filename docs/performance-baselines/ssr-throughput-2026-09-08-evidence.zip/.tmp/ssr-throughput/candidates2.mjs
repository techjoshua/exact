import {readFile,writeFile} from 'node:fs/promises';
import {createComparisonService} from '../../framework-comparison/src/service.mjs';
import assert from 'node:assert/strict';
const original=await readFile('framework-comparison/participants/exact/dist-server/server-entry.js','utf8');
const variants={
 baseline:original,
 dense:original.replaceAll('new Array(value.length)', '[]').replaceAll('new Array(fieldCount)', '[]'),
 ancestry:original.replaceAll('this.values.at(-1)', 'this.values[this.values.length - 1]'),
 literal:original.replaceAll('const output = new Array(fieldCount);','const output = [];').replaceAll('output[outputIndex++] = encoded;', 'output.push(encoded);'),
};
const fixture=JSON.parse(await readFile('framework-comparison/fixtures/baseline.json','utf8'));
const service=createComparisonService(fixture);
const data={...await (await service.fetch(new Request('http://localhost/api/session'))).json(),...await (await service.fetch(new Request('http://localhost/api/incidents'))).json()};
await writeFile('.tmp/ssr-throughput/data.json',JSON.stringify(data));
const entries={};
for(const [name,code] of Object.entries(variants)){if(name!=='baseline')assert.notEqual(code,original);await writeFile('.tmp/ssr-throughput/'+name+'.mjs',code);entries[name]=await import('./'+name+'.mjs');}
function render(entry){let output='';const bytes=entry.renderParticipantToSink(data,'/incidents/inc-101',s=>output+=s,Buffer.byteLength);return {output,bytes};}
const expected=render(entries.baseline);
for(const e of Object.values(entries)){assert.deepEqual(render(e),expected);for(let i=0;i<3000;i++)render(e);}
const results=[];
for(let round=0;round<12;round++)for(const name of round%2?Object.keys(entries).reverse():Object.keys(entries)){const start=performance.now();for(let i=0;i<10000;i++)render(entries[name]);results.push({round,name,ms:performance.now()-start});}
await writeFile('.tmp/ssr-throughput/candidates2.json',JSON.stringify(results));
for(const name of Object.keys(entries))console.log(name,results.filter(x=>x.name===name).reduce((s,x)=>s+x.ms,0)/12);
