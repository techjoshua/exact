const pool = [];
const maxPooledBytes = 65536;
let allocated = 0, reused = 0, released = 0;
const rent = size => {
 for(let i=0;i<pool.length;i++)if(pool[i].length>=size){reused++;return pool.splice(i,1)[0];}
 allocated++;return Buffer.allocUnsafe(Math.max(8192,size));
};
const giveBack = buffer => {released++;if(buffer.length<=maxPooledBytes && pool.length<16)pool.push(buffer);};
export const poolStats = () => ({allocated,reused,released,retained:pool.length});

export function createByteCollector(mode) {
 let pending='', total=0, buffer=mode==='pool'?rent(8192):undefined, chunks=[], done=false;
 function append(value) {
  if(!value)return;
  const size=Buffer.byteLength(value);
  if(mode==='concat'){chunks.push(Buffer.from(value));total+=size;return;}
  if(total+size>buffer.length){const next=rent(Math.max(total+size,buffer.length*2));buffer.copy(next,0,0,total);giveBack(buffer);buffer=next;}
  buffer.write(value,total,size,'utf8');total+=size;
 }
 return {
  write(value){
   if(!value)return;
   if(pending){value=pending+value;pending='';}
   const last=value.charCodeAt(value.length-1);
   if(last>=0xd800 && last<=0xdbff){pending=value.slice(-1);value=value.slice(0,-1);}
   append(value);
  },
  finish(){append(pending);pending='';return mode==='concat'?Buffer.concat(chunks,total):buffer.subarray(0,total);},
  release(){if(done)return;done=true;if(buffer)giveBack(buffer);buffer=undefined;chunks=[];}
 };
}
