import {readFile,writeFile} from 'node:fs/promises';
import {profileNodeCpu} from '../../framework-comparison/src/ssr-allocation-profiler.mjs';
import {renderParticipantToSink} from './baseline.mjs';
const data=JSON.parse(await readFile('.tmp/ssr-throughput/data.json','utf8'));
const render=()=>renderParticipantToSink(data,'/incidents/inc-101',()=>{},Buffer.byteLength);
for(let i=0;i<10000;i++)render();
const result=await profileNodeCpu(()=>{for(let i=0;i<100000;i++)render();});
await writeFile('.tmp/ssr-throughput/profile.json',JSON.stringify(result));
console.log(JSON.stringify(result.summary.topSites.slice(0,18)));
