import {readFile,writeFile} from 'node:fs/promises';
let code=await readFile('.tmp/ssr-throughput/static-spans.mjs','utf8');
const buffers=[];
code=code.replace(/__exactSsr\.static\(__exactOutput, ("(?:\\.|[^"\\])*")\)/g,(call,literal)=>{
 const value=JSON.parse(literal);if(/[^\x00-\x7f]/.test(value))return call;
 const name='__node_static_'+buffers.length;buffers.push('const '+name+'=Buffer.from('+literal+');');return '__exactSsr.static(__exactOutput, '+name+')';
});
await writeFile('.tmp/ssr-throughput/hoisted-buffers.mjs',buffers.join('\n')+'\n'+code);
let writer=await readFile('.tmp/ssr-throughput/readable-cork-writer.mjs','utf8');
writer=writer.replace('write.static=value=>{','write.static=value=>{\n    if(Buffer.isBuffer(value)){this.chunks.push(value);return;}');
await writeFile('.tmp/ssr-throughput/readable-hoisted-writer.mjs',writer);
let check=await readFile('.tmp/ssr-throughput/check-readable.mjs','utf8');
check=check.replaceAll('readable-writer.mjs','readable-hoisted-writer.mjs').replaceAll('static-spans.mjs','hoisted-buffers.mjs');
await writeFile('.tmp/ssr-throughput/check-hoisted.mjs',check);
console.log('Hoisted ASCII spans:',buffers.length);
