import { readdir, readFile, writeFile } from 'node:fs/promises';
import { summarizeSsrCapacityCapture } from '../../framework-comparison/src/ssr-capacity-report.mjs';
const summary = { micro: {}, http: {} };
for (const name of await readdir('.tmp/ssr-throughput')) {
  if (/^candidates\d*\.json$/.test(name)) {
    const rows = JSON.parse(await readFile(`.tmp/ssr-throughput/${name}`, 'utf8'));
    summary.micro[name] = Object.fromEntries([...new Set(rows.map(r => r.name))].map(n => {
      const values = rows.filter(r => r.name === n);
      return [n, values.reduce((s, r) => s + r.ms, 0) / values.length];
    }));
  }
  if (/^http-.*\.json$/.test(name) && name !== 'http-profile.json') {
    const capture = JSON.parse(await readFile(`.tmp/ssr-throughput/${name}`, 'utf8'));
    summary.http[name] = summarizeSsrCapacityCapture(capture);
  }
}
await writeFile('docs/performance-baselines/ssr-throughput-2026-09-08.json', JSON.stringify(summary, null, 2) + '\n');
for (const [name, rows] of Object.entries(summary.http)) console.log(name, rows.filter(r => r.concurrency === 32).map(r => `${r.name}: ${Math.round(r.rps)}`).join(', '));
