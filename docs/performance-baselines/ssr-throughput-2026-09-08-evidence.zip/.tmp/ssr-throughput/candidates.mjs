import {readFile,writeFile} from 'node:fs/promises';
import {createComparisonService} from '../../framework-comparison/src/service.mjs';
import assert from 'node:assert/strict';
const original=await readFile('framework-comparison/participants/exact/dist-server/server-entry.js','utf8');
const variants={
 baseline:original,
 projector:original.replace('value.length >= 16 && !state.path','value.length >= 1 && !state.path'),
 wrapper:original.replace('function createPreparedServerRenderProgram(branded, eagerValues, enhancement) {','class ServerProgramInvocation { constructor(program, eagerValues) { this[PreparedServerRenderProgram] = true; this.program = program; this.eagerValues = eagerValues; } }\nfunction createPreparedServerRenderProgram(branded, eagerValues, enhancement) {').replace('const invocation = {\n\t\t[PreparedServerRenderProgram]: true,\n\t\tprogram: branded,\n\t\teagerValues\n\t};','const invocation = new ServerProgramInvocation(branded, eagerValues);'),
 ascii:original.replace('if (!output) return escapeText(value);','if (!output) return escapeText(value);\n if (!/[&<>\\u0080-\\uffff]/.test(value)) { output.accountKnown(value, value.length); return value; }')
};
const fixture=JSON.parse(await readFile('framework-comparison/fixtures/baseline.json','utf8'));
const service=createComparisonService(fixture);
const data={...await (await service.fetch(new Request('http://localhost/api/session'))).json(),...await (await service.fetch(new Request('http://localhost/api/incidents'))).json()};
await writeFile('.tmp/ssr-throughput/data.json',JSON.stringify(data));
const entries={};
for(const [name,code] of Object.entries(variants)){if(name!=='baseline')assert.notEqual(code,original);await writeFile('.tmp/ssr-throughput/'+name+'.mjs',code);entries[name]=await import('./'+name+'.mjs');}
function render(entry){let output='';const bytes=entry.renderParticipantToSink(data,'/incidents/inc-101',s=>output+=s,Buffer.byteLength);return {output,bytes};}
const expected=render(entries.baseline);
for(const e of Object.values(entries)){assert.deepEqual(render(e),expected);for(let i=0;i<3000;i++)render(e);}
const results=[];
for(let round=0;round<12;round++)for(const name of round%2?Object.keys(entries).reverse():Object.keys(entries)){const start=performance.now();for(let i=0;i<10000;i++)render(entries[name]);results.push({round,name,ms:performance.now()-start});}
await writeFile('.tmp/ssr-throughput/candidates.json',JSON.stringify(results));
for(const name of Object.keys(entries))console.log(name,results.filter(x=>x.name===name).reduce((s,x)=>s+x.ms,0)/12);
