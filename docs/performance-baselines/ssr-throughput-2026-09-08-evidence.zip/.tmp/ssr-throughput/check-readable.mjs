import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createExactProducedResponse,exactResponseBodyOf} from '@exactjs/server';
import {ProducedReadable,bufferStats} from './readable-writer.mjs';
import {renderParticipantToSink as original} from '../../framework-comparison/participants/exact/dist-server/server-entry.js';
import {renderParticipantToSink as candidate} from './static-spans.mjs';
const data=JSON.parse(await readFile('.tmp/ssr-throughput/data.json','utf8'));
async function consume(produce){const body=exactResponseBodyOf(createExactProducedResponse(200,{},produce));const stream=new ProducedReadable(body);const chunks=[];for await(const chunk of stream)chunks.push(chunk);return Buffer.concat(chunks);}
for(const title of [data.incidents[0].title,'<&🚀\u2028','x'.repeat(100000)]){
 data.incidents[0].title=title;
 let expected='';original(data,'/incidents/inc-101',s=>expected+=s,Buffer.byteLength);
 const result=await consume(write=>candidate(data,'/incidents/inc-101',write,Buffer.byteLength));
 assert.deepEqual(result,Buffer.from(expected));
}
assert.equal((await consume(write=>{write.static('\ud83d');write('');write.static('\ude80');write('\ud83d');write('x');})).toString(),'🚀\ufffdx');
await assert.rejects(consume(write=>{write('partial');throw new Error('render failure');}),/render failure/);
const hits=bufferStats().hits;await consume(write=>candidate(data,'/incidents/inc-101',write,Buffer.byteLength));assert.ok(bufferStats().hits>hits);
assert.ok(bufferStats().entries>0);console.log('Readable bytes, hydration ordering, Unicode, rejection, and static reuse passed',bufferStats());
