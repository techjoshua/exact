import { pipeline } from 'node:stream/promises';
import { exactResponseBodyOf } from '@exactjs/server';
import { writeNodeResponse as originalWriter } from '@exactjs/node-adapter';
import { StagingReadable } from './staging-readable.mjs';

const environment = Object.freeze({ encodedByteLength: Buffer.byteLength });

/** Bridges the existing non-resumable fixture producer for encoding/transport measurements only. */
export function createStagedBodyReadable(body, options) {
  return new StagingReadable(async writer => {
    const spans = [];
    const write = value => spans.push({ value, static: false });
    write.static = value => spans.push({ value, static: true });
    // Legacy generated functions cannot suspend. This array remains whole-response buffered.
    const completion = body.writeSynchronously(write, environment);
    // Observe cleanup rejection before any backpressure wait can yield to the event loop.
    const settled = completion?.then(() => undefined, error => ({ error }));
    try {
      for (let index = 0; index < spans.length; index++) {
        const span = spans[index];
        spans[index] = undefined;
        let value = span.value;
        // This is the known benchmark envelope, not a general HTML parser or runtime contract.
        if (index === 0 && typeof value === 'string' && value.startsWith('<!doctype html>')) {
          const headEnd = value.indexOf('</head>') + 7;
          if (headEnd >= 7) {
            const pending = writer.write(value.slice(0, headEnd));
            if (pending) await pending;
            const flushed = writer.flush();
            if (flushed) await flushed;
            value = value.slice(headEnd);
          }
        }
        const pending = span.static ? writer.static(value) : writer.write(value);
        if (pending) await pending;
      }
      if (settled) {
        const result = await writer.beforeAwait(() => settled);
        if (result) throw result.error;
      }
    } finally { spans.length = 0; }
  }, { ...options, cancel: reason => body.cancel(reason) });
}

/** Experimental adapter; pipeline destroys both endpoints on producer or transport failure. */
export async function writeNodeResponse(response, result, signal, logger) {
  const body = exactResponseBodyOf(result);
  if (!body?.writeSynchronously) return originalWriter(response, result, signal, logger);
  response.statusCode = result.status;
  for (const [name, value] of Object.entries(result.headers)) response.setHeader(name, value);
  const stream = createStagedBodyReadable(body, {
    signal, flushThresholdBytes: Number(process.env.SSR_FLUSH_THRESHOLD_BYTES ?? 8192)
  });
  try { await pipeline(stream, response, { signal }); }
  catch (error) {
    stream.destroy(error);
    if (!signal?.aborted) console.error('Experimental SSR stream failed', error);
  }
}
