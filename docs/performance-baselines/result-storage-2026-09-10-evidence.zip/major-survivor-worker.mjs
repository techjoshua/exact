import {Session} from 'node:inspector/promises';
import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const [entry,scenario,output]=process.argv.slice(2);
const mod=await import(pathToFileURL(resolve(entry)));
const data=JSON.parse(await readFile('.tmp/positional-leaves/data.json','utf8'));
if(scenario==='large')data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
const render=()=>mod.renderParticipant(data,'/incidents/inc-101',{clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'});
let html;
for(let i=0;i<50000;i++)html=await render();
const session=new Session();session.connect();
try {
 await session.post('HeapProfiler.startSampling',{samplingInterval:16384,includeObjectsCollectedByMajorGC:true,includeObjectsCollectedByMinorGC:false});
 for(let i=0;i<10000;i++)html=await render();
 const {profile}=await session.post('HeapProfiler.stopSampling');
 await writeFile(output,JSON.stringify(profile));
 if(!/^<!doctype html>/i.test(html)||!/<\/body><\/html>\s*$/i.test(html))throw Error('Incomplete document');
 console.log(JSON.stringify({entry,scenario,output,iterations:10000,samplingInterval:16384,includeMinorCollected:false,includeMajorCollected:true,bytes:Buffer.byteLength(html),hash:createHash('sha256').update(html).digest('hex'),artifactSha256:createHash('sha256').update(await readFile(entry)).digest('hex'),runtime:process.version}));
} finally {session.disconnect();}
