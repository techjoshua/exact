import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
const worker=root+'major-survivor-worker.mjs';
fs.writeFileSync(worker,fs.readFileSync(root+'direct-child-boundary-allocation-worker.mjs','utf8').replace('includeObjectsCollectedByMinorGC:true','includeObjectsCollectedByMinorGC:false').replace('includeCollected:true','includeMinorCollected:false,includeMajorCollected:true'));
const rows=[];
for(const scenario of ['small','large'])for(const variant of ['current','react']){
 const entry=variant==='current'?root+'proven-reference-integrated/server-entry.js':'framework-comparison/participants/react/dist-server/server-entry.js';
 const profile=root+`major-survivor-${variant}-${scenario}.heapprofile`;
 const run=spawnSync('node',[worker,entry,scenario,profile],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 assert.equal(run.status,0,run.stderr+run.stdout);
 const row={variant,...JSON.parse(run.stdout)};const sites=new Map();let bytes=0;
 function visit(n){bytes+=n.selfSize;const f=n.callFrame;const key=JSON.stringify([f.functionName,f.url,f.lineNumber+1]);sites.set(key,(sites.get(key)??0)+n.selfSize);for(const child of n.children??[])visit(child);}
 visit(JSON.parse(fs.readFileSync(profile)).head);
 row.estimatedBytesPerRender=bytes/row.iterations;
 row.sites=[...sites].sort((a,b)=>b[1]-a[1]).map(([key,size])=>({site:JSON.parse(key),bytesPerRender:size/row.iterations}));
 rows.push(row);fs.writeFileSync(root+'major-survivor-results.json',JSON.stringify(rows,null,2));
 console.log(variant,scenario,row.estimatedBytesPerRender,row.sites.slice(0,8));
}
