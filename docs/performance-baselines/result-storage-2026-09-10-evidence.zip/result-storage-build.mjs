import fs from 'node:fs';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
let code=fs.readFileSync(root+'proven-reference-integrated/server-entry.js','utf8');
assert.equal(code,fs.readFileSync('framework-comparison/participants/exact/dist-server/server-entry.js','utf8'));
const start=code.indexOf('function createChunkedStringResult('),end=code.indexOf('/** Recognizes normalized document output',start);
assert.ok(start>0&&end>start);
code=code.slice(0,start)+`const resultStorage = Symbol('resultStorage');
const stringResultDescriptors = {
 html: {enumerable:true,configurable:true,get:function(){
  const data=this[resultStorage];
  return data.materialized ??= data.chunks.length===1?data.chunks[0]:data.chunks.join('');
 }}
};
const hydratableResultDescriptors = {
 resumptions: {enumerable:true,configurable:true,get:function(){const value=this[resultStorage].resumptions;return typeof value==='function'?value():value;}},
 htmlWithHydration: stringResultDescriptors.html,
 html: {enumerable:true,configurable:true,get:function(){return this[resultStorage].result.html;}}
};
function createChunkedStringResult(chunks,state,hydrationTable,preloadLinks,wallClockSnapshot){
 const result={html:undefined,state};
 Object.defineProperties(result,stringResultDescriptors);
 Object.defineProperty(result,resultStorage,{value:{chunks,materialized:undefined}});
 if(wallClockSnapshot!==undefined)result.wallClockSnapshot=wallClockSnapshot;
 if(hydrationTable)result.hydrationTable=hydrationTable;
 if(preloadLinks?.length)result.preloadLinks=Object.freeze([...preloadLinks]);
 Object.defineProperty(result,ssrHtmlChunks,{value:chunks});
 return result;
}
function createChunkedHydratableResult(result,resumptions,hydrationScript){
 const htmlChunks=htmlChunksOf(result);
 const chunks=htmlChunks?augmentChunkedBody(htmlChunks,hydrationScript):[augmentDocumentBody(result.html,hydrationScript)];
 const hydratable={resumptions:undefined,htmlWithHydration:undefined,html:undefined,state:result.state,hydrationScript};
 Object.defineProperties(hydratable,hydratableResultDescriptors);
 Object.defineProperty(hydratable,resultStorage,{value:{chunks,materialized:undefined,result,resumptions}});
 if(result.wallClockSnapshot!==undefined)hydratable.wallClockSnapshot=result.wallClockSnapshot;
 if(result.hydrationTable)hydratable.hydrationTable=result.hydrationTable;
 if(result.preloadLinks)hydratable.preloadLinks=result.preloadLinks;
 Object.defineProperty(hydratable,ssrHtmlChunks,{value:htmlChunks??[result.html]});
 Object.defineProperty(hydratable,ssrHydratableChunks,{value:chunks});
 return hydratable;
}
`+code.slice(end);
fs.mkdirSync(root+'result-storage',{recursive:true});fs.writeFileSync(root+'result-storage/server-entry.js',code);
fs.writeFileSync(root+'result-storage-gc-run.mjs',fs.readFileSync(root+'direct-child-boundary-gc-run.mjs','utf8').replaceAll("candidate:d+'direct-child-boundary/server-entry.js'","candidate:d+'result-storage/server-entry.js'").replace('direct-child-boundary-gc-results.json','result-storage-gc-results.json'));
fs.writeFileSync(root+'result-storage-run.mjs',fs.readFileSync(root+'direct-child-boundary-run.mjs','utf8').replaceAll('direct-child-boundary','result-storage').replace("['node','bun']","['bun']"));
