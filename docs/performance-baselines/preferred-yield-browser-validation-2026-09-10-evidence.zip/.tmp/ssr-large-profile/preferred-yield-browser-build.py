import re,json
from pathlib import Path
repo=Path.cwd();base=repo/'.tmp/ssr-large-profile';root=base/'preferred-yield-browser';root.mkdir(exist_ok=True)
def relocate(path):
 text=path.read_text()
 def replace(m):
  if m[2]=='../dist-server/server-entry.js':return m[0]
  value=(path.parent/m[2]).resolve().as_uri()
  if m[2].endswith('/'):value+='/'
  return m[1]+value+m[1]
 return re.sub(r"(['\"])(\.\.?/[^'\"]+)\1",replace,text)
adapter=(repo/'framework-adapters/node-adapter/dist/index.js').as_uri()
node=relocate(repo/'framework-comparison/src/e2e-server.mjs')
node="import {createNodeRenderScheduler} from '"+adapter+"';\n"+node
target='const sockets = new Set();';assert target in node
node=node.replace(target,"const scheduleRender = participant.id === 'exact' ? createNodeRenderScheduler() : undefined;\n"+target,1)
assert node.count('{ clientTags }')==2
node=node.replace('{ clientTags }','{ clientTags, scheduleRender }')
(root/'node-server.mjs').write_text(node)
worker=relocate(repo/'framework-comparison/src/ssr-benchmark-worker.mjs')
worker="import {createNodeRenderScheduler} from '"+adapter+"';\nconst scheduleRender=createNodeRenderScheduler();\n"+worker
worker=worker.replace("const documentOptions = { clientTags: process.env.COMPARISON_CLIENT_TAGS ?? '' };","const documentOptions = { clientTags: process.env.COMPARISON_CLIENT_TAGS ?? '', get scheduleRender(){return participantId==='exact'?scheduleRender:undefined;} };")
worker=worker.replace("const suiteRoot = resolve(import.meta.dirname, '..');",'const suiteRoot = '+json.dumps(str(repo/'framework-comparison'))+';')
(root/'bun-worker.mjs').write_text(worker)
bun=relocate(repo/'framework-comparison/src/e2e-bun-server.mjs')
bun=bun.replace("const suiteRoot = resolve(import.meta.dirname, '..');",'const suiteRoot = '+json.dumps(str(repo/'framework-comparison'))+';')
bun=bun.replace("workerPath: resolve(suiteRoot, 'src/ssr-benchmark-worker.mjs'),",'workerPath: '+json.dumps(str(root/'bun-worker.mjs'))+',')
(root/'bun-server.mjs').write_text(bun)
(root/'setup.mjs').write_text("export default async function(){const h=await import(process.env.COMPARISON_E2E_RUNTIME==='bun'?'./bun-server.mjs':'./node-server.mjs');return h.close;}\n")
(root/'config.mjs').write_text('export default '+json.dumps(dict(testDir=str(repo/'framework-comparison/e2e'),globalSetup=str(root/'setup.mjs'),fullyParallel=False,retries=0,reporter='line',use=dict(trace='retain-on-failure')))+';')
r=(base/'static-invocation-browser.mjs').read_text().replace("'playwright.config.ts'",json.dumps(str(root/'config.mjs'))).replace('static-invocation-browser-','preferred-yield-browser-')
(base/'preferred-yield-browser-run.mjs').write_text(r)
