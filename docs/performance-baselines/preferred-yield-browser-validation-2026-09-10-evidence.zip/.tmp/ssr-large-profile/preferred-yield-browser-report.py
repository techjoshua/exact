import hashlib,json,zipfile
from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'preferred-yield-browser'
logs=[base/f'preferred-yield-browser-{runtime}-{mode}.log' for runtime in ('node','bun') for mode in ('string','stream')]
for p in logs:assert '14 passed' in p.read_text()
report=Path('docs/performance-baselines/preferred-yield-browser-validation-2026-09-10.md')
report.write_text('''# Preferred yield scheduler browser validation

All 56 controlled-service browser checks passed, 14 each for Node string, Node stream, Bun string and Bun stream. The current built eXact participant receives the actual rebuilt createNodeRenderScheduler through scheduleRender. React receives no scheduler. Tests cover server-rendered HTML without JavaScript, hydration, interaction behavior, focused input preservation, validation, recoverable transport failure and event-stream reconnect.

The temporary harness copies existing server harnesses and changes eXact render options to enable scheduling. Relative module locations are adjusted for the scratch directory. Bun uses its native HTTP worker with the same explicit option. Default comparison configuration remains unchanged. Two harness preparation failures (a relocated relative filesystem path and an overly broad text replacement) were corrected before the successful test runs. No framework behavior was changed to pass these tests. All owned harness processes terminated.

The Node-adapter suite passes 38 tests, covering both scheduler.yield and setImmediate fallback paths, cancellation and yield rejection. Adapter build, targeted ESLint, source-architecture, JSDoc, explicit-any ratchet (73/73) and changed-file formatting checks pass.

These are correctness checks, not browser performance measurements. They do not establish paint timing, low-rate HTTP latency or throughput of larger documents. The optimization goal remains open. The adjacent SHA-verified archive contains successful browser logs, harness generation and the source scheduler/tests.
''',encoding='utf8')
files=logs+list(root.glob('*'))+[report,base/'preferred-yield-browser-build.py',base/'preferred-yield-browser-run.mjs',base/'preferred-yield-browser-report.py']+[Path(p) for p in ('framework-adapters/node-adapter/src/render-scheduler.ts','framework-adapters/node-adapter/src/render-scheduler.test.ts','framework-adapters/node-adapter/dist/render-scheduler.js')]
archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for n in manifest:z.write(n,n)
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print('56 browser checks passed;',len(manifest),'archived files verified')
