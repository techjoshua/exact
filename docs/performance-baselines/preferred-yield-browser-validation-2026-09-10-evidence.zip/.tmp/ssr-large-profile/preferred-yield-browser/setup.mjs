export default async function(){const h=await import(process.env.COMPARISON_E2E_RUNTIME==='bun'?'./bun-server.mjs':'./node-server.mjs');return h.close;}
