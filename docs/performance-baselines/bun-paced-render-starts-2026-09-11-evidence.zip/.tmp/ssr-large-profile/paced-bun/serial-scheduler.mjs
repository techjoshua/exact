import {scheduler} from 'node:timers/promises';
/** Signal-free diagnostic: stagger starts within a host batch by microtask checkpoints. */
export function createSerialScheduler(hops=1){
 let pending;
 return signal=>{
  if(signal)throw Error('Signal-free diagnostic only');
  return new Promise(resolve=>{
   const first=!pending,batch=pending??=[];batch.push(resolve);if(batch.length===32)pending=undefined;
   if(first)scheduler.yield().then(()=>{
    if(pending===batch)pending=undefined;
    let index=0;
    function release(){const start=batch[index];batch[index++]=undefined;start();if(index<batch.length){let remaining=hops;function advance(){if(--remaining===0)release();else queueMicrotask(advance);}queueMicrotask(advance);}}
    release();
   });
  });
 };
}
