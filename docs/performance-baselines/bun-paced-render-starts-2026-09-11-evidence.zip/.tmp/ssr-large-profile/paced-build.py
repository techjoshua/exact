from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'paced-bun';root.mkdir(exist_ok=True)
(root/'serial-scheduler.mjs').write_bytes((base/'paced-scheduler.mjs').read_bytes())
(root/'worker.mjs').write_bytes((base/'serial-scheduler/worker.mjs').read_bytes())
r=(base/'serial-scheduler-run.mjs').read_text().replace('serial-scheduler/','paced-bun/').replace('large96-bun-serial-batch-turns','large96-bun-microtask-paced-batch')
r=r.replace("'serial-32',",'').replace('serial-8','serial-1').replace('report.blocks.length,14','report.blocks.length,12')
(base/'paced-bun-run.mjs').write_text(r)
