# Client V8 bytecode audit, September 11, 2026

Status: the initial client audit and candidate screening are complete. Production runtime source and
the public benchmark charts are unchanged. The isolated candidates reduce sampled allocation, but
the timing results do not establish a consistent application speedup.

## Scope and method

Source commit: `65693e6a39a5fced14ae5e041736c4ef6c3b0940`. Chromium 149.0.7827.55 reports V8 14.9.207.21.
Node 26.8.1 hosts the harness; these bytecode dumps come from Chromium, rather than the earlier Node
SSR investigation. Bun is outside this audit because it uses another JavaScript engine.

Separate hidden-source-map builds reproduce both shipped client JavaScript bundles byte-for-byte.
The eXact bundle is 199,356 bytes and React is 200,428 bytes. Canonical application outputs were not
replaced. The common replay server supplies each framework's own complete document and assets;
framework servers stop before client measurements. The controlled service remains available.

The workloads cover cold initial hydration, repeated severity filtering, and client-side incident
selection. A filter update alternates three rows with one critical row. A selection update switches
between the first two incident details using each application's real click handler. Filtering
preserves the retained critical row's DOM identity. These are the current three-incident fixture,
not a large-list result or a claim about every application.

Timing uses 20 warmup updates, then 400 filter or 100 selection updates, with ten fresh-context
populations per variant and balanced execution positions. It measures event dispatch to the expected DOM
mutation, including application work such as `history.pushState`. It does not measure paint or
network navigation. Individual timer granularity limits single-update interpretation; population
means are reported. The PC had variable foreground usage, including a user-owned docs server.
All populations remain visible. The earlier combined candidate has a slow filtering population;
the final confirmation has a slow first selection population. Neither is removed.

CPU and allocation profiling run separately, with five balanced populations, a requested 100-microsecond CPU
sample interval, and a 1,024-byte allocation sampling interval. Both collected-object flags are
enabled. The [DevTools sampling contract](https://chromedevtools.github.io/devtools-protocol/v8/HeapProfiler/#method-startSampling)
explains why the ordinary sampler, which excludes already-collected objects by default, cannot
measure all temporary churn. Sampled allocations are estimates, not retained heap or exact counts.
Native allocation sites are attributed to their nearest mapped application/framework stack frame.
Cold-start CPU samples are sparse and do not justify ranking individual initialization functions
by tiny differences.

## Current client gap

The initial uninstrumented screen measured filtering at 145.08 microseconds for eXact versus 46.38
for React; selection was 227.83 versus 225.17. The balanced confirmation below includes each isolated
candidate and a combined candidate. Allocation columns come from separate profiled populations.

| Framework / variant | Workload  | Mean us/update | Median population us/update | Mean sampled bytes/update |
| ------------------- | --------- | -------------: | --------------------------: | ------------------------: |
| eXact baseline      | filter    |         137.05 |                      137.00 |                    40,030 |
| eXact baseline      | selection |         227.70 |                      225.50 |                    46,713 |
| eXact direct-source | filter    |         135.13 |                      134.88 |                    37,882 |
| eXact direct-source | selection |         227.00 |                      227.50 |                    42,307 |
| eXact lazy-equality | filter    |         135.95 |                      135.75 |                    39,681 |
| eXact lazy-equality | selection |         224.90 |                      224.00 |                    44,089 |
| eXact combined      | filter    |         134.18 |                      134.25 |                    37,921 |
| eXact combined      | selection |         250.50 |                      224.50 |                    40,331 |
| React baseline      | filter    |          44.13 |                       44.00 |                     6,920 |
| React baseline      | selection |         226.60 |                      226.50 |                    22,465 |

The dominant measured gap is list filtering: approximately three times React's update time and
nearly six times its sampled allocation. Selection is much closer in time despite approximately
twice React's sampled allocation in the baseline. Browser-native history work contributes to
selection time; it must not be attributed entirely to reactive execution.

## Bytecode and optimization findings

The audit captures `--print-bytecode`, `--trace-opt`, `--trace-deopt`, and
`--trace-turbo-inlining` output from the actual production browser bundles. The
[V8 flag definitions](https://github.com/v8/v8/blob/main/src/flags/flag-definitions.h) describe these
diagnostic controls. Timings with these flags are not acceptance measurements.

| eXact function               | Ignition bytecode bytes | Relevant work                         |
| ---------------------------- | ----------------------: | ------------------------------------- |
| `adoptStaticChildrenRange`   |                   2,040 | Initial hydration boundaries          |
| `flushSync`                  |                   1,718 | Reactive scheduling and stabilization |
| `isJsonSafe`                 |                   1,280 | Initial hydration validation          |
| `patchMixedNativeChildren`   |                   1,143 | DOM child reconciliation              |
| `structurallyEqual`          |                   1,114 | Reactive change detection             |
| `adoptProgramChildSlots`     |                     974 | Compiled child adoption               |
| `stopEffectScope`            |                     950 | Scope teardown and cleanup            |
| `claimCompiledProgramWiring` |                     766 | Compiler-provided claim instructions  |
| `unmountMounted`             |                     734 | Mounted-tree teardown                 |
| `runTracked`                 |                     290 | Dependency collection                 |
| `trackProxySources`          |                     157 | Parent-path dependency reads          |

React's corresponding inventory includes `completeWork` at 4,208 bytes, `beginWork` at 2,983,
in different parts of its renderer. These are different architectures and functions,
not equivalent-work bytecode ratios. React's larger functions make it clear that reducing bytecode
length alone is not a sufficient optimization criterion. The mapped named-function inventory
excludes anonymous functions, ambiguous local names, and methods that cannot be safely identified by name.

Three repeated filter/selection cycles produce 36 eXact bailout entries and 43 React entries in the
first cycle, including harness and warmup work. Neither trace has bailout entries during the
second or third cycle. This fixture does not demonstrate persistent deoptimization churn. The
traces contain inlining refusals for missing feedback vectors, but they do not establish that
splitting every large helper would improve the application.

## Allocation candidates

### Direct proxy source

Every registration currently replaces a one-element `Set` in `proxySources`, while writing the
same source to `proxyRefs`. Every property read then iterates that set. Inspection of all writers
and readers confirms that the set never accumulates additional aliases: aliases have distinct
path-specific proxies. The candidate reads the existing `proxyRefs` entry directly, preserving
the same parent dependency and moved-item identity.

The browser helper shrinks from 157 to 36 bytecode bytes. The initial hypothesis was 15–25% less
filtering allocation and potentially 5–15% less time. The result falls short: confirmation shows
about 5% less filtering allocation and 9% less selection allocation. Native Set/iterator samples
also belong to other tracking and teardown paths, so removing this one source cannot remove all
of that churn. Timing differences change direction across populations and workloads.

### Lazy equality storage

The baseline equality bytecode constructs two WeakMaps and two array literals before even checking
raw identity. The candidate returns immediately for identical values and creates the cycle maps
only when object traversal needs them. It preserves unwrapping, descriptor comparison, cycle and
alias topology, sparse-array handling, opaque-operation identity, and the traversal limit.

This is a limited allocation hypothesis, not a proposal to remove structural equality. Confirmation
shows about 6% less selection allocation, with little filtering benefit. Combined with direct
proxy-source access, selection allocation falls from roughly 46.7 KB to 40.3 KB per update, about
14%. The combined selection mean is worse because of a retained 476-microsecond first-population
outlier. The earlier screen also had a 228.7-microsecond combined filtering population. Neither
those outliers nor later faster populations justify claiming a consistent timing effect.

All four browser variants agree on 576 equality pairs and their unwrap-call counts, plus checks
for retained aliases, moved-item identity and references, descriptors, cycles, sparse arrays, and
accessor non-execution. These are focused candidate checks, not a full runtime regression suite.
The evidence contains proposed source patches for review; neither candidate is integrated.

## Larger next targets

Diagnostic counters, separate from timing, show these average operations per update:

| Operation                  | Filtering | Selection |
| -------------------------- | --------: | --------: |
| Scope construction         |         5 |         0 |
| Scope-stop invocation      |         5 |         0 |
| Tracked reaction execution |         7 |        10 |
| Mounted-tree unmount entry |         1 |         0 |
| Render-program mount       |         2 |         0 |

Filtering alternately removes and restores two rows, so the averages span both removal and
insertion. The retained row remains the same DOM node. These counts establish the executed work;
they do not prove that any lifecycle operation can safely be omitted.

1. **Dependency collection and membership storage.** `runTracked` creates a pass record, a `Set`,
   and a replacement dependency array on every execution. Membership changes allocate subscriber
   storage too. A focused follow-up should distinguish first collection, stable dependencies, and
   changing branches before selecting a smaller representation. Nested tracking, synchronous
   invalidation, observation transitions, and disposal during execution must remain correct.
2. **Mounted-tree and scope teardown storage.** `unmountMounted` creates entry/exit records and
   cleanup closures; scope shutdown snapshots reaction and cleanup collections. A flat traversal
   stack and fewer temporary records deserve measurement. Snapshot and error-continuation behavior
   cannot simply be removed because cleanup callbacks can mutate owned collections.
3. **Compiled template claiming.** Fresh row programs clone templates and execute the compiled
   claim sequence before binding expressions. Its cost is visible, but smaller self-sample counts
   do not yet justify a compiler/ABI redesign. Count claim operations on a larger list before
   experimenting with specialized claim code.
4. **Cold hydration passes.** Initial validation, form-state capture, DOM walking, and slot adoption
   appear in the startup profile. They need a cold-start-specific experiment with more startup
   samples. The warm filtering results do not justify removing hydration integrity or form-state
   preservation guarantees.

The priority is less temporary storage around the existing durable component and precise-update
model. This audit does not justify adopting a React-style rerendering model, pooling live ownership
records indiscriminately, or creating another rendering engine.

## Evidence

[Structured findings](client-v8-2026-09-11.json) include all confirmation population means, allocation
samples, source identities, lifecycle counts, bytecode inventory, and deoptimization entries.
The evidence archive contains raw profiles, bytecode, optimization traces, isolated source maps,
candidate checks, proposed source patches, and runners. Original timing populations are retained.
This focused audit supplements the [full benchmark baseline](admission-full-2026-09-11.md); it does
not replace its client or SSR charts.
