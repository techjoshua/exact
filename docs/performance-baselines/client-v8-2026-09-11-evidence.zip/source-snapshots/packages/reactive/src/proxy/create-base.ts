import { hasActiveTransaction, recordTransactionUndo, track, trigger } from '../internal/deps.js';

import { markReactiveHashDirty } from '../internal/keyed-collections.js';

import { iterateKey, proxyMarker, rawTarget } from '../internal/symbols.js';

import { isArrayStructureKey } from '../internal/objects.js';
import { isReactive, isReactiveValue, unwrap } from '../internal/values.js';

import type { ReactiveOptions, ReactiveRef } from '../internal/types.js';

import { createPropertyUndo, mutateArray, recordPropertyUndo } from '../array-mutation.js';
import { hasChanged, isReactiveContainer } from '../change-detection.js';

import {
	defaultReactiveOptions,
	mutatingArrayMethods,
	parentSourceCache,
	proxyRefs,
	proxySources,
	reactiveRawObjects,
	readonlyReactiveOptionsKey,
	rootProxyCache,
	sourcedProxyCache,
	type CachedParentSource
} from './state.js';

/** Collection-member implementation injected only by the general reactive entry. */
export type ReactiveCollectionMember = (
	target: Map<unknown, unknown> | Set<unknown>,
	key: PropertyKey,
	receiver: object,
	options: ReactiveOptions,
	wrap: (value: unknown, dependency?: PropertyKey) => unknown
) => unknown;

type ReactiveProxyRecord = {
	readonly options: ReactiveOptions;
	readonly collectionMember?: ReactiveCollectionMember;
	forwardingSet: boolean;
	proxy?: object;
};

type ReactiveProxyHandler = ProxyHandler<object> & {
	record: ReactiveProxyRecord;
};

/**
 * Retains alias-specific proxy ownership while sharing the trap code across every nested proxy.
 * A per-proxy record is required because one raw value may have several simultaneous parent paths.
 */
const reactiveProxyHandler: ProxyHandler<object> = {
	get(this: ReactiveProxyHandler, target: object, key: PropertyKey, receiver: object): unknown {
		if (key === proxyMarker) return true;
		if (key === rawTarget) return target;

		const { collectionMember, options, proxy } = this.record;
		trackProxySources(proxy!);
		if (target instanceof Map || target instanceof Set) {
			if (!collectionMember)
				throw new TypeError('Compiled object/array state received a Map or Set value');
			return collectionMember(target, key, proxy!, options, (current, dependency) => {
				if (!current || typeof current !== 'object' || !isReactiveContainer(unwrap(current)))
					return current;
				return sourcedReactive(
					unwrap(current) as object,
					options,
					dependency === undefined
						? undefined
						: createParentSource(target, dependency, options, collectionMember),
					collectionMember
				);
			});
		}
		const current = Reflect.get(target, key, receiver);
		if (current && typeof current === 'object' && requiresExactProxyValue(target, key))
			return current;
		if (Array.isArray(target) && mutatingArrayMethods.has(key) && typeof current === 'function') {
			return (...args: unknown[]) =>
				mutateArray(target, String(key), current, args, receiver, options);
		}
		if (options.passthroughKeys?.includes(key)) {
			track(target, key);
			return current;
		}

		if (isReactiveValue(current)) {
			track(target, key);
			const currentValue = current.get();
			const currentTarget = unwrap(currentValue);
			return isReactiveContainer(currentTarget)
				? sourcedReactive(
						currentTarget,
						options,
						createParentSource(target, key, options, collectionMember),
						collectionMember
					)
				: currentTarget;
		}

		if (current && typeof current === 'object' && isReactiveContainer(unwrap(current))) {
			const currentTarget = unwrap(current) as object;
			if (currentTarget === target) {
				track(target, key);
				return receiver;
			}
			const source = createParentSource(target, key, options, collectionMember);
			return sourcedReactive(currentTarget, options, source, collectionMember);
		}

		track(target, key);
		return current;
	},

	set(
		this: ReactiveProxyHandler,
		target: object,
		key: PropertyKey,
		next: unknown,
		receiver: object
	): boolean {
		const { options } = this.record;
		if (options.readonly) {
			options.onReadonlyWrite?.(key);
			return false;
		}

		const previousLength = Array.isArray(target) ? target.length : undefined;
		const removedIndexes =
			Array.isArray(target) && key === 'length' && typeof next === 'number' && next < target.length
				? Array.from({ length: target.length - next }, (_, offset) => next + offset).filter(
						(index) => Reflect.has(target, index)
					)
				: [];
		const previous = Reflect.get(target, key, receiver);
		const unwrapped = unwrap(next);
		const hadKey = Object.prototype.hasOwnProperty.call(target, key);
		const changed = hasChanged(previous, unwrapped);
		const ownDescriptor = Reflect.getOwnPropertyDescriptor(target, key);
		if (!changed && ownDescriptor && 'value' in ownDescriptor) return true;
		const undo = hasActiveTransaction() ? createPropertyUndo(target, key) : undefined;
		this.record.forwardingSet = true;
		let ok: boolean;
		try {
			ok = Reflect.set(target, key, unwrapped, receiver);
		} finally {
			this.record.forwardingSet = false;
		}
		if (ok && undo && (!hadKey || !Object.is(previous, Reflect.get(target, key, receiver))))
			recordTransactionUndo(undo, target, key);
		if (ok && changed) {
			markReactiveHashDirty(target);
			trigger(target, key);
			for (const index of removedIndexes) trigger(target, String(index));
			if (
				previousLength !== undefined &&
				Array.isArray(target) &&
				target.length !== previousLength &&
				key !== 'length'
			)
				trigger(target, 'length');
			if (!hadKey || isArrayStructureKey(target, key)) trigger(target, iterateKey);
			notifyMutation(options, key, 'set');
		}
		return ok;
	},

	defineProperty(
		this: ReactiveProxyHandler,
		target: object,
		key: PropertyKey,
		descriptor: PropertyDescriptor
	): boolean {
		const { options } = this.record;
		if (this.record.forwardingSet) return Reflect.defineProperty(target, key, descriptor);
		if (options.readonly) {
			options.onReadonlyWrite?.(key);
			return false;
		}
		const previous = Reflect.getOwnPropertyDescriptor(target, key);
		if (samePropertyDescriptor(previous, descriptor)) return true;
		const undo = hasActiveTransaction() ? createPropertyUndo(target, key) : undefined;
		const oldLength = Array.isArray(target) ? target.length : undefined;
		const ok = Reflect.defineProperty(target, key, normalizeDescriptor(descriptor));
		if (!ok) return false;
		if (undo) recordTransactionUndo(undo, target, key);
		markReactiveHashDirty(target);
		trigger(target, key);
		if (!previous || isArrayStructureKey(target, key)) trigger(target, iterateKey);
		if (oldLength !== undefined && (target as unknown[]).length !== oldLength && key !== 'length')
			trigger(target, 'length');
		notifyMutation(options, key, 'define');
		return true;
	},

	deleteProperty(this: ReactiveProxyHandler, target: object, key: PropertyKey): boolean {
		const { options } = this.record;
		if (options.readonly) {
			options.onReadonlyWrite?.(key);
			return false;
		}

		const hadKey = Object.prototype.hasOwnProperty.call(target, key);
		const descriptor =
			hadKey && hasActiveTransaction() ? Reflect.getOwnPropertyDescriptor(target, key) : undefined;
		const ok = Reflect.deleteProperty(target, key);
		if (ok && hadKey) {
			if (descriptor)
				recordTransactionUndo(
					() => {
						Reflect.defineProperty(target, key, descriptor);
					},
					target,
					key
				);
			markReactiveHashDirty(target);
			trigger(target, key);
			trigger(target, iterateKey);
			notifyMutation(options, key, 'delete');
		}
		return ok;
	},

	ownKeys(this: ReactiveProxyHandler, target: object): ArrayLike<string | symbol> {
		trackProxySources(this.record.proxy!);
		track(target, iterateKey);
		return Reflect.ownKeys(target);
	},

	has(this: ReactiveProxyHandler, target: object, key: PropertyKey): boolean {
		track(target, key);
		return Reflect.has(target, key);
	}
};

/** Creates a reactive with an explicitly selected collection capability. */
export function createReactiveBase(
	value: object,
	options: ReactiveOptions,
	parentSource?: ReactiveRef,
	collectionMember?: ReactiveCollectionMember
): object {
	const reactiveTarget = isReactive(value) ? (value as { [rawTarget]: object })[rawTarget] : value;
	const cached = getCachedProxy(reactiveTarget, options, parentSource);
	if (cached) {
		if (parentSource) registerProxySource(cached, parentSource);
		return cached;
	}

	const record: ReactiveProxyRecord = { options, collectionMember, forwardingSet: false };
	const handler = Object.create(reactiveProxyHandler) as ReactiveProxyHandler;
	handler.record = record;
	const proxy = new Proxy(reactiveTarget, handler);
	record.proxy = proxy;

	cacheProxy(reactiveTarget, options, parentSource, proxy);
	if (parentSource) {
		reactiveRawObjects.add(reactiveTarget);
		registerProxySource(proxy, parentSource);
	}
	return proxy;
}

/** Preserves ECMAScript invariants for frozen object-valued data properties. */
function requiresExactProxyValue(target: object, key: PropertyKey): boolean {
	const descriptor = Reflect.getOwnPropertyDescriptor(target, key);
	return !!descriptor && 'value' in descriptor && !descriptor.configurable && !descriptor.writable;
}

function createParentSource(
	target: object,
	key: PropertyKey,
	options: ReactiveOptions,
	collectionMember?: ReactiveCollectionMember
): CachedParentSource {
	const optionKey = reactiveOptionsKey(options);
	let byKey = parentSourceCache.get(target);
	if (!byKey) parentSourceCache.set(target, (byKey = new Map()));
	let byOptions = byKey.get(key);
	if (!byOptions) byKey.set(key, (byOptions = new WeakMap()));
	const cached = byOptions.get(optionKey);
	if (cached) return cached;
	const source: CachedParentSource = {
		target,
		key,
		get() {
			track(target, key);
			const next = Reflect.get(target, key);
			if (isReactiveValue(next)) {
				const nextValue = next.get();
				return nextValue && typeof nextValue === 'object'
					? sourcedReactive(unwrap(nextValue) as object, options, source, collectionMember)
					: nextValue;
			}
			return next && typeof next === 'object'
				? sourcedReactive(unwrap(next) as object, options, source, collectionMember)
				: next;
		},
		set(value: unknown) {
			const previous = Reflect.get(target, key);
			const unwrapped = unwrap(value);
			if (!hasChanged(previous, unwrapped)) return;
			recordPropertyUndo(target, key);
			Reflect.set(target, key, unwrapped);
			markReactiveHashDirty(target);
			trigger(target, key);
			if (isArrayStructureKey(target, key)) trigger(target, iterateKey);
		}
	};
	byOptions.set(optionKey, source);
	return source;
}

/** Reuses the child proxy most recently resolved through one stable parent path. */
function sourcedReactive(
	raw: object,
	options: ReactiveOptions,
	source?: CachedParentSource,
	collectionMember?: ReactiveCollectionMember
): object {
	if (!source) return createReactiveBase(raw, options, undefined, collectionMember);
	if (source.cachedRaw === raw && source.cachedProxy) {
		registerProxySource(source.cachedProxy, source);
		return source.cachedProxy;
	}
	const proxy = createReactiveBase(raw, options, source, collectionMember);
	source.cachedRaw = raw;
	source.cachedProxy = proxy;
	return proxy;
}

function getCachedProxy(
	raw: object,
	options: ReactiveOptions,
	source?: ReactiveRef
): object | undefined {
	const optionKey = reactiveOptionsKey(options);
	if (!source) return rootProxyCache.get(raw)?.get(optionKey);
	const bySource = sourcedProxyCache.get(raw)?.get(optionKey);
	const exact = bySource?.get(source);
	if (exact) return exact;
	// Preserve item identity across keyed moves. A proxy may change paths only
	// after its old path no longer contains this raw value; simultaneous aliases
	// retain distinct path-specific proxies and therefore precise dependencies.
	if (bySource) {
		for (const [oldSource, proxy] of bySource) {
			if (unwrap(Reflect.get(oldSource.target, oldSource.key)) === raw) continue;
			bySource.delete(oldSource);
			bySource.set(source, proxy);
			proxySources.set(proxy, new Set([source]));
			proxyRefs.set(proxy, source);
			return proxy;
		}
	}
	return undefined;
}

function cacheProxy(
	raw: object,
	options: ReactiveOptions,
	source: ReactiveRef | undefined,
	proxy: object
): void {
	const optionKey = reactiveOptionsKey(options);
	if (source) {
		let byOptions = sourcedProxyCache.get(raw);
		if (!byOptions) sourcedProxyCache.set(raw, (byOptions = new WeakMap()));
		let bySource = byOptions.get(optionKey);
		if (!bySource) byOptions.set(optionKey, (bySource = new Map()));
		bySource.set(source, proxy);
		return;
	}
	let byOptions = rootProxyCache.get(raw);
	if (!byOptions) rootProxyCache.set(raw, (byOptions = new WeakMap()));
	byOptions.set(optionKey, proxy);
}

function registerProxySource(proxy: object, source: ReactiveRef): void {
	proxySources.set(proxy, new Set([source]));
	// ref(value) is primarily used immediately after obtaining value from its
	// parent. Keep that exact path while property reads subscribe to every known
	// alias, preventing retained aliases from silently losing updates.
	proxyRefs.set(proxy, source);
}

function trackProxySources(proxy: object): void {
	for (const source of proxySources.get(proxy) ?? []) track(source.target, source.key);
}

function normalizeDescriptor(descriptor: PropertyDescriptor): PropertyDescriptor {
	return 'value' in descriptor ? { ...descriptor, value: unwrap(descriptor.value) } : descriptor;
}

function samePropertyDescriptor(
	left: PropertyDescriptor | undefined,
	right: PropertyDescriptor
): boolean {
	if (!left) return false;
	if ('value' in left !== 'value' in right) return false;
	if (left.configurable !== right.configurable || left.enumerable !== right.enumerable)
		return false;
	if ('value' in left && 'value' in right) {
		return left.writable === right.writable && !hasChanged(left.value, right.value);
	}
	return left.get === right.get && left.set === right.set;
}

function reactiveOptionsKey(options: ReactiveOptions): object {
	if ('__exactCollectionCacheMode' in options) return options as object;
	if (
		!options.readonly &&
		!options.onReadonlyWrite &&
		!options.onMutation &&
		!options.passthroughKeys?.length
	)
		return defaultReactiveOptions;
	if (
		options.readonly &&
		!options.onReadonlyWrite &&
		!options.onMutation &&
		!options.passthroughKeys?.length
	)
		return readonlyReactiveOptionsKey;
	return options as object;
}

function notifyMutation(
	options: ReactiveOptions,
	key: PropertyKey | undefined,
	operation: string
): void {
	try {
		options.onMutation?.(key, operation);
	} catch {
		// Observation is deliberately outside application error propagation.
	}
}
