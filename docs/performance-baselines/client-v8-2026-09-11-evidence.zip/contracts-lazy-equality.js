(() => {
  var __defProp = Object.defineProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // packages/reactive/dist/index.js
  var dist_exports = {};
  __export(dist_exports, {
    batch: () => batch,
    captureReactiveMutations: () => captureReactiveMutations,
    collectionRef: () => collectionRef,
    computed: () => computed,
    createEffectScope: () => createEffectScope,
    createExternalSource: () => createExternalSource,
    createProfiledEffectScope: () => createProfiledEffectScope,
    createSelectedExternalSource: () => createSelectedExternalSource,
    currentWorkPriority: () => currentWorkPriority,
    decodeReactiveProtocolValue: () => decodeReactiveProtocolValue,
    deleteReactiveValue: () => deleteReactiveValue,
    effectScopeWorkPriority: () => effectScopeWorkPriority,
    encodeReactiveProtocolValue: () => encodeReactiveProtocolValue,
    flushSync: () => flushSync,
    indexedReactive: () => indexedReactive,
    inspectComputed: () => inspectComputed,
    inspectScheduledWork: () => inspectScheduledWork,
    isReactive: () => isReactive,
    isReactiveValue: () => isReactiveValue,
    isTransportableReactiveMapKey: () => isTransportableReactiveMapKey,
    mutateReactiveArray: () => mutateReactiveArray,
    mutateReactiveCollection: () => mutateReactiveCollection,
    peek: () => peek,
    publishBatch: () => publishBatch,
    reactive: () => reactive,
    readReactiveOwnProperty: () => readReactiveOwnProperty,
    ref: () => ref,
    registerReactiveListKey: () => registerReactiveListKey,
    rollbackReactiveMutationJournals: () => rollbackReactiveMutationJournals,
    runWithPriority: () => runWithPriority,
    scheduleWork: () => scheduleWork,
    setEffectScopeWorkPriority: () => setEffectScopeWorkPriority,
    setScheduledWorkContextCapture: () => setScheduledWorkContextCapture,
    snapshot: () => snapshot,
    subscribe: () => subscribe,
    transferEffectScope: () => transferEffectScope,
    unwrap: () => unwrap,
    updateReactive: () => updateReactive,
    updateReactiveValue: () => updateReactiveValue,
    updateReactiveValueWithResult: () => updateReactiveValueWithResult,
    watch: () => watch,
    whenEffectScopeResumed: () => whenEffectScopeResumed,
    withEffectScope: () => withEffectScope,
    writeReactive: () => writeReactive,
    writeReactiveLazy: () => writeReactiveLazy
  });

  // packages/reactive/dist/internal/dependency-graph.js
  var deps = /* @__PURE__ */ new WeakMap();
  var depObservationHooks = /* @__PURE__ */ new WeakMap();
  var reactionStack = [];
  var trackingPasses = [];
  var trackingPauseFloors = [];
  var pendingObservationTransitions = [];
  var publishingObservationTransitions = false;
  function track(target, key) {
    const pauseFloor = trackingPauseFloors[trackingPauseFloors.length - 1];
    if (pauseFloor !== void 0 && reactionStack.length <= pauseFloor)
      return false;
    const reaction = reactionStack[reactionStack.length - 1];
    if (!reaction)
      return false;
    linkReaction(reaction, target, key);
    return true;
  }
  function registerDependencyObservationHooks(target, key, hooks) {
    let targetHooks = depObservationHooks.get(target);
    if (!targetHooks)
      depObservationHooks.set(target, targetHooks = /* @__PURE__ */ new Map());
    targetHooks.set(key, hooks);
    return () => {
      const current = depObservationHooks.get(target);
      if (current?.get(key) !== hooks)
        return;
      current.delete(key);
      if (!current.size)
        depObservationHooks.delete(target);
    };
  }
  function linkReaction(reaction, target, key) {
    linkReactionToDependency(reaction, getDep(target, key));
  }
  function linkReactionToDependency(reaction, dep) {
    const subscribers = dep.subscribers;
    const pass = trackingPasses[trackingPasses.length - 1];
    const collecting = pass?.reaction === reaction;
    if (subscribers === reaction || subscribers instanceof Set && subscribers.has(reaction)) {
      if (collecting && !pass.seen.has(dep)) {
        pass.seen.add(dep);
        reaction.deps.push(dep);
      }
      return;
    }
    if (collecting)
      pass.seen.add(dep);
    const wasEmpty = subscribers === void 0;
    dep.subscribers = subscribers === void 0 ? reaction : subscribers instanceof Set ? subscribers.add(reaction) : /* @__PURE__ */ new Set([subscribers, reaction]);
    reaction.deps.push(dep);
    if (wasEmpty)
      publishObservationTransition(depObservationHooks.get(dep.target)?.get(dep.key)?.onObserved);
  }
  function reactionDependencies(reaction) {
    return reaction.deps;
  }
  function getDep(target, key) {
    let targetDeps = deps.get(target);
    if (!targetDeps)
      deps.set(target, targetDeps = /* @__PURE__ */ new Map());
    let dep = targetDeps.get(key);
    if (!dep) {
      dep = { target, key };
      targetDeps.set(key, dep);
    }
    return dep;
  }
  function cleanupReaction(reaction) {
    for (const pass of trackingPasses)
      if (pass.reaction === reaction) {
        for (const dep of pass.previous)
          detachDependency(reaction, dep);
        pass.previous = [];
      }
    for (const dep of reaction.deps)
      detachDependency(reaction, dep);
    reaction.deps.length = 0;
  }
  function detachDependency(reaction, dep) {
    const subscribers = dep.subscribers;
    if (subscribers === reaction)
      dep.subscribers = void 0;
    else if (subscribers instanceof Set && subscribers.delete(reaction)) {
      if (subscribers.size === 1)
        dep.subscribers = subscribers.values().next().value;
      else if (subscribers.size === 0)
        dep.subscribers = void 0;
    } else
      return;
    if (dep.subscribers === void 0)
      releaseEmptyDependency(dep);
  }
  function scheduleDependencyReactions(target, key) {
    const dep = deps.get(target)?.get(key);
    const subscribers = dep?.subscribers;
    if (subscribers instanceof Set) {
      for (const reaction of [...subscribers])
        if (observesDuringTracking(reaction, dep))
          reaction.schedule();
    } else if (subscribers && observesDuringTracking(subscribers, dep))
      subscribers.schedule();
  }
  function scheduleTriggeredReactions(triggers) {
    if (!triggers.size)
      return;
    const reactions = /* @__PURE__ */ new Set();
    for (const [target, keys] of triggers) {
      const targetDeps = deps.get(target);
      if (!targetDeps)
        continue;
      for (const key of keys) {
        const dep = targetDeps.get(key);
        const subscribers = dep?.subscribers;
        if (subscribers instanceof Set) {
          for (const reaction of subscribers)
            if (observesDuringTracking(reaction, dep))
              reactions.add(reaction);
        } else if (subscribers && observesDuringTracking(subscribers, dep))
          reactions.add(subscribers);
      }
    }
    for (const reaction of reactions)
      reaction.schedule();
  }
  function observesDuringTracking(reaction, dep) {
    for (let i = trackingPasses.length - 1; i >= 0; i--) {
      const pass = trackingPasses[i];
      if (pass.reaction === reaction)
        return pass.seen.has(dep);
    }
    return true;
  }
  function runTracked(reaction, fn) {
    const pass = { reaction, previous: reaction.deps, seen: /* @__PURE__ */ new Set() };
    reaction.deps = [];
    trackingPasses.push(pass);
    reactionStack.push(reaction);
    try {
      fn();
    } finally {
      reactionStack.pop();
      trackingPasses.pop();
      for (const dep of pass.previous)
        if (!pass.seen.has(dep))
          detachDependency(reaction, dep);
      if (!reaction.active)
        cleanupReaction(reaction);
    }
  }
  function peek(fn) {
    trackingPauseFloors.push(reactionStack.length);
    try {
      return fn();
    } finally {
      trackingPauseFloors.pop();
    }
  }
  function releaseEmptyDependency(dep) {
    publishObservationTransition(depObservationHooks.get(dep.target)?.get(dep.key)?.onUnobserved);
    const targetDeps = deps.get(dep.target);
    if (targetDeps?.get(dep.key) === dep)
      targetDeps.delete(dep.key);
    if (targetDeps && !targetDeps.size)
      deps.delete(dep.target);
  }
  function publishObservationTransition(transition) {
    if (!transition)
      return;
    pendingObservationTransitions.push(transition);
    if (publishingObservationTransitions)
      return;
    publishingObservationTransitions = true;
    try {
      while (pendingObservationTransitions.length)
        pendingObservationTransitions.pop()();
    } finally {
      publishingObservationTransitions = false;
    }
  }

  // packages/reactive/dist/internal/deps.js
  var transactions = [];
  var mutationVersions = /* @__PURE__ */ new WeakMap();
  var journalTransactions = /* @__PURE__ */ new WeakMap();
  var restorationVersion = 0;
  function trigger(target, key) {
    const previousVersion = readMutationVersion(target, key);
    const nextVersion = incrementMutationVersion(target, key);
    const transaction = transactions[transactions.length - 1];
    if (transaction) {
      let keys = transaction.triggers.get(target);
      if (!keys) {
        keys = /* @__PURE__ */ new Set();
        transaction.triggers.set(target, keys);
      }
      keys.add(key);
      if (transaction.versionRanges)
        recordMutationVersionRange(transaction.versionRanges, target, key, previousVersion, nextVersion);
      return;
    }
    triggerNow(target, key);
  }
  function batch(fn) {
    const parent = transactions[transactions.length - 1];
    const transaction = createTransaction(true, Boolean(parent?.versionRanges));
    transactions.push(transaction);
    let result;
    try {
      result = fn();
    } catch (error) {
      transactions.pop();
      rollbackTransaction(transaction);
      throw error;
    }
    transactions.pop();
    publishTransaction(parent, transaction);
    return result;
  }
  function publishBatch(fn) {
    const parent = transactions[transactions.length - 1];
    const transaction = createTransaction(Boolean(parent?.undos), Boolean(parent?.versionRanges));
    transactions.push(transaction);
    let result;
    try {
      result = fn();
    } catch (error) {
      transactions.pop();
      publishTransaction(parent, transaction);
      throw error;
    }
    transactions.pop();
    publishTransaction(parent, transaction);
    return result;
  }
  function captureReactiveMutations(fn) {
    const transaction = createTransaction(true, true);
    transactions.push(transaction);
    try {
      fn();
    } catch (error) {
      transactions.pop();
      rollbackTransaction(transaction);
      throw error;
    }
    transactions.pop();
    const parent = transactions[transactions.length - 1];
    if (parent)
      mergeTriggers(parent.triggers, transaction.triggers);
    else
      flushTriggers(transaction.triggers);
    const protectedVersions = transactionMutationVersions(transaction.versionRanges);
    let active = true;
    const journal = {
      rollback() {
        if (!active)
          return;
        active = false;
        rollbackTransaction(transaction, protectedVersions);
        const parent2 = transactions[transactions.length - 1];
        if (parent2)
          mergeTriggers(parent2.triggers, transaction.triggers);
        else
          flushTriggers(transaction.triggers);
        transaction.undos.length = 0;
        transaction.triggers.clear();
      },
      discard() {
        if (!active)
          return;
        active = false;
        transaction.undos.length = 0;
        transaction.triggers.clear();
      }
    };
    journalTransactions.set(journal, transaction);
    return journal;
  }
  function rollbackReactiveMutationJournals(journals) {
    const covered = /* @__PURE__ */ new Map();
    const blocked = /* @__PURE__ */ new Map();
    const rollbackTriggers = /* @__PURE__ */ new Map();
    const restored = /* @__PURE__ */ new Map();
    for (let journalIndex = journals.length - 1; journalIndex >= 0; journalIndex--) {
      const journal = journals[journalIndex];
      const transaction = journalTransactions.get(journal);
      if (!transaction) {
        journal.rollback();
        continue;
      }
      rollbackOwnedTransaction(transaction, covered, blocked, restored);
      addCoveredVersionRanges(covered, transaction.versionRanges);
      mergeTriggers(rollbackTriggers, transaction.triggers);
      journal.discard();
    }
    advanceRestoredDependencyVersions(restored);
    const parent = transactions[transactions.length - 1];
    if (parent)
      mergeTriggers(parent.triggers, rollbackTriggers);
    else
      flushTriggers(rollbackTriggers);
  }
  function recordTransactionUndo(undo, target, key) {
    transactions[transactions.length - 1]?.undos?.push({ apply: undo, target, key });
  }
  function hasActiveTransaction() {
    return Boolean(transactions[transactions.length - 1]?.undos);
  }
  function hasActiveReactiveTransaction() {
    return transactions.length > 0;
  }
  function mergeTransaction(parent, child) {
    if (parent.undos && child.undos)
      parent.undos.push(...child.undos);
    mergeTriggers(parent.triggers, child.triggers);
    if (parent.versionRanges && child.versionRanges)
      mergeVersionRanges(parent.versionRanges, child.versionRanges);
  }
  function publishTransaction(parent, transaction) {
    if (parent)
      mergeTransaction(parent, transaction);
    else
      flushTriggers(transaction.triggers);
  }
  function mergeTriggers(parent, child) {
    for (const [target, keys] of child) {
      let pending = parent.get(target);
      if (!pending) {
        pending = /* @__PURE__ */ new Set();
        parent.set(target, pending);
      }
      for (const key of keys)
        pending.add(key);
    }
  }
  function rollbackTransaction(transaction, protectedVersions) {
    const undos = transaction.undos;
    if (!undos)
      return;
    const restored = /* @__PURE__ */ new Map();
    for (let index = undos.length - 1; index >= 0; index--) {
      const undo = undos[index];
      if (protectedVersions && undo.target && undo.key !== void 0 && readMutationVersion(undo.target, undo.key) !== protectedVersions.get(undo.target)?.get(undo.key))
        continue;
      undo.apply();
      if (undo.target && undo.key !== void 0)
        recordRestoredDependency(restored, undo.target, undo.key);
    }
    advanceRestoredDependencyVersions(restored);
  }
  function transactionMutationVersions(versionRanges) {
    const result = /* @__PURE__ */ new Map();
    for (const [target, ranges] of versionRanges) {
      const versions = /* @__PURE__ */ new Map();
      for (const [key, range] of ranges)
        versions.set(key, range.end);
      result.set(target, versions);
    }
    return result;
  }
  function incrementMutationVersion(target, key) {
    let versions = mutationVersions.get(target);
    if (!versions)
      mutationVersions.set(target, versions = /* @__PURE__ */ new Map());
    const next = (versions.get(key) ?? 0) + 1;
    versions.set(key, next);
    return next;
  }
  function readMutationVersion(target, key) {
    return mutationVersions.get(target)?.get(key) ?? 0;
  }
  function readReactiveRestorationVersion() {
    return restorationVersion;
  }
  function createTransaction(rollback, retainVersions = false) {
    return {
      ...rollback ? { undos: [] } : {},
      triggers: /* @__PURE__ */ new Map(),
      ...retainVersions ? { versionRanges: /* @__PURE__ */ new Map() } : {}
    };
  }
  function recordMutationVersionRange(versionRanges, target, key, start, end) {
    let ranges = versionRanges.get(target);
    if (!ranges)
      versionRanges.set(target, ranges = /* @__PURE__ */ new Map());
    const range = ranges.get(key);
    if (range)
      range.end = end;
    else
      ranges.set(key, { start, end });
  }
  function mergeVersionRanges(parent, child) {
    for (const [target, childRanges] of child) {
      let ranges = parent.get(target);
      if (!ranges)
        parent.set(target, ranges = /* @__PURE__ */ new Map());
      for (const [key, childRange] of childRanges) {
        const range = ranges.get(key);
        if (range)
          range.end = childRange.end;
        else
          ranges.set(key, { ...childRange });
      }
    }
  }
  function rollbackOwnedTransaction(transaction, covered, blocked, restored) {
    const undos = transaction.undos;
    if (!undos || !transaction.versionRanges)
      return;
    for (let index = undos.length - 1; index >= 0; index--) {
      const undo = undos[index];
      if (undo.target && undo.key !== void 0) {
        if (blocked.get(undo.target)?.has(undo.key))
          continue;
        const range = transaction.versionRanges.get(undo.target)?.get(undo.key);
        if (range && !versionsCovered(range.end + 1, readMutationVersion(undo.target, undo.key), covered.get(undo.target)?.get(undo.key) ?? [])) {
          let keys = blocked.get(undo.target);
          if (!keys)
            blocked.set(undo.target, keys = /* @__PURE__ */ new Set());
          keys.add(undo.key);
          continue;
        }
      }
      undo.apply();
      if (undo.target && undo.key !== void 0)
        recordRestoredDependency(restored, undo.target, undo.key);
    }
  }
  function recordRestoredDependency(restored, target, key) {
    let keys = restored.get(target);
    if (!keys)
      restored.set(target, keys = /* @__PURE__ */ new Set());
    keys.add(key);
  }
  function advanceRestoredDependencyVersions(restored) {
    if (!restored.size)
      return;
    for (const [target, keys] of restored)
      for (const key of keys)
        incrementMutationVersion(target, key);
    restorationVersion++;
  }
  function versionsCovered(start, end, ranges) {
    if (start > end)
      return true;
    let next = start;
    for (const range of [...ranges].sort((left, right) => left.start - right.start)) {
      const ownedStart = range.start + 1;
      if (ownedStart > next)
        return false;
      if (range.end >= next)
        next = range.end + 1;
      if (next > end)
        return true;
    }
    return false;
  }
  function addCoveredVersionRanges(covered, additions) {
    for (const [target, addedRanges] of additions) {
      let ranges = covered.get(target);
      if (!ranges)
        covered.set(target, ranges = /* @__PURE__ */ new Map());
      for (const [key, range] of addedRanges) {
        const values = ranges.get(key) ?? [];
        values.push(range);
        ranges.set(key, values);
      }
    }
  }
  function flushTriggers(triggers) {
    scheduleTriggeredReactions(triggers);
  }
  function triggerNow(target, key) {
    scheduleDependencyReactions(target, key);
  }

  // packages/instrumentation/dist/index.js
  function publishExactProfile(sink, event) {
    if (!sink)
      return;
    try {
      sink(event);
    } catch {
    }
  }
  function profileTimestamp() {
    const runtime = globalThis;
    return runtime.performance?.now() ?? Date.now();
  }

  // packages/reactive/dist/internal/scheduler.js
  var queuedReactions = /* @__PURE__ */ new Map();
  var queuedComputations = /* @__PURE__ */ new Map();
  var priorityStack = [];
  var foregroundFlushScheduled = false;
  var deferredFlushScheduled = false;
  var consecutiveForegroundFlushes = 0;
  var maxFlushPasses = 1e3;
  var maxForegroundFlushesBeforeDeferred = 8;
  var priorityOrder = {
    interactive: 0,
    normal: 1,
    deferred: 2
  };
  var captureScheduledWorkContext;
  var settlementCallbacks = /* @__PURE__ */ new Set();
  var settlementScheduled = false;
  var settling = false;
  function setScheduledWorkContextCapture(capture) {
    captureScheduledWorkContext = capture;
  }
  function queueReaction(reaction, priority = currentWorkPriority()) {
    priority = constrainedPriority(reaction.scope, priority);
    const previous = queuedReactions.get(reaction);
    const context = captureScheduledWorkContext?.(priority);
    if (context)
      previous?.context?.cancel();
    if (!previous || isHigherWorkPriority(priority, previous.priority) || context)
      queuedReactions.set(reaction, {
        priority: previous && !isHigherWorkPriority(priority, previous.priority) ? previous.priority : priority,
        context: context ?? previous?.context
      });
    scheduleFlush(priority);
  }
  function queueComputation(computation, onError, priority = currentWorkPriority(), scope) {
    priority = constrainedPriority(scope, priority);
    const previous = queuedComputations.get(computation);
    if (!previous || isHigherWorkPriority(priority, previous.priority)) {
      queuedComputations.set(computation, {
        priority,
        onError: onError ?? previous?.onError,
        scope: scope ?? previous?.scope
      });
    }
    scheduleFlush(priority);
  }
  function removeQueuedComputation(computation) {
    queuedComputations.delete(computation);
  }
  function discardScheduledScopeWork(scope, scopes) {
    for (const reaction of queuedReactions.keys()) {
      if (scopes ? reaction.scope && scopes.has(reaction.scope) : reaction.scope === scope) {
        queuedReactions.get(reaction)?.context?.cancel();
        queuedReactions.delete(reaction);
      }
    }
    for (const [computation, queued] of queuedComputations) {
      if (scopes ? queued.scope && scopes.has(queued.scope) : queued.scope === scope)
        queuedComputations.delete(computation);
    }
  }
  function createScheduledScopePurge() {
    return queuedReactions.size || queuedComputations.size ? /* @__PURE__ */ new Set() : void 0;
  }
  function currentWorkPriority() {
    return priorityStack[priorityStack.length - 1] ?? "normal";
  }
  function inspectScheduledWork() {
    const computations = { interactive: 0, normal: 0, deferred: 0 };
    const reactions = { interactive: 0, normal: 0, deferred: 0 };
    for (const queued of queuedComputations.values())
      computations[queued.priority]++;
    for (const queued of queuedReactions.values())
      reactions[queued.priority]++;
    return Object.freeze({
      currentPriority: currentWorkPriority(),
      computations: Object.freeze(computations),
      reactions: Object.freeze(reactions)
    });
  }
  function runWithPriority(priority, work) {
    priorityStack.push(priority);
    try {
      return work();
    } finally {
      priorityStack.pop();
    }
  }
  function scheduleWork(work, priority = currentWorkPriority(), onError, scope) {
    queueComputation(work, onError, priority, scope);
  }
  function resumeScheduledWork() {
    scheduleRemainingWork();
  }
  function flushSync(through = "deferred") {
    let passes = 0;
    let firstError;
    let hasError = false;
    let profileStarted;
    const profiledReactions = /* @__PURE__ */ new Map();
    try {
      while (hasEligibleWork(through)) {
        if (++passes > maxFlushPasses) {
          const overflow = new Error("eXact reactive scheduler exceeded its flush limit; a reaction is repeatedly invalidating itself");
          if (settleOverflow(overflow))
            return;
          throw overflow;
        }
        while (hasEligibleComputations(through)) {
          if (++passes > maxFlushPasses) {
            const overflow = new Error("eXact reactive scheduler exceeded its flush limit; a computation is repeatedly invalidating itself");
            if (settleOverflow(overflow))
              return;
            throw overflow;
          }
          const computations = takeEligibleComputations(through);
          for (const [computation, queued] of computations) {
            if (queued.scope && !queued.scope.active)
              continue;
            try {
              runWithPriority(queued.priority, computation);
            } catch (error) {
              if (queued.onError) {
                try {
                  queued.onError(error);
                } catch (handlerError) {
                  if (!hasError)
                    firstError = handlerError;
                  hasError = true;
                }
              } else {
                if (!hasError)
                  firstError = error;
                hasError = true;
              }
            }
          }
        }
        const reactions = takeEligibleReactions(through);
        for (const [reaction, queued] of reactions) {
          if (!reaction.active || reaction.scope && (!reaction.scope.active || reaction.scope.paused)) {
            queued.context?.cancel();
            continue;
          }
          const profile = reaction.scope?.onProfile;
          if (profile) {
            profileStarted ??= profileTimestamp();
            profiledReactions.set(profile, (profiledReactions.get(profile) ?? 0) + 1);
          }
          try {
            if (queued.context)
              queued.context.run(() => runReactionWithPriority(queued.priority, reaction));
            else
              runReactionWithPriority(queued.priority, reaction);
          } catch (error) {
            if (!hasError)
              firstError = error;
            hasError = true;
          }
        }
      }
    } finally {
      if (through === "deferred") {
        foregroundFlushScheduled = false;
        deferredFlushScheduled = false;
      } else {
        foregroundFlushScheduled = false;
      }
      scheduleRemainingWork();
      if (!hasEligibleWork("deferred"))
        settleScheduler();
      if (profileStarted !== void 0) {
        for (const [sink, reactions] of profiledReactions) {
          publishExactProfile(sink, Object.freeze({
            subsystem: "reactive",
            phase: "flush",
            elapsedMs: profileTimestamp() - profileStarted,
            counts: Object.freeze({ passes, reactions })
          }));
        }
      }
    }
    if (hasError)
      throw firstError;
  }
  function runReactionWithPriority(priority, reaction) {
    priorityStack.push(priority);
    try {
      reaction.run();
    } finally {
      priorityStack.pop();
    }
  }
  function settleScheduler() {
    if (settling || hasEligibleWork("deferred"))
      return;
    settlementScheduled = false;
    if (!settlementCallbacks.size)
      return;
    const callbacks = [...settlementCallbacks];
    settlementCallbacks.clear();
    settling = true;
    try {
      for (const callback of callbacks)
        callback();
    } finally {
      settling = false;
      if (settlementCallbacks.size && !settlementScheduled) {
        settlementScheduled = true;
        queueMicrotask(settleScheduler);
      }
    }
  }
  function settleOverflow(error) {
    const handlers = /* @__PURE__ */ new Set();
    for (const queued of queuedComputations.values())
      if (queued.onError)
        handlers.add(queued.onError);
    for (const [reaction, queued] of queuedReactions) {
      reaction.scheduled = false;
      reaction.pendingPriority = void 0;
      queued.context?.cancel();
      if (reaction.scope?.onError)
        handlers.add(reaction.scope.onError);
    }
    queuedComputations.clear();
    queuedReactions.clear();
    if (!handlers.size)
      return false;
    let firstError;
    let failed = false;
    for (const handler of handlers) {
      try {
        handler(error);
      } catch (handlerError) {
        if (!failed)
          firstError = handlerError;
        failed = true;
      }
    }
    if (failed)
      throw firstError;
    return true;
  }
  function scheduleFlush(priority) {
    if (priority === "deferred") {
      if (foregroundFlushScheduled || deferredFlushScheduled)
        return;
      deferredFlushScheduled = true;
      scheduleDeferredFlush(() => {
        deferredFlushScheduled = false;
        consecutiveForegroundFlushes = 0;
        flushSync();
      });
      return;
    }
    if (foregroundFlushScheduled)
      return;
    foregroundFlushScheduled = true;
    queueMicrotask(() => {
      foregroundFlushScheduled = false;
      const drainDeferred = hasQueuedPriority("deferred") && ++consecutiveForegroundFlushes >= maxForegroundFlushesBeforeDeferred;
      if (drainDeferred)
        consecutiveForegroundFlushes = 0;
      flushSync(drainDeferred ? "deferred" : "normal");
    });
  }
  function scheduleRemainingWork() {
    const priority = highestQueuedPriority();
    if (priority)
      scheduleFlush(priority);
  }
  function highestQueuedPriority() {
    let selected;
    for (const [reaction, queued] of queuedReactions) {
      if (reaction.scope?.paused)
        continue;
      if (!selected || isHigherWorkPriority(queued.priority, selected))
        selected = queued.priority;
    }
    for (const queued of queuedComputations.values()) {
      if (queued.scope?.paused)
        continue;
      if (!selected || isHigherWorkPriority(queued.priority, selected))
        selected = queued.priority;
    }
    return selected;
  }
  function hasEligibleWork(through) {
    return hasEligibleComputations(through) || hasEligibleReactions(through);
  }
  function hasEligibleComputations(through) {
    for (const queued of queuedComputations.values()) {
      if (queued.scope?.paused)
        continue;
      if (isEligible(queued.priority, through))
        return true;
    }
    return false;
  }
  function hasEligibleReactions(through) {
    for (const [reaction, queued] of queuedReactions) {
      if (reaction.scope?.paused)
        continue;
      if (isEligible(queued.priority, through))
        return true;
    }
    return false;
  }
  function hasQueuedPriority(priority) {
    for (const [reaction, queued] of queuedReactions)
      if (!reaction.scope?.paused && queued.priority === priority)
        return true;
    for (const queued of queuedComputations.values())
      if (!queued.scope?.paused && queued.priority === priority)
        return true;
    return false;
  }
  function takeEligibleComputations(through) {
    const selected = [];
    for (const [computation, queued] of queuedComputations) {
      if (queued.scope?.paused)
        continue;
      if (!isEligible(queued.priority, through))
        continue;
      queuedComputations.delete(computation);
      selected.push([computation, queued]);
    }
    selected.sort((left, right) => priorityOrder[left[1].priority] - priorityOrder[right[1].priority]);
    return selected;
  }
  function takeEligibleReactions(through) {
    const selected = [];
    for (const [reaction, queued] of queuedReactions) {
      if (reaction.scope?.paused)
        continue;
      if (!isEligible(queued.priority, through))
        continue;
      queuedReactions.delete(reaction);
      selected.push([reaction, queued]);
    }
    selected.sort((left, right) => priorityOrder[left[1].priority] - priorityOrder[right[1].priority] || (left[0].order ?? 1) - (right[0].order ?? 1));
    return selected;
  }
  function isEligible(priority, through) {
    return priorityOrder[priority] <= priorityOrder[through];
  }
  function isHigherWorkPriority(candidate, current) {
    return priorityOrder[candidate] < priorityOrder[current];
  }
  function constrainedPriority(scope, requested) {
    let resolved = requested;
    for (let cursor = scope; cursor; cursor = cursor.parent) {
      if (cursor.workPriority && isHigherWorkPriority(resolved, cursor.workPriority))
        resolved = cursor.workPriority;
    }
    return resolved;
  }
  function scheduleDeferredFlush(flush) {
    setTimeout(flush, 0);
  }

  // packages/reactive/dist/internal/scopes.js
  var scopeStack = [];
  var emptyScopes = /* @__PURE__ */ new Set();
  var emptyReactions = /* @__PURE__ */ new Set();
  var emptyCleanups = /* @__PURE__ */ new Set();
  var emptyResumeWaiters = /* @__PURE__ */ new Set();
  var EffectScopeRecord = class {
    active = true;
    selfPaused = false;
    workPriority;
    parent;
    onError;
    onProfile;
    childrenValue;
    reactionsValue;
    cleanupsValue;
    resumeWaitersValue;
    constructor(parent, onError, onProfile) {
      this.parent = parent;
      this.onError = onError ?? parent?.onError;
      this.onProfile = onProfile ?? parent?.onProfile;
      parent?.children.add(this);
    }
    get paused() {
      return isEffectScopePaused(this);
    }
    get children() {
      return this.childrenValue ??= /* @__PURE__ */ new Set();
    }
    get reactions() {
      return this.reactionsValue ??= /* @__PURE__ */ new Set();
    }
    get cleanups() {
      return this.cleanupsValue ??= /* @__PURE__ */ new Set();
    }
    get resumeWaiters() {
      return this.resumeWaitersValue ??= /* @__PURE__ */ new Set();
    }
    pause() {
      this.selfPaused = true;
    }
    resume() {
      if (!this.selfPaused)
        return;
      this.selfPaused = false;
      notifyResumedSubtree(this);
      resumeScheduledWork();
    }
    stop() {
      stopEffectScope(this);
    }
    /** Returns descendants without materializing an empty child collection. */
    ownedChildren() {
      return this.childrenValue ?? emptyScopes;
    }
    /** Returns reactions without materializing an empty reaction collection. */
    ownedReactions() {
      return this.reactionsValue ?? emptyReactions;
    }
    /** Returns cleanups without materializing an empty cleanup collection. */
    ownedCleanups() {
      return this.cleanupsValue ?? emptyCleanups;
    }
    /** Returns pause waiters without materializing an empty waiter collection. */
    ownedResumeWaiters() {
      return this.resumeWaitersValue ?? emptyResumeWaiters;
    }
    /** Removes a child without allocating storage for a collection that cannot contain it. */
    removeChild(child) {
      this.childrenValue?.delete(child);
      if (this.childrenValue?.size === 0)
        this.childrenValue = void 0;
    }
    /** Removes a reaction and releases its now-empty backing collection. */
    removeReaction(reaction) {
      this.reactionsValue?.delete(reaction);
      if (this.reactionsValue?.size === 0)
        this.reactionsValue = void 0;
    }
    /** Removes a cleanup and releases its now-empty backing collection. */
    removeCleanup(cleanup) {
      this.cleanupsValue?.delete(cleanup);
      if (this.cleanupsValue?.size === 0)
        this.cleanupsValue = void 0;
    }
    /** Releases every settled pause waiter without retaining an empty set. */
    releaseResumeWaiters() {
      this.resumeWaitersValue = void 0;
    }
    /** Releases empty ownership collections after final disposal. */
    releaseCollections() {
      this.childrenValue = void 0;
      this.reactionsValue = void 0;
      this.cleanupsValue = void 0;
      this.resumeWaitersValue = void 0;
    }
  };
  function registerEffectScopeReaction(scope, reaction) {
    scope.reactions.add(reaction);
  }
  function releaseEffectScopeReaction(scope, reaction) {
    scope.removeReaction(reaction);
  }
  function registerEffectScopeCleanup(scope, cleanup) {
    scope.cleanups.add(cleanup);
  }
  function releaseEffectScopeCleanup(scope, cleanup) {
    scope.removeCleanup(cleanup);
  }
  function createEffectScope(parent = currentEffectScope(), onError, onProfile) {
    const parentScope = parent;
    if (parentScope && !parentScope.active) {
      throw new Error("Cannot create an effect scope beneath an inactive parent scope");
    }
    return new EffectScopeRecord(parentScope, onError, onProfile);
  }
  function createProfiledEffectScope(onProfile, parent = currentEffectScope(), onError) {
    return createEffectScope(parent, onError, onProfile);
  }
  function transferEffectScope(scope, parent) {
    const child = scope;
    const nextParent = parent;
    if (!child.active)
      throw new Error("Cannot transfer an inactive effect scope");
    if (nextParent && !nextParent.active)
      throw new Error("Cannot transfer an effect scope beneath an inactive parent scope");
    for (let cursor = nextParent; cursor; cursor = cursor.parent) {
      if (cursor === child)
        throw new Error("Cannot create an effect scope cycle");
    }
    if (child.parent === nextParent)
      return;
    child.parent?.removeChild(child);
    child.parent = nextParent;
    nextParent?.children.add(child);
    notifyResumedSubtree(child);
    resumeScheduledWork();
  }
  function stopEffectScope(root) {
    if (!root.active)
      return;
    const stopped = createScheduledScopePurge();
    const pending = [root];
    let firstError;
    let failed = false;
    while (pending.length) {
      const entry = pending.pop();
      const complete = entry === void 0;
      const scope = complete ? pending.pop() : entry;
      if (!complete) {
        if (!scope.active)
          continue;
        scope.active = false;
        for (const resume of scope.ownedResumeWaiters())
          resume();
        scope.releaseResumeWaiters();
        const children = scope.ownedChildren();
        if (children.size) {
          pending.push(scope, void 0);
          const childStart = pending.length;
          for (const child of children)
            pending.push(child);
          for (let left = childStart, right = pending.length - 1; left < right; left++, right--) {
            const child = pending[left];
            pending[left] = pending[right];
            pending[right] = child;
          }
          continue;
        }
      }
      for (const reaction of [...scope.ownedReactions()]) {
        try {
          reaction.stop();
        } catch (error) {
          if (!failed)
            firstError = error;
          failed = true;
        }
      }
      for (const cleanup of [...scope.ownedCleanups()]) {
        try {
          cleanup();
        } catch (error) {
          if (!failed)
            firstError = error;
          failed = true;
        }
      }
      if (stopped)
        stopped.add(scope);
      else
        discardScheduledScopeWork(scope);
      scope.parent?.removeChild(scope);
      scope.parent = void 0;
      scope.releaseCollections();
    }
    if (stopped)
      discardScheduledScopeWork(void 0, stopped);
    resumeScheduledWork();
    if (failed)
      throw firstError;
  }
  function withEffectScope(scope, fn) {
    if (!scope)
      return fn();
    if (!scope.active)
      throw new Error("Cannot create reactive work inside an inactive effect scope");
    scopeStack.push(scope);
    try {
      return fn();
    } finally {
      scopeStack.pop();
    }
  }
  function currentEffectScope() {
    return scopeStack[scopeStack.length - 1];
  }
  function whenEffectScopeResumed(scope, signal) {
    const owned = scope;
    if (!owned.active || !owned.paused || signal?.aborted)
      return Promise.resolve();
    return new Promise((resolve) => {
      const waiters = owned.resumeWaiters;
      const finish = () => {
        waiters.delete(finish);
        signal?.removeEventListener("abort", finish);
        resolve();
      };
      waiters.add(finish);
      signal?.addEventListener("abort", finish, { once: true });
    });
  }
  function setEffectScopeWorkPriority(scope, priority) {
    scope.workPriority = priority;
  }
  function effectScopeWorkPriority(scope, requested) {
    let resolved = requested;
    for (let cursor = scope; cursor; cursor = cursor.parent) {
      if (cursor.workPriority && isHigherWorkPriority(resolved, cursor.workPriority))
        resolved = cursor.workPriority;
    }
    return resolved;
  }
  function isEffectScopePaused(scope) {
    for (let cursor = scope; cursor; cursor = cursor.parent) {
      if (cursor.selfPaused)
        return true;
    }
    return false;
  }
  function notifyResumedSubtree(root) {
    const pending = [root];
    while (pending.length) {
      const scope = pending.pop();
      if (scope.active && !scope.paused && scope.ownedResumeWaiters().size) {
        for (const resume of scope.ownedResumeWaiters())
          resume();
        scope.releaseResumeWaiters();
      }
      for (const child of scope.ownedChildren())
        pending.push(child);
    }
  }

  // packages/reactive/dist/internal/symbols.js
  var proxyMarker = /* @__PURE__ */ Symbol.for("exact.reactive.proxy");
  var reactiveValueMarker = /* @__PURE__ */ Symbol.for("exact.reactive.value");
  var rawTarget = /* @__PURE__ */ Symbol.for("exact.reactive.raw");
  var reactiveValueRef = /* @__PURE__ */ Symbol.for("exact.reactive.valueRef");
  var iterateKey = /* @__PURE__ */ Symbol.for("exact.reactive.iterate");

  // packages/reactive/dist/internal/values.js
  function isReactiveValue(value) {
    return !!value && typeof value === "object" && reactiveValueMarker in value;
  }
  function isReactive(value) {
    return !!value && typeof value === "object" && Boolean(value[proxyMarker]);
  }
  function unwrap(value) {
    if (value === null || typeof value !== "object")
      return value;
    if (isReactiveValue(value))
      return value.get();
    if (isReactive(value))
      return value[rawTarget];
    return value;
  }
  function rejectReadonlyReactiveValueWrite() {
    throw new TypeError("Cannot write to readonly reactive value");
  }

  // packages/reactive/dist/proxy/state.js
  function conflictingListKeyError(left, right) {
    const sites = [left, right].sort();
    return new Error(`Conflicting this.map() key extractors for the same collection (${sites[0]} and ${sites[1]}). A reactive collection must have one stable key contract.`);
  }
  var defaultReactiveOptions = Object.freeze({});
  var readonlyReactiveOptionsKey = Object.freeze({ readonly: true });
  var rootProxyCache = /* @__PURE__ */ new WeakMap();
  var sourcedProxyCache = /* @__PURE__ */ new WeakMap();
  var parentSourceCache = /* @__PURE__ */ new WeakMap();
  var proxyRefs = /* @__PURE__ */ new WeakMap();
  var proxySources = /* @__PURE__ */ new WeakMap();
  var reactiveRawObjects = /* @__PURE__ */ new WeakSet();
  var listKeyExtractors = /* @__PURE__ */ new WeakMap();
  var mutatingArrayMethods = /* @__PURE__ */ new Set([
    "copyWithin",
    "fill",
    "pop",
    "push",
    "reverse",
    "shift",
    "sort",
    "splice",
    "unshift"
  ]);

  // packages/reactive/dist/internal/objects.js
  function isPlainObject(value) {
    if (!value || typeof value !== "object")
      return false;
    const prototype = Object.getPrototypeOf(value);
    return prototype === Object.prototype || prototype === null;
  }
  function isArrayStructureKey(target, key) {
    return Array.isArray(target) && (key === "length" || isArrayIndex(key));
  }
  function isArrayIndex(key) {
    if (typeof key === "number")
      return Number.isInteger(key) && key >= 0;
    if (typeof key !== "string" || key === "")
      return false;
    const index = Number(key);
    return Number.isInteger(index) && index >= 0 && String(index) === key;
  }

  // packages/reactive/dist/internal/equality.js
  var exactOpaqueOperationIdentity = /* @__PURE__ */ Symbol.for("@exactjs/opaque-target-operation");
  function hasChanged(previous, next, unwrap2) {
    return !structurallyEqual(previous, next, unwrap2);
  }
  function structurallyEqual(left, right, unwrap2) {
    if (Object.is(left, right)) return true;
    let leftToRight;
    let rightToLeft;
    const pending = [[left, right]];
    let visited = 0;
    while (pending.length) {
      if (++visited > 1e6)
        return false;
      const [rawLeft, rawRight] = pending.pop();
      if (Object.is(rawLeft, rawRight))
        continue;
      const currentLeft = unwrap2(rawLeft);
      const currentRight = unwrap2(rawRight);
      if (Object.is(currentLeft, currentRight))
        continue;
      if (!currentLeft || !currentRight || typeof currentLeft !== "object" || typeof currentRight !== "object")
        return false;
      if (exactOpaqueOperationIdentity in currentLeft || exactOpaqueOperationIdentity in currentRight)
        return false;
      leftToRight ??= /* @__PURE__ */ new WeakMap();
      rightToLeft ??= /* @__PURE__ */ new WeakMap();
      const priorRight = leftToRight.get(currentLeft);
      const priorLeft = rightToLeft.get(currentRight);
      if (priorRight || priorLeft) {
        if (priorRight !== currentRight || priorLeft !== currentLeft)
          return false;
        continue;
      }
      leftToRight.set(currentLeft, currentRight);
      rightToLeft.set(currentRight, currentLeft);
      const arrays = Array.isArray(currentLeft) && Array.isArray(currentRight);
      const objects = isPlainObject(currentLeft) && isPlainObject(currentRight);
      if (!arrays && !objects)
        return false;
      if (Object.getPrototypeOf(currentLeft) !== Object.getPrototypeOf(currentRight))
        return false;
      if (arrays && currentLeft.length !== currentRight.length)
        return false;
      const leftKeys = Reflect.ownKeys(currentLeft).filter((key) => !arrays || key !== "length");
      const rightKeys = Reflect.ownKeys(currentRight).filter((key) => !arrays || key !== "length");
      if (leftKeys.length !== rightKeys.length)
        return false;
      for (const key of leftKeys) {
        if (!Object.prototype.hasOwnProperty.call(currentRight, key))
          return false;
        const leftDescriptor = Reflect.getOwnPropertyDescriptor(currentLeft, key);
        const rightDescriptor = Reflect.getOwnPropertyDescriptor(currentRight, key);
        if (!leftDescriptor || !rightDescriptor)
          return false;
        if (!("value" in leftDescriptor) || !("value" in rightDescriptor)) {
          if (leftDescriptor.get !== rightDescriptor.get || leftDescriptor.set !== rightDescriptor.set || leftDescriptor.enumerable !== rightDescriptor.enumerable || leftDescriptor.configurable !== rightDescriptor.configurable)
            return false;
          continue;
        }
        if (leftDescriptor.enumerable !== rightDescriptor.enumerable || leftDescriptor.configurable !== rightDescriptor.configurable || leftDescriptor.writable !== rightDescriptor.writable)
          return false;
        pending.push([leftDescriptor.value, rightDescriptor.value]);
      }
    }
    return true;
  }

  // packages/reactive/dist/change-detection.js
  var exactOpaqueOperationIdentity2 = /* @__PURE__ */ Symbol.for("@exactjs/opaque-target-operation");
  function hasChanged2(previous, next) {
    return hasChanged(previous, next, unwrap);
  }
  function isReactiveContainer(value) {
    if (value && typeof value === "object" && Object.prototype.hasOwnProperty.call(value, exactOpaqueOperationIdentity2))
      return false;
    return Array.isArray(value) || value instanceof Map || value instanceof Set || isPlainObject(value);
  }
  function reactiveValueChanged(previous, next) {
    return (isReactiveValue(previous) || isReactiveValue(next)) && !Object.is(previous, next);
  }

  // packages/reactive/dist/computation.js
  var computedTargets = /* @__PURE__ */ new WeakMap();
  var computedValues = /* @__PURE__ */ new WeakMap();
  var maximumSettlementSteps = 1e5;
  var cycleMessage = "eXact reactive computation cycle detected";
  var nextSettlementGeneration = 0;
  var activeSettlementGeneration = 0;
  function computed(compute) {
    const node = new ComputedNode(compute, currentEffectScope());
    const value = {
      [reactiveValueMarker]: true,
      [reactiveValueRef]: node,
      get: () => node.get(),
      toJSON: readComputedValue,
      toString: computedValueToString,
      valueOf: readComputedValue,
      [Symbol.toPrimitive]: readComputedValue
    };
    computedValues.set(value, node);
    return value;
  }
  function readComputedValue() {
    return this.get();
  }
  function computedValueToString() {
    return String(this.get());
  }
  function inspectComputed(value) {
    return computedValues.get(value)?.inspect();
  }
  var ComputedNode = class {
    compute;
    scope;
    active = true;
    scheduled = false;
    pendingPriority;
    deps = [];
    target = {};
    key = "value";
    state = "dirty";
    initialized = false;
    current;
    observed = false;
    failed = false;
    invalidatedWhileComputing = false;
    validatedGeneration = 0;
    restorationVersion = readReactiveRestorationVersion();
    dependencies = [];
    computedSources;
    computedSinks;
    releaseObservationHooks;
    settleScheduled = () => this.settle();
    constructor(compute, scope) {
      this.compute = compute;
      this.scope = scope;
      computedTargets.set(this.target, this);
      this.releaseObservationHooks = registerDependencyObservationHooks(this.target, this.key, {
        onObserved: () => this.becomeObserved(),
        onUnobserved: () => this.becomeUnobserved()
      });
      if (scope)
        registerEffectScopeReaction(scope, this);
    }
    set(_value) {
      rejectReadonlyReactiveValueWrite();
    }
    get() {
      if (this.state === "computing")
        throw new Error(cycleMessage);
      if (this.active && !this.scope?.paused && (activeSettlementGeneration === 0 || this.validatedGeneration !== activeSettlementGeneration))
        this.settle();
      track(this.target, this.key);
      return this.current;
    }
    run() {
      this.scheduled = false;
      this.pendingPriority = void 0;
      if (!this.active || this.scope && !this.scope.active) {
        this.stop();
        return;
      }
      this.settle();
    }
    schedule() {
      if (!this.active || this.scope && !this.scope.active) {
        this.stop();
        return;
      }
      if (this.state !== "computing" && this.initialized && this.dependencies.every((dependency) => readMutationVersion(dependency.target, dependency.key) === dependency.version))
        return;
      if (this.state === "computing")
        this.invalidatedWhileComputing = true;
      else
        this.state = "dirty";
      this.markSinksChecked();
      if (this.isRetained())
        this.queue();
    }
    stop() {
      if (!this.active)
        return;
      this.active = false;
      this.state = "stopped";
      this.scheduled = false;
      this.pendingPriority = void 0;
      removeQueuedComputation(this.settleScheduled);
      cleanupReaction(this);
      this.detachComputedSources();
      this.releaseObservationHooks();
      if (this.scope)
        releaseEffectScopeReaction(this.scope, this);
    }
    inspect() {
      return Object.freeze({
        state: this.failed ? "failed" : this.scope?.paused ? "paused" : this.state,
        priority: this.pendingPriority ?? effectScopeWorkPriority(this.scope, currentWorkPriority()),
        observed: this.isRetained(),
        initialized: this.initialized,
        sources: this.dependencies.length,
        sinks: this.computedSinks?.size ?? 0
      });
    }
    settle() {
      if (!this.active || this.scope?.paused)
        return;
      const ownsGeneration = activeSettlementGeneration === 0;
      if (ownsGeneration)
        activeSettlementGeneration = ++nextSettlementGeneration;
      try {
        settleGraph(this);
      } finally {
        if (ownsGeneration)
          activeSettlementGeneration = 0;
      }
    }
    needsValidation() {
      return this.state !== "clean" || !this.isRetained() || hasActiveReactiveTransaction() || this.restorationVersion !== readReactiveRestorationVersion();
    }
    validateAndEvaluate() {
      if (!this.active || this.scope?.paused)
        return;
      if (this.state === "computing")
        throw new Error(cycleMessage);
      if (this.initialized && this.state !== "dirty") {
        const changed = this.dependencies.some((dependency) => readMutationVersion(dependency.target, dependency.key) !== dependency.version);
        if (!changed) {
          this.state = "clean";
          removeQueuedComputation(this.settleScheduled);
          this.scheduled = false;
          this.pendingPriority = void 0;
          this.validatedGeneration = activeSettlementGeneration;
          this.restorationVersion = readReactiveRestorationVersion();
          return;
        }
        this.state = "dirty";
      }
      if (this.state === "dirty" || !this.initialized)
        this.evaluate();
      this.validatedGeneration = activeSettlementGeneration;
      this.restorationVersion = readReactiveRestorationVersion();
    }
    evaluate() {
      const previousDependencies = this.dependencies;
      const previousValue = this.current;
      const hadValue = this.initialized;
      this.state = "computing";
      this.failed = false;
      this.invalidatedWhileComputing = false;
      removeQueuedComputation(this.settleScheduled);
      cleanupReaction(this);
      this.detachComputedSources();
      let next;
      try {
        withEffectScope(this.scope, () => runTracked(this, () => {
          const computedValue = this.compute();
          trackReturnedReference(computedValue);
          next = unwrap(computedValue);
        }));
      } catch (error) {
        this.recoverFromFailure(previousDependencies, error);
        return;
      }
      this.dependencies = snapshotDependencies(this);
      this.refreshComputedSources();
      if (!this.isRetained()) {
        cleanupReaction(this);
        this.detachComputedSources();
      }
      const changed = !hadValue || hasChanged2(previousValue, next);
      this.current = hadValue && !changed ? previousValue : next;
      this.initialized = true;
      this.state = this.invalidatedWhileComputing ? "dirty" : "clean";
      this.scheduled = false;
      this.pendingPriority = void 0;
      if (hadValue && changed)
        trigger(this.target, this.key);
      if (this.invalidatedWhileComputing)
        this.queue(true);
    }
    recoverFromFailure(previousDependencies, error) {
      const attemptedDependencies = snapshotDependencies(this);
      cleanupReaction(this);
      this.dependencies = mergeDependencies(previousDependencies, attemptedDependencies);
      if (this.isRetained())
        this.attachDependencies();
      this.failed = true;
      this.state = "clean";
      this.validatedGeneration = activeSettlementGeneration;
      this.restorationVersion = readReactiveRestorationVersion();
      removeQueuedComputation(this.settleScheduled);
      this.scheduled = false;
      this.pendingPriority = void 0;
      const onError = this.scope?.onError;
      if (!onError)
        throw error;
      onError(error);
    }
    queue(force = false) {
      if (!force && !this.isRetained())
        return;
      const priority = effectScopeWorkPriority(this.scope, currentWorkPriority());
      if (this.pendingPriority === void 0 || priority === "interactive" || this.pendingPriority === "deferred" && priority === "normal")
        this.pendingPriority = priority;
      this.scheduled = true;
      queueComputation(this.settleScheduled, void 0, priority, this.scope);
    }
    markSinksChecked() {
      const pending = this.computedSinks ? [...this.computedSinks] : [];
      const visited = /* @__PURE__ */ new Set();
      while (pending.length) {
        const sink = pending.pop();
        if (!visited.add(sink) || !sink.active)
          continue;
        if (sink.state === "clean")
          sink.state = "checked";
        if (sink.state === "computing")
          sink.invalidatedWhileComputing = true;
        if (sink.isRetained())
          sink.queue();
        if (sink.computedSinks)
          for (const descendant of sink.computedSinks)
            pending.push(descendant);
      }
    }
    becomeObserved() {
      if (this.observed || !this.active)
        return;
      this.observed = true;
      this.attachDependencies();
      if (this.state !== "clean")
        this.queue();
    }
    becomeUnobserved() {
      if (!this.observed)
        return;
      this.observed = false;
      if (this.scope)
        return;
      cleanupReaction(this);
      this.detachComputedSources();
      removeQueuedComputation(this.settleScheduled);
      this.scheduled = false;
      this.pendingPriority = void 0;
    }
    attachDependencies() {
      for (const dependency of this.dependencies)
        linkReaction(this, dependency.target, dependency.key);
      this.refreshComputedSources();
    }
    refreshComputedSources() {
      this.detachComputedSources();
      if (!this.isRetained())
        return;
      for (const dependency of this.dependencies) {
        if (!dependency.computed)
          continue;
        (this.computedSources ??= /* @__PURE__ */ new Set()).add(dependency.computed);
        (dependency.computed.computedSinks ??= /* @__PURE__ */ new Set()).add(this);
      }
    }
    detachComputedSources() {
      if (!this.computedSources)
        return;
      for (const source of this.computedSources) {
        source.computedSinks?.delete(this);
        if (source.computedSinks?.size === 0)
          source.computedSinks = void 0;
      }
      this.computedSources = void 0;
    }
    computedDependencies() {
      return this.dependencies;
    }
    isRetained() {
      return this.observed || Boolean(this.scope);
    }
  };
  function settleGraph(root) {
    const stack = [{ node: root, leave: false }];
    const visiting = /* @__PURE__ */ new Set();
    let steps = 0;
    while (stack.length) {
      if (++steps > maximumSettlementSteps)
        throw new Error("eXact reactive computation graph exceeded its settlement limit");
      const frame = stack.pop();
      const node = frame.node;
      if (frame.leave) {
        visiting.delete(node);
        node.validateAndEvaluate();
        continue;
      }
      if (!node.needsValidation())
        continue;
      if (visiting.has(node))
        throw new Error(cycleMessage);
      visiting.add(node);
      stack.push({ node, leave: true });
      const dependencies = node.computedDependencies();
      for (let index = dependencies.length - 1; index >= 0; index--) {
        const source = dependencies[index].computed;
        if (source)
          stack.push({ node: source, leave: false });
      }
    }
  }
  function snapshotDependencies(reaction) {
    return reactionDependencies(reaction).map(({ target, key }) => ({
      target,
      key,
      version: readMutationVersion(target, key),
      computed: computedTargets.get(target)
    }));
  }
  function mergeDependencies(previous, attempted) {
    const merged = [...attempted];
    for (const dependency of previous) {
      if (merged.some((candidate) => candidate.target === dependency.target && candidate.key === dependency.key))
        continue;
      merged.push({
        ...dependency,
        version: readMutationVersion(dependency.target, dependency.key)
      });
    }
    return merged;
  }
  function trackReturnedReference(value) {
    if (isReactiveValue(value)) {
      value.get();
      return;
    }
    if (value && typeof value === "object")
      proxyRefs.get(value)?.get();
  }

  // packages/reactive/dist/observation.js
  var inactiveWatch = () => void 0;
  var collectionRefs = /* @__PURE__ */ new WeakMap();
  function watch(fn, scheduler, options = {}) {
    return watchRetained(fn, scheduler, options) ?? inactiveWatch;
  }
  function watchRetained(fn, scheduler, options = {}) {
    const scope = resolveObservationScope(options);
    const reaction = new RetainedReaction(fn, scheduler, options, scope);
    if (scope)
      registerEffectScopeReaction(scope, reaction);
    try {
      reaction.run();
    } catch (error) {
      reaction.stop();
      throw error;
    }
    return reaction.active ? options.owned ? reaction : () => reaction.stop() : void 0;
  }
  var RetainedReaction = class {
    fn;
    scheduler;
    scope;
    fixed;
    active = true;
    scheduled = false;
    pendingPriority;
    deps = [];
    order;
    constructor(fn, scheduler, options, scope, fixed = false) {
      this.fn = fn;
      this.scheduler = scheduler;
      this.scope = scope;
      this.fixed = fixed;
      this.order = options.structural ? 0 : 1;
      this.onSchedule = options.onSchedule;
      this.onError = options.onError;
      this.onRelease = options.onRelease;
    }
    onSchedule;
    onError;
    onRelease;
    run() {
      if (!this.active)
        return;
      if (this.scope && !this.scope.active) {
        this.stop();
        return;
      }
      this.scheduled = false;
      this.pendingPriority = void 0;
      try {
        if (this.fixed)
          withEffectScope(this.scope, this.fn);
        else {
          withEffectScope(this.scope, () => runTracked(this, this.fn));
          if (this.deps.length === 0)
            this.stop();
        }
      } catch (error) {
        this.handleError(error);
      }
    }
    schedule() {
      if (!this.active)
        return;
      if (this.scope && !this.scope.active) {
        this.stop();
        return;
      }
      const priority = effectScopeWorkPriority(this.scope, currentWorkPriority());
      if (this.scheduled) {
        if (this.pendingPriority !== void 0 && isHigherWorkPriority(priority, this.pendingPriority)) {
          this.pendingPriority = priority;
          if (this.scheduler)
            this.scheduler();
          else
            queueReaction(this, priority);
        }
        return;
      }
      this.scheduled = true;
      this.pendingPriority = priority;
      try {
        if (this.onSchedule)
          withEffectScope(this.scope, this.onSchedule);
        if (this.scheduler)
          this.scheduler();
        else
          queueReaction(this);
      } catch (error) {
        this.scheduled = false;
        this.pendingPriority = void 0;
        this.handleError(error);
      }
    }
    stop() {
      if (!this.active)
        return;
      this.active = false;
      this.scheduled = false;
      this.pendingPriority = void 0;
      cleanupReaction(this);
      if (this.scope)
        releaseEffectScopeReaction(this.scope, this);
      this.onRelease?.();
    }
    handleError(error) {
      const onError = this.onError ?? this.scope?.onError;
      if (!onError)
        throw error;
      onError(error);
    }
  };
  function subscribe(source, callback, options = {}) {
    const scope = resolveObservationScope(options);
    const reaction = new RetainedReaction(callback, void 0, options, scope, true);
    linkReactionToDependency(reaction, getDep(source.target, source.key));
    if (scope)
      registerEffectScopeReaction(scope, reaction);
    return () => reaction.stop();
  }
  function resolveObservationScope(options) {
    return Object.prototype.hasOwnProperty.call(options, "scope") ? options.scope : currentEffectScope();
  }
  function ref(value) {
    if (isReactiveValue(value)) {
      value.get();
      return value[reactiveValueRef];
    }
    if (value && typeof value === "object") {
      return proxyRefs.get(value);
    }
    return void 0;
  }
  function collectionRef(value) {
    const existing = ref(value);
    let source = collectionRefs.get(value);
    if (source)
      return source;
    if (!existing && !isReactive(value))
      return void 0;
    const target = unwrap(value);
    source = {
      target: existing?.target ?? target,
      key: existing?.key ?? iterateKey,
      get() {
        const current = existing ? existing.get() : value;
        trackCollectionStructure(current);
        return current;
      },
      set(next) {
        if (existing) {
          existing.set(next);
          return;
        }
        throw new TypeError("Cannot replace a collection through its structural reference");
      }
    };
    collectionRefs.set(value, source);
    return source;
  }
  function trackCollectionStructure(value) {
    track(unwrap(value), iterateKey);
  }

  // packages/reactive/dist/internal/hash.js
  var encoder = new TextEncoder();
  function hashCanonicalJson(value, domain) {
    const canonical = canonicalJson(value);
    return hashText(`${domain.length}:${domain}${canonical.length}:${canonical}`);
  }
  function hashStringSequence(values, domain) {
    let framed = `${domain.length}:${domain}${values.length}:`;
    for (const value of values)
      framed += `${value.length}:${value}`;
    return hashText(framed);
  }
  function canonicalJson(value) {
    return encodeValue(value, /* @__PURE__ */ new WeakSet(), 0);
  }
  function encodeValue(value, active, depth) {
    if (depth > 100)
      throw new TypeError("Cannot hash JSON deeper than 100 levels");
    if (value === null)
      return "null";
    if (typeof value === "boolean")
      return value ? "true" : "false";
    if (typeof value === "string")
      return JSON.stringify(value);
    if (typeof value === "number") {
      if (!Number.isFinite(value))
        throw new TypeError("Cannot hash non-finite JSON numbers");
      return Object.is(value, -0) ? "0" : JSON.stringify(value);
    }
    if (!value || typeof value !== "object")
      throw new TypeError(`Cannot hash non-JSON ${typeof value}`);
    if (active.has(value))
      throw new TypeError("Cannot hash cyclic JSON");
    active.add(value);
    try {
      if (Array.isArray(value)) {
        if (Object.getPrototypeOf(value) !== Array.prototype)
          throw new TypeError("Cannot hash non-standard arrays");
        const keys2 = Object.keys(value);
        if (keys2.length !== value.length || keys2.some((key, index) => key !== String(index))) {
          throw new TypeError("Cannot hash sparse arrays or arrays with enumerable properties");
        }
        if (Object.getOwnPropertySymbols(value).some((symbol) => Object.prototype.propertyIsEnumerable.call(value, symbol))) {
          throw new TypeError("Cannot hash arrays with enumerable symbols");
        }
        const items = [];
        for (let index = 0; index < value.length; index++) {
          const descriptor = Object.getOwnPropertyDescriptor(value, String(index));
          if (!descriptor || !("value" in descriptor))
            throw new TypeError("Cannot hash array accessors");
          items.push(encodeValue(descriptor.value, active, depth + 1));
        }
        return `[${items.join(",")}]`;
      }
      const prototype = Object.getPrototypeOf(value);
      if (prototype !== Object.prototype && prototype !== null)
        throw new TypeError("Cannot hash non-plain JSON objects");
      if (Object.getOwnPropertySymbols(value).some((symbol) => Object.prototype.propertyIsEnumerable.call(value, symbol))) {
        throw new TypeError("Cannot hash objects with enumerable symbols");
      }
      const descriptors = Object.getOwnPropertyDescriptors(value);
      const keys = Object.keys(descriptors).filter((key) => descriptors[key].enumerable).sort();
      const properties = [];
      for (const key of keys) {
        const descriptor = descriptors[key];
        if (!("value" in descriptor))
          throw new TypeError("Cannot hash object accessors");
        properties.push(`${JSON.stringify(key)}:${encodeValue(descriptor.value, active, depth + 1)}`);
      }
      return `{${properties.join(",")}}`;
    } finally {
      active.delete(value);
    }
  }
  function hashText(value) {
    const bytes = encoder.encode(value);
    let a = 2166136261;
    let b = 2654435769;
    let c = 2246822507;
    let d = 3266489909;
    for (const byte of bytes) {
      a = Math.imul(a ^ byte, 16777619);
      b = Math.imul(b ^ byte, 668265261);
      c = Math.imul(c ^ byte, 374761393);
      d = Math.imul(d ^ byte, 2246822519);
    }
    a = avalanche(a ^ bytes.length);
    b = avalanche(b ^ a);
    c = avalanche(c ^ b);
    d = avalanche(d ^ c);
    return [a, b, c, d].map((part) => (part >>> 0).toString(16).padStart(8, "0")).join("");
  }
  function avalanche(value) {
    value ^= value >>> 16;
    value = Math.imul(value, 2146121005);
    value ^= value >>> 15;
    value = Math.imul(value, 2221713035);
    return value ^ value >>> 16;
  }

  // packages/reactive/dist/internal/keyed/protocol.js
  var hashPattern = /^[0-9a-f]{32}$/;
  function encodeKeyedProtocolValue(value, extractorFor, metadataFor) {
    return encodeValue2(value, extractorFor, metadataFor, /* @__PURE__ */ new WeakSet(), 0);
  }
  function decodeKeyedProtocolValue(value, install) {
    return decodeValue(value, install, /* @__PURE__ */ new WeakSet(), 0);
  }
  function encodeValue2(value, extractorFor, metadataFor, active, depth) {
    if (!value || typeof value !== "object")
      return value;
    if (depth > 100 || active.has(value))
      throw new TypeError("Cannot encode cyclic or excessively deep reactive protocol data");
    active.add(value);
    try {
      if (value instanceof Map) {
        const entries = [];
        for (const [key, item] of value) {
          assertTransportableMapKey(key);
          entries.push([key, encodeValue2(item, extractorFor, metadataFor, active, depth + 1)]);
        }
        return { $exact: "map", version: 1, entries };
      }
      if (value instanceof Set)
        return {
          $exact: "set",
          version: 1,
          values: [...value].map((item) => encodeValue2(item, extractorFor, metadataFor, active, depth + 1))
        };
      if (Array.isArray(value)) {
        const metadata = metadataFor(value, extractorFor(value));
        const items = value.map((item) => encodeValue2(item, extractorFor, metadataFor, active, depth + 1));
        if (!metadata)
          return items;
        return createKeyedCollectionEnvelope(metadata, items);
      }
      const output = {};
      for (const key of Object.keys(value))
        defineEncodedProperty(output, key, encodeValue2(value[key], extractorFor, metadataFor, active, depth + 1));
      return output;
    } finally {
      active.delete(value);
    }
  }
  function createKeyedCollectionEnvelope(metadata, items) {
    return {
      $exact: "keyed-collection",
      version: 1,
      keys: [...metadata.keys],
      keyHash: metadata.keyHash,
      itemHashes: [...metadata.itemHashes],
      itemsHash: metadata.itemsHash,
      items
    };
  }
  function defineEncodedProperty(output, key, value) {
    Object.defineProperty(output, key, {
      configurable: true,
      enumerable: true,
      writable: true,
      value
    });
  }
  function decodeValue(value, install, active, depth) {
    if (!value || typeof value !== "object")
      return value;
    if (depth > 100 || active.has(value))
      throw new TypeError("Cannot decode cyclic or excessively deep reactive protocol data");
    active.add(value);
    try {
      if (Array.isArray(value))
        return value.map((item) => decodeValue(item, install, active, depth + 1));
      if (value.$exact === "map") {
        const envelope = validateMapEnvelope(value);
        return new Map(envelope.entries.map(([key, item]) => [key, decodeValue(item, install, active, depth + 1)]));
      }
      if (value.$exact === "set") {
        const envelope = validateSetEnvelope(value);
        return new Set(envelope.values.map((item) => decodeValue(item, install, active, depth + 1)));
      }
      if (value.$exact === "keyed-collection") {
        const envelope = validateEnvelope(value);
        const items = envelope.items.map((item) => decodeValue(item, install, active, depth + 1));
        install(items, envelope);
        return items;
      }
      const output = {};
      for (const key of Object.keys(value))
        Object.defineProperty(output, key, {
          configurable: true,
          enumerable: true,
          writable: true,
          value: decodeValue(value[key], install, active, depth + 1)
        });
      return output;
    } finally {
      active.delete(value);
    }
  }
  function validateMapEnvelope(value) {
    if (!hasOnlyEnvelopeKeys(value, ["$exact", "version", "entries"]) || value.version !== 1 || !Array.isArray(value.entries) || !value.entries.every((entry) => Array.isArray(entry) && entry.length === 2 && isTransportableReactiveMapKey(entry[0])))
      throw new TypeError("Malformed eXact Map envelope");
    return value;
  }
  function validateSetEnvelope(value) {
    if (!hasOnlyEnvelopeKeys(value, ["$exact", "version", "values"]) || value.version !== 1 || !Array.isArray(value.values))
      throw new TypeError("Malformed eXact Set envelope");
    return value;
  }
  function validateEnvelope(value) {
    const allowed = /* @__PURE__ */ new Set([
      "$exact",
      "version",
      "keys",
      "keyHash",
      "itemHashes",
      "itemsHash",
      "items"
    ]);
    if (Object.keys(value).some((key) => !allowed.has(key)) || value.version !== 1 || !Array.isArray(value.keys) || !value.keys.every((key) => typeof key === "string") || new Set(value.keys).size !== value.keys.length || !Array.isArray(value.itemHashes) || !value.itemHashes.every((hash) => typeof hash === "string" && hashPattern.test(hash)) || !Array.isArray(value.items) || value.keys.length !== value.itemHashes.length || value.keys.length !== value.items.length || typeof value.keyHash !== "string" || !hashPattern.test(value.keyHash) || typeof value.itemsHash !== "string" || !hashPattern.test(value.itemsHash))
      throw new TypeError("Malformed eXact keyed-collection envelope");
    return value;
  }
  function assertTransportableMapKey(value) {
    if (!isTransportableReactiveMapKey(value))
      throw new TypeError("eXact Map protocol keys must be null, boolean, finite number, or string values");
  }
  function isTransportableReactiveMapKey(value) {
    return value === null || typeof value === "boolean" || typeof value === "string" || typeof value === "number" && Number.isFinite(value);
  }
  function hasOnlyEnvelopeKeys(value, allowed) {
    const keys = new Set(allowed);
    return Object.keys(value).every((key) => keys.has(key));
  }

  // packages/reactive/dist/internal/keyed-collections.js
  var metadataByCollection = /* @__PURE__ */ new WeakMap();
  var ownersByObject = /* @__PURE__ */ new WeakMap();
  function seedKeyedCollectionMetadata(collection, key) {
    return rebuildMetadata(collection, key);
  }
  function releaseKeyedCollectionMetadata(collection) {
    clearMetadata(collection);
  }
  function keyedCollectionMetadata(collection, key) {
    const metadata = metadataByCollection.get(collection);
    if (!metadata)
      return key ? rebuildMetadata(collection, key) : void 0;
    if (!metadata.structureDirty && metadata.dirtyKeys.size === 0)
      return metadata;
    if (!key)
      return void 0;
    if (metadata.structureDirty || keysChanged(collection, metadata.keys, key))
      return rebuildMetadata(collection, key);
    try {
      const dirtyKeys = new Set(metadata.dirtyKeys);
      for (let index = 0; index < collection.length; index++) {
        const itemKey = metadata.keys[index];
        if (metadata.dirtyKeys.has(itemKey))
          metadata.itemHashes[index] = hashItem(itemKey, collection[index]);
      }
      metadata.itemsHash = hashStringSequence(metadata.itemHashes, "exact:keyed-items:v1");
      metadata.dirtyKeys.clear();
      rebindOwners(metadata, collection, dirtyKeys);
      return metadata;
    } catch {
      clearMetadata(collection);
      return void 0;
    }
  }
  function markReactiveHashDirty(target) {
    const own = metadataByCollection.get(target);
    if (own)
      own.structureDirty = true;
    for (const owner of ownersByObject.get(target) ?? [])
      ownerMetadata(owner)?.dirtyKeys.add(owner.key);
  }
  function installKeyedCollectionMetadata(collection, source, bindMutationOwners = true) {
    clearMetadata(collection);
    const metadata = {
      keys: [...source.keys],
      keyHash: source.keyHash,
      itemHashes: [...source.itemHashes],
      itemsHash: source.itemsHash,
      structureDirty: false,
      dirtyKeys: /* @__PURE__ */ new Set(),
      owners: []
    };
    metadataByCollection.set(collection, metadata);
    if (bindMutationOwners)
      bindOwners(metadata, collection);
  }
  function adoptKeyedCollectionMetadata(collection, source, changedKeys) {
    const metadata = metadataByCollection.get(collection);
    if (!metadata) {
      installKeyedCollectionMetadata(collection, source);
      return;
    }
    const previousOwners = /* @__PURE__ */ new Map();
    for (let index = 0; index < metadata.keys.length; index++) {
      const owner = metadata.owners[index];
      if (owner)
        previousOwners.set(metadata.keys[index], owner);
    }
    const retainedOwners = /* @__PURE__ */ new Set();
    const nextOwners = [];
    for (let index = 0; index < source.keys.length; index++) {
      const key = source.keys[index];
      const previous = previousOwners.get(key);
      if (previous && !changedKeys.has(key)) {
        retainedOwners.add(previous);
        nextOwners.push(previous);
        continue;
      }
      if (previous)
        clearOwner(previous);
      nextOwners.push(createOwner(collection, key, collection[index]));
    }
    for (const owner of metadata.owners)
      if (!retainedOwners.has(owner) && !changedKeys.has(owner.key))
        clearOwner(owner);
    metadata.owners = nextOwners;
    metadata.keys = [...source.keys];
    metadata.keyHash = source.keyHash;
    metadata.itemHashes = [...source.itemHashes];
    metadata.itemsHash = source.itemsHash;
    metadata.structureDirty = false;
    metadata.dirtyKeys.clear();
  }
  function encodeReactiveProtocolValueInternal(value, extractorFor) {
    return encodeKeyedProtocolValue(value, extractorFor, keyedCollectionMetadata);
  }
  function decodeReactiveProtocolValueInternal(value) {
    return decodeKeyedProtocolValue(value, (items, envelope) => installKeyedCollectionMetadata(items, envelope, false));
  }
  function rebuildMetadata(collection, key) {
    try {
      const keys = [];
      const itemHashes = [];
      const seen = /* @__PURE__ */ new Set();
      for (const item of collection) {
        const itemKey = String(key(item));
        if (seen.has(itemKey))
          throw new Error(`Duplicate key "${itemKey}"`);
        seen.add(itemKey);
        keys.push(itemKey);
        itemHashes.push(hashItem(itemKey, item));
      }
      clearMetadata(collection);
      const metadata = {
        keys,
        keyHash: hashStringSequence(keys, "exact:keyed-keys:v1"),
        itemHashes,
        itemsHash: hashStringSequence(itemHashes, "exact:keyed-items:v1"),
        structureDirty: false,
        dirtyKeys: /* @__PURE__ */ new Set(),
        owners: []
      };
      metadataByCollection.set(collection, metadata);
      bindOwners(metadata, collection);
      return metadata;
    } catch {
      clearMetadata(collection);
      return void 0;
    }
  }
  function keysChanged(collection, keys, key) {
    if (collection.length !== keys.length)
      return true;
    for (let index = 0; index < collection.length; index++)
      if (String(key(collection[index])) !== keys[index])
        return true;
    return false;
  }
  function hashItem(key, value) {
    return hashCanonicalJson([key, value], "exact:keyed-item:v1");
  }
  function bindOwners(metadata, collection) {
    clearOwners(metadata);
    for (let index = 0; index < collection.length; index++) {
      const owner = createOwner(collection, metadata.keys[index], collection[index]);
      metadata.owners.push(owner);
    }
  }
  function rebindOwners(metadata, collection, keys) {
    for (let index = 0; index < metadata.keys.length; index++) {
      if (!keys.has(metadata.keys[index]))
        continue;
      const previous = metadata.owners[index];
      if (previous)
        clearOwner(previous);
      const owner = createOwner(collection, metadata.keys[index], collection[index]);
      metadata.owners[index] = owner;
    }
  }
  function createOwner(collection, key, value) {
    const nodes = [];
    collectJsonObjects(value, nodes, /* @__PURE__ */ new WeakSet(), 0);
    const owner = { collection, key, nodes };
    for (const node of nodes) {
      let owners = ownersByObject.get(node);
      if (!owners)
        ownersByObject.set(node, owners = /* @__PURE__ */ new Set());
      owners.add(owner);
    }
    return owner;
  }
  function collectJsonObjects(value, output, seen, depth) {
    if (!value || typeof value !== "object" || seen.has(value) || depth > 100)
      return;
    seen.add(value);
    output.push(value);
    if (Array.isArray(value)) {
      for (const item of value)
        collectJsonObjects(item, output, seen, depth + 1);
    } else {
      for (const key of Object.keys(value)) {
        const descriptor = Object.getOwnPropertyDescriptor(value, key);
        if (descriptor && "value" in descriptor)
          collectJsonObjects(descriptor.value, output, seen, depth + 1);
      }
    }
  }
  function clearMetadata(collection) {
    const metadata = metadataByCollection.get(collection);
    if (metadata)
      clearOwners(metadata);
    metadataByCollection.delete(collection);
  }
  function clearOwners(metadata) {
    for (const owner of metadata.owners)
      clearOwner(owner);
    metadata.owners = [];
  }
  function clearOwner(owner) {
    for (const node of owner.nodes) {
      const owners = ownersByObject.get(node);
      owners?.delete(owner);
      if (owners?.size === 0)
        ownersByObject.delete(node);
    }
  }
  function ownerMetadata(owner) {
    return metadataByCollection.get(owner.collection);
  }

  // packages/reactive/dist/array-mutation.js
  function mutateArray(target, methodName, method, args, receiver, options) {
    if ((methodName === "push" || methodName === "pop") && method === Array.prototype[methodName]) {
      return mutateArrayEnd(target, methodName, method, args, receiver, options);
    }
    const previous = target.slice();
    let result;
    try {
      result = method.apply(target, args.map((arg) => unwrap(arg)));
    } finally {
      recordArrayMutationUndo(target, previous);
      batch(() => {
        const maxLength = Math.max(previous.length, target.length);
        let changed = previous.length !== target.length;
        for (let index = 0; index < maxLength; index++) {
          const existed = Reflect.has(previous, index);
          const exists = Reflect.has(target, index);
          if (existed === exists && Object.is(unwrap(previous[index]), unwrap(target[index])))
            continue;
          changed = true;
          trigger(target, String(index));
        }
        if (previous.length !== target.length)
          trigger(target, "length");
        if (changed) {
          markReactiveHashDirty(target);
          trigger(target, iterateKey);
          notifyMutation(options, methodName);
        }
      });
    }
    return result === target ? receiver : result;
  }
  function notifyMutation(options, operation) {
    try {
      options.onMutation?.(void 0, operation);
    } catch {
    }
  }
  function recordArrayMutationUndo(target, previous) {
    if (!hasActiveTransaction())
      return;
    const optimistic = target.slice();
    let prefix = 0;
    while (prefix < previous.length && prefix < optimistic.length && sameArraySlot(previous, optimistic, prefix, prefix))
      prefix++;
    let suffix = 0;
    while (suffix < previous.length - prefix && suffix < optimistic.length - prefix && sameArraySlot(previous, optimistic, previous.length - suffix - 1, optimistic.length - suffix - 1))
      suffix++;
    const previousEnd = previous.length - suffix;
    const optimisticEnd = optimistic.length - suffix;
    const removed = previous.slice(prefix, previousEnd);
    const inserted = optimistic.slice(prefix, optimisticEnd);
    recordTransactionUndo(() => {
      let segmentUnchanged = true;
      for (let offset = 0; offset < inserted.length; offset++) {
        if (!sameArraySlot(optimistic, target, prefix + offset, prefix + offset)) {
          segmentUnchanged = false;
          break;
        }
      }
      if (segmentUnchanged) {
        Array.prototype.splice.call(target, prefix, inserted.length, ...removed.map((value) => unwrap(value)));
        for (let offset = 0; offset < removed.length; offset++) {
          const previousIndex = prefix + offset;
          const targetIndex = prefix + offset;
          const descriptor = Reflect.getOwnPropertyDescriptor(previous, String(previousIndex));
          if (descriptor)
            Reflect.defineProperty(target, String(targetIndex), descriptor);
          else
            Reflect.deleteProperty(target, String(targetIndex));
        }
        return;
      }
      const changedLength = Math.max(previousEnd, optimisticEnd);
      for (let index = prefix; index < changedLength; index++) {
        if (!sameArraySlot(optimistic, target, index, index))
          continue;
        if (Reflect.has(previous, index))
          target[index] = previous[index];
        else
          Reflect.deleteProperty(target, index);
      }
    });
  }
  function sameArraySlot(left, right, leftIndex, rightIndex) {
    const leftExists = Reflect.has(left, leftIndex);
    const rightExists = Reflect.has(right, rightIndex);
    return leftExists === rightExists && (!leftExists || Object.is(unwrap(left[leftIndex]), unwrap(right[rightIndex])));
  }
  function mutateArrayEnd(target, methodName, method, args, receiver, options) {
    const oldLength = target.length;
    const removed = methodName === "pop" && oldLength > 0 ? Reflect.getOwnPropertyDescriptor(target, String(oldLength - 1)) : void 0;
    const journaled = hasActiveTransaction();
    const result = method.apply(target, args.map((arg) => unwrap(arg)));
    const newLength = target.length;
    if (newLength !== oldLength) {
      if (journaled) {
        if (methodName === "push") {
          for (let index = oldLength; index < newLength; index++) {
            const insertedIndex = index;
            recordTransactionUndo(() => {
              Array.prototype.splice.call(target, insertedIndex, 1);
            }, target, String(insertedIndex));
          }
        } else {
          recordTransactionUndo(() => {
            Array.prototype.splice.call(target, oldLength - 1, 0, void 0);
            if (removed)
              Reflect.defineProperty(target, String(oldLength - 1), removed);
            else
              Reflect.deleteProperty(target, String(oldLength - 1));
          }, target, String(oldLength - 1));
        }
      }
      batch(() => {
        markReactiveHashDirty(target);
        if (methodName === "push") {
          for (let index = oldLength; index < newLength; index++)
            trigger(target, String(index));
        } else {
          trigger(target, String(oldLength - 1));
        }
        trigger(target, "length");
        trigger(target, iterateKey);
      });
      notifyMutation(options, methodName);
    }
    return result === target ? receiver : result;
  }
  function recordPropertyUndo(target, key) {
    if (!hasActiveTransaction())
      return;
    recordTransactionUndo(createPropertyUndo(target, key), target, key);
  }
  function createPropertyUndo(target, key) {
    if (Array.isArray(target) && key === "length")
      return createArrayUndo(target);
    const descriptor = Reflect.getOwnPropertyDescriptor(target, key);
    const arrayTarget = Array.isArray(target) ? target : void 0;
    const oldLength = arrayTarget?.length;
    return () => {
      if (descriptor)
        Reflect.defineProperty(target, key, descriptor);
      else
        Reflect.deleteProperty(target, key);
      if (oldLength !== void 0 && arrayTarget && arrayTarget.length !== oldLength)
        arrayTarget.length = oldLength;
    };
  }
  function recordArrayUndo(target) {
    if (!hasActiveTransaction())
      return;
    recordTransactionUndo(createArrayUndo(target), target, iterateKey);
  }
  function createArrayUndo(target) {
    const descriptors = /* @__PURE__ */ new Map();
    for (const key of Reflect.ownKeys(target)) {
      const descriptor = Reflect.getOwnPropertyDescriptor(target, key);
      if (descriptor)
        descriptors.set(key, descriptor);
    }
    return () => {
      for (const key of Reflect.ownKeys(target))
        if (key !== "length" && !descriptors.has(key))
          Reflect.deleteProperty(target, key);
      const length = descriptors.get("length")?.value;
      if (typeof length === "number")
        target.length = length;
      for (const [key, descriptor] of descriptors)
        if (key !== "length")
          Reflect.defineProperty(target, key, descriptor);
    };
  }

  // packages/reactive/dist/proxy/create-base.js
  var reactiveProxyHandler = {
    get(target, key, receiver) {
      if (key === proxyMarker)
        return true;
      if (key === rawTarget)
        return target;
      const { collectionMember, options, proxy } = this.record;
      trackProxySources(proxy);
      if (target instanceof Map || target instanceof Set) {
        if (!collectionMember)
          throw new TypeError("Compiled object/array state received a Map or Set value");
        return collectionMember(target, key, proxy, options, (current2, dependency) => {
          if (!current2 || typeof current2 !== "object" || !isReactiveContainer(unwrap(current2)))
            return current2;
          return sourcedReactive(unwrap(current2), options, dependency === void 0 ? void 0 : createParentSource(target, dependency, options, collectionMember), collectionMember);
        });
      }
      const current = Reflect.get(target, key, receiver);
      if (current && typeof current === "object" && requiresExactProxyValue(target, key))
        return current;
      if (Array.isArray(target) && mutatingArrayMethods.has(key) && typeof current === "function") {
        return (...args) => mutateArray(target, String(key), current, args, receiver, options);
      }
      if (options.passthroughKeys?.includes(key)) {
        track(target, key);
        return current;
      }
      if (isReactiveValue(current)) {
        track(target, key);
        const currentValue = current.get();
        const currentTarget = unwrap(currentValue);
        return isReactiveContainer(currentTarget) ? sourcedReactive(currentTarget, options, createParentSource(target, key, options, collectionMember), collectionMember) : currentTarget;
      }
      if (current && typeof current === "object" && isReactiveContainer(unwrap(current))) {
        const currentTarget = unwrap(current);
        if (currentTarget === target) {
          track(target, key);
          return receiver;
        }
        const source = createParentSource(target, key, options, collectionMember);
        return sourcedReactive(currentTarget, options, source, collectionMember);
      }
      track(target, key);
      return current;
    },
    set(target, key, next, receiver) {
      const { options } = this.record;
      if (options.readonly) {
        options.onReadonlyWrite?.(key);
        return false;
      }
      const previousLength = Array.isArray(target) ? target.length : void 0;
      const removedIndexes = Array.isArray(target) && key === "length" && typeof next === "number" && next < target.length ? Array.from({ length: target.length - next }, (_, offset) => next + offset).filter((index) => Reflect.has(target, index)) : [];
      const previous = Reflect.get(target, key, receiver);
      const unwrapped = unwrap(next);
      const hadKey = Object.prototype.hasOwnProperty.call(target, key);
      const changed = hasChanged2(previous, unwrapped);
      const ownDescriptor = Reflect.getOwnPropertyDescriptor(target, key);
      if (!changed && ownDescriptor && "value" in ownDescriptor)
        return true;
      const undo = hasActiveTransaction() ? createPropertyUndo(target, key) : void 0;
      this.record.forwardingSet = true;
      let ok;
      try {
        ok = Reflect.set(target, key, unwrapped, receiver);
      } finally {
        this.record.forwardingSet = false;
      }
      if (ok && undo && (!hadKey || !Object.is(previous, Reflect.get(target, key, receiver))))
        recordTransactionUndo(undo, target, key);
      if (ok && changed) {
        markReactiveHashDirty(target);
        trigger(target, key);
        for (const index of removedIndexes)
          trigger(target, String(index));
        if (previousLength !== void 0 && Array.isArray(target) && target.length !== previousLength && key !== "length")
          trigger(target, "length");
        if (!hadKey || isArrayStructureKey(target, key))
          trigger(target, iterateKey);
        notifyMutation2(options, key, "set");
      }
      return ok;
    },
    defineProperty(target, key, descriptor) {
      const { options } = this.record;
      if (this.record.forwardingSet)
        return Reflect.defineProperty(target, key, descriptor);
      if (options.readonly) {
        options.onReadonlyWrite?.(key);
        return false;
      }
      const previous = Reflect.getOwnPropertyDescriptor(target, key);
      if (samePropertyDescriptor(previous, descriptor))
        return true;
      const undo = hasActiveTransaction() ? createPropertyUndo(target, key) : void 0;
      const oldLength = Array.isArray(target) ? target.length : void 0;
      const ok = Reflect.defineProperty(target, key, normalizeDescriptor(descriptor));
      if (!ok)
        return false;
      if (undo)
        recordTransactionUndo(undo, target, key);
      markReactiveHashDirty(target);
      trigger(target, key);
      if (!previous || isArrayStructureKey(target, key))
        trigger(target, iterateKey);
      if (oldLength !== void 0 && target.length !== oldLength && key !== "length")
        trigger(target, "length");
      notifyMutation2(options, key, "define");
      return true;
    },
    deleteProperty(target, key) {
      const { options } = this.record;
      if (options.readonly) {
        options.onReadonlyWrite?.(key);
        return false;
      }
      const hadKey = Object.prototype.hasOwnProperty.call(target, key);
      const descriptor = hadKey && hasActiveTransaction() ? Reflect.getOwnPropertyDescriptor(target, key) : void 0;
      const ok = Reflect.deleteProperty(target, key);
      if (ok && hadKey) {
        if (descriptor)
          recordTransactionUndo(() => {
            Reflect.defineProperty(target, key, descriptor);
          }, target, key);
        markReactiveHashDirty(target);
        trigger(target, key);
        trigger(target, iterateKey);
        notifyMutation2(options, key, "delete");
      }
      return ok;
    },
    ownKeys(target) {
      trackProxySources(this.record.proxy);
      track(target, iterateKey);
      return Reflect.ownKeys(target);
    },
    has(target, key) {
      track(target, key);
      return Reflect.has(target, key);
    }
  };
  function createReactiveBase(value, options, parentSource, collectionMember) {
    const reactiveTarget = isReactive(value) ? value[rawTarget] : value;
    const cached = getCachedProxy(reactiveTarget, options, parentSource);
    if (cached) {
      if (parentSource)
        registerProxySource(cached, parentSource);
      return cached;
    }
    const record = { options, collectionMember, forwardingSet: false };
    const handler = Object.create(reactiveProxyHandler);
    handler.record = record;
    const proxy = new Proxy(reactiveTarget, handler);
    record.proxy = proxy;
    cacheProxy(reactiveTarget, options, parentSource, proxy);
    if (parentSource) {
      reactiveRawObjects.add(reactiveTarget);
      registerProxySource(proxy, parentSource);
    }
    return proxy;
  }
  function requiresExactProxyValue(target, key) {
    const descriptor = Reflect.getOwnPropertyDescriptor(target, key);
    return !!descriptor && "value" in descriptor && !descriptor.configurable && !descriptor.writable;
  }
  function createParentSource(target, key, options, collectionMember) {
    const optionKey = reactiveOptionsKey(options);
    let byKey = parentSourceCache.get(target);
    if (!byKey)
      parentSourceCache.set(target, byKey = /* @__PURE__ */ new Map());
    let byOptions = byKey.get(key);
    if (!byOptions)
      byKey.set(key, byOptions = /* @__PURE__ */ new WeakMap());
    const cached = byOptions.get(optionKey);
    if (cached)
      return cached;
    const source = {
      target,
      key,
      get() {
        track(target, key);
        const next = Reflect.get(target, key);
        if (isReactiveValue(next)) {
          const nextValue = next.get();
          return nextValue && typeof nextValue === "object" ? sourcedReactive(unwrap(nextValue), options, source, collectionMember) : nextValue;
        }
        return next && typeof next === "object" ? sourcedReactive(unwrap(next), options, source, collectionMember) : next;
      },
      set(value) {
        const previous = Reflect.get(target, key);
        const unwrapped = unwrap(value);
        if (!hasChanged2(previous, unwrapped))
          return;
        recordPropertyUndo(target, key);
        Reflect.set(target, key, unwrapped);
        markReactiveHashDirty(target);
        trigger(target, key);
        if (isArrayStructureKey(target, key))
          trigger(target, iterateKey);
      }
    };
    byOptions.set(optionKey, source);
    return source;
  }
  function sourcedReactive(raw, options, source, collectionMember) {
    if (!source)
      return createReactiveBase(raw, options, void 0, collectionMember);
    if (source.cachedRaw === raw && source.cachedProxy) {
      registerProxySource(source.cachedProxy, source);
      return source.cachedProxy;
    }
    const proxy = createReactiveBase(raw, options, source, collectionMember);
    source.cachedRaw = raw;
    source.cachedProxy = proxy;
    return proxy;
  }
  function getCachedProxy(raw, options, source) {
    const optionKey = reactiveOptionsKey(options);
    if (!source)
      return rootProxyCache.get(raw)?.get(optionKey);
    const bySource = sourcedProxyCache.get(raw)?.get(optionKey);
    const exact = bySource?.get(source);
    if (exact)
      return exact;
    if (bySource) {
      for (const [oldSource, proxy] of bySource) {
        if (unwrap(Reflect.get(oldSource.target, oldSource.key)) === raw)
          continue;
        bySource.delete(oldSource);
        bySource.set(source, proxy);
        proxySources.set(proxy, /* @__PURE__ */ new Set([source]));
        proxyRefs.set(proxy, source);
        return proxy;
      }
    }
    return void 0;
  }
  function cacheProxy(raw, options, source, proxy) {
    const optionKey = reactiveOptionsKey(options);
    if (source) {
      let byOptions2 = sourcedProxyCache.get(raw);
      if (!byOptions2)
        sourcedProxyCache.set(raw, byOptions2 = /* @__PURE__ */ new WeakMap());
      let bySource = byOptions2.get(optionKey);
      if (!bySource)
        byOptions2.set(optionKey, bySource = /* @__PURE__ */ new Map());
      bySource.set(source, proxy);
      return;
    }
    let byOptions = rootProxyCache.get(raw);
    if (!byOptions)
      rootProxyCache.set(raw, byOptions = /* @__PURE__ */ new WeakMap());
    byOptions.set(optionKey, proxy);
  }
  function registerProxySource(proxy, source) {
    proxySources.set(proxy, /* @__PURE__ */ new Set([source]));
    proxyRefs.set(proxy, source);
  }
  function trackProxySources(proxy) {
    for (const source of proxySources.get(proxy) ?? [])
      track(source.target, source.key);
  }
  function normalizeDescriptor(descriptor) {
    return "value" in descriptor ? { ...descriptor, value: unwrap(descriptor.value) } : descriptor;
  }
  function samePropertyDescriptor(left, right) {
    if (!left)
      return false;
    if ("value" in left !== "value" in right)
      return false;
    if (left.configurable !== right.configurable || left.enumerable !== right.enumerable)
      return false;
    if ("value" in left && "value" in right) {
      return left.writable === right.writable && !hasChanged2(left.value, right.value);
    }
    return left.get === right.get && left.set === right.set;
  }
  function reactiveOptionsKey(options) {
    if ("__exactCollectionCacheMode" in options)
      return options;
    if (!options.readonly && !options.onReadonlyWrite && !options.onMutation && !options.passthroughKeys?.length)
      return defaultReactiveOptions;
    if (options.readonly && !options.onReadonlyWrite && !options.onMutation && !options.passthroughKeys?.length)
      return readonlyReactiveOptionsKey;
    return options;
  }
  function notifyMutation2(options, key, operation) {
    try {
      options.onMutation?.(key, operation);
    } catch {
    }
  }

  // packages/reactive/dist/framework/objects.js
  function reactiveObjects(value, options = defaultReactiveOptions, parentSource) {
    const raw = unwrap(value);
    if (!isReactiveContainer(raw))
      return value;
    if (raw instanceof Map || raw instanceof Set)
      throw new TypeError("Compiled object/array state received a Map or Set value");
    return createReactiveBase(raw, options, parentSource);
  }

  // packages/reactive/dist/external-source.js
  function createExternalSource(options) {
    const serverSnapshot = !("window" in globalThis) && options.getServerSnapshot !== void 0;
    let current = serverSnapshot ? options.getServerSnapshot() : options.getSnapshot();
    const state = reactiveObjects({ revision: 0 });
    let stop;
    let disposed = false;
    const ownerScope = currentEffectScope();
    const refresh = () => {
      if (disposed)
        return current;
      const next = options.getSnapshot();
      if (!(options.isEqual ?? Object.is)(current, next)) {
        current = next;
        batch(() => {
          state.revision++;
        });
      }
      return current;
    };
    const source = {
      value: computed(() => {
        void state.revision;
        return current;
      }),
      get connected() {
        return stop !== void 0;
      },
      get disposed() {
        return disposed;
      },
      snapshot: () => current,
      refresh,
      connect() {
        if (disposed)
          throw new Error("Cannot reconnect a disposed external source");
        if (stop)
          return source.dispose;
        refresh();
        const unsubscribe = options.subscribe(refresh);
        if (typeof unsubscribe !== "function")
          throw new TypeError("External source subscribe must return an unsubscribe function");
        let active = true;
        stop = () => {
          if (!active)
            return;
          active = false;
          unsubscribe();
        };
        refresh();
        return source.dispose;
      },
      dispose() {
        if (disposed)
          return;
        disposed = true;
        if (ownerScope)
          releaseEffectScopeCleanup(ownerScope, source.dispose);
        const unsubscribe = stop;
        stop = void 0;
        unsubscribe?.();
      }
    };
    if (ownerScope)
      registerEffectScopeCleanup(ownerScope, source.dispose);
    if (options.connect ?? !serverSnapshot)
      source.connect();
    return Object.freeze(source);
  }
  function createSelectedExternalSource(options) {
    return createExternalSource({
      getSnapshot: () => options.selector(options.getSnapshot()),
      subscribe: options.subscribe,
      ...options.getServerSnapshot ? { getServerSnapshot: () => options.selector(options.getServerSnapshot()) } : {},
      isEqual: options.isEqual,
      connect: options.connect
    });
  }

  // packages/reactive/dist/proxy/collections.js
  var iterateDependency = /* @__PURE__ */ Symbol("exact.collection.iterate");
  var sizeDependency = /* @__PURE__ */ Symbol("exact.collection.size");
  var keyDependencies = /* @__PURE__ */ new WeakMap();
  function reactiveCollectionMember(target, key, receiver, options, wrap) {
    if (key === "size") {
      track(target, sizeDependency);
      return target.size;
    }
    if (target instanceof Map)
      return reactiveMapMember(target, key, receiver, options, wrap);
    return reactiveSetMember(target, key, receiver, options, wrap);
  }
  function reactiveMapMember(target, key, receiver, options, wrap) {
    switch (key) {
      case "get":
        return (input) => {
          const rawKey = unwrap(input);
          const dependency = collectionKeyDependency(target, rawKey);
          track(target, dependency);
          return wrap(target.get(rawKey), dependency);
        };
      case "has":
        return (input) => {
          const rawKey = unwrap(input);
          track(target, collectionKeyDependency(target, rawKey));
          return target.has(rawKey);
        };
      case "set":
        return (input, value) => {
          assertWritable(options, "set");
          const rawKey = unwrap(input);
          const rawValue = unwrap(value);
          const had = target.has(rawKey);
          const previous = target.get(rawKey);
          if (had && !hasChanged2(previous, rawValue))
            return receiver;
          recordMapUndo(target, rawKey, had, previous);
          target.set(rawKey, rawValue);
          trigger(target, collectionKeyDependency(target, rawKey));
          trigger(target, iterateDependency);
          if (!had)
            trigger(target, sizeDependency);
          notifyMutation3(options, rawKey, "map.set");
          return receiver;
        };
      case "delete":
        return (input) => {
          assertWritable(options, "delete");
          const rawKey = unwrap(input);
          if (!target.has(rawKey))
            return false;
          const previous = target.get(rawKey);
          if (hasActiveTransaction()) {
            const following = followingCollectionKeys(target.keys(), rawKey);
            recordTransactionUndo(() => {
              if (!following.size) {
                target.set(rawKey, previous);
                return;
              }
              const entries = [...target.entries()];
              const before = entries.findIndex(([key2]) => following.has(key2));
              entries.splice(before < 0 ? entries.length : before, 0, [rawKey, previous]);
              restoreMap(target, entries);
            }, target, collectionKeyDependency(target, rawKey));
          }
          const deleted = target.delete(rawKey);
          if (deleted) {
            triggerCollectionRemoval(target, rawKey);
            notifyMutation3(options, rawKey, "map.delete");
          }
          return deleted;
        };
      case "clear":
        return () => {
          assertWritable(options, "clear");
          if (!target.size)
            return void 0;
          const previous = [...target.entries()];
          if (hasActiveTransaction())
            recordTransactionUndo(() => restoreMap(target, previous), target, iterateDependency);
          target.clear();
          for (const [entryKey] of previous)
            trigger(target, collectionKeyDependency(target, entryKey));
          trigger(target, iterateDependency);
          trigger(target, sizeDependency);
          notifyMutation3(options, void 0, "map.clear");
          return void 0;
        };
      case "keys":
        return () => mapIterator(target, "keys", wrap);
      case "values":
        return () => mapIterator(target, "values", wrap);
      case "entries":
      case Symbol.iterator:
        return () => mapIterator(target, "entries", wrap);
      case "forEach":
        return (callback, thisArg) => {
          track(target, iterateDependency);
          target.forEach((value, entryKey) => {
            const dependency = collectionKeyDependency(target, entryKey);
            callback.call(thisArg, wrap(value, dependency), wrap(entryKey), receiver);
          });
        };
      default:
        return Reflect.get(target, key, target);
    }
  }
  function reactiveSetMember(target, key, receiver, options, wrap) {
    switch (key) {
      case "has":
        return (input) => {
          const rawValue = unwrap(input);
          track(target, collectionKeyDependency(target, rawValue));
          return target.has(rawValue);
        };
      case "add":
        return (input) => {
          assertWritable(options, "add");
          const rawValue = unwrap(input);
          if (target.has(rawValue))
            return receiver;
          if (hasActiveTransaction())
            recordTransactionUndo(() => target.delete(rawValue), target, collectionKeyDependency(target, rawValue));
          target.add(rawValue);
          trigger(target, collectionKeyDependency(target, rawValue));
          trigger(target, iterateDependency);
          trigger(target, sizeDependency);
          notifyMutation3(options, void 0, "set.add");
          return receiver;
        };
      case "delete":
        return (input) => {
          assertWritable(options, "delete");
          const rawValue = unwrap(input);
          if (!target.has(rawValue))
            return false;
          if (hasActiveTransaction()) {
            const following = followingCollectionKeys(target.values(), rawValue);
            recordTransactionUndo(() => {
              if (!following.size) {
                target.add(rawValue);
                return;
              }
              const values = [...target.values()];
              const before = values.findIndex((value) => following.has(value));
              values.splice(before < 0 ? values.length : before, 0, rawValue);
              restoreSet(target, values);
            }, target, collectionKeyDependency(target, rawValue));
          }
          const deleted = target.delete(rawValue);
          if (deleted) {
            triggerCollectionRemoval(target, rawValue);
            notifyMutation3(options, void 0, "set.delete");
          }
          return deleted;
        };
      case "clear":
        return () => {
          assertWritable(options, "clear");
          if (!target.size)
            return void 0;
          const previous = [...target.values()];
          if (hasActiveTransaction())
            recordTransactionUndo(() => restoreSet(target, previous), target, iterateDependency);
          target.clear();
          for (const value of previous)
            trigger(target, collectionKeyDependency(target, value));
          trigger(target, iterateDependency);
          trigger(target, sizeDependency);
          notifyMutation3(options, void 0, "set.clear");
          return void 0;
        };
      case "keys":
      case "values":
      case Symbol.iterator:
        return () => setIterator(target, wrap);
      case "entries":
        return () => setEntryIterator(target, wrap);
      case "forEach":
        return (callback, thisArg) => {
          track(target, iterateDependency);
          target.forEach((value) => {
            const wrapped = wrap(value);
            callback.call(thisArg, wrapped, wrapped, receiver);
          });
        };
      default:
        return Reflect.get(target, key, target);
    }
  }
  function mapIterator(target, kind, wrap) {
    track(target, iterateDependency);
    const iterator = target[kind]();
    return wrapIterator(iterator, (value) => {
      if (kind === "keys")
        return wrap(value);
      if (kind === "values")
        return wrap(value);
      const [entryKey, entryValue] = value;
      return [wrap(entryKey), wrap(entryValue, collectionKeyDependency(target, entryKey))];
    });
  }
  function setIterator(target, wrap) {
    track(target, iterateDependency);
    return wrapIterator(target.values(), (value) => wrap(value));
  }
  function setEntryIterator(target, wrap) {
    track(target, iterateDependency);
    return wrapIterator(target.values(), (value) => {
      const wrapped = wrap(value);
      return [wrapped, wrapped];
    });
  }
  function wrapIterator(iterator, wrap) {
    return {
      next() {
        const result = iterator.next();
        return result.done ? { done: true, value: void 0 } : { done: false, value: wrap(result.value) };
      },
      [Symbol.iterator]() {
        return this;
      }
    };
  }
  function collectionKeyDependency(target, key) {
    let dependencies = keyDependencies.get(target);
    if (!dependencies)
      keyDependencies.set(target, dependencies = { primitives: /* @__PURE__ */ new Map(), objects: /* @__PURE__ */ new WeakMap() });
    const objectKey = key !== null && (typeof key === "object" || typeof key === "function");
    const keys = objectKey ? dependencies.objects : dependencies.primitives;
    let dependency = keys.get(key);
    if (!dependency) {
      dependency = /* @__PURE__ */ Symbol("exact.collection.key");
      keys.set(key, dependency);
    }
    return dependency;
  }
  function triggerCollectionRemoval(target, value) {
    trigger(target, collectionKeyDependency(target, value));
    trigger(target, iterateDependency);
    trigger(target, sizeDependency);
  }
  function recordMapUndo(target, key, had, previous) {
    if (!hasActiveTransaction())
      return;
    recordTransactionUndo(() => {
      if (had)
        target.set(key, previous);
      else
        target.delete(key);
    }, target, collectionKeyDependency(target, key));
  }
  function restoreMap(target, entries) {
    target.clear();
    for (const [key, value] of entries)
      target.set(key, value);
  }
  function restoreSet(target, values) {
    target.clear();
    for (const value of values)
      target.add(value);
  }
  function assertWritable(options, operation) {
    if (!options.readonly)
      return;
    options.onReadonlyWrite?.(operation);
    throw new TypeError(`Cannot call ${operation} on a readonly reactive collection`);
  }
  function notifyMutation3(options, key, operation) {
    const propertyKey = typeof key === "string" || typeof key === "number" || typeof key === "symbol" ? key : void 0;
    try {
      options.onMutation?.(propertyKey, operation);
    } catch {
    }
  }
  function followingCollectionKeys(keys, removed) {
    const following = /* @__PURE__ */ new Set();
    let found = false;
    for (const key of keys) {
      if (found)
        following.add(key);
      else if (key === removed || Object.is(key, removed))
        found = true;
    }
    return following;
  }

  // packages/reactive/dist/proxy/create.js
  var collectionOptions = /* @__PURE__ */ new WeakMap();
  function createReactive(value, options, parentSource) {
    const key = collectionOptionsKey(options);
    let selected = collectionOptions.get(key);
    if (!selected) {
      const created = Object.assign(Object.create(key), {
        __exactCollectionCacheMode: true
      });
      collectionOptions.set(key, created);
      selected = created;
    }
    return createReactiveBase(value, selected, parentSource, reactiveCollectionMember);
  }
  function collectionOptionsKey(options) {
    if (!options.readonly && !options.onReadonlyWrite && !options.onMutation && !options.passthroughKeys?.length)
      return defaultReactiveOptions;
    if (options.readonly && !options.onReadonlyWrite && !options.onMutation && !options.passthroughKeys?.length)
      return readonlyReactiveOptionsKey;
    return options;
  }

  // packages/reactive/dist/reactive.js
  function reactive(value, options = defaultReactiveOptions, parentSource) {
    if (!isReactiveContainer(unwrap(value)))
      return value;
    return createReactive(value, options, parentSource);
  }

  // packages/reactive/dist/indexed-layout.js
  var indexedLayouts = /* @__PURE__ */ new WeakMap();
  function indexedLayout(keys) {
    const identity = keys;
    const cached = indexedLayouts.get(identity);
    if (cached)
      return cached;
    const indexes = /* @__PURE__ */ new Map();
    const uniqueKeys = [];
    for (const key of keys) {
      if (indexes.has(key))
        continue;
      indexes.set(key, indexes.size);
      uniqueKeys.push(key);
    }
    const layout = { indexes, keys: uniqueKeys };
    indexedLayouts.set(identity, layout);
    return layout;
  }

  // packages/reactive/dist/reactive-record-slots.js
  function indexedRecordIndex(record, key) {
    return record.layout.indexes.get(key) ?? record.dynamicIndexes?.get(key);
  }
  function ensureIndexedRecordIndex(record, key) {
    const existing = indexedRecordIndex(record, key);
    if (existing !== void 0)
      return existing;
    const dynamicIndexes = record.dynamicIndexes ??= /* @__PURE__ */ new Map();
    const dynamicKeys = record.dynamicKeys ??= [];
    const index = record.layout.keys.length + dynamicIndexes.size;
    dynamicIndexes.set(key, index);
    dynamicKeys.push(key);
    record.initialized.push(false);
    return index;
  }
  function indexedRecordKey(record, index) {
    if (index < record.layout.keys.length)
      return record.layout.keys[index];
    return record.dynamicKeys[index - record.layout.keys.length];
  }

  // packages/reactive/dist/indexed-base.js
  var compiledReactivePropertyOperand = /* @__PURE__ */ Symbol.for("exact.reactive.property-operand");
  var indexedRecords = /* @__PURE__ */ new WeakMap();
  var indexedProxyHandler = {
    get(target, key, receiver) {
      if (key === proxyMarker)
        return true;
      if (key === rawTarget)
        return target;
      const { record } = this;
      const index = indexedRecordIndex(record, key);
      return index === void 0 ? Reflect.get(target, key, receiver) : readIndexedValue(record, key, index, "facade");
    },
    set(_target, key, next) {
      const { record } = this;
      if (record.options.readonly) {
        record.options.onReadonlyWrite?.(key);
        return false;
      }
      const index = ensureIndexedRecordIndex(record, key);
      return writeIndexedRecord(record, index, next);
    },
    deleteProperty(target, key) {
      const { record } = this;
      const index = indexedRecordIndex(record, key);
      return index === void 0 ? Reflect.deleteProperty(target, key) : deleteIndexedRecord(record, index);
    },
    has(target, key) {
      const { record } = this;
      const index = indexedRecordIndex(record, key);
      return index !== void 0 && record.initialized[index] === true || Reflect.has(target, key);
    }
  };
  function createIndexedReactive(keys, options, wrap, initial, preserveReactiveValues = false) {
    const layout = indexedLayout(keys);
    const target = {};
    const initialized = new Array(layout.keys.length).fill(false);
    const record = {
      layout,
      initialized,
      target,
      options,
      wrap,
      preserveReactiveValues
    };
    if (initial)
      seedIndexedRecord(record, initial);
    const handler = Object.create(indexedProxyHandler);
    handler.record = record;
    const facade = new Proxy(target, handler);
    indexedRecords.set(facade, record);
    return facade;
  }
  function updateIndexedReactive(value, next, reconcileNested) {
    const indexed = indexedRecords.get(value);
    if (!indexed)
      return false;
    batch(() => {
      for (const key of Reflect.ownKeys(indexed.target)) {
        if (Object.prototype.hasOwnProperty.call(next, key))
          continue;
        const index = indexedRecordIndex(indexed, key);
        if (index !== void 0)
          deleteIndexedRecord(indexed, index);
      }
      for (const key of Reflect.ownKeys(next)) {
        const incoming = Reflect.get(next, key);
        const index = ensureIndexedRecordIndex(indexed, key);
        if (indexed.initialized[index] && reconcileNested(indexed.target[key], incoming))
          continue;
        writeIndexedRecord(indexed, index, incoming);
      }
    });
    return true;
  }
  function readReactiveOwnPropertyInto(value, key, cell) {
    const indexed = indexedRecords.get(value);
    if (indexed) {
      const index = indexedRecordIndex(indexed, key);
      if (index !== void 0 && indexed.initialized[index]) {
        cell.value = indexed.target[key];
        return true;
      }
      cell.value = void 0;
      return false;
    }
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (descriptor && "value" in descriptor) {
      cell.value = descriptor.value;
      return true;
    }
    cell.value = void 0;
    return false;
  }
  function readReactiveOwnProperty(value, key) {
    const cell = { value: void 0 };
    return readReactiveOwnPropertyInto(value, key, cell) ? { present: true, value: cell.value } : { present: false };
  }
  function writeIndexedRecord(indexed, index, next) {
    const key = indexedRecordKey(indexed, index);
    const previous = indexed.target[key];
    const raw = retainedIndexedValue(indexed, key, next);
    const value = !indexed.options.passthroughKeys?.includes(key) && !(Array.isArray(raw) && raw[0] === compiledReactivePropertyOperand) && !isReactiveValue(raw) && raw && typeof raw === "object" && isReactiveContainer(raw) ? indexed.wrap(raw, indexed.options, indexedParentSource(indexed, index)) : raw;
    const wasInitialized = indexed.initialized[index] === true;
    if (wasInitialized && !hasChanged2(previous, value))
      return true;
    if (hasActiveTransaction())
      recordTransactionUndo(() => {
        if (wasInitialized)
          indexed.target[key] = previous;
        if (!wasInitialized) {
          indexed.initialized[index] = false;
          Reflect.deleteProperty(indexed.target, key);
        }
      }, indexed.target, index);
    Reflect.defineProperty(indexed.target, key, {
      configurable: true,
      enumerable: true,
      value,
      writable: true
    });
    indexed.initialized[index] = true;
    trigger(indexed.target, index);
    try {
      indexed.options.onMutation?.(key, "set");
    } catch {
    }
    return true;
  }
  function seedIndexedRecord(indexed, initial) {
    for (const key of Reflect.ownKeys(initial)) {
      const index = ensureIndexedRecordIndex(indexed, key);
      const raw = retainedIndexedValue(indexed, key, Reflect.get(initial, key));
      indexed.target[key] = !indexed.options.passthroughKeys?.includes(key) && !(Array.isArray(raw) && raw[0] === compiledReactivePropertyOperand) && !isReactiveValue(raw) && raw && typeof raw === "object" && isReactiveContainer(raw) ? indexed.wrap(raw, indexed.options, indexedParentSource(indexed, index)) : raw;
      indexed.initialized[index] = true;
    }
  }
  function retainedIndexedValue(indexed, key, value) {
    if (indexed.options.passthroughKeys?.includes(key))
      return value;
    if (indexed.preserveReactiveValues && isReactiveValue(value))
      return value;
    return unwrap(value);
  }
  function readIndexedValue(indexed, key, index, mode) {
    const current = indexed.target[key];
    if (indexed.options.passthroughKeys?.includes(key)) {
      if (mode !== "peek")
        track(indexed.target, index);
      return current;
    }
    const propertyOperand = indexed.preserveReactiveValues && Array.isArray(current) && current[0] === compiledReactivePropertyOperand ? current : void 0;
    const value = propertyOperand ? Reflect.get(propertyOperand[1], propertyOperand[2]) : indexed.preserveReactiveValues && isReactiveValue(current) ? current.get() : current;
    const raw = unwrap(value);
    if (raw && typeof raw === "object" && isReactiveContainer(raw)) {
      if (mode === "direct")
        track(indexed.target, index);
      return indexed.wrap(raw, indexed.options, indexedParentSource(indexed, index));
    }
    if (mode !== "peek")
      track(indexed.target, index);
    return raw;
  }
  function indexedParentSource(indexed, index) {
    const sources = indexed.sources ??= [];
    const existing = sources[index];
    if (existing)
      return existing;
    const source = {
      target: indexed.target,
      key: index,
      get() {
        return readIndexedValue(indexed, indexedRecordKey(indexed, index), index, "direct");
      },
      set(value) {
        writeIndexedRecord(indexed, index, value);
      }
    };
    sources[index] = source;
    return source;
  }
  function deleteIndexedRecord(indexed, index) {
    const key = indexedRecordKey(indexed, index);
    if (indexed.initialized[index]) {
      const previous = indexed.target[key];
      if (hasActiveTransaction())
        recordTransactionUndo(() => {
          Reflect.defineProperty(indexed.target, key, {
            configurable: true,
            enumerable: true,
            value: previous,
            writable: true
          });
          indexed.initialized[index] = true;
        }, indexed.target, index);
      trigger(indexed.target, index);
    }
    indexed.initialized[index] = false;
    return Reflect.deleteProperty(indexed.target, key);
  }

  // packages/reactive/dist/indexed.js
  function indexedReactive(keys, options = {}) {
    return createIndexedReactive(keys, options, reactive);
  }

  // packages/reactive/dist/snapshot.js
  function snapshot(value) {
    const root = unwrap(value);
    if (!isSnapshotContainer(root))
      return root;
    const output = createSnapshotContainer(root);
    const seen = new WeakMap([[root, output]]);
    const pending = [{ source: root, target: output }];
    while (pending.length) {
      const { source, target } = pending.pop();
      if (source instanceof Map) {
        const targetMap = target;
        for (const [key, child] of source)
          targetMap.set(key, snapshotChild(child, seen, pending));
        continue;
      }
      if (source instanceof Set) {
        const targetSet = target;
        for (const child of source)
          targetSet.add(snapshotChild(child, seen, pending));
        continue;
      }
      if (Array.isArray(source))
        target.length = source.length;
      const keys = Array.isArray(source) ? Array.from({ length: source.length }, (_, index) => index).filter((index) => Reflect.has(source, index)) : Reflect.ownKeys(source);
      for (const key of keys)
        defineSnapshotProperty(target, key, snapshotChild(Reflect.get(source, key), seen, pending));
    }
    return output;
  }
  function snapshotChild(value, seen, pending) {
    const child = unwrap(value);
    if (!isSnapshotContainer(child))
      return child;
    const prior = seen.get(child);
    if (prior)
      return prior;
    const clone = createSnapshotContainer(child);
    seen.set(child, clone);
    pending.push({ source: child, target: clone });
    return clone;
  }
  function isSnapshotContainer(value) {
    return !!value && typeof value === "object" && (Array.isArray(value) || value instanceof Map || value instanceof Set || isPlainObject(value));
  }
  function createSnapshotContainer(value) {
    if (Array.isArray(value))
      return [];
    if (value instanceof Map)
      return /* @__PURE__ */ new Map();
    if (value instanceof Set)
      return /* @__PURE__ */ new Set();
    return Object.create(Object.getPrototypeOf(value));
  }
  function defineSnapshotProperty(target, key, value) {
    Object.defineProperty(target, key, {
      value,
      writable: true,
      enumerable: true,
      configurable: true
    });
  }

  // packages/reactive/dist/protocol.js
  function encodeReactiveProtocolValue(value) {
    return encodeReactiveProtocolValueInternal(unwrap(value), (collection) => listKeyExtractors.get(collection)?.key);
  }
  function decodeReactiveProtocolValue(value) {
    return decodeReactiveProtocolValueInternal(value);
  }

  // packages/reactive/dist/reconciliation.js
  function updateReactive(target, next) {
    updateReactiveProperties(target, next, true);
  }
  function updateReactiveProperties(target, next, reconcileNested) {
    if (updateIndexedReactive(target, next, (previous, value) => {
      if (!reconcileNested || !canUpdateNestedReactive(previous, value))
        return false;
      updateReactive(previous, unwrap(value));
      return true;
    }))
      return;
    const raw = isReactive(target) ? target[rawTarget] : target;
    const nextRecord = next;
    batch(() => {
      for (const key of Reflect.ownKeys(raw)) {
        if (!Object.prototype.hasOwnProperty.call(nextRecord, key)) {
          const hadKey = Object.prototype.hasOwnProperty.call(raw, key);
          if (hadKey) {
            recordPropertyUndo(raw, key);
            Reflect.deleteProperty(raw, key);
            markReactiveHashDirty(raw);
            trigger(raw, key);
            trigger(raw, iterateKey);
          }
        }
      }
      for (const key of Reflect.ownKeys(next)) {
        const previous = Reflect.get(raw, key);
        const value = Reflect.get(next, key);
        const hadKey = Object.prototype.hasOwnProperty.call(raw, key);
        if (reconcileNested && canUpdateNestedReactive(previous, value)) {
          updateReactive(previous, unwrap(value));
          continue;
        }
        if (!reactiveValueChanged(previous, value) && !hasChanged2(previous, value))
          continue;
        recordPropertyUndo(raw, key);
        Reflect.set(raw, key, value);
        markReactiveHashDirty(raw);
        trigger(raw, key);
        if (!hadKey || isArrayStructureKey(raw, key))
          trigger(raw, iterateKey);
      }
    });
  }
  function canUpdateNestedReactive(previous, next) {
    const unwrappedPrevious = unwrap(previous);
    const unwrappedNext = unwrap(next);
    if (Object.is(unwrappedPrevious, unwrappedNext))
      return false;
    return (isReactive(previous) || !!unwrappedPrevious && typeof unwrappedPrevious === "object" && reactiveRawObjects.has(unwrappedPrevious)) && isPlainObject(unwrappedPrevious) && isPlainObject(unwrappedNext);
  }
  function resolveReactivePath(target, path) {
    let parent = target;
    for (let index = 0; index < path.length - 1; index++) {
      const next = parent[path[index]];
      if (!next || typeof next !== "object")
        throw new TypeError(`Cannot resolve reactive state path ${path.join(".")}`);
      parent = next;
    }
    return { parent, key: path[path.length - 1] };
  }
  function reconcileReactiveValue(previous, next, seen, depth = 0) {
    if (depth > 100)
      return false;
    const oldValue = unwrap(previous);
    const nextValue = unwrap(next);
    if (Object.is(oldValue, nextValue))
      return true;
    if (!oldValue || !nextValue || typeof oldValue !== "object" || typeof nextValue !== "object")
      return false;
    const compatible = Array.isArray(oldValue) && Array.isArray(nextValue) ? Object.getPrototypeOf(oldValue) === Object.getPrototypeOf(nextValue) && canReconcileStructure(oldValue) && canReadStructure(nextValue) : isPlainObject(oldValue) && isPlainObject(nextValue) && Object.getPrototypeOf(oldValue) === Object.getPrototypeOf(nextValue) && canReconcileStructure(oldValue) && canReadStructure(nextValue);
    if (!compatible)
      return false;
    const priorNext = seen.oldToNext.get(oldValue);
    const priorOld = seen.nextToOld.get(nextValue);
    if (priorNext || priorOld)
      return priorNext === nextValue && priorOld === oldValue;
    seen.oldToNext.set(oldValue, nextValue);
    seen.nextToOld.set(nextValue, oldValue);
    const current = previous;
    if (Array.isArray(oldValue) && Array.isArray(nextValue)) {
      const registration = listKeyExtractors.get(oldValue);
      if (registration)
        return reconcileKeyedArray(current, oldValue, nextValue, registration.key, seen, depth);
      const oldLength = oldValue.length;
      const previousItems = Array.from({ length: oldLength }, (_, index) => Object.prototype.hasOwnProperty.call(current, index) ? current[index] : arrayHole);
      const existingByIdentity = /* @__PURE__ */ new WeakMap();
      for (const item of previousItems) {
        const identity = structuredIdentity(item);
        if (identity)
          existingByIdentity.set(identity, item);
      }
      const retainedIdentities = /* @__PURE__ */ new WeakSet();
      for (const incoming of nextValue) {
        const identity = structuredIdentity(incoming);
        if (identity && existingByIdentity.has(identity))
          retainedIdentities.add(identity);
      }
      const nextItems = nextValue.map((incoming, index) => {
        const incomingIdentity = structuredIdentity(incoming);
        const retained = incomingIdentity ? existingByIdentity.get(incomingIdentity) : void 0;
        if (retained !== void 0)
          return retained;
        const previousItem = previousItems[index];
        if (previousItem === arrayHole)
          return incoming;
        const previousIdentity = structuredIdentity(previousItem);
        if (previousIdentity && retainedIdentities.has(previousIdentity))
          return incoming;
        return previousItem !== void 0 && reconcileReactiveValue(previousItem, incoming, seen, depth + 1) ? previousItem : incoming;
      });
      reconcileArrayItems(current, oldLength, nextItems);
      reconcileArrayProperties(current, oldValue, nextValue, seen, depth);
      return true;
    }
    const nextRecord = nextValue;
    for (const key of Reflect.ownKeys(oldValue)) {
      if (!Object.prototype.hasOwnProperty.call(nextRecord, key))
        Reflect.deleteProperty(current, key);
    }
    for (const key of Reflect.ownKeys(nextRecord)) {
      const nextDescriptor = Reflect.getOwnPropertyDescriptor(nextRecord, key);
      const oldDescriptor = Reflect.getOwnPropertyDescriptor(oldValue, key);
      if (!("value" in nextDescriptor))
        return false;
      if (!oldDescriptor || !("value" in oldDescriptor) || !reconcileReactiveValue(current[key], nextDescriptor.value, seen, depth + 1)) {
        Reflect.defineProperty(current, key, {
          ...nextDescriptor,
          value: unwrap(nextDescriptor.value)
        });
      }
    }
    return true;
  }
  var arrayHole = /* @__PURE__ */ Symbol("exact.array-hole");
  function createReconcilePairs() {
    return { oldToNext: /* @__PURE__ */ new WeakMap(), nextToOld: /* @__PURE__ */ new WeakMap() };
  }
  function reconcileArrayProperties(current, oldValue, nextValue, seen, depth) {
    const isExtra = (key) => key !== "length" && !(typeof key === "string" && /^(0|[1-9]\d*)$/.test(key));
    for (const key of Reflect.ownKeys(oldValue)) {
      if (isExtra(key) && !Object.prototype.hasOwnProperty.call(nextValue, key))
        Reflect.deleteProperty(current, key);
    }
    for (const key of Reflect.ownKeys(nextValue)) {
      if (!isExtra(key))
        continue;
      const nextDescriptor = Reflect.getOwnPropertyDescriptor(nextValue, key);
      const oldDescriptor = Reflect.getOwnPropertyDescriptor(oldValue, key);
      if (!("value" in nextDescriptor))
        continue;
      if (!oldDescriptor || !("value" in oldDescriptor) || !reconcileReactiveValue(current[key], nextDescriptor.value, seen, depth + 1)) {
        Reflect.defineProperty(current, key, {
          ...nextDescriptor,
          value: unwrap(nextDescriptor.value)
        });
      }
    }
  }
  function reconcileKeyedArray(current, oldValue, nextValue, key, seen, depth) {
    const previousMetadata = keyedCollectionMetadata(oldValue, key);
    const incomingMetadata = keyedCollectionMetadata(nextValue);
    if (previousMetadata && incomingMetadata && previousMetadata.itemsHash === incomingMetadata.itemsHash)
      return true;
    if (previousMetadata && incomingMetadata && previousMetadata.keyHash === incomingMetadata.keyHash) {
      const changedKeys2 = /* @__PURE__ */ new Set();
      for (let index = 0; index < nextValue.length; index++) {
        if (previousMetadata.itemHashes[index] === incomingMetadata.itemHashes[index])
          continue;
        const id = incomingMetadata.keys[index];
        changedKeys2.add(id);
        if (!reconcileReactiveValue(current[index], nextValue[index], seen, depth + 1))
          current[index] = nextValue[index];
      }
      adoptKeyedCollectionMetadata(oldValue, incomingMetadata, changedKeys2);
      return true;
    }
    const existing = /* @__PURE__ */ new Map();
    for (let index = 0; index < oldValue.length; index++) {
      const id = String(key(oldValue[index]));
      if (existing.has(id))
        throw new Error(`Duplicate key "${id}" in the current keyed reactive array`);
      existing.set(id, { item: current[index], index });
    }
    const incomingEntries = nextValue.map((incoming) => ({ id: String(key(incoming)), incoming }));
    const keys = /* @__PURE__ */ new Set();
    for (const { id } of incomingEntries) {
      if (keys.has(id))
        throw new Error(`Duplicate key "${id}" in the next keyed reactive array`);
      keys.add(id);
    }
    const nextItems = [];
    const changedKeys = /* @__PURE__ */ new Set();
    for (let index = 0; index < incomingEntries.length; index++) {
      const { id, incoming } = incomingEntries[index];
      const previousEntry = existing.get(id);
      const hashesMatch = previousEntry !== void 0 && previousMetadata !== void 0 && incomingMetadata !== void 0 && previousMetadata.itemHashes[previousEntry.index] === incomingMetadata.itemHashes[index];
      if (hashesMatch)
        nextItems.push(previousEntry.item);
      else if (previousEntry !== void 0 && reconcileReactiveValue(previousEntry.item, incoming, seen, depth + 1)) {
        changedKeys.add(id);
        nextItems.push(previousEntry.item);
      } else {
        if (previousEntry !== void 0)
          changedKeys.add(id);
        nextItems.push(incoming);
      }
    }
    reconcileArrayItems(current, oldValue.length, nextItems);
    if (incomingMetadata)
      adoptKeyedCollectionMetadata(oldValue, incomingMetadata, changedKeys);
    else
      seedKeyedCollectionMetadata(oldValue, key);
    return true;
  }
  function structuredIdentity(value) {
    const identity = unwrap(value);
    return identity && typeof identity === "object" ? identity : void 0;
  }
  function reconcileArrayItems(current, oldLength, nextItems) {
    const target = unwrap(current);
    recordArrayUndo(target);
    const changedIndexes = /* @__PURE__ */ new Set();
    for (let index = 0; index < nextItems.length; index++) {
      if (!Reflect.has(nextItems, index)) {
        if (Reflect.has(target, index)) {
          Reflect.deleteProperty(target, index);
          changedIndexes.add(index);
        }
        continue;
      }
      const next = unwrap(nextItems[index]);
      if (Object.is(unwrap(target[index]), next))
        continue;
      Reflect.set(target, index, next);
      changedIndexes.add(index);
    }
    if (nextItems.length < oldLength) {
      for (let index = oldLength - 1; index >= nextItems.length; index--) {
        if (Reflect.has(target, index))
          changedIndexes.add(index);
        Reflect.deleteProperty(target, index);
      }
    }
    if (target.length !== nextItems.length)
      target.length = nextItems.length;
    for (const index of changedIndexes)
      trigger(target, String(index));
    if (oldLength !== nextItems.length)
      trigger(target, "length");
    if (changedIndexes.size || oldLength !== nextItems.length)
      trigger(target, iterateKey);
  }
  function canReconcileStructure(value) {
    if (!Object.isExtensible(value))
      return false;
    return Reflect.ownKeys(value).every((key) => {
      if (Array.isArray(value) && key === "length")
        return true;
      const descriptor = Reflect.getOwnPropertyDescriptor(value, key);
      return !!descriptor && "value" in descriptor && descriptor.writable !== false && descriptor.configurable !== false;
    });
  }
  function canReadStructure(value) {
    return Reflect.ownKeys(value).every((key) => {
      if (Array.isArray(value) && key === "length")
        return true;
      const descriptor = Reflect.getOwnPropertyDescriptor(value, key);
      return !!descriptor && "value" in descriptor;
    });
  }

  // packages/reactive/dist/writes.js
  function writeReactive(target, path, next) {
    if (!path.length)
      throw new TypeError("writeReactive requires a state path");
    const { parent, key } = resolveReactivePath(target, path);
    commitReactiveWrite(parent, key, next);
    return next;
  }
  function writeReactiveLazy(target, path, evaluate) {
    if (!path.length)
      throw new TypeError("writeReactiveLazy requires a state path");
    const { parent, key } = resolveReactivePath(target, path);
    const next = evaluate();
    commitReactiveWrite(parent, key, next);
    return next;
  }
  function commitReactiveWrite(parent, key, next) {
    batch(() => {
      const previous = Reflect.get(parent, key);
      if (reconcileReactiveValue(previous, next, createReconcilePairs()))
        return;
      if (!Object.is(unwrap(previous), unwrap(next)))
        Reflect.set(parent, key, next);
    });
  }
  function updateReactiveValue(target, path, operation, returnPrevious = false) {
    const { parent, key } = resolveReactivePath(target, path);
    const previous = Reflect.get(parent, key);
    const next = operation(previous);
    commitReactiveWrite(parent, key, next);
    return returnPrevious ? previous : next;
  }
  function updateReactiveValueWithResult(target, path, operation) {
    const { parent, key } = resolveReactivePath(target, path);
    const previous = Reflect.get(parent, key);
    const [next, result] = operation(previous);
    commitReactiveWrite(parent, key, next);
    return result;
  }
  function deleteReactiveValue(target, path) {
    if (!path.length)
      return false;
    const { parent, key } = resolveReactivePath(target, path);
    return Reflect.deleteProperty(parent, key);
  }
  function mutateReactiveArray(target, path, method, args) {
    const { parent, key } = resolveReactivePath(target, path);
    const value = Reflect.get(parent, key);
    if (!Array.isArray(value))
      throw new TypeError(`Cannot call ${method} on a non-array reactive value`);
    const mutation = value[method];
    const input = typeof args === "function" ? args() : args;
    return mutation.apply(value, input);
  }
  function mutateReactiveCollection(target, path, kind, method, args) {
    const { parent, key } = resolveReactivePath(target, path);
    const value = Reflect.get(parent, key);
    if (kind === "map" && !(unwrap(value) instanceof Map) || kind === "set" && !(unwrap(value) instanceof Set)) {
      throw new TypeError(`Cannot call ${method} on a non-${kind} reactive value`);
    }
    const mutation = Reflect.get(value, method);
    const input = typeof args === "function" ? args() : args;
    return mutation.apply(value, input);
  }
  function registerReactiveListKey(collection, key, site = "an unlabelled this.map() call", identity) {
    if (!collection || typeof collection !== "object")
      return () => void 0;
    const raw = unwrap(collection);
    if (!Array.isArray(raw))
      return () => void 0;
    const signature = identity ? `compiler:${identity}` : `runtime:${Function.prototype.toString.call(key)}`;
    const previous = listKeyExtractors.get(raw);
    if (previous && previous.signature !== signature) {
      throw conflictingListKeyError(previous.site, site);
    }
    if (previous && !identity) {
      for (const item of raw) {
        if (String(previous.key(item)) !== String(key(item)))
          throw conflictingListKeyError(previous.site, site);
      }
    }
    if (previous) {
      previous.references++;
    } else {
      listKeyExtractors.set(raw, { key, signature, site, references: 1 });
    }
    let active = true;
    return () => {
      if (!active)
        return;
      active = false;
      const registration = listKeyExtractors.get(raw);
      if (!registration || registration.signature !== signature)
        return;
      if (--registration.references === 0) {
        listKeyExtractors.delete(raw);
        releaseKeyedCollectionMetadata(raw);
      }
    };
  }

  // <stdin>
  window.auditReactive = { ...dist_exports, structurallyEqual };
})();
