import {build} from 'esbuild';
import {readFile,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {chromium} from 'playwright';
import assert from 'node:assert/strict';
const root='.tmp/client-v8';const variants=['baseline','direct-source','lazy-equality','combined'];const bundles={};
for(const variant of variants){
 const result=await build({stdin:{contents:"import * as api from './packages/reactive/dist/index.js';import {structurallyEqual} from './packages/reactive/dist/internal/equality.js';window.auditReactive={...api,structurallyEqual};",resolveDir:process.cwd()},bundle:true,write:false,platform:'browser',format:'iife',define:{'process.env.NODE_ENV':'"production"'},plugins:[{name:'isolated-candidate',setup(b){b.onLoad({filter:/packages[\\/]reactive[\\/]dist[\\/](?:proxy[\\/]create-base|internal[\\/]equality)\.js$/},async args=>{
 let code=await readFile(args.path,'utf8');
 if((variant==='direct-source'||variant==='combined')&&args.path.includes('create-base')){
  assert.equal(code.split('proxySources.set(proxy, new Set([source]));').length,3);
  code=code.replaceAll('proxySources.set(proxy, new Set([source]));','').replace('for (const source of proxySources.get(proxy) ?? [])\n        track(source.target, source.key);','const source = proxyRefs.get(proxy);\n    if (source) track(source.target, source.key);');
 }
 if((variant==='lazy-equality'||variant==='combined')&&args.path.includes('equality')){
  code=code.replace('const leftToRight = new WeakMap();','if (Object.is(left, right)) return true;\n    let leftToRight;').replace('const rightToLeft = new WeakMap();','let rightToLeft;').replace('const priorRight = leftToRight.get(currentLeft);','leftToRight ??= new WeakMap();\n        rightToLeft ??= new WeakMap();\n        const priorRight = leftToRight.get(currentLeft);');
 }
 return {contents:code,loader:'js'};
 });}}]});
 bundles[variant]=result.outputFiles[0].text;await writeFile(`${root}/contracts-${variant}.js`,bundles[variant]);
}
const server=createServer((req,res)=>{res.setHeader('content-type','text/javascript');res.end(bundles[req.url.slice(1)]??'');});
await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;const results={};
try{
 browser=await chromium.launch();
 for(const variant of variants){const page=await browser.newPage();try{
  await page.addScriptTag({url:`http://127.0.0.1:${server.address().port}/${variant}`});
  results[variant]=await page.evaluate(()=>{
   const {reactive,watch,flushSync,ref,structurallyEqual}=window.auditReactive;
   const check=(v,message)=>{if(!v)throw Error(message);};const out={};
   const shared={value:1},state=reactive({left:shared,right:shared});const left=state.left,right=state.right;let l=0,r=0;
   const stopL=watch(()=>{left.value;l++;}),stopR=watch(()=>{right.value;r++;});
   state.left={value:2};flushSync();check(l===2&&r===1,'retained aliases changed');stopL();stopR();out.aliases=[l,r];
   const array=reactive({items:[{id:'a',value:1},{id:'b',value:2}]});const retained=array.items[0];array.items.reverse();check(array.items[1]===retained,'keyed move changed proxy identity');
   check(ref(array.items[1]).get()===retained,'moved ref changed');let observed=0;const stop=watch(()=>{array.items[1].value;observed++;});array.items[1].value=3;flushSync();check(observed===2,'moved item subscription changed');stop();out.move=observed;
   const cycle={value:1};cycle.self=cycle;const same={value:1};same.self=same;
   const getter=()=>1;const accessor=Object.defineProperty({},'a',{get:getter,enumerable:true});
   const values=[undefined,null,false,true,0,-0,NaN,Infinity,'','x',1,2,{},[],[undefined],new Array(1),Object.create(null),cycle,same,accessor,new Date(0),new Map(),()=>1,Symbol.for('probe')];
   out.equality=[];
   for(let i=0;i<values.length;i++)for(let j=0;j<values.length;j++){let calls=0;const result=structurallyEqual(values[i],values[j],v=>{calls++;return v;});out.equality.push([result,calls]);}
   check(structurallyEqual(cycle,same,v=>v),'cyclic equality changed');
   const alias={};check(!structurallyEqual([alias,alias],[{},{}],v=>v),'alias topology changed');
   check(!structurallyEqual(new Array(1),[undefined],v=>v),'sparse array changed');
   let reads=0;const a=Object.defineProperty({},'a',{get(){reads++;return 1;}});structurallyEqual(a,{},v=>v);check(reads===0,'equality invoked accessor');
   const x={a:1};const y=Object.defineProperty({},'a',{value:1,writable:false,enumerable:true,configurable:true});check(!structurallyEqual(x,y,v=>v),'descriptor changed');
   return out;
  });
 }finally{await page.close();}}
 for(const variant of variants)assert.deepEqual(results[variant],results.baseline,variant+' differed from baseline');
 await writeFile(root+'/contracts.json',JSON.stringify({browser:browser.version(),variants,equalityPairsPerVariant:576,aliasAndMoveChecks:true,descriptorCycleSparseAndAccessorChecks:true,results},null,2));
 console.log('All four browser variants agree on 576 equality pairs, unwrap call counts, aliases, keyed moves, descriptors, cycles, sparse arrays, and accessor checks');
}finally{try{await browser?.close();}finally{await new Promise(r=>server.close(r));}}
