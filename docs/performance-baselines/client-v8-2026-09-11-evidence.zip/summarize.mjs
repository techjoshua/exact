import {readFile,writeFile} from 'node:fs/promises';
import {TraceMap,originalPositionFor} from '@jridgewell/trace-mapping';
const root='.tmp/client-v8';
const artifacts=JSON.parse(await readFile(root+'/artifacts.json','utf8'));
const maps={};for(const id of ['exact','react'])maps[id]=new TraceMap(JSON.parse(await readFile(`${root}/${id}-mapped/assets/${artifacts[id][0].file}.map`,'utf8')));
function site(id,f){
 if(!f.url?.includes('/assets/'))return f.functionName||'(native)';
 const p=originalPositionFor(maps[id],{line:f.lineNumber+1,column:f.columnNumber});
 return `${p.source?.replace(/^.*?packages\//,'packages/')} : ${p.line}:${p.column} ${p.name??f.functionName}`;
}
const data=JSON.parse(await readFile(root+'/profile-exact-react.json','utf8'));
const totals={};
for(const r of data.records){const id=r.id.split('-')[0];for(const [phase,p] of Object.entries(r.phases)){
 const key=id+'/'+phase;const out=totals[key]??={count:0,cpu:Object.create(null),heap:Object.create(null),allocationOwners:Object.create(null),minified:Object.create(null),metrics:[]};out.count++;out.metrics.push(p.metrics);
 const nodes=new Map(p.cpu.nodes.map(n=>[n.id,n]));
 p.cpu.samples.forEach((n,i)=>{const f=nodes.get(n).callFrame,k=site(id,f);out.cpu[k]=(out.cpu[k]??0)+p.cpu.timeDeltas[i]/1000;if(f.url?.includes('/assets/'))out.minified[f.functionName]={source:k,line:f.lineNumber,column:f.columnNumber};});
 const walk=(n,owner='(native)')=>{if(n.callFrame.url?.includes('/assets/'))owner=site(id,n.callFrame);if(n.selfSize){const k=site(id,n.callFrame);out.heap[k]=(out.heap[k]??0)+n.selfSize;out.allocationOwners[owner]=(out.allocationOwners[owner]??0)+n.selfSize;}for(const c of n.children)walk(c,owner);};walk(p.heap.head);
}}
for(const [k,o]of Object.entries(totals)){
 for(const metric of ['cpu','heap','allocationOwners'])o[metric]=Object.entries(o[metric]).sort((a,b)=>b[1]-a[1]);
 console.log(k,'Allocation owners',JSON.stringify(o.allocationOwners.slice(0,10)));
}
await writeFile(root+'/profile-summary.json',JSON.stringify(totals,null,2));
