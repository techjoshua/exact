﻿import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { readFile, readdir, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
process.env.NODE_ENV='production';
const require=createRequire(resolve('framework-comparison/package.json'));
const {build}=await import(pathToFileURL(require.resolve('vite')).href);
const results={};
for(const id of ['exact','react']) {
 const source=resolve(`framework-comparison/participants/${id}`);
 const out=resolve(`.tmp/client-v8/${id}-mapped`);
 await build({configFile:source+'/vite.config.ts',build:{outDir:out,sourcemap:'hidden',emptyOutDir:true}});
 const assets=(await readdir(source+'/dist/assets')).filter(f=>f.endsWith('.js'));
 results[id]=[];
 for(const f of assets){
  const a=await readFile(source+'/dist/assets/'+f),b=await readFile(out+'/assets/'+f);
  if(!a.equals(b))throw Error('Mapped build differs from measured production bundle: '+id+'/'+f);
  results[id].push({file:f,bytes:a.length,sha256:createHash('sha256').update(a).digest('hex')});
 }
}
await writeFile('.tmp/client-v8/artifacts.json',JSON.stringify(results,null,2));
console.log('Production JS bytes identical; separate source maps ready');

