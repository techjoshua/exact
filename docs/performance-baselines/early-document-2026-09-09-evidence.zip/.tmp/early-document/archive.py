from pathlib import Path
import hashlib
import json
import zipfile

root = Path.cwd()
target = root / 'docs/performance-baselines/early-document-2026-09-09-evidence.zip'
report_path = root / 'docs/performance-baselines/early-document-2026-09-09.json'
report = json.loads(report_path.read_text(encoding='utf-8'))
paths = list((root / '.tmp/early-document').glob('*'))
paths += [root / row['path'] for row in report['sourceEvidence']]
paths += [root / '.tmp/post-shell-optimization/render-worker.mjs']
for ancestor in [target.parent, *target.parent.parents]:
    if ancestor.is_symlink() or ancestor.is_junction():
        raise RuntimeError(f'Linked evidence ancestor: {ancestor}')
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in paths:
        if path.is_file() and not path.is_symlink():
            archive.write(path, path.relative_to(root).as_posix())
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    for row in report['sourceEvidence']:
        assert hashlib.sha256(archive.read(row['path'])).hexdigest() == row['sha256']
report['evidenceArchive'] = {'path': target.relative_to(root).as_posix(), 'bytes': target.stat().st_size,
    'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}
report['validation'] = {'ssrTests': 260, 'hydrationTests': 240, 'nodeStreamingE2E': 7,
    'bunStreamingE2E': 7, 'abi': 'passed', 'platformBoundaries': 'passed',
    'sourceArchitecture': 'passed', 'jsdoc': 'passed', 'lint': 'passed', 'docsTypecheck': 'passed'}
report_path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report['evidenceArchive']))
