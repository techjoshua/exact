import {readFile,writeFile,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const rows=JSON.parse(await readFile('.tmp/early-document/first-http.json','utf8'));
const browser=JSON.parse(await readFile('.tmp/early-document/browser.json','utf8'));
const summary=['node','bun'].map(runtime=>{
 const select=variant=>rows.filter(r=>r.runtime===runtime&&r.variant===variant);
 const mean=variant=>select(variant).reduce((s,r)=>s+r.rps,0)/select(variant).length;
 const baseline=mean('baseline'),candidate=mean('candidate');
 return {runtime,baselineRps:baseline,candidateRps:candidate,changePercent:(candidate/baseline-1)*100,errors:rows.filter(r=>r.runtime===runtime).reduce((s,r)=>s+r.errors,0)};
});
const sources=['packages/ssr/src/render/async-rendering.ts','packages/ssr/src/render/entrypoints.ts','packages/ssr/src/render/progressive-response.ts','packages/ssr/src/stream/protocol.ts','packages/ssr/src/render/host.ts','packages/ssr/src/render/server-component-abi-execution.ts','packages/ssr/src/document-publication.test.ts','packages/ssr/src/documents-security.fixtures.test.tsx'];
const evidence=[];
for(const path of sources){const bytes=await readFile(path);evidence.push({path,sha256:createHash('sha256').update(bytes).digest('hex')});}
const report={date:'2026-09-09',baseline:'post-shell-2026-09-09',hypothesis:'Earlier resource discovery by publishing the shell before hydration; small-document throughput expected within roughly 0-5% cost.',summary,browser,http:rows,sourceEvidence:evidence};
await writeFile('docs/performance-baselines/early-document-2026-09-09.json',JSON.stringify(report,null,2)+'\n');
const table=summary.map(r=>`| ${r.runtime} | ${r.baselineRps.toFixed(2)} | ${r.candidateRps.toFixed(2)} | ${r.changePercent.toFixed(2)}% | ${r.errors} |`).join('\n');
await writeFile('docs/performance-baselines/early-document-2026-09-09.md',`# Early full-document shell publication

The progressive HTML path now sends the rendered document through its body content before
constructing hydration data. Hydration and closing tags follow in one final write. The concatenated
document is unchanged. Both readable streams and produced responses use the same framing.

## Hypothesis and focused measurement

Earlier shell delivery should let browsers discover CSS and scripts before hydration arrives.
Additional writes were expected to cost approximately 0-5% on small-document throughput. This
experiment targets browser latency rather than faster rendering.

In Chromium, a controlled 200 ms transport hold before hydration-containing chunks let the new
build request both CSS and module JavaScript before hydration was sent. The preserved build could
request neither until afterward. Both loaded the same compiler-rendered application document,
one hydration payload, and the script, without browser errors. The artificial hold demonstrates
overlap, not a measured real-world latency reduction.

Production-mode streaming HTTP comparison: Node 26.8.1 and Bun 1.4.2, two fresh server populations
per variant in reversed order, two independent drivers with 16 connections each, two seconds warmup
and four seconds measurement. Every timed response was checked against its full byte/hash identity;
baseline and candidate documents also matched exactly. React was not rerun for this focused change.

| Runtime | Preserved build RPS | Early shell RPS | Change | Errors |
| --- | ---: | ---: | ---: | ---: |
${table}

These small differences do not establish a throughput improvement. Retain the change for observable
resource-discovery overlap. The published full benchmark charts remain the earlier preserved capture.

## Correctness and scope

Full documents with pending scheduled work settle before shell publication because they cannot use
the fragment replacement protocol after bytes have been sent. Document event streams and fragment
HTML keep their replacement behavior. Cancellation interrupts producers waiting for demand.

A regression test uncovered missing document-host rollback in scheduled render retries. The renderer
now restores root/head/body claims for discarded attempts instead of treating the next valid attempt
as a duplicate document. This correction also applies to asynchronous string rendering.

The change does not flush the head during tree traversal. Rendering the body, and pending tasks
that could revise the document, can still delay initial bytes. A safe earlier publication boundary
remains an open investigation; this is not completion of the broader performance work.

Validation: 260 SSR tests, including seven new publication/settlement/cancellation cases; browser
resource-discovery check; seven application streaming SSR/hydration/interaction checks on Node and
seven on Bun. Further ABI, hydration, platform and documentation checks are recorded in the work log.

[Raw measurements and source hashes](early-document-2026-09-09.json) preserve the focused results.
The reproducible probe scripts and frozen candidate entries remain under .tmp/early-document.
`);
console.log(summary);
