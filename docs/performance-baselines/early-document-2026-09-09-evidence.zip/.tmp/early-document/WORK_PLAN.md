# Early document publication

Preserve post-shell-2026-09-09 as the completed comparison baseline.

Hypothesis before measurement: sending the completed document shell before hydration publication
allows CSS and script fetches to overlap the remaining response interval. A controlled 200 ms delay
before hydration should allow discovery within that interval, whereas the previous framing cannot.
This is a browser latency improvement, not an expected renderer throughput improvement. Additional
stream writes may cost approximately 0-5% on small documents; measure Node and Bun with unchanged
final bytes. Do not infer real-world milliseconds saved from the artificial delay.

Implementation: retain only closing tags after the shell, send hydration in the existing framework
region, then close the document. Settle mutable full-document shells before irreversible publication;
preserve event-stream and fragment replacement behavior. Do not change emitted compiler ABI.

Regression found: scheduled document attempts retained root/head/body claims when a task caused a
retry, rejecting the next valid attempt as duplicate HTML. Restore these claims with attempt rollback.

Remaining separate investigation: flush compiler-owned head output during traversal, before body work.
This needs publication boundaries that cannot later be invalidated by ancestor task retries.

Results: Chromium requested CSS and module JavaScript before hydration was sent with the new build,
and only afterward with the preserved build. The 200 ms transport hold demonstrates overlap only.
HTTP: Node 5155.62 -> 5125.72 RPS (-0.58%); Bun 5260.01 -> 5258.25 RPS (-0.03%).
Eight measured blocks, exact complete-document byte/hash checks, zero response errors.

Validation complete: 260 SSR tests, 240 hydration tests, 7 streaming application E2E cases on each
of Node and Bun, compiled and frozen release ABI checks, platform boundaries, source architecture,
JSDoc, changed-file lint, docs typecheck, formatting, and git diff --check.
No compiler artifact contract or public API changed. Public charts retain the prior full capture.
