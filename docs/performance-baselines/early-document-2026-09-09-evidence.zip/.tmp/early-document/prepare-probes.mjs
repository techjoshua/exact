import {readFile,writeFile,copyFile} from 'node:fs/promises';
let source=await readFile('.tmp/post-shell-optimization/http-round.mjs','utf8');
source=source.replace("const root='.tmp/post-shell-optimization'","const root='.tmp/early-document'")
.replace("['string','stream']","['stream']")
.replace("['react','candidate','baseline']:['baseline','candidate','react']","['candidate','baseline']:['baseline','candidate']")
.replace("root+'/baseline/'+relative","`.tmp/post-shell-final/current-exact-${runtime.id}.mjs`")
.replaceAll(".replace(/<!--[\\s\\S]*?-->/g,'')",'');
await writeFile('.tmp/early-document/http.mjs',source);
await copyFile('framework-comparison/participants/exact/dist-server/server-entry.js','.tmp/early-document/current-node.mjs');
await copyFile('framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js','.tmp/early-document/current-bun.mjs');
