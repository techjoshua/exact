import {createServer} from 'node:http';
import {readFile,writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import {chromium} from 'playwright';
import assert from 'node:assert/strict';
const data=JSON.parse(await readFile('.tmp/positional-leaves/data.json','utf8'));
const variants={baseline:'.tmp/post-shell-final/current-exact-node.mjs',candidate:'framework-comparison/participants/exact/dist-server/server-entry.js'};
const rows=[];
for(const [variant,entry] of Object.entries(variants)){
 const mod=await import(pathToFileURL(resolve(entry)));
 const record={variant,resourceRequests:[],hydrationSent:false,errors:[]};
 const active=new Set();let browser;
 const server=createServer((req,res)=>{
  if(req.url==='/app.css'||req.url==='/early.js'){
   record.resourceRequests.push({url:req.url,beforeHydration:!record.hydrationSent});
   res.setHeader('content-type',req.url.endsWith('.css')?'text/css':'application/javascript');
   res.end(req.url.endsWith('.css')?'body {color: rgb(1, 2, 3)}':'globalThis.earlyResourceLoaded=true;');return;
  }
  if(req.url!=='/'){res.writeHead(404);res.end();return;}
  const task=(async()=>{
   const reader=mod.renderParticipantStream(data,'/incidents/inc-101',{clientTags:'<link rel="stylesheet" href="/app.css"><script type="module" src="/early.js"></script>'}).getReader();
   res.setHeader('content-type','text/html; charset=utf-8');
   try{while(true){const next=await reader.read();if(next.done)break;
    if(Buffer.from(next.value).includes(Buffer.from('id="__exact_hydration"'))){await new Promise(r=>setTimeout(r,200));record.hydrationSent=true;}
    res.write(next.value);
   }res.end();}finally{await reader.cancel();}
  })();active.add(task);task.catch(e=>{record.errors.push(String(e));res.destroy(e);}).finally(()=>active.delete(task));
 });
 try{
  await new Promise(r=>server.listen(0,'127.0.0.1',r));browser=await chromium.launch();
  const page=await browser.newPage();page.on('pageerror',e=>record.errors.push(e.message));
  await page.goto(`http://127.0.0.1:${server.address().port}/`);
  assert.equal(await page.title(),'Incident Operations');
  assert.equal(await page.locator('#__exact_hydration').count(),1);
  assert.equal(await page.locator('html').count(),1);
  assert.equal(await page.evaluate(()=>globalThis.earlyResourceLoaded),true);
  assert.deepEqual(record.errors,[]);assert.equal(record.resourceRequests.length,2);
  assert.ok(record.resourceRequests.every(r=>r.beforeHydration===(variant==='candidate')));
  rows.push(record);
 }finally{await browser?.close();await Promise.allSettled([...active]);server.closeAllConnections();await new Promise(r=>server.close(r));}
}
await writeFile('.tmp/early-document/browser.json',JSON.stringify({note:'Controlled 200 ms transport hold before hydration-containing chunks; verifies overlap, not real-world speedup.',rows},null,2));
console.log(JSON.stringify(rows,null,2));
