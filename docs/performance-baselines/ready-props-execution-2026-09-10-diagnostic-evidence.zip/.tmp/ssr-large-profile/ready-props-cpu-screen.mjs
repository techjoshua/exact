import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';
const worker=root+'ready-props-cpu-worker.mjs';
let source=fs.readFileSync(root+'ready-props-stable-timing-worker.mjs','utf8');
source=source.replace('const started=performance.now();','const cpuStart=process.cpuUsage();\nconst started=performance.now();');
source=source.replace('const elapsed=performance.now()-started;', 'const elapsed=performance.now()-started;\nconst cpu=process.cpuUsage(cpuStart);');
source=source.replace('processPriority:os.getPriority()','processPriority:os.getPriority(),cpuMicrosPerRender:(cpu.user+cpu.system)/count');
fs.writeFileSync(worker,source);
const rows=[];
for(const [runtime,scenario] of [['node','large'],['bun','assets']])for(let round=0;round<2;round++)for(const variant of round?['candidate','current']:['current','candidate']){
 const entry=root+(variant==='candidate'?'ready-props-stable':'direct-execution-integrated')+'/server-entry.js';
 const artifactSha256=createHash('sha256').update(fs.readFileSync(entry)).digest('hex');
 assert.equal(artifactSha256,variant==='candidate'?'99f76e4e06e41960c5a6da7a1a6669e197051160e5987f5ba6eefb17cbd9d3ba':'2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18');
 const run=spawnSync(runtime,[worker,entry,'encoded',scenario,'20000'],{windowsHide:true,encoding:'utf8',env:{...process.env,NODE_ENV:'production'}});
 assert.equal(run.status,0,run.stderr+run.stdout);
 const row={runtimeId:runtime,variant,round,artifactSha256,...JSON.parse(run.stdout)};
 const peer=rows.find(r=>r.scenario===scenario);if(peer)assert.equal(row.hash,peer.hash);
 rows.push(row);fs.writeFileSync(root+'ready-props-cpu-screen.json',JSON.stringify(rows,null,2));
 console.log(runtime,variant,round,'wall',row.usPerRender.toFixed(2),'CPU',row.cpuMicrosPerRender.toFixed(2),'us/render');
}
