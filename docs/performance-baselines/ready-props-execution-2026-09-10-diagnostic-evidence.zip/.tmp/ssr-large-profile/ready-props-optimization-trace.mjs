import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
for(const [variant,folder] of [['current','direct-execution-integrated'],['candidate','ready-props-stable']]){
 const log=root+`ready-props-${variant}-optimization.log`;
 const fd=fs.openSync(log,'w');
 let run;
 try {
  run=spawnSync(process.execPath,['--trace-turbo-inlining','--trace-opt','--trace-deopt',root+'ready-props-stable-timing-worker.mjs',root+folder+'/server-entry.js','encoded','large','1000'],{windowsHide:true,stdio:['ignore',fd,fd],env:{...process.env,NODE_ENV:'production'}});
 } finally {fs.closeSync(fd);}
 assert.equal(run.status,0,log);
 console.log(variant,fs.statSync(log).size,'trace bytes');
}
