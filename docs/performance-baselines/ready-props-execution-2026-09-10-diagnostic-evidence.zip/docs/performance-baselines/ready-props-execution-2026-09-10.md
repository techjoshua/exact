# Direct execution after props preparation

Status: neither prototype is adopted. Investigation remains open following the user's request to explain why a plausible optimization regresses. The corrected variant preserves selected metadata, passes focused probes and measurably reduces allocation, but increases large-Node process CPU consumption. Production remains the validated execution-target integration.

## Hypothesis

`executeDirectSsrComponent` passes its entire execution body as a callback to mapRenderValue even when props are already ready. The experiment extracts that body into a regular internal function, calls it directly for available props, and creates a continuation only for pending props. Child issuance, component frames, publication, observer hooks, rollback and disposal still run through the existing implementation. No second rendering engine or sink mode branch is introduced.

The working hypothesis is a small reduction in allocation, approximately 1-3%, with a possible 0-3% timing benefit from avoiding one callback per synchronous component. Those timing expectations have not been tested. Remaining nested callbacks and their captured state still exist, and optimized allocation cannot be inferred from source closure counts alone.

## Allocation capture and integration confirmation

Twelve fresh Node 26.8.1 production processes use two reversed orders for three variants and two fixture sizes. Each process performs 50,000 warmups and samples 10,000 renders with a 16 KiB interval, including minor-collected and major-collected objects. One process runs at a time with below-normal priority 10 while the user uses the PC. Complete document hashes match. Values are estimated allocated bytes per render, not retained memory or exact object counts.

| Fixture | Before execution-target integration | Integrated current build | First props prototype |
| --- | ---: | ---: | ---: |
| 3 incidents | 70,077 | 67,679 | 66,591 |
| 96 incidents | 525,233 | 497,411 | 485,082 |

Both pairs improve for both comparisons and fixture sizes. The preceding-to-integrated comparison confirms the retained source optimization: approximately 3.4% lower allocation for the small page and 5.3% lower for the large page. The first props prototype reduces allocation a further 1.6% and 2.5%, respectively. These results do not establish throughput, GC count or GC duration changes.

## Read-order correction

The first extraction reads `contract.artifact` and `artifact.execution` again inside the helper. The original implementation retains the values selected before props preparation. Although compiler metadata is normally frozen data, freezing alone does not make accessor results stable. There is no reason for this optimization to add metadata reads or move selection across props settlement.

The corrected prototype passes the already selected artifact and execution metadata into the helper, retaining original read order for both ready and pending props. It adds two internal arguments instead of allocating a wrapper. The first prototype's allocation numbers must not be attributed to this revised code before measuring it.

A diagnostic exposes the existing internal executor from each frozen bundle and supplies an artifact getter returning distinct selections on successive reads. This is a read-order probe, not a claim that such hand-authored metadata is a public application API. On both Node and Bun, with ready and promised props:

- the control reads once and renders the first selection;
- the first prototype reads twice and renders the second selection;
- the corrected prototype reads once and renders the first selection.

Both prototypes separately pass 24 complete-output comparisons across Node/Bun string/stream with three concurrent requests per fixture and forced ready-call suspension. Each runtime induces 183/105 small string/stream suspensions and 1,113/663 large suspensions. These probes supplement rather than replace acceptance coverage for props rejection, lifecycle failures, observers and scheduled work.

## Corrected variant response consumption

Sixteen fresh production processes compare the corrected variant against the current integrated build. Each warms 50,000 iterations and measures 20,000 full string renders followed by Response construction and text consumption. Node 26.8.1 and Bun 1.4.2 each run two reversed orders for both fixture sizes. All processes report below-normal priority 10 and run one at a time during active workstation use. Complete document hashes match. The same frozen server bundle is used on both runtimes; these are not HTTP measurements.

Mean microseconds per response-consumption iteration:

| Runtime | Fixture | Current | Corrected prototype | Change |
| --- | --- | ---: | ---: | ---: |
| Node | 3 incidents | 47.62 | 46.57 | -2.2% |
| Bun | 3 incidents | 35.66 | 37.23 | +4.4% |
| Node | 96 incidents | 203.39 | 215.21 | +5.8% |
| Bun | 96 incidents | 273.80 | 268.94 | -1.8% |

Small Node pairs are 45.18 to 45.33 and 50.06 to 47.81, with mixed directions. Small Bun pairs are 35.65 to 37.08 and 35.66 to 37.38, both slower. Large Node pairs are 200.35 to 215.77 and 206.42 to 214.66, both slower. Large Bun pairs are 278.47 to 261.07 and 269.13 to 276.80, with mixed directions. All observations are retained, including the favorable populations. Shared workstation use limits precision, but the repeated regressions in two cases do not support adoption.

At this stage no allocation or GC benefit had been measured for the corrected variant. The first variant's allocation savings did not establish the corrected variant's behavior or compensate for its observed timing regressions. The initial decision was to keep it out of production. The deeper investigation below tests why the apparently useful change failed to improve timing rather than treating that initial result as a sufficient explanation.

## Deeper investigation

The user requested further investigation of promising changes that do not initially help. Three subsequent checks distinguish allocation, optimization behavior and scheduling effects. All use the unchanged corrected prototype and current integrated control.

First, Node optimization traces use `--trace-turbo-inlining`, `--trace-opt` and `--trace-deopt`, with 50,000 warmups and 1,000 additional large-page encoded iterations at below-normal priority. Trace-enabled elapsed times are not performance evidence. The candidate's extracted helper is explicitly inlined into executeDirectSsrComponent and executeSynchronousArtifact. The control's original callback is also inlined. Each trace contains 20 bailout records with matching grouped reasons: nine wrong-map, ten labeled unknown and one insufficient-feedback record. Neither trace reports a bailout for executeDirectSsrComponent, executePreparedDirectComponent or executeSynchronousArtifact. This rules out the simple claim that the helper remains an uninlined call or introduces an obvious executor deoptimization storm. It does not prove that generated machine code, inlining decisions elsewhere or optimization costs are identical.

Second, eight fresh Node allocation populations repeat the 50,000-warmup, 10,000-measured-render, 16 KiB sampling protocol in two reversed orders. Both pairs improve for both fixtures. The corrected variant lowers estimated allocation from 67,337 to 66,158 bytes per small render (1.8%) and from 497,390 to 485,813 bytes per large render (2.3%). Thus its allocation benefit is measured directly, independently of the first prototype. No corrected-variant GC duration benefit is established by this capture.

Third, eight unprofiled populations record process CPU usage around the measured loop alongside elapsed time. These retain reduced priority and the same 50,000 warmups and 20,000 encoded iterations. They focus on large Node and small Bun, the cases with repeated earlier regressions.

| Case | Current mean elapsed, us | Candidate mean elapsed, us | Current process CPU, us/render | Candidate process CPU, us/render |
| --- | ---: | ---: | ---: | ---: |
| Node, 96 incidents | 196.88 | 214.91 | 199.65 | 216.00 |
| Bun, 3 incidents | 35.28 | 35.79 | 46.10 | 47.28 |

Node CPU pairs are 198.50 to 214.05 and 200.80 to 217.95 microseconds per render, both worse. Node elapsed pairs are 195.84 to 210.07 and 197.92 to 219.74, also both worse. The 8.2% higher mean process CPU consumption means lost scheduling time alone does not explain the Node regression. Process CPU sums work across the process's threads and can exceed elapsed time; it is not just renderer-thread time.

Bun elapsed pairs are 34.07 to 35.77 and 36.48 to 35.82, now mixed. Its CPU pairs are 44.55 to 44.55 and 47.65 to 50.00. This follow-up does not establish a stable Bun effect and does not erase the earlier two regressions.

The explanation remains incomplete: the helper is inlined and sampled allocation decreases, yet Node CPU consumption rises. Further investigation should attribute that extra CPU work, including collector work and optimized-code differences, before choosing a redesign. Neither extra argument count nor inlining failure is asserted as the cause without evidence. This experiment remains outside production while that question is open.

## Decision and evidence

Keep the current integrated renderer while investigating the regression. Neither prototype changed production source or compiler ABI. The retained execution-target optimization's independently confirmed allocation improvement remains intact. Current Node/Bun HTTP adapter comparisons against React are still needed independently of this investigation.

Preceding control SHA-256: `6d92194f2ee395f4e4e5267b8719bc1160a96ce7bc16f1a6bbdc74f98aba4997`.

Current integrated SHA-256: `2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18`.

First prototype SHA-256: `0db2388cc9aa4d3f6b56c6a27eafe4b03ccb110dd1aca0242b6b302948df514f`.

Corrected prototype SHA-256: `99f76e4e06e41960c5a6da7a1a6669e197051160e5987f5ba6eefb17cbd9d3ba`.

`ready-props-execution-2026-09-10-evidence.zip` preserves the four frozen bundles, asserted builders, allocation driver and worker, twelve heap profiles and summary, suspension and metadata probes/results, relevant source snapshots and this report. The preceding integrated optimization's performance confirmation is now available; the overall Node string and HTTP comparison work remains unfinished.

`ready-props-execution-2026-09-10-timing-evidence.zip` preserves all sixteen corrected-variant timing populations, the driver and worker, both compared bundles, fixture data and this updated decision. The earlier archive remains an unchanged snapshot from before these measurements.

`ready-props-execution-2026-09-10-diagnostic-evidence.zip` preserves optimization traces and their runner, corrected-variant allocation profiles and summaries, CPU/elapsed-time populations and workers, both bundles, fixture data and the updated investigation report.
