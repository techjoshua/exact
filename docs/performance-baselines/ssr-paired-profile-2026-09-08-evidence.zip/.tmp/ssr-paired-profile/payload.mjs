import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import * as entry from './capture-payload.mjs';
const data=JSON.parse(await readFile('.tmp/ssr-path-costs/data.json','utf8'));
entry.renderParticipantToSink(data,'/incidents/inc-101',()=>{},Buffer.byteLength);
const original=entry.lastPayload;
const packed=JSON.parse(JSON.stringify(original));
function cloneDense(value){if(Array.isArray(value)){const result=[];for(const item of value)result.push(cloneDense(item));return result;}if(value&&typeof value==='object'){const result={};for(const [key,item]of Object.entries(value))result[key]=cloneDense(item);return result;}return value;}
const dense=cloneDense(original);
assert.equal(JSON.stringify(original),JSON.stringify(packed));assert.equal(JSON.stringify(original),JSON.stringify(dense));
const operations={original:()=>JSON.stringify(original),parsed:()=>JSON.stringify(packed),dense:()=>JSON.stringify(dense),reactData:()=>JSON.stringify(data)};
const samples=[];let bytes=0;
for(const op of Object.values(operations))for(let i=0;i<10000;i++)bytes+=op().length;
for(let round=0;round<12;round++)for(const name of round%2?Object.keys(operations).reverse():Object.keys(operations)){
 const start=performance.now();for(let i=0;i<100000;i++)bytes+=operations[name]().length;
 samples.push({round,name,microseconds:(performance.now()-start)/100});
}
await writeFile('.tmp/ssr-paired-profile/payload-json.json',JSON.stringify({samples,bytes},null,2));
for(const name of Object.keys(operations))console.log(name,samples.filter(s=>s.name===name).reduce((n,s)=>n+s.microseconds,0)/12);
await writeFile('.tmp/ssr-paired-profile/payload.json',JSON.stringify(original));
