import {readFile,writeFile} from 'node:fs/promises';
import {Session} from 'node:inspector/promises';
import * as exact from '../../framework-comparison/participants/exact/dist-server/server-entry.js';
import * as react from '../../framework-comparison/participants/react/dist-server/server-entry.js';
import {comparisonDocumentHtml} from '../../framework-comparison/src/ssr-response-breakdown.mjs';
const data=JSON.parse(await readFile('.tmp/ssr-path-costs/data.json','utf8'));
if(process.env.NODE_ENV !== 'production')throw new Error('Production mode required');
const [prefix,suffix]=comparisonDocumentHtml('exact','__PROFILE_BODY__',data).split('__PROFILE_BODY__');
const operations={exact:()=>{let rendered='';exact.renderParticipantToSink(data,'/incidents/inc-101',v=>rendered+=v,Buffer.byteLength);return prefix+rendered+suffix;},react:()=>comparisonDocumentHtml('react',react.renderParticipant(data,'/incidents/inc-101'),data)};
let consumed=0;const samples=[];
for(const op of Object.values(operations))for(let i=0;i<10000;i++)consumed+=op().length;
for(let round=0;round<24;round++)for(const id of round%2?['react','exact']:['exact','react']){
 const start=performance.now();for(let i=0;i<5000;i++)consumed+=operations[id]().length;
 samples.push({round,id,microseconds:(performance.now()-start)/5});
}
for(const id of ['exact','react'])console.log(id,samples.filter(s=>s.id===id).reduce((n,s)=>n+s.microseconds,0)/24);
await writeFile('.tmp/ssr-paired-profile/render-only.json',JSON.stringify({samples,consumed,note:'Both produce the complete production response document including initial client state, without HTTP, request telemetry, or response ownership wrappers.'},null,2));
for(const id of ['exact','react']){
 const session=new Session();session.connect();await session.post('Profiler.enable');await session.post('Profiler.setSamplingInterval',{interval:1000});await session.post('Profiler.start');
 for(let i=0;i<100000;i++)consumed+=operations[id]().length;
 const {profile}=await session.post('Profiler.stop');session.disconnect();await writeFile(`.tmp/ssr-paired-profile/${id}-render.cpuprofile`,JSON.stringify(profile));
}
