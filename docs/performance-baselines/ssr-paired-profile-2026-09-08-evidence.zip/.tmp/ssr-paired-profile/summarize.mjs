import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {summarizeSsrCapacityCapture} from '../../framework-comparison/src/ssr-capacity-report.mjs';
const root='.tmp/ssr-paired-profile/';
const summary={profiles:JSON.parse(await readFile(root+'analysis.json','utf8')),bytes:JSON.parse(await readFile(root+'bytes.json','utf8')),renderer:{},http:{}};
for(const file of ['domain-node-first.json','domain-node.json','domain-bun-first.json','domain-bun.json','render-only.json']){
 const raw=JSON.parse(await readFile(root+file,'utf8'));const samples=raw.samples??raw;
 summary.renderer[file]=[...new Set(samples.map(s=>s.name??s.id))].map(name=>{const rows=samples.filter(s=>(s.name??s.id)===name);return{name,rounds:rows.length,microseconds:rows.reduce((n,s)=>n+s.microseconds,0)/rows.length};});
}
for(const file of ['handoff.json','domain-http.json','assembly.json']){
 const capture=JSON.parse(await readFile(root+file,'utf8'));assert.equal(capture.complete,true);const rows=[];
 for(const b of capture.blocks)for(const r of b.results)for(const s of r.stages)assert.equal(s.errors,0);
 for(const variant of [...new Set(capture.blocks.map(b=>b.variant))]){
  const blocks=capture.blocks.filter(b=>b.variant===variant);const [row]=summarizeSsrCapacityCapture({...capture,blocks});
  const populations=blocks.map(b=>{const stages=b.results.map(r=>r.stages.find(s=>!s.discard));const start=Math.min(...stages.map(s=>Date.parse(s.startedAt))),end=Math.max(...stages.map(s=>Date.parse(s.startedAt)+s.elapsedMs));return{population:b.population,rps:1000*stages.reduce((n,s)=>n+s.valid,0)/(end-start)};});
  rows.push({variant,...row,populations,wireHeaders:blocks[0].wireHeaders});
  console.log(file,variant,Math.round(row.rps),populations.map(p=>Math.round(p.rps)).join('/'));
 }
 summary.http[file]=rows;
}
await writeFile('docs/performance-baselines/ssr-paired-profile-2026-09-08.json',JSON.stringify(summary,null,2)+'\n');
