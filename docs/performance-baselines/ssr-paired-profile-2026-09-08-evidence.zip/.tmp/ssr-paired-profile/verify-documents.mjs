import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import * as exact from './exact-before.js';
import * as react from './react-before.js';
import {comparisonDocumentHtml} from '../../framework-comparison/src/ssr-response-breakdown.mjs';
assert.equal(process.env.NODE_ENV,'production');
const data=JSON.parse(await readFile('.tmp/ssr-paired-profile/data.json','utf8'));
const capture=JSON.parse(await readFile('.tmp/ssr-paired-profile/capture.json','utf8'));
for(const [id,entry]of Object.entries({exact,react})){
 let rendered='';if(id==='exact')entry.renderParticipantToSink(data,'/incidents/inc-101',v=>rendered+=v,Buffer.byteLength);else rendered=entry.renderParticipant(data,'/incidents/inc-101');
 const body=comparisonDocumentHtml(id,rendered,data);
 const identity={bytes:Buffer.byteLength(body),hash:createHash('sha256').update(body).digest('hex')};
 for(const block of capture.blocks.filter(b=>b.id===id))assert.deepEqual(identity,block.identity);
 console.log(id,'render-only document matches profiled HTTP body');
}
