import {readFile,writeFile} from 'node:fs/promises';
import * as exact from '../../framework-comparison/participants/exact/dist-server/server-entry.js';
import * as react from '../../framework-comparison/participants/react/dist-server/server-entry.js';
import {responseByteBreakdown} from '../../framework-comparison/src/ssr-response-breakdown.mjs';
const data=JSON.parse(await readFile('.tmp/ssr-path-costs/data.json','utf8'));
const result={};for(const [id,entry]of Object.entries({exact,react}))result[id]=responseByteBreakdown(id,entry.renderParticipant(data,'/incidents/inc-101'),data);
await writeFile('.tmp/ssr-paired-profile/bytes.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
