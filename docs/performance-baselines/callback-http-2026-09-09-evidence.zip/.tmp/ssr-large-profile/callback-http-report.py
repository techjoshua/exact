import hashlib,json,pathlib,statistics,zipfile
root=pathlib.Path('.');work=root/'.tmp/ssr-large-profile'
rows=json.loads((work/'callback-current-http.json').read_text(encoding='utf-8'))
assert len(rows)==16
summary=[];valid=0;errors=0
for row in rows:
 assert hashlib.sha256(pathlib.Path(row['entry']).read_bytes()).hexdigest()==row['artifactSha256']
 for result in row['results']:
  stage=result['stages'][1]
  assert stage['started']==stage['completed']==stage['valid']+stage['errors']
  valid+=stage['valid'];errors+=stage['errors']
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  medians={v:statistics.median(r['rps'] for r in rows if r['runtime']==runtime and r['mode']==mode and r['variant']==v) for v in ['candidate','react']}
  summary.append(dict(runtime=runtime,mode=mode,exact=medians['candidate'],react=medians['react'],relative_percent=(medians['candidate']/medians['react']-1)*100))
table='\n'.join(f"| {s['runtime']} | {s['mode']} | {s['exact']:,.0f} | {s['react']:,.0f} | {s['relative_percent']:+.1f}% |" for s in summary)
dest=root/'docs/performance-baselines/callback-http-2026-09-09'
dest.with_suffix('.json').write_text(json.dumps(dict(validMeasuredResponses=valid,errors=errors,summary=summary,populations=rows),indent=2)+'\n',encoding='utf-8')
doc=f'''# Retained callback build HTTP comparison

Date: 2026-09-09. The React parity objective remains unmet.

The retained eXact build leads Node streaming. React leads Node and Bun strings. Bun streaming is
close, with one population favoring each framework; this capture does not establish a reliable
lead for either there.

## Artifact and method verification

The actual Node eXact participant artifact matches callback-current.mjs byte for byte, SHA-256
8f2b511cb49b9a5b6be45587e538ef6c5fffead9ffdd336e95bdeb6c897380b6. Bun uses its runtime-specific
artifact, whose retained scalar-root, document-tail, and synchronous callback code was inspected.
Each measured artifact's hash is recorded and verified again when producing this report.
No diagnostic or rejected experiment bundle is selected.

Node 26.8.1 and Bun 1.4.2, React 19.2.0. The worker explicitly sets NODE_ENV=production. This uses
the real Node HTTP and Bun Fetch response adapters, rather than the common renderer consumer used
in recent isolated experiments. Both frameworks render complete application-owned documents on
each request. Controlled service data is preloaded, with three incidents and empty client asset
tags, so repeated service-fetch latency and client loading are outside this measurement.

Two reversed-order populations per runtime/output mode, 16 populations total. Each population
uses two independent load drivers at concurrency 16 each, 32 aggregate. Warmup lasts two seconds,
measurement four seconds. Reported throughput counts valid responses over the combined driver
measurement interval. Initial responses must be successful complete documents. Every measured
response is checked against that population's full-body byte count and SHA-256 identity.

All {valid:,} measured responses were valid; measured errors: {errors}.

| Runtime | Output | eXact requests/s | React requests/s | eXact relative throughput |
| --- | --- | ---: | ---: | ---: |
{table}

These are medians of two short populations on a shared workstation, not confidence intervals.
The absolute rates differ substantially from the earlier retained HTTP capture. There is no old
eXact build control in this run, so neither absolute changes nor changes in ratios across captures
can be attributed solely to the accepted optimizations. Compare frameworks within this capture.

## Consequences

Node string throughput remains the clearest gap in this workload. The Bun string deficit is
smaller, while Bun streaming is close enough that further claims require stronger paired evidence.
The large-document diagnostics remain separate: this small-document HTTP result cannot establish
large-document parity or eliminate the need to optimize hydration projection.

No production code changed. No new browser timing or correctness run is claimed here. Public full
benchmark charts retain their historical baseline: this focused HTTP run does not replace client,
navigation, interaction, memory, service-backed, or large-document measurements. All task-owned
service, worker, and driver processes were closed, and a subsequent process inventory found only
the unrelated Codex CLI Node process.

The JSON contains raw populations and driver results. The accompanying evidence archive preserves
the runner, current participant artifacts, benchmark support scripts, and SHA-256 manifest.
Reproduction requires the locked workspace dependencies.
'''
dest.with_suffix('.md').write_text(doc,encoding='utf-8')
previous=root/'docs/performance-baselines/retained-http-2026-09-09-evidence.zip'
with zipfile.ZipFile(previous) as old:
 support=[root/n for n in old.namelist() if n.startswith('framework-comparison/src/') or n.startswith('scripts/') or n.startswith('framework-comparison/node_modules/')]
files=support+[work/'current-http.mjs',work/'callback-current-http.json',work/'callback-http-report.py',dest.with_suffix('.md'),dest.with_suffix('.json')]+[pathlib.Path(r['entry']) for r in rows]
files=sorted(set(p.resolve() for p in files))
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 manifest={}
 for p in files:
  name=p.relative_to(root.resolve()).as_posix();z.write(p,name);manifest[name]=hashlib.sha256(p.read_bytes()).hexdigest()
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(table);print('Valid responses',valid,'errors',errors);print('Verified',archive)
