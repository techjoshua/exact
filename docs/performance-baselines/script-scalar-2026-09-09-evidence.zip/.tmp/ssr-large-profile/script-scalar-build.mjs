import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
let source=readFileSync(dir+'direct-map-current.mjs','utf8');
const before='src: createExpression(() => src)';
if(source.split(before).length!==2)throw Error('Unexpected script scalar site');
source=source.replace(before,'src');
writeFileSync(dir+'script-scalar.mjs',source);
let runner=readFileSync(dir+'direct-map-current-run.mjs','utf8').replaceAll("'callback-current'","'direct-map-current'").replace("['direct-map-current','direct-map-current']","['script-scalar','direct-map-current']").replace("['direct-map-current','direct-map-current']","['direct-map-current','script-scalar']").replace('direct-map-current-results.json','script-scalar-results.json');
writeFileSync(dir+'script-scalar-run.mjs',runner);
