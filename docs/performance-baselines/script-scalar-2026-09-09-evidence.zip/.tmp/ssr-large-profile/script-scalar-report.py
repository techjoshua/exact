import hashlib,json,pathlib,zipfile
root=pathlib.Path('.');work=root/'.tmp/ssr-large-profile'
rows=json.loads((work/'script-scalar-results.json').read_text(encoding='utf-8'));summary=[]
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  changes=[]
  for round in range(2):
   group=[r for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['round']==round]
   a=next(r for r in group if r['variant']=='direct-map-current');b=next(r for r in group if r['variant']=='script-scalar')
   assert a['hash']==b['hash'];changes.append((b['usPerRender']/a['usPerRender']-1)*100)
  summary.append(dict(runtime=runtime,mode=mode,changes=changes))
table='\n'.join(f"| {s['runtime']} | {s['mode']} | {s['changes'][0]:+.2f}% | {s['changes'][1]:+.2f}% |" for s in summary)
dest=root/'docs/performance-baselines/script-scalar-2026-09-09'
dest.with_suffix('.json').write_text(json.dumps(dict(summary=summary,populations=rows),indent=2)+'\n',encoding='utf-8')
doc='''# Shell script lowering audit and scalar probe

Date: 2026-09-09. Production remains at the retained direct-map build.

## Compiler finding

unsupportedPlannedHost in jsx_render_program_lowering.go excludes script, style, template, and
other special hosts. The existing exception permits server document roots, not scripts. Consequently
the comparison Document's empty external module scripts use createCompiledIntrinsicReceipt,
including an element identity and a createExpression wrapper around the immutable map parameter.
The stylesheet list uses prepared render programs. compiledSsrAttribute already contains script
attribute-name normalization, but the host exclusion prevents this example taking that path.

## Narrow experiment

Before attempting a compiler change, a frozen-bundle probe replaces only `src: createExpression(
() => src)` with the scalar `src` at the one generated external-script site. The hypothesis is a
small saving from avoiding reactive wrapper construction and reading for this immutable parameter.
It does not compile the script, remove its identity, change its attributes, or modify authored code.
This site-specific probe is not a production optimization or a generic compiler proof.

Sixteen fresh processes: Node/Bun, string/consumed stream, two reversed-order pairs per cell.
NODE_ENV=production, 5,000 warmups, 12,000 measured renders, three incidents, complete authored
documents, two scripts and two stylesheet links. Both runtimes use the same portable artifact;
Response.text() consumes streams. All paired document hashes match. No HTTP/browser timing is run.

Positive means longer rendering time. Workstation variability was substantial, especially Node
strings. Two pairs do not support precise estimates or causal explanations for individual outliers.

| Runtime | Mode | Pair 1 time change | Pair 2 time change |
| --- | --- | ---: | ---: |
'''+table+'''

All cells are mixed across the two orders. The scalar-only change is not adopted or treated as
an established improvement. The result does not answer whether compiling the entire empty script
intrinsic would remove enough generic work to help.

## Next compiler experiment requirements

A broader candidate should be restricted initially to server-only empty external script roots,
preserving ordinary client lowering. It must preserve element identity, src sanitization, script
attribute spelling/order, enhancement routing, keyed ranges, and full-document hydration. Inline
script content and dynamic children must retain existing handling unless independently proven safe.
Client script execution and adoption must be tested in a real browser; matching HTML alone cannot
establish those semantics. Generic support must be implemented in the compiler, not by special-casing
the comparison application or its generated identifier names.

No production code or compiler binary changed. No package/browser regression tests were run for
this rejected scalar probe. The objective remains unmet. The archive includes artifacts, fixed
input, runner, builder, worker, raw results, reporter, and SHA-256 hashes.
'''
dest.with_suffix('.md').write_text(doc,encoding='utf-8')
files=[work/n for n in ['direct-map-current.mjs','script-scalar.mjs','script-scalar-build.mjs','script-scalar-run.mjs','script-scalar-results.json','script-scalar-report.py','direct-map-worker.mjs','direct-map-current-run.mjs']]+[root/'.tmp/positional-leaves/data.json']
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps({p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(table);print('Verified',archive)
