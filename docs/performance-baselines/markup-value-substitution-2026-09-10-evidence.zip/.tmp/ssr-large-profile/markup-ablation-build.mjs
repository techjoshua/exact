import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'markup-ablation',{recursive:true});
const source=(await fs.readFile(root+'component-forwarding-integrated/server-entry.js','utf8')).replaceAll('\r\n','\n');
const ast=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const edits=[];const sites=[];let resets=0;
function visit(n){
 if(ts.isVariableDeclaration(n)&&n.name.getText(ast)==='generatedSsrOperations'){
  function method(c){
   if(ts.isMethodDeclaration(c)){
    const name=c.name.getText(ast),variable=({text:'dynamic',attribute:'html',compiledAttribute:'html',attributes:'html',rootOpening:'rendered'})[name];
    if(variable){
     function declaration(d){
      if(ts.isVariableDeclaration(d)&&d.name.getText(ast)===variable){
       const expression=name==='text'?'(context.markers && !markerless ? `<!--x:${id}-->${value === null || value === void 0 || value === false || value === true ? "" : escapeText(String(value))}<!--/x:${id}-->` : (value === null || value === void 0 || value === false || value === true ? "" : escapeText(String(value))))':d.initializer.getText(ast);
       edits.push({start:d.initializer.getStart(ast),end:d.initializer.end,text:`auditStage==='markup'?auditReplayString('${name}'):auditRecordString('${name}',${expression})`});sites.push(name);
      }
      if(name==='text'&&ts.isVariableStatement(d)&&d.declarationList.declarations.some(x=>x.name.getText(ast)==='rendered'))edits.push({start:d.getStart(ast),end:d.end,text:''});
      ts.forEachChild(d,declaration);
     }declaration(c.body);
     if(name==='rootOpening')edits.push({start:c.body.getStart(ast)+1,end:c.body.getStart(ast)+1,text:"if(opaqueContext.targetReceiptLayers?.some(layer=>!layer.consumed))throw Error('Markup substitution cannot skip target consumption');"});
    }
   }else ts.forEachChild(c,method);
  }method(n.initializer);
 }
 if(ts.isFunctionDeclaration(n)&&n.name?.text==='renderHydratableOutput'){edits.push({start:n.body.getStart(ast)+1,end:n.body.getStart(ast)+1,text:'auditCursor=0;'});resets++;}
 ts.forEachChild(n,visit);
}visit(ast);
if(sites.length!==5||resets!==1)throw Error('Unexpected markup layout '+JSON.stringify(sites));
let output=source;for(const e of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,e.start)+e.text+output.slice(e.end);
output=`let auditStage='none',auditRecords=[],auditCursor=0,auditCounts={normal:0,replay:0};\n`+output+`
function auditRecordString(site,value){
 const index=auditCursor++,record=auditRecords[index];++auditCounts.normal;
 if(record){if(record.site!==site)throw Error('Markup order changed');}
 else {if(typeof value!=='string')throw Error('Non-string markup');auditRecords[index]={site,value};}
 return value;
}
function auditReplayString(site){
 const record=auditRecords[auditCursor++];++auditCounts.replay;
 if(!record||record.site!==site)throw Error('Markup cache/order mismatch');return record.value;
}
export function auditClearCounts(){auditCounts={normal:0,replay:0};}
export function auditReset(){auditStage='none';auditRecords=[];auditCursor=0;auditClearCounts();}
export function auditSelect(stage){if(!['none','markup'].includes(stage))throw Error('Invalid stage');if(stage==='markup'&&!auditRecords.length)throw Error('Not primed');auditStage=stage;}
export function auditRead(){return {stage:auditStage,counts:{...auditCounts},records:auditRecords.length,sites:auditRecords.reduce((result,r)=>(result[r.site]=(result[r.site]??0)+1,result),{}),ready:!!auditRecords.length};}
`;
await fs.writeFile(root+'markup-ablation/server-entry.js',output);
await fs.writeFile(root+'markup-ablation/sites.json',JSON.stringify(sites));
await fs.copyFile(root+'hydration-ablation/worker.mjs',root+'markup-ablation/worker.mjs');
let runner=(await fs.readFile(root+'tree-ablation-run.mjs','utf8')).replaceAll('tree-ablation/','markup-ablation/').replaceAll('within-worker-tree-substitution','within-worker-markup-substitution').replaceAll("'none','tree','none'","'none','markup','none'");
await fs.writeFile(root+'markup-ablation-run.mjs',runner);
let check=(await fs.readFile(root+'tree-ablation-check.mjs','utf8')).replaceAll('tree-ablation/','markup-ablation/').replace("['none','tree']","['none','markup']").replace("assert.equal(snapshot.counts.tree,stage==='tree'?0:1);","assert.ok(snapshot.records>0);assert.equal(snapshot.counts.normal,stage==='markup'?0:snapshot.records);assert.equal(snapshot.counts.replay,stage==='markup'?snapshot.records:0);");
await fs.writeFile(root+'markup-ablation-check.mjs',check);
console.log({sites});
