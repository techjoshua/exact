import hashlib
import json
import zipfile
from pathlib import Path
from statistics import mean

base=Path('.tmp/ssr-large-profile');folder=base/'markup-ablation'
data=json.loads((folder/'capture.json').read_text());assert data['complete']
rows=[]
for population in (0,1):
    blocks=[b for b in data['blocks'] if b['population']==population]
    assert [b['phase'] for b in blocks]==['none','markup','none']
    controls=[blocks[0],blocks[2]];candidate=blocks[1]
    for b in blocks:
        snapshot=b['after']['ablation'];counts=snapshot['counts'];selected=b['phase']=='markup'
        assert counts['normal' if selected else 'replay']==0
        assert counts['replay' if selected else 'normal']>0
        assert snapshot['records']==47
    def render(b):
        s=b['after']['telemetry']['statistics']['renderMs'];return s['sum']/s['count']*1000
    def loop(b):return mean(b[k]['meanMs'] for k in ('loopBefore','loopAfter'))*1000
    normal=mean(b['rps'] for b in controls)
    rows.append(dict(population=population+1,normalRps=normal,replayRps=candidate['rps'],gainPct=(candidate['rps']/normal-1)*100,normalHttpUs=mean(render(b) for b in controls),replayHttpUs=render(candidate),normalLoopUs=mean(loop(b) for b in controls),replayLoopUs=loop(candidate)))
valid=sum(b['valid'] for b in data['blocks']);errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages']);assert errors==0
(folder/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid,errors=errors),indent=2))
report=Path('docs/performance-baselines/markup-value-substitution-2026-09-10.md')
lines=['# Dynamic markup value substitution, 2026-09-10','','## Hypothesis and scope','',
'Hypothesis before measurement: replacing dynamic markup generation with recorded strings will improve HTTP throughput by roughly 5 to 10 percent if escaping and attribute generation explain a meaningful part of the remaining gap. This differs from the earlier sink substitution, which still computed every input string.', '',
'An AST transformation changes generatedSsrOperations text and attribute helpers. It records or replays string values by request-local occurrence and operation identity. The fixture executes 47 substituted values: 24 root attribute strings, 19 dynamic text strings (including any text marker), and four compiled attributes. Static-prefix/suffix concatenation, character-limit checks, individual sink writes, child traversal, component execution, state capture, hydration and surrounding ownership remain active.', '',
'Both modes reset their occurrence cursor at renderHydratableOutput. Records are rebuilt when the fixture is reset, and operation order is checked. Root attribute helpers reject pending target contributions, because skipping their consumption would be an invalid diagnostic. Dynamic input evaluation before the helpers still runs. General validation and reference effects inside substituted attribute helpers are intentionally bypassed; this fixed-fixture experiment is not a safe general cache or production optimization.', '',
'Two fresh production Node 26.8.1 string workers each run normal/replay/normal after ten seconds of HTTP warmup. Five-second blocks use two fresh drivers with 16 requests each. Adjacent controls are averaged within each worker. Isolated loops before and after each block warm and measure 10,000 renders. Workstation load can vary. Instrumented results should be compared within this experiment.', '',
'| Worker | Normal RPS | Replay RPS | Change | HTTP us, normal / replay | Isolated us, normal / replay |',
'| --- | ---: | ---: | ---: | ---: | ---: |']
for r in rows:
    lines.append(f"| {r['population']} | {r['normalRps']:,.0f} | {r['replayRps']:,.0f} | {r['gainPct']:+.2f}% | {r['normalHttpUs']:.2f} / {r['replayHttpUs']:.2f} | {r['normalLoopUs']:.2f} / {r['replayLoopUs']:.2f} |")
lines+=['',f'All {valid:,} measured responses matched the complete 4,672-byte document, with zero errors. Four ordinary/escaped document parity cases pass. Counters verify 47 values per checked render. Artifact and adapter hash guards pass. The source artifact matches the current built participant SHA-256, 6882479fc08ae551f88751a2395f44491f98e5a10f871476f5b520b5ce61e6f3. No production code changed.', '',
'This isolates dynamic markup generation across leaf and branching writers. It does not remove branching control flow, eager input construction or prepared program invocations. Effects overlap other substitutions and cannot be added. Raw results and a verified SHA-256 inventory are preserved in the adjacent archive. This is not a new full benchmark baseline.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[report,Path('.tmp/positional-leaves/data.json')]+[base/n for n in ('markup-ablation-build.mjs','markup-ablation-check.mjs','markup-ablation-run.mjs','markup-ablation-report.py','tree-ablation-run.mjs','tree-ablation-check.mjs','hydration-ablation/worker.mjs','component-forwarding-integrated/server-entry.js')]
files=sorted(set(p for p in files if p.is_file()));archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps(rows,indent=2));print(valid,'valid;',len(files),'verified files')
