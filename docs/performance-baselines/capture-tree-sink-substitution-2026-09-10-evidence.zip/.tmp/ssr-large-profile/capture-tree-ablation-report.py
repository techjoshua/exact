import hashlib
import json
import zipfile
from pathlib import Path

base=Path('.tmp/ssr-large-profile')
names=('capture-ablation','tree-ablation','sink-ablation')
summaries={name:json.loads((base/name/'summary.json').read_text()) for name in names}
assert all(s['complete'] and s['errors']==0 for s in summaries.values())
report=Path('docs/performance-baselines/capture-tree-sink-substitution-2026-09-10.md')
lines=['# Capture, tree and sink substitutions, 2026-09-10','','## Method and scope','',
'Continue the same-worker fixed-input substitution investigation using the frozen',
'integrated Node string artifact. No production code changes. Each treatment is',
'bracketed by normal execution in the same worker, with two fresh worker',
'populations. Compare each treatment with its adjacent controls, not across',
'diagnostics. Instrumentation changes normal-path timing and code optimization.', '',
'Capture blocks last three seconds; tree and sink blocks last five seconds.',
'Each worker warms HTTP for ten seconds. Two fresh drivers per block each hold',
'16 requests in flight. Isolated 10,000-render loops before/after each HTTP block',
'use their own 10,000-render warmup. Cache priming is separate for isolated loops',
'and HTTP so pathname representation is not borrowed between contexts.', '',
'## Substitution boundaries','',
'- Publish: reserve normal request-local records, then replace each published',
'  resumption tuple with its fixed precalculated tuple. Component execution and',
'  ownership remain active.',
'- Capture: also bypass schema lookup and record construction during reservation.',
'  A current request-local record array receives the cached tuples. The capture',
'  instance, options and its initial arrays still allocate. This is not complete',
'  elimination of capture setup.',
'- Tree: reuse the completed tree result and its records instead of calling',
'  renderOwnedOutput. This skips component rendering, associated allocation,',
'  capture work and render ownership together. Normal root preparation, hydration',
'  publication, document assembly and HTTP delivery remain. The priming render',
'  completed its cleanup before its result was retained.',
'- Sink: execute components and generate their write arguments normally, but',
'  discard string-sink writes and return precalculated HTML at finish. Keep sink',
'  destruction and component ownership. This removes accumulation, sink write',
'  checks and finalization work together, and changes output string reuse.', '',
'The fixture has three reservation checks, one published resumption record and',
'89 string-sink writes per render. Initial capture hypothesis was meaningful',
'pre-serialization work; the observed one-record count limits expected headroom.',
'The sink hypothesis was a much smaller effect than whole-tree replay, likely',
'under 5 percent. These are fixed-input diagnostics, not cache implementations',
'for application requests or support for removing correctness checks.', '',
'Fourteen normal/escaped complete-document parity cases pass. Stage counters',
'verify the substituted operations do not execute. All measured HTTP documents',
'match the complete 4,672-byte identity; zero errors. Artifact/adapter hashes',
'are checked and owned worker/load processes close after each experiment.', '',
'## Paired HTTP throughput','',
'| Substitution | Worker | Normal RPS | Substituted RPS | Change |',
'| --- | ---: | ---: | ---: | ---: |']
for name in names:
    for r in summaries[name]['rows']:
        lines.append(f"| {r['stage']} | {r['population']} | {r['normalRps']:,.0f} | {r['stubRps']:,.0f} | {r['gainPct']:+.2f}% |")
lines+=['','## Isolated versus HTTP render duration','',
'Microseconds per render. Normal values average adjacent controls; isolated',
'values average the before/after loops. These are elapsed render intervals, not',
'exclusive CPU or an additive stage accounting.', '',
'| Substitution | Worker | Normal isolated | Substituted isolated | Normal HTTP | Substituted HTTP |',
'| --- | ---: | ---: | ---: | ---: | ---: |']
for name in names:
    for r in summaries[name]['rows']:
        values=' | '.join(f'{r[k]:.2f}' for k in ('normalLoopUs','stubLoopUs','normalHttpUs','stubHttpUs'))
        lines.append(f"| {r['stage']} | {r['population']} | {values} |")
lines+=['','## Interpretation','',
'Capture publication is a modest contributor in this fixture. Whole-tree replay',
'removes a much larger amount of both isolated and HTTP render time, and more',
'time under HTTP. This boundary includes too much work to justify blaming a',
'specific traversal algorithm, allocator or component helper. It also changes',
'downstream memory reuse and string representation. The effects are not additive.', '',
'Keep narrowing the tree boundary into component preparation, compiled execution',
'and sink output. Do not infer that doubling throughput with a pre-rendered tree',
'is an achievable production optimization. The shared renderer must continue',
'executing the actual application with hydration and lifecycle guarantees.', '',
'These experiments do not compare against React and do not complete the broader',
'Node/Bun string/stream goal. No production optimization is accepted here.', '',
'## Evidence','']
for name in names:lines.append(f"- {name}: {summaries[name]['valid']:,} validated measured responses.")
lines+=['','The adjacent archive retains scripts, raw blocks, summaries, parity checks,',
'diagnostic and current artifacts, fixture and a verified SHA-256 inventory.',
'Workspace dependencies are not a standalone distribution.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=[report,Path('.tmp/positional-leaves/data.json'),base/'component-forwarding-integrated/server-entry.js',base/'hydration-ablation/worker.mjs',base/'hydration-ablation-run.mjs',base/'hydration-ablation-check.mjs',base/'capture-tree-ablation-analyze.py',base/'capture-tree-ablation-report.py']
for name in names:
    files+=list((base/name).glob('*'))+[base/(name+suffix) for suffix in ('-build.mjs','-run.mjs','-check.mjs')]
files=sorted(set(f for f in files if f.is_file()))
archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={f.as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in files:z.write(f,f.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(report,len(files),'verified files')
