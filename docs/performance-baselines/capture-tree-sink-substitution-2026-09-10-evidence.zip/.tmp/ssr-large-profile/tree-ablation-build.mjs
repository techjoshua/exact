import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'tree-ablation',{recursive:true});
const source=(await fs.readFile(root+'component-forwarding-integrated/server-entry.js','utf8')).replaceAll('\r\n','\n');
const ast=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const edits=[];let replaced=0;
function visit(n){
 if(ts.isFunctionDeclaration(n)&&n.name?.text==='renderHydratableOutput'){
  function inner(v){
   if(ts.isVariableDeclaration(v)){
    const name=v.name.getText(ast);
    if(name==='rendered'){
     edits.push({start:v.initializer.getStart(ast),end:v.initializer.end,text:`auditStage==='tree'?auditCache.result:(++auditCounts.tree,${v.initializer.getText(ast)})`});replaced++;
    }
    if(name==='resumptions'){
     edits.push({start:v.initializer.getStart(ast),end:v.initializer.end,text:`auditStage==='tree'?auditCache.records:${v.initializer.getText(ast)}`});
     edits.push({start:v.parent.parent.end,end:v.parent.parent.end,text:'\nif(auditCache.result===undefined){auditCache.result=result;auditCache.records=resumptions;}'});replaced++;
    }
   }
   ts.forEachChild(v,inner);
  }inner(n.body);
 }
 ts.forEachChild(n,visit);
}
visit(ast);if(replaced!==2)throw Error('Missing tree boundaries');
let output=source;for(const e of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,e.start)+e.text+output.slice(e.end);
output=`let auditStage='none',auditCache={},auditCounts={tree:0};\n`+output+`
export function auditClearCounts(){auditCounts={tree:0};}
export function auditReset(){auditStage='none';auditCache={};auditClearCounts();}
export function auditSelect(stage){if(!['none','tree'].includes(stage))throw Error('Invalid stage');if(stage!=='none'&&!auditCache.result)throw Error('Not primed');auditStage=stage;}
export function auditRead(){return {stage:auditStage,counts:{...auditCounts},ready:!!auditCache.result};}
`;
await fs.writeFile(root+'tree-ablation/server-entry.js',output);
await fs.copyFile(root+'hydration-ablation/worker.mjs',root+'tree-ablation/worker.mjs');
let runner=(await fs.readFile(root+'hydration-ablation-run.mjs','utf8')).replaceAll('hydration-ablation/','tree-ablation/').replaceAll('within-worker-hydration-stage-substitution','within-worker-tree-substitution');
runner=runner.replaceAll("'none','hydration','none','validation','none','escape','none','json','none'","'none','tree','none'").replaceAll("'none','json','none','escape','none','validation','none','hydration','none'","'none','tree','none'").replace('report.blocks.length,18','report.blocks.length,6').replace('durationMs:3000','durationMs:5000');
await fs.writeFile(root+'tree-ablation-run.mjs',runner);
let check=(await fs.readFile(root+'hydration-ablation-check.mjs','utf8')).replaceAll('hydration-ablation/','tree-ablation/').replace("['none','validation','json','escape','hydration']","['none','tree']");
check=check.replace("for(const name of ['hydration','validation','json','escape'])assert.equal(snapshot.counts[name],stage==='hydration'||stage===name&&stage!=='none'?0:1);", "assert.equal(snapshot.counts.tree,stage==='tree'?0:1);");
await fs.writeFile(root+'tree-ablation-check.mjs',check);
console.log({replaced});
