import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'sink-ablation',{recursive:true});
const source=(await fs.readFile(root+'component-forwarding-integrated/server-entry.js','utf8')).replaceAll('\r\n','\n');
const ast=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const edits=[];let replaced=0;
function visit(n){
 if(ts.isVariableDeclaration(n)&&n.name.getText(ast)==='StringProgramSink'){
  for(const m of n.initializer.members){
   const name=m.name?.getText(ast);if(!m.body)continue;
   if(name==='write'){
    edits.push({start:m.body.getStart(ast)+1,end:m.body.getStart(ast)+1,text:"if(auditStage==='sink')return;++auditCounts.write;"});replaced++;
   }
   if(name==='finish'){
    edits.push({start:m.name.getStart(ast),end:m.name.end,text:'auditOriginalFinish'});
    edits.push({start:m.end,end:m.end,text:`\nfinish(prefix=[]) {if(auditStage==='sink'){this.destroy();return auditCache.html;}++auditCounts.finish;const html=this.auditOriginalFinish(prefix);if(auditCache.html===undefined)auditCache.html=html;return html;}\n`});replaced++;
   }
  }
 }
 ts.forEachChild(n,visit);
}
visit(ast);if(replaced!==2)throw Error('Missing sink boundaries');
let output=source;for(const e of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,e.start)+e.text+output.slice(e.end);
output=`let auditStage='none',auditCache={},auditCounts={write:0,finish:0};\n`+output+`
export function auditClearCounts(){auditCounts={write:0,finish:0};}
export function auditReset(){auditStage='none';auditCache={};auditClearCounts();}
export function auditSelect(stage){if(!['none','sink'].includes(stage))throw Error('Invalid stage');if(stage!=='none'&&auditCache.html===undefined)throw Error('Not primed');auditStage=stage;}
export function auditRead(){return {stage:auditStage,counts:{...auditCounts},ready:auditCache.html!==undefined};}
`;
await fs.writeFile(root+'sink-ablation/server-entry.js',output);
await fs.copyFile(root+'hydration-ablation/worker.mjs',root+'sink-ablation/worker.mjs');
let runner=(await fs.readFile(root+'tree-ablation-run.mjs','utf8')).replaceAll('tree-ablation/','sink-ablation/').replaceAll('within-worker-tree-substitution','within-worker-sink-substitution').replaceAll("'none','tree','none'","'none','sink','none'");
await fs.writeFile(root+'sink-ablation-run.mjs',runner);
let check=(await fs.readFile(root+'tree-ablation-check.mjs','utf8')).replaceAll('tree-ablation/','sink-ablation/').replace("['none','tree']","['none','sink']").replace("assert.equal(snapshot.counts.tree,stage==='tree'?0:1);","assert.equal(snapshot.counts.write===0,stage==='sink');assert.equal(snapshot.counts.finish,stage==='sink'?0:1);");
await fs.writeFile(root+'sink-ablation-check.mjs',check);
console.log({replaced});
