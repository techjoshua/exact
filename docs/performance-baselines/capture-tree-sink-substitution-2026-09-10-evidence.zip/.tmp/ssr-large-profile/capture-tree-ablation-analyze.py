import json
from pathlib import Path
from statistics import mean

base=Path('.tmp/ssr-large-profile')
for experiment in ('capture-ablation','tree-ablation','sink-ablation'):
    folder=base/experiment
    if not (folder/'capture.json').exists():continue
    data=json.loads((folder/'capture.json').read_text())
    rows=[]
    for population in (0,1):
        blocks=[b for b in data['blocks'] if b['population']==population]
        for i,b in enumerate(blocks):
            if b['phase']=='none' or i+1==len(blocks):continue
            controls=[blocks[i-1],blocks[i+1]]
            assert all(c['phase']=='none' for c in controls)
            counts=b['after']['ablation']['counts']
            if experiment=='capture-ablation':
                assert (counts['reserve']==0)==(b['phase']=='capture')
                assert counts['publish']==0
                assert b['after']['ablation']['records']==1
            elif experiment=='sink-ablation':assert counts['write']==0 and counts['finish']==0
            else:assert counts['tree']==0
            def render(x):
                s=x['after']['telemetry']['statistics']['renderMs']
                return s['sum']/s['count']*1000
            def loop(x):return mean(x[k]['meanMs'] for k in ('loopBefore','loopAfter'))*1000
            normal=mean(c['rps'] for c in controls)
            rows.append(dict(population=population+1,stage=b['phase'],normalRps=normal,
                             stubRps=b['rps'],gainPct=(b['rps']/normal-1)*100,
                             normalHttpUs=mean(render(c) for c in controls),stubHttpUs=render(b),
                             normalLoopUs=mean(loop(c) for c in controls),stubLoopUs=loop(b)))
    summary=dict(complete=data['complete'],rows=rows,valid=sum(b['valid'] for b in data['blocks']),
                 errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages']))
    assert summary['errors']==0
    if data['complete']:
        assert len(rows)==(4 if experiment=='capture-ablation' else 2)
        (folder/'summary.json').write_text(json.dumps(summary,indent=2))
    print(experiment,json.dumps(summary,indent=2))
