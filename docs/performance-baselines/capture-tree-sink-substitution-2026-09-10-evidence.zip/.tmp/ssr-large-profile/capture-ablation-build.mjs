import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'capture-ablation',{recursive:true});
const source=(await fs.readFile(root+'component-forwarding-integrated/server-entry.js','utf8')).replaceAll('\r\n','\n');
const ast=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const edits=[];let replaced=0;
function visit(n){
 if(ts.isVariableDeclaration(n)&&n.name.getText(ast)==='DirectSsrResumptionCapture'){
  for(const m of n.initializer.members){
   const name=m.name?.getText(ast);if(!m.body)continue;
   let prefix;
   if(name==='reserveDirect')prefix=`if(auditStage==='capture'){if(!contract.resumption)return undefined;const token=this.records.length;this.records.push(auditCache.records[token]);return token;}++auditCounts.reserve;`;
   if(name==='publishDirect')prefix=`if(auditStage==='capture'||auditStage==='publish'){this.records[token]=auditCache.records[token];return;}++auditCounts.publish;`;
   if(name==='serializedRecords')prefix=`if(auditCache.records===undefined)auditCache.records=this.records.map(record=>record.slice());`;
   if(prefix){edits.push({start:m.body.getStart(ast)+1,end:m.body.getStart(ast)+1,text:prefix});replaced++;}
  }
 }
 ts.forEachChild(n,visit);
}
visit(ast);if(replaced!==3)throw Error('Missing capture boundaries');
let output=source;for(const e of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,e.start)+e.text+output.slice(e.end);
output=`let auditStage='none',auditCache={},auditCounts={reserve:0,publish:0};\n`+output+`
export function auditClearCounts(){auditCounts={reserve:0,publish:0};}
export function auditReset(){auditStage='none';auditCache={};auditClearCounts();}
export function auditSelect(stage){if(!['none','publish','capture'].includes(stage))throw Error('Invalid stage');if(stage!=='none'&&!auditCache.records)throw Error('Not primed');auditStage=stage;}
export function auditRead(){return {stage:auditStage,counts:{...auditCounts},records:auditCache.records?.length,ready:!!auditCache.records};}
`;
await fs.writeFile(root+'capture-ablation/server-entry.js',output);
await fs.copyFile(root+'hydration-ablation/worker.mjs',root+'capture-ablation/worker.mjs');
let runner=(await fs.readFile(root+'hydration-ablation-run.mjs','utf8')).replaceAll('hydration-ablation/','capture-ablation/').replaceAll('within-worker-hydration-stage-substitution','within-worker-capture-substitution');
runner=runner.replaceAll("'none','hydration','none','validation','none','escape','none','json','none'","'none','capture','none','publish','none'").replaceAll("'none','json','none','escape','none','validation','none','hydration','none'","'none','publish','none','capture','none'").replace('report.blocks.length,18','report.blocks.length,10');
await fs.writeFile(root+'capture-ablation-run.mjs',runner);
let check=(await fs.readFile(root+'hydration-ablation-check.mjs','utf8')).replaceAll('hydration-ablation/','capture-ablation/').replace("['none','validation','json','escape','hydration']","['none','publish','capture']");
check=check.replace("for(const name of ['hydration','validation','json','escape'])assert.equal(snapshot.counts[name],stage==='hydration'||stage===name&&stage!=='none'?0:1);", "assert.ok(snapshot.records>0);assert.equal(snapshot.counts.reserve===0,stage==='capture');assert.equal(snapshot.counts.publish===0,stage!=='none');");
await fs.writeFile(root+'capture-ablation-check.mjs',check);
console.log({replaced});
