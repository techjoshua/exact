import fs from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
const original=await import(pathToFileURL(resolve(root+'component-forwarding-integrated/server-entry.js')));
const diagnostic=await import(pathToFileURL(resolve(root+'capture-ablation/server-entry.js')));
const fixture=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));
const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
const rows=[];
for(const escaped of [false,true]){
 const data=structuredClone(fixture);if(escaped)data.incidents[0].title+=' </script>\u2028\u2029\ud800';
 const expected=await original.renderParticipant(data,'/incidents/inc-101',options);
 for(const stage of ['none','publish','capture']){
  diagnostic.auditReset();assert.equal(await diagnostic.renderParticipant(data,'/incidents/inc-101',options),expected);
  diagnostic.auditSelect(stage);diagnostic.auditClearCounts();
  assert.equal(await diagnostic.renderParticipant(data,'/incidents/inc-101',options),expected);
  const snapshot=diagnostic.auditRead();
  assert.ok(snapshot.records>0);assert.equal(snapshot.counts.reserve===0,stage==='capture');assert.equal(snapshot.counts.publish===0,stage!=='none');
  rows.push({escaped,stage,bytes:Buffer.byteLength(expected),...snapshot});
 }
}
await fs.writeFile(root+'capture-ablation/checks.json',JSON.stringify(rows,null,2));console.log({matched:rows.length});
