import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
let source=readFileSync(dir+'callback-current.mjs','utf8');
const before='value.length >= 16 && !state.path ? readPositionalProjector(schema[1]) : void 0';
if(source.split(before).length!==2)throw Error('Unexpected projector selection');
source=source.replace(before,'void 0');
writeFileSync(dir+'projector-interpreter.mjs',source);
writeFileSync(dir+'projector-interpreter-run.mjs',readFileSync(dir+'segments-only-run.mjs','utf8').replaceAll('segments-only','projector-interpreter'));
