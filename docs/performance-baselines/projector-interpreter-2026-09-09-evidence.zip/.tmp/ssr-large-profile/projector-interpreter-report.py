import hashlib,json,pathlib,zipfile
root=pathlib.Path('.'); work=root/'.tmp/ssr-large-profile'
rows=json.loads((work/'projector-interpreter-results.json').read_text(encoding='utf-8'))
summary=[]
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  pairs=[]
  for round in range(2):
   selected=[r for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['round']==round]
   a=next(r for r in selected if r['variant']=='callback-current');b=next(r for r in selected if r['variant']=='projector-interpreter')
   assert a['hash']==b['hash']
   pairs.append((b['usPerRender']/a['usPerRender']-1)*100)
  summary.append(dict(runtime=runtime,mode=mode,changes=pairs))
table='\n'.join(f"| {s['runtime']} | {s['mode']} | {s['changes'][0]:+.2f}% | {s['changes'][1]:+.2f}% |" for s in summary)
dest=root/'docs/performance-baselines/projector-interpreter-2026-09-09'
dest.with_suffix('.json').write_text(json.dumps(dict(summary=summary,rows=rows),indent=2)+'\n',encoding='utf-8')
doc='''# Generated projection versus existing interpreter

Date: 2026-09-09. Production unchanged; retain generated projectors.

## Hypothesis

Generated positional projectors unroll schema field access but still call generic validation for
each primitive. Before adding further generated code, test the assumption that the generated lane
outperforms the existing positional interpreter on the current build. A neutral result would favor
investigating simplification; an interpreter regression would support keeping specialization.

## Experiment

The candidate changes only selection of the generated projector in the retained callback-current
bundle to undefined, invoking the existing interpreter instead. It preserves ordinary validation,
positional output, property reads and ownership checks, budgets, and escaping. The interpreter uses
its existing shallow ancestor tracker, while the generated lane requires a native Set. Therefore
this compares the complete existing lanes, not unrolling alone. No public contract is changed.

Sixteen fresh processes cover Node/Bun and string/consumed stream, with two reversed-order pairs
per cell. Each uses NODE_ENV=production, 5,000 warmups, 12,000 measured renders, the 96-incident
fixture, a complete application-authored document, and empty client tags. Both runtimes use the
same portable bundle. Response.text() consumes streams. All paired document hashes match.

## Results

Positive means the interpreter candidate takes longer. Two pairs are preliminary observations
on a variable-load workstation, not precise estimates. No HTTP or browser timing is measured.

| Runtime | Mode | Pair 1 time change | Pair 2 time change |
| --- | --- | ---: | ---: |
'''+table+'''

Node results are mixed or nearly flat. Bun strings favor generated projection in both pairs.
This provides no case for disabling generated projectors globally. It also does not demonstrate
a large universal benefit from generated projection. Further specialization needs its own measured
hypothesis rather than assuming compiler-generated code is necessarily faster.

Production remains unchanged. Fixture output equality does not replace failure and lifecycle
tests if a lane is redesigned. No package/browser tests were run for this diagnostic prototype.
No React population was run and no new React parity claim is made. The overall goal remains unmet.

The archive contains frozen bundles, fixed input, worker, builder, runner, raw results, reporter,
and a SHA-256 manifest.
'''
dest.with_suffix('.md').write_text(doc,encoding='utf-8')
files=[work/name for name in ['callback-current.mjs','projector-interpreter.mjs','long-worker.mjs','projector-interpreter-build.mjs','projector-interpreter-run.mjs','projector-interpreter-results.json','projector-interpreter-report.py','segments-only-run.mjs']]+[root/'.tmp/positional-leaves/data.json']
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p))
 z.writestr('manifest.json',json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(table)
print('Verified',archive)
