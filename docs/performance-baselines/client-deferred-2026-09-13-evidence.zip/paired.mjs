import {chromium} from 'playwright';
import {writeFile} from 'node:fs/promises';
import {startClientBenchmarkHarness} from '../../framework-comparison/src/client-benchmark-harness.mjs';
import {measureRetainedMemory} from '../../framework-comparison/src/browser-memory.mjs';
import {waitForFirstContentfulPaint} from '../../framework-comparison/src/paint-timing.mjs';
import {installBrowserVitals,readBrowserVitals} from '../../framework-comparison/src/browser-vitals.mjs';
import {hashSemanticResponse} from '../../framework-comparison/src/artifact-integrity.mjs';
process.env.NODE_ENV='production';
const participants=[{id:'exact',directory:'exact',artifact:'dist',url:'http://127.0.0.1:4401'},{id:'sveltekit',directory:'sveltekit',artifact:'build/client',url:'http://127.0.0.1:4403'}];
const harness=await startClientBenchmarkHarness(participants);let browser;const rows=[];
try {browser=await chromium.launch();for(const p of participants)await measureBrowserSample(browser,p);for(let i=0;i<30;i++)for(const p of i%2?[...participants].reverse():participants){rows.push({id:p.id,round:i,...await measureBrowserSample(browser,p)});}await writeFile('.tmp/client-deferred-2026-09-13/'+process.argv[2]+'.json',JSON.stringify({harness:harness.evidence(),rows},null,2));console.log('Completed '+process.argv[2]);}finally{try{await browser?.close();}finally{await harness.close();}}
async function measureBrowserSample(browserInstance, participant) {
	await resetService({});
	const context = await browserInstance.newContext();
	try {
		const page = await context.newPage();
		const browserErrors = [];
		const failedRequests = [];
		page.on('console', (message) => {
			if (message.type() === 'error') browserErrors.push(message.text());
		});
		page.on('pageerror', (error) => browserErrors.push(error.message));
		page.on('requestfailed', (request) =>
			failedRequests.push(`${request.method()} ${request.url()}: ${request.failure()?.errorText}`)
		);
		await page.addInitScript(installInteractionTiming);
		await page.addInitScript(installBrowserVitals);
		const session = await context.newCDPSession(page);
		await session.send('Network.enable');
		await session.send('Network.setCacheDisabled', { cacheDisabled: true });
		await session.send('Performance.enable');
		// EventSource intentionally keeps the network active, so semantic readiness gates the sample.
		await page.goto(`${participant.url}/incidents/inc-100`, { waitUntil: 'domcontentloaded' });
		await page.getByRole('heading', { name: 'Checkout authorization failures' }).waitFor();
		const firstContentfulPaintMs = await page.evaluate(waitForFirstContentfulPaint);
		await page.waitForLoadState('load');
		const navigation = await page.evaluate(() => {
			const entry = performance.getEntriesByType('navigation')[0];
			const scripts = performance
				.getEntriesByType('resource')
				.filter(
					(resource) => resource.initiatorType === 'script' || /\.m?js(?:$|\?)/.test(resource.name)
				)
				.reduce((sum, resource) => sum + (resource.transferSize || 0), 0);
			return {
				durationMs: entry?.duration ?? null,
				domContentLoadedMs: entry?.domContentLoadedEventEnd ?? null,
				loadEventMs: entry?.loadEventEnd ?? null,
				transferredScriptBytes: scripts
			};
		});
		navigation.firstContentfulPaintMs = firstContentfulPaintMs;
		try {
			await page.locator('.connection').getByText('Live service', { exact: true }).waitFor();
		} catch (error) {
			throw new Error(
				`Live service readiness failed for ${participant.id}. ` +
					`Requests: ${failedRequests.join(' | ') || '<none>'}. ` +
					`Browser: ${browserErrors.join(' | ') || '<none>'}.`,
				{ cause: error }
			);
		}
		await page.getByRole('button', { name: 'Claim incident' }).click();
		await page.getByText('Alex Chen', { exact: true }).waitFor();
		await page.getByText('Version 2', { exact: true }).waitFor();
		const timing = await page.evaluate(() => globalThis.__frameworkComparisonTiming);
		if (timing?.optimisticFeedbackMs == null || timing.settlementMs == null)
			throw new Error(`Missing browser interaction timing for ${participant.id}`);
		// Collect retained memory after interaction timing. A forced collection immediately before the
		// click would turn optimistic feedback into a cold-allocation recovery measurement.
		const memory = await measureRetainedMemory(session);
		const vitals = await page.evaluate(readBrowserVitals);
		const semanticResponse = await page.evaluate(() => ({
			heading: document.querySelector('h1, h2')?.textContent?.trim() ?? null,
			owner: document.querySelector('.facts > div:first-child strong')?.textContent?.trim() ?? null,
			version: document.querySelector('.version')?.textContent?.trim() ?? null
		}));
		if (browserErrors.length || failedRequests.length)
			throw new Error(`${participant.id}: ${[...browserErrors, ...failedRequests].join(' | ')}`);
		return {
			navigation,
			vitals,
			heapBytes: memory.jsHeapUsedBytes,
			memory,
			optimisticFeedbackMs: timing.optimisticFeedbackMs,
			settlementMs: timing.settlementMs,
			phasesMs: timing.phasesMs,
			responseHash: hashSemanticResponse(semanticResponse)
		};
	} finally {
		await context.close();
	}
}

/** Installs a participant-neutral click-to-visible-mutation clock in the page's own time domain. */
function installInteractionTiming() {
	const timing = {
		startedAt: null,
		optimisticFeedbackMs: null,
		settlementMs: null,
		phasesMs: {}
	};
	globalThis.__frameworkComparisonTiming = timing;
	const mark = (phase) => {
		if (timing.startedAt === null || timing.phasesMs[phase] !== undefined) return;
		timing.phasesMs[phase] = performance.now() - timing.startedAt;
	};

	const nativeFetch = globalThis.fetch;
	globalThis.fetch = (...args) => {
		const input = args[0];
		const url = typeof input === 'string' ? input : input instanceof Request ? input.url : '';
		if (url.endsWith('/claim')) mark('request-dispatched');
		return nativeFetch(...args).then((response) => {
			if (url.endsWith('/claim')) mark('http-headers-received');
			return response;
		});
	};
	const nativeResponseJson = Response.prototype.json;
	Response.prototype.json = function () {
		return nativeResponseJson.call(this).then((value) => {
			if (this.url.endsWith('/claim')) mark('http-json-decoded');
			return value;
		});
	};
	const observedEventSources = new WeakSet();
	const nativeAddEventListener = EventSource.prototype.addEventListener;
	EventSource.prototype.addEventListener = function (type, listener, options) {
		if (type === 'incident' && !observedEventSources.has(this)) {
			observedEventSources.add(this);
			nativeAddEventListener.call(this, type, () => mark('sse-incident-received'));
		}
		return nativeAddEventListener.call(this, type, listener, options);
	};
	document.addEventListener(
		'click',
		(event) => {
			const button = event.target instanceof Element ? event.target.closest('button') : null;
			if (button?.textContent?.trim() !== 'Claim incident' || timing.startedAt !== null) return;
			timing.startedAt = performance.now();
		},
		true
	);
	new MutationObserver(() => {
		if (timing.startedAt === null) return;
		const now = performance.now();
		const owner = document.querySelector('.facts > div:first-child strong')?.textContent?.trim();
		const version = document.querySelector('.version')?.textContent?.trim();
		if (timing.optimisticFeedbackMs === null && owner === 'Alex Chen') {
			timing.optimisticFeedbackMs = now - timing.startedAt;
			timing.phasesMs['optimistic-dom-visible'] ??= timing.optimisticFeedbackMs;
		}
		if (timing.settlementMs === null && version === 'Version 2') {
			timing.settlementMs = now - timing.startedAt;
			timing.phasesMs['authoritative-dom-visible'] ??= timing.settlementMs;
		}
	}).observe(document, { childList: true, characterData: true, subtree: true });
}

async function resetService(body) {
	const response = await fetch('http://127.0.0.1:4310/__benchmark/reset', {
		method: 'POST',
		headers: { 'content-type': 'application/json', 'x-benchmark-control': 'fixture-reset' },
		body: JSON.stringify(body)
	});
	if (!response.ok) throw new Error(`Fixture reset failed with ${response.status}`);
}

