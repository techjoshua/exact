import {spawnSync} from 'node:child_process';
import {existsSync,mkdirSync,readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const dir='.tmp/ssr-large-profile/current-cpu';mkdirSync(dir,{recursive:true});
const results=existsSync(dir+'/results.json')?JSON.parse(readFileSync(dir+'/results.json','utf8')):[];
for(const scenario of ['small','large'])for(const variant of ['callback-current','react']){
 if(results.some(r=>r.variant===variant&&r.scenario===scenario))continue;
 const entry=variant==='react'?'framework-comparison/participants/react/dist-server/server-entry.js':`.tmp/ssr-large-profile/${variant}.mjs`;
 const r=spawnSync('node',[`--cpu-prof`,`--cpu-prof-dir=${dir}`,`--cpu-prof-name=${variant}-${scenario}.cpuprofile`,'.tmp/ssr-large-profile/long-worker.mjs',entry,'string',scenario,'50000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status)throw Error(r.stderr||r.stdout);
 const row={variant,artifactSha256:createHash('sha256').update(readFileSync(entry)).digest('hex'),...JSON.parse(r.stdout)};
 results.push(row);writeFileSync(dir+'/results.json',JSON.stringify(results,null,2));console.log(variant,scenario,row.usPerRender.toFixed(2));
}
