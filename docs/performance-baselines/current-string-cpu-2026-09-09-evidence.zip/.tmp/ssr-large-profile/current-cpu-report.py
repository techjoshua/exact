import hashlib,json,pathlib,zipfile
root=pathlib.Path('.');work=root/'.tmp/ssr-large-profile';directory=work/'current-cpu'
rows=json.loads((directory/'results.json').read_text());profiles=json.loads((directory/'summary.json').read_text())
assert len(rows)==4
controls=json.loads((work/'callback-current-results.json').read_text())
for r in rows:
 matches=[c for c in controls if c['variant']==r['variant'] and c['scenario']==r['scenario'] and c['mode']=='string']
 assert matches and all(c['hash']==r['hash'] for c in matches)
dest=root/'docs/performance-baselines/current-string-cpu-2026-09-09'
dest.with_suffix('.json').write_text(json.dumps(dict(runs=rows,profiles=profiles),indent=2)+'\n',encoding='utf-8')
tables=[]
for p in profiles:
 table='\n'.join(f"| {r['function'] or '(anonymous at line '+str(r['line'])+')'} | {r['percent']:.1f}% |" for r in p['top'][:10])
 tables.append('## '+p['profile']+'\n\n| Sampled leaf frame | Self time share |\n| --- | ---: |\n'+table)
doc='''# Current Node string CPU profiles

Date: 2026-09-09. Diagnostic only; no production change.

## Purpose and method

The root-attribute audit found string accumulation already in use, not an attribute array that
could simply be removed. A fresh CPU profile tests whether the earlier allocation ranking also
identifies dominant execution time and directs the next renderer experiment.

Four fresh Node 26.8.1 processes cover retained eXact and React, three/96-incident string renders.
Each runs with NODE_ENV=production and --cpu-prof, using 5,000 warmups and 50,000 measured renders.
The profile includes startup and warmup; it is not scoped exclusively to the measured loop.
Each framework renders its full authored document with empty client tags. Response hashes match
the earlier corresponding control fixture. React uses its actual Node artifact. An initial missing
temporary React artifact path failed before rendering; the runner was corrected to the installed
participant artifact and resumed without repeating the successful eXact small capture.

Samples are weighted by timeDeltas and attributed to their leaf frame. Self-time percentages are
not inclusive function cost, allocation quantities, or exact microseconds per request. Generated
and inlined work can move attribution. Profiles perturb execution and are not substitutes for
paired uninstrumented throughput measurements. No HTTP sockets or browser work are measured.

'''+ '\n\n'.join(tables)+'''

## Interpretation

Garbage collection represents approximately 11% of sampled eXact time in both sizes. The small
profile highlights prepared server programs, opaque operations, and fragment receipt creation,
alongside positional validation and JSON serialization. Large root attribute rendering has a
smaller CPU share than its earlier allocation ranking might suggest. React spends substantial
sampled time on escaping, element traversal, and output accumulation.

The next concrete target is intermediate server carrier construction, especially on the small
string workload where Node HTTP parity remains furthest away. Existing issuer scopes must remain:
an apparently leaf-only result can still construct and discard children with scheduled tasks.
The profile does not authorize removing task ownership, validation, or cleanup. Eliminating GC
entirely is not realistic, and its sampled share is not a guaranteed recoverable speedup.

The current implementation remains retained. No package/browser tests were run for this diagnostic.
The overall performance goal is unmet. The archive preserves CPU profiles, weighted summaries,
runner, worker, fixed input, framework artifacts, and hashes. React dependency execution requires
the locked workspace; its manifest versions are included.
'''
dest.with_suffix('.md').write_text(doc,encoding='utf-8')
files=list(directory.glob('*'))+[work/'current-cpu-run.mjs',work/'current-cpu-summary.py',work/'current-cpu-report.py',work/'long-worker.mjs',work/'callback-current-results.json',root/'.tmp/positional-leaves/data.json']+[root/r['entry'] for r in rows]+[root/'framework-comparison/node_modules/react/package.json',root/'framework-comparison/node_modules/react-dom/package.json']
files=sorted(set(files))
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps({p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print('Verified',archive)
