import collections,json,pathlib
directory=pathlib.Path('.tmp/ssr-large-profile/current-cpu');summary=[]
for path in sorted(directory.glob('*.cpuprofile')):
 data=json.loads(path.read_text(encoding='utf-8'));nodes={n['id']:n for n in data['nodes']};weights=collections.Counter()
 for node,delta in zip(data['samples'],data['timeDeltas']):
  frame=nodes[node]['callFrame'];weights[(frame['functionName'],frame['url'],frame['lineNumber']+1)]+=delta
 total=sum(weights.values());top=[dict(function=k[0],url=k[1],line=k[2],sampledMs=v/1000,percent=v/total*100) for k,v in weights.most_common(18)]
 summary.append(dict(profile=path.name,totalSampledMs=total/1000,top=top))
 print(path.name,[(r['function'],round(r['percent'],1)) for r in top[:10]])
(directory/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
