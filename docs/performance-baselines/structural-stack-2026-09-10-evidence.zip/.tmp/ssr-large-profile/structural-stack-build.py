from pathlib import Path
p=Path('.tmp/ssr-large-profile');out=p/'structural-stack';out.mkdir()
code=r'''
/** Diagnostic explicit stack for structural carriers; component writers retain their normal engine. */
class AuditStackChildren {
 constructor(context,children,target){this.context=context;this.sink=context.writerSink;this.target=target;this.frames=[{children,index:0,previous:false,owned:false,stage:0,closing:'',marked:false}];}
 render(){try{const value=this.run();return value instanceof Promise?value.catch(error=>this.fail(error)):value;}catch(error){return this.fail(error);}}
 fail(error){while(this.frames.length){const f=this.frames.pop();if(f.owned)leaveSsrTreeDepth(this.context);}throw error;}
 writeMarker(text){if(text){this.context.outputSink?.accountKnown(text,text.length);this.sink.write(text);}}
 append(frame,result){let html=result.html;if(this.context.textSeparators&&result.text&&frame.previous)html='<!-- -->'+html;if(html!=='')this.sink.write(html);frame.previous=result.text;}
 run(){
  while(this.frames.length){
   const frame=this.frames[this.frames.length-1];
   if(frame.stage===0&&frame.index<frame.children.length){
    const child=frame.children[frame.index++];
    const range=readPreparedServerChildRange(child);
    const list=range?undefined:readServerList(child);
    const keyed=range||list?undefined:readPreparedServerKeyedChild(child);
    const program=keyed?readPreparedServerRenderProgram(keyed.value):undefined;
    if(range||list||(keyed&&(!program||program.program.ssrHost==='script'))){
     countSsrNode(this.context);enterSsrTreeDepth(this.context);
     const next={children:[],index:0,previous:false,owned:true,stage:0,closing:'',marked:!!this.context.markers};this.frames.push(next);
     let id='';
     if(range)next.children=normalizeRenderResult(unwrap(range.value));
     else if(list){next.children=list.children;id=markerId(this.context,'fragment',undefined,list.key);}
     else{next.children=[keyed.value];id=markerId(this.context,'item',undefined,keyed.key);}
     if(next.marked){const item=id.startsWith('item:')?id.slice(5):undefined;const opening=item===undefined?(id?`<!--exact:${id}-->`:'<!--x-->'):`<!--i:${item}-->`;next.closing=item===undefined?(id?`<!--/exact:${id}-->`:'<!--/x-->'):`<!--/i:${item}-->`;this.writeMarker(opening);const ready=this.sink.ready();if(ready instanceof Promise)return ready.then(()=>this.run());}
     continue;
    }
    const value=renderChildWithTarget(this.context,child,this.target);
    if(value instanceof Promise)return awaitSsrProgramSink(this.sink,value).then(result=>{this.append(frame,result);const ready=this.sink.ready();return ready instanceof Promise?ready.then(()=>this.run()):this.run();});
    this.append(frame,value);const ready=this.sink.ready();if(ready instanceof Promise)return ready.then(()=>this.run());continue;
   }
   if(frame.stage===0){frame.stage=1;if(frame.marked){const ready=this.sink.ready();if(ready instanceof Promise)return ready.then(()=>this.run());}}
   if(frame.stage===1){frame.stage=2;if(frame.marked){this.writeMarker(frame.closing);const ready=this.sink.ready();if(ready instanceof Promise)return ready.then(()=>this.run());}}
   this.frames.pop();if(frame.owned)leaveSsrTreeDepth(this.context);if(this.frames.length){this.frames[this.frames.length-1].previous=false;const ready=this.sink.ready();if(ready instanceof Promise)return ready.then(()=>this.run());}
  }
  return '';
 }
}
'''
(out/'stack.js.txt').write_text(code)
for filename in ['server-entry.js','bun-server-entry.js']:
 src=(p/'conditional-emission'/filename).read_text()
 needle='return new ChildrenOutput(context, children, new SsrOperationTarget(context, parent, options, hasComponentAncestor, renderChildren)).render();'
 assert src.count(needle)==1
 replacement='return new (context.writerSink ? AuditStackChildren : ChildrenOutput)(context, children, new SsrOperationTarget(context, parent, options, hasComponentAncestor, renderChildren)).render();'
 (out/filename).write_text(src.replace(needle,replacement)+code)
check=(p/'structural-detail-check.mjs').read_text().replace('structural-detail','structural-stack')
check=check.replace('data.incidents[1]',"data.incidents.find(item=>item.id==='inc-101')")
(p/'structural-stack-check.mjs').write_text(check)
limits=(p/'structural-detail-limits.mjs').read_text().replace('structural-detail','structural-stack');(p/'structural-stack-limits.mjs').write_text(limits)
