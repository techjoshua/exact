import fs from 'node:fs/promises';import {resolve} from 'node:path';import {pathToFileURL} from 'node:url';import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';const mods=[];
const extra=`
export async function auditStackBehavior({markers=true,separators=true,pressure=false,failWrite=0,failDrain=0,depth=4,maxDepth=100}){
 const context=createSsrContext({markers,textSeparators:separators,maxTreeDepth:maxDepth,maxTreeNodes:100000});let writes=[],pending=false,drains=0;
 const sink={write(html){if(pending)throw Error('Write before drain');if(writes.length+1===failWrite)throw Error('write-failed');writes.push(html);if(pressure){const n=++drains;pending=Promise.resolve().then(()=>{pending=false;if(n===failDrain)throw Error('drain-failed');});}},ready(){return pending||undefined;},flush(){return this.ready();}};
 context.writerSink=sink;let value=createServerList(['alpha','beta',null,'gamma'],'list');for(let i=0;i<depth;i++)value=createPreparedServerChildRange([value,'tail']);
 let error;try{await renderChildren(context,[value,'last'],undefined,{markers,textSeparators:separators});}catch(e){error={name:e.name,message:e.message};}
 return {writes,error,depth:context.traversalDepth,nodes:context.traversedNodes};
}
`;
for(const name of ['conditional-emission','structural-stack']){const src=await fs.readFile(root+name+'/server-entry.js','utf8');const file=root+'structural-stack/'+name+'-probe.js';await fs.writeFile(file,src+extra);mods.push(await import(pathToFileURL(resolve(file))));}
const rows=[];for(const markers of [false,true])for(const pressure of [false,true])for(const fault of [{},{failWrite:3},{failDrain:2},{maxDepth:3}]){const options={markers,pressure,...fault};const a=await mods[0].auditStackBehavior(options),b=await mods[1].auditStackBehavior(options);assert.deepEqual(b,a);assert.equal(b.depth,0);rows.push({options,...b});}
await fs.writeFile(root+'structural-stack/lifecycle-checks.json',JSON.stringify(rows,null,2));console.log('Matched structural ordering, pressure, failures and depth cleanup:',rows.length);
