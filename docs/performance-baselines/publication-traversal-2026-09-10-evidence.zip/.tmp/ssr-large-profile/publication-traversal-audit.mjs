import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';
const raw=await fs.readFile(root+'direct-execution-integrated/server-entry.js');
assert.equal(createHash('sha256').update(raw).digest('hex'),'2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18');
let source=raw.toString();
for(const [name,signature] of [['generic','function validateValue(value, depth, state, shape = 0) {'],['positional','function validatePositionalValue(value, schema, depth, state) {']]){
 assert.equal(source.split(signature).length,2);
 source=source.replace(signature,signature+`\n auditVisit('${name}',value);`);
}
const reg='function registerPositionalProjector(schema, version, project) {';
assert.equal(source.split(reg).length,2);
source=source.replace(reg,reg+'\n const original=project;project=function(value,...args){auditVisit("generated",value);return original(value,...args);};');
const payload='const payload = serializeValidatedHydrationPayload(compacted, reactiveCollections);';
assert.equal(source.split(payload).length,2);
source=source.replace(payload,'auditEnvelope=compacted;\n\t'+payload);
source='let auditVisits=new Map(),auditCalls={},auditEnvelope;\nfunction auditVisit(kind,value){auditCalls[kind]=(auditCalls[kind]??0)+1;if(value&&typeof value==="object"){let counts=auditVisits.get(value);if(!counts)auditVisits.set(value,counts={});counts[kind]=(counts[kind]??0)+1;}}\n'+source;
source+='\nexport function auditReset(){auditVisits=new Map();auditCalls={};auditEnvelope=undefined;}\nexport function auditRead(){return {calls:auditCalls,visits:[...auditVisits.values()],envelope:auditEnvelope};}\n';
const entry=root+'publication-traversal-entry.mjs';await fs.writeFile(entry,source);
const mod=await import(pathToFileURL(resolve(entry)));
const control=await import(pathToFileURL(resolve(root+'direct-execution-integrated/server-entry.js')));
const results=[];
for(const scenario of ['small','large']){
 const data=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));
 if(scenario==='large')data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
 const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
 const expected=await control.renderParticipant(data,'/incidents/inc-101',options);
 mod.auditReset();const actual=await mod.renderParticipant(data,'/incidents/inc-101',options);assert.equal(actual,expected);
 const audit=mod.auditRead();const repeated=audit.visits.filter(counts=>Object.values(counts).some(n=>n>1));
 let remaining=audit.envelope[1]&~16,index=2;const fields=[];
 while(remaining){const bit=remaining&-remaining;remaining&=remaining-1;const value=audit.envelope[index++];fields.push({bit,jsonBytes:Buffer.byteLength(JSON.stringify(value)),arrayLength:Array.isArray(value)?value.length:undefined});}
 results.push({scenario,runtime:process.versions.bun??process.version,calls:audit.calls,uniqueVisitedObjects:audit.visits.length,repeatedObjectCounts:repeated,delegatedObjects:audit.visits.filter(c=>Object.keys(c).length>1).length,envelopeMask:audit.envelope[1],fields,envelopeJsonBytes:Buffer.byteLength(JSON.stringify(audit.envelope)),documentBytes:Buffer.byteLength(actual),documentHash:createHash('sha256').update(actual).digest('hex')});
}
await fs.writeFile(root+'publication-traversal-'+(process.versions.bun?'bun':'node')+'.json',JSON.stringify(results,null,2));
console.log(JSON.stringify(results,null,2));
