import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {setPriority} from 'node:os';
setPriority(0,10);
const base='.tmp/ssr-large-profile/';
const file=process.versions.bun?'bun-server-entry.js':'server-entry.js';
const modules=await Promise.all(['conditional-emission','bound-ssr-operations'].map(folder=>import(pathToFileURL(resolve(base+folder+'/'+file)))));
const fixture=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));
const rows=[];
for(const mode of ['string','stream'])for(let test=0;test<8;test++){
 const data=structuredClone(fixture);data.incidents.find(item=>item.id==='inc-101').title='Changed < & café 🚀 '+test;
 if(test===5)data.incidents.find(item=>item.id==='inc-101').comments=[];
 const options={clientTags: test===0?'':Array.from({length:test},(_,i)=>`<script type="module" src="/assets/${i%2}?q=&amp;.js"></script><link rel="stylesheet" href="/assets/${i}.css">`).join('')};
 const path=test===7?'/incidents/missing':'/incidents/inc-101';
 const results=[];
 for(const mod of modules)results.push(process.versions.bun?await (await mod.renderParticipantBunResponse(data,path,undefined,options,mode)).text():mode==='string'?await mod.renderParticipant(data,path,options):await new Response(await mod.renderParticipantStream(data,path,options)).text());
 assert.equal(results[0],results[1]);rows.push({mode,test,bytes:Buffer.byteLength(results[1])});
}
const runtime=process.versions.bun?'bun':'node';
await fs.writeFile(base+'bound-ssr-operations/'+runtime+'-checks.json',JSON.stringify(rows,null,2));
console.log(JSON.stringify({runtime,matched:rows.length}));
