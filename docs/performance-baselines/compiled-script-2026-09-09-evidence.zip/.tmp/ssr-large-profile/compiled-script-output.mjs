import {readFile,writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const data=JSON.parse(await readFile('.tmp/positional-leaves/data.json','utf8'));
const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
for(const variant of ['direct-map-current','compiled-script-current']){
 const mod=await import(pathToFileURL(resolve(`.tmp/ssr-large-profile/${variant}.mjs`)));
 const html=await mod.renderParticipant(data,'/incidents/inc-101',options);
 await writeFile(`.tmp/ssr-large-profile/${variant}-assets.html`,html);
}
