package exactcompiler

import "github.com/microsoft/TypeScript/tsc/internal/ast"

// plannedEmptyExternalScript admits only a server root with explicit attributes and no content.
// Client creation, inline text, spreads, and enhancement-owned scripts retain their existing lane.
func (lowering *jsxLowering) plannedEmptyExternalScript(opening *ast.Node, children *ast.NodeList) bool {
	if lowering.target != TargetServer || sourceText(lowering.sourceFile, openingTag(opening)) != "script" || (children != nil && len(children.Nodes) != 0) {
		return false
	}
	attributes := opening.Attributes()
	if attributes == nil || lowering.renderProgramIntrinsicHasEnhancements(attributes) {
		return false
	}
	hasSource := false
	for _, property := range attributes.AsJsxAttributes().Properties.Nodes {
		if !ast.IsJsxAttribute(property) {
			return false
		}
		name := jsxAttributeText(property.AsJsxAttribute().Name())
		if name == "ref" || name == "children" || name == "unsafeHtml" || name == "dangerouslySetInnerHTML" {
			return false
		}
		if name == "src" {
			hasSource = true
		}
	}
	return hasSource
}
