
import fs from 'node:fs';
const root='.tmp/ssr-hotpath-experiments/';const result={createdAt:new Date().toISOString(),http:{},micro:{}};
for(const file of fs.readdirSync(root).filter(f=>f.startsWith('http-')&&f.endsWith('.json'))){
 const capture=JSON.parse(fs.readFileSync(root+file));if(!capture.complete)throw Error('Incomplete '+file);
 const blocks=capture.blocks.filter(b=>b.round>=0);const rounds=[...new Set(blocks.map(b=>b.round))];const means=Object.fromEntries(['control','candidate','react'].map(name=>[name,blocks.filter(b=>b.name===name).reduce((s,b)=>s+b.rps,0)/rounds.length]));
 const wins=rounds.filter(round=>blocks.find(b=>b.round===round&&b.name==='candidate').rps>blocks.find(b=>b.round===round&&b.name==='control').rps).length;
 const errors=blocks.reduce((s,b)=>s+b.results.reduce((s,r)=>s+r.stages.reduce((s,t)=>s+t.errors,0),0),0);
 result.http[file]={means,wins,rounds:rounds.length,errors,gainPercent:100*(means.candidate/means.control-1),reactGapPercent:100*(1-means.candidate/means.react),artifacts:capture.artifacts,identities:Object.fromEntries(['control','candidate','react'].map(name=>[name,blocks.find(b=>b.name===name).results[0].identity])),roundValues:blocks.map(({round,name,rps})=>({round,name,rps}))};
}
for(const file of fs.readdirSync(root).filter(f=>f.startsWith('micro-')&&f.endsWith('.json')))result.micro[file]=JSON.parse(fs.readFileSync(root+file));
result.serializationStages=JSON.parse(fs.readFileSync(root+'serialization-stage.json'));
fs.writeFileSync('docs/performance-baselines/ssr-hotpath-experiments-2026-09-08.json',JSON.stringify(result,null,2));
for(const [file,r]of Object.entries(result.http)) console.log(file,JSON.stringify({means:r.means,wins:r.wins,errors:r.errors,gain:r.gainPercent,gap:r.reactGapPercent}));
