import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import * as before from './control.js';
const after = await import('./'+process.env.SSR_CANDIDATE+'.js');
const original=JSON.parse(await readFile('.tmp/ssr-paired-profile/data.json','utf8'));
const cases={original,unicode:structuredClone(original),longUnicode:structuredClone(original)};
for(const [name,count] of [['unicode',30],['longUnicode',1000]])for(const incident of cases[name].incidents)incident.title+=' \u6f22\u5b57\ud83d\ude80'.repeat(count);
const samples=[];let consumed=0;
for(const [name,data] of Object.entries(cases)){
 const render=entry=>()=>{let value='';const bytes=entry.renderParticipantToSink(data,'/incidents/inc-101',chunk=>value+=chunk,Buffer.byteLength);assert.equal(bytes,Buffer.byteLength(value));return value;};
 const operations={before:render(before),after:render(after)};
 assert.equal(operations.before(),operations.after());
 for(const op of Object.values(operations))for(let i=0;i<1000;i++)consumed+=op().length;
 for(let round=0;round<12;round++)for(const variant of round%2?['after','before']:['before','after']){
  const start=performance.now();for(let i=0;i<1000;i++)consumed+=operations[variant]().length;
  samples.push({name,variant,round,us:performance.now()-start});
 }
}
const means=Object.fromEntries(Object.keys(cases).map(name=>[name,Object.fromEntries(['before','after'].map(variant=>[variant,samples.filter(s=>s.name===name&&s.variant===variant).reduce((sum,s)=>sum+s.us,0)/12]))]));
console.log(means);await writeFile('.tmp/ssr-hotpath-experiments/micro-'+process.env.SSR_CANDIDATE+'.json',JSON.stringify({means,samples,consumed},null,2));
