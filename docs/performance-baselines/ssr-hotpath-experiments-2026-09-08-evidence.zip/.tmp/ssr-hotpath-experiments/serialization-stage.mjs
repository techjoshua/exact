
import fs from 'node:fs';import assert from 'node:assert/strict';import * as entry from './capture.js';
const original=JSON.parse(fs.readFileSync('.tmp/ssr-paired-profile/data.json'));const cases={original,unicode:structuredClone(original)};
for(const i of cases.unicode.incidents)i.title+=' \u6f22\u5b57\ud83d\ude80'.repeat(1000);
const results=[];let consumed=0;
for(const [name,data]of Object.entries(cases)){
 let html='';entry.renderParticipantToSink(data,'/incidents/inc-101',s=>html+=s,Buffer.byteLength);
 const text=html.match(/<script[^>]*id="__exact_hydration"[^>]*>([\s\S]*?)<\/script>/)[1];const {payload,replacer}=entry.readCapturedPayload();assert.equal(replacer,undefined);const json=JSON.stringify(payload);
 const operations={stringify:()=>JSON.stringify(payload),escaping:()=>json.replace(/</g,'\\u003C').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029'),guarded:()=>json.length>=2048&&!/[<\u2028\u2029]/.test(json)?json:json.replace(/</g,'\\u003C').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029')};
 assert.equal(operations.escaping(),text);assert.equal(operations.guarded(),text);
 for(const op of Object.values(operations))for(let i=0;i<2000;i++)consumed+=op().length;
 for(let round=0;round<12;round++)for(const kind of round%2?Object.keys(operations).reverse():Object.keys(operations)){
  const start=performance.now();for(let i=0;i<2000;i++)consumed+=operations[kind]().length;
  results.push({name,kind,round,us:(performance.now()-start)/2});
 }
}
fs.writeFileSync('.tmp/ssr-hotpath-experiments/serialization-stage.json',JSON.stringify({results,consumed},null,2));
for(const name of Object.keys(cases))for(const kind of ['stringify','escaping','guarded'])console.log(name,kind,results.filter(r=>r.name===name&&r.kind===kind).reduce((n,r)=>n+r.us,0)/12);
