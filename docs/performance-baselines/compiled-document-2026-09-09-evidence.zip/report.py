﻿from pathlib import Path
import json,statistics,hashlib,shutil,difflib
root=Path('.tmp/compiled-document');out=Path('docs/performance-baselines');name='compiled-document-2026-09-09'
renderer=json.loads((root/'renderer.json').read_text(encoding='utf-8'));http=json.loads((root/'compiled-document-http.json').read_text(encoding='utf-8'));counts=json.loads((root/'counts/counts.json').read_text(encoding='utf-8'))
assert len(renderer)==108 and len(http)==24 and all(r['errors']==0 for r in http)
text='''# Compiled document components, September 9, 2026

Retained: ordinary component render programs now handle document hosts, coalesce proven static
children, and preserve existing dynamic child adoption boundaries. String and streaming output
continue to use the same renderer. No shell-specific public API or application workaround was added.

The [preceding profile](ssr-program-profile-2026-09-09.md) identified generic document operations as
avoidable work and proposed a 5 to 10% small-document rendering improvement. This implementation
reduces median small-document rendering time by 9.4 to 17.5% for strings and 7.0 to 16.8% for streams
in the focused samples. Median HTTP throughput improves in all four runtime/output combinations.
The large string workload changes little. These results do not establish parity with React across
workloads or replace the historical public benchmark charts.

## Retained implementation

- The native compiler emits `ssrHost` metadata identifying a server program's root intrinsic.
  An explicit, ordered head/body pair can form a compiled HTML program. Incomplete, reordered,
  conditional, or ambiguous document structure retains runtime normalization and rejection.
- HTML, head, and body remain ordinary authored component markup. Document host identities remain
  available to ordinary client adoption. Static children can share the surrounding program, while
  dynamic expressions, lists, components, and independently compiled dynamic child regions keep
  their existing adoption boundaries and sibling task issuance.
- The existing ordered output walker retains document ancestry through pending descendants and
  releases it on failure. Ordinary compiled roots invalidate document probing, preventing an
  enclosing compiled main element from concealing an invalid nested HTML document.
- Normalization recognizes both generic intrinsic operations and prepared program roots. It can
  synthesize missing head/body hosts around unambiguous compiled content and rejects duplicates
  or an authored body combined with loose content.
- Document publication still waits for rendering and tasks that can revise the shell. It publishes
  body content before hydration and closing tags; this change does not add traversal-time head
  flushing or weaken cancellation, output limits, or hydration validation.

The implementation belongs to the compiler, core artifact types, and shared SSR traversal. Application
Document components and React implementations were not changed. The initial unreleased 0.5.0 ABI
notes describe the new required program semantics; preserved development fixtures were not regenerated.

## Correctness findings and validation

The initial SSR check caught missing document-host IDs. They were restored in compiler-generated
root props. New composition coverage caught a compiled main concealing nested HTML; root-host
metadata and probing now reject it.

An initial browser round caught a Document hydration mismatch even though SSR tests passed: merging
dynamic regions changed the boundaries expected by the client head lists. The final implementation
coalesces only proven static children and preserves ordinary dynamic child lowering. The corrected
build passes all 56 production browser checks: Node and Bun, string and stream, eXact and React.
These checks include hydration, filtering, optimistic actions, live updates, focus preservation,
validation, empty data, and reconnection. Browser timing was not remeasured and no paint/navigation
improvement is claimed.

Validation completed:

- Native compiler overlay and command tests, plus a final normal build-cache verification.
- 272 SSR, 247 core, and 240 hydration package tests.
- 56 production browser checks across both runtimes and output modes.
- Test type checking, affected-file lint/formatting, JSDoc, explicit-any ratchet, source architecture,
  platform boundaries, and published package contents.
- Frozen compiled ABI fixtures and release ABI checks.
- Documentation application type checking and production build.

## Renderer measurements

Node 26.8.1, Bun 1.4.2, React 19.2.0, production mode. Each framework constructs its own complete
HTML document through its component tree. Three rotated orders of starting eXact, retained eXact,
and React for each runtime, output mode, and workload: 108 fresh-process populations. Each performs
2,000 warmups followed by 6,000 measured renders. Streams are consumed completely with Response.text(),
so these numbers include stream consumption and decoding, not just HTML generation.

Small is the three-incident fixture. Unicode adds 100 repetitions of accented, astral, and Japanese
text to each incident title. Large contains 96 incidents. Median microseconds per complete document,
lower is better. Reduction compares medians within this capture.

| Runtime | Mode | Workload | Starting eXact | Retained eXact | React | Time reduction |
| --- | --- | --- | ---: | ---: | ---: | ---: |
'''
for rt in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['small','unicode','large']:
   values=[statistics.median(r['usPerRender'] for r in renderer if r['runtimeId']==rt and r['mode']==mode and r['scenario']==scenario and r['variant']==v) for v in ['baseline','candidate','react']]
   text+=f'| {rt} | {mode} | {scenario} | '+' | '.join(f'{v:.2f}' for v in values)+f' | {(1-values[1]/values[0])*100:.1f}% |\n'
text+='''
The smaller gains on large strings fit an optimization focused on document setup. React remains
faster for strings on both runtimes and for Bun streams in these fixtures. The retained eXact
streaming probe is faster on Node in this capture, including stream consumption. These local
samples are not isolated-machine performance guarantees; individual large-workload pairs vary.

## HTTP throughput

Two counterbalanced populations per runtime/output mode/framework variant: 24 populations. Each
uses two independent load-driver processes at concurrency 16, for total concurrency 32. Each driver
warms for 2 seconds and measures for 4 seconds. The application data is preloaded to isolate SSR
from controlled-service fetching. Node uses the existing Node HTTP path; Bun uses native Bun fetch
servers. Both variants use the same current benchmark worker and unchanged production transports.
Every measured response must match its variant's complete raw response identity.

Median valid requests per second, higher is better:

| Runtime | Mode | Starting eXact | Retained eXact | React | eXact gain |
| --- | --- | ---: | ---: | ---: | ---: |
'''
for rt in ['node','bun']:
 for mode in ['string','stream']:
  vals=[statistics.median(r['rps'] for r in http if r['runtime']==rt and r['mode']==mode and r['variant']==v) for v in ['baseline','candidate','react']]
  text+=f'| {rt} | {mode} | '+' | '.join(f'{v:,.0f}' for v in vals)+f' | {(vals[1]/vals[0]-1)*100:.1f}% |\n'
text+='''
All 24 populations completed with zero errors. Both paired populations favored the retained build
in every runtime/output combination. Two populations still provide limited precision. Compare
variants within this capture, not absolute rates with earlier runs under different PC workload.

The Node streaming HTTP advantage includes the previously measured adapter difference: React uses
Readable.fromWeb()/pipeline(), while eXact's adapter consumes the stream directly. This investigation
changes neither React nor those adapters and does not attribute that full advantage to the compiler.

## Removed work and response identity

An instrumented single small-document render confirms the intended work reduction:

| Operation | Starting eXact | Retained eXact |
| --- | ---: | ---: |
| Opaque operation creation | 5 | 2 |
| Generic intrinsic receipt creation | 3 | 0 |
| Prepared server program creation | 21 | 20 |
| Attribute preparation | 25 | 24 |
| Component references / prop preparation | 8 / 8 | 8 / 8 |
| Positional validation visits | 40 | 40 |
| JSON serialization | 1 | 1 |

These are helper invocation counts, not allocation totals. Hydration validation was not removed.
The retained empty asset lists still own two generic fragment operations for ordinary client adoption.

Small documents remain 3,966 bytes for eXact and 3,457 for React. Cross-build raw hashes differ because
the compiler changes request-local fragment ordinals, for example 5/6 become 7/8. The comparison
normalizes only the ordinal field in exact:fragment comments, retaining each comment and its stable
compiler-owned fragment identity. Structural hashes match for all paired renderer workloads, and
normalized complete HTTP documents match across eXact variants. Every build's raw hash and byte
length remain recorded; HTTP drivers validate the entire raw response against that build's own hash.
No production benchmark identity checks were weakened.

## Evidence

[Raw renderer and HTTP measurements](compiled-document-2026-09-09.json) and
[artifacts, input, source snapshots, logs, and scripts](compiled-document-2026-09-09-evidence.zip)
retain this investigation. The evidence archive has a per-file SHA-256 manifest. The starting Node
artifact exactly matches the preceding investigation's final archived artifact; the native Bun
baseline comes from that same final archive. Retained timed artifacts are frozen separately from
later documentation-only edits. Scripts use repository-relative paths and the normal workspace
dependencies. The input snapshot is retained as input.json.

The archive also retains the initial failed checks and the narrowed implementation. Its code patch
is relative to snapshots taken at this task's start, rather than the repository's much older HEAD.
The report and public documentation clarify that existing full charts predate this optimization.
'''
(out/(name+'.md')).write_text(text,encoding='utf-8')
(out/(name+'.json')).write_text(json.dumps({'renderer':renderer,'http':http,'retainedCounts':counts},indent=2)+'\n',encoding='utf-8')
p=Path('docs/performance.md');s=p.read_text(encoding='utf-8');needle='The [original full-document baseline]';addition='''The [compiled document implementation](performance-baselines/compiled-document-2026-09-09.md)
retains ordinary component compilation for document hosts and proven static content, with existing
dynamic adoption boundaries. It records paired renderer and HTTP improvements on Node and Bun,
plus production browser correctness. It does not replace the historical full charts above.

''';s=s.replace(needle,addition+needle,1);p.write_text(s,encoding='utf-8')
p=Path('docs/ssr-hydration.md');s=p.read_text(encoding='utf-8').replace('Server compilation retains document host identities while coalescing compiler-finite head and body\ncontents into the same render programs used elsewhere.', 'Server compilation retains document host identities while coalescing proven static head and body\nchildren into the same render programs used elsewhere. Dynamic expressions, lists, components, and\nindependently compiled dynamic child regions retain their existing client adoption boundaries.');p.write_text(s,encoding='utf-8')
paths=['native/typescript-go/overlay/internal/exactcompiler/jsx_render_program_lowering.go','native/typescript-go/overlay/internal/exactcompiler/jsx_render_program_document.go','native/typescript-go/overlay/internal/exactcompiler/jsx_render_program_document_test.go','packages/core/src/render-program.ts','packages/ssr/src/render/program-output.ts','packages/ssr/src/render/direct-component-content.ts','packages/ssr/src/render/operation-target.ts','packages/ssr/src/render/intrinsic-receipt.ts','packages/ssr/src/render/program-output.test.ts','packages/ssr/src/compiled-documents.fixtures.test.tsx','packages/ssr/src/compiled-documents.test.ts','docs/ssr-hydration.md','docs/release-readiness.md','docs/performance.md','apps/docs/src/pages/AdvancedPage.tsx','apps/docs/src/pages/PerformancePage.tsx','framework-comparison/src/ssr-benchmark-worker.mjs','framework-comparison/participants/exact/src/Document.tsx','framework-comparison/participants/react/src/Document.tsx','framework-comparison/participants/react/dist-server/server-entry.js','framework-comparison/participants/react/dist-bun-server/bun-server-entry.js','native/typescript-go/upstream.json']
for path in paths:
 target=root/'final-source'/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target)
shutil.copyfile('.tmp/positional-leaves/data.json',root/'input.json')
shutil.copyfile('.tmp/native-compiler/win32-x64.build.json',root/'native-build.json')
patch=[]
for path in paths[:11]:
 p=Path(path);before=root/'before'/path
 if before.exists():old=before.read_text(encoding='utf-8')
 elif path.endswith('program-output.test.ts'):old=p.read_text(encoding='utf-8').split("describe('compiled document host ownership'")[0].rstrip()+'\n'
 else:old=''
 patch.extend(difflib.unified_diff(old.splitlines(keepends=True),p.read_text(encoding='utf-8').splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
(root/'implementation.patch').write_text(''.join(patch),encoding='utf-8')
(root/'validation.json').write_text(json.dumps({'compiler':'overlay and command tests passed; normal native build cache verified','ssr':272,'core':247,'hydrate':240,'browser':{'node-string':14,'node-stream':14,'bun-string':14,'bun-stream':14},'checks':['test types','affected ESLint','source architecture','platform boundaries','JSDoc','explicit-any 73/73','package contents','frozen compiled ABI','initial release ABI','docs verify']},indent=2),encoding='utf-8')
print('Report, raw measurements, source snapshots, and isolated implementation patch written')
