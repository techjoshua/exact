import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const rows=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const scenario of ['small','unicode','large'])for(let round=0;round<3;round++){
 const variants=['baseline','candidate','react'];const order=[...variants.slice(round),...variants.slice(0,round)];
 for(const variant of order){
  const entry=variant==='baseline'?'.tmp/compiled-document/baseline/exact-node.mjs':`framework-comparison/participants/${variant==='react'?'react':'exact'}/dist-server/server-entry.js`;
  const result=spawnSync(runtime,['.tmp/compiled-document/renderer-worker.mjs',entry,mode,scenario,'6000'],{env:{...process.env,NODE_ENV:'production'},encoding:'utf8',windowsHide:true});
  if(result.status!==0)throw Error(result.stderr||result.stdout);
  const row={variant,round,runtimeId:runtime,artifactSha256:createHash('sha256').update(readFileSync(entry)).digest('hex'),...JSON.parse(result.stdout)};rows.push(row);
  if(variant!=='react'){const peer=rows.find(r=>r.runtimeId===runtime&&r.mode===mode&&r.scenario===scenario&&r.round===round&&r.variant!==variant&&r.variant!=='react');if(peer&&(peer.structuralHash!==row.structuralHash))throw Error('Document identity changed');}
  console.log(runtime,mode,scenario,round,variant,row.usPerRender.toFixed(2));writeFileSync('.tmp/compiled-document/renderer.json',JSON.stringify(rows,null,2));
 }
}
