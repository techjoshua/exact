﻿import {readFileSync,writeFileSync} from 'node:fs';
const data=JSON.parse(readFileSync('.tmp/positional-leaves/data.json','utf8'));
const modules=[await import('./baseline/exact-node.mjs'),await import('../../framework-comparison/participants/exact/dist-server/server-entry.js')];
const html=[];for(let i=0;i<2;i++){html[i]=await modules[i].renderParticipant(data,'/incidents/inc-101',{clientTags:''});writeFileSync(`.tmp/compiled-document/document-${i}.html`,html[i]);}
console.log(html.map(s=>Buffer.byteLength(s)));
let first=0;while(first<Math.min(...html.map(s=>s.length))&&html[0][first]===html[1][first])first++;console.log(first,html.map(s=>s.slice(Math.max(0,first-80),first+350)));
