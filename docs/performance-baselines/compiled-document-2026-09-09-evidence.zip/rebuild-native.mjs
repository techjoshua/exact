﻿import {spawnSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {createNativeCompilerBuildKey,writeNativeCompilerBuildStamp} from '../../scripts/native-compiler-build-cache.mjs';
const cwd=resolve('.tmp/native-typescript-go/tsc'),exe=resolve('.tmp/native-compiler/exactc.exe');
for(const args of [['test','./internal/exactcompiler','./cmd/exactc'],['build','-buildvcs=false','-trimpath','-o',exe,'./cmd/exactc']]){
 const r=spawnSync('go',args,{cwd,stdio:'inherit',windowsHide:true,env:{...process.env,CGO_ENABLED:'0',GOOS:'windows',GOARCH:'amd64'}});if(r.status!==0)process.exit(r.status??1);
}
const {revision}=JSON.parse(readFileSync('native/typescript-go/upstream.json','utf8'));
await writeNativeCompilerBuildStamp(resolve('.tmp/native-compiler/win32-x64.build.json'),await createNativeCompilerBuildKey({repositoryRoot:process.cwd(),revision,target:'win32-x64'}),exe);
