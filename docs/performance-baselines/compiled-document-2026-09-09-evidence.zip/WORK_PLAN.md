﻿# Compiled ordinary document programs

Task: implement profiled document-shell optimization, preserve ordinary component semantics and one SSR engine, validate browser adoption and benchmark vs frozen current baseline and React.

Baseline: .tmp/ssr-program-profile/exact-baseline.mjs (before this task), worker .tmp/ssr-program-profile/worker.mjs. Existing public charts unchanged.

Implemented:
- jsx_render_program_lowering.go and new jsx_render_program_document.go: server document roots can be programs; canonical html requires explicit ordered head/body; other layouts use runtime normalization.
- ssrHost metadata identifies every server program root. Document hosts and immediate intrinsic children of html retain stack scope. Other root intrinsics invalidate document probing. Runtime output walker remains shared.
- normalizeDocumentChildren recognizes prepared program hosts and ordinary compiled intrinsic content.
- Preserve data-exact-id on document hosts for ordinary client adoption.
- New compiler tests, SSR compiled-document fixtures/tests, output host lifecycle tests.
- Engineering, release, public Advanced docs updated.

Checks:
- First 261 SSR tests had two missing host-id failures, fixed compiler ID emission.
- New focused tests caught compiled main concealing nested html; fixed root-host metadata/claims.
- 272 SSR tests passed after those fixes. Core/SSR builds passed.
- First production Node/string browser round: React 7 passed, exact 7 failed due Document hydration mismatch. Traces confirm marker mismatch, not renderer-only correctness.
- Current compiler correction coalesces only static document children, preserving ordinary lowering for dynamic children and independently compiled child regions. Retains existing markers and sibling task issuance. Source changed, native rebuild in progress.

Build process:
- Full build:native-compiler ran twice, stages .tmp/native-typescript-go/tsc and tests overlay.
- Subsequent incremental script .tmp/compiled-document/rebuild-native.mjs runs full overlay Go tests and builds exactc then writes normal build stamp. MUST copy all changed overlay Go files into staged tree first. Upstream unchanged. Final normal build command should verify cache.
- Native build logs .tmp/compiled-document/compiler-boundaries.log current. Full log and prior failures retained.
- Current jobs: native rebuild session 62044; test types session 70284. ESLint affected files passed.

Next:
1. Finish native build, rebuild core/SSR compiled modules and exact participant. Run SSR tests, browser Node/string again; fix any mismatches at compiler/runtime.
2. Full Node/Bun string/stream browser correctness, affected hydration/core tests and quality gates.
3. Focused paired renderer benchmarks baseline/current/React, small/Unicode/large on Node/Bun, both sinks. Report actual results promptly. HTTP/browser timing if justified.
4. Durable report + raw/archive, update docs, final process cleanup.

No agents allowed. No commits/pushes. Preserve huge pre-existing dirty tree. Do not edit code while matching tests/build/bench run. Windows UTF-8: Python read/write encoding explicit; PowerShell stdin can corrupt Unicode, use Python Unicode escapes. Test Unicode fixed to actual cafe/rocket using escapes.

Completed: final static-only coalescing preserves dynamic child regions. All 272 SSR, 247 core, 240 hydrate, and 56 production browser checks pass. Compiler tests, test types, lint/format, architecture, platform, JSDoc, any ratchet, package contents, ABI, and docs verify pass. 108 renderer and 24 HTTP populations complete; all HTTP populations zero errors. Current timed artifacts frozen under candidate/. Report and raw results in docs/performance-baselines/compiled-document-2026-09-09.*.
