import { normalizeRenderResult, type AnyComponentInstance, type Child } from '@exactjs/core';
import {
	readPreparedServerRenderProgram,
	type ExactPreparedServerRenderProgram
} from '@exactjs/core/framework/server-render-structure';
import type { SsrContext } from '../types.js';
import type { RenderValue } from './execution.js';
import { renderProgramOutput } from './program-output.js';
import { renderPreparedSsrProgram } from './render-program.js';
import type { ServerComponentReference } from './server-component-reference.js';

/** Compiler-closed result before its deferred child/component segments are serialized. */
export type DirectSsrComponentContent =
	| Readonly<{ children: Child[]; program?: never }>
	| Readonly<{ children?: never; program: ExactPreparedServerRenderProgram }>;

/** Classifies raw component output before generic child normalization loses its server ABI. */
export function readDirectSsrContent(value: unknown): DirectSsrComponentContent {
	const program = readPreparedServerRenderProgram(value);
	return program ? { program } : { children: normalizeRenderResult(value as Child | Child[]) };
}

/** Serializes direct component content through caller-owned recursive rendering operations. */
export function renderDirectSsrContent(
	context: SsrContext,
	content: DirectSsrComponentContent,
	parent: AnyComponentInstance | undefined,
	renderChildren: (
		children: readonly Child[],
		parent: AnyComponentInstance | undefined
	) => RenderValue<string>,
	renderOwnedComponent: (
		component: ServerComponentReference,
		parent: AnyComponentInstance | undefined
	) => RenderValue<string>
): RenderValue<string> {
	if (content.children) return renderChildren(content.children, parent);
	const planned = renderPreparedSsrProgram(context, content.program, parent);
	return renderProgramOutput(context, planned.segments, (segment) =>
		Array.isArray(segment)
			? renderChildren(segment, parent)
			: renderOwnedComponent(segment as ServerComponentReference, parent)
	);
}
