import type { SsrContext } from '../types.js';
import type { RenderValue } from './execution.js';
import { appendBoundedHtml, assertOutputCharacterBound } from './limits.js';
import { captureNestedEnhancementStringPrefix } from './operation-enhancement-routes.js';

/** Consumes completed string spans directly and renders only deferred program segments. */
export function renderProgramOutput<T extends object>(
	context: SsrContext,
	segments: readonly (string | T)[],
	render: (segment: T) => RenderValue<string>
): RenderValue<string> {
	const first = segments[0];
	if (
		segments.length === 1 &&
		typeof first === 'string' &&
		!context.enhancementOperationRoutes?.length
	) {
		assertOutputCharacterBound(context, first);
		return first;
	}
	return continueProgramOutput(context, segments, render, 0, '');
}

/** Resumes ordered output after actual suspension; completed work allocates no continuations. */
function continueProgramOutput<T extends object>(
	context: SsrContext,
	segments: readonly (string | T)[],
	render: (segment: T) => RenderValue<string>,
	start: number,
	output: string
): RenderValue<string> {
	for (let index = start; index < segments.length; index++) {
		const segment = segments[index]!;
		const value = typeof segment === 'string' ? segment : render(segment);
		if (value instanceof Promise)
			return value.then((html) =>
				continueProgramOutput(
					context,
					segments,
					render,
					index + 1,
					appendBoundedHtml(context, captureNestedEnhancementStringPrefix(context, output), html)
				)
			);
		output = appendBoundedHtml(
			context,
			captureNestedEnhancementStringPrefix(context, output),
			value
		);
	}
	return output;
}
