import { describe, expect, it } from 'vitest';
import {
	renderToString,
	renderToHydratableString,
	renderToHydratableProgressiveHtmlStream
} from './index.js';
import { createOperation } from './test-support/native-operations.js';
import {
	BodyOnlyDocument,
	LooseDocument,
	ReorderedDocument,
	AmbiguousDocument,
	DuplicateHeadDocument,
	NestedDocument,
	AssetDocument
} from './compiled-documents.fixtures.test.js';

describe('compiled document components', () => {
	it.each([BodyOnlyDocument, LooseDocument])(
		'normalizes missing document hosts around compiled contents',
		async (component) => {
			const { html } = await renderToString(createOperation(component, null), { markers: false });
			expect(html).toMatch(/^<!doctype html><html[^>]*><head[^>]*><\/head><body[^>]*><main/);
			expect(html).toMatch(/<\/main><\/body><\/html>$/);
		}
	);
	it('orders an authored head before its body through runtime normalization', async () => {
		const { html } = await renderToString(createOperation(ReorderedDocument, null), {
			markers: false
		});
		expect(html.indexOf('<head')).toBeLessThan(html.indexOf('<body'));
		expect(html).toContain('<title>Reordered</title>');
	});
	it.each([
		[AmbiguousDocument, /ambiguous loose content/],
		[DuplicateHeadDocument, /at most one <head>/],
		[NestedDocument, /nested or duplicate/]
	] as const)('rejects invalid document composition', async (component, error) => {
		await expect(renderToString(createOperation(component, null))).rejects.toThrow(error);
	});
	it.each([[], ['/one.js', '/two.js']])(
		'preserves dynamic metadata and resources in both output modes',
		async (...sources: string[]) => {
			const props = { title: 'Café 🚀 <safe>', sources };
			const operation = createOperation(AssetDocument, props);
			const string = (await renderToHydratableString(operation, { publishRootProps: true }))
				.htmlWithHydration;
			const stream = await new Response(
				renderToHydratableProgressiveHtmlStream(createOperation(AssetDocument, props), {
					publishRootProps: true
				})
			).text();
			for (const html of [string, stream]) {
				expect(html).toMatch(/^<!doctype html>/);
				expect(html).toContain('Café 🚀 &lt;safe&gt;');
				expect(html).toContain('href="/app.css"');
				for (const src of sources) expect(html).toContain(`src="${src}"`);
				expect(html).toMatch(/<\/body><\/html>$/);
			}
		}
	);
});
