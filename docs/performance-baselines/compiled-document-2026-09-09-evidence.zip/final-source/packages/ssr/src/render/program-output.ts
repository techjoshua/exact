import type { SsrContext } from '../types.js';
import { mapRenderValue, withRenderCleanup, type RenderValue } from './execution.js';
import { claimRootText, enterHostTag, leaveHost } from './host.js';
import { appendBoundedHtml, assertOutputCharacterBound } from './limits.js';
import { captureNestedEnhancementStringPrefix } from './operation-enhancement-routes.js';

/**
 * Consumes completed spans directly and renders only deferred program segments.
 * Retains compiler-owned document ancestry through pending descendants and releases it on failure.
 */
export function renderProgramOutput<T extends object>(
	context: SsrContext,
	segments: readonly (string | T)[],
	render: (segment: T) => RenderValue<string>,
	host?: string
): RenderValue<string> {
	// Ordinary roots must invalidate document probing too. Only document hosts and their
	// immediate intrinsic children need a retained stack frame for document validation.
	if (
		host &&
		(host === 'html' ||
			host === 'head' ||
			host === 'body' ||
			(context.documentRootSeen && context.hostStack.at(-1) === 'html'))
	) {
		const entered = enterHostTag(context, host);
		return withRenderCleanup(
			() =>
				mapRenderValue(renderProgramOutput(context, segments, render), (html) =>
					entered.prefix ? appendBoundedHtml(context, entered.prefix, html) : html
				),
			() => leaveHost(context, entered.tag)
		);
	}
	if (host && !context.hostStack.length) claimRootText(context);
	const first = segments[0];
	if (
		segments.length === 1 &&
		typeof first === 'string' &&
		!context.enhancementOperationRoutes?.length
	) {
		assertOutputCharacterBound(context, first);
		return first;
	}
	return continueProgramOutput(context, segments, render, 0, '');
}

/** Resumes ordered output after actual suspension; completed work allocates no continuations. */
function continueProgramOutput<T extends object>(
	context: SsrContext,
	segments: readonly (string | T)[],
	render: (segment: T) => RenderValue<string>,
	start: number,
	output: string
): RenderValue<string> {
	for (let index = start; index < segments.length; index++) {
		const segment = segments[index]!;
		const value = typeof segment === 'string' ? segment : render(segment);
		if (value instanceof Promise)
			return value.then((html) =>
				continueProgramOutput(
					context,
					segments,
					render,
					index + 1,
					appendBoundedHtml(context, captureNestedEnhancementStringPrefix(context, output), html)
				)
			);
		output = appendBoundedHtml(
			context,
			captureNestedEnhancementStringPrefix(context, output),
			value
		);
	}
	return output;
}
