# SSR and hydration

Status: implemented foundation with the explicit limits listed below.

Progressive document rendering honors `publishRootProps` through the same root-prop schema and
component capture used by string rendering. This includes native head lists and nested resumable
components when the browser adopts the authored document. Progressive HTML publishes the rendered
document through its body content before constructing the hydration payload, then emits hydration
inside the reserved framework region and closes the body and HTML elements. Both readable streams
and produced responses honor backpressure between these publications. This permits resource discovery
before hydration delivery. It does not yet flush the head during tree traversal: full-document
shells still wait for rendering and pending tasks that could revise the head or body. Document event
streams retain their shell/replacement protocol; fragment HTML retains progressive replacements.
Scheduled render retries restore document host claims along with other attempt state, so a discarded
document attempt does not make the settled attempt appear to contain duplicate HTML, head, or body tags.

Hydration validation keeps shallow active ancestry in a request-local stack, promoting it to a
native `Set` at 16 active containers. Only the active path participates in cycle detection; shared
sibling references remain valid. Promotion preserves every active ancestor and also occurs before
calling any version-one compiled positional projector, retaining that projector's native `Set`
contract. Error-path validation starts with independent ancestry. Serialization checks, depth/node
limits, wire format, and compiled projector ABI are unchanged.

## Package ownership

- `@exactjs/ssr` renders strings, documents, event streams, progressive HTML,
  hydratable output, and adapter-neutral response objects.
- `@exactjs/hydrate` adopts server DOM, activates client islands, invokes the
  server endpoint, validates results, and applies patches.
- `@exactjs/hydrate/root` is the statically selectable hydration-only facade for applications
  without compiler-generated server operations, response patches, or client islands. Its root
  owns adoption and disposal but does not retain those optional modules in the browser graph.
  Its `hydrateAfterNavigation()` entry accepts an element or the current `document` and gives
  visible SSR content one rendering opportunity before
  scheduling user-visible adoption outside the DOMContentLoaded critical path. An
  interaction-capture fallback still activates the root synchronously when a user acts first, and
  hidden documents use a task fallback because animation frames may be throttled indefinitely.
  Hydration roots must belong to the executing window's current document. An embedded document runs
  its own eXact runtime instead of transferring DOM ownership to its parent window. Scheduling uses
  that current document's readiness and queues. Activation has one terminal settlement:
  scheduling and hydration failures remove pending hooks and cannot trigger a later retry.
  The ordinary opt-in sink reports aggregate hydration. The framework-comparison diagnostic build
  adds client creation, DOM capture, adoption, and control-restoration phases without shipping those
  timers in a production application. Its nested DOM profile divides adoption into component
  construction and attachment plus render-program claim, structural-child adoption, and binding,
  so maintainers can distinguish scheduling delay from the exact adoption work performed.
- `@exactjs/server` owns allowlisted invocation/refresh dispatch, request
  validation, authorization hooks, limits, and runtime-neutral adapters.
- `@exactjs/compiler` owns placement, artifact generation, operation
  contracts, hydration registration, and final client-bundle isolation.

## Server rendering

`renderToString()` and `renderToHydratableString()` return promises. `renderKeyedListSnapshot()`
also returns a promise because item components may depend on pending tasks. String and stream
entry points share one traversal, component executor, and hydration capture. There is no separate
synchronous renderer or `Async` API alias. Internal operations return available output directly
and create continuations only for actual pending work or asynchronous cleanup.

Completed program strings bypass deferred component dispatch. The ordered segment walker keeps its
continuation state in function parameters and allocates a promise callback only when a segment is
pending. Both output modes retain the same enhancement-prefix capture and output bounds. String
results retain request-owned chunks and lazily materialize HTML; hydration publication uses its
fresh options object directly without copying it again.

Node full-response adaptation materializes buffered chunks once and calls `response.end(html)`.
The body-only writer retains ordered chunk writes and backpressure for handlers that own subsequent
content. Asynchronous producers and Web Streams retain progressive publication and cancellation.

Task execution belongs to the core task system. A component frame exposes pending work and a
completion revision to rendering. The renderer checks that state, waits only when necessary, and
retries if a relevant task completed while descendants were rendered. Hydration treats writers of
compiler-selected shared contexts as publication dependencies, even when their authored task is
nonblocking: the value and its completed continuation identity must be published together to avoid
repeating the task in the browser. Other nonblocking tasks retain their readiness policy.

Native SSR emits deterministic markers for components, cells, dynamic
children, fragments, keyed lists, Suspense, Activity, client islands, and
compiler-planned server ranges. Multiple server descendants beneath one client
boundary retain independent plan-edge identities and adoptable DOM slots rather
than sharing one broad children slot. Active attributed enhancements remain
ordinary component owners in the same partition graph. String rendering waits for required
blocking work. Progressive
rendering emits a shell and can reveal settled Suspense ranges independently;
it falls back to an authoritative root replacement if work outside those
ranges changed.

Root-document mode accepts authored `html`, `head`, and `body` and inserts
framework-owned hydration or progressive-stream nodes into reserved positions.
An authored `html` root receives a doctype, and unambiguous missing `head` and `body`
regions are synthesized. Hydratable string rendering places its state publication before the
closing body tag. Fragment string rendering remains a fragment API.
Document shells remain ordinary components with props, state, tasks, and reactive expressions.
Server compilation retains document host identities while coalescing proven static head and body
children into the same render programs used elsewhere. Dynamic expressions, lists, components, and
independently compiled dynamic child regions retain their existing client adoption boundaries. An explicit ordered head/body pair can use
a compiled HTML program; incomplete or conditional composition retains runtime normalization.
The program's `ssrHost` metadata identifies its root intrinsic. The shared output traversal retains
document-host ancestry across pending descendants and cleanup, and ordinary roots invalidate the
root-document probe. This prevents compiled intrinsic regions from concealing nested documents.
Normalization recognizes both generic intrinsic operations and prepared program roots. Client
adoption continues to use the existing document intrinsic identities; no shell-specific authoring
API or second server renderer is involved. Early publication and task settlement follow the rules
above.

Use `hydrate(operation, document)` to adopt an authored document root. Native lists in its head
retain their compiler-owned fragment identities during adoption. Nested resumable components
captured by the root use ordinary component boundaries or compiler-owned slots, rather than
duplicating props in independent island wrappers.
Rendering applies output-size, task-pass, and task-duration limits.

The native compiler emits branded render programs for compiler-finite intrinsic regions. HTML,
SVG, MathML, scalar text, finite host properties and attributes, classes, styles, URLs, ordinary
form controls, events, and refs reuse focused renderer operations. Closed server artifacts emit a
component-specific SSR function whose generated calls prepare known values and then write static
markup, scalar text, structural children, and attributes in source order. Universal artifacts use
the same generated server lane alongside their client topology. The server runtime
provides escaping, marker, resource-limit, and recursive-child mechanics; it does not interpret a
generic render tape or retain client templates and topology tables. Markerless SSR writes escaped
values directly. A synchronous compiler-closed component executes on a request-local state frame
without allocating the browser's durable component instance. The frame snapshots compiler
expression props, publishes only compiler-selected resumable state after successful output, and
uses a shared non-retaining keyed-child renderer if a generated list callback produces a dynamic
slot shape. Compiler-closed child ranges, keyed children, and nested component calls are prepared as
request-local server ABI carriers and consumed directly; they are not VNodes or public opaque
operations and are never retained or serialized. A prepared server render program retains a small
nominal wrapper so ordinary child normalization cannot flatten its compiler-created values array.
All server invocations share one immutable empty client-reader table; request values remain owned by
the wrapper and are released with it. Hydratable SSR also omits scalar delimiters when
static markup bounds
the value on both sides; the client claims that text, or creates an owned empty text node, at the
compiled position. Adjacent text retains delimiters where browser parsing could merge independently
updated values. Client mounting clones a cached inert template, and hydration adopts elements and
scalar text through generated claim calls. Nested conditional regions retain the namespace established
by their intrinsic JSX ancestors, and standalone SVG or MathML programs mount through a
namespace-correct template. A finite intrinsic client program may contain compiler-owned structural
child slots: the server renders those children recursively through the ordinary dynamic-marker
protocol, while hydration adopts and subsequently patches only the marked child range. Enhancement-
routed, opaque-spread, raw-content, and otherwise dynamic hosts select explicit focused operations;
native TSX does not retain a region-local VNode fallback.

Compiler-closed render programs encode retained scalar, structural-child, and component ranges as
paired `x:` comments with dense artifact-local base-36 ordinals. Client and server projections
derive those ordinals from the same marker-only sequence even when their complete slot tables
differ. The program root scopes the identities; they are not durable application or transport
identifiers.

A keyed item whose value is a
compiler-prepared single-intrinsic-root
program uses that element as its item boundary. The receiving keyed receipt supplies the key and
owns the item scope; hydration does not need an additional pair of item comments. Generic items,
multi-node ranges, and server keyed-list patch snapshots retain explicit item boundaries. The client
continues to accept the older paired item markers.

A client program places a statically resolved native component in an explicit component lifecycle
slot. Server and complete artifacts retain the component's recursive execution and add the same
stable range marker, so hydration claims the component without rediscovering the surrounding host
tree. Once claimed, the compiler-proven single component mounts and patches through its direct
lifecycle operation rather than general sibling reconciliation. State, interactions, contexts,
split boundaries, transitions, and keyed-list render callbacks
remain owned by the component's durable instance inside that slot.

When structural slots contain compiler-known keyed-list expressions, hydration adopts every slot
inside one component render transaction. Later refreshes use the same grouped lane, preserving
keyed instance identity and disposing removed registrations once after the complete list group has
published. The compiler supplies stable list-site identity, original collection provenance, and key
identity to that lane. Each materialized key owns the reactive expressions created by its item
factory, and removing the key disposes that item scope after its DOM range reconciles away. The
stable server marker ranges remain the ownership boundary for each resulting DOM range.

SSR allocates one request-owned FIFO task scheduler when the first scheduled task needs it.
`maxAsyncSsrConcurrency` defaults to 4, accepts 1 for serial task execution, and is capped at 32.
The task system owns execution and dependency settlement. HTML traversal remains ordered, so
components do not concurrently mutate document hosts, marker allocation, or enhancement state.

Components with compiler-attached execution subgraphs wire reachable child components before
waiting for their own setup continuations. Ready task generations enter that same request
scheduler; rendering itself holds no task permit. This removes the recursive async
discovery waterfall without building or flattening a request-wide plan. Explicit compatibility
boundaries keep the ordinary drain-before-render path, and structural render reachability still prevents inactive
branches or unselected dynamic components from starting work.

A direct scheduled component executes on a request-local state frame, settles pending
props that ordinary construction or rendering consumes, and preserves dependency provenance only
for compiler-proven task-exclusive inputs. The generated `deferredTaskProps` list is the complete
authority for that distinction; SSR does not reconstruct it from the generic execution graph.
The component consumes generated input/output slices directly. It allocates neither a generic component
instance nor a reactive component scope. Its generated setup and task bodies mutate that plain state
directly; request cancellation wraps only the awaits and owned timers that need it. Compiler-proven scheduled child slots emit direct issue
calls in the server artifact, so their setup tasks can enter the bounded scheduler while the parent
prepares their child invocations and before the first sibling settles. Each request owns and disposes its frames, task generations, cancellation, and buffered
resumption snapshots; immutable component contracts, cached resumption schemas, and prepared
indexes are the only cross-request state. Cached schemas contain no request values: they retain
only compiler-selected path segments, context order, and allowed continuation identities. Direct artifacts also omit the generic reactive error context. A direct construction
failure propagates through the request unless the reachable artifact graph explicitly installs the
generic component/error-boundary capability.

Context providers and consumers do not require that generic component capability. Their direct
frames form a request-local logical parent chain and store only contexts actually published by the
component. This preserves nearest-provider and ambient-request lookup while allowing forwarded
children or explicit foreign compatibility values to retain their owning serializer when their
output topology is not compiler-closed.

Compiler-closed hydration publication reads each compiler-declared positional field once while it
constructs the final getter-free tuple arrays. That pass enforces the schema, cycle, depth, and node
limits without allocating property descriptors; a getter on a declared authored field therefore
uses ordinary JavaScript semantics and runs once. Structurally open values and output-extension
results retain descriptor-safe prototype and accessor validation. Serialization encodes validated
reactive collections through the JSON replacer instead of first constructing a second encoded
object graph. The byte limit is computed over the exact escaped UTF-8 payload without allocating an
intermediate byte array. String and progressive rendering select native byte counting when the
host provides it, with a portable counter otherwise. Stream encoding uses the host's native UTF-8
encoder when available and `TextEncoder` otherwise, without importing Node modules into the neutral
runtime. Each emitted byte range remains independently owned. Byte-limit semantics, split-surrogate
accounting, and serialized values are identical on both paths.

All native rendering uses direct resumption capture. Only compiler-owned root state and prop
storage use direct reads; published input
comparisons and nested values retain accessor-safe reads. Hydration JSON escapes script-breaking
characters without changing its wire representation. Static literal `charSet`, `charset`, and
`content` attributes on `meta` elements are compiled into markup on both targets, while server root
attribute bags remain available for enhancement overrides.

Dynamic text of at least 32 UTF-16 code units first uses a native search for HTML escaping
characters. If none are present, it retains the original string and charges it through the output
sink, using the adapter's UTF-8 counter when available. Short text and text requiring escaping keep
the combined escaping/accounting loop. The sink retains exact byte limits and surrogate pairing
across adjacent publications; no encoded buffer or hydration protocol change is introduced.

After output extensions choose the rendered root, SSR reuses a root-keyed immutable contract
blueprint for components reached beneath that root, including dynamic components on first use. It
does not build a second execution-plan index. Weak keys avoid retaining replaced dynamic components,
and an attachment or compiler-identity change forces contract validation again.
The cache contains no props, contexts, state, task generations, cancellation, or other request data.
Request-domain capabilities use a fixed private record shape instead of temporary spread objects.
The public domain remains an immutable execution identity; optional capability defaults, shared
logging state, and request-owned wall-clock samples retain their existing behavior.
Per request, components allocate only their compact value slots and the watchers required by actual
transitions; components without transitions skip continuation-frame allocation entirely.

## Hydration

Hydration adopts matching server nodes rather than recreating them. It
preserves element identity, form state, refs, handlers, retained Activity
ranges, and component ownership.

Compiler-cell roots adopt their existing cell range directly; they do not pass through static-tree
repair or clear the root container. Compiler-proven native component calls use the component's own
identity marker without an additional cell marker pair. Intrinsic cells and structural expression
ranges retain their markers because those ranges still own independent reactive updates.
Compiler-direct structural ranges are claimed by their component-local operation and ordered
hydration cursor, so their explicit marker pair uses one shared anonymous identity instead of
serializing the operation's unrelated stable id. Closing claims pair nested anonymous ranges by
depth. Dynamic-component, keyed, refreshable, and otherwise externally addressable ranges retain
their stable marker identities.
Closed client render programs adopt their intrinsic nodes, scalar slots, and structural child
ranges through component-local claim tuples. Shared focused operations walk the known static topology in DOM
order. A structural call advances directly to its matching close marker, so a variable number of
SSR nodes cannot perturb later static siblings. The successful path therefore creates neither a
region-local identity map nor a second interpreted node/slot plan. The same generated executor
selects the template-sentinel representation for client-created regions, marker-free bounded SSR
text, or the identity-sentinel fallback for ambiguous SSR text. Programs retain the SSR DOM without
rebuilding an equivalent generic host tree. Initial adopted prop binding is covered by the
root-level focus/form snapshot, so it does not repeat focus inspection for every intrinsic.
Completed component mounts cache their first target and host candidates; parent publication reuses
those structural results instead of recursively rediscovering roots through nested components.

Finite render-program roots do not receive a generic cell envelope in compiler-generated SSR. The
program's root element and generated dense claims provide its fixed ownership and hydration
identity. Authored or protocol-facing
`data-exact-id` attributes are not consulted as a fallback render-program identity map.
Variable-width component, cell, fragment, list, and structural ranges keep their markers when no
compiler-known boundary is available. A compiler-proven final structural or component child uses
its parent and the end of the child list as its complete retained boundary. A native child followed
by a plain compiler-known intrinsic can instead use that intrinsic as its exclusive end boundary
when the child belongs to the program root or to a direct intrinsic parent with a stable forward
path, and all later siblings have fixed width. Both forms omit an otherwise redundant comment pair
while preserving the child's explicit range ownership; the parent still does not inspect whether
the child produced multiple nodes or no nodes.

When scalar expressions and static text fill an intrinsic, SSR emits a continuous text span
without scalar comments. Initial bindings collect each value once under normal dependency
tracking. Adoption validates all such runs before splitting text at UTF-16 offsets with
`Text.splitText()`, retaining independent nodes even for empty values. A mismatch uses normal
owning-root recovery. Temporary run plans are released after attachment or disposal; mixed
structural content retains its existing boundary strategy.

Compiler-closed hydratable component roots likewise omit the outer component boundary. Their
direct hydration envelope carries a markerless-root presence bit, which is a compiler proof for
markerless root attachment rather than a request to ignore marker validation. Nested range comments
keep their ordinary ownership.
When the hydration JSON script is emitted beside the root markup, attachment keeps the script in the
DOM but excludes it from the component's adopted output range.

The ordinary compiler-direct document path publishes that envelope as a versioned tuple. A bitmask
identifies which canonical fields follow, and the values appear once in fixed protocol order. This
keeps optional metadata compact without turning authored values into a new encoding: root props,
state, contexts, endpoint tables, and other authored containers still cross the descriptor-safe
validation boundary in their existing representation. The validator rejects unknown mask bits,
missing values, and trailing values. The hydration-only client entry also rejects complete-runtime
fields such as endpoints and continuations. Output extensions retain the keyed envelope because
they are an explicit generic transformation boundary rather than a compiler-direct document.

Schema-defined empty hydration metadata is omitted from compiler registrations and document
payloads. Hydration restores omitted continuation arrays and resumption arrays or objects with
shared immutable empty values. This compaction never applies recursively to authored state, props,
or public-context values, where an empty collection remains meaningful application data.
The Vite, Webpack, and Bun adapters also accept `renderMode: 'hydrate'` for browser artifacts that
adopt SSR HTML and `renderMode: 'client'` for fresh-mount-only artifacts. Both modes retain the
same executable component semantics while leaving analysis-only state, task, and reactive
inventories in the compiler's build result instead of emitted JavaScript. Client-only projection
also omits component resumption records. The default `universal` mode preserves the complete
contract when a build cannot commit to one browser rendering mode.
An SSR-only server entry can use `target: 'server'` with `renderMode: 'server-render'`. That facet
retains compiled setup, dependency-ready tasks, rendering, and resumption publication while omitting
the executors used only by later continuation requests. A server that also composes an executor
contract must keep the default complete server mode or build a separate executor entry.
Applications whose client entry imports a generated hydration registration should set
`includeContinuations: false` in `createExactHydrationConfig()` so the HTML does not duplicate the
same continuation contracts.
Artifact generation may also emit a named client bootstrap from that registration. The build graph
selects the server-operation and lazy-island client surface before bundling, while the emitted
module contains only executable registrations and request-independent tables—not the graph's
descriptive component or partition inventory.
When a lazy island later exposes the same compiler contract, hydration canonicalizes omitted empty
client fields before comparison. Equivalent repeat registration is idempotent; a materially
different contract with the same continuation identity remains an error.

Compiler-finite client boundaries are grouped once per response by component name and canonical
prop schema. Each boundary carries a compact table coordinate instead of repeating its component
name and serialized props; opaque spreads retain the self-describing representation. Hydration
validates the table, row arity, coordinate, and boundary identity before constructing props.
Malformed rows are isolated from valid siblings. Interaction-only compact boundaries retain the
shared table without per-boundary props objects until activation, and the table is released after
the final dormant coordinate is claimed.

Progressive inline streams install one root-confined replacement helper on the first reveal and
emit small ordered calls afterward. `progressiveMode: 'inert'` continues to emit non-executable
template payloads. Root hydration derives and removes the response helper before publishing
hydrated ownership, while any late reveal observes the hydrated root and refuses to mutate it.

Component resumption records authorize state restoration only when the DOM
renderer has matched an SSR component marker and is constructing that exact
component for adoption. Compiled markers use the same contract identity as
resumption records. Mismatched route or conditional ranges mount as fresh client
instances, even while compatible ancestors continue adopting.
Records follow the committed component-tree traversal rather than speculative preparation order.
Each adopted component claims the next compact activation from a request-owned cursor before its
descendants claim theirs. Scheduled server frames reserve their activation only when their writer
enters that traversal, so preparation cannot reorder the hydration stream. Adoption checkpoints
restore the cursor when a candidate range fails.

Root hydration parses and validates its embedded bootstrap configuration once, then passes the
resolved immutable inputs into client construction. Static scalar DOM props bypass reactive watcher
construction; compiler expressions and supported composite class or `srcdoc` values retain observed
bindings.

An application whose root component receives its initial request data as props can opt into one
authoritative bootstrap copy:

```tsx
// server
const result = await renderToHydratableString(<App initialData={data} path={url.pathname} />, {
	publishRootProps: true
});

// client
const props = readPublishedRootProps<AppProps>(App, container);
hydrateAfterNavigation(<App {...props} />, container);
```

`publishRootProps` requires a component root and cannot be combined with a separate hydration
`state`. The compiler records direct setup assignments such as
`this.state.items = props.initialData.items`. SSR omits that resumable state value only when the
published prop path and final state value are identical. Derived, mutated, ambiguous, or nested
component state remains in its ordinary component resumption record. Reading the props and later
resolving hydration options reuse the same bounded decode. For finite nested prop types, the
compiler places an immutable positional schema on both target artifacts. The server publishes
matching plain values as component-bound nested arrays during the combined validation and
projection traversal, and the client reconstructs the authored objects only after verifying the
component identity. Structurally open values, runtime shape
mismatches, output extensions, and unsupported types retain the named-object format. Descriptor-safe
validation applies to structurally open values; declared positional fields use the single-read
rules described above. Hydration limits apply in either form. The generated tuple arrays do not
undergo a second validation traversal before JSON serialization.

Compiler-finite client boundaries group their props in the response hydration table by component
and canonical prop order. Within one immutable server build, the boundary's compiler-generated ID
also reuses that schema across requests, so publication does not repeatedly discover, sort, and
hash the same prop names. A conditional server child range has separate present and absent schema
variants. The shared cache contains only component names and prop-name arrays; boundary values,
component state, request tables, and coordinates remain request-owned.

The `@exactjs/hydrate/root` entry uses a bounded hydration-only field projection. Operation
endpoints, continuations, islands, and transports belong to the complete runtime; their presence in
a root-only document configuration fails closed. Build identity, component authorization,
resumptions, public contexts, state, wall-clock activation, and the compact hydration table retain
the same validation and resource ceilings.

Finite component-registry selections retain the registry binding, selected
key, and opaque compiled entry identity in their component marker. A matching
selection adopts normally. A nested mismatch remounts only that owned
component range and preserves compatible sibling DOM; a root mismatch follows
the configured root recovery policy.

The compiler classifies safe interaction-only islands. Their SSR fallback
contains the real intrinsic markup and binding values but no active handlers.
The generated hydration registration uses dynamic imports, so the island code
loads on first supported interaction. While it loads:

- activation events retain their order;
- repeated input/change events coalesce to the latest value per target;
- replay is generation-fenced and discarded if the boundary was replaced; and
- load failure restores the native browser fallback where possible.

Refs, initial client work, opaque prop spreads, unsupported events, and
server-only child graphs remain eager.

## Server exchanges and patches

The endpoint supports individual invocation/refresh operations and same-tick
batches. Independent operations may run concurrently; `dependsOn` expresses an
explicit prerequisite. NDJSON responses can publish independently settled
operation chunks.

The client sends only compiler-approved state, dependency, capture, and
boundary snapshots. Successful responses are shape-validated before
application. Available patches include:

- text, attributes/properties, and styles;
- keyed-list changes;
- component state;
- compiler-stable dynamic range replacement;
- independent nested element replacement; and
- authoritative boundary replacement.

Property patches are limited to non-executable, non-structural DOM properties. Inline event
handlers, `srcdoc`, prototype controls, and setters such as `innerHTML`, `outerHTML`, and
`textContent` are rejected by both the server response validator and the hydration commit planner.
Text and structural changes must use their dedicated operations so ownership cleanup and unsafe
HTML policy cannot be bypassed.

Stable dynamic markers let a server refresh replace one structural expression
without recreating unaffected siblings or component instances. Partition refresh
contracts authorize only their declared range and descendant ranges; a response
targeting an ancestor or independent sibling is rejected before publication.
Hosts that retain dynamic branch or keyed instances provide `resolvePartitionAuthority`
to the server runtime. The resolver returns the current build, edge, owner,
discriminator, and generation tuple; stale or released instances are rejected before
the refresh handler runs.
Boundary replacement remains the correctness fallback.

Runtime inspection exposes the same retained ranges through `partitions.tree`.
The Chromium DevTools component view shows their host, opaque plan identity,
component owner, activation mode and fallback reason, discriminator kind, generation, and nested range ancestry without
turning inspection identities into dispatch authority.

Compiler-proven interaction islands install only the delegated listeners named by their generated
registry policy. `click` and `submit` resume through native `click()` and `requestSubmit()`;
`input` and `change` preserve the browser's already-applied control mutation and coalesce to the
latest value; focus events replay notification only. Queues retain identities and policy fields,
never native `Event` objects, and are generation-fenced and bounded. Refs, unsupported events or
event data, observable initial work, and non-finite spreads produce source-located eager reasons.
Finite immutable object spreads are expanded in source overwrite order, leaving handlers in the
client artifact and sending only fallback values through SSR. Independently planned server ranges
remain inert inside a dormant client island and retain their own refresh generation.
The generated policy belongs to the lazy registry entry. An eager component entry cannot inherit
interaction authority from boundary markup, and hydration does not install a general event family
for such an entry.

Passive hydration does not manufacture a focus transition when the document body owns focus. When
an authored control already owns focus, DOM adoption and later reactive patches preserve that
connected element and its input or editable selection if browser DOM work temporarily drops focus.

When an interaction island loads, hydration prepares its immutable component execution slice from
the compiled definition and caches it by component artifact. Adoption installs only the root's
authorized setup-transition watchers; already-resumed continuations suppress their initial
generation, while unresolved live-ins use the declared predecessor slots. Dependency cycles fail
the activation instead of leaving it indefinitely loading. The slice exists only while the island
region is constructed, so it cannot suppress or activate unrelated dormant components. Boundary
generation replacement, abort, or unmount continues to fence loader completion, queued events, and
task publications.

## Data boundary

Hydration bootstrap data and protocol values use validated JSON-safe data.
Server requests bound and validate the complete encoded JSON graph before reactive protocol
decoding. Decoding reconstructs only plain data and validated collection envelopes, so dispatch
does not repeat the same graph traversal after reconstruction; operation contracts and security
hooks remain independent authoritative checks.
Compiler-approved `Map` and `Set` state uses tagged entries and is restored as
real collections; continuation changes travel as ordered entry or membership
deltas. Functions, DOM nodes, unsupported class instances, `Date`, cycles,
server contexts, and secret-qualified values are rejected.

## Remaining work

- Measured [structural render-program refresh extensions](proposals/compiler-planned-structural-refresh.md)
  may add proven patch fast paths, but current range and boundary replacement is already the
  correctness contract and does not block later SSR work.
- Webpack, Bun, and Vite/Rollup now share the production microfrontend artifact and recovery contract.
- Persisting postponed renderer state across requests is intentionally not planned: ordinary
  Suspense and progressive SSR provide the useful behavior without checkpoint reconstruction and
  distributed replay coordination.

See [server-components.md](server-components.md) for authoring and
[component-registries.md](component-registries.md) for finite dynamic
component selection,
[actions-and-forms.md](actions-and-forms.md) for task interactions and forms, and
[native-ssr-production-guide.md](native-ssr-production-guide.md) for production
operation.

## Decoded collection validation limits

Decoded Map string keys count toward the configured byte budget on both server and hydration
validation paths. Map and Set traversal checks the remaining node budget before queueing entries,
so an oversized collection is rejected without first expanding the entire collection into work.
