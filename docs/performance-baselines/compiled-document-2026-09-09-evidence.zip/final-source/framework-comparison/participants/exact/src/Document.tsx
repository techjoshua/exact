import { IncidentApp } from './IncidentApp.jsx';
import type { InitialData } from './types.js';

/** Trusted build-generated asset tags used by the application document. */
export type DocumentOptions = { clientTags?: string };

/** Root document shared by server rendering and browser document adoption. */
export function Document(props: DocumentOptions & { initialData?: InitialData; path?: string }) {
	return () => (
		<html lang="en">
			<head>
				<meta charSet="UTF-8" />
				<meta name="viewport" content="width=device-width, initial-scale=1.0" />
				<meta name="framework-participant" content="exact" />
				<title>Incident Operations</title>
				{scriptSources(props.clientTags).map((src) => (
					<script type="module" src={src} />
				))}
				{stylesheetSources(props.clientTags).map((href) => (
					<link rel="stylesheet" href={href} />
				))}
			</head>
			<body>
				<div id="app" data-render-mode="ssr">
					<IncidentApp initialData={props.initialData} path={props.path} />
				</div>
			</body>
		</html>
	);
}

function scriptSources(tags = ''): string[] {
	return Array.from(tags.matchAll(/<script\b[^>]*\bsrc="([^"]+)"/g), (match) => match[1]!);
}

function stylesheetSources(tags = ''): string[] {
	return Array.from(tags.matchAll(/<link\b[^>]*\bhref="([^"]+)"/g), (match) => match[1]!);
}
