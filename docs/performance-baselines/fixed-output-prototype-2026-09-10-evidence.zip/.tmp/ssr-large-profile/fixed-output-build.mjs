import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'fixed-output',{recursive:true});
const source=await fs.readFile(root+'merged-output/server-entry.js','utf8');
const ast=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const edits=[];let targets=0,executions=0,factories=0;
function visit(n){
 if(ts.isNewExpression(n)&&n.expression.getText(ast)==='SsrOperationTarget'){
  edits.push({start:n.expression.getStart(ast),end:n.expression.end,text:"(auditStage==='reuse'?AuditMergedOperationTarget:SsrOperationTarget)"});targets++;
 }
 if(ts.isFunctionDeclaration(n)&&n.name?.text==='renderServerComponentArtifactOutput'){
  function inner(c){
   if(ts.isVariableDeclaration(c)&&c.name.getText(ast)==='execution'){
    edits.push({start:c.initializer.getStart(ast),end:c.initializer.end,text:`auditStage==='reuse'?new AuditMergedArtifactExecution(context,options,publication,publish,renderChildren,renderOwnedComponent):${c.initializer.getText(ast)}`});executions++;
   }
   ts.forEachChild(c,inner);
  }inner(n.body);
 }
 if(ts.isFunctionDeclaration(n)&&n.name?.text==='auditOutput'){
  edits.push({start:n.body.getStart(ast),end:n.body.end,text:`{
   if(target.context!==context||target.preparation!==undefined||target.sink!==context.writerSink)throw Error('Invalid fixed output ownership');
   ++auditCounts.reused;return target;
  }`});factories++;
 }
 ts.forEachChild(n,visit);
}
visit(ast);if(!targets||executions!==1||factories!==1)throw Error('Missing target constructors');
let output=source;for(const e of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,e.start)+e.text+output.slice(e.end);
output+=`
class AuditMergedOperationTarget extends SsrOperationTarget {
 constructor(context,parent,options,hasComponentAncestor,renderChildren){
  super(context,parent,options,hasComponentAncestor,renderChildren);this.sink=context.writerSink;
 }
 render(value){return this.renderProgramSegment(value);}
 prepareReferences(values){return this.prepareProgramReferences(values);}
}
class AuditMergedArtifactExecution {
 constructor(context,options,publication,publish,renderChildren,renderOwnedComponent){
  this.context=context;this.options=options;this.publication=publication;this.publish=publish;
  this.renderChildren=renderChildren;this.renderOwnedComponent=renderOwnedComponent;
  this.renderOwner=undefined;this.sink=context.writerSink;
 }
 render(value){return this.renderProgramSegment(value);}
 prepareReferences(values){return this.prepareProgramReferences(values);}
}
AuditMergedArtifactExecution.prototype.renderProgramSegment=renderExecutionProgramSegment;
AuditMergedArtifactExecution.prototype.prepareProgramReferences=prepareExecutionProgramReferences;
`;
await fs.writeFile(root+'fixed-output/server-entry.js',output);
await fs.writeFile(root+'fixed-output/sites.json',JSON.stringify({targets,executions,factories}));
for(const suffix of ['run.mjs','check.mjs','pressure.mjs']){
 let script=(await fs.readFile(root+'merged-output-'+suffix,'utf8')).replaceAll('merged-output','fixed-output');
 await fs.writeFile(root+'fixed-output-'+suffix,script);
}
await fs.copyFile(root+'hydration-ablation/worker.mjs',root+'fixed-output/worker.mjs');
console.log({targets,executions,factories});
