import hashlib
import json
import zipfile
from pathlib import Path
from statistics import mean

base=Path('.tmp/ssr-large-profile');folder=base/'fixed-output'
data=json.loads((folder/'capture.json').read_text());assert data['complete']
rows=[]
for population in (0,1):
    blocks=[b for b in data['blocks'] if b['population']==population]
    assert [b['phase'] for b in blocks]==['none','reuse','none']
    controls=[blocks[0],blocks[2]];b=blocks[1]
    def render(x):
        s=x['after']['telemetry']['statistics']['renderMs'];return s['sum']/s['count']*1000
    def loop(x):return mean(x[k]['meanMs'] for k in ('loopBefore','loopAfter'))*1000
    normal=mean(c['rps'] for c in controls)
    rows.append(dict(population=population+1,normalRps=normal,candidateRps=b['rps'],gainPct=(b['rps']/normal-1)*100,
                     normalHttpUs=mean(render(c) for c in controls),candidateHttpUs=render(b),normalLoopUs=mean(loop(c) for c in controls),candidateLoopUs=loop(b)))
valid=sum(b['valid'] for b in data['blocks']);errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages']);assert errors==0
alloc=[]
for file in sorted(folder.glob('allocation-*.heapprofile')):
    profile=json.loads(file.read_text())
    alloc.append(dict(file=str(file),mode=file.stem.split('-')[-1],sampledBytesPerRender=sum(s['size'] for s in profile['samples'])/10000))
assert len(alloc)==4
(folder/'summary.json').write_text(json.dumps(dict(rows=rows,allocations=alloc,valid=valid,errors=errors),indent=2))
report=Path('docs/performance-baselines/fixed-output-prototype-2026-09-10.md')
lines=['# Constructor-initialized combined outputs, 2026-09-10','','## Hypothesis and design','',
'The previous combined target/output reduced allocation volume but ran slower.',
'Test whether adding fields after target construction caused that regression.',
'This variant initializes sink during construction and places render/prepare',
'forwarding on prototypes. A subclass handles operation targets; a dedicated',
'execution class handles component targets. Baseline mode keeps the original',
'constructors and execution objects. Both modes are present in one artifact.', '',
'Programs that own preparation retain separate outputs. The existing generated',
'writer capability classification is diagnostic AST metadata, not a public ABI.',
'Eligible programs use the target as output, retaining the original host and',
'completion flow. Guards reject sink/context changes and unexpected preparation.',
'Separate output constructions remain reduced from 24 to six per fixture render.', '',
'## Validation and measurement','',
'Four ordinary/escaped full-document checks pass. Twelve forced suspension/failure',
'comparisons pass on Node and twelve on Bun using the portable artifact, covering',
'small/large strings, selected drain rejections and complete streaming output.',
'This is not native Bun HTTP validation or complete adoption coverage.', '',
'Two fresh Node string workers each run baseline/candidate/baseline after ten',
'seconds of HTTP warmup, with five-second blocks and two fresh drivers each',
'holding 16 requests in flight. The baseline is the mean of adjacent blocks.',
'Independent isolated loops before/after each block warm and measure 10,000 renders.', '',
'| Worker | Baseline RPS | Candidate RPS | Change | Baseline HTTP us | Candidate HTTP us |',
'| --- | ---: | ---: | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['population']} | {r['normalRps']:,.0f} | {r['candidateRps']:,.0f} | {r['gainPct']:+.2f}% | {r['normalHttpUs']:.2f} | {r['candidateHttpUs']:.2f} |")
lines+=['',f'All {valid:,} measured responses match the complete 4,672-byte document;',
'zero errors. Counters, artifact hashes and adapter hashes are checked. Owned',
'worker/load processes exit. Raw isolated durations are preserved in summary.json.', '',
'## Allocation follow-up','',
'Four fresh Node processes run baseline/candidate/candidate/baseline, 50,000 warm',
'renders then 10,000 sampled renders, with a 16 KiB interval and collected minor/',
'major-GC objects included. Sampling estimates allocated bytes, not retained heap',
'or GC pause time. Allocation capture runs after HTTP, never concurrently.', '',
'| Sample | Mode | Sampled bytes/render |','| --- | --- | ---: |']
for i,r in enumerate(alloc):lines.append(f"| {i+1} | {r['mode']} | {r['sampledBytesPerRender']:,.0f} |")
lines+=['','## Decision','',
'Do not adopt this variant. Constructor initialization did not recover throughput.',
'The test changes target types, object layouts and forwarding methods together;',
'it does not prove which of those causes the slowdown. The original shared output',
'shape may aid writer helpers, but that remains an inference requiring profiling',
'or a controlled shape experiment. Fewer objects alone are not a sufficient reason',
'to redesign this boundary. No production source changes were made.', '',
'The shared SSR performance goal remains open. Do not repeat the same combined-',
'output experiments without a new explanation supported by evidence.', '',
'The adjacent archive contains builders, checks, raw HTTP/heap samples, fixture,',
'artifacts and a verified SHA-256 inventory. Workspace dependencies are not',
'packaged as a standalone distribution.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[report,Path('.tmp/positional-leaves/data.json')]+[base/n for n in ('fixed-output-build.mjs','fixed-output-check.mjs','fixed-output-pressure.mjs','fixed-output-run.mjs','fixed-output-report.py','merged-output-allocation-worker.mjs','merged-output/server-entry.js','merged-output-run.mjs','merged-output-check.mjs','merged-output-pressure.mjs','hydration-ablation/worker.mjs','component-forwarding-integrated/server-entry.js')]
files=sorted(set(f for f in files if f.is_file()));archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={f.as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in files:z.write(f,f.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps(rows,indent=2));print(json.dumps(alloc,indent=2));print(valid,'valid;',len(files),'verified files')
