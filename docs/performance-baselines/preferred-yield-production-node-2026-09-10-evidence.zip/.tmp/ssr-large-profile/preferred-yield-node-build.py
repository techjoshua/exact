from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'source-scheduler-preferred-node';root.mkdir(exist_ok=True)
for name in ('worker.mjs','old-scheduler.mjs'):
 (root/name).write_bytes((base/'source-scheduler-preferred'/name).read_bytes())
r=(base/'source-scheduler-preferred-run.mjs').read_text().replace('source-scheduler-preferred/','source-scheduler-preferred-node/').replace('preferred-yield-production-bun','preferred-yield-production-node')
r=r.replace("availableSsrRuntimes('bun')","availableSsrRuntimes('node')").replace("transport:'bun-fetch'","transport:'node-http'").replace('dist-bun-server/bun-server-entry.js','dist-server/server-entry.js')
(base/'source-scheduler-preferred-node-run.mjs').write_text(r)
p=(base/'preferred-yield-report.py').read_text().replace("base/'source-scheduler-preferred'","base/'source-scheduler-preferred-node'").replace('preferred-yield-production-bun-2026-09-10','preferred-yield-production-node-2026-09-10').replace('production implementation on Bun','production implementation on Node').replace('Native Bun transport remains in use.','Both participants use Node HTTP transport.').replace('Larger workloads and Node performance of this changed primitive remain outstanding.','Larger workloads and browser and sparse-traffic validation remain outstanding.').replace("base/'source-scheduler-preferred-run.mjs'","base/'source-scheduler-preferred-node-run.mjs',base/'preferred-yield-node-build.py'")
(base/'preferred-yield-node-report.py').write_text(p)
