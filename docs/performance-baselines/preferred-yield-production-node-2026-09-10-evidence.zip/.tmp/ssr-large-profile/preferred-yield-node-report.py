import json,hashlib,zipfile
from pathlib import Path
from statistics import mean
base=Path('.tmp/ssr-large-profile'); folder=base/'source-scheduler-preferred-node'
d=json.loads((folder/'capture.json').read_text());assert d['complete'] and len(d['blocks'])==16
rows=[]
for mode in ('string','stream'):
 for pop in (0,1):
  bs=[b for b in d['blocks'] if b['mode']==mode and b['population']==pop]
  old=mean(b['rps'] for b in bs if b['phase']=='scheduled')
  new=next(b['rps'] for b in bs if b['phase']=='preferred')
  react=next(b['rps'] for b in bs if b['id']=='react')
  rows.append(dict(mode=mode,population=pop+1,oldRps=old,newRps=new,reactRps=react,gainPct=(new/old-1)*100))
for b in d['blocks']:
 assert b['after']['scheduleCalls']==(b['valid']+len(b['results']) if b['phase']!='normal' else 0)
 assert all(s['errors']==0 for r in b['results'] for s in r['stages'])
valid=sum(b['valid'] for b in d['blocks'])
(folder/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid),indent=2))
report=Path('docs/performance-baselines/preferred-yield-production-node-2026-09-10.md')
lines=['# Preferred yield scheduler: production implementation on Node','',
'Hypothesis: preferring scheduler.yield while retaining prompt cancellation and propagating yield failures should preserve the scheduling gain. The preceding diagnostic omitted signal support. This capture uses the rebuilt Node-adapter scheduler, selecting node:timers/promises scheduler.yield when available and setImmediate otherwise. The old scheduler is restored from the SHA-verified prior source-render-scheduler-bun archive. React is unchanged. Both participants use Node HTTP transport.', '',
'Each mode uses fresh eXact/React/React/eXact workers, ten-second warmup and five-second blocks at concurrency 32. eXact runs old/new/old, with averaged old controls. React runs unchanged. Machine workload can vary. Each response is rendered independently and validated against complete-document identity. Source API defaults remain opt-in.', '',
'| Mode | Repeat | Previous scheduler RPS | Preferred yield RPS | React RPS | Change |',
'| --- | ---: | ---: | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['mode']} | {r['population']} | {r['oldRps']:,.0f} | {r['newRps']:,.0f} | {r['reactRps']:,.0f} | {r['gainPct']:+.2f}% |")
lines+=['',f'{valid:,} complete validated measured responses, zero errors. Scheduler counts match measured requests plus driver preflights. Participant and dependency artifact guards pass. Node-adapter tests: 38 passed, including yield and fallback batching/cancellation, asynchronous yield rejection and synchronous failure recovery. Build and targeted lint passed.', '',
'HTTP benchmark calls are signal-free; cancellation correctness is established separately by unit tests. These runs do not establish browser or sparse-traffic performance. Larger workloads and browser and sparse-traffic validation remain outstanding.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[report,base/'preferred-yield-build.py',base/'preferred-yield-node-report.py',base/'source-scheduler-preferred-node-run.mjs',base/'preferred-yield-node-build.py']+[Path(p) for p in ('framework-adapters/node-adapter/src/render-scheduler.ts','framework-adapters/node-adapter/src/render-scheduler.test.ts','framework-adapters/node-adapter/dist/render-scheduler.js')]
archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print(json.dumps(rows,indent=2));print(valid,'validated responses')
