import hashlib,json,pathlib,zipfile
root=pathlib.Path('.');work=root/'.tmp/ssr-large-profile'
rows=json.loads((work/'single-result-results.json').read_text(encoding='utf-8'));summary=[]
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['small','large']:
   changes=[]
   for round in range(2):
    group=[r for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['round']==round]
    a=next(r for r in group if r['variant']=='callback-current');b=next(r for r in group if r['variant']=='single-result')
    assert a['hash']==b['hash'];changes.append((b['usPerRender']/a['usPerRender']-1)*100)
   summary.append(dict(runtime=runtime,mode=mode,scenario=scenario,changes=changes))
table='\n'.join(f"| {s['runtime']} | {s['mode']} | {s['scenario']} | {s['changes'][0]:+.2f}% | {s['changes'][1]:+.2f}% |" for s in summary)
dest=root/'docs/performance-baselines/single-result-2026-09-09'
dest.with_suffix('.json').write_text(json.dumps(dict(summary=summary,rows=rows),indent=2)+'\n',encoding='utf-8')
doc='''# Single-chunk string result prototype

Date: 2026-09-09. Candidate warrants confirmation; production unchanged.

## Hypothesis and implementation

createChunkedStringResult currently creates a lazy getter closure even when the renderer has
already completed one string. The candidate returns an ordinary html data property for exactly
one chunk and keeps the lazy getter for all other chunk counts. The hypothesis is a small
allocation/dispatch saving most visible on small documents. No numerical gain was preregistered.

The candidate preserves hydration insertion, hidden chunk metadata, state, and optional result
metadata. However, it intentionally changes the single-chunk html property from a getter to a
writable data property and captures its value at result construction. The public TypeScript field
is currently writable, while runtime assignment to the getter throws in strict mode. A production
decision must classify that behavior change and confirm no internal caller mutates the supposedly
readonly chunk array after construction. No compatibility alias is proposed for this unreleased API.

## Method and results

Thirty-two fresh processes: Node/Bun, string/consumed stream, three/96 incidents, two reversed-order
pairs per cell. NODE_ENV=production, 5,000 warmups and 12,000 measured renders. Both runtimes use the
same portable bundle. The application renders its full document, client tags are empty, and streams
are consumed with Response.text(). All paired full-document hashes match.

Positive means longer rendering time. These are preliminary local timings, not confidence bounds.

| Runtime | Mode | Fixture | Pair 1 time change | Pair 2 time change |
| --- | --- | --- | ---: | ---: |
'''+table+'''

Small Node strings and small streams on both runtimes improved in both pairs. Large Bun strings
regressed slightly in both pairs. Several larger stream gains vary substantially between pairs,
so the data warrants confirmation rather than a universal speedup claim. This candidate has not
been rejected or adopted. Follow-up should assess the result-property contract and repeat the
promising cells while checking the Bun string tradeoff.

No production edits, package tests, or browser tests were performed for this bundle prototype.
Hash equality alone is insufficient for acceptance. The overall React parity goal remains unmet;
React and actual HTTP adapters were not measured here.

The evidence archive preserves the frozen control/candidate, worker, runner, builder, fixed input,
raw observations, reporter, and SHA-256 manifest.
'''
dest.with_suffix('.md').write_text(doc,encoding='utf-8')
files=[work/name for name in ['callback-current.mjs','single-result.mjs','single-result-build.mjs','single-result-run.mjs','single-result-results.json','single-result-report.py','long-worker.mjs','segments-only-run.mjs']]+[root/'.tmp/positional-leaves/data.json']
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps({p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(table);print('Verified',archive)
