import assert from 'node:assert/strict';
import {PublicationStringSink} from './application-string-deferred-sink.mjs';
import {PublicationByteSink} from './incremental-publication-state-sink.mjs';
const text='<html>é中😀\ud800a\udc00😃</html>';
let cases=0;
for(let a=0;a<=text.length;a++)for(let b=a;b<=text.length;b++)for(const maxBytes of [0,8,Buffer.byteLength(text)-1,Buffer.byteLength(text),Infinity]) {
 const fragments=[text.slice(0,a),'',text.slice(a,b),'',text.slice(b)];
 const strings=new PublicationStringSink({maxBytes});
 const chunks=[];
 const bytes=new PublicationByteSink(chunk=>chunks.push(chunk),{maxBytes,threshold:8});
 function execute(sink) {
  try {for(const fragment of fragments){sink.write(fragment);sink.flush('head');}return {bytes:sink.finish()};}
  catch(error){assert.throws(()=>sink.write('late'),/closed/);return {error:error.message};}
 }
 const result=execute(strings);
 assert.deepEqual(result,execute(bytes));
 if(!result.error){assert.equal(strings.value,text);assert.deepEqual(Buffer.from(strings.value),Buffer.concat(chunks));}
 else assert.equal(strings.value,'');
 strings.destroy();strings.destroy();assert.equal(strings.value,'');cases++;
}
console.log(JSON.stringify({cases,runtime:process.versions}));
