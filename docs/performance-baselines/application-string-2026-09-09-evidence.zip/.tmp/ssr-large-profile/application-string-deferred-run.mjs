import fs from 'node:fs';import {spawnSync} from 'node:child_process';import {createHash} from 'node:crypto';
const d='.tmp/ssr-large-profile/',dir=d+'application-string/',rows=[];
for(const runtime of ['node','bun'])for(const scenario of ['assets','large'])for(let round=0;round<2;round++)for(const variant of round?['string-sink-deferred','current-production']:['current-production','string-sink-deferred']){
 const entry=dir+variant+'.mjs';
 const run=spawnSync(runtime,[d+'production-refresh-worker.mjs',entry,'string',scenario,'12000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(run.status!==0)throw Error(run.stderr||run.stdout);
 const row={runtimeId:runtime,round,variant,artifactSha256:createHash('sha256').update(fs.readFileSync(entry)).digest('hex'),...JSON.parse(run.stdout)};
 const peer=rows.find(r=>r.scenario===scenario);if(peer&&peer.hash!==row.hash)throw Error('Document changed');
 rows.push(row);fs.writeFileSync(dir+'deferred-results.json',JSON.stringify(rows,null,2));console.log(runtime,scenario,round,variant,row.usPerRender.toFixed(2));
}
