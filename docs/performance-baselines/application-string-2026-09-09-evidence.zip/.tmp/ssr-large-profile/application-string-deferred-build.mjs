import fs from 'node:fs';
const d='.tmp/ssr-large-profile/',dir=d+'application-string/';
const source=fs.readFileSync(dir+'string-sink-accounted.mjs','utf8').replace("'../publication-string-sink.mjs'","'../application-string-deferred-sink.mjs'");
fs.writeFileSync(dir+'string-sink-deferred.mjs',source);
let runner=fs.readFileSync(d+'application-string-run.mjs','utf8');
runner=runner.replace("['string-sink-accounted','string-sink','accumulator-control','current-production']:['current-production','accumulator-control','string-sink','string-sink-accounted']","['string-sink-deferred','current-production']:['current-production','string-sink-deferred']").replace("dir+'results.json'","dir+'deferred-results.json'");
fs.writeFileSync(d+'application-string-deferred-run.mjs',runner);
