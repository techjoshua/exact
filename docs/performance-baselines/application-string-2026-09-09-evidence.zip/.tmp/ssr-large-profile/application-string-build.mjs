import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
const root='.tmp/ssr-large-profile/',dir=root+'application-string/';fs.mkdirSync(dir,{recursive:true});
fs.copyFileSync('framework-comparison/participants/exact/dist-server/server-entry.js',dir+'current-production.mjs');
fs.copyFileSync(root+'map-fragment-run.mjs',dir+'map-fragment-run.mjs');
const stages=['shared-accumulator-build','shared-accumulator-direct-build','shared-accumulator-ranges-build','direct-writer-build','direct-writer-continuation-build','direct-writer-siblings-build'];
for(const stage of stages){
 let code=fs.readFileSync(root+stage+'.mjs','utf8').replaceAll(root,dir);
 if(stage==='shared-accumulator-build')code=code.replace('marker-hex-current.mjs','current-production.mjs');
 if(stage==='direct-writer-siblings-build')code=code.replace('direct-writer-current-node.mjs','direct-writer-continuation.mjs');
 fs.writeFileSync(dir+stage+'.mjs',code);
 const run=spawnSync(process.execPath,[dir+stage+'.mjs'],{encoding:'utf8',windowsHide:true});
 if(run.status!==0)throw Error(stage+': '+run.stderr+run.stdout);
}
let source=fs.readFileSync(dir+'direct-writer-siblings.mjs','utf8');
const scope=`function executeDirectWriter(invocation,output){
 return withRenderCleanup(()=>executePreparedDirectWriter(invocation,output),()=>output.preparation?.[Symbol.asyncDispose]());
}`;
if(!source.includes(scope))throw Error('Missing scope');
source=source.replace(scope,`function executeDirectWriter(invocation,output){
 let result;
 try{result=executePreparedDirectWriter(invocation,output);}
 catch(error){if(!output.preparation)throw error;return withRenderCleanup(()=>{throw error;},()=>output.preparation[Symbol.asyncDispose]());}
 return output.preparation?withRenderCleanup(()=>result,()=>output.preparation[Symbol.asyncDispose]()):result;
}`);
fs.writeFileSync(dir+'accumulator-control.mjs',source);
function replace(a,b){if(source.split(a).length!==2)throw Error('Missing unique '+a);source=source.replace(a,b);}
source="import {PublicationStringSink} from '../publication-string-sink.mjs';\n"+source;
replace('context.experimentalSink={value:""};',`context.experimentalSink=new PublicationStringSink({maxBytes:context.maxOutputBytes});
 return withRenderCleanup(()=>renderCollectedTree(context,operation,options,omitRootBoundary,outputKind,renderOptions),()=>context.experimentalSink.destroy());
}
function renderCollectedTree(context,operation,options,omitRootBoundary,outputKind,renderOptions){`);
replace('html=context.experimentalSink.value+html;',`if(html)context.experimentalSink.write(html);
 context.experimentalSink.finish();
 html=context.experimentalSink.value;`);
replace('function appendSharedSink(context,sink,text){','function appendSharedSink(context,sink,text){\n if(sink.write){sink.write(text);return;}');
replace('sink.value=appendBoundedHtml(this.context,sink.value,result.html);','appendSharedSink(this.context,sink,result.html);');
replace("sink.value=appendBoundedHtml(this.context,sink.value,'<!-- -->');","appendSharedSink(this.context,sink,'<!-- -->');");
fs.writeFileSync(dir+'string-sink.mjs',source);
// The collector has validated the complete string. Resource-hint prepending still recounts.
const start=source.indexOf('function renderCollectedTree('),end=source.indexOf('//#endregion',start);
let body=source.slice(start,end);
if(!body.includes('output.append(html);'))throw Error('Missing final collection');
body=body.replace('output.append(html);','output.appendAccounted(html);');
fs.writeFileSync(dir+'string-sink-accounted.mjs',source.slice(0,start)+body+source.slice(end));
console.log('Built fresh accumulator and two native string-sink variants.');
