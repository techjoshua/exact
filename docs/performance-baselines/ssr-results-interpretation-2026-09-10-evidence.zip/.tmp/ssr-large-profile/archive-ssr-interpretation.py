from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();base=root/'.tmp/ssr-large-profile'
report=root/'docs/performance-baselines/ssr-results-interpretation-2026-09-10.md'
files={report,Path(__file__).resolve(),base/'inline-slot-frame-interpret.py',base/'inline-slot-frame/interpretation.json',base/'inline-slot-frame/http.json',base/'inline-slot-frame/followup-http.json',base/'inline-slot-frame/summary.json',root/'docs/performance-baselines/inline-slot-frame-http-2026-09-10.md'}
archive=report.with_name('ssr-results-interpretation-2026-09-10-evidence.zip');assert not archive.exists()
manifest={f.relative_to(root).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(files)}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(files):z.write(f,f.relative_to(root).as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified',len(files),'files')
