from pathlib import Path
from statistics import mean, median
import json
base=Path('.tmp/ssr-large-profile')
rows=json.loads((base/'inline-slot-frame/http.json').read_text())+json.loads((base/'inline-slot-frame/followup-http.json').read_text())
results=[]
for runtime,mode in [('node','string'),('node','stream'),('bun','string'),('bun','stream')]:
    group=[r for r in rows if r['runtime']==runtime and r['mode']==mode]
    blocks=[]
    for b in range(6):
        ordered=[r for r in group if r['block']==b]
        rates={r['variant']:r['rps'] for r in ordered}
        blocks.append(dict(block=b,order=[r['variant'] for r in ordered],**rates,change=100*(rates['compiled']/rates['baseline']-1),delta=rates['compiled']-rates['baseline']))
    def effect(bs):return 100*(mean(b['compiled'] for b in bs)/mean(b['baseline'] for b in bs)-1)
    loo=[dict(omitted=b['block'],change=effect([x for x in blocks if x is not b])) for b in blocks]
    result=dict(runtime=runtime,mode=mode,meanChange=effect(blocks),medianPairChange=median(b['change'] for b in blocks),blocks=blocks,leaveOneBlockOut=loo,
        candidateBeforeControlChange=effect([b for b in blocks if b['order'].index('compiled')<b['order'].index('baseline')]),
        candidateAfterControlChange=effect([b for b in blocks if b['order'].index('compiled')>b['order'].index('baseline')]))
    results.append(result)
    print(runtime,mode,'mean',round(result['meanChange'],2),'median pair',round(result['medianPairChange'],2),'leave-one-out',round(min(x['change'] for x in loo),2),round(max(x['change'] for x in loo),2))
    for b in blocks:print(b['block'],','.join(b['order']),*(round(b[k],2) for k in ['baseline','compiled','react','change']))
    print('candidate before/after control',round(result['candidateBeforeControlChange'],2),round(result['candidateAfterControlChange'],2))
(base/'inline-slot-frame/interpretation.json').write_text(json.dumps(results,indent=2))
