# Publication-boundary pressure and CPU budgeting

Follow-up to the latched per-span prototype. CPU checkpoints occur only after actual head/body publications. Existing sink readiness and output accounting remain unchanged. Destination pressure is awaited before consulting the host-owned budget. A promise alone does not refresh a consumed turn; the immediate marker does. Clock sampling is every publication here because there are far fewer transport publications than component-ready calls.

Controls retain shipping Node admission and the dedicated Bun streaming half-millisecond policy. The same renderer bundle contains both sinks. Compiled component emission remains verbatim. Source preparation and all captures stay separate from the earlier prototype. Screening cannot establish mixed-mode production integration on its own.

The large-publication variant adds CPU checkpoints only after body chunks with at least streamBufferSize UTF-16 code units (8192 by default). This conservative work-size screen needs no extra UTF-8 scan. Smaller publications and head publication still honor transport pressure, but add no CPU yield. Existing admission/resumption remains responsible for fairness between small renders.
