import { writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { startSsrLoadProcess } from '../../framework-comparison/src/ssr-load-process-owner.mjs';
import { startSsrWorker,stopSsrWorker,controlSsrWorker } from '../../framework-comparison/src/ssr-worker-controller.mjs';
import { availableSsrRuntimes } from '../../framework-comparison/src/ssr-run-environment.mjs';
const rows=[];
for(const runtimeId of ['node','bun'])for(const every of [1,8,32])for(const count of ['default','96']) {
 const mode='stream';
 let service,worker;
 try {
  service=await startSsrLoadProcess('service');
  worker=await startSsrWorker({runtime:availableSsrRuntimes(runtimeId)[0],participantId:'exact',transport:runtimeId==='bun'?'bun-fetch':'node-http',workerPath:resolve('.tmp/pressure-budget-latched-2026-09-22/diagnostic-worker.mjs'),workingDirectory:resolve('framework-comparison'),serviceUrl:service.url,environment:{NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:mode,EXPERIMENT_VARIANT:'budget',EXPERIMENT_ROWS:count,EXPERIMENT_CLOCK_EVERY:String(every),COMPARISON_EXACT_SERVER_ENTRY:resolve('.tmp/pressure-budget-latched-2026-09-22/'+runtimeId+'-entry.js')}});
  for(let i=0;i<50;i++) { const r=await fetch(worker.url+'?__benchmarkPreloaded=true');await r.arrayBuffer(); }
  const before=(await controlSsrWorker(worker,'telemetry')).budgetDiagnostic;
  for(let i=0;i<100;i++) { const r=await fetch(worker.url+'?__benchmarkPreloaded=true');await r.arrayBuffer(); }
  const after=(await controlSsrWorker(worker,'telemetry')).budgetDiagnostic;
  const response=await fetch(worker.url+'?__benchmarkPreloaded=true');const body=Buffer.from(await response.arrayBuffer());
  rows.push({runtimeId,mode,every,rows:count,requests:100,before,after,status:response.status,headers:Object.fromEntries(response.headers),bytes:body.length,sha256:createHash('sha256').update(body).digest('hex')});
  console.log(JSON.stringify(rows.at(-1)));
 } finally {if(worker)await stopSsrWorker(worker);if(service)await service.close();}
}
await writeFile('.tmp/pressure-budget-latched-2026-09-22/renderer-clock-diagnostic.json',JSON.stringify(rows,null,2)+'\n');
