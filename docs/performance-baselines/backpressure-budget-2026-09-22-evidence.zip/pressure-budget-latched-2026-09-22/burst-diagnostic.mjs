import { writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { startSsrLoadProcess } from '../../framework-comparison/src/ssr-load-process-owner.mjs';
import { startSsrWorker,stopSsrWorker,controlSsrWorker } from '../../framework-comparison/src/ssr-worker-controller.mjs';
import { availableSsrRuntimes } from '../../framework-comparison/src/ssr-run-environment.mjs';
const rows=[];
for(const runtimeId of ['bun','node'])for(const variant of ['control','budget'])for(const count of ['default','96']) {
 let service,worker;
 try {
  service=await startSsrLoadProcess('service');
  worker=await startSsrWorker({runtime:availableSsrRuntimes(runtimeId)[0],participantId:'exact',transport:runtimeId==='bun'?'bun-fetch':'node-http',workerPath:resolve('.tmp/pressure-budget-latched-2026-09-22/diagnostic-worker.mjs'),workingDirectory:resolve('framework-comparison'),serviceUrl:service.url,environment:{NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:'stream',EXPERIMENT_VARIANT:variant,EXPERIMENT_ROWS:count,EXPERIMENT_CLOCK_EVERY:'32',COMPARISON_EXACT_SERVER_ENTRY:resolve('.tmp/pressure-budget-latched-2026-09-22/'+runtimeId+'-entry.js')}});
  const url=worker.url+'?__benchmarkPreloaded=true';
  let identity;
  const framing={};
  const request=async(record)=>{
    const response=await fetch(url);assert.equal(response.status,200);
    const buffer=Buffer.from(await response.arrayBuffer());const hash=createHash('sha256').update(buffer).digest('hex');
    if(identity)assert.equal(hash,identity);else identity=hash;
    if(record){const key=response.headers.has('content-length')?'length:'+response.headers.get('content-length'):'transfer:'+response.headers.get('transfer-encoding');framing[key]=(framing[key]??0)+1;}
  };
  for(let i=0;i<50;i++)await request(false);
  const before=(await controlSsrWorker(worker,'telemetry')).budgetDiagnostic;
  for(let i=0;i<5;i++)await Promise.all(Array.from({length:32},()=>request(true)));
  const after=(await controlSsrWorker(worker,'telemetry')).budgetDiagnostic;
  rows.push({runtimeId,variant,clockEvery:32,rows:count,requests:160,framing,identity,before,after});console.log(JSON.stringify(rows.at(-1)));
 } finally {if(worker)await stopSsrWorker(worker);if(service)await service.close();}
}
await writeFile('.tmp/pressure-budget-latched-2026-09-22/burst-diagnostic.json',JSON.stringify(rows,null,2)+'\n');
