import { performance } from 'node:perf_hooks';
import { WorkBudget } from './work-budget.mjs';
import { BunRequestGate as ControlGate } from './adapters/bun-control/adaptive-gate.js';
const control={checkpoints:0,yieldDecisions:0};
const controlCheck=ControlGate.prototype.shouldSchedule;
ControlGate.prototype.shouldSchedule=function(){control.checkpoints++;const due=controlCheck.call(this);if(due)control.yieldDecisions++;return due;};
const counters={checkpoints:0,clockReads:0,newTurns:0,yieldDecisions:0,maxObservedOvershootMs:0};
const mark=WorkBudget.prototype.markTurn;
const check=WorkBudget.prototype.shouldYield;
WorkBudget.prototype.markTurn=function(){
 if(this.marker===undefined){counters.clockReads++;counters.newTurns++;}
 return mark.call(this);
};
WorkBudget.prototype.shouldYield=function(signal){
 counters.checkpoints++;
 if(this.marker!==undefined && !this.exhausted && this.remaining<=1)counters.clockReads++;
 const due=check.call(this,signal);
 if(due){counters.yieldDecisions++;counters.maxObservedOvershootMs=Math.max(counters.maxObservedOvershootMs,performance.now()-this.started-this.milliseconds);}
 return due;
};
globalThis.budgetDiagnostic=()=>({...counters,control:{...control}});
