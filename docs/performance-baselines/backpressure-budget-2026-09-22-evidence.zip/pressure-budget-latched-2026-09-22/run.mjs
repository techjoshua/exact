import { spawn } from 'node:child_process';
import { openSync,closeSync,readFileSync,writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';
const dir = '.tmp/pressure-budget-latched-2026-09-22';
const smoke = process.argv.includes('--smoke');
const workload = smoke ? 'smoke' : (process.argv[2] ?? 'screen');
const journal=[];
for(const runtime of ['bun','node']) {
  const captures=[];
  const variants=runtime==='bun'?[['control',1],['clock',8],['budget',8],['budget',1],['budget',32]]:[['budget',32],['budget',1],['budget',8],['control',1]];
  for(const [variant,every] of variants) {
    const name=`${workload}-${runtime}-${variant}-${every}`;
    const env={NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:'stream',EXPERIMENT_VARIANT:variant,EXPERIMENT_CLOCK_EVERY:String(every),EXPERIMENT_ROWS:workload==='large'?'96':'default',EXPERIMENT_ORDER:runtime==='bun'?'react-first':'exact-first'};
    const args=[`${dir}/capture.mjs`,`${dir}/${workload==='large'?'screen':workload}.json`,`${dir}/${name}.json`,runtime];
    const step={name,args,env,startedAt:new Date().toISOString()};journal.push(step);
    const save=()=>writeFileSync(`${dir}/${workload}-execution.json`,JSON.stringify(journal,null,2));save();console.log('START',name);
    const fd=openSync(`${dir}/${name}.log`,'w');
    try{await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{env:{...process.env,...env},stdio:['ignore',fd,fd]});step.pid=child.pid;save();child.once('error',fail);child.once('exit',code=>{step.code=code;code===0?done():fail(Error(`${name}: ${code}`));});});}
    finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}
    const c=JSON.parse(readFileSync(`${dir}/${name}.json`));assert.equal(c.complete,true);captures.push(c);
    console.log('DONE',name);
  }
  for(const c of captures.slice(1)) {
    assert.deepEqual(c.responseIdentities,captures[0].responseIdentities);
    assert.deepEqual(c.artifacts.exact,captures[0].artifacts.exact);
    assert.deepEqual(c.artifacts.react,captures[0].artifacts.react);
  }
}
console.log('PASS',workload);
