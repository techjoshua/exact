import { writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { startSsrLoadProcess } from '../../framework-comparison/src/ssr-load-process-owner.mjs';
import { startSsrWorker,stopSsrWorker } from '../../framework-comparison/src/ssr-worker-controller.mjs';
import { availableSsrRuntimes } from '../../framework-comparison/src/ssr-run-environment.mjs';
const rows=[];
for(const runtimeId of ['node','bun'])for(const mode of ['string','stream']) {
 let service,worker;
 try {
  service=await startSsrLoadProcess('service');
  worker=await startSsrWorker({runtime:availableSsrRuntimes(runtimeId)[0],participantId:'exact',transport:runtimeId==='bun'?'bun-fetch':'node-http',workerPath:resolve('.tmp/mode-paths-2026-09-21/worker.mjs'),workingDirectory:resolve('framework-comparison'),serviceUrl:service.url,environment:{NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:mode,EXPERIMENT_VARIANT:'control',EXPERIMENT_ROWS:'96',COMPARISON_EXACT_SERVER_ENTRY:resolve('.tmp/bun-stream-codec-2026-09-21/actual-host'+(runtimeId==='node'?'-node':'')+'-entry.js')}});
  const response=await fetch(worker.url+'?__benchmarkPreloaded=true');const body=Buffer.from(await response.arrayBuffer());
  rows.push({runtimeId,mode,rows:96,status:response.status,headers:Object.fromEntries(response.headers),bytes:body.length,sha256:createHash('sha256').update(body).digest('hex')});
  console.log(JSON.stringify(rows.at(-1)));
 } finally {if(worker)await stopSsrWorker(worker);if(service)await service.close();}
}
await writeFile('.tmp/pressure-budget-latched-2026-09-22/headers-large.json',JSON.stringify(rows,null,2)+'\n');
