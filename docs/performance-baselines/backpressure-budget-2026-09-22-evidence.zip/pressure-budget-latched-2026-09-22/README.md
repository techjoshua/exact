# Pressure-first CPU budget experiment

Private prototype, not a shipped API. Baseline: shipping Node policy and the Bun streaming half-millisecond work window from the coordinated mode experiment. Node string retention is rejected. Bun string short controls remain subject to their within-mode guards.

The same compiled component writers call sink.ready(). Streaming candidate sinks first honor destination readiness, then consult a host-owned work budget. String sinks are unchanged. Clock sampling variants consult performance.now() every 1, 8, or 32 CPU checkpoints; transport readiness and abort checks are never sampled away. An immediate marker ends an observed turn. A resolved promise alone does not reset the budget. Timing checks can overshoot by up to the work between samples; there is no hard real-time deadline.

The private renderer bundle contains both the original and budgeted sink and selects via a runtime scheduler capability. Every variant uses the same bundle. No component emission changes. Host callbacks retain the existing bounded and cancellable queue.

Planned checks: exact response identity, delayed destination ordering, cancellation during pressure and CPU waits, large pages, concurrency and scheduled demand, repeated paired comparisons with React. Diagnostic counters for clock calls and observed overshoot are separated from timed throughput runs.

Revision: once a clock read detects exhaustion, every subsequent checkpoint must yield until the immediate marker clears. Sampling only skips clock reads while the budget is not known to be exhausted. The earlier unlatched prototype and its interrupted screen remain in the prior directory, not merged with these results.

The Bun clock-only variant changes admission/resumption clock sampling without adding sink checkpoints. It separates clock-sampling effects from the cost of suspending inside component traversal.
