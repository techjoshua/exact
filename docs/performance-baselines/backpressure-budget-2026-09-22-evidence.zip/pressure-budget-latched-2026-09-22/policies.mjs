/** Keeps each runtime's preferred control and enables pressure-first budgets only in the candidate. */
export async function selectRequestAdapters(runtime, mode, variant) {
  if (!['node','bun'].includes(runtime) || !['stream','string'].includes(mode) || !['control','budget','clock'].includes(variant)) throw new TypeError('Invalid experimental path');
  const policyId = `${runtime}-${variant}`;
  const [node,bun] = await Promise.all([
    import(`./adapters/${runtime === 'node' ? policyId : 'node-control'}/index.js`),
    import(`./adapters/${runtime === 'bun' ? policyId : 'bun-control'}/index.js`)
  ]);
  return {policyId, createNodeHandler:node.createNodeHandler, createBunRequestHandler:bun.createBunRequestHandler};
}
