import { performance } from 'node:perf_hooks';
import { setImmediate as immediate } from 'node:timers/promises';
import { writeFile } from 'node:fs/promises';
import { WorkBudget } from './work-budget.mjs';
const original=performance.now;
const clock=original.bind(performance);
const rows=[];
// Diagnostic only: direct checkpoints with representative CPU work, not published HTTP throughput.
for(const every of [1,8,32]) {
 let reads=0,yields=0,maxOvershootMs=0;
 performance.now=()=>{reads++;return clock();};
 const budget=new WorkBudget(async()=>{yields++;maxOvershootMs=Math.max(maxOvershootMs,clock()-budget.started-.5);await immediate();},every,.5);
 const start=clock();
 for(let i=0;i<10000;i++) {
  const until=clock()+.005;while(clock()<until){}
  const pending=budget.checkpoint();if(pending)await pending;
 }
 rows.push({every,checkpoints:10000,clockReads:reads,yields,maxOvershootMs,elapsedMs:clock()-start});
 await immediate();
 performance.now=original;
}
await writeFile('.tmp/pressure-budget-2026-09-21/clock-diagnostic-'+('bun' in process.versions?'bun':'node')+'.json',JSON.stringify(rows,null,2)+'\n');
console.log(JSON.stringify(rows));
