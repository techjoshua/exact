import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { performance } from 'node:perf_hooks';
import { setImmediate as immediate } from 'node:timers/promises';
import { WorkBudget } from './work-budget.mjs';
const sinkSource=readFileSync(new URL('./scheduled-sink.txt',import.meta.url),'utf8');
class Destination {
  constructor(_bytes, destination) { this.destination=destination; }
  ready() { return this.destination.ready(); }
}
const Sink=new Function('HostDocumentStreamSink',sinkSource+'\nreturn BudgetDocumentStreamSink;')(Destination);

test('pressure settles before a CPU checkpoint and abort prevents resumption',async()=>{
  let release;const events=[];const owner=new AbortController();
  const pressure=new Promise(resolve=>release=resolve);
  const sink=new Sink(100,{ready:()=>{events.push('pressure');return pressure;}},8,(signal)=>{signal.throwIfAborted();events.push('cpu');},owner.signal);
  const pending=sink.ready();assert.deepEqual(events,['pressure']);
  owner.abort(new Error('disconnected'));release();
  await assert.rejects(pending,/disconnected/);assert.deepEqual(events,['pressure']);
});
test('pressure failure preserves its error and does not schedule CPU work',async()=>{
  const failure=new Error('transport');let called=false;
  const sink=new Sink(100,{ready:()=>Promise.reject(failure)},8,()=>{called=true;});
  await assert.rejects(sink.ready(),error=>error===failure);assert.equal(called,false);
});
test('available destinations check budget and await a required yield before continuing',async()=>{
  let release;const queue=new Promise(resolve=>release=resolve);let count=0;
  const sink=new Sink(100,{ready:()=>undefined},8,()=>{count++;return queue;});
  const pending=sink.ready();assert.equal(count,1);assert.equal(pending,queue);release();await pending;
});
test('clock sampling is shared across checkpoints, with bounded check counts',async(t)=>{
  const realNow=performance.now.bind(performance);let now=0,calls=0;
  t.mock.method(performance,'now',()=>{calls++;return now;});
  for(const every of [1,8,32]) {
    let yields=0;const budget=new WorkBudget(()=>{yields++;return Promise.resolve();},every,.5);
    budget.checkpoint();const startCalls=calls;now+=1;
    for(let i=1;i<every;i++){budget.checkpoint();assert.equal(yields,0);}
    budget.checkpoint();assert.equal(yields,1);assert.equal(calls-startCalls,1);
    // Microtasks alone cannot refresh the turn budget.
    await Promise.resolve();assert.notEqual(budget.marker,undefined);
    await immediate();assert.equal(budget.marker,undefined);
    budget.checkpoint();assert.equal(yields,1);
    await immediate();
  }
  assert.ok(Number.isFinite(realNow()));
});
test('abort is checked even between clock samples',()=>{
 const owner=new AbortController();const budget=new WorkBudget(()=>Promise.resolve(),32);
 budget.checkpoint(owner.signal);owner.abort(new Error('cancelled'));
 assert.throws(()=>budget.checkpoint(owner.signal),/cancelled/);
});
