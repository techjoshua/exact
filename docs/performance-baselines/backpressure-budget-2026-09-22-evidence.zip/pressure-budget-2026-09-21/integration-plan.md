# Production integration boundary to validate after screening

The coordinated mode experiment selects an adapter for a dedicated output-mode host. That proves candidates can coexist without changing component artifacts; it does not yet prove an automatic mixed-mode integration.

Preferred framework boundary: retain the signal-bound host scheduler and add an optional internal output-policy selection capability. The SSR string or progressive entry point selects the policy once, then descendants share it through options and the sink. Explicit scheduleRender overrides retain priority. Node remains on its shipping scheduling policy unless its own combined-budget experiment passes.

Bun must retain one host-wide observer for native pendingRequests accounting. Never combine subset arrival counts with the host-wide pending counter. A streaming CPU budget can be a separate host-owned policy without native-drain bookkeeping. Initial admission occurs before the renderer knows its API, so retaining existing initial admission plus selecting the streaming policy at the SSR entry point differs from the private whole-handler candidate. That integration needs its own focused capacity/latency and mixed-mode tests before acceptance. Do not silently equate their measurements.

String-probe changes cannot be accepted solely for latency if their own throughput ratio regresses. The current matrix shows a small-page capacity guard failure and awaits its larger-page completion.
