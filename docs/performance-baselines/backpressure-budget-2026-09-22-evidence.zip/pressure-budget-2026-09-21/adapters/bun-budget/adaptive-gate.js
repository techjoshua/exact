import { WorkBudget } from '../../work-budget.mjs';
export class BunRequestGate extends WorkBudget {
 constructor() { super(undefined, Number(process.env.EXPERIMENT_CLOCK_EVERY ?? 1)); }
 observeRequest() { this.markTurn(); }
 shouldSchedule() { return this.shouldYield(); }
}
