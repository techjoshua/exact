from pathlib import Path
from shutil import copytree
import json
p=Path('.tmp/pressure-budget-2026-09-21'); old=Path('.tmp/mode-paths-2026-09-21')
for runtime in ['node','bun']:
 control=old/'adapters'/('bun-stream' if runtime=='bun' else 'node-control')
 for variant in ['control','budget']:
  dest=p/'adapters'/f'{runtime}-{variant}'
  copytree(control,dest,dirs_exist_ok=True)
  if variant=='control':continue
  if runtime=='bun':
   (dest/'adaptive-gate.js').write_text("import { WorkBudget } from '../../work-budget.mjs';\nexport class BunRequestGate extends WorkBudget {\n constructor() { super(undefined, Number(process.env.EXPERIMENT_CLOCK_EVERY ?? 1)); }\n observeRequest() { this.markTurn(); }\n shouldSchedule() { return this.shouldYield(); }\n}\n")
   handler=dest/'request-handler.js';s=handler.read_text()
   before='                gates.set(server, entry);'
   assert before in s
   s=s.replace(before,'                entry.checkpoint.sinkCheckpoint = entry.checkpoint;\n'+before)
  else:
   handler=dest/'requests/admission.js';s=handler.read_text()
   s="import { WorkBudget } from '../../../work-budget.mjs';\n"+s
   before='    return (response, signal) => {'
   assert before in s
   s=s.replace(before,"    const budget = new WorkBudget(enqueue, Number(process.env.EXPERIMENT_CLOCK_EVERY ?? 1));\n    checkpoint.sinkCheckpoint = (signal) => budget.checkpoint(signal);\n"+before)
  handler.write_text(s)
# Shared renderer code: only sink implementation/selection changes. All emitted component code remains verbatim.
for runtime in ['node','bun']:
 source=Path('.tmp/bun-stream-codec-2026-09-21')/('actual-host-node-entry.js' if runtime=='node' else 'actual-host-entry.js')
 s=source.read_text()
 at=s.index('\n',s.index('var HostDocumentStreamSink ='))+1
 s=s[:at]+(p/'scheduled-sink.txt').read_text()+s[at:]
 before='const sink = destination ? new HostDocumentStreamSink(context.maxOutputBytes, destination, streamBufferSize) : new DocumentStringSink(context.maxOutputBytes);'
 assert s.count(before)==1
 after='const checkpoint = renderOptions.scheduleRender?.sinkCheckpoint;\n\tconst sink = destination ? (checkpoint ? new BudgetDocumentStreamSink(context.maxOutputBytes, destination, streamBufferSize, checkpoint, renderOptions.signal) : new HostDocumentStreamSink(context.maxOutputBytes, destination, streamBufferSize)) : new DocumentStringSink(context.maxOutputBytes);'
 s=s.replace(before,after)
 (p/f'{runtime}-entry.js').write_text(s)
s=(old/'worker.mjs').read_text();(p/'worker.mjs').write_text(s)
s=(old/'capture.mjs').read_text().replace(str(old),str(p))
s=s.replace("resolve('.tmp/bun-stream-codec-2026-09-21/actual-host'+(runtimeId==='node'?'-node':'')+'-entry.js')", "resolve('.tmp/pressure-budget-2026-09-21/'+runtimeId+'-entry.js')")
s=s.replace("rows:process.env.EXPERIMENT_ROWS??'default',order:", "rows:process.env.EXPERIMENT_ROWS??'default',clockEvery:Number(process.env.EXPERIMENT_CLOCK_EVERY??1),order:")
s=s.replace("EXPERIMENT_VARIANT:process.env.EXPERIMENT_VARIANT??'control',EXPERIMENT_ROWS:","EXPERIMENT_VARIANT:process.env.EXPERIMENT_VARIANT??'control',EXPERIMENT_CLOCK_EVERY:process.env.EXPERIMENT_CLOCK_EVERY??'1',EXPERIMENT_ROWS:")
s=s.replace("artifacts.experimentalAdapters =", "artifacts.workBudget={path:'.tmp/pressure-budget-2026-09-21/work-budget.mjs',sha256:createHash('sha256').update(await readFile('.tmp/pressure-budget-2026-09-21/work-budget.mjs')).digest('hex')};\nartifacts.experimentalAdapters =")
(p/'capture.mjs').write_text(s)
for name in ['concurrency','demand','smoke']:(p/f'{name}.json').write_text((old/f'{name}.json').read_text())
(p/'summarize.py').write_text((old/'summarize.py').read_text())
