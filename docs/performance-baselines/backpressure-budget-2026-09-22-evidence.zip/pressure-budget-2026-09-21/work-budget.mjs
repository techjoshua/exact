import { performance } from 'node:perf_hooks';
import { setImmediate } from 'node:timers';

/** Host-owned cooperative work window. Real immediate callbacks, not promise completion, end turns. */
export class WorkBudget {
  constructor(enqueue, every = 1, milliseconds = 0.5) {
    if (!Number.isSafeInteger(every) || every < 1) throw new RangeError('Invalid clock sampling interval');
    this.enqueue = enqueue;
    this.every = every;
    this.milliseconds = milliseconds;
    this.remaining = 0;
    this.marker = undefined;
    this.started = 0;
  }
  /** Starts measuring active work lazily; sparse traffic has no recurring timer. */
  markTurn() {
    if (this.marker !== undefined) return false;
    this.started = performance.now();
    this.remaining = this.every;
    this.marker = setImmediate(() => { this.marker = undefined; });
    this.marker.unref?.();
    return true;
  }
  /** Transport pressure is checked by the sink before calling this CPU-only checkpoint. */
  shouldYield(signal) {
    signal?.throwIfAborted();
    if (this.markTurn()) return false;
    if (--this.remaining > 0) return false;
    this.remaining = this.every;
    return performance.now() - this.started >= this.milliseconds;
  }
  checkpoint(signal) {
    if (this.shouldYield(signal)) return this.enqueue(signal);
  }
}
