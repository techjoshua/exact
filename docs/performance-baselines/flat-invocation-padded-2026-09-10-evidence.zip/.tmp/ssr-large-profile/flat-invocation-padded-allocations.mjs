import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';
const variants={
 previous:['current-target-integrated','6d92194f2ee395f4e4e5267b8719bc1160a96ce7bc16f1a6bbdc74f98aba4997'],
 integrated:['flat-invocation-control','bc0135fbb733559a1be1fdd7a45c2a9a6e27a34914b5512868ba1b8ff37436e0'],
 candidate:['flat-invocation-padded','3e772ace6ed815992242bc0bff5a120d57b9c6d17dd14c17255c3cdbed680be5']
};
const worker=root+'direct-execution-target-allocation-worker.mjs';
let source=fs.readFileSync(root+'direct-child-boundary-allocation-worker.mjs','utf8');
source="import os from 'node:os';\nos.setPriority(0,os.constants.priority.PRIORITY_BELOW_NORMAL);\n"+source;
source=source.replace('runtime:process.version','runtime:process.version,processPriority:os.getPriority()');
fs.writeFileSync(worker,source);
const rows=[];
for(const scenario of ['small','large'])for(let round=0;round<2;round++)for(const variant of round?['candidate','integrated']:['integrated','candidate']){
 const [folder,expectedHash]=variants[variant];
 const entry=root+folder+'/server-entry.js';
 assert.equal(createHash('sha256').update(fs.readFileSync(entry)).digest('hex'),expectedHash);
 const profile=root+`flat-invocation-padded-allocation-${variant}-${scenario}-${round}.heapprofile`;
 const run=spawnSync(process.execPath,[worker,entry,scenario,profile],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 assert.equal(run.status,0,run.stderr+run.stdout);
 const row={variant,round,...JSON.parse(run.stdout)};
 assert.ok(row.processPriority>0,'Worker priority was not reduced');
 const peer=rows.find(r=>r.scenario===scenario);if(peer)assert.equal(row.hash,peer.hash);
 let bytes=0;const sites=new Map();
 function visit(node){bytes+=node.selfSize;const key=node.callFrame.functionName;sites.set(key,(sites.get(key)??0)+node.selfSize);for(const child of node.children??[])visit(child);}
 visit(JSON.parse(fs.readFileSync(profile)).head);
 row.estimatedBytesPerRender=bytes/row.iterations;
 row.sites=[...sites.entries()].sort((a,b)=>b[1]-a[1]).map(([name,bytes])=>({name,bytesPerRender:bytes/row.iterations}));
 rows.push(row);fs.writeFileSync(root+'flat-invocation-padded-allocations.json',JSON.stringify(rows,null,2));
 console.log(variant,scenario,round,row.estimatedBytesPerRender.toFixed(1),'priority',row.processPriority);
}
assert.equal(rows.length,8);
