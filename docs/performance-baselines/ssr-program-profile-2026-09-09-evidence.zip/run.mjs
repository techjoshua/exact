﻿import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const dir='.tmp/ssr-program-profile', rows=[];
for (const runtime of ['node','bun']) for(const mode of ['string','stream']) for(const variant of ['exact','react']) {
 const name=`${runtime}-${variant}-${mode}`;
 const entry=`framework-comparison/participants/${variant}/dist-server/server-entry.js`;
 const r=spawnSync(runtime,[`--cpu-prof`,`--cpu-prof-dir=${dir}`,`--cpu-prof-name=${name}.cpuprofile`,`${dir}/worker.mjs`,entry,mode,'small','60000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 const row={name,artifactHash:createHash('sha256').update(readFileSync(entry)).digest('hex'),...JSON.parse(r.stdout)};rows.push(row);console.log(JSON.stringify(row));writeFileSync(`${dir}/runs.json`,JSON.stringify(rows,null,2));
}
