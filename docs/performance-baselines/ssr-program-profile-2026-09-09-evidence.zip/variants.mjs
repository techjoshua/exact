﻿import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-program-profile',base=readFileSync(`${dir}/exact-baseline.mjs`,'utf8');
const old=`const operation = Object.defineProperty({}, exactOpaqueOperationIdentity, { value: true });\n\tif (execute) Object.defineProperty(operation, exactOpaqueOperationExecution, { value: execute });`;
const next=`let descriptors = execute && operationDescriptors.get(execute);\n\tif (!descriptors) {\n\t\tdescriptors = { [exactOpaqueOperationIdentity]: {value:true} };\n\t\tif (execute) { descriptors[exactOpaqueOperationExecution] = {value:execute}; operationDescriptors.set(execute, descriptors); }\n\t}\n\tconst operation = Object.create(Object.prototype, descriptors);`;
if(!base.includes(old))throw Error('opaque pattern missing');
writeFileSync(`${dir}/exact-descriptors.mjs`,base.replace('function createOpaqueOperation(execute, metadata) {','const operationDescriptors = new WeakMap();\nfunction createOpaqueOperation(execute, metadata) {').replace(old,next));

const start=base.indexOf('\n\t\treturn {\n\t\t\tcontent: readDirectSsrContent(withServerComponentIssuer(',base.indexOf('function renderIssuedServerComponentChildren('));
const end=base.indexOf('\n\t} catch (error)',start);
if(start<0||end<0)throw Error('scheduling pattern missing');
const block=base.slice(start,end);
const expr=block.slice(block.indexOf('readDirectSsrContent('),block.indexOf('\n\t\t\t...prepared.length')).trim().replace(/,$/,'');
writeFileSync(`${dir}/exact-issued.mjs`,base.slice(0,start)+`\n\t\tconst content = ${expr};\n\t\tif (!prepared.length) return {content};\n\t\treturn {content, preparation: Object.freeze({[Symbol.asyncDispose]: () => disposePrepared(context, prepared)})};`+base.slice(end));
