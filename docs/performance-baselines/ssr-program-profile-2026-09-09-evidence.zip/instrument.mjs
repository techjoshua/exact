﻿import {readFileSync,writeFileSync} from 'node:fs';
const root='.tmp/ssr-program-profile';
let code=readFileSync('framework-comparison/participants/exact/dist-server/server-entry.js','utf8');
writeFileSync(`${root}/exact-baseline.mjs`,code);
const names=['createOpaqueOperation','createPreparedServerRenderProgram','createCompiledIntrinsicReceipt','createCompiledFragmentReceipt','createCompiledChildRangeReceipt','prepareComponentProps','prepareSsrAttribute','prepareSsrText','validatePositionalValue','serializeJson','createPreparedServerComponentReference'];
for(const name of names){const re=new RegExp(`(function ${name}\\([^]*?\\) \\{)`);if(!re.test(code))throw Error(name);code=code.replace(re,`$1\nglobalThis.__counts['${name}']=(globalThis.__counts['${name}']??0)+1;`);}
code=code.replace('globalThis.__counts[\'createCompiledIntrinsicReceipt\']=',`globalThis.__tags[tag]=(globalThis.__tags[tag]??0)+1;globalThis.__counts['createCompiledIntrinsicReceipt']=`);
writeFileSync(`${root}/exact-counted.mjs`,code);
