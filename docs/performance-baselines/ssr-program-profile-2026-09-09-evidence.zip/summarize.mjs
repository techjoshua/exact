﻿import {readFileSync,writeFileSync} from 'node:fs';
const rows=JSON.parse(readFileSync('.tmp/ssr-program-profile/runs.json','utf8'));
const result={};
for (const row of rows){const p=JSON.parse(readFileSync(`.tmp/ssr-program-profile/${row.name}.cpuprofile`,'utf8'));const nodes=new Map(p.nodes.map(n=>[n.id,n]));const totals=new Map();let sum=0;for(let i=0;i<p.samples.length;i++){const n=nodes.get(p.samples[i]);const t=p.timeDeltas?.[i]??1000;const key=`${n.callFrame.functionName||'(anonymous)'} @ ${n.callFrame.url}:${n.callFrame.lineNumber+1}`;totals.set(key,(totals.get(key)||0)+t);sum+=t;}const top=[...totals].sort((a,b)=>b[1]-a[1]).slice(0,30).map(([name,t])=>({name,percent:Math.round(t/sum*1000)/10,usPerIteration:t/62000}));result[row.name]={sum,top};console.log(row.name,JSON.stringify(top));}
writeFileSync('.tmp/ssr-program-profile/summary.json',JSON.stringify(result,null,2));
