﻿import {readFileSync,writeFileSync} from 'node:fs';
globalThis.__counts={};globalThis.__tags={};
const mod=await import('./exact-counted.mjs');const data=JSON.parse(readFileSync('.tmp/positional-leaves/data.json','utf8'));
const html=await mod.renderParticipant(data,'/incidents/inc-101',{clientTags:''});
const result={counts:globalThis.__counts,tags:globalThis.__tags,bytes:Buffer.byteLength(html)};console.log(JSON.stringify(result,null,2));writeFileSync('.tmp/ssr-program-profile/counts.json',JSON.stringify(result,null,2));
