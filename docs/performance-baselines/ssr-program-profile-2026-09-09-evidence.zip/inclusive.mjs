﻿import {readFileSync} from 'node:fs';
for(const name of ['node-exact-string','node-react-string','bun-exact-string','bun-react-string']){
 const p=JSON.parse(readFileSync(`.tmp/ssr-program-profile/${name}.cpuprofile`,'utf8'));const nodes=new Map(p.nodes.map(n=>[n.id,n]));const parents=new Map();for(const n of p.nodes)for(const c of n.children??[])parents.set(c,n.id);
 const sums={document:0,hydration:0};let total=0;for(let i=0;i<p.samples.length;i++){const dt=p.timeDeltas[i];total+=dt;let n=nodes.get(p.samples[i]);let document=false,hydration=false;while(n){document ||= n.callFrame.functionName==='Document';hydration ||= n.callFrame.functionName==='renderHydrationScriptValue';n=nodes.get(parents.get(n.id));}if(document)sums.document+=dt;if(hydration)sums.hydration+=dt;}console.log(name,total,sums,Object.fromEntries(Object.entries(sums).map(([k,v])=>[k,{percent:v/total*100,us:v/62000}])));
}
