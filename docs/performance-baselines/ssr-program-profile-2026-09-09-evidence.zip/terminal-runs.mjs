﻿import {spawnSync} from 'node:child_process';import {writeFileSync} from 'node:fs';
const dir='.tmp/ssr-program-profile',rows=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const scenario of ['small','large'])for(let round=0;round<3;round++)for(const variant of round%2?['terminal','baseline']:['baseline','terminal']){
 const r=spawnSync(runtime,[`${dir}/worker.mjs`,`${dir}/exact-${variant}.mjs`,mode,scenario,'10000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});if(r.status!==0)throw Error(r.stderr||r.stdout);const row={runtimeId:runtime,variant,round,...JSON.parse(r.stdout)};const peer=rows.find(p=>p.runtimeId===runtime&&p.mode===mode&&p.scenario===scenario&&p.round===round);if(peer?.hash&&peer.hash!==row.hash)throw Error('Changed document');rows.push(row);writeFileSync(`${dir}/terminal-results.json`,JSON.stringify(rows,null,2));console.log(runtime,mode,scenario,round,variant,row.usPerRender.toFixed(2));
}
