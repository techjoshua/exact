﻿import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const dir='.tmp/ssr-program-profile',rows=[];
for (const runtime of ['node','bun'])for(const mode of ['string','stream'])for(let round=0;round<3;round++){
 const variants=['baseline','descriptors','issued'];const order=[...variants.slice(round),...variants.slice(0,round)];
 for(const variant of order){const r=spawnSync(runtime,[`${dir}/worker.mjs`,`${dir}/exact-${variant}.mjs`,mode,'small','20000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});if(r.status!==0)throw Error(r.stderr||r.stdout);const row={runtimeId:runtime,variant,round,...JSON.parse(r.stdout)};const peer=rows.find(p=>p.runtimeId===runtime&&p.mode===mode&&p.round===round);if(peer?.hash&&peer.hash!==row.hash)throw Error('Output changed');rows.push(row);writeFileSync(`${dir}/experiments.json`,JSON.stringify(rows,null,2));console.log(runtime,mode,round,variant,row.usPerRender.toFixed(2));}
}
