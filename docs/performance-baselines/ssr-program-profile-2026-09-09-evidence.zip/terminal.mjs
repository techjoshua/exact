﻿import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-program-profile',base=readFileSync(`${dir}/exact-baseline.mjs`,'utf8');
const pattern='const planned = renderPreparedSsrProgram(this.context, program, this.parent);';
if(!base.includes(pattern))throw Error('missing');
writeFileSync(`${dir}/exact-terminal.mjs`,base.replace(pattern,pattern+`\n\t\tif (planned.segments.length === 1 && typeof planned.segments[0] === 'string') return renderProgramOutput(this.context, planned.segments, (segment) => this.renderProgramSegment(segment));`));
