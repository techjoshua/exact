import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
const root = '.tmp/full-refresh-performance';
const snapshot = JSON.parse(await readFile(`${root}/current-build-verification.json`, 'utf8'));
const hash = async path => createHash('sha256').update(await readFile(path)).digest('hex');
for (const runtime of ['node', 'bun']) {
  const expected = snapshot.checks[runtime];
  assert.equal(await hash(expected.path), expected.sha256, `${runtime} production artifact changed during measurements`);
  for (const lane of ['multi', 'normal', 'arrivals']) {
    const capture = JSON.parse(await readFile(`${root}/${runtime}-${lane}.json`, 'utf8'));
    assert.equal(capture.complete, true);
    assert.equal(capture.artifacts.exact.sha256, expected.sha256);
  }
}
for (const [path, expected] of Object.entries(snapshot.externalReactRuntime)) assert.equal(await hash(path), expected, `React runtime changed: ${path}`);
const execution = JSON.parse(await readFile(`${root}/execution.json`, 'utf8'));
assert.ok(execution.every(step => step.code === 0));
assert.ok(Date.parse(snapshot.createdAt) < Date.parse(execution.find(step => step.name === 'browser').startedAt));
await writeFile(`${root}/final-artifact-verification.json`, JSON.stringify({ verifiedAt: new Date().toISOString(), exactBuilds: 2, capacityCaptures: 6, externalReactFiles: Object.keys(snapshot.externalReactRuntime).length, completedStages: execution.length }, null, 2) + '\n');
console.log('Verified current eXact build identity across all six capacity captures and unchanged external React runtime files.');
