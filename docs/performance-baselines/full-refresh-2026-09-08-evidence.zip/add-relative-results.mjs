import {readFile,writeFile} from 'node:fs/promises';
const prefix='docs/performance-baselines/full-refresh-2026-09-08';
const archive=JSON.parse(await readFile(`${prefix}.json`,'utf8'));
const rows=[];
for(const runtime of ['node','bun'])for(const concurrency of [16,32,64,128]){
  const pick=(capacity,name)=>capacity.preloaded.find(r=>r.name===name&&r.concurrency===concurrency).rps;
  const current=archive.capacities[runtime],previous=archive.previousCapacity[runtime];
  const ratio=pick(current,'eXact')/pick(current,'React');
  const previousRatio=pick(previous,'eXact')/pick(previous,'React');
  rows.push({runtime,concurrency,ratio,previousRatio,relativeChangePercent:(ratio/previousRatio-1)*100});
}
const browser=archive.report.browserCharts.map(chart=>{
  const previous=archive.previousReport.browserCharts.find(c=>c.title===chart.title);
  const pick=(c,name)=>c.series.find(s=>s.name===name).stats.mean;
  return{metric:chart.title,ratio:pick(chart,'Exact')/pick(chart,'React'),previousRatio:pick(previous,'Exact')/pick(previous,'React')};
});
archive.relativeComparison={throughput:rows,browser};
const populations=[];
for(const runtime of ['node','bun']){
  const capture=JSON.parse(await readFile(archive.sources[`${runtime}-multi`].path,'utf8'));
  for(const population of [0,1])for(const concurrency of [16,32,64,128]){
    const rate=id=>{
      const block=capture.blocks.find(b=>b.population===population&&b.id===id);
      const stages=block.results.map(r=>r.stages.find(s=>!s.discard&&s.concurrency*2===concurrency));
      const start=Math.min(...stages.map(s=>Date.parse(s.startedAt)));
      const end=Math.max(...stages.map(s=>Date.parse(s.startedAt)+s.elapsedMs));
      return stages.reduce((n,s)=>n+s.valid,0)/(end-start)*1000;
    };
    populations.push({runtime,population,concurrency,ratio:rate('exact')/rate('react')});
  }
}
archive.relativeComparison.populations=populations;
archive.execution=JSON.parse(await readFile('.tmp/full-refresh-performance/execution.json','utf8'));
await writeFile(`${prefix}.json`,JSON.stringify(archive,null,2)+'\n');
const lines=['## Relative performance against React','','Throughput ratios divide eXact valid RPS by React valid RPS from the same capture. Above 1 means higher eXact throughput. These controls reduce historical host variation but do not eliminate differences between sequential blocks or establish causation from the optimization patch.','','| Runtime | Concurrency | Previous eXact/React | Current eXact/React | Ratio change |','| --- | ---: | ---: | ---: | ---: |',...rows.map(r=>`| ${r.runtime} | ${r.concurrency} | ${r.previousRatio.toFixed(3)} | ${r.ratio.toFixed(3)} | ${r.relativeChangePercent.toFixed(2)}% |`),'','Browser ratios below divide eXact means by React means. Lower than 1 means lower eXact time or heap for that metric.','','| Browser metric | Previous eXact/React | Current eXact/React |','| --- | ---: | ---: |',...browser.map(r=>`| ${r.metric} | ${r.previousRatio.toFixed(3)} | ${r.ratio.toFixed(3)} |`),''];
const markdown=await readFile(`${prefix}.md`,'utf8');
lines.push('Population ratios expose variation between the two sequential framework orders:','','| Runtime | Concurrency | eXact-first population | React-first population |','| --- | ---: | ---: | ---: |');
for(const runtime of ['node','bun'])for(const concurrency of [16,32,64,128]){
  lines.push(`| ${runtime} | ${concurrency} | ${[0,1].map(p=>populations.find(r=>r.runtime===runtime&&r.concurrency===concurrency&&r.population===p).ratio.toFixed(3)).join(' | ')} |`);
}
lines.push('');
await writeFile(`${prefix}.md`,markdown.replace('## Browser results',lines.join('\n')+'\n## Browser results'));
console.log(JSON.stringify({rows,browser},null,2));
