import pathlib,json,hashlib,zipfile
d=pathlib.Path('.tmp/ssr-large-profile')
rows=json.loads((d/'publication-string-results.json').read_text());assert len(rows)==16
lines=[]
for runtime in ['node','bun']:
 for size in ['small','large']:
  cell=[r for r in rows if r['runtimeName']==runtime and r['size']==size]
  assert len({r['hash'] for r in cell})==1
  pairs=[]
  for pair in [0,1]:
   a=next(r['us'] for r in cell if r['pair']==pair and r['variant']=='control')
   b=next(r['us'] for r in cell if r['pair']==pair and r['variant']=='candidate')
   pairs.append(f'{a:.2f} / {b:.2f} ({(b/a-1)*100:+.2f}%)')
  lines.append(f'| {runtime} | {size} | '+ ' | '.join(pairs)+' |')
before=json.loads((d/'publication-string-lifecycle-results.json').read_text())
after=json.loads((d/'publication-abort-results.json').read_text())
assert all(r['status']==1 for r in before) and all(r['status']==0 for r in after)
report=pathlib.Path('docs/performance-baselines/publication-string-2026-09-09.md')
report.write_text('''# Native string collection for the shared staged renderer

Date: 2026-09-09. String sink remains experimental; interruption ownership fix applied to framework source.

The previous collection experiment encoded all text into byte chunks and decoded it at completion.
The hypothesis is that a string sink should avoid this round trip while retaining the same traversal,
task settlement, hydration serializer, and UTF-8 output budget. The candidate accumulates native
strings, charges incoming text once through the existing ledger, and treats head/await flush requests
as no-ops. The byte sink remains responsible for progressive byte publication. No second renderer
is introduced.

Two reversed-order pairs on Node 26.8.1 and Bun 1.4.2 compare the optimized byte sink at 8 KB with
the native string sink. Small: two scheduled children, 2,000 warmups, 6,000 measured renders.
Large: 96 scheduled children, 1,000 warmups, 2,000 measured renders. All processes use production
mode, and no completed samples were discarded. The complete documents match exactly across
variants, including hydration; all children dispose once. These are controlled compiled-tree
fixtures, not the framework-comparison application, and markers remain disabled.

Times are microseconds per render: byte collection / native string (time change).

| Runtime | Fixture | Pair 1 | Pair 2 |
| --- | --- | --- | --- |
'''+ '\n'.join(lines)+'''

The string candidate improves every pair, most clearly on Node. This validates sink specialization
within one traversal, not a speedup against React or the current production string renderer.
The sink remains an integration candidate pending native compiler staging and browser hydration
coverage. 1,380 Unicode/split/budget cases per runtime compare exact encoded bytes, failures,
final byte counts, and destruction with the byte sink. Native strings retain original UTF-16
code units; byte equivalence is checked after encoding, including unpaired surrogates.

## Cancellation ownership defect exposed by integration

The additional closed-task cancellation check printed passing assertions but then exited with
an unhandled TaskCancellation. Both the string candidate and byte control failed on Node and Bun.
The existing awaitWithAbort helper rejected immediately for an already-aborted request without
observing its supplied, already-started promise. Later task disposal could reject that promise.
An already-expired deadline had the same ownership gap.

The framework fix attaches a rejection observer only on those two immediate-interruption branches,
then preserves the original interruption error. Normal waits still use the existing Promise.race
path. Two framework regression tests cover later work rejection after abort/deadline; the four
isolated Node/Bun sink lifecycle processes pass after the patch. The lifecycle checks also cover
invalid hydration and release of collected strings. Raw failure and success output is archived.

Source validation: the SSR package was rebuilt and its compiled fixtures regenerated. All 291
SSR tests passed, including the two new regression cases. Test type checking, changed-source
lint, source architecture, platform boundaries, compiled/released ABI checks, and published
package-content checks passed. Engineering and public SSR documentation describe interruption
ownership. The normal rendering contract and initial ABI epoch are unchanged.

Performance samples predate this exceptional-path fix. It adds no normal-path observer or new
serialization. This report makes no measured performance claim about that fix. The public staged
renderer remains unfinished, and the overall React performance objective remains incomplete.
''',encoding='utf8')
files=list(d.glob('publication-string-*'))+list(d.glob('publication-abort-*'))
files += [d/n for n in ['publication-tree-worker.mjs','publication-large-tree-worker.mjs','hydration-tail-entry.mjs','hydration-tail-fixture.mjs','publication-large-tail-entry.mjs','publication-large-tail-fixture.mjs','hydration-tail-sink.mjs','incremental-publication-pressure.mjs','incremental-publication-state-sink.mjs','publication-stages-sink.mjs','publication-byte-sink.mjs']]
files += [report,pathlib.Path('packages/ssr/src/render/context.ts'),pathlib.Path('packages/ssr/src/render/context.test.ts')]
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
archive=report.with_name(report.stem+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name in manifest:z.write(name,name)
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('\n'.join(lines));print('Verified archive',len(manifest))
