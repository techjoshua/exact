import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
const d='.tmp/ssr-large-profile/',rows=[];
for(const runtime of ['node','bun']) {
 const audit=spawnSync(runtime,[d+'publication-string-audit.mjs'],{encoding:'utf8',env:{...process.env,NODE_ENV:'production'},windowsHide:true});
 if(audit.status!==0)throw Error(audit.stderr||audit.stdout);
 fs.writeFileSync(d+`publication-string-audit-${runtime}.json`,audit.stdout);
 for(const size of ['small','large'])for(let pair=0;pair<2;pair++)for(const variant of pair?['candidate','control']:['control','candidate']) {
  const r=spawnSync(runtime,[d+`publication-string-${size}-worker.mjs`,variant,'string','8192'],{encoding:'utf8',env:{...process.env,NODE_ENV:'production'},windowsHide:true});
  if(r.status!==0)throw Error(r.stderr||r.stdout);
  const row={runtimeName:runtime,size,pair,...JSON.parse(r.stdout)};
  const peer=rows.find(x=>x.size===size);if(peer&&peer.hash!==row.hash)throw Error('Document changed');
  rows.push(row);fs.writeFileSync(d+'publication-string-results.json',JSON.stringify(rows,null,2));
  console.log(runtime,size,pair,variant,row.us.toFixed(2));
 }
}
