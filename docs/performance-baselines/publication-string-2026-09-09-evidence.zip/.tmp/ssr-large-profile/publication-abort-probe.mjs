import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
const d='.tmp/ssr-large-profile/';
const source=fs.readFileSync(d+'hydration-tail-entry.mjs','utf8');
const start=source.indexOf('async function awaitWithAbort('),end=source.indexOf('\n}',start);
if(start<0||end<0)throw Error('Missing wait');
const body=source.slice(start,end);
const fixed=body.replace('if (signal?.aborted) throw signal.reason ?? new DOMException("SSR render aborted", "AbortError");','if (signal?.aborted) {void promise.catch(()=>{});throw signal.reason ?? new DOMException("SSR render aborted", "AbortError");}').replace('if (remaining !== void 0 && remaining <= 0) throw new SsrTaskDeadlineError();','if (remaining !== void 0 && remaining <= 0) {void promise.catch(()=>{});throw new SsrTaskDeadlineError();}');
if(fixed===body)throw Error('No changes');
fs.writeFileSync(d+'publication-abort-entry.mjs',source.slice(0,start)+fixed+source.slice(end));
fs.writeFileSync(d+'publication-abort-fixture.mjs',fs.readFileSync(d+'hydration-tail-fixture.mjs','utf8').replace('./hydration-tail-entry.mjs','./publication-abort-entry.mjs'));
const rows=[];
for(const variant of ['candidate','control']) {
 const input=variant==='candidate'?'publication-string-lifecycle.mjs':'publication-string-lifecycle-control.mjs';
 const worker=fs.readFileSync(d+input,'utf8').replace('./hydration-tail-entry.mjs','./publication-abort-entry.mjs').replace('./hydration-tail-fixture.mjs','./publication-abort-fixture.mjs');
 const path=d+`publication-abort-${variant}.mjs`;fs.writeFileSync(path,worker);
 for(const runtime of ['node','bun']) {
  const run=spawnSync(runtime,[path],{encoding:'utf8',windowsHide:true});
  rows.push({runtime,variant,status:run.status,stdout:run.stdout,stderr:run.stderr});console.log(runtime,variant,run.status);
 }
}
fs.writeFileSync(d+'publication-abort-results.json',JSON.stringify(rows,null,2));
