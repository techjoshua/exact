import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
for(const size of ['small','large']) {
 let worker=fs.readFileSync(d+(size==='small'?'publication-tree-worker.mjs':'publication-large-tree-worker.mjs'),'utf8');
 worker="import {PublicationStringSink} from './publication-string-sink.mjs';\n"+worker;
 worker=worker.replace("const Sink=variant==='control'?Original:Optimized;",'const Sink=Optimized;');
 worker=worker.replace('const sink=new HydrationTailSink(new Sink(bytes=>{','const stringSink=variant===\'candidate\'?new PublicationStringSink():undefined;\n const sink=new HydrationTailSink(stringSink??new Sink(bytes=>{');
 worker=worker.replace('const html=consumed?await consumed:Buffer.concat(chunks).toString(\'utf8\');',"const html=stringSink?stringSink.value:consumed?await consumed:Buffer.concat(chunks).toString('utf8');");
 fs.writeFileSync(d+`publication-string-${size}-worker.mjs`,worker);
}
