import {PublicationStringSink} from './publication-string-sink.mjs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {HydrationTailSink} from './hydration-tail-sink.mjs';
import {PublicationPressureSink as Original} from './publication-stages-sink.mjs';
import {PublicationPressureSink as Optimized} from './incremental-publication-pressure.mjs';
import * as runtime from './publication-large-tail-entry.mjs';
import * as fixture from './publication-large-tail-fixture.mjs';
const [variant, mode, thresholdText, countText='2000']=process.argv.slice(2);
const Sink=Optimized;
const threshold=Number(thresholdText), count=Number(countText);
async function render() {
 fixture.reset();fixture.settle();
 const capture=runtime.createSsrResumptionCapture({markers:false});
 const context=runtime.createSsrContext(capture.options);
 let controller;
 const chunks=[];
 const stream=mode==='stream'?new ReadableStream({start(value){controller=value;}}):undefined;
 const consumed=stream?new Response(stream).text():undefined;
 const stringSink=variant==='candidate'?new PublicationStringSink():undefined;
 const sink=new HydrationTailSink(stringSink??new Sink(bytes=>{
  if(controller)controller.enqueue(bytes);else chunks.push(bytes);
 },{threshold}));
 context.experimentalSink=sink;
 try {
  const target=new runtime.SsrOperationTarget(context,undefined,capture.options,false,runtime.renderChildren);
  const root=runtime.createPreparedServerComponentReference(fixture.StagedDocument,{});
  await target.renderCompilerClosedRootComponent(root);
  const bytes=await sink.finishHydration(()=>runtime.renderHydrationScript({state:{note:'</script><script>bad()</script>\u2028'}},undefined,capture.serializedRecords()));
  controller?.close();
  const html=stringSink?stringSink.value:consumed?await consumed:Buffer.concat(chunks).toString('utf8');
  return {html,bytes};
 } catch(error) {
  controller?.error(error);
  if(consumed)await consumed.catch(()=>{});
  throw error;
 } finally {sink.destroy();}
}
for(let i=0;i<1000;i++)await render();
const start=performance.now();let output;
for(let i=0;i<count;i++)output=await render();
const us=(performance.now()-start)*1000/count;
assert.equal(output.bytes,Buffer.byteLength(output.html));
assert.match(output.html,/^<!doctype html><html(?:\s[^>]*)?>/);
assert.match(output.html,/<strong[^>]*>Ready 1<\/strong><strong[^>]*>Ready 2<\/strong>/);
assert.match(output.html,/<!--exact:framework-body:end--><\/body><\/html>$/);
assert.deepEqual([...fixture.disposedIndices].sort((a,b)=>a-b),Array.from({length:96},(_,i)=>i+1));
console.log(JSON.stringify({variant,mode,threshold,count,us,bytes:output.bytes,hash:createHash('sha256').update(output.html).digest('hex'),runtime:process.versions}));
