import assert from 'node:assert/strict';
import {PublicationStringSink} from './publication-string-sink.mjs';
import {HydrationTailSink} from './hydration-tail-sink.mjs';
import * as runtime from './publication-abort-entry.mjs';
import * as fixture from './publication-abort-fixture.mjs';
const results=[];
for(const mode of ['abort-task','invalid-hydration']) {
 fixture.reset();
 const controller=new AbortController();
 const capture=runtime.createSsrResumptionCapture({markers:false,signal:controller.signal});
 const context=runtime.createSsrContext(capture.options);
 const strings=new PublicationStringSink();
 const sink=new HydrationTailSink(strings);
 context.experimentalSink=sink;
 const target=new runtime.SsrOperationTarget(context,undefined,capture.options,false,runtime.renderChildren);
 const root=runtime.createPreparedServerComponentReference(fixture.StagedDocument,{});
 if(mode==='invalid-hydration')fixture.settle();
 let error;
 const rendering=Promise.resolve(target.renderCompilerClosedRootComponent(root)).then(()=>sink.finishHydration(()=>runtime.renderHydrationScript({state:{bad:NaN}}))).catch(reason=>{error=reason;}).finally(()=>sink.destroy());
 try {
  if(mode==='abort-task') {
   for(let turn=0;turn<500&&fixture.starts!==2;turn++)await Promise.resolve();
   assert.equal(fixture.starts,2);controller.abort();
  }
  let timer;
  try {await Promise.race([rendering,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Render did not settle')),2000);})]);}
  finally {clearTimeout(timer);}
  assert.ok(error);
  if(mode==='abort-task')assert.equal(error.name,'AbortError');
  else assert.match(error.message,/JSON-serializable/);
  assert.equal(strings.value,'');assert.throws(()=>strings.write('late'),/closed/);
  assert.deepEqual([...fixture.disposedIndices].sort(),[1,2]);
  results.push({mode,passed:true});
 } finally {controller.abort();fixture.settle();sink.destroy();await rendering;}
}
console.log(JSON.stringify({runtime:process.versions,results}));
