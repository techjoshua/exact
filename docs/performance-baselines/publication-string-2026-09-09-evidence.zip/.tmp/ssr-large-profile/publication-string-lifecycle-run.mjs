import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
const d='.tmp/ssr-large-profile/';
const candidate=fs.readFileSync(d+'publication-string-lifecycle.mjs','utf8');
const control=candidate.replace("import {PublicationStringSink} from './publication-string-sink.mjs';","import {PublicationPressureSink} from './incremental-publication-pressure.mjs';").replace('new PublicationStringSink()','new PublicationPressureSink(()=>{})').replace("assert.equal(strings.value,'');",'');
fs.writeFileSync(d+'publication-string-lifecycle-control.mjs',control);
const rows=[];
for(const runtime of ['node','bun'])for(const variant of ['candidate','control']) {
 const run=spawnSync(runtime,[d+(variant==='candidate'?'publication-string-lifecycle.mjs':'publication-string-lifecycle-control.mjs')],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 rows.push({runtime,variant,status:run.status,stdout:run.stdout,stderr:run.stderr});
 console.log(runtime,variant,run.status);
}
fs.writeFileSync(d+'publication-string-lifecycle-results.json',JSON.stringify(rows,null,2));
