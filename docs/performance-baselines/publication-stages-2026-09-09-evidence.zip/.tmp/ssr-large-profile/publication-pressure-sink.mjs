import {PublicationByteSink} from './publication-byte-sink.mjs';

/** Prototype enforcing at most one outstanding asynchronous byte publication. */
export class PublicationPressureSink {
 #sink;#pending;#reject;#closed=false;#signal;#abort;
 constructor(publish,options={}){
  this.#sink=new PublicationByteSink((bytes,reason)=>{
   const value=publish(bytes,reason);
   if(value&&typeof value.then==='function'){
    const cancelled=new Promise((_,reject)=>{this.#reject=reject;});
    const pending=Promise.race([value,cancelled]).then(()=>{
     if(this.#pending===pending){this.#pending=undefined;this.#reject=undefined;}
    },error=>{this.destroy(error);throw error;});
    this.#pending=pending;void pending.catch(()=>{});
   }
  },options);
  this.#signal=options.signal;
  this.#abort=()=>this.destroy(this.#signal.reason??new DOMException('Aborted','AbortError'));
  if(this.#signal?.aborted)this.#abort();else this.#signal?.addEventListener('abort',this.#abort,{once:true});
 }
 write(text){
  if(this.#closed)throw Error('Sink is closed');
  if(this.#pending)throw Error('Writer continued through backpressure');
  try{this.#sink.write(text);return this.#pending;}catch(error){this.destroy(error);throw error;}
 }
 flush(reason){
  if(this.#closed)throw Error('Sink is closed');
  if(this.#pending)return this.#pending;
  try{this.#sink.flush(reason);return this.#pending;}catch(error){this.destroy(error);throw error;}
 }
 finish(){
  if(this.#closed)throw Error('Sink is closed');
  if(this.#pending)return this.#pending.then(()=>this.finish());
  try{
   const bytes=this.#sink.finish();
   const complete=()=>{this.destroy();return bytes;};
   return this.#pending?this.#pending.then(complete):complete();
  }catch(error){this.destroy(error);throw error;}
 }
 destroy(error=new DOMException('Sink destroyed','AbortError')){
  if(this.#closed)return;
  this.#closed=true;this.#sink.destroy();this.#signal?.removeEventListener('abort',this.#abort);
  this.#reject?.(error);this.#reject=undefined;this.#pending=undefined;
 }
 get blocked(){return this.#pending!==undefined;}
 get pendingCharacters(){return this.#sink.pendingCharacters;}
}
