import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
let sink=readFileSync(dir+'publication-pressure-sink.mjs','utf8');
sink=sink.replace(' get blocked(){',' ready(){return this.#pending;}\n get blocked(){');
writeFileSync(dir+'publication-stages-sink.mjs',sink);
let entry=readFileSync(dir+'publication-pressure-entry.mjs','utf8');
const before='return withRenderCleanup(()=>mapRenderValue(executeDirectWriter(invocation,output),value=>{';
if(entry.split(before).length!==2)throw Error('Missing document entry');
entry=entry.replace(before,'return withRenderCleanup(()=>mapRenderValue(mapRenderValue(output.sink.ready?.(),()=>executeDirectWriter(invocation,output)),value=>{');
writeFileSync(dir+'publication-stages-entry.mjs',entry);
let fixture=readFileSync(dir+'direct-publication/fixture.mjs','utf8');
const start=fixture.indexOf('  __exactCharacters = __exactSsr.rootOpening(');
const end=fixture.indexOf('  return __exactOutput;',start)+'  return __exactOutput;'.length;
if(start<0||end<20)throw Error('Missing leaf output');
let stages=0;
function lower(body){
 const match=/  (__exactCharacters = )(__exactSsr\.(?:rootOpening|text)\([^\n]+\));/.exec(body);
 if(!match)return body;
 const id=stages++,name='__exactResumeWrite_'+id;
 return body.slice(0,match.index)+`  const __exactResult_${id}=${match[2]};
  const __exactDrain_${id}=__exactOutput.sink.ready?.();
  if(__exactDrain_${id})return __exactDrain_${id}.then(${name});
  return ${name}();
  function ${name}(){
   __exactCharacters=__exactResult_${id};
${lower(body.slice(match.index+match[0].length))}
  }`;
}
fixture=fixture.slice(0,start)+lower(fixture.slice(start,end))+fixture.slice(end);
if(stages!==2)throw Error('Expected root and text stages');
writeFileSync(dir+'publication-stages-fixture.mjs',fixture);
console.log('Lowered '+stages+' compiler-emitted output operations to conditional continuations.');
