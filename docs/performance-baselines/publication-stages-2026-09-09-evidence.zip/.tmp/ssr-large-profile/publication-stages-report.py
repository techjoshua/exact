import pathlib,json,hashlib,zipfile
d=pathlib.Path('.tmp/ssr-large-profile')
for runtime in ['node','bun']:
 rows=json.loads((d/f'publication-stages-{runtime}.json').read_text(encoding='utf-8'))
 assert len(rows)==6 and all(sorted(r['disposedIndices'])==[1,2] for r in rows)
files=[d/n for n in ['publication-stages-build.mjs','publication-stages-sink.mjs','publication-stages-entry.mjs','publication-stages-fixture.mjs','publication-stages-audit.mjs','publication-stages-report.py','publication-stages-node.json','publication-stages-bun.json','publication-byte-sink.mjs','publication-pressure-sink.mjs','publication-pressure-entry.mjs','direct-publication/fixture.mjs']]
files += [pathlib.Path('docs/performance-baselines/publication-stages-2026-09-09.md')]
manifest={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=pathlib.Path('docs/performance-baselines/publication-stages-2026-09-09-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p).replace('\\','/'))
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified twelve capacity/lifecycle cases and archive hashes.')
