import {readFileSync,writeFileSync,readdirSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
import {gzipSync} from 'node:zlib';
const base=import.meta.dirname;
const out={};
for(const side of ['before','after']){
 const bytes=readFileSync(resolve(base,`v8-${side}.log`));
 const lines=bytes.toString(bytes[0]===255?'utf16le':'utf8').split(/\r?\n/);
 const own=lines.filter(x=>x.includes(`enhancement-capability-optimization/${side}/client.mjs`));
 const deopts=own.filter(x=>x.includes('deoptimizing'));
 const reasons={},functions={};
 for(const x of deopts){const r=x.match(/reason: ([^)]+)/)?.[1];reasons[r]=(reasons[r]??0)+1;const f=x.match(/<JSFunction ([^<]+)/)?.[1].trim();functions[f]=(functions[f]??0)+1;}
 out[side]={deopts:deopts.length,reasons,functions,optimized:[...new Set(own.filter(x=>x.includes('completed optimizing')).map(x=>x.match(/<JSFunction ([^<]+)/)?.[1].trim()))]};
}
writeFileSync(resolve(base,'v8-summary.json'),JSON.stringify(out,null,2));
const sizes={};
for(const [id,dir]of [['before',resolve(base,'browser-before/assets')],['after',resolve('framework-comparison/participants/exact/dist/assets')]]){
 sizes[id]={raw:0,gzip:0,files:[]};
 for(const file of readdirSync(dir).filter(x=>x.endsWith('.js'))){const bytes=readFileSync(resolve(dir,file));const size={file,raw:bytes.length,gzip:gzipSync(bytes).length};sizes[id].files.push(size);sizes[id].raw+=size.raw;sizes[id].gzip+=size.gzip;}
}
const median=v=>{const a=[...v].sort((a,b)=>a-b),i=Math.floor(a.length/2);return a.length%2?a[i]:(a[i-1]+a[i])/2;};
const mean=v=>v.reduce((a,b)=>a+b,0)/v.length;
const summary={sizes,v8:out};
if(existsSync(resolve(base,'browser-pair.json'))){
 const data=JSON.parse(readFileSync(resolve(base,'browser-pair.json'),'utf8'));
 summary.browser={};
 for(const id of ['before','after','react-control']){
  const timing=data.samples.filter(x=>x.id===id&&x.lane==='timing'),heap=data.samples.filter(x=>x.id===id&&x.lane==='heap');
  summary.browser[id]={readyMedian:median(timing.map(x=>x.ready)),timing:timing.map(x=>x.ready),heapSample:heap[0],memoryMeans:Object.fromEntries(Object.keys(heap[0].memory).filter(k=>typeof heap[0].memory[k]==='number').map(k=>[k,mean(heap.map(x=>x.memory[k]))]))};
 }
}
if(existsSync(resolve(base,'paired-rounds.json'))){
 const rounds=JSON.parse(readFileSync(resolve(base,'paired-rounds.json'),'utf8'));
 summary.paired={};
 for(const kind of ['plain','intrinsic','component','explicit','intl']){
  if(rounds.some(r=>r.before[kind].error||r.after[kind].error)){summary.paired[kind]={unavailable:true};continue;}
  summary.paired[kind]={};
  for(const metric of Object.keys(rounds[0].before[kind].median)){
   const b=rounds.map(r=>r.before[kind].median[metric]),a=rounds.map(r=>r.after[kind].median[metric]);
   summary.paired[kind][metric]={before:median(b),after:median(a),change:100*(median(a)/median(b)-1),rounds:b.map((v,i)=>100*(a[i]/v-1))};
  }
 }
}
writeFileSync(resolve(base,'summary.json'),JSON.stringify(summary,null,2));
console.log(JSON.stringify({sizes,v8:Object.fromEntries(Object.entries(out).map(([id,d])=>[id,{deopts:d.deopts,reasons:d.reasons,functions:d.functions}])),browser:summary.browser,paired:summary.paired},null,2));
