import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import {installPerformanceDom} from '../../scripts/performance/dom-environment.mjs';
const dom=installPerformanceDom();
try {
	const directory=resolve(process.argv[2]);
	const client=await import(pathToFileURL(directory+'/client.mjs'));
	const server=await import(pathToFileURL(directory+'/server.mjs'));
	for(const kind of ['plain','intrinsic','component','explicit']){
		const html=await server.hydrationOutput(kind,20);
		for(let i=0;i<60;i++){
			client.measureClient(kind,20,20);
			client.measureHydration(kind,20,html);
		}
	}
} finally { dom.window.close(); }
