import {takeSuppliedPlacement} from '../../packages/dom/dist/client/renderer/supplied-placement-capability.js';
for(let i=0;i<10000;i++)takeSuppliedPlacement(undefined,undefined,undefined,undefined,undefined);
