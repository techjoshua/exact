import {PreparedComponentAttachment} from '../../packages/dom/dist/client/renderer/prepared-component-attachment.js';
import {createCompiledIntrinsicReceipt} from '../../packages/core/dist/client/component-abi/intrinsic-receipt.js';
const first=new PreparedComponentAttachment(),second=new PreparedComponentAttachment();
const before=%HaveSameMap(first,second);first.abort();
const result={preparedInitialMap:before,preparedAfterAbortMap:%HaveSameMap(first,second),preparedFastProperties:%HasFastProperties(first)};
for(const [name,props] of [['ordinary',{}],['keyed',{key:'one'}]]){
	const a=createCompiledIntrinsicReceipt('span',props,'a'),b=createCompiledIntrinsicReceipt('span',props,'b');
	result[name]={sameMap:%HaveSameMap(a,b),fastProperties:%HasFastProperties(a),frozen:Object.isFrozen(a)};
}
console.log(JSON.stringify(result,null,2));
