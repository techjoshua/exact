import {spawn} from 'node:child_process';
import {resolve} from 'node:path';
import {writeFile,readFile} from 'node:fs/promises';
const base=import.meta.dirname;
const rounds=[];
for(let index=0;index<4;index++){
 const round={};
 for(const side of index%2?['after','before']:['before','after']){
  const file=resolve(base,`round-${index}-${side}.json`);
  await new Promise((done,reject)=>{const p=spawn(process.execPath,['scripts/benchmark-enhancement-comparison.mjs','--measure',resolve(base,side),file],{stdio:'inherit',windowsHide:true});p.once('error',reject);p.once('exit',code=>code?reject(new Error(String(code))):done());});
  round[side]=JSON.parse(await readFile(file,'utf8'));
 }
 rounds.push(round);console.log('Completed round',index+1);
}
await writeFile(resolve(base,'paired-rounds.json'),JSON.stringify(rounds,null,2));
