import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createServer} from 'node:http';
import {execFileSync} from 'node:child_process';
import {chromium} from 'playwright';
import {startComparisonServer} from '../../framework-comparison/src/server.mjs';
import {captureClientPage,startClientPageReplay} from '../../framework-comparison/src/client-page-replay.mjs';
import {waitForSemanticReady,runProfiledInteraction} from '../../framework-comparison/src/client-profiling.mjs';
import {measureRetainedMemory} from '../../framework-comparison/src/browser-memory.mjs';
import {captureHeapComposition} from '../../framework-comparison/src/browser-heap-snapshot.mjs';
const base=import.meta.dirname;
const service=await startComparisonServer();
const replays=[];
let browser;
const entries=[
 {id:'before',directory:resolve(base,'browser-before'),server:'exact',port:4401},
 {id:'after',directory:resolve('framework-comparison/participants/exact/dist'),server:'exact',port:4406},
 {id:'react-control',directory:resolve('framework-comparison/participants/react/dist'),server:'react',port:4402}
];
const samples=[];
const telemetry=[];
function machine(){
 return JSON.parse(execFileSync('powershell.exe',['-NoProfile','-Command',`$cpu = Get-CimInstance Win32_PerfFormattedData_Counters_ProcessorInformation | Where-Object Name -eq '_Total'; @{ time=(Get-Date).ToUniversalTime().ToString('o'); power=(powercfg /getactivescheme); processor=$cpu | Select-Object PercentProcessorUtility,ProcessorFrequency,PercentofMaximumFrequency; processes=@(Get-Process | Sort-Object CPU -Descending | Select-Object -First 12 ProcessName,Id,CPU) } | ConvertTo-Json -Depth 5`],{encoding:'utf8',windowsHide:true}));
}
try{
 for(const entry of entries){
  const index=await readFile(resolve(entry.directory,'index.html'),'utf8');
  const clientTags=index.match(/(?:<script[^>]+src="[^"]+"[^>]*><\/script>|<link[^>]+href="[^"]+"[^>]*>)/g)?.join('\n')??'';
  const {renderParticipant}=await import(pathToFileURL(resolve('framework-comparison/participants',entry.server,'dist-server/server-entry.js')));
  const {incidents,users,sessionUserId}=service.service.store.snapshot();
  const html=await renderParticipant({incidents,users,sessionUserId},'/incidents/inc-100',{clientTags});
  const server=createServer((req,res)=>{res.writeHead(200,{'content-type':'text/html'});res.end(html);});
  await new Promise(done=>server.listen(entry.port,'127.0.0.1',done));
  let capture;
  try{capture=await captureClientPage({id:entry.id,url:`http://127.0.0.1:${entry.port}`,directory:entry.directory});}
  finally{server.closeAllConnections();await new Promise(done=>server.close(done));}
  replays.push(await startClientPageReplay(capture));
 }
 browser=await chromium.launch();
 // Timing and GC/snapshot lanes are separate. Every sample gets a fresh browser context.
 for(const lane of ['timing','heap']){
  const rounds=lane==='timing'?12:5;
  for(let round=-1;round<rounds;round++){
   telemetry.push({lane,round,...machine()});
   const order=round%2?[...entries].reverse():entries;
   for(const entry of order){
    const reset=await fetch('http://127.0.0.1:4310/__benchmark/reset',{method:'POST',headers:{'content-type':'application/json','x-benchmark-control':'fixture-reset'},body:'{}'});
    if(!reset.ok)throw new Error('reset failed');
    const context=await browser.newContext();
    try{
     const page=await context.newPage(); const errors=[];page.on('pageerror',e=>errors.push(e.message));
     const session=await context.newCDPSession(page);
     await session.send('Network.enable'); await session.send('Network.setCacheDisabled',{cacheDisabled:true}); await session.send('Performance.enable');
     await page.goto(`http://127.0.0.1:${entry.port}/incidents/inc-100`,{waitUntil:'domcontentloaded'});
     await waitForSemanticReady(page);
     const ready=await page.evaluate(()=>performance.now());
     await runProfiledInteraction(page);
     await page.evaluate(()=>new Promise(done=>requestAnimationFrame(done)));
     if(errors.length)throw new Error(errors.join('\n'));
     const sample={lane,round,id:entry.id,ready};
     if(lane==='heap'){ sample.memory=await measureRetainedMemory(session);if(round>=0)sample.composition=await captureHeapComposition(session); }
     if(round>=0)samples.push(sample);
    }finally{await context.close();}
   }
   console.log(lane,round);
  }
 }
 await writeFile(resolve(base,'browser-pair.json'),JSON.stringify({createdAt:new Date().toISOString(),browser:browser.version(),node:process.version,protocol:{timingRounds:12,heapRounds:5,warmupRounds:1,cache:'disabled',throttling:'none',order:'alternating before/after/control; reverse every other round',timing:'navigation to semantic-ready sampled from page clock',sameServerForExact:true},telemetry,samples,evidence:replays.map(r=>r.evidence())},null,2));
}finally{await browser?.close();for(const replay of replays)await replay.close();await service.close();}
