import re,json
from pathlib import Path
repo=Path.cwd();base=repo/'.tmp/ssr-large-profile';root=base/'scheduler-browser';root.mkdir(exist_ok=True)
node=(base/'preferred-yield-browser/node-server.mjs').read_text()
node=node.replace("{ id: 'react',", "{ id: 'exact', directory: new URL('"+(repo/'framework-comparison/participants/exact/dist').as_uri()+"/', import.meta.url), port: 4406 },\n\t{ id: 'react',",1)
start=node.index('const { handler: svelteKitHandler }');end=node.index('let closing = false;',start)
node=node[:start]+"const frameworkServers=[];const nuxtServer={async close(){}};\n"+node[end:]
node=node.replace("participant.id === 'exact' ? createNodeRenderScheduler()", "participant.port === 4406 ? createNodeRenderScheduler()")
(root/'node-server.mjs').write_text(node)
worker=(base/'preferred-yield-browser/bun-worker.mjs').read_text().replace("participantId==='exact'?scheduleRender:undefined","participantId==='exact'&&process.env.COMPARISON_SCHEDULE_RENDER==='1'?scheduleRender:undefined")
(root/'bun-worker.mjs').write_text(worker)
bun=(base/'preferred-yield-browser/bun-server.mjs').read_text()
bun=bun.replace("['exact', 'react', 'sveltekit', 'nuxt', 'tanstack-start']","['exact', 'react', 'exact']")
bun=bun.replace(str(base/'preferred-yield-browser/bun-worker.mjs').replace('\\','\\\\'),str(root/'bun-worker.mjs').replace('\\','\\\\'))
bun=bun.replace("COMPARISON_SSR_BOUNDED_TELEMETRY: '1'", "COMPARISON_SCHEDULE_RENDER:index===2?'1':'0', COMPARISON_SSR_BOUNDED_TELEMETRY: '1'")
bun=bun.replace('4401 + index','index===2?4406:4401+index')
(root/'bun-server.mjs').write_text(bun)
source=(base/'current-browser-performance.mjs').read_text()
functions=source[source.index('async function measureBrowserSample'):]
header="""import {writeFile,readFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {chromium} from 'playwright';
import {measureRetainedMemory} from '../../framework-comparison/src/browser-memory.mjs';
import {waitForFirstContentfulPaint} from '../../framework-comparison/src/paint-timing.mjs';
import {installBrowserVitals,readBrowserVitals} from '../../framework-comparison/src/browser-vitals.mjs';
import {hashSemanticResponse} from '../../framework-comparison/src/artifact-integrity.mjs';
import {createHash} from 'node:crypto';
const samples=Number(process.argv[2]??12),runtime=process.env.COMPARISON_E2E_RUNTIME,mode=process.env.COMPARISON_SSR_RENDER_MODE;
const participants=[{id:'exact-immediate',url:'http://127.0.0.1:4401'},{id:'exact-scheduled',url:'http://127.0.0.1:4406'},{id:'react',url:'http://127.0.0.1:4402'}];
async function resetService(body){const r=await fetch('http://127.0.0.1:4310/__benchmark/reset',{method:'POST',headers:{'content-type':'application/json','x-benchmark-control':'fixture-reset'},body:JSON.stringify(body)});assert(r.ok);}
function installReadinessTiming(){globalThis.__focusedReadyMs=null;new MutationObserver(()=>{if(globalThis.__focusedReadyMs===null&&document.querySelector('.connection')?.textContent.includes('Live service'))globalThis.__focusedReadyMs=performance.now();}).observe(document,{childList:true,characterData:true,subtree:true});}
const harness=await import(runtime==='bun'?'./scheduler-browser/bun-server.mjs':'./scheduler-browser/node-server.mjs');let browser;
const report={complete:false,runtime,mode,samples,rows:[],documents:[]};
try{
 for(const p of participants){await resetService({});const r=await fetch(p.url+'/incidents/inc-100');assert.equal(r.status,200);const body=Buffer.from(await r.arrayBuffer());assert.match(body.toString(),/^<!doctype html>/i);assert.match(body.toString(),/<\\/body><\\/html>$/i);report.documents.push({id:p.id,bytes:body.length,sha256:createHash('sha256').update(body).digest('hex')});}
 assert.equal(report.documents[0].sha256,report.documents[1].sha256);
 browser=await chromium.launch();
 for(const profile of ['local','constrained'])for(let round=-1;round<samples;round++){
  const offset=(round+3)%3,order=[...participants.slice(offset),...participants.slice(0,offset)];
  for(const p of order){p.profile=profile;const result=await measureBrowserSample(browser,p);if(round>=0)report.rows.push({id:p.id,profile,round,...result});}
  assert.equal(new Set(report.rows.map(r=>r.responseHash)).size,round>=0||profile==='constrained'?1:0);
  console.log(runtime,mode,profile,round+1);await writeFile(`.tmp/ssr-large-profile/scheduler-browser/${runtime}-${mode}.json`,JSON.stringify(report,null,2));
 }
 report.complete=true;await writeFile(`.tmp/ssr-large-profile/scheduler-browser/${runtime}-${mode}.json`,JSON.stringify(report,null,2));
}finally{await browser?.close();await harness.close();}
"""
(base/'scheduler-browser-measure.mjs').write_text(header+functions)
