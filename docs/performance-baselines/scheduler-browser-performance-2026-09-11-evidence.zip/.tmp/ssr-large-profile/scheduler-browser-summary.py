import json,statistics
from pathlib import Path
root=Path('.tmp/ssr-large-profile/scheduler-browser')
for path in root.glob('*.json'):
 d=json.loads(path.read_text())
 if not d.get('complete'):continue
 print(path.stem)
 for profile in ('local','constrained'):
  for name in ('exact-immediate','exact-scheduled','react'):
   rows=[r for r in d['rows'] if r['id']==name and r['profile']==profile]
   def median(key):return round(statistics.median(r['navigation'][key] for r in rows),2)
   print(profile,name,'FCP',median('firstContentfulPaintMs'),'navigation',median('durationMs'),'TTFB',median('responseStartMs'),'ready',round(statistics.median(r['readyMs'] for r in rows),2),'optimistic',round(statistics.median(r['optimisticFeedbackMs'] for r in rows),2))
