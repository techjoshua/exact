import json,hashlib,zipfile,statistics
from pathlib import Path
base=Path('.tmp/ssr-large-profile');out=Path('docs/performance-baselines')
def publish(stem,lines,files):
 report=out/(stem+'-2026-09-11.md')
 if report.exists():return
 report.write_text('\n'.join(lines)+'\n',encoding='utf8');files=list(dict.fromkeys(files+[report,base/'continuation-reports.py']))
 archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
 manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
  for p in files:z.write(p,p.as_posix())
  z.writestr('SHA256.json',json.dumps(manifest,indent=2))
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
 print(report,'verified archive')
for folder,stem,intro,extras in [
 ('queue-trace-node','scheduler-queue-wait-trace','Hypothesis: bounded serial batches improve loop fairness by moving request latency into the render-start queue. Large96 Node string, concurrency 256. Both frameworks receive the same outer timing wrapper. eXact gets request-local scheduler timing. Instrumentation adds allocations and Promise work, so this is explanatory evidence rather than an uninstrumented performance baseline.',['queue-trace-build.py','queue-trace-node-run.mjs','queue-trace-summary.py']),
 ('paced-bun','bun-paced-render-starts','Hypothesis: staggering starts by one or four microtask checkpoints inside each existing 32-start batch might reduce simultaneous completed-response lifetime and recover 5-15% throughput. Large96 native Bun string, concurrency 32. serial-1 and serial-4 labels mean checkpoint counts here, not batch sizes. Signal-free diagnostic only. React is unchanged.',['paced-build.py','paced-bun-run.mjs','paced-scheduler.mjs']),
 ('edge-sink','bun-deferred-document-edges','Hypothesis: preserving the first and last sink writes around the middle rope avoids flattening the entire HTML for document recognition and hydration insertion, potentially recovering 5-10%. Shared component sink API is unchanged. Three output chunks replace one only in the collecting sink; document recomposition uses concatenation. Large96 native Bun string, concurrency 32; current and candidate are frozen compiled bundles, with unchanged React.',['edge-sink-build.py','edge-sink-run.mjs'])]:
 root=base/folder;path=root/'capture.json'
 if not path.exists():continue
 d=json.loads(path.read_text())
 if not d['complete']:continue
 lines=['# '+stem.replace('-',' ').capitalize(),'',intro,'','Ten-second warmup, five-second measured blocks, two fresh-worker repeats with reversed ordering and immediate controls before and after scheduled variants. Machine workload may vary. Full authored documents and hydration are validated by response bytes and SHA-256.','', '| Repeat | Framework / variant | Policy | RPS | Response p95 A / B (ms) | Response p99 A / B (ms) |','| --- | --- | --- | ---: | --- | --- |'];total=0
 for b in d['blocks']:
  total+=b['valid'];ds=[]
  for r in b['results']:
   s=r['stages'][0];assert s['errors']==0 and s['started']==s['completed']==s['valid'];ds.append(s['distributions']['responseMs'])
  calls=b['after']['scheduleCalls'];expected=b['valid']+len(b['results']);assert calls==(expected if b['id']=='exact' and b['phase']!='normal' else 0)
  def tail(key):return ' / '.join(f'{x[key]:.3f}' for x in ds)
  lines.append(f"| {b['population']+1} | {b.get('variant',b['id'])} | {b['phase']} | {b['rps']:,.0f} | {tail('p95')} | {tail('p99')} |")
 lines+=['',f'{total:,} complete measured responses, zero errors. Percentiles are separate per-driver values, never pooled or averaged. Invocation guards pass.','']
 if folder=='queue-trace-node':
  lines+=['| Repeat | Framework | Policy | Mean queue (ms) | Mean remaining call (ms) | Queue share in slow sampled calls |','| --- | --- | --- | ---: | ---: | ---: |']
  for b in d['blocks']:
   t=b['after']['trace'];samples=t['samples'];tail=sorted(samples,key=lambda x:x['total'])[-max(1,len(samples)//20):];share=sum(x['queue'] for x in tail)/sum(x['total'] for x in tail)*100
   lines.append(f"| {b['population']+1} | {b['id']} | {b['phase']} | {t['queue']['mean']:.3f} | {t['remaining']['mean']:.3f} | {share:.1f}% |")
  lines+=['','One in 64 calls is sampled deterministically, capped at 8,192 samples per block. The last column selects the slowest approximately 5% of these samples. Remaining time is wall time after subtracting this call\'s measured gate wait, including other requests and Promise continuations. It is not renderer CPU time. Gate timing includes the diagnostic continuation.','', 'Serial 8 moves average waiting to roughly 68-69 ms versus 12 ms with the current scheduler. Approximately 98% of slow sampled serial-8 call time is queue wait. Do not select a default policy from event-loop lag alone. No production policy change.','']
 if folder=='paced-bun':lines+=['Pacing loses throughput relative to the current scheduled policy in both repeats, and both remain slower than immediate rendering on this workload. No production change adopted.','']
 if folder=='edge-sink':lines+=['Diagnostic only. Interpret current/candidate controls together with drift and response equality before deciding whether to implement and validate this sink in source.','']
 publish(stem,lines,[p for p in root.rglob('*') if p.is_file()]+[base/p for p in extras])

root=base/'scheduler-browser';paths=[root/(r+'-'+m+'.json') for r in ('node','bun') for m in ('string','stream')]
if all(p.exists() and json.loads(p.read_text())['complete'] for p in paths):
 lines=['# Browser performance with host render scheduling','','Twelve fresh-context samples per participant, runtime, render mode and browser profile, plus one discarded warmup per combination. Participant order rotates each round. Each navigation renders the complete authored document and hydration. eXact immediate and scheduled HTML hashes match. React rendering is unchanged. All samples verify hydration readiness, optimistic claim feedback, settled state, semantic equivalence and absence of browser/request errors.','', 'Local loopback; constrained profile uses 4x Chromium CPU throttling, 40 ms configured CDP latency and 10 Mbps each direction. Cache is disabled. Node uses the comparison browser harness\'s common response transport. Bun uses native Bun SSR workers behind the existing Node browser asset frontend/proxy, so Node/Bun navigation times are not pure runtime comparisons. No background load.','', '| Runtime | Render mode | Profile | Participant | Median FCP (ms) | Median navigation (ms) | Median ready (ms) | Median optimistic feedback (ms) |','| --- | --- | --- | --- | ---: | ---: | ---: | ---: |']
 for path in paths:
  d=json.loads(path.read_text());assert len(d['rows'])==72
  for profile in ('local','constrained'):
   for name in ('exact-immediate','exact-scheduled','react'):
    rows=[r for r in d['rows'] if r['id']==name and r['profile']==profile]
    def med(key):return statistics.median(r['navigation'][key] for r in rows)
    lines.append(f"| {d['runtime']} | {d['mode']} | {profile} | {name} | {med('firstContentfulPaintMs'):.2f} | {med('durationMs'):.2f} | {statistics.median(r['readyMs'] for r in rows):.2f} | {statistics.median(r['optimisticFeedbackMs'] for r in rows):.2f} |")
 lines+=['','288 measured scenarios passed. eXact navigation medians are lower than React in every measured cell. Constrained first paint is broadly tied. Scheduling has no consistent quiet-host browser benefit or penalty. React retains a small optimistic feedback advantage, about 1 ms under CPU throttling. Twelve samples per cell are insufficient for a robust p99 claim.','', 'These are current-build comparisons, not proof that a specific historical navigation regression has been eliminated. The browser frontend topology and measurement conditions must match before comparing older navigation figures.','']
 publish('scheduler-browser-performance',lines,paths+[p for p in root.glob('*.mjs')]+[base/'scheduler-browser-build.py',base/'scheduler-browser-measure.mjs',base/'scheduler-browser-summary.py'])
