import {writeFile,readFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {chromium} from 'playwright';
import {measureRetainedMemory} from '../../framework-comparison/src/browser-memory.mjs';
import {waitForFirstContentfulPaint} from '../../framework-comparison/src/paint-timing.mjs';
import {installBrowserVitals,readBrowserVitals} from '../../framework-comparison/src/browser-vitals.mjs';
import {hashSemanticResponse} from '../../framework-comparison/src/artifact-integrity.mjs';
import {createHash} from 'node:crypto';
const samples=Number(process.argv[2]??12),runtime=process.env.COMPARISON_E2E_RUNTIME,mode=process.env.COMPARISON_SSR_RENDER_MODE;
const participants=[{id:'exact-immediate',url:'http://127.0.0.1:4401'},{id:'exact-scheduled',url:'http://127.0.0.1:4406'},{id:'react',url:'http://127.0.0.1:4402'}];
async function resetService(body){const r=await fetch('http://127.0.0.1:4310/__benchmark/reset',{method:'POST',headers:{'content-type':'application/json','x-benchmark-control':'fixture-reset'},body:JSON.stringify(body)});assert(r.ok);}
function installReadinessTiming(){globalThis.__focusedReadyMs=null;new MutationObserver(()=>{if(globalThis.__focusedReadyMs===null&&document.querySelector('.connection')?.textContent.includes('Live service'))globalThis.__focusedReadyMs=performance.now();}).observe(document,{childList:true,characterData:true,subtree:true});}
const harness=await import(runtime==='bun'?'./scheduler-browser/bun-server.mjs':'./scheduler-browser/node-server.mjs');let browser;
const report={complete:false,runtime,mode,samples,rows:[],documents:[]};
try{
 for(const p of participants){await resetService({});const r=await fetch(p.url+'/incidents/inc-100');assert.equal(r.status,200);const body=Buffer.from(await r.arrayBuffer());assert.match(body.toString(),/^<!doctype html>/i);assert.match(body.toString(),/<\/body><\/html>$/i);report.documents.push({id:p.id,bytes:body.length,sha256:createHash('sha256').update(body).digest('hex')});}
 assert.equal(report.documents[0].sha256,report.documents[1].sha256);
 browser=await chromium.launch();
 for(const profile of ['local','constrained'])for(let round=-1;round<samples;round++){
  const offset=(round+3)%3,order=[...participants.slice(offset),...participants.slice(0,offset)];
  for(const p of order){p.profile=profile;const result=await measureBrowserSample(browser,p);if(round>=0)report.rows.push({id:p.id,profile,round,...result});}
  assert.equal(new Set(report.rows.map(r=>r.responseHash)).size,round>=0||profile==='constrained'?1:0);
  console.log(runtime,mode,profile,round+1);await writeFile(`.tmp/ssr-large-profile/scheduler-browser/${runtime}-${mode}.json`,JSON.stringify(report,null,2));
 }
 report.complete=true;await writeFile(`.tmp/ssr-large-profile/scheduler-browser/${runtime}-${mode}.json`,JSON.stringify(report,null,2));
}finally{await browser?.close();await harness.close();}
async function measureBrowserSample(browserInstance, participant) {
	await resetService({});
	const context = await browserInstance.newContext();
	try {
		const page = await context.newPage();
		const browserErrors = [];
		const failedRequests = [];
		page.on('console', (message) => {
			if (message.type() === 'error') browserErrors.push(message.text());
		});
		page.on('pageerror', (error) => browserErrors.push(error.message));
		page.on('requestfailed', (request) =>
			failedRequests.push(`${request.method()} ${request.url()}: ${request.failure()?.errorText}`)
		);
		await page.addInitScript(installInteractionTiming);
await page.addInitScript(installReadinessTiming);
		await page.addInitScript(installBrowserVitals);
		const session = await context.newCDPSession(page);
		await session.send('Network.enable');
		await session.send('Network.setCacheDisabled', { cacheDisabled: true });
		await session.send('Performance.enable');
        if(participant.profile==='constrained') {
            await session.send('Emulation.setCPUThrottlingRate',{rate:4});
            await session.send('Network.emulateNetworkConditions',{offline:false,latency:40,downloadThroughput:1250000,uploadThroughput:1250000});
        }
		// EventSource intentionally keeps the network active, so semantic readiness gates the sample.
		await page.goto(`${participant.url}/incidents/inc-100`, { waitUntil: 'domcontentloaded' });
		await page.getByRole('heading', { name: 'Checkout authorization failures' }).waitFor();
		const firstContentfulPaintMs = await page.evaluate(waitForFirstContentfulPaint);
		await page.waitForLoadState('load');
		const navigation = await page.evaluate(() => {
			const entry = performance.getEntriesByType('navigation')[0];
			const scripts = performance
				.getEntriesByType('resource')
				.filter(
					(resource) => resource.initiatorType === 'script' || /\.m?js(?:$|\?)/.test(resource.name)
				)
				.reduce((sum, resource) => sum + (resource.transferSize || 0), 0);
			return {
				durationMs: entry?.duration ?? null,
                responseStartMs: entry?.responseStart ?? null,
                responseEndMs: entry?.responseEnd ?? null,
                resources: performance.getEntriesByType('resource').filter(r=> /\.(css|js)(?:$|\?)/.test(r.name)).map(r=>({name:r.name,startTime:r.startTime,responseEnd:r.responseEnd})),
				domContentLoadedMs: entry?.domContentLoadedEventEnd ?? null,
				loadEventMs: entry?.loadEventEnd ?? null,
				transferredScriptBytes: scripts
			};
		});
		navigation.firstContentfulPaintMs = firstContentfulPaintMs;
		try {
			await page.locator('.connection').getByText('Live service', { exact: true }).waitFor();
		} catch (error) {
			throw new Error(
				`Live service readiness failed for ${participant.id}. ` +
					`Requests: ${failedRequests.join(' | ') || '<none>'}. ` +
					`Browser: ${browserErrors.join(' | ') || '<none>'}.`,
				{ cause: error }
			);
		}
		await page.getByRole('button', { name: 'Claim incident' }).click();
		await page.getByText('Alex Chen', { exact: true }).waitFor();
		await page.getByText('Version 2', { exact: true }).waitFor();
		const timing = await page.evaluate(() => globalThis.__frameworkComparisonTiming);
		if (timing?.optimisticFeedbackMs == null || timing.settlementMs == null)
			throw new Error(`Missing browser interaction timing for ${participant.id}`);
		// Collect retained memory after interaction timing. A forced collection immediately before the
		// click would turn optimistic feedback into a cold-allocation recovery measurement.
		const memory = await measureRetainedMemory(session);
		const vitals = await page.evaluate(readBrowserVitals);
		const semanticResponse = await page.evaluate(() => ({
			heading: document.querySelector('h1, h2')?.textContent?.trim() ?? null,
			owner: document.querySelector('.facts > div:first-child strong')?.textContent?.trim() ?? null,
			version: document.querySelector('.version')?.textContent?.trim() ?? null
		}));
		if (browserErrors.length || failedRequests.length)
			throw new Error(`${participant.id}: ${[...browserErrors, ...failedRequests].join(' | ')}`);
		return {
			navigation,
readyMs: await page.evaluate(() => globalThis.__focusedReadyMs),
			vitals,
			heapBytes: memory.jsHeapUsedBytes,
			memory,
			optimisticFeedbackMs: timing.optimisticFeedbackMs,
			settlementMs: timing.settlementMs,
			phasesMs: timing.phasesMs,
			responseHash: hashSemanticResponse(semanticResponse)
		};
	} finally {
		await context.close();
	}
}

/** Installs a participant-neutral click-to-visible-mutation clock in the page's own time domain. */
function installInteractionTiming() {
	const timing = {
		startedAt: null,
		optimisticFeedbackMs: null,
		settlementMs: null,
		phasesMs: {}
	};
	globalThis.__frameworkComparisonTiming = timing;
	const mark = (phase) => {
		if (timing.startedAt === null || timing.phasesMs[phase] !== undefined) return;
		timing.phasesMs[phase] = performance.now() - timing.startedAt;
	};

	const nativeFetch = globalThis.fetch;
	globalThis.fetch = (...args) => {
		const input = args[0];
		const url = typeof input === 'string' ? input : input instanceof Request ? input.url : '';
		if (url.endsWith('/claim')) mark('request-dispatched');
		return nativeFetch(...args).then((response) => {
			if (url.endsWith('/claim')) mark('http-headers-received');
			return response;
		});
	};
	const nativeResponseJson = Response.prototype.json;
	Response.prototype.json = function () {
		return nativeResponseJson.call(this).then((value) => {
			if (this.url.endsWith('/claim')) mark('http-json-decoded');
			return value;
		});
	};
	const observedEventSources = new WeakSet();
	const nativeAddEventListener = EventSource.prototype.addEventListener;
	EventSource.prototype.addEventListener = function (type, listener, options) {
		if (type === 'incident' && !observedEventSources.has(this)) {
			observedEventSources.add(this);
			nativeAddEventListener.call(this, type, () => mark('sse-incident-received'));
		}
		return nativeAddEventListener.call(this, type, listener, options);
	};
	document.addEventListener(
		'click',
		(event) => {
			const button = event.target instanceof Element ? event.target.closest('button') : null;
			if (button?.textContent?.trim() !== 'Claim incident' || timing.startedAt !== null) return;
			timing.startedAt = performance.now();
		},
		true
	);
	new MutationObserver(() => {
		if (timing.startedAt === null) return;
		const now = performance.now();
		const owner = document.querySelector('.facts > div:first-child strong')?.textContent?.trim();
		const version = document.querySelector('.version')?.textContent?.trim();
		if (timing.optimisticFeedbackMs === null && owner === 'Alex Chen') {
			timing.optimisticFeedbackMs = now - timing.startedAt;
			timing.phasesMs['optimistic-dom-visible'] ??= timing.optimisticFeedbackMs;
		}
		if (timing.settlementMs === null && version === 'Version 2') {
			timing.settlementMs = now - timing.startedAt;
			timing.phasesMs['authoritative-dom-visible'] ??= timing.settlementMs;
		}
	}).observe(document, { childList: true, characterData: true, subtree: true });
}

