from pathlib import Path
import json
root=Path('.tmp/bun-adaptive-ssr');root.mkdir(exist_ok=True)
old=Path('.tmp/client-full')
for file in ['capacity-runner.mjs','multi-plan.json','normal-plan.json','arrivals-plan.json','final-browser.mjs','verify-docs.mjs']:
 (root/file).write_text((old/file).read_text(encoding='utf8').replace('.tmp/client-full','.tmp/bun-adaptive-ssr'),encoding='utf8')
s=(old/'run.mjs').read_text(encoding='utf8').replace('.tmp/client-full','.tmp/bun-adaptive-ssr')
start=s.index("await run('browser',")
end=s.index("for(const mode of ['string','stream'])",start)
s=s[:start]+s[end:]
start=s.index("for(const [name,file,json]")
s=s[:start]+"await run('server',['scripts/benchmark-server-performance.mjs']);\nconsole.log('COMPLETE all SSR measurements');\n"
(root/'run.mjs').write_text(s,encoding='utf8')
for file in ['performance-report','ssr-capacity-report','ssr-bun-capacity-report','ssr-node-stream-capacity-report','ssr-bun-stream-capacity-report','ssr-stream-report']:
 (root/('before-'+file+'.json')).write_bytes(Path('apps/docs/src/data/'+file+'.json').read_bytes())
