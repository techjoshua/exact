from pathlib import Path
import re,json
root=Path.cwd();out=root/'.tmp/bun-adaptive-auto'
s=(root/'framework-comparison/src/ssr-benchmark-worker.mjs').read_text(encoding='utf8')
s=re.sub(r"from '([^']+)'",lambda m: "from '"+(root/'framework-comparison/src'/m[1]).resolve().as_uri()+"'" if m[1].startswith('.') else m[0],s)
s=s.replace("const suiteRoot = resolve(import.meta.dirname, '..');",'const suiteRoot = '+json.dumps(str(root/'framework-comparison'))+';')
s=s.replace('createBunRequestHandler : undefined','createBunRequestHandler : undefined')
# Keep the framework implementation intact; the temporary worker supplies only the public opt-out.
s=s.replace('? createBunRequestHandler', "? (handler) => createBunRequestHandler(handler, {adaptive: process.env.BUN_ADMISSION_CONTROL !== 'immediate'})")
s="import { BunRequestGate } from '"+(root/'framework-adapters/bun-adapter/dist/adaptive-gate.js').as_uri()+"';\nconst observe=BunRequestGate.prototype.shouldSchedule;BunRequestGate.prototype.shouldSchedule=function(){const value=observe.call(this);if(this.lastDiagnostic!==value){console.error('ADMISSION',value,this.phase);this.lastDiagnostic=value;}return value;};\n"+s
(out/'focus-worker.mjs').write_text(s,encoding='utf8')
s=(root/'.tmp/client-full/capacity-runner.mjs').read_text(encoding='utf8').replace("resolve('framework-comparison/src/ssr-benchmark-worker.mjs')","resolve('.tmp/bun-adaptive-auto/focus-worker.mjs')")
(out/'capacity-runner.mjs').write_text(s,encoding='utf8')
plan={'drivers':2,'stages':[{'name':'warmup','mode':'concurrency','concurrency':16,'durationMs':5000,'discard':True},{'name':'total-c32','mode':'concurrency','concurrency':16,'durationMs':8000},{'name':'total-arrivals-8000','mode':'arrivals','rate':4000,'durationMs':8000}]}
(out/'focus-plan.json').write_text(json.dumps(plan),encoding='utf8')
