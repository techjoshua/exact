let release;
const ready = new Promise(r => release=r);
const server = Bun.serve({port:0, fetch(){return new Response(new ReadableStream({async start(c){c.enqueue(new TextEncoder().encode('head'));await ready;c.close();}}));}});
try {const response=await fetch(server.url);await new Promise(r=>setTimeout(r,30));console.log('pending while body open',server.pendingRequests);release();await response.text();await new Promise(r=>setTimeout(r,30));console.log('pending after body completed',server.pendingRequests);}finally{release();await server.stop(true);}
