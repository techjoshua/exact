from pathlib import Path
import json
root=Path('.tmp/bun-adaptive-auto')
s=(root/'focus-worker.mjs').read_text(encoding='utf8')
s=s.replace("const initialData = url.searchParams.has('__benchmarkPreloaded')", "let initialData = url.searchParams.has('__benchmarkPreloaded')",1)
s=s.replace("const response = await measureAsyncPhase('renderMs',", "if (process.env.BUN_ADMISSION_LARGE === '1') initialData = {...initialData, incidents: Array.from({length:96},(_,i)=>({...initialData.incidents[i%3],id:'inc-'+(100+i)}))};\n\t\t\t\t\tconst response = await measureAsyncPhase('renderMs',",1)
(root/'large-worker.mjs').write_text(s,encoding='utf8')
s=(root/'capacity-runner.mjs').read_text(encoding='utf8').replace('focus-worker.mjs','large-worker.mjs')
s=s.replace("for(const id of population?['react','exact']:['exact','react'])", "for(const policy of population?['immediate','auto']:['auto','immediate'])")
s=s.replace(' const serviceIntervals=[],', " const id='exact';process.env.BUN_ADMISSION_CONTROL=policy;\n const serviceIntervals=[],")
s=s.replace('const block={population,id,','const block={population,id,policy,').replace("console.log('Population',population+1,id,'drivers'", "console.log('Population',population+1,id,policy,'drivers'")
(root/'control-runner.mjs').write_text(s,encoding='utf8')
plan={'drivers':2,'stages':[{'name':'warmup','mode':'concurrency','concurrency':16,'durationMs':5000,'discard':True},{'name':'total-c32','mode':'concurrency','concurrency':16,'durationMs':8000}]}
(root/'control-plan.json').write_text(json.dumps(plan),encoding='utf8')
