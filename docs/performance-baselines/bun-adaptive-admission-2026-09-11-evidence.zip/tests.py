from pathlib import Path
s=Path('framework-adapters/node-adapter/src/requests/adaptive-gate.test.ts').read_text(encoding='utf8').replace('AdaptiveRequestGate','BunRequestGate').replace("'./adaptive-gate.js'","'./adaptive-gate.js'").replace('new BunRequestGate()', 'new BunRequestGate(() => 0)')
s=s.replace('const epoch = gate.observeRequest();\n\t\t\tif (epoch !== undefined) gate.observeCompletion(epoch);','gate.observeRequest();').replace('const epoch = gate.observeRequest();\n\t\t\t\tif (epoch !== undefined) gate.observeCompletion(epoch);','gate.observeRequest();')
a=s.index("it('does not credit completions")
b=s.index("it('resets an interrupted",a)
s=s[:a]+'''it('does not count starts whose native bodies remain pending as departures', () => {
 let pending = 0;
 const gate = new BunRequestGate(() => pending);
 for (let window = 0; window < 24; window++) {
  for (let request = 0; request < 100; request++) {
   pending++;
   gate.observeRequest();
  }
  vi.advanceTimersByTime(250);
  expect(gate.shouldSchedule()).toBe(false);
 }
});

'''+s[b:]
Path('framework-adapters/bun-adapter/src/adaptive-gate.test.ts').write_text(s,encoding='utf8')
s=Path('framework-adapters/node-adapter/src/render-scheduler.test.ts').read_text(encoding='utf8').replace('createNodeRenderScheduler','createBunRenderScheduler')
Path('framework-adapters/bun-adapter/src/render-scheduler.test.ts').write_text(s,encoding='utf8')
