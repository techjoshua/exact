import json,hashlib,zipfile
from pathlib import Path
from statistics import mean
root=Path('.tmp/ssr-large-profile')
data=json.loads((root/'http-literal-path/capture.json').read_text())
assert data['complete'] and len(data['blocks'])==2
valid=0
for block in data['blocks']:
    for result in block['results']:
        for s in result['stages']:
            assert s['errors']==0 and s['valid']==s['started']==s['completed']
            valid+=s['valid']
summary={'valid':valid,'regions':{}}
names=data['blocks'][0]['after']['regions']['regions']
for name in names:
    stats={}
    for label,key in [('before','loopBefore'),('http','after'),('after','loopAfter')]:
        stats[label]=mean(b[key]['regions']['regions'][name]['exclusiveMs']*1000/b[key]['regions']['samples'] for b in data['blocks'])
    summary['regions'][name]=stats
print(json.dumps(summary,indent=2))
(root/'http-literal-path/summary.json').write_text(json.dumps(summary,indent=2))
files=set()
for p in root.glob('http-literal-path*'):
    if p.is_file():files.add(p)
    else:files.update(f for f in p.rglob('*') if f.is_file())
for name in ['exact','react','worker']:
    item=data['artifacts'][name];path=Path(item['path'])
    assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'];files.add(path)
files.add(root/'conditional-emission/server-entry.js')
files.add(root/'path-string-layout.log')
files.add(Path('.tmp/positional-leaves/data.json'))
files={p.resolve().relative_to(Path.cwd()) for p in files}
archive=Path('docs/performance-baselines/http-literal-path-2026-09-10-evidence.zip')
assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files):z.write(p,p.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified archive files:',len(files))

