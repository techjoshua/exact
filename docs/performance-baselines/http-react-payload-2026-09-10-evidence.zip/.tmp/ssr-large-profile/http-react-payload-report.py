from pathlib import Path
from statistics import mean
import json,hashlib,zipfile
root=Path('.tmp/ssr-large-profile')
capture=json.loads((root/'http-react-payload/capture.json').read_text())
assert capture['complete'] and len(capture['blocks'])==16
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for artifact in capture['artifacts'].values():
 if 'path' in artifact and 'sha256' in artifact and Path(artifact['path']).is_file():assert sha(artifact['path'])==artifact['sha256']
valid=errors=0
for block in capture['blocks']:
 assert block['identity']['bytes']==(4672 if block['id']=='exact' or block['phase']=='on' else 3660)
 for result in block['results']:
  for stage in result['stages']:
   assert stage['started']==stage['completed']==stage['valid']
   valid+=stage['valid'];errors+=stage['errors']
assert errors==0
rows=[]
for participant in ['exact','react']:
 for population in [0,1]:
  grouped={phase:[b for b in capture['blocks'] if b['id']==participant and b['population']==population and b['phase']==phase] for phase in ['off','on']}
  assert all(len(v)==2 for v in grouped.values())
  data={'participant':participant,'population':population}
  for phase,blocks in grouped.items():
   data[phase+'Rps']=mean(b['rps'] for b in blocks)
   data[phase+'RenderUs']=mean(b['after']['telemetry']['statistics']['renderMs']['sum']*1000/b['after']['telemetry']['statistics']['renderMs']['count'] for b in blocks)
  data['changePercent']=(data['onRps']/data['offRps']-1)*100
  rows.append(data)
summary={'rows':rows,'valid':valid,'errors':errors}
(root/'http-react-payload/summary.json').write_text(json.dumps(summary,indent=2))
table=['| Participant / worker | Normal RPS | Padding enabled RPS | Change |','| --- | ---: | ---: | ---: |']
for row in rows:table.append(f"| {row['participant']} / {row['population']+1} | {row['offRps']:,.0f} | {row['onRps']:,.0f} | {row['changePercent']:+.2f}% |")
report=Path('docs/performance-baselines/http-react-payload-2026-09-10.md')
assert not report.exists()
report.write_text('''# Response-size contribution to the Node HTTP gap

Status: diagnostic complete. No production or benchmark-baseline change.

## Hypothesis

The current standard document is 4,672 bytes for eXact and 3,660 bytes for React.
The difference crosses 4 KiB, making transport buffering or allocation a plausible
contributor to the HTTP throughput gap. Explaining the whole recent gap would
require approximately a 20 to 25 percent React throughput decrease after padding.
This is a hypothesis about a possible size effect, not a claim that the current
Node transport has a specific 4 KiB allocation threshold.

The existing equalizeNodeResponsePayload helper changes response.end(chunk) into
body and padding writes followed by end(). That confounds payload size with write
pattern. This scratch worker instead appends a precomputed 1,012-space string to
React's completed document and still sends one response.end(responseDocument).
Both modes render the full React component tree on every request. No response or
render result is cached. The normal renderer timing excludes padding; complete
HTTP throughput includes concatenation, encoding, telemetry and transmission.

The eXact branch remains unchanged and acts as a null control when the same
diagnostic switch is toggled. This does not make the two benchmark payloads
permanently equal, shorten eXact output, change a renderer, or improve React.

## Method and checks

Four fresh production Node 26.8.1 workers start in eXact / React / React / eXact
order. Each receives ten seconds of warmup and four three-second measurement
blocks. Switch orders are on/off/off/on and off/on/on/off. Each block uses two
fresh driver processes at concurrency 16 each. Worker, drivers and service run
below normal priority. No tests, builds or profilers run during measurement.
Original invocation and bounded benchmark telemetry remain enabled in both modes.

Before each block, fetch and validate the selected response: status 200, unchanged
complete document prefix, expected length, and only ASCII spaces after the
original document. Drivers then verify the complete selected response identity.
Original eXact and React component trees, hydration payloads, shells, headers and
single-end response patterns are preserved. Artifact/worker hashes and adapter
measurements are checked again after the run.

The builder initially rejected its expected-source match because the worker used
CRLF line endings. It was corrected to normalize scratch source line endings before
matching. No benchmark worker was started by that failed build.

## Results

Arithmetic means of each worker's two blocks per mode:

'''+ '\n'.join(table)+f'''

All {valid:,} measured responses are valid with zero errors, excluding warmups and
preflights. The raw capture contains all 16 blocks, per-block identities, timings,
telemetry and process metadata. All task-owned processes close after completion.

Padding produces a much smaller change than would be needed to close the gap.
The unchanged eXact control varies too, demonstrating why a small mode difference
cannot be treated as an exact causal estimate of transport cost. This capture does
not support response size as the dominant explanation for eXact's HTTP shortfall.
It also does not prove size has zero cost or identify a particular Node buffer
threshold. No correction factor should be applied to the public benchmark numbers.

Keep prioritizing measured rendering/publication and request-path work. This is
only a Node string-response diagnostic; it does not establish native Bun behavior,
streaming behavior, browser timing or the value of future output-size reductions.
The overall goal of outperforming React remains open.

The adjacent archive contains the worker and builder, run and report scripts,
capture and summary, fixture, framework artifacts, ownership helpers and this
report with a verified SHA-256 manifest. It is an evidence archive, not a complete
standalone installation of every workspace dependency.
''',encoding='utf8')
files={report,Path('.tmp/positional-leaves/data.json')}
files.update(p for p in root.glob('http-react-payload-*') if p.is_file())
files.update(p for p in (root/'http-react-payload').rglob('*') if p.is_file())
files.add(root/'http-react-payload.log')
files.update(Path(capture['artifacts'][name]['path']).relative_to(Path.cwd()) for name in ['exact','react'])
files.update(Path(p) for p in ['framework-comparison/src/ssr-worker-controller.mjs','framework-comparison/src/ssr-load-process-owner.mjs','framework-comparison/src/ssr-run-environment.mjs','scripts/development-process-lifecycle.mjs'])
archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={p.as_posix():sha(p) for p in sorted(files)}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files):z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,digest in json.loads(z.read('SHA256.json')).items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps({'summary':summary,'files':len(files),'archive':str(archive)},indent=2))
