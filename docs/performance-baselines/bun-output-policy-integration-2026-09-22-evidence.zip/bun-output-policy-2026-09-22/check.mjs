import { spawn } from 'node:child_process';
import { openSync,closeSync,writeFileSync } from 'node:fs';
const dir='.tmp/bun-output-policy-2026-09-22';
const steps=[
 ['build',['node_modules/@typescript/native/bin/tsc','-b','packages/server','packages/ssr','framework-adapters/bun-adapter']],
 ['adapter-tests',['node_modules/vitest/vitest.mjs','run','framework-adapters/bun-adapter/src','packages/server/src/framework/render-scheduling.test.ts']],
 ['ssr-tests',['../../node_modules/vitest/vitest.mjs','run','src/render/resume-scheduling.test.ts','src/render/render-scheduling.test.ts','src/render/readiness-scheduling.test.ts'],'packages/ssr']
];
const journal=[];
for(const [name,args,cwd] of steps){
 const row={name,args,cwd:cwd??'.',startedAt:new Date().toISOString()};journal.push(row);
 const save=()=>writeFileSync(`${dir}/checks.json`,JSON.stringify(journal,null,2));save();console.log('START',name);
 const fd=openSync(`${dir}/${name}.log`,'w');
 try{await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{cwd,stdio:['ignore',fd,fd]});child.once('error',fail);child.once('exit',code=>{row.code=code;code===0?done():fail(Error(name+' failed '+code));});});}
 finally{closeSync(fd);row.endedAt=new Date().toISOString();save();}
 console.log('DONE',name);
}
