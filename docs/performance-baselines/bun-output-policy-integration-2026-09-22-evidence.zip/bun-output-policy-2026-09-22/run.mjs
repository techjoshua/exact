import { spawn } from 'node:child_process';
import { openSync,closeSync,readFileSync,writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';
const dir='.tmp/bun-output-policy-2026-09-22';
const workload=process.argv[2]??'smoke';
const journal=[];
for(const mode of ['stream','string']) {
 const pair=[];
 for(const variant of mode==='stream'?['candidate','control']:['control','candidate']) {
  const name=`${workload}-${mode}-${variant}`;
  const env={NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:mode,EXPERIMENT_VARIANT:variant,EXPERIMENT_ROWS:workload==='large'?'96':'default',EXPERIMENT_ORDER:mode==='stream'?'react-first':'exact-first'};
  const args=[`${dir}/capture.mjs`,`${dir}/${workload==='large'?'concurrency':workload}.json`,`${dir}/${name}.json`,'bun'];
  const step={name,args,env,startedAt:new Date().toISOString()};journal.push(step);
  const save=()=>writeFileSync(`${dir}/${workload}-execution.json`,JSON.stringify(journal,null,2));save();console.log('START',name);
  const fd=openSync(`${dir}/${name}.log`,'w');
  try{await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{env:{...process.env,...env},stdio:['ignore',fd,fd]});step.pid=child.pid;save();child.once('error',fail);child.once('exit',code=>{step.code=code;code===0?done():fail(Error(`${name}: ${code}`));});});}
  finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}
  const c=JSON.parse(readFileSync(`${dir}/${name}.json`));assert.equal(c.complete,true);pair.push(c);console.log('DONE',name);
 }
 assert.deepEqual(pair[0].responseIdentities,pair[1].responseIdentities);
 assert.deepEqual(pair[0].artifacts.exact,pair[1].artifacts.exact);
}
console.log('PASS',workload);
