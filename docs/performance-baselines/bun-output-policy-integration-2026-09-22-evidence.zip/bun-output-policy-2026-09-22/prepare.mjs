import { cpSync,readFileSync,writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import ts from 'typescript';
const dir='.tmp/bun-output-policy-2026-09-22';
const prior='.tmp/mode-paths-2026-09-21';
for(const variant of ['control','candidate']) {
 cpSync(`${prior}/adapters/bun-control`,`${dir}/adapters/bun-${variant}`,{recursive:true});
 if(variant==='candidate')for(const name of ['request-handler','render-policy']) {
  const file=`framework-adapters/bun-adapter/src/${name}.ts`;
  const source=readFileSync(file,'utf8');
  const result=ts.transpileModule(source,{fileName:file,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}});
  writeFileSync(`${dir}/adapters/bun-${variant}/${name}.js`,result.outputText);
  writeFileSync(`${dir}/${name}.source.ts`,source);
 }
}
cpSync(`${prior}/adapters/node-control`,`${dir}/adapters/node-control`,{recursive:true});
let source=readFileSync('.tmp/bun-stream-codec-2026-09-21/actual-host-entry.js','utf8');
assert.ok(source.includes('function withRequestRenderScheduling(options) {'));
source=source.replace('function withRequestRenderScheduling(options) {','function withRequestRenderScheduling(options, kind = "string") {');
const before='const scheduleRender = requestRenderScheduler(options.signal);';
assert.equal(source.split(before).length,2);
source=source.replace(before,'const host = requestRenderScheduler(options.signal);\n\tconst scheduleRender = host?.forOutput?.(kind) ?? host;');
const start=source.indexOf('async function streamDocumentRender(');
assert.ok(start>0);
const tail=source.slice(start).replace('options = withRequestRenderScheduling(options);','options = withRequestRenderScheduling(options, "stream");');
source=source.slice(0,start)+tail;
writeFileSync(`${dir}/entry.js`,source);
writeFileSync(`${dir}/worker.mjs`,readFileSync(`${prior}/worker.mjs`,'utf8'));
let capture=readFileSync(`${prior}/capture.mjs`,'utf8').replaceAll(prior,dir);
capture=capture.replace("resolve('.tmp/bun-stream-codec-2026-09-21/actual-host'+(runtimeId==='node'?'-node':'')+'-entry.js')",`resolve('${dir}/entry.js')`);
writeFileSync(`${dir}/capture.mjs`,capture);
for(const name of ['concurrency.json','demand.json','smoke.json','summarize.py'])cpSync(`${prior}/${name}`,`${dir}/${name}`);
