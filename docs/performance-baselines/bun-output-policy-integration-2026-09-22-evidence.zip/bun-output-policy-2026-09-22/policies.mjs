export async function selectRequestAdapters(runtime,mode,variant) {
 if(runtime!=='bun'||!['string','stream'].includes(mode)||!['control','candidate'].includes(variant))throw new TypeError('Invalid integration lane');
 const [node,bun]=await Promise.all([import('./adapters/node-control/index.js'),import(`./adapters/bun-${variant}/index.js`)]);
 return {policyId:`bun-${variant}`,createNodeHandler:node.createNodeHandler,createBunRequestHandler:bun.createBunRequestHandler};
}
