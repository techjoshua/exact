from pathlib import Path
import json,hashlib,zipfile
p=Path(__file__).parent
rows=json.loads((p/'summary.json').read_text())
comparisons=[]
for workload in ['concurrency','large','demand']:
 journal=json.loads((p/f'{workload}-execution.json').read_text())
 assert len(journal)==4 and all(x.get('code')==0 for x in journal)
 for mode in ['stream','string']:
  prefix=f'{workload}-{mode}'
  for stage in sorted({r['stage'] for r in rows if r['capture'].startswith(prefix)}):
   group={(r['variant'],r['framework']):r for r in rows if r['capture'].startswith(prefix) and r['stage']==stage}
   assert len(group)==4
   c=group['control','exact'];n=group['candidate','exact'];cr=group['control','react'];nr=group['candidate','react']
   comparisons.append(dict(workload=workload,mode=mode,stage=stage,control=c,candidate=n,reactControl=cr,reactCandidate=nr,ratioChangePercent=100*((n['validRps']/nr['validRps'])/(c['validRps']/cr['validRps'])-1)))
(p/'comparison.json').write_text(json.dumps(comparisons,indent=2)+'\n')
text=['# Bun automatic output-policy integration, September 22, 2026','','The final integration selects a progressive-render work window from the signal-bound host scheduler. It retains the existing string policy and initial adaptive Fetch admission. A single native observer counts all requests, including mixed string and stream routes. Explicit renderer scheduling callbacks and the adaptive opt-out retain precedence. Compiled components, sinks, transport backpressure, and Node scheduling are unchanged.','','The private controls start at `70b73fa8`. Both sides use identical renderer bundles and emitted components, with the new progressive-only policy selector present in both. Only the adapter supplies the optional streaming policy. Complete response identities and frozen artifacts are checked. Large cases expand both frameworks to 96 rows. Each capture includes two drivers and a React comparison; RPS includes drain. Concurrency uses 10-second warmup and 15-second stages; scheduled demand uses 30-second warmup and 60-second measurement at 10,000 offered RPS. This focused protocol is distinct from the full suite with reversed populations and both 8,000 and 10,000 rates.','','The first integration used a generic output selector. Its streaming ratios improved, but its string c32 ratio fell about 5%. That result is retained in the archive. The final revision preserves the original string helper and reads an optional `streaming` field only in the progressive entry point. These measurements do not isolate a single dispatch call as the cause of the earlier string result.','']
for workload in ['concurrency','large','demand']:
 text+=['## '+workload.capitalize(),'','| API | Stage | eXact control RPS | eXact candidate RPS | React control RPS | React candidate RPS | Ratio change |','| --- | --- | ---: | ---: | ---: | ---: | ---: |']
 for r in comparisons:
  if r['workload']!=workload:continue
  text.append(f"| {r['mode']} | {r['stage']} | {r['control']['validRps']:,.0f} | {r['candidate']['validRps']:,.0f} | {r['reactControl']['validRps']:,.0f} | {r['reactCandidate']['validRps']:,.0f} | {r['ratioChangePercent']:+.1f}% |")
 text+=['']
text+=['## Scheduled-demand latency','','| API | Control p99 | Candidate p99 | Control capacity misses | Candidate capacity misses |','| --- | ---: | ---: | ---: | ---: |']
for r in comparisons:
 if r['workload']!='demand':continue
 c=r['control'];n=r['candidate']
 text.append(f"| {r['mode']} | {min(c['p99']):.2f}–{max(c['p99']):.2f} ms | {min(n['p99']):.2f}–{max(n['p99']):.2f} ms | {c['capacityMissPercent']:.2f}% | {n['capacityMissPercent']:.2f}% |")
text+=['','p99 ranges are separate driver observations, not confidence intervals. String results are preservation guards, not evidence of an intentionally faster string algorithm. The archive retains raw captures, telemetry, both integration revisions, source snapshots, plans, identities, and validation logs. These focused captures do not replace the full public charts.','']
(p/'report.md').write_text('\n'.join(text))
print(json.dumps(comparisons,indent=2))
