from pathlib import Path
import json,zipfile,hashlib
root=Path(__file__).parent
prefix=Path('docs/performance-baselines/bun-output-policy-integration-2026-09-22')
archive=Path(str(prefix)+'-evidence.zip');manifest={}
directories=[Path('.tmp/bun-output-policy-2026-09-22'),root]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for directory in directories:
  for p in sorted(directory.rglob('*')):
   if not p.is_file():continue
   name=str(p.relative_to(directory.parent));data=p.read_bytes()
   z.writestr(name,data);manifest[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
data={'comparisons':json.loads((root/'comparison.json').read_text()),'archive':{'path':str(archive),'sha256':sha,'bytes':archive.stat().st_size,'files':len(manifest)}}
Path(str(prefix)+'.json').write_text(json.dumps(data,indent=2)+'\n')
text=(root/'report.md').read_text()+f'\n[Structured comparison]({prefix.name}.json) and [evidence archive]({archive.name}). Archive SHA-256: `{sha}`.\n'
Path(str(prefix)+'.md').write_text(text)
print(json.dumps(data['archive'],indent=2))
