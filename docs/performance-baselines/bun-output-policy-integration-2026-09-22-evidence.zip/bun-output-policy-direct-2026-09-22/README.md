# Bun automatic output-policy integration candidate

This candidate selects the progressive work window at the SSR API boundary using an optional capability on the signal-bound host scheduler. String rendering and initial Fetch admission retain the shipping adaptive gate. Both modes share one host-wide arrival/departure observer, so mixed routes do not combine subset arrivals with all native pending requests. No component emission changes. Explicit scheduleRender callbacks retain precedence; adaptive:false continues to disable automatic scheduling.

This is a different integration from the dedicated streaming-host prototype: initial admission remains adaptive until the renderer selects its output API. It must independently pass capacity and latency checks before adoption. Private builds transpile only the new adapter modules and patch only the runtime policy-selection helper in the shared renderer bundle. Both sides use that same bundle, with the original emitted components intact.

Revision: preserve the original string policy helper verbatim. Progressive SSR alone reads the host scheduler's optional streaming field. No generic selector call is added to string rendering. The first integration had a -5% string ratio guard at c32, so this smaller dispatch surface requires its own fresh checks. No claim is made that the removed function call alone caused that measured loss.
