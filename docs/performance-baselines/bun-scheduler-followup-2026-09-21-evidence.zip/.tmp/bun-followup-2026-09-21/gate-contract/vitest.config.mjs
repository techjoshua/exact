import {defineConfig} from 'vitest/config';
export default defineConfig({test:{include:['.tmp/bun-followup-2026-09-21/gate-contract/*.test.ts'],exclude:[],maxWorkers:1}});
