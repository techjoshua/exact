import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import assert from 'node:assert/strict';
const root='.tmp/bun-followup-2026-09-21';
for(const file of ['cpu-observer-guard-execution.json']){
 const steps=JSON.parse(await readFile(`${root}/${file}`));
 assert.ok(steps.length>0&&steps.every(s=>s.code===0),'Timing guard still active');
}
const fixture=JSON.parse(await readFile('framework-comparison/fixtures/baseline.json'));
const data={sessionUserId:fixture.sessionUserId,users:fixture.users,incidents:fixture.incidents};
const variants={};const artifacts={};
for(const id of ['actual-host','asset-cache']){
 const file=new URL(`../bun-stream-codec-2026-09-21/${id}-node-entry.js`,import.meta.url);
 variants[id]=await import(file.href);artifacts[id]=createHash('sha256').update(await readFile(file)).digest('hex');
}
const report={kind:'render-only-isolation',createdAt:new Date().toISOString(),node:process.version,artifacts,rows:[],note:'No HTTP or scheduler. Diagnostic rendering cost, not request capacity.'};
for(const mode of ['string','stream']){
 async function render(id,collect=false){
  if(mode==='string')return (await variants[id].renderParticipant(data,'/incidents/inc-101',{}));
  const chunks=[];let bytes=0;
  for await(const chunk of variants[id].renderParticipantStream(data,'/incidents/inc-101',{})){bytes+=chunk.byteLength;if(collect)chunks.push(chunk);}
  return collect?Buffer.concat(chunks).toString():bytes;
 }
 const reference=await render('actual-host',true);
 for(const id of Object.keys(variants)){
  assert.equal(await render(id,true),reference);
  for(let i=0;i<2000;i++)await render(id);
 }
 for(let repeat=0;repeat<6;repeat++){
  const order=repeat%2?['asset-cache','actual-host']:['actual-host','asset-cache'];
  for(const id of order){
   await new Promise(setImmediate);
   const started=performance.now(),cpu=process.cpuUsage();let consumed=0;
   for(let i=0;i<10000;i++){const result=await render(id);consumed+=typeof result==='string'?result.length:result;}
   const elapsedMs=performance.now()-started,usage=process.cpuUsage(cpu);
   const row={mode,id,repeat,renders:10000,elapsedMs,cpuMs:(usage.user+usage.system)/1000,consumed};
   report.rows.push(row);console.log(JSON.stringify(row));
   await writeFile(`${root}/asset-isolation.json`,JSON.stringify(report,null,2));
  }
 }
}
