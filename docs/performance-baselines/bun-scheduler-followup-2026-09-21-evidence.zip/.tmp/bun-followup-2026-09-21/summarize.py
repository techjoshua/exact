import json
from pathlib import Path
root=Path(__file__).parent
rows=[]
for path in sorted(root.glob('*.json')):
 d=json.loads(path.read_text())
 if not isinstance(d,dict) or d.get('kind')!='multi-driver-preloaded-ssr' or not d.get('complete'):continue
 for b in d['blocks']:
  stages={}
  for result in b['results']:
   for s in result['stages']:
    if not s.get('discard'):stages.setdefault(s['name'],[]).append(s)
  for name,ss in stages.items():
   rows.append(dict(capture=path.stem,runtime=d['runtimeId'],mode=d['renderMode'],framework=b['id'],stage=name,validRps=sum(s['validRps'] for s in ss),p99=[s['distributions']['responseMs']['p99'] for s in ss],capacityMisses=sum(s['missedCapacity'] for s in ss),errors=sum(s['errors'] for s in ss),invalid=sum(s['invalid'] for s in ss)))
root.joinpath('capture-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:
 print(row['capture'],row['framework'],row['stage'],round(row['validRps']),row['p99'])
