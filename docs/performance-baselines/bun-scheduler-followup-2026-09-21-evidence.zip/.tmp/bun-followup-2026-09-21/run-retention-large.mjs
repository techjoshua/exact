import {spawn,spawnSync} from 'node:child_process';
import {openSync,closeSync,writeFileSync,readFileSync} from 'node:fs';
const dir='.tmp/bun-followup-2026-09-21',variants='.tmp/bun-stream-codec-2026-09-21';
const previous=JSON.parse(readFileSync(dir+'/retention-execution.json'));
if(previous.length!==8||!previous.every(s=>s.code===0))throw Error('Traces still active');
const cases=[
 ['node-retention-96-row-string','node-retained-headroom-96-row-matrix','matrix-preloaded','string','node'],
 ['node-control-96-row-string','node-actual-96-row-matrix','matrix-preloaded','string','node'],
 ['bun-control-96-row-string','actual-host-large-matrix','matrix-preloaded','string','bun'],
 ['bun-retention-96-row-string','retained-headroom-large-matrix','matrix-preloaded','string','bun']
];

const journal=[];
for(const [name,runner,plan,mode,runtime='bun'] of cases){
 const args=[`${variants}/${runner}.mjs`,`${variants}/${plan}.json`,`${dir}/${name}.json`,runtime];
 const step={name,args,mode,startedAt:new Date().toISOString()};journal.push(step);
 const save=()=>writeFileSync(dir+'/retention-large-execution.json',JSON.stringify(journal,null,2));save();console.log('START',name);
 const fd=openSync(dir+'/'+name+'.log','w');
 try{await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{env:{...process.env,COMPARISON_SSR_RENDER_MODE:mode},stdio:['ignore',fd,fd]});step.pid=child.pid;save();child.once('error',fail);child.once('exit',code=>{step.code=code;code===0?done():fail(Error(name+' '+code));});});}
 finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}console.log('DONE',name);
}
