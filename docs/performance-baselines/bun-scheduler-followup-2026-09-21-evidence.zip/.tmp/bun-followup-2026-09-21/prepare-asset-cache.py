from pathlib import Path
p=Path('.tmp/bun-stream-codec-2026-09-21');out=Path('.tmp/bun-followup-2026-09-21')
for suffix in ['', '-node']:
 s=(p/f'actual-host{suffix}-entry.js').read_text();a=s.index('function scriptSources(tags = "") {');b=s.index('//#endregion',a)
 old=s[a:b];assert 'function stylesheetSources' in old
 # Reuse the original extraction expressions, with one bounded immutable-string-keyed entry.
 script=old.split('return ',1)[1].split(';',1)[0]
 style=old.split('function stylesheetSources',1)[1].split('return ',1)[1].split(';',1)[0]
 new=f'''let parsedDocumentAssets;
function documentAssets(tags = "") {{
 if(parsedDocumentAssets?.tags === tags) return parsedDocumentAssets;
 return parsedDocumentAssets = {{tags, scripts: {script}, stylesheets: {style}}};
}}
function scriptSources(tags = "") {{ return documentAssets(tags).scripts; }}
function stylesheetSources(tags = "") {{ return documentAssets(tags).stylesheets; }}
'''
 (p/f'asset-cache{suffix}-entry.js').write_text(s[:a]+new+s[b:])
for kind in ['matrix','reverse-matrix','large-matrix']:
 s=(p/f'actual-host-{kind}.mjs').read_text().replace("/actual-host'+", "/asset-cache'+")
 (p/f'asset-cache-{kind}.mjs').write_text(s)
s=(out/'render-isolation.mjs').read_text()
s=s.replace("['retention-execution.json','short-controls-execution.json']", "['cpu-observer-guard-execution.json']")
s=s.replace("['current','actual-host','direct']", "['actual-host','asset-cache']")
s=s.replace("['direct','actual-host','current']", "['asset-cache','actual-host']")
s=s.replace("render('current',true)", "render('actual-host',true)").replace('render-isolation.json','asset-isolation.json')
(out/'asset-isolation.mjs').write_text(s)
s=(out/'run-cpu-observer-guards.mjs').read_text().replace("dir+'/transport-diagnostic-execution.json'", "dir+'/cpu-observer-guard-execution.json'").replace('previous.length!==3','previous.length!==4').replace("dir+'/cpu-observer-guard-execution.json',JSON.stringify", "dir+'/asset-cache-execution.json',JSON.stringify")
a=s.index('const cases=');b=s.index('\n\nconst journal',a)
s=s[:a]+'''const isolated=spawnSync(process.execPath,[dir+'/asset-isolation.mjs'],{env:{...process.env,NODE_ENV:'production'},stdio:'inherit'});if(isolated.status!==0)throw Error('Asset isolation failed');
const cases=[
 ['node-asset-cache-stream','asset-cache-matrix','matched-plan','stream','node'],
 ['node-asset-cache-control-stream','actual-host-matrix','matched-plan','stream','node'],
 ['bun-asset-cache-control-stream','actual-host-matrix','matched-plan','stream','bun'],
 ['bun-asset-cache-stream','asset-cache-matrix','matched-plan','stream','bun']
];'''+s[b:];(out/'run-asset-cache.mjs').write_text(s)
