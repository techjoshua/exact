import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const fixture=JSON.parse(await readFile('framework-comparison/fixtures/baseline.json'));
const data={sessionUserId:fixture.sessionUserId,users:fixture.users,incidents:fixture.incidents};
const suffix=typeof Bun==='object'?'':'-node';
const original=await import(`../bun-stream-codec-2026-09-21/actual-host${suffix}-entry.js`);
const candidate=await import(`../bun-stream-codec-2026-09-21/asset-cache${suffix}-entry.js`);
const tags=[undefined,'','<script type="module" src="/a.js"></script><link rel="stylesheet" href="/a.css">','<link href="/b.css"><script src="/b.js"></script><script src="/a.js"></script>','<script src="/a.js"></script><script src="/a.js"></script>','',undefined];
let checks=0;
for(const clientTags of tags)for(const mode of ['string','stream']){
 const render=async entry=>{
  if(typeof Bun==='object')return (await entry.renderParticipantBunResponse(data,'/incidents/inc-101',undefined,{clientTags},mode)).text();
  if(mode==='string')return await entry.renderParticipant(data,'/incidents/inc-101',{clientTags});
  const chunks=[];
  for await(const chunk of entry.renderParticipantStream(data,'/incidents/inc-101',{clientTags}))chunks.push(chunk);
  return Buffer.concat(chunks).toString();
 };
 const expected=await render(original);
 assert.equal(await render(candidate),expected);
 assert.equal(await render(candidate),expected);
 checks+=2;
}
console.log(JSON.stringify({runtime:typeof Bun==='object'?Bun.version:process.version,checks}));
