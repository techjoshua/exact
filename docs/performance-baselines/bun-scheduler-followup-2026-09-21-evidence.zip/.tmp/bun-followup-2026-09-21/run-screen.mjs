import {spawn,spawnSync} from 'node:child_process';
import {openSync,closeSync,writeFileSync,readFileSync} from 'node:fs';
const dir='.tmp/bun-followup-2026-09-21',variants='.tmp/bun-stream-codec-2026-09-21';
const full=JSON.parse(readFileSync('.tmp/bun-stream-counting-final-2026-09-21/execution.json'));
if(full.length!==27||!full.every(s=>s.code===0))throw Error('Full measurement must finish before focused work resumes');
const proof=spawnSync('bun',[variants+'/check-pending-string.mjs'],{encoding:'utf8'});
writeFileSync(dir+'/pending-string-equivalence.log',(proof.stdout??'')+(proof.stderr??''));
if(proof.status!==0)throw Error('Pending-string equivalence failed: '+(proof.error??proof.status));
writeFileSync(dir+'/preflight.json',JSON.stringify({checkedAt:new Date().toISOString(),equivalenceExitCode:proof.status},null,2));
const cases=[
 ['string-10000-actual','actual-host-demand','demand-10000','string'],
 ['string-10000-headroom-95','headroom-95-demand','demand-10000','string'],
 ['stream-matrix-original','current-matrix','matched-plan','stream'],
 ['stream-matrix-actual','actual-host-matrix','matched-plan','stream'],
 ['stream-matrix-pending-string','pending-string-matrix','matched-plan','stream'],
 ['node-stream-matrix-original','current-matrix','matched-plan','stream','node'],
 ['node-stream-matrix-actual','actual-host-matrix','matched-plan','stream','node'],
 ['node-string-10000-actual','node-actual-demand','demand-10000','string','node'],
 ['node-string-10000-headroom-95','node-headroom-95-demand','demand-10000','string','node']
];
const journal=[];
for(const [name,runner,plan,mode,runtime='bun'] of cases){
 const args=[`${variants}/${runner}.mjs`,`${variants}/${plan}.json`,`${dir}/${name}.json`,runtime];
 const step={name,args,mode,startedAt:new Date().toISOString()};journal.push(step);
 const save=()=>writeFileSync(dir+'/screen-execution.json',JSON.stringify(journal,null,2));save();console.log('START',name);
 const fd=openSync(dir+'/'+name+'.log','w');
 try{await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{env:{...process.env,COMPARISON_SSR_RENDER_MODE:mode},stdio:['ignore',fd,fd]});step.pid=child.pid;save();child.once('error',fail);child.once('exit',code=>{step.code=code;code===0?done():fail(Error(name+' '+code));});});}
 finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}console.log('DONE',name);
}
