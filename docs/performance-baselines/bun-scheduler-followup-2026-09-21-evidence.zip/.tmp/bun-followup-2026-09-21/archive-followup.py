import hashlib,json,zipfile
from pathlib import Path
root=Path.cwd();name='bun-scheduler-followup-2026-09-21'; dest=root/'docs/performance-baselines'; paths=[]
for folder in ['.tmp/bun-followup-2026-09-21','.tmp/bun-stream-codec-2026-09-21']:
 for p in sorted((root/folder).rglob('*')):
  if p.is_symlink():raise RuntimeError(f'Unexpected link: {p}')
  if p.is_file():paths.append(p)
paths += [dest/(name+'.md'),dest/(name+'.json')]
manifest=[]
with zipfile.ZipFile(dest/(name+'-evidence.zip'),'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for p in paths:
  data=p.read_bytes();rel=p.relative_to(root).as_posix();archive.writestr(rel,data);manifest.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 archive.writestr('manifest.json',json.dumps({'sourceRevision':'efe62245ce5c19a6751154247bc9226c363c7ccb','files':manifest},indent=2))
with zipfile.ZipFile(dest/(name+'-evidence.zip')) as archive:
 assert archive.testzip() is None
 for item in manifest:assert hashlib.sha256(archive.read(item['path'])).hexdigest()==item['sha256']
print(json.dumps({'files':len(paths),'bytes':(dest/(name+'-evidence.zip')).stat().st_size,'sha256':hashlib.sha256((dest/(name+'-evidence.zip')).read_bytes()).hexdigest()}))
