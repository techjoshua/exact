# Bun scheduler follow-up, September 21, 2026

These are focused experiments after the [full progressive-output capture](../../docs/performance-baselines/bun-stream-counting-final-2026-09-21.md). The production framework remains at revision `1663f74b37fe440c86da9082c934ba07938874b1` until a candidate passes the remaining guards. Private copies isolate each change. Measurements run serially in native Linux loopback namespaces with Node v26.9.0 and Bun 1.4.2. They do not replace the full comparison charts.

## Reference identities

The September 20 scheduled-demand Bun streaming reference at 10,000 offered RPS is 6,681 valid RPS, 33.11% missed arrivals, and 108.29–136.32 ms response p99. Bun string is 9,998 valid RPS and 23.42–24.42 ms p99. The 9,866 RPS / 1.34% misses / 72.26–77.82 ms row belongs to Node streaming. An earlier conversational summary mislabeled that row as Bun string; the published historical capture did not.

## Decisions before the final workload guards

- Higher CPU thresholds and retention-only relaxation were rejected. Node streaming regressed, and Bun string latency did not improve consistently.
- Constructor selection did not explain a Node renderer regression. Render-only diagnostics and CPU profiles do not establish that the current renderer is slower.
- Replacing Bun's fragment array with string concatenation did not improve the matched comparisons.
- A one-entry cache for document asset parsing improved isolated rendering and Bun closed-loop HTTP capacity. It lost under scheduled streaming demand: 6,552 valid RPS versus an unchanged control's 6,957. String results were essentially equal at 10,000 offered RPS. It is not adopted. This is fixture-owned preparation, and a fair application change would require equivalent preparation for React.
- Shorter Bun control probes remain a candidate. They preserve the original CPU thresholds and scheduler queue, remove the unmeasured interval after a scheduled trial, and require one completed high-lag control window during reassessment of a previously selected policy. All 24 existing controller tests pass unchanged against the candidate.

The first Bun string pair reduced p99 from 39.2–39.6 ms to 24.6–24.8 ms. A fresh pair reduced it from 33.0–33.3 ms to 23.6–23.7 ms, with both versions delivering essentially 10,000 RPS. A streaming pair yielded 7,236 versus 7,163 valid RPS, a 1.0% difference, with mixed response tails. Those streaming results alone do not demonstrate a repeatable gain.

## Measurement overhead

Node CPU profiles attributed approximately 6–7% of sampled time to `process.cpuUsage`. The benchmark calls it twice per request in addition to periodic process telemetry. A private candidate removed only per-request CPU collection and retained response timings, errors, and periodic CPU measurements. Node closed-loop streaming ratios improved approximately 0.4–4.3%, and Bun string scheduled demand improved from 9,970 to 9,995 valid RPS with p99 falling from about 55 to 40 ms. This is measurement overhead, not a framework optimization. No production measurement protocol has changed.

## Interpretation and limits

Fresh unchanged Bun streaming controls reached 6,957 and 7,163 valid RPS, compared with the historical 6,681 reference. This variation means a single run crossing the reference is not proof that a candidate recovered performance. The full capture remains the published baseline, including unfavorable results.

The diagnostic socket counter observed approximately one native write operation per eXact Node preloaded streaming response. That case did not support a redundant-write optimization. Render-only experiments exclude HTTP and scheduler costs and must not be presented as request-capacity measurements.

Two captures named `node-threshold-large-string-*` used the ordinary Node fixture. They are not large-page guards. One unchanged Bun instrumentation control recorded two warmup ECONNRESET errors; those are retained in its capture. The newly added asset and short-probe scheduled-demand pairs reported zero request errors and zero invalid responses.

The Bun streaming concurrency sweep improved eXact/React ratios by 3.8%, 4.9%, and 4.2% at concurrency 16, 32, and 64, respectively, but fell 3.2% at concurrency 128. This leaves a performance regression concern despite the string tail-latency benefit. No production scheduler change is accepted on these results.
