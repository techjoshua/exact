from pathlib import Path
p=Path('.tmp/bun-stream-codec-2026-09-21');out=Path('.tmp/bun-followup-2026-09-21')
base=(p/'current-worker.mjs').read_text()
s=base.replace('function measureNodeRequest(response) {', '''const socketWriteCounts = { write: 0, writev: 0 };
const observedSockets = new WeakSet();
function measureNodeRequest(response) {
 const socket=response.socket;
 if(socket&&!observedSockets.has(socket)){
  observedSockets.add(socket);
  for(const name of ['write','writev']){
   const original=socket['_'+name];
   if(typeof original==='function')socket['_'+name]=function(...args){socketWriteCounts[name]++;return original.apply(this,args);};
  }
 }
''')
s=s.replace('function resetTelemetry() {','function resetTelemetry() {\n socketWriteCounts.write=socketWriteCounts.writev=0;')
s=s.replace('function telemetry() {\n\treturn {','function telemetry() {\n\treturn {\n socketWriteCounts: {...socketWriteCounts},')
(p/'socket-count-worker.mjs').write_text(s)
s=base;a=s.index('function measureNodeRequest(response) {');b=s.index('/** Measures a Node participant',a);part=s[a:b]
for line in ['\tconst cpuStarted = process.cpuUsage();\n','\t\tconst cpu = process.cpuUsage(cpuStarted);\n','\t\tstatistics.userCpuMs.push(cpu.user / 1_000);\n','\t\tstatistics.systemCpuMs.push(cpu.system / 1_000);\n']:
 assert line in part;part=part.replace(line,'')
s=s[:a]+part+s[b:]
s=s.replace('function telemetry() {\n\treturn {','function telemetry() {\n\treturn {\n requestCpuMeasurement: false,')
(p/'no-request-cpu-worker.mjs').write_text(s)
for variant in ['socket-count','no-request-cpu']:
 s=(p/'actual-host-matrix.mjs').read_text().replace('current-worker.mjs',variant+'-worker.mjs')
 s=s.replace("const prior={artifacts",f"artifacts.experimentalWorker={{path:'.tmp/bun-stream-codec-2026-09-21/{variant}-worker.mjs',sha256:createHash('sha256').update(await readFile('.tmp/bun-stream-codec-2026-09-21/{variant}-worker.mjs')).digest('hex')}};\nconst prior={{artifacts")
 (p/f'{variant}-matrix.mjs').write_text(s)
s=(out/'run-short-controls-repeat.mjs').read_text().replace("dir+'/short-controls-repeat-execution.json',JSON.stringify", "dir+'/transport-diagnostic-execution.json',JSON.stringify")
a=s.index('const cases=');b=s.index('\n\nconst journal',a)
s=s[:a]+'''const cases=[
 ['node-socket-count-stream','socket-count-matrix','socket-count-plan','stream','node'],
 ['node-cpu-instrumented-stream','actual-host-matrix','matched-plan','stream','node'],
 ['node-no-request-cpu-stream','no-request-cpu-matrix','matched-plan','stream','node']
];'''+s[b:];(out/'run-transport-diagnostics.mjs').write_text(s)
(p/'socket-count-plan.json').write_text((out/'node-profile-plan.json').read_text())
