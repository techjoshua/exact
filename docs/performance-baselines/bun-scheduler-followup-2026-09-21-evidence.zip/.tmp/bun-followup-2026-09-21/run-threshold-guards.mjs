import {spawn,spawnSync} from 'node:child_process';
import {openSync,closeSync,writeFileSync,readFileSync} from 'node:fs';
const dir='.tmp/bun-followup-2026-09-21',variants='.tmp/bun-stream-codec-2026-09-21';
const previous=JSON.parse(readFileSync(dir+'/node-repeat-execution.json'));
if(previous.length!==4||!previous.every(s=>s.code===0))throw Error('Traces still active');
const cases=[
 ['node-direct-constructor-stream','direct-node-matrix','matched-plan','stream','node'],
 ['node-alias-constructor-stream','actual-host-matrix','matched-plan','stream','node'],
 ['repeat-bun-string-10000-headroom-95','headroom-95-demand','demand-10000','string','bun'],
 ['repeat-bun-string-10000-actual','actual-host-demand','demand-10000','string','bun'],
 ['node-threshold-stream-actual','actual-host-matrix','matched-plan','stream','node'],
 ['node-threshold-stream-95','node-headroom-95-matrix','matched-plan','stream','node'],
 ['node-threshold-large-string-95','node-headroom-95-large-matrix','matrix-preloaded','string','node'],
 ['node-threshold-large-string-actual','actual-host-large-matrix','matrix-preloaded','string','node']
];

const journal=[];
for(const [name,runner,plan,mode,runtime='bun'] of cases){
 const args=[`${variants}/${runner}.mjs`,`${variants}/${plan}.json`,`${dir}/${name}.json`,runtime];
 const step={name,args,mode,startedAt:new Date().toISOString()};journal.push(step);
 const save=()=>writeFileSync(dir+'/threshold-guard-execution.json',JSON.stringify(journal,null,2));save();console.log('START',name);
 const fd=openSync(dir+'/'+name+'.log','w');
 try{await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{env:{...process.env,COMPARISON_SSR_RENDER_MODE:mode},stdio:['ignore',fd,fd]});step.pid=child.pid;save();child.once('error',fail);child.once('exit',code=>{step.code=code;code===0?done():fail(Error(name+' '+code));});});}
 finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}console.log('DONE',name);
}
