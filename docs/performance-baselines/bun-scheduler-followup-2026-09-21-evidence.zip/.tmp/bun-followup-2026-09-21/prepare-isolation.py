from pathlib import Path
import json
p=Path('.tmp/bun-stream-codec-2026-09-21');out=Path('.tmp/bun-followup-2026-09-21')
plan={'preloaded':True,'drivers':2,'stages':[{'name':'warmup','mode':'concurrency','concurrency':16,'durationMs':10000,'discard':True},{'name':'total-c32','mode':'concurrency','concurrency':16,'durationMs':20000}]}
(out/'node-profile-plan.json').write_text(json.dumps(plan))
for variant in ['current','actual-host']:
 s=(p/'node-actual-demand.mjs').read_text().replace('/actual-host-node-entry.js',f'/{variant}-node-entry.js')
 old='const runtime=availableSsrRuntimes(runtimeId)[0];';assert old in s
 s=s.replace(old,old+f"runtime.arguments.push('--cpu-prof','--cpu-prof-interval=500','--cpu-prof-dir=/home/techj/projects/exact/.tmp/bun-followup-2026-09-21','--cpu-prof-name=node-stream-{variant}.cpuprofile');")
 (out/f'node-profile-{variant}.mjs').write_text(s)
p=out/'render-isolation.mjs';s=p.read_text().replace("['threshold-guard-execution.json','bun-threshold-guard-execution.json']", "['retention-execution.json','short-controls-execution.json']");p.write_text(s)
s=(out/'run-short-controls.mjs').read_text().replace("dir+'/retention-execution.json'", "dir+'/short-controls-execution.json'").replace('previous.length!==8','previous.length!==6').replace("dir+'/short-controls-execution.json',JSON.stringify", "dir+'/isolation-execution.json',JSON.stringify")
a=s.index('const cases=');b=s.index('\n\nconst journal',a)
s=s[:a]+'''const cases=[
 ['node-profile-current','node-profile-current','node-profile-plan','stream','node'],
 ['node-profile-actual-host','node-profile-actual-host','node-profile-plan','stream','node']
];'''+s[b:]
s=s.replace('`${variants}/${runner}.mjs`,`${variants}/${plan}.json`','`${dir}/${runner}.mjs`,`${dir}/${plan}.json`')
s+="\nconst render=spawnSync(process.execPath,[dir+'/render-isolation.mjs'],{env:{...process.env,NODE_ENV:'production'},stdio:'inherit'});if(render.status!==0)throw Error('Render isolation failed');\n"
(out/'run-isolation.mjs').write_text(s)
