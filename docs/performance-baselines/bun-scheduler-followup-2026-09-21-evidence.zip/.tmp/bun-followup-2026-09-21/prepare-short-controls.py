from pathlib import Path
from shutil import copytree
p=Path('.tmp/bun-stream-codec-2026-09-21')
for runtime in ['node','bun']:
 target=p/(runtime+'-short-controls');copytree(Path('framework-adapters')/(runtime+'-adapter')/'dist',target,dirs_exist_ok=True)
 file=target/('requests/adaptive-gate.js' if runtime=='node' else 'adaptive-gate.js');s=file.read_text()
 a=s.index("if (this.phase === 'trial') {");b=s.index("if (this.phase === 'after')",a);part=s[a:b]
 assert "this.phase = 'settle';" in part
 part=part.replace("this.phase = 'settle';", "this.phase = 'after';").replace("            this.nextPhase = 'after';\n",'').replace("            this.until = now + 250;\n",'')
 s=s[:a]+part+s[b:]
 a=s.index('restartBaseline(now) {');part=s[a:];assert part.count('this.highSamples = 0;')==1
 s=s[:a]+part.replace('this.highSamples = 0;','this.highSamples = 1;');file.write_text(s)
s=(p/'current-worker.mjs').read_text().replace("from '@exactjs/node-adapter'", "from './node-short-controls/index.js'").replace("from './current/index.js'", "from './bun-short-controls/index.js'");(p/'short-controls-worker.mjs').write_text(s)
for kind in ['matrix','reverse-matrix']:
 s=(p/f'actual-host-{kind}.mjs').read_text().replace('current-worker.mjs','short-controls-worker.mjs')
 s=s.replace('const prior={artifacts',"artifacts.shortControlsAdapter=await measureSsrArtifact(resolve('.tmp/bun-stream-codec-2026-09-21/'+runtimeId+'-short-controls'));\nconst prior={artifacts")
 (p/f'short-controls-{kind}.mjs').write_text(s)
for runtime in ['node','bun']:
 source='node-actual-demand.mjs' if runtime=='node' else 'actual-host-demand.mjs'
 s=(p/source).read_text().replace('current-worker.mjs','short-controls-worker.mjs')
 s=s.replace('const prior={artifacts',"artifacts.shortControlsAdapter=await measureSsrArtifact(resolve('.tmp/bun-stream-codec-2026-09-21/'+runtimeId+'-short-controls'));\nconst prior={artifacts")
 (p/f'{runtime}-short-controls-demand.mjs').write_text(s)
p=Path('.tmp/bun-followup-2026-09-21');s=(p/'run-retention-large.mjs').read_text().replace("dir+'/retention-large-execution.json',JSON.stringify", "dir+'/short-controls-execution.json',JSON.stringify")
a=s.index('const cases=');b=s.index('\n\nconst journal',a)
s=s[:a]+'''const cases=[
 ['node-short-controls-string-10000','node-short-controls-demand','demand-10000','string','node'],
 ['node-short-controls-reference-string-10000','node-actual-demand','demand-10000','string','node'],
 ['node-short-controls-reference-stream','actual-host-matrix','matched-plan','stream','node'],
 ['node-short-controls-stream','short-controls-matrix','matched-plan','stream','node'],
 ['bun-short-controls-string-10000','bun-short-controls-demand','demand-10000','string','bun'],
 ['bun-short-controls-reference-string-10000','actual-host-demand','demand-10000','string','bun']
];'''+s[b:];(p/'run-short-controls.mjs').write_text(s)
