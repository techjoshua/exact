from pathlib import Path
from shutil import copytree
p=Path('.tmp/bun-stream-codec-2026-09-21')
for runtime in ['node','bun']:
 target=p/(runtime+'-retained-headroom');copytree(Path('framework-adapters')/(runtime+'-adapter')/'dist',target,dirs_exist_ok=True)
 file=target/('requests/adaptive-gate.js' if runtime=='node' else 'adaptive-gate.js');s=file.read_text()
 if runtime=='node':
  old='if (sample.lag < 3 && sample.utilization < 0.8) {'
  new='if (sample.lag < 3 && (sample.utilization < 0.8 || (sample.utilization < 0.95 && sample.rate > this.controlRate && sample.count >= sample.admissions * 0.99))) {'
 else:
  old='if (hasHeadroom(sample)) {'
  new='if (hasHeadroom(sample) || (sample.lag < 8 && sample.utilization > 0 && sample.utilization < 0.95 && sample.rate > this.controlRate && sample.count >= sample.arrivals * 0.99)) {'
 assert s.count(old)==1;(file).write_text(s.replace(old,new))
for suffix in ['', '-large']:
 s=(p/f'current{suffix}-worker.mjs').read_text()
 assert "from '@exactjs/node-adapter'" in s
 s=s.replace("from '@exactjs/node-adapter'","from './node-retained-headroom/index.js'").replace("from './current/index.js'","from './bun-retained-headroom/index.js'")
 assert "from './bun-retained-headroom/index.js'" in s
 (p/f'retained-headroom{suffix}-worker.mjs').write_text(s)
for kind in ['matrix','reverse-matrix','large-matrix']:
 s=(p/f'actual-host-{kind}.mjs').read_text();suffix='-large' if kind=='large-matrix' else ''
 s=s.replace(f'current{suffix}-worker.mjs',f'retained-headroom{suffix}-worker.mjs')
 s=s.replace("const prior={artifacts", "artifacts.retainedHeadroomAdapter=await measureSsrArtifact(resolve('.tmp/bun-stream-codec-2026-09-21/'+runtimeId+'-retained-headroom'));\nconst prior={artifacts")
 (p/f'retained-headroom-{kind}.mjs').write_text(s)
for runtime in ['node','bun']:
 template='node-actual-demand.mjs' if runtime=='node' else 'actual-host-demand.mjs'
 s=(p/template).read_text().replace('current-worker.mjs','retained-headroom-worker.mjs')
 s=s.replace("const prior={artifacts", "artifacts.retainedHeadroomAdapter=await measureSsrArtifact(resolve('.tmp/bun-stream-codec-2026-09-21/'+runtimeId+'-retained-headroom'));\nconst prior={artifacts")
 (p/f'{runtime}-retained-headroom-demand.mjs').write_text(s)
p=Path('.tmp/bun-followup-2026-09-21');s=(p/'run-bun-threshold-guards.mjs').read_text().replace("dir+'/bun-threshold-guard-execution.json',JSON.stringify", "dir+'/retention-execution.json',JSON.stringify")
a=s.index('const cases=');b=s.index('\n\nconst journal',a)
s=s[:a]+'''const cases=[
 ['node-retention-string-10000','node-retained-headroom-demand','demand-10000','string','node'],
 ['node-retention-control-string-10000','node-actual-demand','demand-10000','string','node'],
 ['node-retention-control-stream','actual-host-matrix','matched-plan','stream','node'],
 ['node-retention-stream','retained-headroom-matrix','matched-plan','stream','node'],
 ['bun-retention-string-10000','bun-retained-headroom-demand','demand-10000','string','bun'],
 ['bun-retention-control-string-10000','actual-host-demand','demand-10000','string','bun'],
 ['bun-retention-control-stream-8000','actual-host-demand','demand-8000','stream','bun'],
 ['bun-retention-stream-8000','bun-retained-headroom-demand','demand-8000','stream','bun']
];'''+s[b:];(p/'run-retention.mjs').write_text(s)
