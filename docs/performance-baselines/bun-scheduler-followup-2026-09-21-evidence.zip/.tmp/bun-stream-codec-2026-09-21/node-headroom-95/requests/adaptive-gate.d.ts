/**
 * Node-owned admission controller. Lag triggers a trial; completed-response capacity and lag
 * relative to surrounding immediate windows decide whether to retain it. Demand-limited trials
 * can instead prove that they complete admitted work with low lag and event-loop headroom. Handler duration is
 * deliberately not treated as client latency because it excludes time before Node dispatch.
 * A selected policy stays active while lag is low and the event loop has spare capacity;
 * lower offered demand is not evidence that the policy lost completion capacity.
 * Sparse traffic creates no histogram or timer. Idle monitoring disables and releases its timer.
 */
export declare class AdaptiveRequestGate {
    private delay;
    private timer;
    private lastRequest;
    private recentRequests;
    private requests;
    private completions;
    private admissions;
    private unhealthySamples;
    private hadHeadroom;
    private epoch;
    private started;
    private enabled;
    private highSamples;
    private phase;
    private nextPhase;
    private until;
    private cooldown;
    private backoff;
    private baseline;
    private trial;
    private controlRate;
    private controlLag;
    private utilization;
    /** Begins one request; a returned epoch permits completion accounting for this window only. */
    observeRequest(): number | undefined;
    /** Records successful response completion only in the observation window that admitted it. */
    observeCompletion(epoch: number): void;
    /** Whether the current request should enter the bounded render-start queue. */
    shouldSchedule(): boolean;
    private resetWindow;
    /** Reassesses capacity with immediate controls on both sides of a scheduled trial. */
    private sample;
    private restartBaseline;
}
//# sourceMappingURL=adaptive-gate.d.ts.map