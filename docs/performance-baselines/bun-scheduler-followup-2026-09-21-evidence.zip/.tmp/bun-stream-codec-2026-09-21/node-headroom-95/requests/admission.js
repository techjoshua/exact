import { bindRequestRenderScheduler } from '@exactjs/server/framework/render-scheduling';
import { AdaptiveRequestGate } from './adaptive-gate.js';
import { createNodeRenderScheduler } from '../render-scheduler.js';
const admissionOwner = Symbol('exact.node.admission');
/**
 * Creates one host-owned admission policy. Completion listeners exist only while monitoring is
 * active and remove themselves on finish or cancellation. No response or rendering work is shared.
 */
export function createNodeRequestAdmission(options = {}) {
    const enqueue = createNodeRenderScheduler({ maxBatchSize: options.maxBatchSize });
    const gate = (options.adaptive ?? !('bun' in process.versions)) ? new AdaptiveRequestGate() : undefined;
    const checkpoint = (signal) => {
        signal?.throwIfAborted();
        return gate?.shouldSchedule() ? enqueue(signal) : undefined;
    };
    return (response, signal) => {
        if (signal.aborted)
            return Promise.reject(signal.reason);
        // An outer page host may dispatch to an eXact endpoint handler. Its request policy wins.
        const owned = response;
        const existing = owned[admissionOwner];
        if (existing !== undefined) {
            if (existing)
                bindRequestRenderScheduler(signal, existing);
            return;
        }
        owned[admissionOwner] = gate ? checkpoint : false;
        if (!gate)
            return;
        bindRequestRenderScheduler(signal, checkpoint);
        const epoch = gate.observeRequest();
        if (epoch !== undefined) {
            const completed = () => {
                response.off('finish', completed);
                response.off('close', completed);
                if (response.writableFinished)
                    gate.observeCompletion(epoch);
            };
            response.once('finish', completed);
            response.once('close', completed);
        }
        return gate.shouldSchedule() ? enqueue(signal) : undefined;
    };
}
//# sourceMappingURL=admission.js.map