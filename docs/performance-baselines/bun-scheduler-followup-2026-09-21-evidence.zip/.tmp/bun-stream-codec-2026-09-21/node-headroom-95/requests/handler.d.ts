import type { IncomingMessage, ServerResponse } from 'node:http';
import type { ExactServerContext } from '@exactjs/server';
import { type NodeSchedulingOptions } from './admission.js';
/** A Node page or application handler whose signal cancels when its client disconnects. */
export type NodeRequestHandler = (request: IncomingMessage, response: ServerResponse, signal: AbortSignal) => void | Promise<void>;
/** Configures host-owned admission and unexpected handler error reporting. */
export interface NodeHandlerOptions extends NodeSchedulingOptions {
    /** Receives unexpected failures; errors sent to clients remain generic. */
    logger?: ExactServerContext['logger'];
}
/**
 * Wraps a Node page/application handler with automatic adaptive admission before rendering starts.
 * Create once per host. Quiet requests begin synchronously; queued disconnects never run the handler.
 * Successful completion and cancellation release listeners. The callback owns its response and must
 * observe the supplied signal for pending tasks or streaming work. Synchronous and asynchronous
 * failures are reported and terminate the response without exposing implementation details.
 */
export declare function createNodeHandler(handler: NodeRequestHandler, options?: NodeHandlerOptions): (request: IncomingMessage, response: ServerResponse) => void;
//# sourceMappingURL=handler.d.ts.map