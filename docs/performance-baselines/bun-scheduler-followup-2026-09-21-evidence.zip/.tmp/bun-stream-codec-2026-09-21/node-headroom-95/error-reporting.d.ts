import type { ExactServerContext } from '@exactjs/server';
/** Reports server failures without letting a failing custom logger interrupt response cleanup. */
export declare function reportNodeError(error: unknown, phase: 'request' | 'response' | 'cleanup', logger?: ExactServerContext['logger']): void;
//# sourceMappingURL=error-reporting.d.ts.map