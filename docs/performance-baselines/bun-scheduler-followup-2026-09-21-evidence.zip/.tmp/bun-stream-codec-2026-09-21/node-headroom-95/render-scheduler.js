import { clearImmediate, setImmediate } from 'node:timers';
import * as timerPromises from 'node:timers/promises';
/**
 * Creates a host-owned scheduler for the SSR `scheduleRender` option. Share one
 * scheduler across requests to batch starts through scheduler.yield(), falling
 * back to setImmediate when that API is unavailable. Cancellation
 * rejects promptly and removes the queued continuation. Batches release at most
 * maxBatchSize starts; render work and response ownership remain with SSR. This low-level gate
 * always yields. Node request handlers apply automatic adaptive admission around it.
 */
export function createNodeRenderScheduler(options = {}) {
    const limit = options.maxBatchSize ?? 32;
    if (!Number.isSafeInteger(limit) || limit < 1)
        throw new RangeError('maxBatchSize must be a positive safe integer');
    let pending;
    const scheduler = timerPromises.scheduler;
    const yieldTask = typeof scheduler?.yield === 'function' ? () => scheduler.yield() : undefined;
    const enqueue = (signal) => new Promise((resolve, reject) => {
        if (signal?.aborted) {
            reject(signal.reason);
            return;
        }
        const first = !pending;
        const batch = pending ?? {
            starts: [],
            failures: [],
            active: 0,
            timer: undefined
        };
        if (first)
            pending = batch;
        const index = batch.starts.length;
        batch.active++;
        if (signal) {
            const abort = () => {
                batch.starts[index] = undefined;
                batch.failures[index] = undefined;
                signal.removeEventListener('abort', abort);
                if (--batch.active === 0) {
                    if (batch.timer !== undefined)
                        clearImmediate(batch.timer);
                    batch.timer = undefined;
                    batch.starts = [];
                    batch.failures = [];
                    if (pending === batch)
                        pending = undefined;
                }
                reject(signal.reason);
            };
            batch.starts.push(() => {
                signal.removeEventListener('abort', abort);
                resolve();
            });
            batch.failures.push((reason) => {
                signal.removeEventListener('abort', abort);
                reject(reason);
            });
            signal.addEventListener('abort', abort, { once: true });
        }
        else {
            batch.starts.push(resolve);
            batch.failures.push(reject);
        }
        if (batch.starts.length === limit)
            pending = undefined;
        if (first) {
            const release = () => {
                if (pending === batch)
                    pending = undefined;
                batch.timer = undefined;
                for (const start of batch.starts)
                    start?.();
                batch.starts = [];
                batch.failures = [];
            };
            const fail = (reason) => {
                if (pending === batch)
                    pending = undefined;
                for (const rejectStart of batch.failures)
                    rejectStart?.(reason);
                batch.starts = [];
                batch.failures = [];
            };
            try {
                if (yieldTask)
                    void yieldTask().then(release, fail);
                else
                    batch.timer = setImmediate(release);
            }
            catch (reason) {
                fail(reason);
            }
        }
    });
    return enqueue;
}
//# sourceMappingURL=render-scheduler.js.map