/** Limits how many render starts one event-loop callback releases. */
export interface NodeRenderSchedulerOptions {
    /** Maximum starts per batch. Defaults to 32; must be a positive safe integer. */
    maxBatchSize?: number;
}
/**
 * Creates a host-owned scheduler for the SSR `scheduleRender` option. Share one
 * scheduler across requests to batch starts through scheduler.yield(), falling
 * back to setImmediate when that API is unavailable. Cancellation
 * rejects promptly and removes the queued continuation. Batches release at most
 * maxBatchSize starts; render work and response ownership remain with SSR. This low-level gate
 * always yields. Node request handlers apply automatic adaptive admission around it.
 */
export declare function createNodeRenderScheduler(options?: NodeRenderSchedulerOptions): (signal?: AbortSignal) => Promise<void>;
//# sourceMappingURL=render-scheduler.d.ts.map