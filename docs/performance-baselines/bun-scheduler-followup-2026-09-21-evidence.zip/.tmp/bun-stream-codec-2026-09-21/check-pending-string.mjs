import assert from 'node:assert/strict';
import {TestSink as Current} from './current-sink-test-entry.js';
import {TestSink as Candidate} from './pending-string-sink-test-entry.js';
const head='<!doctype html><html><head><title>Ready</title></head>';
const tail='</body></html>';
const encoder=new TextEncoder();
async function run(Sink,spans,max,size,flush,hints){
 const chunks=[];let aborted=0,index=-1;
 const destination={head(html){chunks.push(['head',html]);},body(html){chunks.push(['body',html]);if(chunks.length%3===0)return Promise.resolve();},abort(){aborted++;}};
 const sink=new Sink(max,destination,size);
 try{
  sink.write(head);await sink.flush('head');
  for(index=0;index<spans.length;index++){sink.write(spans[index]);await sink.ready();if(flush&&index%7===0)await sink.flush('await');}
  const result=await sink.finish(hints);return {chunks,result,aborted};
 }catch(error){assert.throws(()=>sink.write('later'),/closed/);return {chunks,error:error.message,index,aborted};}
}
let count=0;
for(let seed=1;seed<=16;seed++){
 let state=seed;const random=()=>{state=(state*1664525+1013904223)>>>0;return state;};
 const body='<body>'+('abc日🚀é\ud800x\udc00'.repeat(10+seed))+tail;const spans=[];
 for(let i=0;i<body.length;){const length=1+random()%9;spans.push(body.slice(i,i+length));i+=length;}
 const bytes=encoder.encode(head+body).length;
 for(const size of [1,7,32,8192])for(const extra of [-5,-1,0,1,50])for(const flush of [false,true]){
  const hints=seed%2?[]:['<!--日-->'];
  assert.deepEqual(await run(Candidate,spans,bytes+extra,size,flush,hints),await run(Current,spans,bytes+extra,size,flush,hints),JSON.stringify({seed,size,extra,flush}));count++;
 }
}
console.log(`${count} baseline-equivalence cases passed: exact limits, split surrogates, flush thresholds, hints, pressure and cleanup.`);
