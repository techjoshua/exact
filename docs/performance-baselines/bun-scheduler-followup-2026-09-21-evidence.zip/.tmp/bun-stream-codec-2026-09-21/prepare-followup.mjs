import {readFileSync,writeFileSync,copyFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const dir=import.meta.dirname;
for(const runtime of ['bun','node']){
 const suffix=runtime==='node'?'-node':'';
 const path=`framework-comparison/participants/exact/${runtime==='bun'?'dist-bun-server/bun-server-entry.js':'dist-server/server-entry.js'}`;
 copyFileSync(path,`${dir}/actual-host${suffix}-entry.js`);
 let source=readFileSync(path,'utf8');
 const start=source.indexOf('var FragmentDocumentStreamSink = class extends DocumentStreamSink {');
 assert.ok(start>=0);const end=source.indexOf('//#endregion',start);assert.ok(end>start);
 let body=source.slice(start,end);
 body=body.replace('unmeasured = [];','unmeasured = "";').replace(/\n\s*unmeasuredCharacters = 0;/,'');
 body=body.replace('this.unmeasured.push(html);','this.unmeasured += html;').replace(/\n\s*this\.unmeasuredCharacters \+= html\.length;/,'');
 body=body.replaceAll('this.unmeasured.length = 0;','this.unmeasured = "";').replaceAll(/\n\s*this\.unmeasuredCharacters = 0;/g,'');
 body=body.replace(/const html = this\.unmeasured\.length === 1 \? this\.unmeasured\[0\] : this\.unmeasured\.join\(""\);/,'const html = this.unmeasured;');
 body=body.replaceAll('this.unmeasuredCharacters','this.unmeasured.length');
 assert.ok(!body.includes('.join(')&&!body.includes('.push(')&&!body.includes('unmeasuredCharacters'));
 writeFileSync(`${dir}/pending-string${suffix}-entry.js`,source.slice(0,start)+body+source.slice(end));
}
for(const variant of ['actual-host','pending-string'])for(const kind of ['demand','matrix','reverse-matrix','large-matrix']){
 const template=readFileSync(`${dir}/current-${kind}.mjs`,'utf8');
 writeFileSync(`${dir}/${variant}-${kind}.mjs`,template.replaceAll('/current-entry.js',`/${variant}-entry.js`).replaceAll("/current'+",`/${variant}'+`));
}
console.log('Prepared private follow-up controls and pending-string candidate. Nothing measured or adopted.');
