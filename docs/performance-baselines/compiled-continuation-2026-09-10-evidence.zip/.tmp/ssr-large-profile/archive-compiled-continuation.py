from pathlib import Path
import hashlib, json, zipfile

root = Path.cwd()
base = root / '.tmp/ssr-large-profile'
report = root / 'docs/performance-baselines/compiled-continuation-2026-09-10.md'
files = {report, Path(__file__).resolve(), base / 'compiled-continuation-trace.mjs',
         base / 'compiled-continuation-trace.log', base / 'conditional-emission/server-entry.js',
         root / '.tmp/positional-leaves/data.json'}
files.update(f for f in (base / 'compiled-continuation-trace').iterdir() if f.is_file())
for name in ('jsx_render_program_ssr_continuation.go', 'jsx_render_program_ssr_frame.go'):
    files.add(root / 'native/typescript-go/overlay/internal/exactcompiler' / name)
for mode, expected in [('string', 0), ('stream', 0), ('stream-pressure', 1)]:
    trace = json.loads((base / 'compiled-continuation-trace' / (mode + '.trace.json')).read_text())
    assert sum(e.get('name') == 'compiled continuation snapshot' for e in trace['traceEvents']) == expected
archive = report.with_name('compiled-continuation-2026-09-10-evidence.zip')
assert not archive.exists()
manifest = {f.relative_to(root).as_posix(): hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(files)}
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as output:
    for f in sorted(files): output.write(f, f.relative_to(root).as_posix())
    output.writestr('SHA256.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None
    for name, digest in manifest.items(): assert hashlib.sha256(output.read(name)).hexdigest() == digest
print('Verified', len(files), 'files')
