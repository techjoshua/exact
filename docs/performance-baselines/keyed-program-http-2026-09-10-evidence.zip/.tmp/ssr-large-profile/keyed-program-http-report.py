from pathlib import Path
from statistics import mean
import hashlib, json, zipfile
root = Path.cwd()
base = root / '.tmp/ssr-large-profile'
folder = base / 'keyed-program-http'
rows = json.loads((folder / 'http.json').read_text())
assert len(rows) == 72
summary = []
for runtime in ('node', 'bun'):
    for mode in ('string', 'stream'):
        group = [r for r in rows if r['runtime'] == runtime and r['mode'] == mode]
        exact = [r for r in group if r['variant'] != 'react']
        assert len({r['identity']['hash'] for r in exact}) == 1
        rates = {v: mean(r['rps'] for r in group if r['variant'] == v) for v in ('baseline', 'compiled', 'react')}
        wins = sum(next(r['rps'] for r in group if r['variant'] == 'compiled' and r['block'] == b) > next(r['rps'] for r in group if r['variant'] == 'baseline' and r['block'] == b) for b in range(6))
        summary.append(dict(runtime=runtime, mode=mode, rps=rates, improvedBlocks=wins,
                            candidateChangePercent=100*(rates['compiled']/rates['baseline']-1),
                            candidateVsReactPercent=100*(rates['compiled']/rates['react']-1)))
stages = [d['stages'][0] for r in rows for d in r['results']]
assert all(s['errors'] == 0 and s['completed'] == s['started'] == s['valid'] for s in stages)
for r in rows: assert hashlib.sha256(Path(r['entry']).read_bytes()).hexdigest() == r['artifactSha256']
result = dict(valid=sum(s['valid'] for s in stages), errors=sum(s['errors'] for s in stages), summary=summary)
(folder / 'summary.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
