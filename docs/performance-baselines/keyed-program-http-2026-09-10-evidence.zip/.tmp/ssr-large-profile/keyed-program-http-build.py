from pathlib import Path
p = Path('.tmp/ssr-large-profile')
s = (p / 'single-child-traversal-http.mjs').read_text()
s = s.replace('single-child-traversal/', 'keyed-program-http/')
s = s.replace("root+'keyed-program-http/'+", "root+'keyed-program/'+")
s = s.replace('Static shell HTTP diagnostic', 'Prepared keyed-program HTTP comparison')
a = s.index("if(variant==='compiled'){")
b = s.index('\n Object.assign', a)
s = s[:a] + "if(variant==='compiled')assert.equal(html,exactDocument);" + s[b:]
(p / 'keyed-program-http').mkdir(exist_ok=True)
(p / 'keyed-program-http.mjs').write_text(s)
