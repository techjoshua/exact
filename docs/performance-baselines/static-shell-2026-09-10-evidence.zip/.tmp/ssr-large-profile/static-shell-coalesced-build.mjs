import fs from 'node:fs/promises';import {resolve} from 'node:path';import {pathToFileURL} from 'node:url';import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'static-shell/coalesced',{recursive:true});
const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
const original=await import(pathToFileURL(resolve(root+'static-shell/server-entry.js')));
const data=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));
const sample=await original.renderParticipant(data,'/incidents/inc-101',options);
const head=sample.match(/<head\b[\s\S]*?<\/head>/)[0];assert.equal((head.match(/<script /g)||[]).length,2);
for(const name of ['server-entry.js','bun-server-entry.js']){
 let source=await fs.readFile(root+'static-shell/'+name,'utf8');
 const host=source.indexOf('ssrHost: "head"');assert.ok(host>0);
 const start=source.lastIndexOf('\tssr: ',host),end=source.lastIndexOf('\n\t},',host)+5;assert.ok(start>0&&end>start);
 const replacement='\tssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {\n'+
 '__exactSsr.begin(__exactContext,9,0,'+head.length+','+head.length+');\n'+
 '__exactOutput.sink.write('+JSON.stringify(head)+');\n'+
 'const ready=__exactOutput.sink.ready();return ready?ready.then(()=>__exactOutput):__exactOutput;\n\t},';
 source=source.slice(0,start)+replacement+source.slice(end);
 await fs.writeFile(root+'static-shell/coalesced/'+name,source);
}
const mod=await import(pathToFileURL(resolve(root+'static-shell/coalesced/server-entry.js')));
const checks=[];
for(const mode of ['string','stream'])for(let i=0;i<3;i++){
 data.incidents[1].title='Distinct '+i+' <safe>';
 const render=async m=>mode==='string'?m.renderParticipant(data,'/incidents/inc-101',options):new Response(m.renderParticipantStream(data,'/incidents/inc-101',options)).text();
 const expected=await render(original),actual=await render(mod);assert.equal(actual,expected);checks.push({mode,request:i,bytes:Buffer.byteLength(actual)});
}
await fs.writeFile(root+'static-shell/coalesced-verification.json',JSON.stringify(checks,null,2));
let runner=await fs.readFile(root+'static-shell-parse-http.mjs','utf8');
runner=runner.replace("'raw/':'parsed/'","'raw/':'coalesced/'").replace("root+'direct-execution-integrated/'","root+'static-shell/'").replace('parsed-http.json','coalesced-http.json');
await fs.writeFile(root+'static-shell-coalesced-http.mjs',runner);
console.log('Six byte-identical changing-request checks passed; static head diagnostic built.');
