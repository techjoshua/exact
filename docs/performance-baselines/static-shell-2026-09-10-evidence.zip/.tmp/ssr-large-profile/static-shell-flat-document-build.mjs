import fs from 'node:fs/promises';import {resolve} from 'node:path';import {pathToFileURL} from 'node:url';import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'static-shell/flat-document',{recursive:true});
const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
const original=await import(pathToFileURL(resolve(root+'static-shell/server-entry.js')));
const data=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));
const sample=await original.renderParticipant(data,'/incidents/inc-101',options);
const opening=sample.match(/^<!doctype html>(<html[^>]*>)/i)[1],head=sample.match(/<head\b[\s\S]*?<\/head>/)[0],body=sample.match(/<body[^>]*><div id="app"[^>]*>/)[0],suffix='</div></body></html>';
const staticLength=opening.length+head.length+body.length+suffix.length;
const program=`var auditFlatDocumentProgram=prepareCompiledRenderProgram({version:1,id:"audit-flat-document",namespace:"html",ssrHost:"html",ssr(s,c,i,o){
const props=i.eagerValues[0],child=s.reference(IncidentApp,{initialData:props.initialData,path:props.path});
if(o.prepareReferences)o.preparation=o.prepareReferences([child]);
s.begin(c,12,1,${staticLength},${staticLength});o.sink.write(${JSON.stringify(opening)});
const enteredHead=enterHostTag(c,"head");
return mapRenderValue(withRenderCleanup(()=>{o.sink.write(${JSON.stringify(head)});return mapRenderValue(o.sink.ready(),()=>o.sink.flush("head"));},()=>leaveHost(c,enteredHead.tag)),()=>{
const enteredBody=enterHostTag(c,"body");
return withRenderCleanup(()=>{o.sink.write(${JSON.stringify(body)});return mapRenderValue(o.sink.ready(),()=>mapRenderValue(s.component(c,o,child,"0",${staticLength},true),()=>{o.sink.write(${JSON.stringify(suffix)});return mapRenderValue(o.sink.ready(),()=>o);}));},()=>leaveHost(c,enteredBody.tag));});}});
`;
for(const name of ['server-entry.js','bun-server-entry.js']){
 let source=await fs.readFile(root+'static-shell/'+name,'utf8');
 const start=source.indexOf('var __exactImplementation_Document_1 = function Document(props) {'),end=source.indexOf('\nvar Document =',start);assert.ok(start>0&&end>start);
 source=source.slice(0,start)+program+'var __exactImplementation_Document_1 = function Document(props){return createPreparedServerRenderProgram(auditFlatDocumentProgram,[props]);};'+source.slice(end);
 await fs.writeFile(root+'static-shell/flat-document/'+name,source);
}
const mod=await import(pathToFileURL(resolve(root+'static-shell/flat-document/server-entry.js')));
const checks=[];
for(const mode of ['string','stream'])for(let i=0;i<3;i++){
 data.incidents[1].title='Distinct '+i+' <safe>';
 const render=async m=>mode==='string'?m.renderParticipant(data,'/incidents/inc-101',options):new Response(m.renderParticipantStream(data,'/incidents/inc-101',options)).text();
 const expected=await render(original),actual=await render(mod);assert.equal(actual,expected);checks.push({mode,request:i,bytes:Buffer.byteLength(actual)});
}
await fs.writeFile(root+'static-shell/flat-document-verification.json',JSON.stringify(checks,null,2));
let runner=await fs.readFile(root+'static-shell-coalesced-http.mjs','utf8');runner=runner.replace("'raw/':'coalesced/'","'raw/':'flat-document/'").replace('coalesced-http.json','flat-document-http.json');
await fs.writeFile(root+'static-shell-flat-document-http.mjs',runner);
console.log('Six byte-identical changing-request checks passed; one-program Document diagnostic built.');
