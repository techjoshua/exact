import fs from 'node:fs/promises';import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';let source=await fs.readFile(root+'consume-result-http.mjs','utf8');
source=source.replace(/const orders=\[[^;]+;/,"const orders=[['baseline','compiled','raw','react'],['react','raw','compiled','baseline'],['compiled','baseline','react','raw'],['raw','react','baseline','compiled']];");
source=source.replace("['candidate','baseline','react']","['baseline','compiled','raw','react']");
const anchor="const entry=resolve(variant==='baseline'?";assert.equal(source.split(anchor).length,2);
source=source.replace(anchor,"const entry=resolve(variant==='compiled'||variant==='raw'?root+'static-shell/'+(variant==='raw'?'raw/':'')+(runtime.id==='bun'?'bun-server-entry.js':'server-entry.js'):variant==='baseline'?");
const equality="if(id==='exact'){if(exactDocument!==undefined)assert.equal(html,exactDocument);else exactDocument=html;}";assert.ok(source.includes(equality));source=source.replace(equality,'');
source=source.replaceAll('consume-result-http.json','static-shell/http.json').replace('rows.length,72','rows.length,64').replace('Integrated result finalization HTTP comparison','Static shell HTTP diagnostic');
await fs.writeFile(root+'static-shell-http.mjs',source);console.log('Prepared 64 blocks across both runtimes and modes.');
