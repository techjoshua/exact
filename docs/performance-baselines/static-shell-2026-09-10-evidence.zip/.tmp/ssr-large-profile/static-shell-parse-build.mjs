import fs from 'node:fs/promises';import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'static-shell/parsed',{recursive:true});
for(const name of ['server-entry.js','bun-server-entry.js']){
 let source=await fs.readFile(root+'direct-execution-integrated/'+name,'utf8');
 for(const fn of ['scriptSources','stylesheetSources']){
  const start=source.indexOf('function '+fn+'('),end=source.indexOf('\n}',start)+2;assert.ok(start>=0&&end>start);
  const original=source.slice(start,end).replace('function '+fn+'(','function auditUncached_'+fn+'(');
  source=source.slice(0,start)+original+'\nlet auditLast_'+fn+',auditValues_'+fn+';\nfunction '+fn+'(tags=""){if(tags!==auditLast_'+fn+'||auditValues_'+fn+'===undefined){auditLast_'+fn+'=tags;auditValues_'+fn+'=auditUncached_'+fn+'(tags);}return auditValues_'+fn+';}'+source.slice(end);
 }
 await fs.writeFile(root+'static-shell/parsed/'+name,source);
}
let runner=await fs.readFile(root+'static-shell-http.mjs','utf8');
runner=runner.replace("['string','stream']","['string']").replaceAll("root+'static-shell/'","root+'static-shell/parsed/'");
runner=runner.replace("root+'static-shell/parsed/'+(variant==='raw'?'raw/':'')","root+'static-shell/'+(variant==='raw'?'raw/':'parsed/')");
runner=runner.replace("let exactDocument;","let exactDocument;");
runner=runner.replace("Object.assign(worker,{variant", "if(variant==='baseline')exactDocument=html;if(variant==='compiled')assert.equal(html,exactDocument);\n Object.assign(worker,{variant");
runner=runner.replace("root+'static-shell/http.json'","root+'static-shell/parsed-http.json'").replace('rows.length,64','rows.length,32');
await fs.writeFile(root+'static-shell-parse-http.mjs',runner);
