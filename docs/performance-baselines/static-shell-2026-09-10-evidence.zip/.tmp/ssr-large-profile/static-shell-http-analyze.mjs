import fs from 'node:fs/promises';import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/static-shell/';const rows=JSON.parse(await fs.readFile(root+'http.json','utf8'));assert.equal(rows.length,64);
const summary=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream']){
 const group=rows.filter(r=>r.runtime===runtime&&r.mode===mode);
 const variants=Object.fromEntries(['baseline','compiled','raw','react'].map(variant=>{const blocks=group.filter(r=>r.variant===variant);assert.equal(blocks.length,4);return [variant,{rps:blocks.reduce((sum,r)=>sum+r.rps,0)/4,bytes:blocks[0].identity.bytes}];}));
 const pairs=Array.from({length:4},(_,block)=>Object.fromEntries(group.filter(r=>r.block===block).map(r=>[r.variant,r.rps])));
 summary.push({runtime,mode,variants,compiledChangePercent:(variants.compiled.rps/variants.baseline.rps-1)*100,rawChangePercent:(variants.raw.rps/variants.baseline.rps-1)*100,rawReactGapPercent:(variants.raw.rps/variants.react.rps-1)*100,compiledImprovedBlocks:pairs.filter(p=>p.compiled>p.baseline).length,rawImprovedBlocks:pairs.filter(p=>p.raw>p.baseline).length,pairs});
}
const valid=rows.reduce((sum,r)=>sum+r.results.reduce((n,d)=>n+d.stages[0].valid,0),0),errors=rows.reduce((sum,r)=>sum+r.results.reduce((n,d)=>n+d.stages[0].errors,0),0);
await fs.writeFile(root+'summary.json',JSON.stringify({valid,errors,summary},null,2));console.log(JSON.stringify({valid,errors,summary:summary.map(({pairs,...r})=>r)},null,2));
