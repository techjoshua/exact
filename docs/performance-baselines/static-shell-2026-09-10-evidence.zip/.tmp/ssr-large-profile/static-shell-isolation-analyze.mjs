import fs from 'node:fs/promises';
const root='.tmp/ssr-large-profile/static-shell/';
for(const experiment of ['parsed','coalesced','flat-document']){
 let rows;try{rows=JSON.parse(await fs.readFile(root+experiment+'-http.json','utf8'));}catch{continue;}
 if(rows.length!==32)continue;
 const summary=['node','bun'].map(runtime=>{
  const selected=rows.filter(r=>r.runtime===runtime);
  const rps=Object.fromEntries(['baseline','compiled','raw','react'].map(v=>[v,selected.filter(r=>r.variant===v).reduce((n,r)=>n+r.rps,0)/4]));
  return {runtime,rps,changePercent:(rps.compiled/rps.baseline-1)*100,improvedBlocks:[0,1,2,3].filter(b=>selected.find(r=>r.block===b&&r.variant==='compiled').rps>selected.find(r=>r.block===b&&r.variant==='baseline').rps).length};
 });
 const valid=rows.reduce((n,r)=>n+r.results.reduce((n,d)=>n+d.stages[0].valid,0),0),errors=rows.reduce((n,r)=>n+r.results.reduce((n,d)=>n+d.stages[0].errors,0),0);
 const result={experiment,valid,errors,summary};await fs.writeFile(root+experiment+'-summary.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
}
