import fs from 'node:fs/promises';import {resolve} from 'node:path';import {pathToFileURL} from 'node:url';import assert from 'node:assert/strict';import {JSDOM} from 'jsdom';
const root='.tmp/ssr-large-profile/';const entries={baseline:root+'direct-execution-integrated/server-entry.js',compiled:root+'static-shell/server-entry.js',raw:root+'static-shell/raw/server-entry.js'};
const modules=Object.fromEntries(await Promise.all(Object.entries(entries).map(async([key,path])=>[key,await import(pathToFileURL(resolve(path)))])));
const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
const rows=[];
for(const mode of ['string','stream'])for(let request=0;request<3;request++){
 const data=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));data.incidents[1].title='Live request '+request+' <safe>';
 let expected;
 for(const [variant,mod] of Object.entries(modules)){
  const html=mode==='string'?await mod.renderParticipant(data,'/incidents/inc-101',options):await new Response(await mod.renderParticipantStream(data,'/incidents/inc-101',options)).text();
  const dom=new JSDOM(html);try{
   const doc=dom.window.document;assert.equal(doc.querySelectorAll('html').length,1);assert.equal(doc.querySelectorAll('body').length,1);
   assert.match(html,/^<!doctype html>/i);assert.match(html,/<\/body><\/html>$/i);
   for(const asset of ['app.js','vendor.js','app.css','theme.css'])assert.ok(doc.head.innerHTML.includes('/assets/'+asset));
   const app=doc.querySelector('.app-shell');assert.ok(app);assert.ok(app.textContent.includes(data.incidents[1].title));
   const normalized=app.outerHTML.replace(/<!--[\s\S]*?-->/g,'').replace(/ data-exact-id="[^"]*"/g,'');
   if(expected===undefined)expected=normalized;else assert.equal(normalized,expected);
   const script=doc.querySelector('#__exact_hydration');assert.ok(script);const payload=JSON.parse(script.textContent);assert.ok(JSON.stringify(payload).includes(data.incidents[1].title));
   rows.push({mode,request,variant,bytes:Buffer.byteLength(html),hydrationBytes:Buffer.byteLength(script.textContent)});
  }finally{dom.window.close();}
 }
}
await fs.writeFile(root+'static-shell/verification.json',JSON.stringify(rows,null,2));console.log('Passed',rows.length,'live application and hydration comparisons.');
