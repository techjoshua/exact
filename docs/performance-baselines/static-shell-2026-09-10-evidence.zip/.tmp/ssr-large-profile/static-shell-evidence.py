from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd()
report=Path('docs/performance-baselines/static-shell-2026-09-10.md')
archive=report.with_name('static-shell-2026-09-10-evidence.zip')
assert not archive.exists()
files=[report]
files+=list(Path('.tmp/ssr-large-profile').glob('static-shell-*.mjs'))
files+=list(Path('.tmp/ssr-large-profile').glob('static-shell-*.py'))
files+=[p for p in Path('.tmp/ssr-large-profile/static-shell').rglob('*') if p.is_file() and 'dist-client' not in p.parts]
files += [Path('.tmp/ssr-large-profile/direct-execution-integrated')/n for n in ['server-entry.js','bun-server-entry.js']]
files += [Path('framework-comparison/participants/react')/n for n in ['dist-server/server-entry.js','dist-bun-server/bun-server-entry.js']]
files += [Path('.tmp/positional-leaves/data.json')]
files=sorted(set(files))
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p,digest in manifest.items():assert hashlib.sha256(z.read(p)).hexdigest()==digest
assert Path('framework-comparison/participants/exact/src/Document.tsx').read_bytes()==Path('.tmp/ssr-large-profile/static-shell/Document.original.tsx').read_bytes()
print(f'Verified {len(manifest)} archived files and restored Document source: {archive}')
