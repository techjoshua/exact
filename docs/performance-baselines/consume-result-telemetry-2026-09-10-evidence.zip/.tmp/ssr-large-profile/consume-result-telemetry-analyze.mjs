import fs from 'node:fs/promises';import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';const rows=JSON.parse(await fs.readFile(root+'consume-result-telemetry.json','utf8'));assert.equal(rows.length,18);
const details=rows.map(row=>{
 const valid=row.results.reduce((sum,d)=>sum+d.stages[0].valid,0);
 const phase={};for(const key of ['renderMs','participantWorkMs','totalMs','envelopeMs']){const a=row.after.statistics[key],b=row.before.statistics[key];phase[key]={count:a.count-b.count,sumMs:a.sum-b.sum};}
 const cpuUs=row.after.cpu.user+row.after.cpu.system-row.before.cpu.user-row.before.cpu.system;
 return {variant:row.variant,block:row.block,rps:row.rps,valid,cpuUs,gcCount:row.after.garbageCollection.count-row.before.garbageCollection.count,gcMs:row.after.garbageCollection.durationMs-row.before.garbageCollection.durationMs,phase};
});
const summary=['baseline','candidate','react'].map(variant=>{
 const values=details.filter(r=>r.variant===variant),sum=key=>values.reduce((n,r)=>n+r[key],0),valid=sum('valid');
 return {variant,valid,rps:sum('rps')/values.length,cpuUsPerRequest:sum('cpuUs')/valid,gcCountPer10k:sum('gcCount')/valid*10000,gcMsPer10k:sum('gcMs')/valid*10000,phaseUs:Object.fromEntries(Object.keys(values[0].phase).map(key=>{const count=values.reduce((n,r)=>n+r.phase[key].count,0),ms=values.reduce((n,r)=>n+r.phase[key].sumMs,0);return [key,count?ms/count*1000:null];}))};
});
await fs.writeFile(root+'consume-result-telemetry-summary.json',JSON.stringify({details,summary},null,2));console.log(JSON.stringify(summary,null,2));
