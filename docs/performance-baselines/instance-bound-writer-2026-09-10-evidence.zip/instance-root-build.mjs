import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';
const baseline=fs.readFileSync('framework-comparison/participants/exact/dist-server/server-entry.js','utf8');
assert.equal(createHash('sha256').update(baseline).digest('hex'),'069f9784fa667af7896202923a6c08622ae1bb3f4060054328314dbe1ae6619b');
fs.mkdirSync(root+'individual-result-integrated',{recursive:true});fs.writeFileSync(root+'individual-result-integrated/server-entry.js',baseline);
const call='return writer(generatedSsrOperations, output.context, invocation, output);';
assert.equal(baseline.split(call).length,2);
const receiver=baseline.replace(call,'return writer.call(invocation, generatedSsrOperations, output.context, invocation, output);');
fs.mkdirSync(root+'instance-root-call',{recursive:true});fs.writeFileSync(root+'instance-root-call/server-entry.js',receiver);
let candidate=receiver;
for(const component of ['IncidentApp','IncidentQueue','IncidentDetail']){
 const start=candidate.indexOf(`var __exactImplementation_${component}_1 = function ${component}(props) {`);
 const end=candidate.indexOf(`\n};\nvar ${component} =`,start);
 assert.ok(start>0&&end>start,component);
 let body=candidate.slice(start,end);
 assert.equal(body.split('return createPreparedServerRenderProgram(').length,2,component);
 body=body.replace('return createPreparedServerRenderProgram(','return prepareInstanceRoot.call(this, ');
 candidate=candidate.slice(0,start)+body+candidate.slice(end);
}
candidate=`function prepareInstanceRoot(program,eagerValues){
 this[PreparedServerRenderProgram]=true;
 this.program=program;
 this.eagerValues=eagerValues;
 return this;
}\n`+candidate;
fs.mkdirSync(root+'instance-root-fold',{recursive:true});fs.writeFileSync(root+'instance-root-fold/server-entry.js',candidate);
let runner=fs.readFileSync(root+'individual-result-descriptors-run.mjs','utf8')
 .replace("current:d+'result-storage-integrated/server-entry.js',candidate:d+'individual-result-descriptors/server-entry.js'","current:d+'individual-result-integrated/server-entry.js',call:d+'instance-root-call/server-entry.js',candidate:d+'instance-root-fold/server-entry.js'")
 .replace('individual-result-descriptors-results.json','instance-root-results.json');
fs.writeFileSync(root+'instance-root-run.mjs',runner);
