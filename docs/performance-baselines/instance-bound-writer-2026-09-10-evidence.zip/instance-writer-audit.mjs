import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';
const entry='framework-comparison/participants/exact/dist-server/server-entry.js';
let code=fs.readFileSync(entry,'utf8');const artifactSha256=createHash('sha256').update(code).digest('hex');
assert.equal(artifactSha256,'069f9784fa667af7896202923a6c08622ae1bb3f4060054328314dbe1ae6619b');
const helpers=`
let auditScope, auditCalls=[], auditWrites=[], auditFrames=new WeakMap(), auditNextFrame=0;
const auditInvocations=new WeakMap(),auditRenderFunctions=new WeakMap();
function auditComponentRender(server,frame,props){
 let frameId=auditFrames.get(frame);if(!frameId){frameId=++auditNextFrame;auditFrames.set(frame,frameId);}
 const scope={id:auditCalls.length,name:server.render.name,mode:server.mode,frameId,shared:frame===statelessDirectSsrComponentFrame,programs:[]};auditCalls.push(scope);
 const previous=auditScope;auditScope=scope;
 try{const value=server.render.call(frame,props);if(typeof value==='function')auditRenderFunctions.set(value,scope);return value;}finally{auditScope=previous;}
}
function auditPreparedRender(render){const previous=auditScope;auditScope=auditRenderFunctions.get(render);try{return render();}finally{auditScope=previous;}}
function auditReset(){auditCalls=[];auditWrites=[];auditFrames=new WeakMap();auditNextFrame=0;}
function auditRead(){return {calls:auditCalls,writes:auditWrites,uniqueFrames:auditNextFrame};}
`;
const direct='server.render.call(frame, props)';assert.equal(code.split(direct).length,5);code=code.replaceAll(direct,'auditComponentRender(server, frame, props)');
assert.equal(code.split('() => render()').length,2);code=code.replace('() => render()','() => auditPreparedRender(render)');
assert.equal(code.split(': render()), owner)').length,2);code=code.replace(': render()), owner)',': auditPreparedRender(render)), owner)');
const factory='function createPreparedServerRenderProgram(branded, eagerValues, enhancement) {';
const start=code.indexOf(factory),end=code.indexOf('\n}',start)+2;assert.ok(start>0&&end>start);
let body=code.slice(start,end);assert.equal(body.split('return invocation;').length,2);
body=body.replace('return invocation;',`if(auditScope){const record={call:auditScope.id,program:branded.id,slots:eagerValues.length};auditScope.programs.push(record);auditInvocations.set(invocation,record);}
 return invocation;`);
code=code.slice(0,start)+body+code.slice(end);
const invoke='return writer(generatedSsrOperations, output.context, invocation, output);';assert.equal(code.split(invoke).length,2);
code=code.replace(invoke,`auditWrites.push(auditInvocations.get(invocation)??{call:null,program:invocation.program.id,slots:invocation.eagerValues.length});\n\t${invoke}`);
const target=root+'instance-writer-audit-entry.mjs';fs.writeFileSync(target,helpers+code+'\nexport {auditReset,auditRead};\n');
const audited=await import(pathToFileURL(resolve(target))),control=await import(pathToFileURL(resolve(entry)));
const rows=[];
for(const scenario of ['small','large'])for(const mode of ['string','stream']){
 const data=JSON.parse(fs.readFileSync('.tmp/positional-leaves/data.json'));
 if(scenario==='large')data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
 const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
 const render=async mod=>mode==='string'?mod.renderParticipant(data,'/incidents/inc-101',options):new Response(await mod.renderParticipantStream(data,'/incidents/inc-101',options)).text();
 const expected=await render(control);audited.auditReset();const html=await render(audited);assert.equal(html,expected);
 const row={scenario,mode,artifactSha256,bytes:Buffer.byteLength(html),...audited.auditRead()};rows.push(row);
 console.log(scenario,mode,JSON.stringify({calls:row.calls.length,frames:row.uniqueFrames,sharedCalls:row.calls.filter(c=>c.shared).length,created:row.calls.reduce((s,c)=>s+c.programs.length,0),writes:row.writes.length,unscopedWrites:row.writes.filter(w=>w.call===null).length,perCall:row.calls.filter(c=>!c.shared||c.programs.length!==1).map(c=>({name:c.name,mode:c.mode,shared:c.shared,programs:c.programs.length,slots:c.programs.reduce((s,p)=>s+p.slots,0)}))}));
}
fs.writeFileSync(root+'instance-writer-audit-results.json',JSON.stringify(rows,null,2));
