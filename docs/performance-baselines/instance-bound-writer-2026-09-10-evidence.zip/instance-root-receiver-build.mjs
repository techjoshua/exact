import fs from 'node:fs';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
let code=fs.readFileSync(root+'instance-root-fold/server-entry.js','utf8');
const programs=[...code.matchAll(/return prepareInstanceRoot\.call\(this, ([\w$]+),/g)].map(m=>m[1]);assert.equal(programs.length,3);
for(const program of programs){
 const start=code.indexOf('var '+program+' ='),end=code.indexOf('\n});',start)+4;assert.ok(start>0&&end>start);
 let body=code.slice(start,end);
 const signature='ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {';
 assert.equal(body.split(signature).length,2);
 body=body.replace(signature,'ssr: function __exactRun(__exactSsr, __exactContext, __exactUnusedInvocation, __exactOutput, __exactFrame) {\n\t\tconst __exactInvocation=this;');
 assert.ok(body.includes('return __exactRun(__exactSaved[0],'));
 body=body.replaceAll('return __exactRun(__exactSaved[0],','return __exactRun.call(__exactSaved[2], __exactSaved[0],');
 code=code.slice(0,start)+body+code.slice(end);
}
fs.mkdirSync(root+'instance-root-receiver',{recursive:true});fs.writeFileSync(root+'instance-root-receiver/server-entry.js',code);
fs.writeFileSync(root+'instance-root-receiver-run.mjs',fs.readFileSync(root+'instance-root-run.mjs','utf8').replace("candidate:d+'instance-root-fold/server-entry.js'","candidate:d+'instance-root-receiver/server-entry.js'").replace('instance-root-results.json','instance-root-receiver-results.json'));
