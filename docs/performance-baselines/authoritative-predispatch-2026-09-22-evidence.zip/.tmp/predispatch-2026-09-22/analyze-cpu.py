from pathlib import Path
import json,collections
for fw in ['exact','react']:
 counts=collections.Counter(); inclusive=collections.Counter();total=0;files=list(Path('.tmp/predispatch-2026-09-22').glob(f'cpu-{fw}-controlled-*.json'))
 for p in files:
  d=json.loads(p.read_text());es=d['trace']['traceEvents'];a=next(e['ts'] for e in es if e['name']=='claim-click');b=next(e['ts'] for e in es if e['name']=='request-dispatched');prof=d['profile'];nodes={x['id']:x for x in prof['nodes']};parents={c:n['id'] for n in prof['nodes'] for c in n.get('children',[])};t=prof['startTime']
  for id,delta in zip(prof['samples'],prof['timeDeltas']):
   t+=delta
   if not a<=t<=b:continue
   total+=delta
   def key(id):
    f=nodes[id]['callFrame'];return (f['functionName'],f['url'][-40:],f['lineNumber'],f['columnNumber'])
   counts[key(id)]+=delta
   while id in nodes:
    inclusive[key(id)]+=delta;id=parents.get(id)
 print(fw,len(files),'samples total us',total)
 print('SELF',counts.most_common(15));print('INCLUSIVE',inclusive.most_common(15))
