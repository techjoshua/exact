import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
export function instrumentCapture(capture){
 for(const [path,resource] of capture.resources){
  if(!path.endsWith('.js'))continue;
  let s=resource.body.toString();
  const replace=(a,b)=>{assert.equal(s.split(a).length,2,a);s=s.replace(a,b);};
  if(capture.id==='exact-controlled'){
   s+=';globalThis.__warmProxy=()=>{const o=br({ownerId:"before",status:"open"},{});se(()=>{o.ownerId="after";o.status="investigating";});};';
   replace('async function n(){if(!L(e,0)||!L(e,2))return;', 'async function n(){__preMark("handler-entry");if(!L(e,0)||!L(e,2))return;');
   replace('let n=rv(L(e,0));L(e,1)({...L(e,0),ownerId:L(e,2),status:`investigating`},`optimistic`),R(t,1,``),R(t,3,``);', '__preMark("fence-done");let n=rv(L(e,0));__preMark("copy-done");const __optimistic={...L(e,0),ownerId:L(e,2),status:`investigating`};__preMark("projection-done");L(e,1)(__optimistic,`optimistic`);__preMark("optimistic-done");R(t,1,``),R(t,3,``);__preMark("clears-done");');
   replace('async function M_(e,t,n,r){let i=await fetch(', 'async function M_(e,t,n,r){__preMark("service-entry");let i=await fetch(');
   replace('let n=(e,t=`authoritative`)=>{let n=L(this.state,2).find(t=>t.id===e.id);', 'let n=(e,t=`authoritative`)=>{__preMark("merge-entry");let n=L(this.state,2).find(t=>t.id===e.id);__preMark("find-done");');
   replace('||se(()=>{n.ownerId=e.ownerId,n.status=e.status,n.version=e.version,dv(n.comments,e.comments)||(n.comments=e.comments)})', '||se(()=>{__preMark("batch-entered");n.ownerId=e.ownerId;__preMark("owner-written");n.status=e.status;__preMark("status-written");n.version=e.version;__preMark("version-written");dv(n.comments,e.comments)||(n.comments=e.comments);__preMark("comments-done");})');
   if(process.env.COUNTS){
    replace('set(e,t,n,r){let{options:i}=this.record;', 'set(e,t,n,r){globalThis.__counts.proxy++;let{options:i}=this.record;');
    replace('function R(e,t,n){return di(e,t,n),n}', 'function R(e,t,n){globalThis.__counts.indexed++;return di(e,t,n),n}');
   }
   if(process.env.DETAIL){
    replace('set(e,t,n,r){let{options:i}=this.record;', 'set(e,t,n,r){if(t===`ownerId`)__preMark("trap-entry");let{options:i}=this.record;');
    replace('let f=D()?cr(e,t):void 0;this.record.forwardingSet=!0;', 'if(t===`ownerId`)__preMark("undo-start");let f=D()?cr(e,t):void 0;if(t===`ownerId`)__preMark("undo-end");this.record.forwardingSet=!0;');
    replace('p=Reflect.set(e,t,c,r)}finally{this.record.forwardingSet=!1}if(p&&f', 'p=Reflect.set(e,t,c,r)}finally{this.record.forwardingSet=!1}if(t===`ownerId`)__preMark("reflect-set-end");if(p&&f');
    replace('),p&&u){Array.isArray(e)&&t===`length`&&T(e,P),qn(e),T(e,t);', '),p&&u){if(t===`ownerId`)__preMark("undo-recorded");Array.isArray(e)&&t===`length`&&T(e,P),qn(e);if(t===`ownerId`)__preMark("hash-dirty");T(e,t);if(t===`ownerId`)__preMark("trigger-done");');
   }
  }else{
   replace('let x=async()=>{if(!e||!n)return;let t=te(e);r({...t,ownerId:n,status:`investigating`},`optimistic`),s(``),_(``);', 'let x=async()=>{__preMark("handler-entry");if(!e||!n)return;__preMark("fence-done");let t=te(e);__preMark("copy-done");const __optimistic={...t,ownerId:n,status:`investigating`};__preMark("projection-done");r(__optimistic,`optimistic`);__preMark("optimistic-done");s(``),_(``);__preMark("clears-done");');
   replace('async function p(e,t,n){let r=await fetch(', 'async function p(e,t,n){__preMark("service-entry");let r=await fetch(');
  }
  resource.body=Buffer.from(s);
 }
 capture.manifest=[...capture.resources].map(([path,r])=>({path,bytes:r.body.length,sha256:createHash('sha256').update(r.body).digest('hex'),headers:r.headers}));
}
