import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
export function makeCandidates(captures){
 const exact=captures.find(c=>c.id==='exact-controlled');
 for(const [variant,port] of [['undo',4406],['setter',4407],['combined',4408]]){
  const clone={...exact,id:'exact-'+variant,url:'http://127.0.0.1:'+port,resources:new Map([...exact.resources].map(([k,v])=>[k,{...v}]))};
  for(const [path,r] of clone.resources){
   if(!path.endsWith('.js'))continue;let s=r.body.toString();
   const replace=(a,b)=>{assert.equal(s.split(a).length,2);s=s.replace(a,b);};
   if((variant==='undo'||variant==='combined'))replace('function cr(e,t){', 'function cr(e,t){if(!Array.isArray(e)){const descriptor=Reflect.getOwnPropertyDescriptor(e,t);return()=>{if(descriptor)Reflect.defineProperty(e,t,descriptor);else Reflect.deleteProperty(e,t);};}return __arrayUndo(e,t);}function __arrayUndo(e,t){');
   if((variant==='setter'||variant==='combined')){
    const start=s.indexOf('set(e,t,n,r){let{options:i}=this.record;');assert.ok(start>0);const end=s.indexOf(',defineProperty(e,t,n)',start);assert.ok(end>start);const original=s.slice(start,end);
    const common='set(e,t,n,r){if(Array.isArray(e))return __arraySet.call(this,e,t,n,r);const {options:i}=this.record;if(i.readonly){i.onReadonlyWrite?.(t);return false;}const previous=Reflect.get(e,t,r),next=I(n),had=Object.prototype.hasOwnProperty.call(e,t),changed=Yt(previous,next),descriptor=Reflect.getOwnPropertyDescriptor(e,t);if(!changed&&descriptor&&"value"in descriptor)return true;const undo=D()?cr(e,t):undefined;this.record.forwardingSet=true;let ok;try{ok=Reflect.set(e,t,next,r);}finally{this.record.forwardingSet=false;}if(ok&&undo&&(!had||!Object.is(previous,Reflect.get(e,t,r))))E(undo,e,t);if(ok&&changed){qn(e);T(e,t);if(!had)T(e,N);kr(i,t,"set");}return ok;}';
    s=s.slice(0,start)+common+s.slice(end)+'\nfunction __arraySet'+original.slice(3)+'\n';
   }
   r.body=Buffer.from(s);
  }
  clone.manifest=[...clone.resources].map(([path,r])=>({path,bytes:r.body.length,sha256:createHash('sha256').update(r.body).digest('hex'),headers:r.headers}));captures.push(clone);
 }
}
