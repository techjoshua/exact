import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {chromium} from 'playwright';
import {startClientBenchmarkHarness} from './harness.mjs';
import {waitForFirstContentfulPaint} from '../../framework-comparison/src/paint-timing.mjs';
import {assertComparisonNetwork} from '../../framework-comparison/src/network-environment.mjs';
const network=assertComparisonNetwork();
const source=await readFile('framework-comparison/src/measure.mjs','utf8');
const timing=source.slice(source.indexOf('function installInteractionTiming()'),source.indexOf('\nasync function measureControlledService()'));
const participants=[{id:'exact-controlled',directory:'exact',artifact:'dist',url:'http://127.0.0.1:4401'},{id:'react-controlled',directory:'react',artifact:'dist',url:'http://127.0.0.1:4402'}];
const harness=await startClientBenchmarkHarness(participants);let browser;const samples=[];
try{
 browser=await chromium.launch();
 for(let round=0;round<3;round++){
  for(const participant of round%2?[...participants].reverse():participants){
   await fetch('http://127.0.0.1:4310/__benchmark/reset',{method:'POST',headers:{'content-type':'application/json','x-benchmark-control':'fixture-reset'},body:'{}'});
   const context=await browser.newContext();
   try{
    const page=await context.newPage();const errors=[],requests=[],responses=[];
    page.on('pageerror',e=>errors.push(e.message));
    await page.addInitScript({content:`(${timing})(); globalThis.__counts={proxy:0,indexed:0};globalThis.__preMark=(name)=>{const t=globalThis.__frameworkComparisonTiming;if(t.startedAt!==null && t.phasesMs[name]===undefined)t.phasesMs[name]=performance.now()-t.startedAt;};`});
    const cdp=await context.newCDPSession(page);if(process.env.CPU_RATE)await cdp.send('Emulation.setCPUThrottlingRate',{rate:Number(process.env.CPU_RATE)});await cdp.send('Network.enable');await cdp.send('Network.setCacheDisabled',{cacheDisabled:true});
    if(process.env.TRACE_NETWORK!=='0') cdp.on('Network.requestWillBeSent',e=>{if(e.request.url.endsWith('/claim'))requests.push({requestId:e.requestId,method:e.request.method,timestamp:e.timestamp,type:e.type,initiator:e.initiator.type});});
    if(process.env.TRACE_NETWORK!=='0') cdp.on('Network.responseReceived',e=>{if(e.response.url.endsWith('/claim'))responses.push({requestId:e.requestId,type:e.type,timestamp:e.timestamp,status:e.response.status,timing:e.response.timing,connectionReused:e.response.connectionReused,protocol:e.response.protocol});});
    await page.goto(participant.url+'/incidents/inc-100',{waitUntil:'domcontentloaded'});
    await page.getByRole('heading',{name:'Checkout authorization failures'}).waitFor();
    await page.evaluate(waitForFirstContentfulPaint);await page.waitForLoadState('load');
    await page.locator('.connection').getByText('Live service',{exact:true}).waitFor();
    const beforeCounts=await page.evaluate(()=>globalThis.__counts);await page.getByRole('button',{name:'Claim incident'}).click();
    await page.getByText('Version 2',{exact:true}).waitFor();await page.getByText('Alex Chen',{exact:true}).waitFor();
    await page.waitForFunction(()=>globalThis.__frameworkComparisonTiming.phasesMs['http-json-decoded']!==undefined);
    assert.deepEqual(errors,[]);
    samples.push({round,beforeCounts,afterCounts:await page.evaluate(()=>globalThis.__counts),id:participant.id,timing:await page.evaluate(()=>globalThis.__frameworkComparisonTiming),requests,responses});
   }finally{await context.close();}
  }
  console.log('Round',round+1,'/20');
 }
 await writeFile('.tmp/predispatch-2026-09-22/results-counts.json',JSON.stringify({network,harness:harness.evidence(),samples},null,2));
}finally{try{await browser?.close();}finally{await harness.close();}}
