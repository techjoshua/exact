# Pre-request diagnostics

Baseline framework implementation dd3d7e69, documentation HEAD 08c95aa0. Private harness copies reuse the production capture/replay and service lifecycle. They transform only in-memory JavaScript resource bytes; repository source and generated artifacts are never rewritten. Replacement sites assert uniqueness and each transformed capture records its actual resource hashes.

Run from the repository root inside the same isolated native-loopback environment as the settlement probes. Set TRACE_NETWORK=0. run.mjs takes optional CPU_RATE=6 or DETAIL=1. run-eager.mjs adds a separate --js-flags=--no-lazy browser as a control. run-cpu.mjs takes CPU_RATE=6 and captures profiles/timeline markers. run-candidates-repeat.mjs compares uninstrumented original, object undo, object setter, and combined paths; run-candidates.mjs predates the combined candidate. run-warm.mjs primes a detached object's mutation path before measurement, for attribution only. run-counts.mjs requires COUNTS=1 and counts indexed/proxy writes around the claim.

The console denominator inherited from the earlier probe is 20 even where loops run 40, 60, or fewer rounds; raw sample counts are authoritative. The candidate module now includes the combined case, which is measured only by the repeat runner. These are diagnostics, not admitted benchmark lanes. Per-step clocks and CPU profiling add overhead. CPU sampling is used to locate stacks, not establish uninstrumented percentages. Warmup and eager compilation are not proposed product changes.

Every completed sample asserts authoritative Version 2, Alex Chen, HTTP JSON completion, and no page errors. Detailed failure/lifecycle correctness is not established by these scenario assertions. No candidate was accepted because the standalone improvements failed to repeat and the combined result disappeared in a further 60-sample-per-case repeat with rotating order.

run-combined-repeat.mjs compares original eXact, combined changes, and React over 60 rotating rounds, without phase instrumentation. Original and combined eXact both average 0.6483 ms to fetch.
