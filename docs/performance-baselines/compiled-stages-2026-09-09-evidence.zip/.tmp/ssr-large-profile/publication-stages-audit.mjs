import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {PublicationPressureSink} from './publication-stages-sink.mjs';
import * as runtime from './publication-stages-entry.mjs';
import * as fixture from './publication-stages-fixture.mjs';
const rows=[];
for(const threshold of [1,8,8192])for(const abort of [false,true]){
 fixture.reset();const events=[];let release,done=false,resultError,outputBytes;
 const controller=new AbortController(),options={markers:false,signal:controller.signal};
 const sink=new PublicationPressureSink((bytes,reason)=>{
  assert.equal(release,undefined,'only one outstanding transport write');
  events.push({reason,text:new TextDecoder().decode(bytes)});
  return new Promise(resolve=>{release=()=>{release=undefined;resolve();};});
 },{threshold,maxBytes:1024,signal:controller.signal});
 const context=runtime.createSsrContext(options);context.experimentalSink=sink;
 const target=new runtime.SsrOperationTarget(context,undefined,options,false,runtime.renderChildren);
 const refs=[1,2].map(index=>runtime.createPreparedServerComponentReference(fixture.ScheduledChild,{index}));
 const head={program:{ssrHost:'head',async ssr(ops,ctx,invocation,out){ops.static(out,'<head><link rel="stylesheet" href="/app.css"></head>');await out.sink.ready();return out;}}};
 const parent=runtime.createPreparedServerRenderProgram(runtime.prepareCompiledRenderProgram({version:1,id:'stage-root',namespace:'html',ssrHost:'html',async ssr(ops,ctx,invocation,out){
  out.preparation=out.prepareReferences(refs);
  ops.static(out,'<html>');await out.sink.ready();
  await runtime.renderDirectWriter(ctx,head,()=>{throw Error('head has no children');});
  ops.static(out,'<body>');await out.sink.ready();
  await ops.component(ctx,out,refs[0],'1',0,true);await out.sink.ready();
  await ops.component(ctx,out,refs[1],'2',0,true);await out.sink.ready();
  ops.static(out,'</body></html>');await out.sink.ready();return out;
 }}),[]);
 const rendering=Promise.resolve(target.renderPreparedServerProgram(parent)).then(()=>sink.finish()).then(bytes=>{outputBytes=bytes;done=true;},error=>{resultError=error;done=true;});
 let cancelled=false;
 try{
  for(let turn=0;turn<500&&!done;turn++){
   await Promise.resolve();
   if(fixture.starts===2)fixture.settle();
   if(release){
    if(abort&&fixture.starts===2&&!cancelled){cancelled=true;controller.abort();}
    else if(!cancelled)release();
   }
  }
  assert.equal(done,true,'drain protocol reaches completion');await rendering;
  if(abort){assert.equal(resultError?.name,'AbortError');assert.equal(cancelled,true);}
  else{
   assert.equal(resultError,undefined);
   const html=events.map(e=>e.text).join('');
   assert.equal(html,'<!doctype html><html><head><link rel="stylesheet" href="/app.css"></head><body><strong>Ready 1</strong><strong>Ready 2</strong></body></html>');
   assert.equal(outputBytes,Buffer.byteLength(html));
  }
  assert.deepEqual([...fixture.disposedIndices].sort(),[1,2]);assert.deepEqual(context.hostStack,[]);
  rows.push({threshold,abort,chunks:events.length,events,disposedIndices:fixture.disposedIndices});
 }finally{controller.abort();fixture.settle();release?.();sink.destroy();}
}
writeFileSync('.tmp/ssr-large-profile/publication-stages-'+(process.versions.bun?'bun':'node')+'.json',JSON.stringify(rows,null,2));
console.log(rows.map(({threshold,abort,chunks})=>({threshold,abort,chunks})));
