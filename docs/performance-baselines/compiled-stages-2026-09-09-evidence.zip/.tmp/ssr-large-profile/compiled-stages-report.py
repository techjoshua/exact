import pathlib,json,hashlib,zipfile
d=pathlib.Path('.tmp/ssr-large-profile')
for runtime in ['node','bun']:
 rows=json.loads((d/f'compiled-stages-{runtime}.json').read_text(encoding='utf-8'))
 assert len(rows)==6 and all(sorted(r['disposedIndices'])==[1,2] for r in rows)
assert json.loads((d/'compiled-stages-build.json').read_text())=={'programs':5,'stages':14}
files=[d/n for n in ['compiled-stages-build.mjs','compiled-stages-build.json','compiled-stages-compile.json','compiled-stages-fixture.mjs','compiled-stages-entry.mjs','compiled-stages-audit-build.mjs','compiled-stages-audit.mjs','compiled-stages-report.py','compiled-stages-node.json','compiled-stages-bun.json','publication-stages-entry.mjs','publication-stages-audit.mjs','publication-stages-sink.mjs','publication-byte-sink.mjs','direct-writer-real-siblings-compile.json']]
files += [pathlib.Path('docs/performance-baselines/compiled-stages-2026-09-09.md')]
manifest={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=pathlib.Path('docs/performance-baselines/compiled-stages-2026-09-09-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p).replace('\\','/'))
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified five programs, fourteen stages, twelve integration cases, and archive hashes.')
