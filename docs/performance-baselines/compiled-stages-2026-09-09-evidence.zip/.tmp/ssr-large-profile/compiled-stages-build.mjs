import {readFileSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {transform} from 'esbuild';
const dir='.tmp/ssr-large-profile/';
const prior=JSON.parse(readFileSync(dir+'direct-writer-real-siblings-compile.json','utf8'));
const request={...prior.request,id:dir+'compiled-stages.tsx',source:prior.request.source+`
export function StagedDocument(){return ()=><html><head><link rel="stylesheet" href="/app.css"/></head><body><ScheduledChild index={1}/><ScheduledChild index={2}/></body></html>;}
`};
const run=spawnSync('.tmp/native-compiler/exactc.exe',[],{input:JSON.stringify(request)+'\n',encoding:'utf8',windowsHide:true,maxBuffer:32*1024*1024});
if(run.status!==0)throw Error(run.stderr||run.stdout);
const response=JSON.parse(run.stdout);writeFileSync(dir+'compiled-stages-compile.json',JSON.stringify({request,response},null,2));
if(response.error||response.diagnostics.some(d=>d.severity==='error'))throw Error(JSON.stringify(response.diagnostics));
let code=(await transform(response.code,{loader:'ts',format:'esm',target:'esnext'})).code;
let stages=0,programs=0;
function lower(body){
 const match=/  (__exactCharacters = )?(__exactSsr\.(?:static|rootOpening|text|child|keyedChild|component|directComponent|attribute|compiledAttribute|attributes)\([^\n]+\));/.exec(body);
 if(!match)return body;
 const id=stages++,result='__writeResult_'+id,after='__afterWrite_'+id,resume='__resumeWrite_'+id;
 return body.slice(0,match.index)+`  const ${result}=${match[2]};
  if(${result} instanceof Promise)return ${result}.then(${after});
  return ${after}(${result});
  function ${after}(settled){
   const drain=__exactOutput.sink.ready?.();
   return drain?drain.then(()=>${resume}(settled)):${resume}(settled);
  }
  function ${resume}(settled){
   ${match[1]?'__exactCharacters=settled;':''}
${lower(body.slice(match.index+match[0].length))}
  }`;
}
code=code.replace(/ssr: \(__exactSsr, __exactContext, __exactInvocation\) => \{([\s\S]*?)\n\}, ssrHost:/g,(_,body)=>{
 programs++;
 body=body.replace('const __exactOutput = __exactSsr.output();','');
 const declarations=[],refs=[];
 body=body.replace(/__exactSsr.directComponent\(__exactContext, __exactOutput, (\w+), (__exactValue_\d+),/g,(_,component,props)=>{
  const ref='__sibling_'+refs.length;refs.push(ref);declarations.push(`const ${ref}=__prepareSibling(${component},${props});`);
  return `__exactSsr.component(__exactContext, __exactOutput, ${ref},`;
 });
 if(refs.length){const index=body.indexOf('__exactSsr.begin(');body=body.slice(0,index)+declarations.join('\n')+`\nif(__exactOutput.prepareReferences)__exactOutput.preparation=__exactOutput.prepareReferences([${refs.join(',')}]);\n`+body.slice(index);}
 return 'ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {'+lower(body)+'\n}, ssrHost:';
});
if(programs<4||stages<8)throw Error('Insufficient generated stages '+JSON.stringify({programs,stages}));
code='import {createPreparedServerComponentReference as __prepareSibling} from "@exactjs/core/framework/server-render-structure";\n'+code;
if(!code.includes('issueServerComponentReceipt as __exactIssueServerComponent, '))throw Error('Missing issuer link');
code=code.replace('issueServerComponentReceipt as __exactIssueServerComponent, ','');
code='import {issueServerComponentReceipt as __exactIssueServerComponent} from "./compiled-stages-entry.mjs";\n'+code;
let runtime=readFileSync(dir+'publication-stages-entry.mjs','utf8');
const leafEntry=' return executeDirectWriter(invocation,output);';
if(runtime.split(leafEntry).length!==2)throw Error('Missing leaf entry');
runtime=runtime.replace(leafEntry,' return mapRenderValue(output.sink.ready?.(),()=>executeDirectWriter(invocation,output));');
writeFileSync(dir+'compiled-stages-entry.mjs',runtime+'\nexport {createSsrResumptionCapture};\nexport function issueServerComponentReceipt(component){activeComponentIssuer?.(component);return component;}\n');
writeFileSync(dir+'compiled-stages-fixture.mjs',code);
writeFileSync(dir+'compiled-stages-build.json',JSON.stringify({programs,stages},null,2));
console.log({programs,stages});
