import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
const worker=root+'direct-execution-target-timing-worker.mjs';
let source=fs.readFileSync(root+'projector-warm50-worker.mjs','utf8');
source="import os from 'node:os';\nos.setPriority(0,os.constants.priority.PRIORITY_BELOW_NORMAL);\n"+source;
source=source.replace('runtime:process.versions.bun??process.version','runtime:process.versions.bun??process.version,processPriority:os.getPriority()');
fs.writeFileSync(worker,source);
const rows=[];
for(const scenario of ['assets','large'])for(const runtime of ['node','bun'])for(let round=0;round<2;round++)for(const variant of round?['candidate','integrated']:['integrated','candidate']){
 const entry=root+(variant==='candidate'?'direct-execution-target':'current-target-integrated')+'/server-entry.js';
 const artifactSha256=createHash('sha256').update(fs.readFileSync(entry)).digest('hex');
 assert.equal(artifactSha256,variant==='candidate'?'b4df40493dea5ac6172ffdf8a1d4511face4212852eeb60894d218abce544078':'6d92194f2ee395f4e4e5267b8719bc1160a96ce7bc16f1a6bbdc74f98aba4997');
 const run=spawnSync(runtime,[worker,entry,'encoded',scenario,'20000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 assert.equal(run.status,0,run.stderr+run.stdout);
 const row={runtimeId:runtime,variant,round,artifactSha256,...JSON.parse(run.stdout)};
 assert.ok(row.processPriority>0);
 const peer=rows.find(r=>r.scenario===scenario);if(peer)assert.equal(row.hash,peer.hash);
 rows.push(row);fs.writeFileSync(root+'direct-execution-target-timing.json',JSON.stringify(rows,null,2));
 console.log(runtime,variant,scenario,round,row.usPerRender.toFixed(2),'us; priority',row.processPriority);
}
assert.equal(rows.length,16);
