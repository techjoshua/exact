import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const directory='.tmp/ssr-large-profile/';
const artifacts={previous:'direct-list-current',candidate:'small-writer-entry'};
const rows=[];
for(const [variant,folder] of Object.entries(artifacts)){
 const path=directory+folder+'/server-entry.js';let source=fs.readFileSync(path,'utf8');
 const start=source.indexOf('var StringProgramSink = class');assert.ok(start>=0);
 const ready=source.indexOf('ready() {}',start);assert.ok(ready>start);
 source=source.slice(0,ready)+'ready() { return Promise.resolve(); }'+source.slice(ready+'ready() {}'.length);
 fs.writeFileSync(directory+folder+'/pressure-entry.js',source);
}
for(const runtime of ['node','bun'])for(const scenario of ['assets','large']){
 let expected;
 for(const [variant,folder] of Object.entries(artifacts)){
  const result=spawnSync(runtime,[directory+'final-rope-worker.mjs',directory+folder+'/pressure-entry.js','encoded',scenario,'10'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
  assert.equal(result.status,0,result.stderr+result.stdout);const row=JSON.parse(result.stdout);
  if(expected)assert.equal(row.hash,expected);else expected=row.hash;
  rows.push({variant,runtimeId:runtime,...row});
 }
}
fs.writeFileSync(directory+'small-writer-entry-pressure.json',JSON.stringify(rows,null,2));
console.log('Eight full-response checks passed with pressure after every write.');
