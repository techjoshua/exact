import fs from 'node:fs';
import ts from 'typescript';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const directory='.tmp/ssr-large-profile/';
const input=directory+'direct-list-current/server-entry.js';
let source=fs.readFileSync(input,'utf8');
const tree=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const edits=[];
function visit(node){
 if(ts.isFunctionExpression(node)&&node.name?.text==='__exactRun'){
  const statements=node.body.statements;
  const dispatch=statements.find(ts.isSwitchStatement);
  const preparation=statements.find(ts.isIfStatement);
  if(dispatch?.caseBlock.clauses.length===5&&preparation?.elseStatement){
   const clauses=dispatch.caseBlock.clauses;
   if([clauses[0],clauses[2]].every(c=>c.statements.length===1&&ts.isExpressionStatement(c.statements[0]))){
    const postlude=statements.at(-1).getText(tree);
    assert.ok(postlude.includes('__exactSaved'));
    let body=statements[0].getText(tree)+'\n'+preparation.elseStatement.statements.map(s=>s.getText(tree)).join('\n');
    for(let index=0;index<2;index++){
     const write=clauses[index*2].statements[0].getText(tree);
     body+='\n'+write;
     const settled=clauses[index*2+1].statements;
     const drain=settled.find(ts.isVariableStatement);
     assert.ok(drain);
     for(const statement of settled){if(ts.isIfStatement(statement))break;body+='\n'+statement.getText(tree);}
     const drainName=drain.declarationList.declarations[0].name.getText(tree);
     body+=`\nif(${drainName}) { __exactStage=${index*2+2}; ${postlude.replace('__exactPending.then',drainName+'.then').replaceAll('__exactRun(', '__exactResume(')} }`;
    }
    body+='\nreturn __exactOutput;';
    const parameters=node.parameters.slice(0,4).map(p=>p.getText(tree)).join(',');
    edits.push({start:node.getStart(tree),end:node.end,text:`(()=>{const __exactResume=${node.getText(tree)};return function __exactFast(${parameters}) {${body}};})()`});
   }
  }
 }
 ts.forEachChild(node,visit);
}
visit(tree);
assert.ok(edits.length>0);
for(const edit of edits.reverse())source=source.slice(0,edit.start)+edit.text+source.slice(edit.end);
const output=directory+'small-writer-entry';fs.mkdirSync(output,{recursive:true});
fs.writeFileSync(output+'/server-entry.js',source);
fs.writeFileSync(output+'/provenance.json',JSON.stringify({input,inputSha256:createHash('sha256').update(fs.readFileSync(input)).digest('hex'),outputSha256:createHash('sha256').update(source).digest('hex'),writers:edits.length,hypothesis:'Compact synchronous entry for two-write programs, retaining original continuation on pressure.'},null,2));
console.log('Transformed writers:',edits.length);
