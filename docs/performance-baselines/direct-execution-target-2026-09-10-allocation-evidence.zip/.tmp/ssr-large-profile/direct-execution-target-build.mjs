import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

const root = '.tmp/ssr-large-profile/';
let code = fs.readFileSync(root + 'current-target-integrated/server-entry.js', 'utf8');
assert.equal(createHash('sha256').update(code).digest('hex'), '6d92194f2ee395f4e4e5267b8719bc1160a96ce7bc16f1a6bbdc74f98aba4997');
function replace(from, to, count = 1) {
  assert.equal(code.split(from).length - 1, count, from.slice(0, 100));
  code = code.split(from).join(to);
}

replace(`function renderDirectSsrContent(context, content, parent, renderChildren, renderOwnedComponent, prepareReferences) {
\tif (content.children) return renderChildren(content.children, parent);
\treturn renderPreparedSsrProgram(context, content.program, (value) => Array.isArray(value) ? renderChildren(value, parent) : renderOwnedComponent(value, parent), (values) => prepareReferences(values, parent));
}`, `function renderDirectSsrContent(execution, content, owner) {
  execution.renderOwner = owner;
  if (content.children) return execution.renderChildren(content.children, owner);
  return renderPreparedSsrProgram(execution.context, content.program, execution);
}
function renderExecutionTargetSegment(value) {
  return Array.isArray(value) ? this.renderChildren(value, this.renderOwner) : this.renderOwnedComponent(value, this.renderOwner);
}
function prepareExecutionTargetReferences(values) {
  return prepareDirectScheduledSsrComponentReferences(this.context, values, this.renderOwner, this.options);
}`);

const preparation = '(values, childOwner) => prepareDirectScheduledSsrComponentReferences(execution.context, values, childOwner, execution.options)';
replace(`renderDirectSsrContent(execution.context, content, owner, execution.renderChildren, execution.renderOwnedComponent, ${preparation})`, 'renderDirectSsrContent(execution, content, owner)', 2);
replace(`renderDirectSsrContent(execution.context, issued.content, scheduled.owner, execution.renderChildren, execution.renderOwnedComponent, ${preparation})`, 'renderDirectSsrContent(execution, issued.content, scheduled.owner)');
replace('\t\trenderOwnedComponent\n\t};\n\tif (artifact.execution.classification', '\t\trenderOwnedComponent,\n\t\trenderOwner: undefined,\n\t\trenderProgramSegment: renderExecutionTargetSegment,\n\t\tprepareProgramReferences: prepareExecutionTargetReferences\n\t};\n\tif (artifact.execution.classification');

fs.mkdirSync(root + 'direct-execution-target', { recursive: true });
fs.writeFileSync(root + 'direct-execution-target/server-entry.js', code);
let pressure = fs.readFileSync(root + 'current-target-integrated-pressure.mjs', 'utf8');
pressure = pressure.replaceAll('current-target-integrated-pressure', 'direct-execution-target-pressure');
pressure = pressure.replace("root+'current-target-integrated/server-entry.js'", "root+'direct-execution-target/server-entry.js'");
pressure = pressure.replace("root+'empty-child-result-integrated/server-entry.js'", "root+'current-target-integrated/server-entry.js'");
pressure = pressure.replace('code=code+`', `code=code.replace('execution.renderOwner = owner;', \`if (auditRenderOwners.has(execution) && auditRenderOwners.get(execution) !== owner) throw new Error('Execution owner changed across renders');
  if (!auditRenderOwners.has(execution)) auditExecutionTargets++;
  auditRenderOwners.set(execution, owner);
  auditDirectCalls++;
  execution.renderOwner = owner;\`);
code=code+\``);
pressure = pressure.replace("const auditPressure=Symbol('auditPressure');", "const auditRenderOwners = new WeakMap(); let auditExecutionTargets = 0; let auditDirectCalls = 0;\nexport function auditOwnerCounts(){return {targets:auditExecutionTargets,calls:auditDirectCalls};}\nconst auditPressure=Symbol('auditPressure');");
pressure = pressure.replace('const before=candidate.auditReadSuspensions();', 'const before=candidate.auditReadSuspensions(); const beforeOwners=candidate.auditOwnerCounts();');
pressure = pressure.replace('rows.push({scenario,mode,requests:3,suspensions});', 'const afterOwners=candidate.auditOwnerCounts(); rows.push({scenario,mode,requests:3,suspensions,executionTargets:afterOwners.targets-beforeOwners.targets,directContentCalls:afterOwners.calls-beforeOwners.calls});');
fs.writeFileSync(root + 'direct-execution-target-pressure.mjs', pressure);
console.log(createHash('sha256').update(code).digest('hex'));
