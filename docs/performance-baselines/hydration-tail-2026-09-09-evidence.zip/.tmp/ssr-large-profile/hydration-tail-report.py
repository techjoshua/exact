import pathlib,json,hashlib,zipfile
d=pathlib.Path('.tmp/ssr-large-profile')
for runtime in ['node','bun']:
 rows=json.loads((d/f'hydration-tail-{runtime}.json').read_text(encoding='utf-8'))
 failures=json.loads((d/f'hydration-tail-failures-{runtime}.json').read_text(encoding='utf-8'))
 assert len(rows)==6 and len(failures)==3
 assert all(r['serializations']==1 for r in rows if not r['abort'])
files=[d/n for n in ['hydration-tail-sink.mjs','hydration-tail-build.mjs','hydration-tail-entry.mjs','hydration-tail-fixture.mjs','hydration-tail-audit.mjs','hydration-tail-failure-audit.mjs','hydration-tail-report.py','hydration-tail-node.json','hydration-tail-bun.json','hydration-tail-failures-node.json','hydration-tail-failures-bun.json','compiled-stages-entry.mjs','compiled-stages-fixture.mjs','compiled-stages-audit.mjs','publication-stages-sink.mjs','publication-byte-sink.mjs']]
files += [pathlib.Path('docs/performance-baselines/hydration-tail-2026-09-09.md')]
manifest={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=pathlib.Path('docs/performance-baselines/hydration-tail-2026-09-09-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p).replace('\\','/'))
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified twelve compiled-tree cases, six failure cases, and archive hashes.')
