﻿import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {HydrationTailSink} from './hydration-tail-sink.mjs';
import {PublicationPressureSink} from './publication-stages-sink.mjs';
import {renderHydrationScript} from './hydration-tail-entry.mjs';
const rows=[];
for(const mode of ['invalid-state','byte-limit','abort-publication']){
 const chunks=[],controller=new AbortController();let offered=false;
 const underlying=new PublicationPressureSink(bytes=>{
  chunks.push(new TextDecoder().decode(bytes));
  if(mode==='abort-publication'&&chunks.length===2){offered=true;return new Promise(()=>{});}
 },{threshold:1,maxBytes:mode==='byte-limit'?20:4096,signal:controller.signal});
 const sink=new HydrationTailSink(underlying);
 await sink.write('<html><body>');sink.beginTail();sink.write('</body>');sink.write('</html>');
 const completion=sink.finishHydration(()=>renderHydrationScript({state:{value:mode==='invalid-state'?NaN:'ready'}},undefined,[]));
 try{
  if(mode==='abort-publication'){
   for(let i=0;i<10&&!offered;i++)await Promise.resolve();assert.equal(offered,true);controller.abort();
  }
  await assert.rejects(completion,error=>mode==='abort-publication'?error.name==='AbortError':mode==='invalid-state'?/JSON-serializable/.test(error.message):/configured maximum/i.test(error.message));
  assert.ok(!chunks.join('').includes('</body>'));
  assert.ok(!chunks.join('').includes('</html>'));
  assert.equal(underlying.pendingCharacters,0);
  assert.throws(()=>sink.write('late'),/closed/);
  rows.push({mode,chunks,closed:true});
 }finally{controller.abort();sink.destroy();}
}
writeFileSync('.tmp/ssr-large-profile/hydration-tail-failures-'+(process.versions.bun?'bun':'node')+'.json',JSON.stringify(rows,null,2));
console.log(rows.map(({mode,closed})=>({mode,closed})));

