import {writeFileSync} from 'node:fs';import {spawnSync} from 'node:child_process';
const dir='.tmp/ssr-large-profile/',rows=[];
for(const runtime of ['node','bun'])for(const [mode,scenario] of [['string','small'],['stream','small'],['stream','large']])for(let round=0;round<2;round++)for(const variant of round?['leaf-direct','marker-current']:['marker-current','leaf-direct']){
 const r=spawnSync(runtime,[dir+'long-worker.mjs',dir+variant+'.mjs',mode,scenario,'10000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});if(r.status)throw Error(r.stderr||r.stdout);
 const row={runtimeId:runtime,round,variant,...JSON.parse(r.stdout)};const peer=rows.find(x=>x.runtimeId===runtime&&x.mode===mode&&x.scenario===scenario&&x.round===round);if(peer&&peer.hash!==row.hash)throw Error('Body mismatch');rows.push(row);writeFileSync(dir+'leaf-direct-confirm-results.json',JSON.stringify(rows,null,2));console.log(runtime,mode,scenario,round,variant,row.usPerRender.toFixed(2));
}
