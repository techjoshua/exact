import ts from 'typescript';import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile',source=readFileSync(`${dir}/keyed-current.mjs`,'utf8');
const sf=ts.createSourceFile('compiled.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS),edits=[];
function visit(node){
 if(ts.isArrowFunction(node)&&node.parameters[0]?.name.getText(sf)==='__exactSsr'&&ts.isBlock(node.body)){
  const original=node.body.getText(sf);
  if(/__exactSsr\.(child|keyedChild|component|directComponent|attributes)\(/.test(original))return;
  let serial=0,lines=[];
  for(const statement of node.body.statements){
   let code=statement.getText(sf);
   if(code==='const __exactOutput = __exactSsr.output();'){lines.push('let __exactOutput = "";');continue;}
   if(code==='return __exactOutput;'){lines.push('return [__exactOutput];');continue;}
   let expression=ts.isExpressionStatement(statement)?statement.expression:undefined;
   const assigned=expression&&ts.isBinaryExpression(expression)&&expression.operatorToken.kind===ts.SyntaxKind.EqualsToken;
   if(assigned)expression=expression.right;
   if(!expression||!ts.isCallExpression(expression)||!ts.isPropertyAccessExpression(expression.expression)||expression.expression.expression.getText(sf)!=='__exactSsr'){lines.push(code);continue;}
   const name=expression.expression.name.text,args=expression.arguments.map(a=>a.getText(sf));
   if(name==='static'){lines.push(`__exactOutput += ${args[1]};`);continue;}
   if(name==='begin'){lines.push(code);continue;}
   const local='__exactSpan'+serial++;
   let html,prefix='""',suffix='""';
   if(name==='text'){
    html=`prototypeSsrText(${args[0]}, ${args[2]}, ${args[3]}, ${args[5]??'false'})`;prefix=args[6]??prefix;suffix=args[7]??suffix;
   }else if(name==='rootOpening'){
    html=`renderSsrRootAttributes(${args[0]}, ${args[2]}, ${args[3]}, ${args[7]??'undefined'})`;prefix=args[4];suffix=args[5];
   }else if(name==='compiledAttribute'){
    html=`renderCompiledNativeAttribute(${args[2]}, ${args[3]}, ${args[4]}, ${args[5]}, ${args[6]}, ${args[0]})`;
   }else if(name==='attribute'){
    html=`renderNativeAttribute(${args[2]}, ${args[3]}, ${args[4]}, ${args[0]})`;
   }else throw Error('Unhandled leaf call '+name);
   lines.push(`const ${local} = ${html};\n__exactCharacters += ${local}.length;\nif (__exactCharacters > __exactContext.maxOutputBytes) throw new SsrOutputLimitError(__exactContext.maxOutputBytes);\n__exactOutput += ${prefix} + ${local} + ${suffix};`);
  }
  edits.push([node.body.getStart(sf),node.body.end,'{\n'+lines.join('\n')+'\n}']);return;
 }
 ts.forEachChild(node,visit);
}
visit(sf);let output=source;for(const [start,end,text]of edits.sort((a,b)=>b[0]-a[0]))output=output.slice(0,start)+text+output.slice(end);
output+=`\nfunction prototypeSsrText(context, value, id, markerless) {\nconst rendered = value === null || value === undefined || value === false || value === true ? '' : escapeText(String(value));\nreturn context.markers && !markerless ? '<!--x:' + id + '-->' + rendered + '<!--/x:' + id + '-->' : rendered;\n}\n`;
writeFileSync(`${dir}/leaf-strings.mjs`,output);console.log('Leaf writers transformed:',edits.length);
