import {readFileSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const dir='.tmp/ssr-large-profile/';
let build=readFileSync(dir+'leaf-strings-build.mjs','utf8').replace('`${dir}/keyed-current.mjs`','`${dir}/marker-current.mjs`').replace("lines.push('return [__exactOutput];');","lines.push('return __exactOutput;');").replace('`${dir}/leaf-strings.mjs`','`${dir}/leaf-direct.mjs`');
writeFileSync(dir+'leaf-direct-generated-build.mjs',build);
const result=spawnSync('node',[dir+'leaf-direct-generated-build.mjs'],{encoding:'utf8',windowsHide:true});
if(result.status)throw Error(result.stderr); console.log(result.stdout);
let source=readFileSync(dir+'leaf-direct.mjs','utf8');
function replaceOnce(before,after){if(!source.includes(before))throw Error('Missing '+before);source=source.replace(before,after);}
replaceOnce('if (!output) throw new TypeError(`Native server render program','if (output === undefined) throw new TypeError(`Native server render program');
replaceOnce('return { segments: output };','return output;');
replaceOnce('renderPreparedSsrProgram(context, content.program, parent).segments','renderPreparedSsrProgram(context, content.program, parent)');
source=source.replaceAll('planned.segments','planned');
replaceOnce('const references = planned.filter(', 'if (typeof planned === "string") return renderProgramOutput(this.context, planned, (segment) => this.renderProgramSegment(segment), program.program.ssrHost);\n\t\tconst references = planned.filter(');
replaceOnce('const first = segments[0];','if (typeof segments === "string") {\n assertOutputCharacterBound(context, segments);\n return captureNestedEnhancementStringPrefix(context, segments);\n }\n const first = segments[0];');
writeFileSync(dir+'leaf-direct.mjs',source);
