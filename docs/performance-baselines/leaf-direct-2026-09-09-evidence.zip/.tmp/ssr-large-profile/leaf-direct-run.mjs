import {readFileSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const dir='.tmp/ssr-large-profile/';const rows=[];
for(const runtime of ['node','bun'])for(let round=0;round<3;round++)for(const variant of round%2?['leaf-direct','marker-current']:['marker-current','leaf-direct']){
 const result=spawnSync(runtime,[dir+'long-worker.mjs',dir+variant+'.mjs','string','large','18000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(result.status)throw Error(result.stderr||result.stdout);
 const row={runtimeId:runtime,round,variant,...JSON.parse(result.stdout)};
 const peer=rows.find(x=>x.runtimeId===runtime&&x.round===round);
 if(peer&&peer.hash!==row.hash)throw Error('Body mismatch');
 rows.push(row);writeFileSync(dir+'leaf-direct-results.json',JSON.stringify(rows,null,2));console.log(runtime,round,variant,row.usPerRender.toFixed(2));
}
