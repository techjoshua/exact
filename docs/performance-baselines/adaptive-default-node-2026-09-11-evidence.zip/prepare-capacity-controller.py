from pathlib import Path
root=Path('.tmp/ssr-final/adaptive-capacity');root.mkdir(exist_ok=True)
s=Path('.tmp/ssr-final/adaptive-outcomes/controller.mjs').read_text()
s=s.replace("this.phase='trial';this.resetWindow(now);this.until=now+750;", "this.phase=this.nextPhase??'trial';this.nextPhase=undefined;this.resetWindow(now);this.until=now+750;")
s=s.replace("if(now-this.started<500)return;", "if(now-this.started<750)return;")
start=s.index("  if(this.phase==='trial'){")
end=s.index("  if(this.phase==='enabled'){",start)
s=s[:start]+'''  if(this.phase==='trial'){
   if(now<this.until)return;
   this.trial=sample;this.enabled=false;this.phase='settle';this.nextPhase='after';this.until=now+250;this.resetWindow(now);return;
  }
  if(this.phase==='after'){
   const baselineRps=(this.baseline.rps+sample.rps)/2,baselineLag=(this.baseline.lag+sample.lag)/2;
   const good=this.trial.count>=100&&sample.count>=100&&this.trial.rps>baselineRps&&this.trial.lag<baselineLag;
   if(good){this.enabled=true;this.phase='enabled';this.until=now+5000;this.backoff=2000;this.note('accepted',{...sample,trial:this.trial,baselineRps,baselineLag});}
   else{this.enabled=false;this.phase='baseline';this.cooldown=now+this.backoff;this.backoff=Math.min(30000,this.backoff*2);this.note('backoff',{...sample,trial:this.trial,baselineRps,baselineLag});}
   this.resetWindow(now);return;
  }
'''+s[end:]
(root/'controller.mjs').write_text(s)
s=Path('.tmp/ssr-final/adaptive-outcomes/worker.mjs').read_text().replace('outcome-prototype','capacity-prototype')
(root/'worker.mjs').write_text(s)
s=Path('.tmp/ssr-final/adaptive-outcomes/run.mjs').read_text().replace('.tmp/ssr-final/adaptive-outcomes/','.tmp/ssr-final/adaptive-capacity/')
s=s.replace("(population?['normal','forced','adaptive','normal']:['normal','adaptive','forced','normal'])","['normal','adaptive','normal']")
s=s.replace("phase==='adaptive'?16000:8000", "phase==='adaptive'?20000:8000")
(root/'run.mjs').write_text(s)
