import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const root='.tmp/ssr-final/adaptive-production';
const capture=JSON.parse(await readFile(root+'/capture.json','utf8'));
assert.equal(capture.complete,true);
const lines=[
 '# Node adaptive scheduling, September 11, 2026','',
 'This capture exercises the production Node adapter with `adaptive: true`. It is separate from',
 'the full benchmark baseline, which omits the scheduling hook. React is unchanged. Bun does not',
 'enable this policy. Each request renders the full authored application and document shell;',
 'responses are not shared. Two independent load generators validate every complete response hash.',
 '',
 'Small documents use 3 rows and total concurrency 32. Large documents use 96 rows and concurrency',
 '128. Two populations reverse participant and scheduling order. Adaptive windows last 16 seconds;',
 'forced and immediate windows last 8 seconds. Immediate controls surround each eXact experiment.',
 'These are local measurements with variable PC usage, not isolated cloud capacity estimates.',
 '',
 '| Rows | API | Population | Policy | Valid RPS | Driver p95 ms | Driver p99 ms |',
 '| ---: | --- | ---: | --- | ---: | --- | --- |'
];
for(const b of capture.blocks){
 const stages=b.results.flatMap(r=>r.stages);
 for(const s of stages){assert.equal(s.errors,0);assert.equal(s.started,s.valid);}
 const metric=k=>stages.map(s=>s.distributions.responseMs[k].toFixed(2)).join(' / ');
 lines.push(`| ${b.rows} | ${b.mode} | ${b.population+1} | ${b.id==='react'?'React':b.phase} | ${Math.round(b.rps)} | ${metric('p95')} | ${metric('p99')} |`);
}
lines.push('',
 'The adaptive controller starts its monitor only after a short request burst. It trials yielding',
 'after sustained lag, backs off unsuccessful trials, and periodically reassesses successful ones.',
 'It observes event-loop delay, not response tails. The option therefore remains an explicit Node',
 'host policy, with representative response p95/p99 measurements required to assess suitability.',
 'The batch limit bounds starts per callback, not all work in an event-loop turn.',
 '',
 'Sparse checks use twelve requests 500 ms apart for immediate, adaptive, and immediate phases.',
 'Every sparse adaptive request bypassed the scheduling queue. Unit tests additionally verify',
 'that sparse requests create no lag histogram or timer. Timings remain in the raw evidence.',
 '',
 'The evidence archive retains the runner, diagnostic worker, production source, raw samples,',
 'artifact hashes, and the earlier prototype capture. The prototype is not the production result.',
 'See [SSR scheduling](../ssr-hydration.md) for the public contract.','');
await writeFile('docs/performance-baselines/adaptive-production-node-2026-09-11.md',lines.join('\n'));
console.log(JSON.stringify(capture.blocks.map(b=>({rows:b.rows,mode:b.mode,population:b.population,policy:b.id==='react'?'react':b.phase,rps:Math.round(b.rps),stage:b.results[0].stages[0]}))));
