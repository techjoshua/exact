from pathlib import Path
root=Path('.tmp/ssr-final/adaptive-transition');root.mkdir(exist_ok=True)
s=Path('.tmp/ssr-final/adaptive-default/worker.mjs').read_text()
s="import {AdaptiveRequestGate} from '../../../framework-adapters/node-adapter/dist/adaptive-request-gate.js';\n"+s
s=s.replace("let auditVariant='normal',auditScheduleCalls=0;", """let auditVariant='normal',auditScheduleCalls=0,auditRows=3,auditLargeData,gateSequence=0;
const auditTransitions=[];
const originalSample=AdaptiveRequestGate.prototype.sample;
AdaptiveRequestGate.prototype.sample=function(){
 const enabled=this.enabled,phase=this.phase;
 originalSample.call(this);
 if(this.enabled!==enabled||this.phase!==phase){
  this.diagnosticId??=++gateSequence;
  if(auditTransitions.length===128)auditTransitions.shift();
  auditTransitions.push({at:performance.now(),gate:this.diagnosticId,rows:auditRows,enabled:this.enabled,phase:this.phase,baseline:this.baseline,trial:this.trial,controlRate:this.controlRate,controlLag:this.controlLag});
 }
};""")
s=s.replace('adaptive:{implementation:"default-request-adapter",counter:"yield callbacks"}', 'adaptive:{implementation:"default-request-adapter",counter:"yield callbacks",transitions:auditTransitions}')
s=s.replace("if(pathname==='/__exact-benchmark/audit-mode')", "if(pathname==='/__exact-benchmark/audit-rows'){auditRows=Number(url.searchParams.get('rows'));if(![3,96].includes(auditRows))throw Error('Invalid rows');writeJson(response,{rows:auditRows});return;}\n if(pathname==='/__exact-benchmark/audit-mode')")
s=s.replace("const initialData = url.searchParams.has('__benchmarkPreloaded')", "let initialData = url.searchParams.has('__benchmarkPreloaded')")
marker="\n\t\t\t\tif (renderMode === 'stream') {"
replacement="""
                if(auditRows===96)initialData=auditLargeData??={...initialData,incidents:Array.from({length:96},(_,i)=>({...initialData.incidents[i%3],id:'inc-'+(100+i)}))};
"""+marker
assert marker in s;s=s.replace(marker,replacement,1)
(root/'worker.mjs').write_text(s)
