import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync,readFileSync,existsSync,copyFileSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
const root=resolve('.'),output=resolve('.tmp/ssr-final'),suite=resolve('framework-comparison');
const journalPath=output+'/default-execution.json';
const journal=existsSync(journalPath)?JSON.parse(readFileSync(journalPath)):[];
mkdirSync(output+'/before-default',{recursive:true});
process.env.NODE_ENV='production';
async function run(name,args,cwd=root,env={}) {
 if(journal.some(s=>s.name===name&&s.code===0)){
  const capturePath=`${output}/${name}.json`;
  const capture=JSON.parse(readFileSync(capturePath));
  if(!capture.blocks?.some(b=>b.telemetryErrors?.length)){console.log('RETAIN '+name);return;}
  const rejected=`${output}/telemetry-incomplete-${name}-attempt-${journal.filter(s=>s.name===name).length}`;
  copyFileSync(capturePath,rejected+'.json');
  copyFileSync(`${output}/default-${name}.log`,rejected+'.log');
  console.log('RETRY '+name+' because telemetry capture was incomplete');
 }
 const step={name,args,cwd,env,startedAt:new Date().toISOString()};journal.push(step);
 const save=()=>writeFileSync(journalPath,JSON.stringify(journal,null,2));save();console.log('START '+name);
 const log=openSync(`${output}/default-${name}.log`,'w');
 try{await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{cwd,env:{...process.env,...env},stdio:['ignore',log,log],windowsHide:true});step.pid=child.pid;save();child.once('error',fail);child.once('exit',(code,signal)=>{step.code=code;step.signal=signal;code===0?done():fail(Error(`${name} failed: ${code??signal}`));});});}
 finally{closeSync(log);step.endedAt=new Date().toISOString();save();}console.log('DONE '+name);
}
for(const mode of ['string','stream'])for(const runtime of ['node','bun'])for(const lane of ['multi','normal','arrivals']){
 const name=runtime+(mode==='stream'?'-stream':'')+'-'+lane;
 if(!existsSync(`${output}/before-default/${name}.json`))copyFileSync(`${output}/${name}.json`,`${output}/before-default/${name}.json`);
 await run(name,[output+'/capacity-runner.mjs',output+'/'+lane+'-plan.json',output+'/'+name+'.json',runtime],root,{COMPARISON_SSR_RENDER_MODE:mode});
}
for(const mode of ['string','stream']){
 const name=mode==='string'?'ssr':'ssr-stream';
 if(!existsSync(`${output}/before-default/${name}.json`))copyFileSync(`${output}/${name}.json`,`${output}/before-default/${name}.json`);
 await run(name,['src/measure-ssr.mjs','--correctness-passed'],suite,{
  COMPARISON_SSR_RENDER_MODE:mode,COMPARISON_SSR_OUTPUT:`${output}/${name}.json`,COMPARISON_SSR_SAMPLES:'500',COMPARISON_SSR_WARMUPS:'100',COMPARISON_SSR_CONCURRENCY_WAVES:'500',COMPARISON_SSR_SATURATION_WINDOWS:'1',COMPARISON_SSR_SATURATION_WINDOW_MS:'1000',COMPARISON_SSR_SATURATION_CONCURRENCY:'32',COMPARISON_SSR_ATTRIBUTION_WINDOWS:'1',COMPARISON_SSR_ATTRIBUTION_CONCURRENCY:'32',COMPARISON_SSR_MEASUREMENT_ROUND:'13'
 });
}
console.log('COMPLETE final current-build HTTP measurements');
