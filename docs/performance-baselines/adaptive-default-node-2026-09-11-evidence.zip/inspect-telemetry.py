import json
from pathlib import Path
for name in ['node','bun','node-stream','bun-stream']:
 for lane in ['multi','normal','arrivals']:
  p=Path('.tmp/ssr-final')/(name+'-'+lane+'.json');c=json.loads(p.read_text())
  for b in c['blocks']:
   if b.get('telemetryErrors'):print(p.name,b['population'],b['id'],b['telemetryErrors'])
