import subprocess,collections
from pathlib import Path
files=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z']).decode().split('\0')
groups=collections.Counter();large=[]
for name in filter(None,files):
 p=Path(name);groups['/'.join(p.parts[:2])]+=1
 if p.is_file() and p.stat().st_size>20_000_000:large.append((p.stat().st_size,name))
print('Untracked groups:')
for name,count in groups.most_common():print(count,name)
print('Files larger than 20MB:')
for size,name in sorted(large,reverse=True):print(size,name)
