import {resolve} from 'node:path';
import {buildPerformanceFixtures} from '../../scripts/performance/fixture-build.mjs';
console.log('Building fixture evidence');
await buildPerformanceFixtures(resolve('.tmp/ssr-final/fixture-audit'));
