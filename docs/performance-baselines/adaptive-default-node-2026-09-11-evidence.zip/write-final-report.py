from pathlib import Path
import json
root=Path('.tmp/ssr-final')
lines=['# SSR completion baseline, September 11, 2026','',
'This capture uses the final initial-release implementation: one rendering engine, separate',
'application hydration and document-shell ownership, incremental 8192-byte streaming, compiler-proven',
'static heads before blocking tasks, and automatic adaptive Node admission. Native Bun retains',
'immediate admission. React uses its unchanged framework renderer and runtime transport. Both',
'frameworks render their complete authored application and document shell for every request.',
'',
'Production Node 26.8.1 and Bun 1.4.2 ran locally on the same PC with variable foreground usage.',
'Two independent load generators validate complete response hashes. Each population reverses',
'framework order. Values below are the two populations, not a comparison with an earlier idle PC run.',
'String and stream APIs are separate. No response coalescing or cached rendered documents are used.',
'',
'## Sustained capacity','',
'Preloaded capacity isolates rendering and HTTP response delivery; normal loading includes fetching',
'the application data. Both rows use total concurrency 32. RPS is valid completed responses per second.',
'',
'| Runtime | API | Loading | eXact RPS | React RPS | eXact driver p99 ms | React driver p99 ms |',
'| --- | --- | --- | ---: | ---: | --- | --- |']
captures={}
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for lane in ['multi','normal','arrivals']:
   name=runtime+('-stream' if mode=='stream' else '')+'-'+lane
   c=json.loads((root/(name+'.json')).read_text());assert c['complete'];captures[name]=c
   if lane=='arrivals':continue
   values={}
   for id in ['exact','react']:
    rates=[];tails=[]
    for b in sorted((b for b in c['blocks'] if b['id']==id),key=lambda b:b['population']):
     ss=[next(s for s in r['stages'] if s['name']=='total-c32') for r in b['results']]
     rates.append(f'{sum(s["validRps"] for s in ss):,.0f}')
     tails.extend(s['distributions']['responseMs']['p99'] for s in ss)
    values[id]=(' / '.join(rates),f'{min(tails):.1f} to {max(tails):.1f}')
   lines.append(f'| {runtime.title()} | {mode} | {"preloaded" if lane=="multi" else "normal"} | {values["exact"][0]} | {values["react"][0]} | {values["exact"][1]} | {values["react"][1]} |')
lines+=['','## Scheduled demand','',
'Misses are requests the load generator could not start on schedule, distinct from response errors.',
'The public charts retain each runtime, API, offered rate, valid RPS, misses, errors, and response tails.',
'',
'| Runtime/API | Framework | Offered RPS | Valid RPS, two populations | Errors | Missed arrivals |',
'| --- | --- | ---: | ---: | ---: | ---: |']
error_counts={};invalid=0;total_errors=0
for name,c in captures.items():
 for b in c['blocks']:
  for r in b['results']:
   for s in r['stages']:
    if s['name']=='warmup':continue
    invalid+=s.get('invalid',0);total_errors+=s['errors']
    for k,v in s.get('errorDetails',{}).get('counts',{}).items():error_counts[k]=error_counts.get(k,0)+v
 if not name.endswith('arrivals'):continue
 for id in ['exact','react']:
  for rate in [8000,10000]:
   rates=[];errors=misses=0
   for b in sorted((b for b in c['blocks'] if b['id']==id),key=lambda b:b['population']):
    ss=[next(s for s in r['stages'] if s['name']==f'total-arrivals-{rate}') for r in b['results']]
    rates.append(f'{sum(s["validRps"] for s in ss):,.0f}')
    errors+=sum(s['errors'] for s in ss)
    misses+=sum(s['missedCapacity']+s['missedLag']+s['missedDeadline'] for s in ss)
   lines.append(f'| {c["runtimeId"].title()} {c["renderMode"]} | {"eXact" if id=="exact" else "React"} | {rate:,} | {" / ".join(rates)} | {errors:,} | {misses:,} |')
lines+=['',f'The capacity captures recorded {invalid:,} invalid responses and {total_errors:,} request errors.',
 'Error categories: '+(json.dumps(error_counts,sort_keys=True) if error_counts else 'none.') ,'',
 'Connection refusals, where recorded, occurred while establishing connections. They are retained',
 'as request failures, not attributed to malformed renderer output. These captures alone do not',
 'establish whether the connection failures originate in host scheduling, networking limits, or',
 'another transport condition. No failed stage is replaced merely to obtain a cleaner chart.','',
'## Browser and validation','',
'The full client capture includes 30 balanced browser rounds, startup at 1x/4x/6x CPU, five heap',
'samples per framework, and the root framework benchmarks. Client tests use common in-memory replay',
'delivery with framework servers stopped. Their unchanged client artifact hashes are verified against',
'the final build. All 112 live Node/Bun string/stream browser checks passed after automatic admission',
'integration. SSR diagnostics were refreshed for both APIs after the final adapter build.',
'',
'The [automatic admission investigation](adaptive-default-node-2026-09-11.md) explains why lag alone',
'and server handler duration were rejected as decision signals. Client p99 is not guaranteed to',
'improve universally. The [shell/body investigation](ssr-shell-body-2026-09-11.md) records the',
'8192-byte decision, rejected 2048-byte trials, and browser proof of early CSS discovery.',
'',
'[Full structured capture](ssr-completion-2026-09-11.json) contains source hashes, raw capture links,',
'execution journals, all public reports, and benchmark runners. The',
'[adaptive evidence archive](adaptive-default-node-2026-09-11-evidence.zip) retains rejected candidates,',
'workload-transition traces, measured source snapshots, validation logs, and before-default captures.',
'Earlier interrupted diagnostics are labeled as such and are excluded from these final results.','']
lines+=['Two Node streaming demand attempts lost telemetry requests. The control client had explicitly',
'closed its connection after every poll, forcing new connections against the saturated listener.',
'The harness now reuses that private connection and retains its timeout and failure checks.',
'Only the paired Node streaming demand capture was repeated with this diagnostic transport fix;',
'application handlers, load generation, and response validation are unchanged. Other captures use',
'the earlier close-after-poll control policy. Each framework in a paired capture uses the same policy.',
'Rejected captures, including connection-refusal errors, remain in the evidence archive under',
'`telemetry-incomplete-node-stream-arrivals*`. All attempts remain in the execution journal.','']
Path('docs/performance-baselines/ssr-completion-2026-09-11.md').write_text('\n'.join(lines),encoding='utf-8')
print(json.dumps({'invalidResponses':invalid,'requestErrors':total_errors,'errorCounts':error_counts}))
