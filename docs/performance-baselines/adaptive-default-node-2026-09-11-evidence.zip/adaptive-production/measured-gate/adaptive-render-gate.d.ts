/**
 * Host-owned admission probe. Sparse requests only update a timestamp and counter. Monitoring
 * begins after a short burst, is unreferenced, and releases its native timer after an idle sample.
 * Successful scheduling trials are periodically reconsidered rather than remaining enabled forever.
 */
export declare class AdaptiveRenderGate {
    private delay;
    private timer;
    private lastRequest;
    private recentRequests;
    private windowRequests;
    private enabled;
    private highSamples;
    private baseline;
    private trialUntil;
    private trialTotal;
    private trialSamples;
    private reassessAt;
    private cooldownUntil;
    private backoffMs;
    /** Records one live request and returns whether it should enter the shared yield queue. */
    shouldSchedule(): boolean;
    /** Samples only request-active windows; quiet windows remove scheduling and release monitoring. */
    private sample;
}
//# sourceMappingURL=adaptive-render-gate.d.ts.map