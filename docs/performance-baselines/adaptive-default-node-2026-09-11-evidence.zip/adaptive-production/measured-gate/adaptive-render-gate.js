import { monitorEventLoopDelay, performance } from 'node:perf_hooks';
const sampleIntervalMs = 250;
const minimumRequests = 4;
/**
 * Host-owned admission probe. Sparse requests only update a timestamp and counter. Monitoring
 * begins after a short burst, is unreferenced, and releases its native timer after an idle sample.
 * Successful scheduling trials are periodically reconsidered rather than remaining enabled forever.
 */
export class AdaptiveRenderGate {
    delay;
    timer;
    lastRequest = -Infinity;
    recentRequests = 0;
    windowRequests = 0;
    enabled = false;
    highSamples = 0;
    baseline = 0;
    trialUntil = 0;
    trialTotal = 0;
    trialSamples = 0;
    reassessAt = 0;
    cooldownUntil = 0;
    backoffMs = 2000;
    /** Records one live request and returns whether it should enter the shared yield queue. */
    shouldSchedule() {
        if (this.timer)
            this.windowRequests++;
        else {
            const now = performance.now();
            this.recentRequests =
                now - this.lastRequest > sampleIntervalMs ? 1 : this.recentRequests + 1;
            this.lastRequest = now;
            if (this.recentRequests >= minimumRequests) {
                this.windowRequests = this.recentRequests;
                this.delay ??= monitorEventLoopDelay({ resolution: 2 });
                this.delay.reset();
                this.delay.enable();
                this.timer = setInterval(() => this.sample(), sampleIntervalMs);
                this.timer.unref();
            }
        }
        return this.enabled;
    }
    /** Samples only request-active windows; quiet windows remove scheduling and release monitoring. */
    sample() {
        const requests = this.windowRequests;
        this.windowRequests = 0;
        const lag = this.delay.percentile(95) / 1e6;
        this.delay.reset();
        const now = performance.now();
        if (requests < minimumRequests) {
            this.enabled = false;
            this.highSamples = 0;
            this.trialUntil = 0;
            this.reassessAt = 0;
            this.backoffMs = 2000;
            if (!requests) {
                clearInterval(this.timer);
                this.timer = undefined;
                this.delay.disable();
                this.recentRequests = 0;
                this.lastRequest = -Infinity;
            }
            return;
        }
        if (!Number.isFinite(lag))
            return;
        if (this.enabled) {
            if (this.trialUntil) {
                this.trialTotal += lag;
                this.trialSamples++;
                if (now >= this.trialUntil) {
                    this.trialUntil = 0;
                    if (this.trialTotal / this.trialSamples >= this.baseline) {
                        this.enabled = false;
                        this.cooldownUntil = now + this.backoffMs;
                        this.backoffMs = Math.min(30_000, this.backoffMs * 2);
                    }
                    else {
                        this.reassessAt = now + 5000;
                        this.backoffMs = 2000;
                    }
                }
            }
            else if (now >= this.reassessAt) {
                this.enabled = false;
                this.highSamples = 0;
                this.cooldownUntil = now;
            }
            return;
        }
        if (now < this.cooldownUntil)
            return;
        this.highSamples = lag > 3 ? this.highSamples + 1 : 0;
        if (this.highSamples >= 2) {
            this.baseline = lag;
            this.trialTotal = 0;
            this.trialSamples = 0;
            this.trialUntil = now + 750;
            this.enabled = true;
            this.highSamples = 0;
        }
    }
}
//# sourceMappingURL=adaptive-render-gate.js.map