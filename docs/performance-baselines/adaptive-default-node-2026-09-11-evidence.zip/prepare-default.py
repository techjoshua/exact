from pathlib import Path
root=Path('.tmp/ssr-final/adaptive-default');root.mkdir(exist_ok=True)
s=Path('.tmp/ssr-final/adaptive-production/worker.mjs').read_text()
s="import {createNodeHandler} from '@exactjs/node-adapter';\nimport {scheduler as nodeScheduler} from 'node:timers/promises';\n"+s
a=s.index("let auditVariant=");b=s.index('\nconst participantId',a)
s=s[:a]+'''let auditVariant='normal',auditScheduleCalls=0;
const sourceScheduler=createNodeRenderScheduler();
const documentOptions={clientTags:process.env.COMPARISON_CLIENT_TAGS??'',get scheduleRender(){
 return participantId==='exact'&&auditVariant==='forced'?sourceScheduler:undefined;
}};
'''+s[b:]
s=s.replace("const participantId = process.argv[2];", "const participantId = process.argv[2];\nif(participantId==='exact'){const nativeYield=nodeScheduler.yield;nodeScheduler.yield=function(){auditScheduleCalls++;return nativeYield.call(this);};}")
s=s.replace('const participant = await createParticipantHandler(participantId);','const participant = await createParticipantHandler(participantId);\nlet automaticHandler=createNodeHandler((request,response,signal)=>participant.handle(request,response,signal));')
s=s.replace('() => participant.handle(request, response)', "() => auditVariant==='adaptive'&&participantId==='exact'?automaticHandler(request,response):participant.handle(request,response)")
s=s.replace('adaptiveScheduler=createNodeRenderScheduler({adaptive:true});', 'automaticHandler=createNodeHandler((request,response,signal)=>participant.handle(request,response,signal));')
s=s.replace('adaptive:{implementation:"production-node-adapter"}','adaptive:{implementation:"default-request-adapter",counter:"yield callbacks"}')
s=s.replace('async handle(request, response) {', 'async handle(request, response, signal = request.signal) {',1)
a=s.index("if (id === 'exact' || id === 'react')");b=s.index('\n\t\t\tasync renderOnly',a)
s=s[:a]+s[a:b].replace('request.signal','signal').replace('signal = signal','signal = request.signal')+s[b:]
(root/'worker.mjs').write_text(s)
s=Path('.tmp/ssr-final/adaptive-production/run.mjs').read_text().replace('.tmp/ssr-final/adaptive-production/','.tmp/ssr-final/adaptive-default/')
s=s.replace("(population?['normal','forced','adaptive','normal']:['normal','adaptive','forced','normal'])","['normal','adaptive','normal']")
s=s.replace("phase==='adaptive'?16000:8000", "phase==='adaptive'?20000:8000")
(root/'run.mjs').write_text(s)
