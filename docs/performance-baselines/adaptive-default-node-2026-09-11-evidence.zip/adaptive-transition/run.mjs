import {writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {installDevelopmentProcessLifecycle} from '../../../scripts/development-process-lifecycle.mjs';
import {startSsrLoadProcess} from '../../../framework-comparison/src/ssr-load-process-owner.mjs';
import {startSsrWorker,stopSsrWorker,controlSsrWorker} from '../../../framework-comparison/src/ssr-worker-controller.mjs';
import {availableSsrRuntimes,ssrEnvironmentMetadata} from '../../../framework-comparison/src/ssr-run-environment.mjs';
const root='.tmp/ssr-final/adaptive-transition/',runtime=availableSsrRuntimes('node')[0];
const report={complete:false,createdAt:new Date().toISOString(),environment:ssrEnvironmentMetadata([runtime]),blocks:[],sparse:[]};
let worker,service,drivers=[];
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function closeDrivers(){const current=drivers;drivers=[];await Promise.all(current.map(d=>d.close()));}
async function close(){await closeDrivers();if(worker){const w=worker;worker=undefined;await stopSsrWorker(w);}if(service){const s=service;service=undefined;await s.close();}}
const lifecycle=installDevelopmentProcessLifecycle({label:'Default Node admission workload transitions',close});
const save=()=>writeFile(root+'capture.json',JSON.stringify(report,null,2));
try{
 for(const mode of ['string','stream'])for(const id of mode==='string'?['exact','react']:['react','exact']){
  service=await startSsrLoadProcess('service');
  worker=await startSsrWorker({runtime,participantId:id,transport:'node-http',workerPath:resolve(root+'worker.mjs'),workingDirectory:resolve('framework-comparison'),serviceUrl:service.url,environment:{NODE_ENV:'production',COMPARISON_SSR_BOUNDED_TELEMETRY:'1',COMPARISON_SSR_RENDER_MODE:mode,EXACT_DIAGNOSTIC_ROWS:'3'}});
  for(const rows of [3,96,3]){
   await controlSsrWorker(worker,'audit-rows?rows='+rows);
   const check=await fetch(worker.url+'?__benchmarkPreloaded=true');
   assert.equal(check.status,200,await check.text());
  }
  if(id==='exact')await controlSsrWorker(worker,'audit-mode?variant=adaptive');
  for(const rows of [3,96,3]){
   await controlSsrWorker(worker,'audit-rows?rows='+rows);
   const response=await fetch(worker.url+'?__benchmarkPreloaded=true');assert.equal(response.status,200);const body=Buffer.from(await response.arrayBuffer());assert.match(body.toString(),/^<!doctype html>/i);assert.match(body.toString(),/<\/body><\/html>$/i);const identity={bytes:body.length,hash:createHash('sha256').update(body).digest('hex')};
   await controlSsrWorker(worker,'audit-start');
   for(let i=0;i<2;i++)drivers.push(await startSsrLoadProcess('driver'));
   for(const d of drivers)d.run({url:worker.url+'?__benchmarkPreloaded=true',contains:'Delayed fulfillment events',expectedIdentity:identity,maxInFlight:256,maxLagMs:50,timeoutMs:10000,stages:[{name:'rows-'+rows,mode:'concurrency',concurrency:rows===3?16:64,durationMs:id==='exact'?20000:8000}]});
   const results=await Promise.race([Promise.all(drivers.map(d=>d.result)),service.result]);
   for(const r of results)for(const s of r.stages){assert.equal(s.errors,0);assert.equal(s.started,s.valid);}
   await closeDrivers();const after=await controlSsrWorker(worker,'audit-stop');
   const rps=results.reduce((n,r)=>n+r.stages[0].validRps,0);
   report.blocks.push({id,mode,rows,rps,identity,results,after});console.log(id,mode,rows,Math.round(rps),after.scheduleCalls);await save();
  }
  if(id==='exact'){
   await sleep(750);await controlSsrWorker(worker,'audit-start');const samples=[];
   for(let i=0;i<12;i++){const start=performance.now(),response=await fetch(worker.url+'?__benchmarkPreloaded=true');assert.equal(response.status,200);await response.arrayBuffer();samples.push(performance.now()-start);await sleep(500);}
   const after=await controlSsrWorker(worker,'audit-stop');assert.equal(after.scheduleCalls,0);report.sparse.push({mode,samples,after});await save();console.log('SPARSE',mode,after.scheduleCalls);
  }
  await close();
 }
 report.complete=true;await save();
}catch(error){console.error(worker?.stderr());throw error;}finally{await close();lifecycle.dispose();}
