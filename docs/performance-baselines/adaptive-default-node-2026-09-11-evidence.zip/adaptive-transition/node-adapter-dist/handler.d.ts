import { type ExactResponseLike, type ExactServerContext } from '@exactjs/server';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { type NodeSchedulingOptions } from './request-admission.js';
/** Creates a Node endpoint handler with automatic adaptive admission and disconnect cancellation. */
export declare function createExactNodeHandler(context: ExactServerContext, options?: NodeSchedulingOptions): (request: IncomingMessage, response: ServerResponse) => void;
/** Reads a Node request body while enforcing the configured byte limit during transport. */
export declare function readNodeRequestBody(request: IncomingMessage, maxBytes?: number): Promise<string>;
/**
 * Writes an eXact response, reporting production, transport and cleanup failures through the
 * supplied logger or console. Error details never enter the generic failure response body.
 */
export declare function writeNodeResponse(response: ServerResponse, result: ExactResponseLike, signal?: AbortSignal, logger?: ExactServerContext['logger']): Promise<void>;
/** Writes only an eXact response body, preserving Node backpressure without Web-stream allocation. */
export declare function writeNodeResponseBody(response: ServerResponse, result: ExactResponseLike, signal?: AbortSignal): Promise<void>;
/** Cancels an unconsumed eXact response body without forcing lazy stream construction. */
export declare function cancelNodeResponseBody(result: ExactResponseLike, reason?: unknown): Promise<void>;
//# sourceMappingURL=handler.d.ts.map