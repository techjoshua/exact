import type { ServerResponse } from 'node:http';
import type { ExactServerContext } from '@exactjs/server';
/** Reports an uncaught handler failure and terminates the response without exposing its details. */
export declare function writeNodeError(response: ServerResponse, error: unknown, logger?: ExactServerContext['logger']): void;
//# sourceMappingURL=request-error.d.ts.map