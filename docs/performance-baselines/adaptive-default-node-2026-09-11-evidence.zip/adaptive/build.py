from pathlib import Path
p=Path('framework-comparison/src/ssr-benchmark-worker.mjs');s=p.read_text()
s=s.replace("from './", "from '../../../framework-comparison/src/").replace("from '../../scripts/", "from '../../../scripts/")
s="import {AdaptiveController} from './controller.mjs';\nimport {createNodeRenderScheduler} from '@exactjs/node-adapter';\n"+s
s=s.replace("const suiteRoot = resolve(import.meta.dirname, '..');", "const suiteRoot = resolve('"+Path('framework-comparison').resolve().as_posix()+"');")
s=s.replace("const documentOptions = { clientTags: process.env.COMPARISON_CLIENT_TAGS ?? '' };", """let auditVariant='normal',auditScheduleCalls=0,windowRequests=0,adaptiveDelay,adaptiveTimer;
const adaptive=new AdaptiveController(),sourceScheduler=createNodeRenderScheduler();
function stopAdaptiveMonitor(){clearInterval(adaptiveTimer);adaptiveTimer=undefined;adaptiveDelay?.disable();}
function startAdaptiveMonitor(){
 if(adaptiveTimer)return;adaptiveDelay??=monitorEventLoopDelay({resolution:2});adaptiveDelay.reset();adaptiveDelay.enable();
 adaptiveTimer=setInterval(()=>{const requests=windowRequests;windowRequests=0;adaptive.observe(adaptiveDelay.percentile(95)/1e6,requests,performance.now());adaptiveDelay.reset();if(!requests)stopAdaptiveMonitor();},250);adaptiveTimer.unref();
}
function scheduleSourceRender(signal){auditScheduleCalls++;return sourceScheduler(signal);}
const documentOptions={clientTags:process.env.COMPARISON_CLIENT_TAGS??'',get scheduleRender(){
 if(participantId!=='exact')return undefined;
 if(auditVariant==='adaptive'){windowRequests++;startAdaptiveMonitor();return adaptive.enabled?scheduleSourceRender:undefined;}
 return auditVariant==='forced'?scheduleSourceRender:undefined;
}};""")
marker="const { pathname } = url;"
control="""
 if(pathname==='/__exact-benchmark/audit-mode'){stopAdaptiveMonitor();auditVariant=url.searchParams.get('variant')??'normal';if(!['normal','forced','adaptive'].includes(auditVariant))throw Error('Unknown diagnostic variant');adaptive.reset();windowRequests=0;if(auditVariant!=='normal'&&participantId!=='exact')throw Error('React scheduling must remain unchanged');writeJson(response,{deferred:auditVariant!=='normal'});return;}
 if(pathname==='/__exact-benchmark/audit-start'){resetTelemetry();auditScheduleCalls=0;writeJson(response,{cpu:process.cpuUsage(),deferred:auditVariant!=='normal'});return;}
 if(pathname==='/__exact-benchmark/audit-stop'){writeJson(response,{cpu:process.cpuUsage(),telemetry:telemetry(),scheduleCalls:auditScheduleCalls,adaptive:{enabled:adaptive.enabled,monitorActive:!!adaptiveTimer,transitions:adaptive.transitions,samples:adaptive.samples}});return;}
"""
idx=s.index('async function handleNodeControlRequest');before,after=s[:idx],s[idx:];assert marker in after;after=after.replace(marker,marker+control,1);s=before+after
s=s.replace('async function shutdown(reason) {','async function shutdown(reason) {\n stopAdaptiveMonitor();')
s=s.replace('return { ...session, ...incidents };',"const data={...session,...incidents};const count=Number(process.env.EXACT_DIAGNOSTIC_ROWS??3);if(count!==3)data.incidents=Array.from({length:count},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));return data;")
Path('.tmp/ssr-final/adaptive/worker.mjs').write_text(s)
