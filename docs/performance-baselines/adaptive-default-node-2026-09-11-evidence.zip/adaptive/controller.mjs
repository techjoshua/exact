/** Diagnostic Node-only policy with periodic reassessment, bounded evidence, and quiet reset. */
export class AdaptiveController {
 constructor(){this.reset();}
 reset(){this.enabled=false;this.high=0;this.baseline=0;this.trial=[];this.cooldownUntil=0;this.backoff=2000;this.transitions=[];this.samples=[];this.trialUntil=0;this.reassessAt=0;}
 observe(lag,requests,now){
  if(this.samples.length===256)this.samples.shift();this.samples.push({lag,requests,now,enabled:this.enabled});
  if(requests<4){if(this.enabled)this.switch(false,now,'quiet');this.high=0;this.trialUntil=0;this.reassessAt=0;this.backoff=2000;return;}
  if(!Number.isFinite(lag))return;
  if(this.enabled){
   if(this.trialUntil){this.trial.push(lag);if(now>=this.trialUntil){
    const average=this.trial.reduce((a,b)=>a+b,0)/this.trial.length;this.trialUntil=0;
    if(average>=this.baseline){this.switch(false,now,'no lag improvement');this.cooldownUntil=now+this.backoff;this.backoff=Math.min(30000,this.backoff*2);}
    else {this.reassessAt=now+5000;this.backoff=2000;}
   }} else if(now>=this.reassessAt){this.switch(false,now,'periodic reassessment');this.high=0;this.cooldownUntil=now;}
   return;
  }
  if(now<this.cooldownUntil)return;
  this.high=lag>3?this.high+1:0;
  if(this.high>=2){this.baseline=lag;this.trial=[];this.trialUntil=now+750;this.switch(true,now,'sustained lag');this.high=0;}
 }
 switch(enabled,now,reason){this.enabled=enabled;if(this.transitions.length===128)this.transitions.shift();this.transitions.push({enabled,now,reason});}
}
