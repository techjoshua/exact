import {readFile} from 'node:fs/promises';
const capture=JSON.parse(await readFile('.tmp/ssr-final/adaptive-outcomes/capture.json','utf8'));
const url=new URL(capture.blocks.at(-1).results[0].plan.url);
url.pathname='/__exact-benchmark/shutdown';url.search='';
const response=await fetch(url,{method:'POST',signal:AbortSignal.timeout(3000)});
console.log(response.status,await response.text());
