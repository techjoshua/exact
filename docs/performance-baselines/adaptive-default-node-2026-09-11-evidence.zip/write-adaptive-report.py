from pathlib import Path
import json
root=Path('.tmp/ssr-final')
c=json.loads((root/'adaptive-transition/capture.json').read_text());assert c['complete']
lines=['# Automatic Node admission, September 11, 2026','',
'Accepted for the initial 0.5.0 release. Node adapter handlers enable adaptive admission by default.',
'Native Bun retains immediate admission. There is one SSR engine and no response sharing.',
'`createNodeHandler(callback)` wraps a custom page/application handler before eager string or',
'streaming rendering. `createExactNodeHandler(context)` applies the same policy to framework',
'endpoints. An outer handler owns admission when it dispatches to another Node handler.',
'',
'## Decision signal','',
'Four closely spaced requests start an unreferenced event-loop monitor. Sparse requests create',
'no monitor, timer, or scheduling promise. Sustained lag triggers a brief scheduling trial.',
'The controller compares completed-response capacity and event-loop delay with immediate windows',
'before and after the trial. Retention requires higher capacity and lower lag than both controls,',
'with at least 100 completions in each compared window. Failed trials back off; successful trials',
'are reconsidered after five seconds or sooner when their observed benefit disappears.',
'',
'Server handler duration is not client latency. An earlier candidate incorrectly compared handler',
'p95/p99: immediate work measured around 0.1 ms inside the handler while deferred work measured',
'around 1.7 ms, despite better client throughput and latency. Requests can wait in networking',
'queues before Node invokes the handler. That candidate was rejected and its diagnostic run',
'intentionally interrupted. Interruption errors are not framework failures.',
'',
'The initial lag-only controller also accepted some large-document cases with worse response tails.',
'A subsequent candidate used the mean surrounding capacity; the final controller requires beating',
'both controls to reduce sensitivity to changing PC load. Client p95/p99 remain external validation',
'metrics. Neither event-loop delay nor server completion rate proves a universal tail-latency gain.',
'Trials can briefly be slower before the controller backs off.',
'',
'## One-host workload changes','',
'One process served 3, then 96, then 3 incident rows. eXact used the actual default Node handler',
'throughout, without recreating its controller between document changes. Two independent drivers',
'used total concurrency 32 for small documents and 128 for large ones. eXact stages lasted 20 seconds;',
'unchanged React controls lasted 8 seconds. Participant order reversed between rendering modes.',
'Every response was checked against the complete document hash. All measured requests succeeded.',
'',
'| Framework | API | Rows | Valid RPS | Driver p95 ms | Driver p99 ms |',
'| --- | --- | ---: | ---: | --- | --- |']
for b in c['blocks']:
    stages=[s for r in b['results'] for s in r['stages']]
    assert all(s['errors']==0 and s['started']==s['valid'] for s in stages)
    metric=lambda k:' / '.join(f"{s['distributions']['responseMs'][k]:.2f}" for s in stages)
    lines.append(f"| {'eXact' if b['id']=='exact' else 'React'} | {b['mode']} | {b['rows']} | {b['rps']:.0f} | {metric('p95')} | {metric('p99')} |")
lines+=['',
'The policy trace shows scheduling retained for small string documents, rejected during the large',
'string phase, and retained again after returning to small documents. Streaming reconsidered the',
'changed workload and recovered when small documents returned. After an idle interval, twelve',
'requests spaced 500 ms apart made zero yield calls in both modes.',
'',
'Small-document throughput exceeds React here. Large-string throughput remains below React;',
'p99 is mixed and is not described as a universal improvement. PC usage varied across captures.',
'Use adjacent controls, not historical absolute rates, to interpret changes.',
'',
'The trace instrumented the private controller once per sampling callback; this is diagnostic',
'instrumentation, not a public API or the final capacity harness. Source and compiled adapter',
'snapshots with hashes are retained with the capture. A fixture-only const-assignment error was',
'corrected before the completed run; its failed preflight is retained separately.',
'',
'See [SSR and hydration](../ssr-hydration.md) for the public contract and the final full capture',
'for sustained default-policy capacity. The older lag-only and mean-control captures are historical',
'experiments, not descriptions of the shipped controller.','']
Path('docs/performance-baselines/adaptive-default-node-2026-09-11.md').write_text('\n'.join(lines))
