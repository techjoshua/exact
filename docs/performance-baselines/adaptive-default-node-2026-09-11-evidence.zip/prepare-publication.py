from pathlib import Path
import shutil
root=Path('.tmp/ssr-final')
for name in ['performance-report','ssr-capacity-report','ssr-bun-capacity-report']:
    dest=root/('before-'+name+'.json')
    if not dest.exists(): shutil.copyfile(Path('apps/docs/src/data')/(name+'.json'),dest)
s=Path('.tmp/post-shell-final/publish.mjs').read_text()
s=s.replace('.tmp/post-shell-final','.tmp/ssr-final').replace('post-shell-2026-09-09','ssr-completion-2026-09-11')
s=s.replace('execution.every(step => step.code === 0)', 'Object.values(Object.fromEntries(execution.map(step => [step.name, step]))).every(step => step.code === 0)')
s=s.replace('/run-round.mjs','/run.mjs')
(root/'publish.mjs').write_text(s)
s=Path('.tmp/post-shell-final/verify-docs.mjs').read_text().replace('.tmp/post-shell-final','.tmp/ssr-final')
(root/'verify-docs.mjs').write_text(s)
