import json,sys
from pathlib import Path
for name in sys.argv[1:]:
 c=json.loads((Path('.tmp/ssr-final')/(name+'.json')).read_text())
 for b in c['blocks']:
  for r in b['results']:
   for s in r['stages']:
    if s['errors']:
     d=s['errorDetails'];print(name,b['population'],b['id'],s['name'],s['errors'],s['invalid'],s['timeouts'],json.dumps(d['counts']),json.dumps(d['samples'][:2]))
