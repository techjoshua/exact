import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync,readFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
const root=resolve('.'),output=resolve('.tmp/ssr-final'),suite=resolve('framework-comparison');
const journal=existsSync(`${output}/execution.json`)?JSON.parse(readFileSync(`${output}/execution.json`)):[];
process.env.NODE_ENV='production';process.env.COMPARISON_SSR_RENDER_MODE='string';
async function run(name,args,cwd=root,env={}) {
 if(journal.some(s=>s.name===name&&s.code===0)){console.log('RETAIN '+name);return;}
 const step={name,args,cwd,env,startedAt:new Date().toISOString()};journal.push(step);
 const save=()=>writeFileSync(`${output}/execution.json`,JSON.stringify(journal,null,2));save();console.log('START '+name);
 const log=openSync(`${output}/${name}.log`,'w');
 try{await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{cwd,env:{...process.env,...env},stdio:['ignore',log,log],windowsHide:true});step.pid=child.pid;save();child.once('error',fail);child.once('exit',(code,signal)=>{step.code=code;step.signal=signal;code===0?done():fail(Error(`${name} failed: ${code??signal}`));});});}
 finally{closeSync(log);step.endedAt=new Date().toISOString();save();}console.log('DONE '+name);
}
await run('heap',['src/measure-heap.mjs','--correctness-passed'],suite,{COMPARISON_HEAP_OUTPUT:`${output}/heap.json`});
for(const mode of ['string','stream'])for(const runtime of ['node','bun'])for(const lane of ['multi','normal','arrivals']) {
 const suffix=mode==='string'?'':'-stream';await run(runtime+suffix+'-'+lane,[output+'/capacity-runner.mjs',output+'/'+lane+'-plan.json',output+'/'+runtime+suffix+'-'+lane+'.json',runtime],root,{COMPARISON_SSR_RENDER_MODE:mode});
}
for(const mode of ['string','stream'])await run(mode==='string'?'ssr':'ssr-stream',['src/measure-ssr.mjs','--correctness-passed'],suite,{
 COMPARISON_SSR_RENDER_MODE:mode,COMPARISON_SSR_OUTPUT:`${output}/${mode==='string'?'ssr':'ssr-stream'}.json`,COMPARISON_SSR_SAMPLES:'500',COMPARISON_SSR_WARMUPS:'100',COMPARISON_SSR_CONCURRENCY_WAVES:'500',COMPARISON_SSR_SATURATION_WINDOWS:'1',COMPARISON_SSR_SATURATION_WINDOW_MS:'1000',COMPARISON_SSR_SATURATION_CONCURRENCY:'32',COMPARISON_SSR_ATTRIBUTION_WINDOWS:'1',COMPARISON_SSR_ATTRIBUTION_CONCURRENCY:'32',COMPARISON_SSR_MEASUREMENT_ROUND:'12'
});
for(const [name,file,json] of [['reactive','benchmark-reactive'],['dom-list','benchmark-dom-list'],['collections','benchmark-collection-transactions',true],['framework','benchmark-framework-performance',true],['server','benchmark-server-performance'],['foundations','benchmark-performance-foundations',true],['compiler','benchmark-compiler-workflow'],['devtools','benchmark-devtools'],['react-compat','benchmark-react-compat'],['react-adapters','benchmark-react-compat-adapters']])await run(name,[`scripts/${file}.mjs`,...(json?[`--output=${output}/${name}.json`]:[])]);
console.log('COMPLETE all remaining measurements');
