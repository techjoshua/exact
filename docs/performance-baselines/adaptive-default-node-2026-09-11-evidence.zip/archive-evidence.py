from pathlib import Path
import hashlib,json,zipfile
root=Path('.tmp/ssr-final')
files=[]
for name in ['adaptive','adaptive-production','adaptive-outcomes','adaptive-capacity','adaptive-default','adaptive-transition','before-default']:
    files.extend(p for p in (root/name).rglob('*') if p.is_file())
for pattern in ['*.mjs','*.py','*.log','*execution.json','*-plan.json','*verification.json','telemetry-incomplete-*.json','completion-checks*.json']:
    files.extend(root.glob(pattern))
files=list(dict.fromkeys(p for p in files if p.is_file()))
archive=Path('docs/performance-baselines/adaptive-default-node-2026-09-11-evidence.zip')
manifest={p.relative_to(root).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
    for p in files:z.write(p,p.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,item in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==item['sha256']
print(json.dumps({'archive':str(archive),'files':len(files),'bytes':archive.stat().st_size}))
