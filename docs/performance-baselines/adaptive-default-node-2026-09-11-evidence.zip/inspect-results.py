import json
from pathlib import Path
root=Path('.tmp/ssr-final')
done={s['name'] for s in json.loads((root/'default-execution.json').read_text()) if s.get('code')==0}
for runtime in ['node','bun']:
 for mode in ['','-stream']:
  for lane in ['multi','normal','arrivals']:
   path=root/f'{runtime}{mode}-{lane}.json'
   if path.stem not in done:continue
   c=json.loads(path.read_text())
   print(path.name,c.get('complete'),c['createdAt'])
   for b in c['blocks']:
    for i,s in enumerate(b['results'][0]['stages']):
     if s['name']=='warmup':continue
     ss=[r['stages'][i] for r in b['results']]
     print(b['population'],b['id'],s['name'],round(sum(x['validRps'] for x in ss)),sum(x['errors'] for x in ss), 'p99', [x['distributions']['responseMs']['p99'] for x in ss])
