import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {installDevelopmentProcessLifecycle} from '../../../scripts/development-process-lifecycle.mjs';
import {startSsrLoadProcess} from '../../../framework-comparison/src/ssr-load-process-owner.mjs';
import {startSsrWorker,stopSsrWorker,controlSsrWorker} from '../../../framework-comparison/src/ssr-worker-controller.mjs';
import {availableSsrRuntimes,ssrEnvironmentMetadata} from '../../../framework-comparison/src/ssr-run-environment.mjs';
const root='.tmp/ssr-final/adaptive-outcomes/',runtime=availableSsrRuntimes('node')[0];
const report={complete:false,createdAt:new Date().toISOString(),environment:ssrEnvironmentMetadata([runtime]),blocks:[],sparse:[],artifacts:{}};
for(const name of ['exact','react']){const path=resolve(`framework-comparison/participants/${name}/dist-server/server-entry.js`);report.artifacts[name]={path,sha256:createHash('sha256').update(await readFile(path)).digest('hex')};}
let worker,service,drivers=[];
async function closeDrivers(){const current=drivers;drivers=[];await Promise.all(current.map(d=>d.close()));}
async function close(){await closeDrivers();if(worker){const w=worker;worker=undefined;await stopSsrWorker(w);}if(service){const s=service;service=undefined;await s.close();}}
const lifecycle=installDevelopmentProcessLifecycle({label:'Node adaptive scheduling reassessment',close});
const save=()=>writeFile(root+'capture.json',JSON.stringify(report,null,2));
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function runStage(name,durationMs,identity,concurrency=32){
 for(let i=0;i<2;i++)drivers.push(await startSsrLoadProcess('driver'));
 for(const d of drivers)d.run({url:worker.url+'?__benchmarkPreloaded=true',contains:'Delayed fulfillment events',expectedIdentity:identity,maxInFlight:256,maxLagMs:50,timeoutMs:10000,stages:[{name,mode:'concurrency',concurrency:concurrency/2,durationMs}]});
 const results=await Promise.race([Promise.all(drivers.map(d=>d.result)),service.result]);
 for(const r of results)for(const s of r.stages){assert.equal(s.errors,0);assert.equal(s.started,s.completed);assert.equal(s.completed,s.valid);}
 await closeDrivers();return results;
}
try {
 for(const rows of [3,96])for(const mode of ['string','stream'])for(let population=0;population<2;population++)for(const id of population?['react','exact']:['exact','react']){
  service=await startSsrLoadProcess('service');
  worker=await startSsrWorker({runtime,participantId:id,transport:'node-http',workerPath:resolve(root+'worker.mjs'),workingDirectory:resolve('framework-comparison'),serviceUrl:service.url,environment:{NODE_ENV:'production',COMPARISON_SSR_BOUNDED_TELEMETRY:'1',COMPARISON_SSR_RENDER_MODE:mode,EXACT_DIAGNOSTIC_ROWS:String(rows)}});
  const response=await fetch(worker.url+'?__benchmarkPreloaded=true');assert.equal(response.status,200);const body=Buffer.from(await response.arrayBuffer());assert.match(body.toString(),/^<!doctype html>/i);assert.match(body.toString(),/<\/body><\/html>$/i);const identity={bytes:body.length,hash:createHash('sha256').update(body).digest('hex')};
  await runStage('warmup',5000,identity);
  const phases=id==='react'?['normal']:(population?['normal','forced','adaptive','normal']:['normal','adaptive','forced','normal']);
  for(const phase of phases){
   await controlSsrWorker(worker,'audit-mode?variant='+phase);await controlSsrWorker(worker,'audit-start');
   const results=await runStage(phase,phase==='adaptive'?16000:8000,identity,rows===96?128:32);
   const after=await controlSsrWorker(worker,'audit-stop');const stages=results.map(r=>r.stages[0]);
   const rps=stages.reduce((n,s)=>n+s.validRps,0);report.blocks.push({rows,mode,population,id,phase,rps,identity,results,after});
   console.log(rows,mode,population,id,phase,Math.round(rps),JSON.stringify(after.adaptive.transitions));await save();
  }
  if(id==='exact'&&population===0){
   for(const phase of ['normal','adaptive','normal']){
    await controlSsrWorker(worker,'audit-mode?variant='+phase);await sleep(750);await controlSsrWorker(worker,'audit-start');const samples=[];
    for(let i=0;i<12;i++){const start=performance.now(),r=await fetch(worker.url+'?__benchmarkPreloaded=true'),bytes=Buffer.from(await r.arrayBuffer());assert.equal(r.status,200);assert.equal(createHash('sha256').update(bytes).digest('hex'),identity.hash);samples.push(performance.now()-start);await sleep(500);}
    await sleep(300);const after=await controlSsrWorker(worker,'audit-stop');assert.equal(after.scheduleCalls,0);report.sparse.push({rows,mode,phase,samples,after});console.log('SPARSE',rows,mode,phase,samples.reduce((a,b)=>a+b)/samples.length);await save();
   }
  }
  await close();
 }
 for(const value of Object.values(report.artifacts))assert.equal(createHash('sha256').update(await readFile(value.path)).digest('hex'),value.sha256);
 report.complete=true;await save();
}finally{await close();lifecycle.dispose();}
