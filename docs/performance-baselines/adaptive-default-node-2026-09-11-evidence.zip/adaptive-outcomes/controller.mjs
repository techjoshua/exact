import {createHistogram,monitorEventLoopDelay,performance} from 'node:perf_hooks';
/** Diagnostic completion-aware policy, kept outside production until measured. */
export class OutcomeController {
 constructor(){this.enabled=false;this.epoch=0;this.lastRequest=-Infinity;this.recent=0;this.requests=0;this.started=0;this.completed=0;this.high=0;this.until=0;this.cooldown=0;this.backoff=2000;this.phase='baseline';this.transitions=[];this.samples=[];}
 request(){
  if(this.timer){this.requests++;return;}
  const now=performance.now();this.recent=now-this.lastRequest>250?1:this.recent+1;this.lastRequest=now;
  if(this.recent<4)return;
  this.delay??=monitorEventLoopDelay({resolution:2});this.latency??=createHistogram();this.delay.reset();this.delay.enable();this.resetWindow(now);
  this.timer=setInterval(()=>this.sample(),250);this.timer.unref();
 }
 finish(epoch,start,end){if(this.timer&&epoch===this.epoch){this.completed++;this.latency.record(Math.max(1,Math.round((end-start)*1000)));}}
 resetWindow(now){this.epoch++;this.started=now;this.completed=0;this.latency.reset();this.delay.reset();}
 sample(){
  const now=performance.now(),requests=this.requests;this.requests=0;
  if(requests<4){this.enabled=false;this.phase='baseline';this.high=0;this.backoff=2000;if(!requests){this.stop();this.recent=0;this.lastRequest=-Infinity;}else this.resetWindow(now);return;}
  if(this.phase==='settle'){if(now>=this.until){this.phase='trial';this.resetWindow(now);this.until=now+750;}return;}
  const lag=this.delay.percentile(95)/1e6;
  if(now-this.started<500)return;
  const sample={at:now,phase:this.phase,lag,rps:this.completed*1000/(now-this.started),p95:this.latency.percentile(95)/1000,p99:this.latency.percentile(99)/1000,count:this.completed};
  if(this.samples.length===128)this.samples.shift();this.samples.push(sample);
  if(this.phase==='trial'){
   if(now<this.until)return;
   const good=sample.count>=100&&sample.rps>this.baseline.rps&&sample.p95<=this.baseline.p95&&sample.p99<=this.baseline.p99;
   if(good){this.phase='enabled';this.until=now+5000;this.backoff=2000;this.note('accepted',sample);}
   else{this.enabled=false;this.phase='baseline';this.cooldown=now+this.backoff;this.backoff=Math.min(30000,this.backoff*2);this.note('backoff',sample);}
   this.resetWindow(now);return;
  }
  if(this.phase==='enabled'){
   if(now>=this.until){this.enabled=false;this.phase='baseline';this.cooldown=now;this.high=0;this.note('reassess',sample);this.resetWindow(now);}return;
  }
  this.high=lag>3?this.high+1:0;
  if(now>=this.cooldown&&this.high>=2&&sample.count>=100){this.baseline=sample;this.enabled=true;this.phase='settle';this.until=now+250;this.note('trial',sample);this.high=0;}
  this.resetWindow(now);
 }
 note(reason,sample){if(this.transitions.length===64)this.transitions.shift();this.transitions.push({reason,...sample});}
 stop(){clearInterval(this.timer);this.timer=undefined;this.delay?.disable();this.enabled=false;}
}
