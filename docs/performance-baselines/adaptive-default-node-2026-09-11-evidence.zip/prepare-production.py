from pathlib import Path
root=Path('.tmp/ssr-final/adaptive-production')
root.mkdir(exist_ok=True)
s=Path('.tmp/ssr-final/adaptive/worker.mjs').read_text()
s=s.replace("import {AdaptiveController} from './controller.mjs';\n",'')
start=s.index("let auditVariant=")
end=s.index('\nconst participantId',start)
s=s[:start]+'''let auditVariant='normal',auditScheduleCalls=0;
const sourceScheduler=createNodeRenderScheduler();
let adaptiveScheduler=createNodeRenderScheduler({adaptive:true});
function scheduleSourceRender(signal){auditScheduleCalls++;return sourceScheduler(signal);}
function scheduleAdaptiveRender(signal){const pending=adaptiveScheduler(signal);if(pending)auditScheduleCalls++;return pending;}
const documentOptions={clientTags:process.env.COMPARISON_CLIENT_TAGS??'',get scheduleRender(){
 if(participantId!=='exact')return undefined;
 return auditVariant==='adaptive'?scheduleAdaptiveRender:auditVariant==='forced'?scheduleSourceRender:undefined;
}};
'''+s[end:]
s=s.replace('stopAdaptiveMonitor();','')
s=s.replace('adaptive.reset();windowRequests=0;','adaptiveScheduler=createNodeRenderScheduler({adaptive:true});')
s=s.replace('adaptive:{enabled:adaptive.enabled,monitorActive:!!adaptiveTimer,transitions:adaptive.transitions,samples:adaptive.samples}','adaptive:{implementation:"production-node-adapter"}')
(root/'worker.mjs').write_text(s)
s=Path('.tmp/ssr-final/adaptive/run.mjs').read_text().replace(".tmp/ssr-final/adaptive/",".tmp/ssr-final/adaptive-production/")
s=s.replace('assert.equal(after.adaptive.monitorActive,false);','')
s=s.replace('JSON.stringify(after.adaptive.transitions)','after.scheduleCalls')
(root/'run.mjs').write_text(s)
