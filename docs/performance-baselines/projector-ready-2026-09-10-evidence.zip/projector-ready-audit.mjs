import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/';
const source=fs.readFileSync(d+'static-invocation-final/server-entry.js','utf8');
const needle='const projector = value.length >= 16 && !state.path ? readPositionalProjector(schema[1]) : void 0;';
assert.equal(source.split(needle).length,2);
const changed=source.replace(needle,`const projector = (value.length >= 16 || state.active instanceof Set) && !state.path ? readPositionalProjector(schema[1]) : void 0;
if (projector && value.length < 16) globalThis.__shortReadyProjectors = (globalThis.__shortReadyProjectors ?? 0) + 1;`);
fs.mkdirSync(d+'projector-ready-audit',{recursive:true});
fs.writeFileSync(d+'projector-ready-audit/server-entry.js',changed);
const worker=fs.readFileSync(d+'final-rope-worker.mjs','utf8').replace('JSON.stringify({reactResolution,','JSON.stringify({shortReadyProjectors:globalThis.__shortReadyProjectors??0,reactResolution,');
fs.writeFileSync(d+'projector-ready-audit-worker.mjs',worker);
const rows=[];
for(const runtime of ['node','bun'])for(const scenario of ['assets','large']){
 const r=spawnSync(runtime,[d+'projector-ready-audit-worker.mjs',d+'projector-ready-audit/server-entry.js','encoded',scenario,'1'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 assert.equal(r.status,0,r.stderr+r.stdout);
 const row={runtimeId:runtime,...JSON.parse(r.stdout)};
 rows.push(row);console.log(runtime,scenario,row.shortReadyProjectors);
}
fs.writeFileSync(d+'projector-ready-audit.json',JSON.stringify(rows,null,2));
