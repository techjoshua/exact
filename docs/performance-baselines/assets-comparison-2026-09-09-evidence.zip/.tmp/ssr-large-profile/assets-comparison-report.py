import hashlib,json,pathlib,statistics,zipfile
root=pathlib.Path('.');work=root/'.tmp/ssr-large-profile'
rows=json.loads((work/'assets-comparison-results.json').read_text(encoding='utf-8'));summary=[]
assert len(rows)==32
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['small','large']:
   medians={v:statistics.median(r['usPerRender'] for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['variant']==v) for v in ['exact','react']}
   summary.append(dict(runtime=runtime,mode=mode,scenario=scenario,exact=medians['exact'],react=medians['react'],exact_time_percent=(medians['exact']/medians['react']-1)*100))
table='\n'.join(f"| {s['runtime']} | {s['mode']} | {s['scenario']} | {s['exact']:.2f} | {s['react']:.2f} | {s['exact_time_percent']:+.1f}% |" for s in summary)
dest=root/'docs/performance-baselines/assets-comparison-2026-09-09'
dest.with_suffix('.json').write_text(json.dumps(dict(summary=summary,populations=rows),indent=2)+'\n',encoding='utf-8')
doc='''# Retained eXact versus React with populated asset lists

Date: 2026-09-09. The overall performance goal remains unmet.

## Purpose and controls

The retained direct-map optimization improved eXact relative to its previous build when shell
asset lists were populated. This run compares that rebuilt implementation directly with React
on the same fixture. The eXact Node artifact matches frozen direct-map-current.mjs byte for byte,
SHA-256 8c8c3cd2e5f383755dc95e0dae347e39e2bd1551e85ad483131c1e34dc3d8b42.

Thirty-two fresh processes: Node/Bun, string/consumed stream, three/96 incidents, two reversed-order
pairs per cell. NODE_ENV=production, 5,000 warmups and 12,000 measured renders per population.
Both participants receive identical document options containing two module scripts and two
stylesheet links. The existing Document implementations parse these options and render their
own complete shells. The worker verifies full document framing and all four asset URLs. Repeated
populations preserve each framework's full-body hash. Framework output hashes are not expected
to match each other because hydration and framework markup differ.

This uses each framework's Node-target participant artifact on both runtimes and consumes streams
with Response.text(). It measures renderer completion, not runtime-specific HTTP adapter capacity,
asset fetches, browser startup, or early-shell latency. It is deliberately separate from the prior
empty-tag HTTP comparison. No fixture-specific production code was introduced.

## Results

Median microseconds per render, lower is better. Positive time difference means eXact took longer.
These are medians of two local populations, not confidence intervals. There was visible variability,
particularly Node small strings and Bun large strings; raw populations remain included.

| Runtime | Output | Fixture | eXact microseconds | React microseconds | eXact time difference |
| --- | --- | --- | ---: | ---: | ---: |
'''+table+'''

React leads string rendering on both runtimes and both sizes. eXact leads Node stream completion;
the small-document margin is much narrower than the historical empty-tag HTTP comparison. React
leads Bun stream completion in this run. The latest retained optimization has not closed these gaps.

Populated asset lists reveal an important additional workload for ongoing experiments. The next
investigation should isolate the cost of each shell list and its generated operations, comparing
zero/one/several entries in the same run. Cross-capture absolute differences cannot establish the
incremental asset cost because workstation load and measurement scopes differ.

No production changes were made for this comparison. The retained map build previously passed
283 SSR tests and 56 browser correctness checks, documented in direct-map-2026-09-09.md. This run
adds full document and asset-presence checks, not new browser timing. Historical public benchmark
charts are unchanged. All worker processes exited.

The evidence archive preserves both participant artifacts, fixed input, runner, worker, raw results,
reporter, dependency versions, and a SHA-256 manifest. Reproduction requires locked dependencies.
'''
dest.with_suffix('.md').write_text(doc,encoding='utf-8')
files=[work/n for n in ['direct-map-current.mjs','assets-comparison-worker.mjs','assets-comparison-run.mjs','assets-comparison-results.json','assets-comparison-report.py','direct-map-worker.mjs']]+[root/'.tmp/positional-leaves/data.json',root/'framework-comparison/participants/react/dist-server/server-entry.js',root/'framework-comparison/node_modules/react/package.json',root/'framework-comparison/node_modules/react-dom/package.json',dest.with_suffix('.md'),dest.with_suffix('.json')]
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps({p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(table);print('Verified',archive)
