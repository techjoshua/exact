export class BunRequestGate { observeRequest() {} shouldSchedule() { return true; } }
