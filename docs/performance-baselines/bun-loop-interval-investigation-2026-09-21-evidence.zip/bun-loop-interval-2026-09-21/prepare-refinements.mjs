import {cpSync,readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/bun-loop-interval-2026-09-21';
for(const [name,base] of [['interval-stable','interval'],['budget-one','budget']]){
 cpSync(`${dir}/${base}`,`${dir}/${name}`,{recursive:true});
 const path=`${dir}/${name}/adaptive-gate.js`;let code=readFileSync(path,'utf8');
 code=name==='interval-stable'?code.replace('this.average>2','this.average>1').replace('this.average<.75','this.average<.25'):code.replace('this.started>=2','this.started>=1');
 writeFileSync(path,code);
 writeFileSync(`${dir}/${name}-worker.mjs`,readFileSync(`${dir}/${base}-worker.mjs`,'utf8').replace(`'./${base}/index.js'`,`'./${name}/index.js'`));
 for(const kind of ['matrix','demand'])writeFileSync(`${dir}/${name}-${kind}.mjs`,readFileSync(`${dir}/${base}-${kind}.mjs`,'utf8').replaceAll(`/${base}-worker.mjs`,`/${name}-worker.mjs`).replace(`resolve('${dir}/${base}')`,`resolve('${dir}/${name}')`));
}
let run=readFileSync(dir+'/demand-run.mjs','utf8').replace("['current','interval','budget']","['interval-stable','budget-one']").replaceAll("demand-execution.json","refinement-execution.json");
writeFileSync(dir+'/refinement-run.mjs',run);
