import json
from pathlib import Path
p=Path(__file__).parent
rows=[]
for file in sorted(list(p.glob('confirm-*.json'))+list(p.glob('trace-demand-10000-*.json'))):
 s=json.loads(file.read_text())
 if not isinstance(s,dict) or s.get('kind')!='multi-driver-preloaded-ssr' or not s.get('complete'):continue
 row={'name':file.stem,'renderMode':s['renderMode'],'rates':{},'stages':[]}
 for b in s['blocks']:
  for i,st in enumerate(b['results'][0]['stages']):
   if s['plan']['stages'][i].get('discard'):continue
   ss=[r['stages'][i] for r in b['results']]
   total=lambda key:sum(x[key] for x in ss)
   misses=total('missedCapacity')+total('missedLag')+total('missedDeadline')
   row['rates'].setdefault(st['name'],{})[b['id']]=total('validRps')
   row['stages'].append({'framework':b['id'],'name':st['name'],'validRps':total('validRps'),'misses':misses,'missPercent':100*misses/total('offered') if total('offered') else 0,'errors':total('errors'),'invalid':total('invalid'),'responseP99RangeMs':[min(x['distributions']['responseMs']['p99'] for x in ss),max(x['distributions']['responseMs']['p99'] for x in ss)]})
 rows.append(row)
(p/'confirm-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:
 print(r['name'],r['renderMode'])
 for s in r['stages']: print(s['framework'],s['name'],round(s['validRps']),round(s['missPercent'],3),s['responseP99RangeMs'])
