import {readFile,writeFile} from 'node:fs/promises';
const root=import.meta.dirname,steps=JSON.parse(await readFile(root+'/matched-execution.json','utf8'));
if(steps.length!==5||!steps.every(s=>s.code===0))throw Error('Matched sequence incomplete');
const cases=[];
for(const step of steps.filter(s=>s.name.startsWith('matched-string-'))){
 const capture=JSON.parse(await readFile(root+'/'+step.name+'.json','utf8'));const rates={};let errors=0,invalid=0;
 for(const block of capture.blocks)for(const result of block.results)for(const stage of result.stages){
  errors+=stage.errors;invalid+=stage.invalid;
  if(stage.discard)continue;
  const row=rates[stage.name]??={};row[block.id]=(row[block.id]??0)+stage.validRps;
 }
 cases.push({name:step.name,errors,invalid,rates});
}
const mean=a=>a.reduce((x,y)=>x+y,0)/a.length;
const rows=Object.keys(cases[0].rates).map(stage=>{
 const sample=variant=>cases.filter(c=>c.name.endsWith('-'+variant)).map(c=>({...c.rates[stage],ratio:c.rates[stage].exact/c.rates[stage].react}));
 const before=sample('current'),after=sample('budget-guarded');
 return {stage,before,after,absolutePercent:100*(mean(after.map(r=>r.exact))/mean(before.map(r=>r.exact))-1),ratioPercent:100*(mean(after.map(r=>r.ratio))/mean(before.map(r=>r.ratio))-1)};
});
await writeFile(root+'/matched-summary.json',JSON.stringify({cases,rows},null,2)+'\n');
console.log(JSON.stringify(rows,null,2));
