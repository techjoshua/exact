import {spawn} from 'node:child_process';import {openSync,closeSync,writeFileSync,readFileSync} from 'node:fs';
const dir='.tmp/bun-loop-interval-2026-09-21',journal=[];
const previous=JSON.parse(readFileSync(dir+'/screen-execution.json'));if(previous.length!==10||!previous.every(s=>s.code===0))throw Error('Screen still active');
for(const variant of ['current','interval','budget']){
 const name=`demand-${variant}-8000`,args=[`${dir}/${variant}-demand.mjs`,`${dir}/demand-8000.json`,`${dir}/${name}.json`,'bun'];
 const step={name,args,startedAt:new Date().toISOString()};journal.push(step);const save=()=>writeFileSync(dir+'/demand-execution.json',JSON.stringify(journal,null,2));save();console.log('START',name);const fd=openSync(dir+'/'+name+'.log','w');
 try{await new Promise((done,fail)=>{const p=spawn(process.execPath,args,{env:{...process.env,COMPARISON_SSR_RENDER_MODE:'string'},stdio:['ignore',fd,fd]});step.pid=p.pid;save();p.once('error',fail);p.once('exit',code=>{step.code=code;code===0?done():fail(Error(name+' '+code));});});}finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}console.log('DONE',name);
}
