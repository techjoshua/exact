# Focused Bun scheduler evidence

Production source revision: cbf96b235efcf106beb3d4c75a2e41b99623e775. No candidate was adopted.

Read the published bun-loop-interval-investigation-2026-09-21.md for the final outcome. investigation.md contains chronological working notes with intermediate hypotheses and plans, not the final decision. Raw report complete flags and execution journals identify measured cases. Generated variants without a corresponding completed capture are unmeasured. double-queue-large-current.json was interrupted and is excluded. work-budget.candidate.ts and rejected-fixed-window-production.patch were not adopted. No full benchmark was run.

Runners expect extraction to .tmp/bun-loop-interval-2026-09-21 within the original repository revision, built workspace participants, Bun 1.4.2, and Node v26.9.0. Run timing serially in a fresh private Linux loopback namespace. The invocation shape is:

```sh
unshare --user --map-root-user --net --pid --fork --mount-proc --kill-child=SIGKILL bash -c 'ip link set lo up && node .tmp/bun-loop-interval-2026-09-21/current-matrix.mjs .tmp/bun-loop-interval-2026-09-21/matched-plan.json /tmp/current-repeat.json bun'
```

Set COMPARISON_SSR_RENDER_MODE to string or stream explicitly. The archived run scripts preserve exact case order and prerequisites; executing all scripts indiscriminately is not a reproduction recipe. Node/Bun must already be on PATH. The archive includes copied experimental adapter modules and source maps, not only final-result prose.
