import {performance} from 'node:perf_hooks';
import {setImmediate} from 'node:timers';
export class BunRequestGate {
 pending; requests=0; previous; stopped=-Infinity; average=0; enabled=false;
 observeRequest(){
  this.requests++;
  if(!this.pending){
   if(performance.now()-this.stopped>250){this.average=0;this.enabled=false;}
   this.previous=undefined;
   this.pending=setImmediate(()=>this.tick());
  }
 }
 shouldSchedule(){return this.enabled;}
 tick(){
  this.pending=undefined;
  const now=performance.now();
  if(this.previous!==undefined){
   this.average+=((now-this.previous)-this.average)*.125;
   if(this.average>1)this.enabled=true;
   else if(this.average<.25)this.enabled=false;
  }
  if(!this.requests){this.previous=undefined;this.stopped=now;return;}
  this.requests=0;this.previous=now;this.pending=setImmediate(()=>this.tick());
 }
}
