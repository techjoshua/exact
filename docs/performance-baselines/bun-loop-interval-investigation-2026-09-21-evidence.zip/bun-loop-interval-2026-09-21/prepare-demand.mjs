import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/bun-loop-interval-2026-09-21';
for(const variant of ['current','interval']){
 let runner=readFileSync(`${dir}/${variant}-matrix.mjs`,'utf8').replace("for(const id of population?['react','exact']:['exact','react'])", "for(const id of ['exact'])");
 writeFileSync(`${dir}/${variant}-demand.mjs`,runner);
}
writeFileSync(dir+'/demand-8000.json',JSON.stringify({preloaded:true,drivers:2,stages:[{name:'warm-target',mode:'arrival',rate:4000,durationMs:30000,discard:true},{name:'total-arrivals-8000',mode:'arrival',rate:4000,durationMs:60000}]}));
