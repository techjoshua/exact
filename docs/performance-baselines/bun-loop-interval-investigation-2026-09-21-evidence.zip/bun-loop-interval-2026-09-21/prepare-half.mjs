import {cpSync,readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/bun-loop-interval-2026-09-21',name='budget-half',base='budget';
cpSync(`${dir}/${base}`,`${dir}/${name}`,{recursive:true});
const path=`${dir}/${name}/adaptive-gate.js`;writeFileSync(path,readFileSync(path,'utf8').replace('this.started>=2','this.started>=0.5'));
writeFileSync(`${dir}/${name}-worker.mjs`,readFileSync(`${dir}/${base}-worker.mjs`,'utf8').replace(`'./${base}/index.js'`,`'./${name}/index.js'`));
for(const kind of ['matrix','demand'])writeFileSync(`${dir}/${name}-${kind}.mjs`,readFileSync(`${dir}/${base}-${kind}.mjs`,'utf8').replaceAll(`/${base}-worker.mjs`,`/${name}-worker.mjs`).replace(`resolve('${dir}/${base}')`,`resolve('${dir}/${name}')`));
