import {spawn} from 'node:child_process';import {openSync,closeSync,writeFileSync,readFileSync} from 'node:fs';
const dir='.tmp/bun-loop-interval-2026-09-21',journal=[];
const previous=JSON.parse(readFileSync(dir+'/refinement-execution.json'));if(previous.length!==2||!previous.every(s=>s.code===0))throw Error('Refinement still active');
const cases=[
 ['repeat-demand-budget-8000','budget-demand','demand-8000','string'],
 ['repeat-demand-current-8000','current-demand','demand-8000','string'],
 ['screen-budget-preloaded','budget-matrix','matrix-preloaded','stream'],
 ['screen-budget-normal','budget-matrix','matrix-normal','stream']
];
for(const [name,runner,plan,mode] of cases){
 const args=[`${dir}/${runner}.mjs`,`${dir}/${plan}.json`,`${dir}/${name}.json`,'bun'];
 const step={name,args,mode,startedAt:new Date().toISOString()};journal.push(step);const save=()=>writeFileSync(dir+'/final-check-execution.json',JSON.stringify(journal,null,2));save();console.log('START',name);const fd=openSync(dir+'/'+name+'.log','w');
 try{await new Promise((done,fail)=>{const p=spawn(process.execPath,args,{env:{...process.env,COMPARISON_SSR_RENDER_MODE:mode},stdio:['ignore',fd,fd]});step.pid=p.pid;save();p.once('error',fail);p.once('exit',code=>{step.code=code;code===0?done():fail(Error(name+' '+code));});});}finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}console.log('DONE',name);
}
