import {spawn} from 'node:child_process';import {openSync,closeSync,writeFileSync,readFileSync} from 'node:fs';
const dir='.tmp/bun-loop-interval-2026-09-21',journal=[];
const previous=JSON.parse(readFileSync(dir+'/attribution-execution.json'));if(previous.length!==5||!previous.every(s=>s.code===0))throw Error('Previous timing still active');
const cases=[
 ['short-guarded-control-string','current-matrix','matrix-preloaded','string'],
 ...['string'].flatMap(mode=>['budget-guarded-inline','budget-guarded-quarter','budget-guarded-eighth'].map(v=>[`short-${v}-${mode}`,`${v}-matrix`,'matrix-preloaded',mode]))
];
for(const [name,runner,plan,mode] of cases){
 const args=[`${dir}/${runner}.mjs`,`${dir}/${plan}.json`,`${dir}/${name}.json`,'bun'];
 const step={name,args,mode,startedAt:new Date().toISOString()};journal.push(step);const save=()=>writeFileSync(dir+'/short-guarded-execution.json',JSON.stringify(journal,null,2));save();console.log('START',name);const fd=openSync(dir+'/'+name+'.log','w');
 try{await new Promise((done,fail)=>{const p=spawn(process.execPath,args,{env:{...process.env,COMPARISON_SSR_RENDER_MODE:mode},stdio:['ignore',fd,fd]});step.pid=p.pid;save();p.once('error',fail);p.once('exit',code=>{step.code=code;code===0?done():fail(Error(name+' '+code));});});}finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}console.log('DONE',name);
}
