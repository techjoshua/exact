export class BunRequestGate { observeRequest() {} shouldSchedule() { return false; } }
