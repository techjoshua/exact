import {spawn} from 'node:child_process';import {openSync,closeSync,writeFileSync} from 'node:fs';
const dir='.tmp/bun-loop-interval-2026-09-21',journal=[];
for(const variant of ['immediate','scheduled','current'])for(const lane of ['preloaded','normal']){
 const name=`probe-${variant}-${lane}`,args=[`${dir}/${variant}-probe-matrix.mjs`,`${dir}/probe-${lane}.json`,`${dir}/${name}.json`,'bun'];
 const step={name,args,startedAt:new Date().toISOString()};journal.push(step);const save=()=>writeFileSync(dir+'/probe-execution.json',JSON.stringify(journal,null,2));save();console.log('START',name);const fd=openSync(dir+'/'+name+'.log','w');
 try{await new Promise((done,fail)=>{const p=spawn(process.execPath,args,{env:{...process.env,COMPARISON_SSR_RENDER_MODE:'stream'},stdio:['ignore',fd,fd]});step.pid=p.pid;save();p.once('error',fail);p.once('exit',code=>{step.code=code;code===0?done():fail(Error(name+' '+code));});});}finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}console.log('DONE',name);
}
