import json
from pathlib import Path
from statistics import mean
p=Path(__file__).parent
rows=[]
for prefix in ['matched-string','repeat-matched-string']:
 for file in sorted(p.glob(prefix+'-*.json')):
  s=json.loads(file.read_text())
  if not s['complete']:continue
  rates={};errors=0
  for b in s['blocks']:
   for i,st in enumerate(b['results'][0]['stages']):
    errors+=sum(r['stages'][i]['errors'] for r in b['results'])
    if s['plan']['stages'][i].get('discard'):continue
    rates.setdefault(st['name'],{})[b['id']]=sum(r['stages'][i]['validRps'] for r in b['results'])
  rows.append(dict(name=file.stem,variant='current' if file.stem.endswith('current') else 'guarded',rates=rates,errors=errors))
changes={}
for group in ['first','repeat','combined']:
 selected=[r for r in rows if group=='combined' or (r['name'].startswith('repeat-')==(group=='repeat'))]
 if not selected:continue
 changes[group]={}
 for stage in selected[0]['rates']:
  values={v:[r['rates'][stage] for r in selected if r['variant']==v] for v in ['current','guarded']}
  if not all(values.values()):continue
  changes[group][stage]={'ratioChangePercent':100*(mean(r['exact']/r['react'] for r in values['guarded'])/mean(r['exact']/r['react'] for r in values['current'])-1),'absoluteChangePercent':100*(mean(r['exact'] for r in values['guarded'])/mean(r['exact'] for r in values['current'])-1)}
print(json.dumps(changes,indent=2))
(p/'combined-matched-summary.json').write_text(json.dumps(dict(cases=rows,changes=changes),indent=2)+'\n')
