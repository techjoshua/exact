import {spawn} from 'node:child_process';import {openSync,closeSync,writeFileSync,readFileSync} from 'node:fs';
const dir='.tmp/bun-loop-interval-2026-09-21',journal=[];
const previous=JSON.parse(readFileSync(dir+'/final-check-execution.json'));if(previous.length!==4||!previous.every(s=>s.code===0))throw Error('Previous timing still active');
const arrival=JSON.parse(readFileSync(dir+'/demand-8000.json'));for(const stage of arrival.stages){stage.rate=5000;if(!stage.discard)stage.name='total-arrivals-10000';}writeFileSync(dir+'/demand-10000.json',JSON.stringify(arrival));
const cases=[
 ...['current','budget','budget','current'].map((v,i)=>[`repeat-stream-${i}-${v}`,`${v}-matrix`,'matrix-preloaded','stream']),
 ['string-preloaded-current','current-matrix','matrix-preloaded','string'],
 ['string-preloaded-budget','budget-matrix','matrix-preloaded','string'],
 ['string-normal-budget','budget-matrix','matrix-normal','string'],
 ['string-normal-current','current-matrix','matrix-normal','string'],
 ['demand-budget-10000','budget-demand','demand-10000','string'],
 ['demand-current-10000','current-demand','demand-10000','string']
];
for(const [name,runner,plan,mode] of cases){
 const args=[`${dir}/${runner}.mjs`,`${dir}/${plan}.json`,`${dir}/${name}.json`,'bun'];
 const step={name,args,mode,startedAt:new Date().toISOString()};journal.push(step);const save=()=>writeFileSync(dir+'/verification-execution.json',JSON.stringify(journal,null,2));save();console.log('START',name);const fd=openSync(dir+'/'+name+'.log','w');
 try{await new Promise((done,fail)=>{const p=spawn(process.execPath,args,{env:{...process.env,COMPARISON_SSR_RENDER_MODE:mode},stdio:['ignore',fd,fd]});step.pid=p.pid;save();p.once('error',fail);p.once('exit',code=>{step.code=code;code===0?done():fail(Error(name+' '+code));});});}finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}console.log('DONE',name);
}
