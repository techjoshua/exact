import {performance} from 'node:perf_hooks';
import {setImmediate} from 'node:timers';
const limits=[.05,.1,.25,.5,1,2,3,4,5,8,12,20,32,64,128,Infinity];
let pending,requests=0,previous;
let count=0,total=0,max=0,callbacks=0,restarts=0,buckets=limits.map(()=>0);
export function observeImmediateInterval(){
 requests++;
 if(!pending){previous=undefined;restarts++;pending=setImmediate(tick);}
}
function tick(){
 pending=undefined;callbacks++;
 const now=performance.now();
 if(previous!==undefined){const ms=now-previous;count++;total+=ms;max=Math.max(max,ms);buckets[limits.findIndex(limit=>ms<=limit)]++;}
 if(!requests){previous=undefined;return;}
 requests=0;previous=now;pending=setImmediate(tick);
}
export function readImmediateIntervals(){
 const value={count,total,max,callbacks,restarts,limits:limits.map(x=>Number.isFinite(x)?x:null),buckets};
 count=total=max=callbacks=restarts=0;buckets=limits.map(()=>0);return value;
}
