# Bun callback-interval and work-budget experiments, September 21, 2026

The user proposed measuring intervals between successive setImmediate callbacks as a simpler event-loop pressure signal. These experiments keep the production source at cbf96b23 and use copied adapter modules against unchanged workspace-resolved 0.6.0 participant builds. All timing is serial in private Linux loopback namespaces. Experimental adapter hashes are recorded separately from the installed workspace adapter. These are focused diagnostic populations, not replacement public chart captures.

## Controllers

- current: unchanged production controller, including independent timer histogram, native departure rate, thread CPU headroom, and policy trials.
- immediate: no observation and no scheduled admission.
- scheduled: no observation; every admission/checkpoint yields through the existing scheduler.
- scheduled-bookkeeping: unchanged observation and policy bookkeeping, but shouldSchedule always returns true. Compared with scheduled, this holds the visible scheduling policy fixed.
- interval: one self-rescheduling immediate probe while arrivals continue, with an exponential moving average (weight 1/8), enable above 2 ms and disable below 0.75 ms. Idle gaps are excluded; more than 250 ms quiet resets policy state.
- interval-stable: enable above 1 ms and disable below 0.25 ms.
- budget: a single pending immediate callback marks a request/SSR work window. Checks stay immediate until 2 ms have elapsed since that window began. The marker ends the window; the next request or continuation starts a fresh one. No histogram, native counter, CPU accounting, backoff, or policy trial is used.
- budget-one / budget-middle / budget-half: same work-window mechanism with 1 / 1.5 / 0.5 ms limits. A generated variant is not evidence of a measurement; only raw captures identify tested cases.

The existing bounded queue, cancellation, rendering, and native response-body ownership remain unchanged in every variant. These prototypes are JavaScript experiment copies, not production implementations.

## Initial probe

The independent diagnostic probe records intervals between consecutive callbacks, excluding the first enqueue-to-callback measurement and idle gaps. Probe summaries pool the warmup and measured stages. Preloaded streaming spans c16 warmup, c32, and c128; normal loading uses c32 after warmup.

Immediate preloaded streaming averaged 4.944 ms between callbacks; always-scheduled operation averaged 2.121 ms. Normal-loading averages were 0.119 ms and 0.391 ms. The diagnostic probe itself ran about 4,007 callbacks per second in immediate normal loading, versus about 202 in preloaded streaming. A smaller controller can therefore run more callbacks than the existing 500 Hz timer observer. Probe timings remain diagnostic; subsequent capacity captures omit that extra instrumentation.

## First capacity screen

Each case owns fresh worker/service/driver processes, uses two drivers and exact response identity validation, and includes eXact and React. Preloaded cases use 10 seconds of c16 warmup and 20 seconds each at c32/c128. Normal loading uses 10 seconds of warmup and 20 seconds at c32. Individual cases are one population and do not establish confidence intervals.

The interval controller changed the eXact/React ratio by approximately −2.2% at streaming c32, +2.1% at c128, and −0.6% with normal loading. Removing all bookkeeping while always scheduling did not reveal a large throughput benefit. Always-scheduled c32 measured 7,782 RPS without bookkeeping and 8,035 with it; normal-loading absolute throughput was 4,378 versus 4,370. Individual controls vary, so these are not claims that bookkeeping increases performance. Disabling scheduling entirely reduced streaming c32 to 6,937 RPS versus 7,865 for the current controller.

## Offered demand

At 8,000 offered RPS (30 seconds warmup, 60 seconds measured, two drivers), the current policy initially measured p99 12.431–12.615 ms. Interval-only measured 21.327–21.359 ms; lower interval thresholds measured 16.015–16.087 ms. The 2 ms work budget measured 14.391–14.599 ms; a 1 ms budget measured 15.503–15.575 ms. All kept up with offered demand without request errors.

The reversed repeat measured 13.895–14.135 ms for the 2 ms budget and 14.863–15.127 ms for the current policy. Their combined ranges overlap; the first pair alone overstated a latency difference. Each range spans individual driver percentiles, not a pooled percentile or confidence interval. Deadline and capacity misses remain in raw captures.

## Two-millisecond budget capacity

The initial budget screen measured 8,602 RPS at streaming c32 and 8,459 at c128. An additional current/budget/budget/current sequence reproduced the improvement: mean absolute eXact throughput changed by +11.27% at c32 and +24.37% at c128; mean eXact/React ratios changed by +10.44% and +22.37%. See repeat-stream-summary.json for each run.

However, the same setting reduced preloaded string c32 from 13,253 to 10,948 RPS, while improving string c128 from 12,153 to 13,234. Normal-loading string remained close (4,586 versus 4,617). The 2 ms setting therefore cannot replace the current policy unchanged. Weaker c16 warmup also prompted separate measured low-concurrency tests. Shorter work budgets are being evaluated before any production adoption.

## Shorter work windows

The measured low-concurrency sweep used 10 seconds of warmup at c16, then 20 seconds each at c16/c32/c128, with two drivers and both frameworks. eXact absolute RPS was:

| Work window | Streaming c16 | Streaming c32 | Streaming c128 |
| --- | ---: | ---: | ---: |
| Current controller | 7,201 | 7,620 | 6,856 |
| 2 ms | 6,987 | 8,686 | 8,499 |
| 1 ms | 7,934 | 10,371 | 7,831 |
| 0.5 ms | 9,813 | 11,051 | 8,150 |

The corresponding string screen measured current 13,273/12,000 RPS at c32/c128, 1 ms 12,851/12,964, and 0.5 ms 14,224/12,636. All requests in these cases passed response validation without errors. See low-summary.json for React controls and ratios. These are screening observations, not yet repeated estimates. The half-millisecond setting proceeds to repeat, normal-loading, larger-document, and offered-demand checks; the unmeasured 1.5 ms variant is not used to select it.

## Larger-document guard

The larger fixture expands the same current participant data to 96 unique rows for both frameworks. It does not reuse the obsolete Windows builds. Exact response identity is validated against a fresh response from each worker, and the worker source is retained with the capture.

The half-millisecond window regressed large string throughput: current 2,422/2,451 RPS at c32/c128, versus 2,001/1,997 for the candidate. Large streaming was 1,795/1,737 versus 1,939/1,728. Consequently the initial fixed-window implementation is not accepted unchanged despite its small-document gains.

The pooled large-string render telemetry includes scheduling waits: the current controller recorded 135,658 total render milliseconds for 120,764 requests, versus 1,224,410 milliseconds for 100,212 candidate requests. These overlapping handler durations are not CPU time. They motivate separating initial Fetch admission from SSR checkpoint admission in diagnostic controls.

The next copied-adapter prototypes include admission-only and checkpoint-only controls, plus a one-use admission credit for the first SSR checkpoint within the same immediate-marker window. Credits expire when the marker closes and do not bypass cancellation or later readiness checks. The two controls are diagnostic, not proposals to remove SSR resumption scheduling or generic Fetch admission from the public adapter.

## Additional controls and protocol correction

The admission-credit candidate did not recover large-string throughput (2,023/2,002 RPS at c32/c128). Checkpoint-only admission measured 2,050/2,117, and Fetch-only admission measured 1,978/2,013. Removing one scheduling boundary therefore did not establish duplicate scheduling as the cause. The remaining credit cases were stopped after these three completed cases. The interrupted current-control case is retained as incomplete and is not a result.

A guarded prototype retains the existing trial controller and applies the half-millisecond budget only while scheduling is selected. Its initial larger-string screen recovered 2,401/2,416 RPS against a fresh current control of 2,463/2,454. Larger streaming measured 1,871/1,751. Its small-string sweep measured 12,413/11,681 at c32/c128, while streaming measured 10,556/7,690. These initial string figures must not be compared directly with shorter prior screens: the guarded sweep included a measured c16 stage, moving its periodic reassessment into a different concurrency stage. All production draft edits were restored; no new implementation has been accepted.

The guarded candidate's fresh 8,000-RPS case measured p99 14.695–14.951 ms. Its 10,000-RPS case missed offered arrivals. Those observations require fresh matched controls before being attributed to the policy, because later bare-budget and React controls also measured lower absolute capacity.

A same-policy bookkeeping control measured string 12,167/11,790 RPS with the existing observation active but budget decisions forced, versus 12,407/11,538 without observation. React controls measured 10,149/11,067 and 10,527/10,978 respectively. The controller-enabled version's ratios were slightly higher, so this pair does not support a large net monitoring penalty. Earlier speculation that the monitor itself caused the guarded loss is not established by these controls.

A diagnostic guarded trace at constant c32 selected the budget for 29 of 32 one-second snapshots. A larger-string trace rejected it and spent 25 snapshots in the immediate baseline, with three trial, two after-control, and two settling snapshots. These traces are not the staged sweep that exposed the initial string difference. A new trace and current/guarded/guarded/current comparison use the same 10-second c16 warmup and 15-second c16/c32/c64/c128 sequence as the full publication protocol. The latter half reverses framework order. These results, rather than mismatched stage placement, will determine whether the guarded policy regresses string rendering.

Prepared quarter-millisecond, eighth-millisecond, and inlined guarded variants have not been measured. Their files are preparation artifacts, not evidence of results.

## Matched staged comparison and finer windows

The first matched current/guarded/guarded/current string sequence completed without request errors or invalid responses. Mean per-run eXact/React ratios changed by −1.35% at c16, +1.83% at c32, −1.62% at c64, and +4.91% at c128. Absolute eXact throughput increased at all four levels, but React also improved. The ratio comparison therefore does not establish an improvement at every level. See matched-summary.json. A reversed guarded/current/current/guarded sequence is running before acceptance.

The matched guarded diagnostic trace selected scheduling after about three seconds, then reassessed around seconds 33–35, 42–44, and 57–59. Stage changes as well as the periodic deadline affect decisions. Constant-c32 traces cannot substitute for staged controls.

Pure 0.25 ms and 0.125 ms windows were then tested on the larger string document, alongside fresh current and always-scheduled controls. Both shorter windows still regressed relative throughput substantially. The always-scheduled control also regressed. See finer-summary.json for exact rates and ratios. Thus shortening the fixed work window does not remove the larger-document tradeoff, and the pure-budget production draft remains rejected. The guarded quarter/eighth and inline variants remain unmeasured.
