import {cpSync,readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/bun-loop-interval-2026-09-21';
cpSync(dir+'/current',dir+'/budget',{recursive:true});
writeFileSync(dir+'/budget/adaptive-gate.js',`import {performance} from 'node:perf_hooks';
import {setImmediate} from 'node:timers';
export class BunRequestGate {
 pending; started=0;
 markTurn(){
  if(this.pending)return;
  this.started=performance.now();
  this.pending=setImmediate(()=>{this.pending=undefined;});
 }
 observeRequest(){this.markTurn();}
 shouldSchedule(){this.markTurn();return performance.now()-this.started>=2;}
}
`);
writeFileSync(dir+'/budget-worker.mjs',readFileSync(dir+'/current-worker.mjs','utf8').replace("'./current/index.js'","'./budget/index.js'"));
let runner=readFileSync(dir+'/current-matrix.mjs','utf8').replaceAll('/current-worker.mjs','/budget-worker.mjs').replace("resolve('"+dir+"/current')","resolve('"+dir+"/budget')");
writeFileSync(dir+'/budget-matrix.mjs',runner);
writeFileSync(dir+'/budget-demand.mjs',runner.replace("for(const id of population?['react','exact']:['exact','react'])", "for(const id of ['exact'])"));
let run=readFileSync(dir+'/demand-run.mjs','utf8').replace("for(const variant of ['current','interval']){", "for(const variant of ['current','interval','budget']){");
writeFileSync(dir+'/demand-run.mjs',run);
