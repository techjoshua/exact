import { performance } from 'node:perf_hooks';
import { setImmediate } from 'node:timers';

/**
 * Bounds immediate work within a selected Bun admission policy. The first check opens
 * a half-millisecond window, closed by one immediate callback. This is an elapsed-work
 * window, not a native event-loop iteration or a response deadline. Inactive policies
 * do not call this gate, and the marker never schedules itself again after traffic stops.
 */
export class BunWorkBudget {
	private pending: ReturnType<typeof setImmediate> | undefined;
	private started = 0;

	/** Requests a bounded-queue yield once the current active work window is exhausted. */
	shouldSchedule(): boolean {
		this.markWindow();
		return performance.now() - this.started >= 0.5;
	}

	/** Requests and SSR continuations share one marker until its callback runs. */
	private markWindow(): void {
		if (this.pending) return;
		this.started = performance.now();
		this.pending = setImmediate(() => {
			this.pending = undefined;
		});
	}
}
