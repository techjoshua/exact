import {performance} from 'node:perf_hooks';
import {setImmediate} from 'node:timers';
export class BunWorkBudget {
 pending; started=0; checks=0; bypasses=0; windows=0;
 markTurn(){
  if(this.pending)return;
  this.started=performance.now();
  this.pending=setImmediate(()=>{this.pending=undefined; this.windows++;});
 }
 observeRequest(){this.markTurn();}
 shouldSchedule(){this.markTurn();this.checks++;const schedule=performance.now()-this.started>=0.5;if(!schedule)this.bypasses++;return schedule;}
}
