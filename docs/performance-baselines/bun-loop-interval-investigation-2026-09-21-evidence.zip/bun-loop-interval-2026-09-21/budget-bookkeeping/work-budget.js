import {performance} from 'node:perf_hooks';
import {setImmediate} from 'node:timers';
export class BunWorkBudget {
 pending; started=0;
 markTurn(){
  if(this.pending)return;
  this.started=performance.now();
  this.pending=setImmediate(()=>{this.pending=undefined;});
 }
 observeRequest(){this.markTurn();}
 shouldSchedule(){this.markTurn();return performance.now()-this.started>=0.5;}
}
