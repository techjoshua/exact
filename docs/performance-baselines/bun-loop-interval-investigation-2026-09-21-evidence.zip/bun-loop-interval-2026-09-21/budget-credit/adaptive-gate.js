import {performance} from 'node:perf_hooks';
import {setImmediate} from 'node:timers';
export class BunRequestGate {
 pending; started=0; credits=new WeakMap();
 markTurn(){
  if(this.pending)return;
  this.started=performance.now();
  this.pending=setImmediate(()=>{this.pending=undefined;});
 }
 observeRequest(){this.markTurn();}
 grantAdmission(signal){this.markTurn();this.credits.set(signal,this.pending);}
 shouldSchedule(signal){this.markTurn();if(signal){const marker=this.credits.get(signal);this.credits.delete(signal);if(marker===this.pending)return false;}return performance.now()-this.started>=0.5;}
}
