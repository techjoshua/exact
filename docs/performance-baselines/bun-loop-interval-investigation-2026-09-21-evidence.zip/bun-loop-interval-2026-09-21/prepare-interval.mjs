import {cpSync,readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/bun-loop-interval-2026-09-21';
cpSync(dir+'/current',dir+'/interval',{recursive:true});
writeFileSync(dir+'/interval/adaptive-gate.js',`import {performance} from 'node:perf_hooks';
import {setImmediate} from 'node:timers';
export class BunRequestGate {
 pending; requests=0; previous; stopped=-Infinity; average=0; enabled=false;
 observeRequest(){
  this.requests++;
  if(!this.pending){
   if(performance.now()-this.stopped>250){this.average=0;this.enabled=false;}
   this.previous=undefined;
   this.pending=setImmediate(()=>this.tick());
  }
 }
 shouldSchedule(){return this.enabled;}
 tick(){
  this.pending=undefined;
  const now=performance.now();
  if(this.previous!==undefined){
   this.average+=((now-this.previous)-this.average)*.125;
   if(this.average>2)this.enabled=true;
   else if(this.average<.75)this.enabled=false;
  }
  if(!this.requests){this.previous=undefined;this.stopped=now;return;}
  this.requests=0;this.previous=now;this.pending=setImmediate(()=>this.tick());
 }
}
`);
writeFileSync(dir+'/interval-worker.mjs',readFileSync(dir+'/current-worker.mjs','utf8').replace("'./current/index.js'","'./interval/index.js'"));
writeFileSync(dir+'/interval-matrix.mjs',readFileSync(dir+'/current-matrix.mjs','utf8').replaceAll('/current-worker.mjs','/interval-worker.mjs').replace("resolve('"+dir+"/current')","resolve('"+dir+"/interval')"));
const plan={preloaded:true,drivers:2,stages:[{name:'warmup',mode:'concurrency',concurrency:8,durationMs:10000,discard:true},{name:'total-c32',mode:'concurrency',concurrency:16,durationMs:20000},{name:'total-c128',mode:'concurrency',concurrency:64,durationMs:20000}]};
writeFileSync(dir+'/matrix-preloaded.json',JSON.stringify(plan));
writeFileSync(dir+'/matrix-normal.json',JSON.stringify({...plan,preloaded:false,stages:plan.stages.slice(0,2)}));
