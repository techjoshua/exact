import {spawn} from 'node:child_process';import {openSync,closeSync,writeFileSync,readFileSync} from 'node:fs';
const dir='.tmp/bun-loop-interval-2026-09-21',journal=[];
const previous=JSON.parse(readFileSync(dir+'/confirm-execution.json'));if(previous.length!==8||!previous.every(s=>s.code===0))throw Error('Previous timing still active');
const cases=[
 ...[8000,10000].flatMap(rate=>(rate===8000?['current','budget-guarded']:['budget-guarded','current']).map(v=>[`confirm-stream-demand-${rate}-${v}`,`${v}-demand`,`demand-${rate}`,'stream'])),
 ...['budget-guarded','current'].map(v=>[`trace-demand-10000-${v}`,`${v}-trace-demand`,'demand-10000','string'])
];
for(const [name,runner,plan,mode] of cases){
 const args=[`${dir}/${runner}.mjs`,`${dir}/${plan}.json`,`${dir}/${name}.json`,'bun'];
 const step={name,args,mode,startedAt:new Date().toISOString()};journal.push(step);const save=()=>writeFileSync(dir+'/trace-demand-execution.json',JSON.stringify(journal,null,2));save();console.log('START',name);const fd=openSync(dir+'/'+name+'.log','w');
 try{await new Promise((done,fail)=>{const p=spawn(process.execPath,args,{env:{...process.env,COMPARISON_SSR_RENDER_MODE:mode},stdio:['ignore',fd,fd]});step.pid=p.pid;save();p.once('error',fail);p.once('exit',code=>{step.code=code;code===0?done():fail(Error(name+' '+code));});});}finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}console.log('DONE',name);
}
