import {spawn} from 'node:child_process';import {openSync,closeSync,writeFileSync,readFileSync} from 'node:fs';
const dir='.tmp/bun-loop-interval-2026-09-21',journal=[];
const previous=JSON.parse(readFileSync(dir+'/low-execution.json'));if(previous.length!==7||!previous.every(s=>s.code===0))throw Error('Previous timing still active');
const cases=[
 ...['current','budget-half','budget-half','current'].map((v,i)=>[`half-repeat-stream-${i}-${v}`,`${v}-matrix`,'low-concurrency-plan','stream']),
 ['half-repeat-string-current','current-matrix','matrix-preloaded','string'],
 ['half-repeat-string-budget-half','budget-half-matrix','matrix-preloaded','string'],
 ...['stream','string'].flatMap(mode=>['budget-half','current'].map(v=>[`half-normal-${mode}-${v}`,`${v}-matrix`,'matrix-normal',mode])),
 ...['string','stream'].flatMap(mode=>['current','budget-half'].map(v=>[`half-large-${mode}-${v}`,`${v}-large-matrix`,'matrix-preloaded',mode])),
 ...[8000,10000].flatMap(rate=>['budget-half','current'].map(v=>[`half-demand-${v}-${rate}`,`${v}-demand`,`demand-${rate}`,'string']))
];
for(const [name,runner,plan,mode] of cases){
 const args=[`${dir}/${runner}.mjs`,`${dir}/${plan}.json`,`${dir}/${name}.json`,'bun'];
 const step={name,args,mode,startedAt:new Date().toISOString()};journal.push(step);const save=()=>writeFileSync(dir+'/half-verification-execution.json',JSON.stringify(journal,null,2));save();console.log('START',name);const fd=openSync(dir+'/'+name+'.log','w');
 try{await new Promise((done,fail)=>{const p=spawn(process.execPath,args,{env:{...process.env,COMPARISON_SSR_RENDER_MODE:mode},stdio:['ignore',fd,fd]});step.pid=p.pid;save();p.once('error',fail);p.once('exit',code=>{step.code=code;code===0?done():fail(Error(name+' '+code));});});}finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}console.log('DONE',name);
}
