import {spawn} from 'node:child_process';import {openSync,closeSync,writeFileSync,readFileSync} from 'node:fs';
const dir='.tmp/bun-loop-interval-2026-09-21',journal=[];
const previous=JSON.parse(readFileSync(dir+'/credit-execution.json'));if(previous.length!==4||!previous.slice(0,3).every(s=>s.code===0)||!previous[3].interrupted)throw Error('Previous timing still active');
const cases=[
 ['guarded-control-large-string','current-large-matrix','matrix-preloaded','string'],
 ['guarded-large-string','budget-guarded-large-matrix','matrix-preloaded','string'],
 ['guarded-large-stream','budget-guarded-large-matrix','matrix-preloaded','stream'],
 ...['string','stream'].map(mode=>[`guarded-preloaded-${mode}`,'budget-guarded-matrix','low-concurrency-plan',mode]),
 ...['string','stream'].map(mode=>[`guarded-normal-${mode}`,'budget-guarded-matrix','matrix-normal',mode]),
 ...[8000,10000].map(rate=>[`guarded-demand-${rate}`,'budget-guarded-demand',`demand-${rate}`,'string'])
];
for(const [name,runner,plan,mode] of cases){
 const args=[`${dir}/${runner}.mjs`,`${dir}/${plan}.json`,`${dir}/${name}.json`,'bun'];
 const step={name,args,mode,startedAt:new Date().toISOString()};journal.push(step);const save=()=>writeFileSync(dir+'/guarded-execution.json',JSON.stringify(journal,null,2));save();console.log('START',name);const fd=openSync(dir+'/'+name+'.log','w');
 try{await new Promise((done,fail)=>{const p=spawn(process.execPath,args,{env:{...process.env,COMPARISON_SSR_RENDER_MODE:mode},stdio:['ignore',fd,fd]});step.pid=p.pid;save();p.once('error',fail);p.once('exit',code=>{step.code=code;code===0?done():fail(Error(name+' '+code));});});}finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}console.log('DONE',name);
}
