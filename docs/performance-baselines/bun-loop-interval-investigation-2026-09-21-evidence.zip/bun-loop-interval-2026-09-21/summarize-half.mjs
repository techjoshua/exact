import {readFile,writeFile} from 'node:fs/promises';
const root=import.meta.dirname;
const steps=JSON.parse(await readFile(root+'/half-verification-execution.json','utf8'));
const cases=[];
for(const step of steps.filter(s=>s.code===0)){
 const capture=JSON.parse(await readFile(root+'/'+step.name+'.json','utf8'));
 const rows=new Map();let allErrors=0,allInvalid=0;
 for(const block of capture.blocks)for(const result of block.results)for(const stage of result.stages){
  allErrors+=stage.errors;allInvalid+=stage.invalid;
  if(stage.discard)continue;
  const key=block.id+'/'+stage.name;
  let row=rows.get(key);if(!row){row={framework:block.id,stage:stage.name,rps:0,errors:0,invalid:0,missedCapacity:0,missedLag:0,missedDeadline:0,p99:[]};rows.set(key,row);}
  for(const field of ['errors','invalid','missedCapacity','missedLag','missedDeadline'])row[field]+=stage[field];
  row.rps+=stage.validRps;row.p99.push(stage.distributions.responseMs.p99);
 }
 cases.push({name:step.name,allErrors,allInvalid,rows:[...rows.values()]});
}
const mean=xs=>xs.reduce((a,b)=>a+b,0)/xs.length;
const changes=[];
for(const stage of ['total-c16','total-c32','total-c128']){
 const group=variant=>cases.filter(c=>c.name.startsWith('half-repeat-stream-')&&c.name.endsWith('-'+variant)).map(c=>{const r=id=>c.rows.find(r=>r.stage===stage&&r.framework===id).rps;return{rps:r('exact'),ratio:r('exact')/r('react')};});
 const before=group('current'),after=group('budget-half');
 if(before.length===2&&after.length===2)changes.push({stage,before,after,absolutePercent:100*(mean(after.map(r=>r.rps))/mean(before.map(r=>r.rps))-1),ratioPercent:100*(mean(after.map(r=>r.ratio))/mean(before.map(r=>r.ratio))-1)});
}
const summary={completed:cases.length,cases,streamChanges:changes};
await writeFile(root+'/half-verification-summary.json',JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify({completed:cases.length,streamChanges:changes},null,2));
