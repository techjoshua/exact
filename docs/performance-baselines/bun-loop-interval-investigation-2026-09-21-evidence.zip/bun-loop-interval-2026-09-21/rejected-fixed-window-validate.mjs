import {spawn,execFileSync} from 'node:child_process';
import {openSync,closeSync,writeFileSync,readFileSync,rmSync} from 'node:fs';
import {resolve} from 'node:path';
const root=resolve('.'),dir=resolve('.tmp/bun-loop-interval-2026-09-21'),npm='/home/techj/.npm/_npx/3c6effcf97752e7c/node_modules/npm/bin/npm-cli.js',journal=[];
const previous=JSON.parse(readFileSync(dir+'/normal-repeat-execution.json'));if(previous.length!==2||!previous.every(s=>s.code===0))throw Error('Focused timing still active');
async function run(name,args,cwd=root){const step={name,args,cwd,startedAt:new Date().toISOString()};journal.push(step);const save=()=>writeFileSync(dir+'/validation-execution.json',JSON.stringify(journal,null,2));save();console.log('START',name);const fd=openSync(dir+'/'+name+'.log','w');try{await new Promise((done,fail)=>{const p=spawn(process.execPath,args,{cwd,stdio:['ignore',fd,fd]});step.pid=p.pid;save();p.once('error',fail);p.once('exit',code=>{step.code=code;code===0?done():fail(Error(name+' '+code));});});}finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}console.log('DONE',name);}
const changed=execFileSync('git',['diff','--name-only','--diff-filter=ACM'],{encoding:'utf8'}).trim().split('\n');
await run('format',['node_modules/prettier/bin/prettier.cjs','--write',...changed]);
for(const ext of ['js','js.map','d.ts','d.ts.map'])rmSync('framework-adapters/bun-adapter/dist/event-loop-observer.'+ext,{force:true});
await run('adapter-build',[npm,'run','build','-w','@exactjs/bun-adapter']);
await run('adapter-tests',[npm,'run','test','-w','@exactjs/bun-adapter']);
await run('native-adapter-tests',[npm,'run','test:bun','-w','@exactjs/bun-adapter']);
await run('ssr-scheduling-tests',[resolve('node_modules/vitest/vitest.mjs'),'run','src/render/resume-scheduling.test.ts','src/render/readiness-scheduling.test.ts','src/stream/early-document-head.test.ts'],resolve('packages/ssr'));
await run('package-contents',['scripts/check-package-contents.mjs']);
await run('platform-boundaries',['scripts/check-platform-boundaries.mjs']);
await run('docs-types',[npm,'run','typecheck','-w','@exactjs/docs']);
