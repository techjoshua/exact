import {cpSync,readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/bun-loop-interval-2026-09-21',old='.tmp/bun-admission-2026-09-20';
for(const variant of ['current','immediate','scheduled','scheduled-bookkeeping']) {
 cpSync('framework-adapters/bun-adapter/dist',dir+'/'+variant,{recursive:true});
 const path=dir+'/'+variant+'/adaptive-gate.js';
 if(variant==='immediate'||variant==='scheduled') writeFileSync(path,`export class BunRequestGate { observeRequest() {} shouldSchedule() { return ${variant==='scheduled'}; } }\n`);
 if(variant==='scheduled-bookkeeping')writeFileSync(path,readFileSync(path,'utf8').replace('return this.enabled;', 'return true;'));
 for(const probe of [false,true]){
  const name=variant+(probe?'-probe':'');
  let worker=readFileSync(old+'/control-clean-worker.mjs','utf8').replace("'./control-clean/index.js'",`'./${variant}/index.js'`);
  if(probe){
   worker=`import {BunRequestGate} from './${variant}/adaptive-gate.js';\nimport {observeImmediateInterval,readImmediateIntervals} from './probe.mjs';\nconst original=BunRequestGate.prototype.observeRequest;\nBunRequestGate.prototype.observeRequest=function(){observeImmediateInterval();return original.call(this);};\n`+worker;
   worker=worker.replace('function telemetry() {\n\treturn {','function telemetry() {\n\treturn {\n immediateIntervals: readImmediateIntervals(),');
  }
  writeFileSync(`${dir}/${name}-worker.mjs`,worker);
  let runner=readFileSync(old+'/production-matrix.mjs','utf8');
  runner=runner.replace("resolve('framework-comparison/src/ssr-benchmark-worker.mjs')",`resolve('${dir}/${name}-worker.mjs')`);
  runner=runner.replace("artifacts.experimentalAdapter = await measureSsrArtifact(resolve('framework-adapters/bun-adapter/dist'));",`artifacts.experimentalAdapter = await measureSsrArtifact(resolve('${dir}/${variant}'));`);
  if(probe)runner=runner.replace("for(const id of population?['react','exact']:['exact','react'])", "for(const id of ['exact'])");
  writeFileSync(`${dir}/${name}-matrix.mjs`,runner);
 }
}
writeFileSync(dir+'/probe-preloaded.json',JSON.stringify({preloaded:true,drivers:2,stages:[{name:'warmup',mode:'concurrency',concurrency:8,durationMs:8000,discard:true},{name:'total-c32',mode:'concurrency',concurrency:16,durationMs:20000},{name:'total-c128',mode:'concurrency',concurrency:64,durationMs:20000}]}));
writeFileSync(dir+'/probe-normal.json',JSON.stringify({preloaded:false,drivers:2,stages:[{name:'warmup',mode:'concurrency',concurrency:8,durationMs:8000,discard:true},{name:'total-c32',mode:'concurrency',concurrency:16,durationMs:20000}]}));
