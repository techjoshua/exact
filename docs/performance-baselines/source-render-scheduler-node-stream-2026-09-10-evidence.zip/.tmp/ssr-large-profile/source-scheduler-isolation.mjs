import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createNodeRenderScheduler} from '../../framework-adapters/node-adapter/dist/index.js';
const participant=await import(pathToFileURL(resolve('framework-comparison/participants/exact/dist-server/server-entry.js')));
const fixture=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));
const inputs=Array.from({length:16},(_,index)=>{
 const data=structuredClone(fixture);data.incidents[0].title+=' independent request '+index+' </script>';
 return {data,path:'/incidents/'+data.incidents[index%data.incidents.length].id};
});
const rows=[];
for(const mode of ['string','stream']){
 const render=async (input,scheduleRender)=>{
  const options={clientTags:'',scheduleRender};
  return mode==='string'?participant.renderParticipant(input.data,input.path,options):new Response(await participant.renderParticipantStream(input.data,input.path,options)).text();
 };
 const expected=[];for(const input of inputs)expected.push(await render(input));
 assert.equal(new Set(expected).size,16);
 let calls=0;const schedule=createNodeRenderScheduler();
 const actual=await Promise.all(inputs.map(input=>render(input,signal=>{++calls;return schedule(signal);})));
 assert.equal(calls,16);assert.deepEqual(actual,expected);
 rows.push({mode,distinctResponses:16,scheduleCalls:calls,allMatched:true});
}
await fs.writeFile('.tmp/ssr-large-profile/source-scheduler-stream/isolation.json',JSON.stringify(rows,null,2));
console.log(rows);
