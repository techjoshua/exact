import fs from 'node:fs/promises';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'source-scheduler-stream',{recursive:true});
let worker=(await fs.readFile(root+'source-scheduler/worker.mjs','utf8')).replaceAll('participant.renderOnly(10000)','participant.renderOnly(2000)');
await fs.writeFile(root+'source-scheduler-stream/worker.mjs',worker);
let runner=(await fs.readFile(root+'source-scheduler-run.mjs','utf8')).replaceAll('source-scheduler/','source-scheduler-stream/').replaceAll('actual-source-scheduler-node','actual-source-scheduler-node-stream');
function replaceOnce(from,to){if(!runner.includes(from))throw Error('Missing '+from);runner=runner.replace(from,to);}
replaceOnce("for(const mode of ['string'])","for(const mode of ['stream'])");
replaceOnce('population?[32,1]:[1,32]','[32]');
replaceOnce('report.blocks.length,16','report.blocks.length,8');
await fs.writeFile(root+'source-scheduler-stream-run.mjs',runner);
console.log('Built source Node streaming comparison');
