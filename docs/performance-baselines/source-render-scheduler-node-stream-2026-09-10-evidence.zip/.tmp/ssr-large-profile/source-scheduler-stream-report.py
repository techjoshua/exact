import hashlib,json,zipfile
from pathlib import Path
from statistics import mean
base=Path('.tmp/ssr-large-profile');folder=base/'source-scheduler-stream'
data=json.loads((folder/'capture.json').read_text());assert data['complete'] and len(data['blocks'])==8
isolation=json.loads((folder/'isolation.json').read_text());assert all(r['distinctResponses']==16 and r['allMatched'] for r in isolation)
def latency(b,key):
    ds=[r['stages'][0]['distributions'][key] for r in b['results']]
    return sum(d['mean']*d['count'] for d in ds)/sum(d['count'] for d in ds)
rows=[]
for population in (0,1):
    exact=[b for b in data['blocks'] if b['population']==population and b['id']=='exact']
    react=[b for b in data['blocks'] if b['population']==population and b['id']=='react']
    assert [b['phase'] for b in exact]==['normal','scheduled','normal'] and len(react)==1
    controls=[exact[0],exact[2]];candidate=exact[1];baseline=react[0]
    normal=mean(b['rps'] for b in controls)
    rows.append(dict(population=population+1,normalRps=normal,scheduledRps=candidate['rps'],reactRps=baseline['rps'],gainVsNormalPct=(candidate['rps']/normal-1)*100,gainVsReactPct=(candidate['rps']/baseline['rps']-1)*100,normalResponseMs=mean(latency(b,'responseMs') for b in controls),scheduledResponseMs=latency(candidate,'responseMs'),reactResponseMs=latency(baseline,'responseMs'),normalTtfbMs=mean(latency(b,'ttfbMs') for b in controls),scheduledTtfbMs=latency(candidate,'ttfbMs'),reactTtfbMs=latency(baseline,'ttfbMs')))
for b in data['blocks']:
    # Each load driver issues one identity preflight before its measured stage.
    assert b['after']['scheduleCalls']==(b['valid']+len(b['results']) if b['phase']=='scheduled' else 0)
    for k in ('loopBefore','loopAfter'):assert b[k]['scheduleCalls']==0
valid=sum(b['valid'] for b in data['blocks']);errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages']);assert errors==0
(folder/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid,errors=errors),indent=2))
report=Path('docs/performance-baselines/source-render-scheduler-node-stream-2026-09-10.md')
lines=['# Source render scheduler: Node streaming, 2026-09-10','',
'Follow-up to the actual-source Node string result. Hypothesis: grouping render starts may improve streaming throughput too, but delaying startup can harm first-byte latency. This measures both against unchanged React. The same authored full document, streaming API, renderer and response adapter remain in use. Only eXact receives the optional createNodeRenderScheduler gate, through public SSR options.', '',
'Four fresh production Node 26.8.1 workers run eXact/React/React/eXact, ten seconds warmup, concurrency 32 with two drivers holding 16 requests each, and five-second measured blocks. Each eXact worker runs normal/scheduled/normal; each React worker runs unchanged once. eXact controls are averaged within workers. Before/after isolated streaming loops warm and measure 2,000 renders with scheduling disabled. Workstation load can vary.', '',
'| Worker | eXact immediate RPS | eXact scheduled RPS | React unchanged RPS | Gain vs immediate | Gain vs React |',
'| --- | ---: | ---: | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['population']} | {r['normalRps']:,.0f} | {r['scheduledRps']:,.0f} | {r['reactRps']:,.0f} | {r['gainVsNormalPct']:+.2f}% | {r['gainVsReactPct']:+.2f}% |")
lines+=['', '| Worker | eXact response ms, immediate / scheduled | React response ms | eXact TTFB ms, immediate / scheduled | React TTFB ms |','| --- | ---: | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['population']} | {r['normalResponseMs']:.3f} / {r['scheduledResponseMs']:.3f} | {r['reactResponseMs']:.3f} | {r['normalTtfbMs']:.3f} / {r['scheduledTtfbMs']:.3f} | {r['reactTtfbMs']:.3f} |")
lines+=['',f'All {valid:,} measured responses matched full document identity, with zero errors. eXact serves 4,672 bytes and React 3,660 bytes. Schedule calls equal measured requests plus one identity-preflight request per load driver in scheduled blocks, and are zero in controls, React and isolated loops. Artifact and adapter hashes remain unchanged.', '',
'There is no response coalescing. The scheduler stores Promise resolvers, not URLs, HTML or response objects. An additional actual-build check queues sixteen distinct input/path combinations through the real scheduler, verifies sixteen distinct outputs against sequential unscheduled output, and asserts sixteen scheduler calls. It passes in both string and streaming modes. Preloaded fixture input reuse is unchanged by scheduling.', '',
'The streaming worker does not populate the string-render phase timer, so renderUs is null in its console log. This report uses complete-response throughput and driver latency, not that unavailable timer. Driver TTFB is not CSS parsing or browser paint timing. Browser, sparse-load and Bun validation remain necessary. These short focused results do not replace the full benchmark baseline.', '',
'The adjacent archive preserves raw data, scripts, isolation checks and rebuilt artifacts with a verified SHA-256 inventory.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[report]+[base/n for n in ('source-scheduler-stream-build.mjs','source-scheduler-stream-run.mjs','source-scheduler-stream-report.py','source-scheduler-isolation.mjs','source-scheduler-run.mjs')]+[Path(p) for p in ('framework-comparison/participants/exact/dist-server/server-entry.js','framework-comparison/participants/react/dist-server/server-entry.js','framework-adapters/node-adapter/src/render-scheduler.ts','framework-adapters/node-adapter/dist/render-scheduler.js','packages/ssr/src/render/render-output.ts')]
files=sorted(set(p for p in files if p.is_file()));archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps(rows,indent=2));print(valid,'valid',len(files),'verified files')
