import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'callback-toggle',{recursive:true});
const source=(await fs.readFile(root+'component-forwarding-integrated/server-entry.js','utf8')).replaceAll('\r\n','\n');
const ast=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const edits=[];let replaced=0;
function visit(n){
 if(ts.isFunctionDeclaration(n)&&n.name?.text==='renderComponentReference'){
  function inner(c){
   if(ts.isCallExpression(c)&&c.expression.getText(ast)==='renderServerComponentArtifactOutput'){
    if(c.arguments[4].getText(ast)!=='renderArtifactChildren'||c.arguments[5].getText(ast)!=='renderArtifactComponent')throw Error('Unexpected callbacks');
    edits.push({start:c.arguments[4].getStart(ast),end:c.arguments[4].end,text:"auditStage==='closures'?(children,owner)=>renderChildren(context,children,owner,options,true):renderArtifactChildren"});
    edits.push({start:c.arguments[5].getStart(ast),end:c.arguments[5].end,text:"auditStage==='closures'?(child,owner)=>renderComponentReference(context,child,owner,options,true,true):renderArtifactComponent"});replaced++;
   }
   ts.forEachChild(c,inner);
  }inner(n.body);
  edits.push({start:n.body.getStart(ast)+1,end:n.body.getStart(ast)+1,text:"if(auditStage==='closures')++auditCounts.closures;else ++auditCounts.shared;"});
 }
 ts.forEachChild(n,visit);
}
visit(ast);if(replaced!==1)throw Error('Missing callback boundary');
let output=source;for(const e of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,e.start)+e.text+output.slice(e.end);
output=`let auditStage='none',auditCounts={shared:0,closures:0};\n`+output+`
export function auditClearCounts(){auditCounts={shared:0,closures:0};}
export function auditReset(){auditStage='none';auditClearCounts();}
export function auditSelect(stage){if(!['none','closures'].includes(stage))throw Error('Invalid stage');auditStage=stage;}
export function auditRead(){return {stage:auditStage,counts:{...auditCounts},ready:true};}
`;
await fs.writeFile(root+'callback-toggle/server-entry.js',output);
await fs.copyFile(root+'hydration-ablation/worker.mjs',root+'callback-toggle/worker.mjs');
let runner=(await fs.readFile(root+'tree-ablation-run.mjs','utf8')).replaceAll('tree-ablation/','callback-toggle/').replaceAll('within-worker-tree-substitution','within-worker-shared-versus-closure-callbacks').replaceAll("'none','tree','none'","'none','closures','none','closures','none'").replace('report.blocks.length,6','report.blocks.length,10');
await fs.writeFile(root+'callback-toggle-run.mjs',runner);
let check=(await fs.readFile(root+'tree-ablation-check.mjs','utf8')).replaceAll('tree-ablation/','callback-toggle/').replace("['none','tree']","['none','closures']").replace("assert.equal(snapshot.counts.tree,stage==='tree'?0:1);","assert.equal(snapshot.counts.shared===0,stage==='closures');assert.equal(snapshot.counts.closures===0,stage==='none');");
await fs.writeFile(root+'callback-toggle-check.mjs',check);
console.log({replaced});
