import hashlib
import json
import zipfile
from pathlib import Path
from statistics import mean

base=Path('.tmp/ssr-large-profile');folder=base/'callback-toggle'
data=json.loads((folder/'capture.json').read_text());assert data['complete']
rows=[]
for population in (0,1):
    blocks=[b for b in data['blocks'] if b['population']==population]
    assert [b['phase'] for b in blocks]==['none','closures','none','closures','none']
    for i in (1,3):
        controls=[blocks[i-1],blocks[i+1]];b=blocks[i]
        assert b['after']['ablation']['counts']['shared']==0
        assert b['after']['ablation']['counts']['closures']>0
        def render(x):
            s=x['after']['telemetry']['statistics']['renderMs'];return s['sum']/s['count']*1000
        def loop(x):return mean(x[k]['meanMs'] for k in ('loopBefore','loopAfter'))*1000
        normal=mean(c['rps'] for c in controls)
        rows.append(dict(population=population+1,pair=(i+1)//2,sharedRps=normal,closuresRps=b['rps'],closuresGainPct=(b['rps']/normal-1)*100,
                         sharedHttpUs=mean(render(c) for c in controls),closuresHttpUs=render(b),sharedLoopUs=mean(loop(c) for c in controls),closuresLoopUs=loop(b)))
valid=sum(b['valid'] for b in data['blocks']);errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages']);assert errors==0
(folder/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid,errors=errors),indent=2))
report=Path('docs/performance-baselines/component-callback-toggle-2026-09-10.md')
lines=['# Same-worker component callback comparison, 2026-09-10','','## Question','',
'Resolve the large worker-sensitive Node signal from the integrated shared',
'component-forwarding screen. Earlier allocation profiles show fewer allocated',
'bytes, but separate-worker HTTP screens point in opposite directions. This test',
'toggles shared methods versus the original fresh forwarding closures inside',
'one artifact and worker. Both execute the same renderer and current descendants.', '',
'No operation is stubbed or cached. At each renderComponentReference boundary,',
'the toggle chooses the two shared execution methods or creates the original',
'two callbacks capturing context/options. The fixture crosses eight boundaries',
'per render. Static toggle instrumentation is present in both modes. This changes',
'call-site feedback compared with dedicated artifacts, so it complements rather',
'than replaces prior isolated/artifact evidence.', '',
'## Method','',
'Two fresh Node string workers each run shared/closures/shared/closures/shared.',
'Each warms HTTP for ten seconds; blocks last five seconds. Two fresh drivers',
'per block each hold 16 requests in flight. Each closure block is compared with',
'the average of adjacent shared blocks in the same worker. Isolated loops before',
'and after each block warm and measure 10,000 renders in the selected mode.', '',
'## Paired throughput','',
'| Worker | Pair | Shared RPS | Closures RPS | Closures change |',
'| --- | ---: | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['population']} | {r['pair']} | {r['sharedRps']:,.0f} | {r['closuresRps']:,.0f} | {r['closuresGainPct']:+.2f}% |")
lines+=['',f'All {valid:,} measured responses match the complete 4,672-byte document,',
'zero errors. Four ordinary/escaped parity cases pass. Counters verify callback',
'selection. Artifact and adapter hashes are checked; owned worker/load processes',
'close. HTTP and isolated render-duration details are retained in summary.json.', '',
'This experiment is not a fresh React comparison and does not resolve the broader',
'Node/Bun performance goal. The earlier functional, ownership, browser and',
'allocation checks are recorded in the',
'[shared forwarding report](component-forwarding-2026-09-10.md).', '',
'The adjacent archive contains source, checks, runner, raw blocks, summary, fixed',
'fixture, current and diagnostic artifacts and a verified SHA-256 inventory.',
'Workspace dependencies are not packaged as a standalone distribution.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[report,Path('.tmp/positional-leaves/data.json')]+[base/n for n in ('callback-toggle-build.mjs','callback-toggle-check.mjs','callback-toggle-run.mjs','callback-toggle-report.py','tree-ablation-run.mjs','tree-ablation-check.mjs','hydration-ablation/worker.mjs','component-forwarding-integrated/server-entry.js')]
files=sorted(set(f for f in files if f.is_file()));archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={f.as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in files:z.write(f,f.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps(rows,indent=2));print(valid,'valid;',len(files),'verified files')
