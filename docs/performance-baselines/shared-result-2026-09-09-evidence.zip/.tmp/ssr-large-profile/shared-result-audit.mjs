import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
const dir='.tmp/ssr-large-profile/';
const results=[];
for(const variant of ['text-surroundings-current','shared-result-current']) {
 const entry=dir+variant+'-result-audit.mjs';
 writeFileSync(entry,readFileSync(dir+variant+'.mjs','utf8')+'\nexport {createChunkedStringResult,createChunkedHydratableResult};\n');
 const {createChunkedStringResult:plain,createChunkedHydratableResult:hydrate}=await import(pathToFileURL(resolve(entry)));
 const chunks=['a','b'];
 const value=plain(chunks,{x:1},undefined,['preload'],7);
 assert.deepEqual(Object.keys(value),['html','state','wallClockSnapshot','preloadLinks']);
 const descriptor=Object.getOwnPropertyDescriptor(value,'html');
 assert.equal(descriptor.enumerable,true);assert.equal(descriptor.configurable,true);assert.equal(descriptor.set,undefined);
 assert.throws(()=>{value.html='overwrite';},TypeError);
 chunks.push('c');assert.equal(value.html,'abc');chunks.push('d');assert.equal(value.html,'abc');
 assert.equal(Object.isFrozen(value.preloadLinks),true);
 let reads=0;
 const hydrated=hydrate(value,()=>{reads++;return [];},'hydrate');
 assert.equal(reads,0);hydrated.resumptions;hydrated.resumptions;assert.equal(reads,2);
 assert.equal(hydrated.html,value.html);
 assert.equal(hydrated.htmlWithHydration,'abcdhydrate');
 const html='<!doctype html><html><body><template></body></template>Ready</BoDy></html>';
 const expected=html.replace('Ready</BoDy>','Ready<!--exact:framework-body:start-->hydrate<!--exact:framework-body:end--></BoDy>');
 for(let split=0;split<=html.length;split++)assert.equal(hydrate(plain([html.slice(0,split),'',html.slice(split)]),[],'hydrate').htmlWithHydration,expected);
 assert.throws(()=>hydrate(plain(['<!doctype html><html><body>Ready</html>']),[],'hydrate'),/missing its closing/);
 let detached;
 try{detached=descriptor.get.call({});}catch(error){detached=error.name;}
 results.push({variant,splitCases:html.length+1,checks:'passed',detachedGetter:detached});
}
writeFileSync(dir+'shared-result-audit-'+(process.versions.bun?'bun':'node')+'.json',JSON.stringify(results,null,2));
console.log(JSON.stringify(results));
