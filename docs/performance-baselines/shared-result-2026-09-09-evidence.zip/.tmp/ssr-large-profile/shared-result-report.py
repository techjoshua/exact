import json, pathlib, hashlib, zipfile
directory=pathlib.Path('.tmp/ssr-large-profile')
rows=json.loads((directory/'shared-result-current-results.json').read_text(encoding='utf-8'))
assert len(rows)==32
text='''# Shared SSR result getters experiment

Date: 2026-09-09. Prototype rejected; production unchanged.

The hypothesis was that sharing lazy result getters could save about 1-3% on small string
renders by removing request-local accessor closures. The prototype uses shared property
descriptors and a WeakMap containing request-local materialization state. It changes only the
two result factories in the frozen current text-surroundings build. Traversal, hydration
validation, document generation, and stream consumption remain identical.

Thirty-two fresh production processes cover Node/Bun, string/consumed stream, three/96 incidents
with two script and two stylesheet assets, and two reversed-order pairs per cell. Each process
performs 5,000 warmups and 12,000 measured renders. All paired full-document hashes match.
These are local renderer timings, not HTTP throughput or browser performance.

Positive percentages mean slower rendering. No completed population was discarded.

| Runtime | Mode | Fixture | Pair 1 time change | Pair 2 time change |
| --- | --- | --- | ---: | ---: |
'''
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['small','large']:
   deltas=[]
   for round in range(2):
    pair=[r for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['round']==round]
    assert len(pair)==2 and pair[0]['hash']==pair[1]['hash']
    old=next(r for r in pair if r['variant']=='text-surroundings-current')
    new=next(r for r in pair if r['variant']=='shared-result-current')
    deltas.append((new['usPerRender']/old['usPerRender']-1)*100)
   text+=f'| {runtime} | {mode} | {scenario} | {deltas[0]:+.2f}% | {deltas[1]:+.2f}% |\n'
text+='''
Node streaming and large Node strings improved in both pairs. Small Bun strings and streams
regressed in both pairs, with small Bun streaming particularly unfavorable. Large Bun results
were mixed. This does not justify adopting the WeakMap representation across the shared engine.
The result does not isolate map access from descriptor construction or garbage collection.

Focused behavior checks passed in both runtimes: enumerable/configurable own getters, assignment
rejection, delayed materialization and memoization, frozen preload metadata, deferred resumption
reads, 75 document split positions per variant, and malformed-document rejection.
One reflection behavior differs: calling a detached getter with an unrelated receiver returns the
original captured value in the control but throws TypeError in the prototype. This would require
an explicit contract decision before any adoption. It is not a hydration regression.

No production files changed, and no new package or browser test result is claimed. The next
allocation experiment should target an actual intermediate object in the render pipeline rather
than replace closures with another request-local lookup layer. The broader direct-sink work and
React parity goal remain incomplete.

The adjacent evidence archive contains both frozen bundles, benchmark and audit scripts,
all 32 raw observations, both runtime audit results, fixed input, and a verified SHA-256 manifest.
'''
target=pathlib.Path('docs/performance-baselines/shared-result-2026-09-09')
target.with_suffix('.md').write_text(text,encoding='utf-8')
files=[directory/name for name in ['text-surroundings-current.mjs','shared-result-current.mjs','shared-result-build.mjs','shared-result-run.mjs','shared-result-current-results.json','shared-result-audit.mjs','shared-result-audit-node.json','shared-result-audit-bun.json','shared-result-report.py','direct-map-worker.mjs']]
files.append(pathlib.Path('.tmp/positional-leaves/data.json'))
manifest={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=pathlib.Path(str(target)+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p).replace('\\','/'))
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(text)
