import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
const source=readFileSync(dir+'text-surroundings-current.mjs','utf8');
const start=source.indexOf('function createChunkedStringResult(');
const end=source.indexOf('function startsExactDocument(',start);
if(start<0||end<start)throw Error('Missing replacement boundary');
const replacement=`
const sharedResultStorage = new WeakMap();
function sharedResultHtml() {
 const state = sharedResultStorage.get(this);
 if(state.original) return state.original.html;
 return state.materialized ??= state.chunks.length === 1 ? state.chunks[0] : state.chunks.join('');
}
function sharedHydratableHtml() {
 const state=sharedResultStorage.get(this);
 return state.materialized ??= state.chunks.length === 1 ? state.chunks[0] : state.chunks.join('');
}
function sharedResumptions() {
 const value=sharedResultStorage.get(this).resumptions;
 return typeof value === 'function' ? value() : value;
}
const sharedHtmlDescriptor={get:sharedResultHtml,enumerable:true,configurable:true};
const sharedHydratedDescriptor={get:sharedHydratableHtml,enumerable:true,configurable:true};
const sharedResumptionsDescriptor={get:sharedResumptions,enumerable:true,configurable:true};
function createChunkedStringResult(chunks,state,hydrationTable,preloadLinks,wallClockSnapshot) {
 const result={};
 Object.defineProperty(result,'html',sharedHtmlDescriptor);
 result.state=state;
 sharedResultStorage.set(result,{chunks,materialized:undefined});
 if(wallClockSnapshot!==undefined)result.wallClockSnapshot=wallClockSnapshot;
 if(hydrationTable)result.hydrationTable=hydrationTable;
 if(preloadLinks?.length)result.preloadLinks=Object.freeze([...preloadLinks]);
 Object.defineProperty(result,ssrHtmlChunks,{value:chunks});
 return result;
}
function createChunkedHydratableResult(result,resumptions,hydrationScript) {
 const htmlChunks=htmlChunksOf(result);
 const chunks=htmlChunks?augmentChunkedBody(htmlChunks,hydrationScript):[augmentDocumentBody(result.html,hydrationScript)];
 const hydratable={};
 Object.defineProperty(hydratable,'resumptions',sharedResumptionsDescriptor);
 Object.defineProperty(hydratable,'htmlWithHydration',sharedHydratedDescriptor);
 Object.defineProperty(hydratable,'html',sharedHtmlDescriptor);
 hydratable.state=result.state;
 hydratable.hydrationScript=hydrationScript;
 sharedResultStorage.set(hydratable,{chunks,materialized:undefined,original:result,resumptions});
 if(result.wallClockSnapshot!==undefined)hydratable.wallClockSnapshot=result.wallClockSnapshot;
 if(result.hydrationTable)hydratable.hydrationTable=result.hydrationTable;
 if(result.preloadLinks)hydratable.preloadLinks=result.preloadLinks;
 Object.defineProperty(hydratable,ssrHtmlChunks,{value:htmlChunks??[result.html]});
 Object.defineProperty(hydratable,ssrHydratableChunks,{value:chunks});
 return hydratable;
}
`;
writeFileSync(dir+'shared-result-current.mjs',source.slice(0,start)+replacement+source.slice(end));
let runner=readFileSync(dir+'text-surroundings-run.mjs','utf8');
runner=runner.replaceAll('text-surroundings-current','shared-result-current').replaceAll('scheduled-contract-current','text-surroundings-current');
writeFileSync(dir+'shared-result-run.mjs',runner);
