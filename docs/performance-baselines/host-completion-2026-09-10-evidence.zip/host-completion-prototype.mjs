import fs from 'node:fs';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
const source=fs.readFileSync(root+'static-invocation-final/server-entry.js','utf8');
const start=source.indexOf('\t\treturn withRenderCleanup(() => {',source.indexOf('function renderProgramWriter('));
const end=source.indexOf('\n\t}',start);
assert.ok(start>0&&end>start);
assert.ok(source.slice(start,end).includes('output.sink.flush("head")'));
const replacement=`
        let result;
        try {
            if (entered.prefix) output.sink.write(entered.prefix);
            const ready = output.sink.ready();
            result = ready instanceof Promise
                ? ready.then(() => finishHostedOutput(executeProgramWriter(output, invoke, local, invocation), output.sink, host))
                : finishHostedOutput(executeProgramWriter(output, invoke, local, invocation), output.sink, host);
        } catch (error) {
            return withRenderCleanup(() => { throw error; }, () => leaveHost(context, entered.tag));
        }
        if (result instanceof Promise)
            return withRenderCleanup(() => result, () => leaveHost(context, entered.tag));
        leaveHost(context, entered.tag);
        return result;`;
const helper=`
function finishHostedOutput(result, sink, host) {
    if (result instanceof Promise) return result.then(html => finishHostedOutput(html, sink, host));
    const flushed = host === 'head' ? sink.flush('head') : undefined;
    return flushed instanceof Promise ? flushed.then(() => result) : result;
}
`;
fs.mkdirSync(root+'host-completion',{recursive:true});
fs.writeFileSync(root+'host-completion/server-entry.js',source.slice(0,start)+replacement+source.slice(end)+helper);
