import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
const rows=['host-completion-results.json','host-completion-large-results.json'].flatMap(f=>JSON.parse(fs.readFileSync(d+f,'utf8')));
let table='| Runtime | Mode | Size | Current | Candidate | React |\n| --- | --- | --- | ---: | ---: | ---: |\n';
for(const runtime of ['node','bun'])for(const mode of ['string','encoded','stream'])for(const scenario of ['assets','large']){
 const mean=variant=>{const selected=rows.filter(r=>r.runtimeId===runtime&&r.mode===mode&&r.scenario===scenario&&r.variant===variant);return (selected.reduce((n,r)=>n+r.usPerRender,0)/selected.length).toFixed(2)};
 table+=`| ${runtime} | ${mode} | ${scenario==='assets'?'small':'large'} | ${mean('current')} | ${mean('candidate')} | ${mean('react')} |\n`;
}
const report=`# Document-host completion experiment, September 10, 2026

Status: prototype measured; source implementation and focused tests prepared. Acceptance is
pending rebuilt measurements and broader validation. Canonical apps still contain static-input
reuse without this experiment.

## Hypothesis and design

The document-host branch of renderProgramWriter created cleanup and mapping callbacks even
when readiness, rendering, and head flushing all completed synchronously. Hypothesis: removing
those callbacks could reduce small-document time by roughly 0.5-2%, with a smaller proportionate
effect on large documents. The candidate retains the same renderer and sink interface. It uses
direct completion when synchronous and the existing cleanup mechanism for pending work and errors.
Head ancestry remains active until its flush settles. It does not enable early head publication
in the public document stream.

## Prototype evidence

The current artifact is the integrated static-input reuse build. Both frameworks render full
application-owned documents with four asset tags. Each fresh production process uses 5,000
warmups and 10,000 measured iterations. Two reversed variant orders cover Node/Bun, string,
encoded string, and fully consumed streaming for small and 96-incident documents. Complete
document hashes match between eXact variants. Units are microseconds per render, lower is better.

${table}

String means improved across both runtimes and document sizes. Encoded and streaming results
are mixed. In particular, large Node encoded candidate populations were 199.02 and 216.31
microseconds; large Bun stream candidate populations were 309.24 and 293.62. Neither sample
is discarded, and no cause for the variation is established. These are renderer measurements,
not HTTP throughput, and do not establish a general win over React.

Eight additional full-response checks passed with readiness forced to return promises after
every write and with an asynchronous flush. Source SSR tests passed: 340 tests in 53 files.
Added cases cover synchronous throws and rejected promises during readiness, writer execution,
and head flushing, verifying error identity, invocation count, and balanced host ancestry.

## Remaining work

An isolated rebuilt artifact and test typechecking are in progress. Rebuilt performance,
browser validation, and quality checks are required before accepting the change. The preceding
[HTTP comparison](static-server-invocations-2026-09-10.md) measures static-input reuse only.

Prototype scripts, artifacts, raw captures, and current source snapshots are preserved in
host-completion-2026-09-10-evidence.zip. Pending rebuild logs will be recorded separately.
`;
fs.writeFileSync('docs/performance-baselines/host-completion-2026-09-10.md',report);
console.log(table);
