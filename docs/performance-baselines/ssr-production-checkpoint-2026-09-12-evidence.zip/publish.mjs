import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {readFile,writeFile,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {measureSsrArtifact} from '../../framework-comparison/src/ssr-run-environment.mjs';
import {createSsrCapacityReport} from '../../framework-comparison/src/publish-ssr-capacity.mjs';
import {refreshDocsSsrDiagnostics,refreshDocsBunSsrDiagnostics} from '../../scripts/component-local-target-abi/refresh-docs-ssr-report.mjs';
const root='.tmp/ssr-production-checkpoint',prefix='docs/performance-baselines/ssr-production-checkpoint-2026-09-12';
const json=async path=>JSON.parse(await readFile(path,'utf8'));
const sourceState=await json(root+'/source-state.json');
const commit=sourceState.baseCommit;
const sourceSha256=createHash('sha256').update(JSON.stringify(sourceState.files)).digest('hex');
for(const [path,hash] of Object.entries(sourceState.files)) {
 if(path.startsWith('apps/docs/') || path.startsWith('docs/') || path.endsWith('README.md')) continue;
 assert.equal(createHash('sha256').update(await readFile(path)).digest('hex'),hash,path+' changed since measurement');
}

const execution=await json(root+'/execution.json');
const stages=Object.values(Object.fromEntries(execution.map(s=>[s.name,s])));
assert.equal(stages.length,16);assert.ok(stages.every(s=>s.code===0));
const sources={},captures={};
for(const mode of ['string','stream'])for(const runtime of ['node','bun'])for(const lane of ['multi','normal','arrivals']){
 const name=runtime+(mode==='stream'?'-stream':'')+'-'+lane;
 const raw=await json(root+'/'+name+'.json');assert.equal(raw.complete,true);assert.equal(raw.renderMode,mode);
 const adapter=await measureSsrArtifact('framework-adapters/'+runtime+'-adapter/dist');
 assert.deepEqual(raw.artifacts[runtime==='bun'?'bunAdapter':'nodeAdapter'],adapter);
 captures[name]=raw;
}
for(const name of [...Object.keys(captures),'ssr','ssr-stream','control-on','control-off','control-bun-stream-on','control-bun-stream-off']){
 const path=prefix+'-'+name+'.json';await copyFile(root+'/'+name+'.json',path);
 sources[name]={path,sha256:createHash('sha256').update(await readFile(path)).digest('hex')};
}
const previous=await json(root+'/before-performance-report.json');
const ssr=await json(root+'/ssr.json'),stream=await json(root+'/ssr-stream.json');
assert.equal(ssr.harness.renderMode,'string');assert.equal(stream.harness.renderMode,'stream');
for(const raw of [ssr,stream]){assert.equal(raw.complete,true);assert.equal(raw.publishable,true);}
const report=refreshDocsBunSsrDiagnostics(refreshDocsSsrDiagnostics(previous,ssr),ssr);
report.metadata.createdAt=new Date().toISOString();report.metadata.capture='ssr-production-checkpoint-2026-09-12';
report.metadata.ssrCommit=commit;report.metadata.ssrSourceSha256=sourceSha256;report.metadata.ssrCapture='ssr-production-checkpoint-2026-09-12';
report.metadata.sources={...previous.metadata.sources,ssrDiagnostics:sources.ssr,ssrBunDiagnostics:sources.ssr};
assert.deepEqual(report.browserCharts,previous.browserCharts);
const streamReport=refreshDocsBunSsrDiagnostics(refreshDocsSsrDiagnostics(previous,stream),stream);
streamReport.metadata={renderMode:'stream',ssrCommit:commit,ssrSourceSha256:sourceSha256,createdAt:stream.createdAt,ssrCreatedAt:stream.createdAt,ssrDiagnosticsEnvironment:stream.environment,ssrSequentialSamples:stream.harness.sampleCount,ssrBurstSamples:stream.harness.concurrencyWaves,ssrRetentionCheckpoints:stream.harness.retentionBatches,source:sources['ssr-stream']};
streamReport.server.sequential.comment='Complete warm HTTP response latency using the streaming API, including fixture fetching, rendering, and stream consumption. Lower is better.';
streamReport.server.bun.sequential.comment=streamReport.server.sequential.comment;
await writeFile('apps/docs/src/data/performance-report.json',JSON.stringify(report,null,2)+'\n');
await writeFile(root+'/report-data.json',JSON.stringify(report,null,2)+'\n');
await writeFile('apps/docs/src/data/ssr-stream-report.json',JSON.stringify({metadata:streamReport.metadata,server:streamReport.server},null,2)+'\n');
const capacities={};
for(const mode of ['string','stream'])for(const runtime of ['node','bun']){
 const suffix=mode==='stream'?'-stream':'';
 const lanes=Object.fromEntries(['multi','normal','arrivals'].map(l=>[l,captures[runtime+suffix+'-'+l]]));
 const capacity=createSsrCapacityReport(lanes,lanes.normal);capacities[runtime+suffix]=capacity;
 const name=mode==='stream'?'ssr-'+runtime+'-stream-capacity-report':'ssr-'+(runtime==='bun'?'bun-':'')+'capacity-report';
 await writeFile('apps/docs/src/data/'+name+'.json',JSON.stringify(capacity,null,2)+'\n');
}
const log=await readFile(root+'/server.log','utf8');
const server=JSON.parse(log.split(/\r?\n/).find(s=>s.startsWith('EXACT_SERVER_BENCHMARK_JSON=')).slice('EXACT_SERVER_BENCHMARK_JSON='.length));
await writeFile(prefix+'-server.json',JSON.stringify(server,null,2)+'\n');
const identities={};
for(const runtime of ['node','bun']){
 const frozen=await readFile(root+'/measured-exact-'+runtime+'.mjs');
 const current=await readFile('framework-comparison/participants/exact/dist-'+(runtime==='bun'?'bun-':'')+'server/'+(runtime==='bun'?'bun-':'')+'server-entry.js');
 assert.deepEqual(frozen,current);identities[runtime]=createHash('sha256').update(current).digest('hex');
}
await writeFile(prefix+'.json',JSON.stringify({commit,sourceSha256,sourceIdentity:'Uncommitted measured source; commit is the parent baseline',sourceState:await json(root+'/source-state.json'),sources,execution,controls:await json(root+'/control-execution.json'),capacities,report,streamReport:{metadata:streamReport.metadata,server:streamReport.server},server,identities,validation:await json(root+'/verification.json'),runners:{measure:await readFile(root+'/run.mjs','utf8'),capacity:await readFile(root+'/capacity-runner.mjs','utf8'),publish:await readFile(import.meta.filename,'utf8')},previousReport:previous},null,2)+'\n');
console.log('Published complete SSR captures; browser evidence preserved.');
