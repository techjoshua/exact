import json,datetime
from pathlib import Path
for s in json.loads(Path('.tmp/bun-adaptive-ssr/execution.json').read_text()):
 if s['name'] in ['ssr','ssr-stream','server']:
  print(s['name'],s.get('code'),s.get('startedAt'),s.get('endedAt'))
