import sys,json
from pathlib import Path
p=Path('.tmp/ssr-production-checkpoint')/(sys.argv[1]+'.json')
if p.exists():
 d=json.loads(p.read_text(encoding='utf8'))
 for b in d['blocks']:
  rows=[]
  for name in [s['name'] for s in b['results'][0]['stages'] if s['name']=='total-c32' or s['name'].startswith('total-arrivals')]:
   ss=[next(s for s in r['stages'] if s['name']==name) for r in b['results']]
   tails=[s['distributions']['responseMs']['p99'] for s in ss]
   rows.append({'stage':name,'rps':round(sum(s['validRps'] for s in ss),2),'errors':sum(s['errors'] for s in ss),'misses':sum(s['missedCapacity']+s['missedLag']+s['missedDeadline'] for s in ss),'p99':[round(min(tails),2),round(max(tails),2)]})
  print(b['id'],b['population']+1,json.dumps(rows))
