from pathlib import Path
import json, hashlib, zipfile
root=Path('.tmp/ssr-production-checkpoint')
prefix=Path('docs/performance-baselines/ssr-production-checkpoint-2026-09-12')
checks=json.loads((root/'checks.json').read_text())
latest={x['name']:x for x in checks}
assert all(x.get('code')==0 for x in latest.values()), 'Final checks are not complete'
verification=json.loads((root/'verification.json').read_text())
package=next(x for x in verification['checks'] if x['name']=='package-tests')
verification['checks']=checks+[package,{'name':'changed-lint','code':0,'log':'check-changed-lint.log'}]
verification['docsBrowser']=json.loads((root/'docs-verification.json').read_text())
verification['notes']=['Initial test type check failed because existing scheduler fixtures used Promise.withResolvers with ES2022 types. Fixtures now use ordinary promises; test types and all five scheduler fixture tests passed afterward.','Measured runtime files remain unchanged. Documentation type checking, tests, production build, desktop/mobile chart value checks, page error checks, and horizontal overflow checks passed.','Package tests emitted MaxListenersExceededWarning and plugin timing warnings; the docs build emitted its large-chunk advisory. No warnings were suppressed.']
(root/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
Path(str(prefix)+'-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
capture=json.loads(Path(str(prefix)+'.json').read_text())
capture['validation']=verification
capture['runners']['controlWorker']=(root/'control-worker.mjs').read_text()
capture['runners']['controls']=(root/'control-run.mjs').read_text()
# Preserve exact frozen sources, plans, runner code, and logs, including the excluded interrupted run.
archive=Path(str(prefix)+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(root.rglob('*')):
  if not p.is_file(): continue
  rel=p.relative_to(root)
  if rel.parts[0] in ('sources','interrupted-before-readiness-recheck') or p.suffix in ('.mjs','.py','.log','.png','.patch','.txt') or p.name in ('source-state.json','execution.json','control-execution.json','verification.json','checks.json','docs-verification.json') or p.name.endswith('-plan.json'):
   z.write(p,rel.as_posix())
capture['evidenceArchive']={'path':archive.as_posix(),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
for source in capture['sources'].values():
 assert hashlib.sha256(Path(source['path']).read_bytes()).hexdigest()==source['sha256']
Path(str(prefix)+'.json').write_text(json.dumps(capture,indent=2)+'\n')
p=Path(str(prefix)+'.md');s=p.read_text()
s+='''
The final checks passed: 677 package tests, 11 native Bun integration tests, 88 benchmark harness
tests, 112 build-script tests, and 10 documentation tests. The five scheduler fixture tests were
rerun after replacing ES2024-only test helpers with ordinary promises to match the ES2022 test
configuration. Package and test types, package contents, platform boundaries, compiled ABI,
source architecture, JSDoc, explicit-any limits, and changed-file lint checks passed.
Documentation type checking and the production build passed. Desktop and mobile browser checks
verified chart values against the published data, with no page errors or horizontal overflow.

The [verification journal](ssr-production-checkpoint-2026-09-12-verification.json) records the
initial test-type failure and successful repeat. Test listener/plugin warnings and the docs build's
large-chunk advisory were retained. The [evidence archive](ssr-production-checkpoint-2026-09-12-evidence.zip)
preserves measured source files and bundles, plans, runners, logs, screenshots, and the interrupted
capture excluded from the final measurements. The structured capture links and hashes every raw
capacity, diagnostic, and checkpoint-control capture. Source provenance identifies the measured
uncommitted working tree by its file hashes and parent commit, without claiming the parent alone
contains the implementation.
'''
p.write_text(s)
print(json.dumps({'checks':len(latest),'archiveBytes':archive.stat().st_size,'sourcesVerified':len(capture['sources'])}))
