import {spawn} from 'node:child_process';
import {openSync, closeSync, writeFileSync} from 'node:fs';
const root='.tmp/ssr-production-checkpoint';
const rows=[];
for(const [runtime, mode, plan] of [['node','string','control-plan'],['bun','stream','normal-plan']]) for(const policy of ['on','off']) {
  const name=runtime==='node'?'control-'+policy:'control-bun-stream-'+policy;
  const row={name,runtime,mode,policy,startedAt:new Date().toISOString()};rows.push(row);
  const log=openSync(root+'/'+name+'.log','w');
  console.log('START '+name);
  try { await new Promise((resolve,reject)=> {
    const child=spawn(process.execPath,[root+'/control-capacity.mjs',root+'/'+plan+'.json',root+'/'+name+'.json',runtime],{windowsHide:true,stdio:['ignore',log,log],env:{...process.env,NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:mode,EXACT_CHECKPOINT_CONTROL:policy}});
    row.pid=child.pid;child.once('error',reject);child.once('exit',code=>{row.code=code;code===0?resolve():reject(new Error('control failed'));});
  }); } finally { closeSync(log);row.endedAt=new Date().toISOString();writeFileSync(root+'/control-execution.json',JSON.stringify(rows,null,2)); }
}
