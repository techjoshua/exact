import json
from pathlib import Path
for folder in ['bun-adaptive-ssr','ssr-production-checkpoint']:
 p=Path('.tmp')/folder/'node-arrivals.json'
 if not p.exists():continue
 d=json.loads(p.read_text())
 for b in d['blocks']:
  counts={}
  for r in b['results']:
   for s in r['stages']:
    for k,v in s.get('errorDetails',{}).get('counts',{}).items():counts[k]=counts.get(k,0)+v
  print(folder,b['id'],b['population']+1,counts)
