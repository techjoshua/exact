import json
from pathlib import Path
p=Path('.tmp/ssr-production-checkpoint/node-arrivals.json')
if p.exists():
 d=json.loads(p.read_text())
 for b in d['blocks']:
  for r in b['results']:
   for s in r['stages']:
    if s['errors']:print(b['id'],s['name'],json.dumps(s.get('errorDetails')), 'invalid',s.get('invalid'))
  if b['workerStderr']: print('stderr',b['workerStderr'][-3000:])
