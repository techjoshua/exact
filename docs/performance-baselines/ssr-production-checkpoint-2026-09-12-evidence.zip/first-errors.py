import json
from pathlib import Path
d=json.loads(Path('.tmp/ssr-production-checkpoint/node-arrivals.json').read_text())
for b in d['blocks']:
 for r in b['results']:
  for s in r['stages']:
   if s['errors']:
    e=s['errorDetails'];print(b['population']+1,e['counts'],json.dumps(e['samples'][:1]))
