import json
from pathlib import Path
p=Path('.tmp/ssr-production-checkpoint/node-arrivals.json')
d=json.loads(p.read_text());b=d['blocks'][0]
print('telemetry keys',list(b['telemetry'][-1]['value']))
for t in b['telemetry']:
 if 1789224954000 <=t['epochMs']<=1789224959000:print(t['epochMs'],str(t['value'])[:1800])
print('stderr',b['workerStderr'][-500:])
