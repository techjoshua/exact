import json
from pathlib import Path
d=json.loads(Path('docs/performance-baselines/bun-adaptive-ssr-2026-09-12.json').read_text())
for x in d['execution']:
 if x['name'] in ['ssr','ssr-stream','server']:print(x)
