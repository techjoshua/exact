from pathlib import Path
import json
root=Path('.tmp/ssr-production-checkpoint')
commit=json.loads((root/'source-state.json').read_text())['baseCommit']
lines=['# Production SSR readiness checkpoints, September 12, 2026','',
'The Node and native Bun adapters now carry their host-owned adaptive policy through request',
'cancellation scopes. SSR consults it at render entry and after pending component props or blocking',
'tasks settle. Ready work remains synchronous; transport backpressure does not add checkpoints.',
'The runtime rechecks task readiness after queued admission so a new generation cannot publish',
'unsettled output. Existing compiler continuations and the single rendering engine remain in use.','',
'Measured working tree based on commit `'+commit+'`. Changed packages and all three eXact comparison',
'outputs were rebuilt. The measured runtime source and bundles were frozen before measurement,',
'while the implementation was uncommitted; source hashes and the parent commit are retained.',
'React and the other participants retain their existing implementations. Production Node 26.8.1',
'and Bun 1.4.2 ran on the shared Windows PC with variable foreground usage. Every response renders',
'the complete authored document and application. No response or component execution is shared.','',
'Two independent load drivers validate complete response hashes. Both fresh populations are retained,',
'with framework order reversed in the second population. Rates count valid completed responses.',
'Older captures are historical context, not idle-PC controls.','',
'## Sustained capacity','',
'Preloaded capacity isolates rendering and HTTP delivery; normal loading includes fetching application data.',
'Both modes below use total concurrency 32. RPS counts valid completed responses. Tail ranges span drivers',
'and both populations.','',
'| Runtime | API | Loading | eXact RPS | React RPS | eXact driver p99 ms | React driver p99 ms |',
'| --- | --- | --- | ---: | ---: | --- | --- |']
captures={}
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for lane in ['multi','normal','arrivals']:
   name=runtime+('-stream' if mode=='stream' else '')+'-'+lane
   c=json.loads((root/(name+'.json')).read_text(encoding='utf8'));assert c['complete'];captures[name]=c
   if lane=='arrivals':continue
   values={}
   for id in ['exact','react']:
    rates=[];tails=[]
    for b in sorted((b for b in c['blocks'] if b['id']==id),key=lambda b:b['population']):
     ss=[next(s for s in r['stages'] if s['name']=='total-c32') for r in b['results']]
     rates.append(f'{sum(s["validRps"] for s in ss):,.0f}')
     tails.extend(s['distributions']['responseMs']['p99'] for s in ss)
    values[id]=(' / '.join(rates),f'{min(tails):.1f} to {max(tails):.1f}')
   lines.append(f'| {runtime.title()} | {mode} | {"preloaded" if lane=="multi" else "normal"} | {values["exact"][0]} | {values["react"][0]} | {values["exact"][1]} | {values["react"][1]} |')
lines+=['','## Scheduled demand','',
'Misses are requests the load generator could not start on schedule, distinct from response errors.',
'The public charts retain each runtime, API, offered rate, valid RPS, misses, errors, and response tails.',
 'Missed arrivals below include capacity, driver-lag, and end-of-stage misses across both populations.',
 'The capacity-only subset is shown separately; p99 ranges span individual drivers and populations.',
'',
'| Runtime/API | Framework | Offered RPS | Valid RPS, two populations | Errors | Missed arrivals | Capacity misses | Driver p99 ms |',
'| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |']
error_counts={};invalid=0;total_errors=0;warmup_errors=0
for name,c in captures.items():
 for b in c['blocks']:
  for r in b['results']:
   for s in r['stages']:
    if s['name']=='warmup':
     warmup_errors+=s['errors']
     continue
    invalid+=s.get('invalid',0);total_errors+=s['errors']
    for k,v in s.get('errorDetails',{}).get('counts',{}).items():error_counts[k]=error_counts.get(k,0)+v
 if not name.endswith('arrivals'):continue
 for id in ['exact','react']:
  for rate in [8000,10000]:
   rates=[];errors=misses=capacity_misses=0;tails=[]
   for b in sorted((b for b in c['blocks'] if b['id']==id),key=lambda b:b['population']):
    ss=[next(s for s in r['stages'] if s['name']==f'total-arrivals-{rate}') for r in b['results']]
    rates.append(f'{sum(s["validRps"] for s in ss):,.0f}')
    errors+=sum(s['errors'] for s in ss)
    misses+=sum(s['missedCapacity']+s['missedLag']+s['missedDeadline'] for s in ss)
    capacity_misses+=sum(s['missedCapacity'] for s in ss)
    tails.extend(s['distributions']['responseMs']['p99'] for s in ss)
   lines.append(f'| {c["runtimeId"].title()} {c["renderMode"]} | {"eXact" if id=="exact" else "React"} | {rate:,} | {" / ".join(rates)} | {errors:,} | {misses:,} | {capacity_misses:,} | {min(tails):.1f} to {max(tails):.1f} |')

lines+=['','### Request-error categories','',
'| Capture | Framework | Population | Stage | Error counts |',
'| --- | --- | ---: | --- | --- |']
for name,c in captures.items():
 for b in c['blocks']:
  by_stage={}
  for r in b['results']:
   for stage in r['stages']:
    for code,count in stage.get('errorDetails',{}).get('counts',{}).items():
     target=by_stage.setdefault(stage['name'],{})
     target[code]=target.get(code,0)+count
  for stage,counts in by_stage.items():
   lines.append(f"| {name} | {b['id']} | {b['population']+1} | {stage} | "+', '.join(f'{k}: {v:,}' for k,v in counts.items())+' |')

lines+=['',f'The capacity captures recorded {invalid:,} invalid responses and {total_errors:,} request errors.',
 f'Warmup stages, excluded from measured rates, recorded {warmup_errors:,} additional request errors.',
 'Error categories: '+(json.dumps(error_counts,sort_keys=True) if error_counts else 'none.'),'',
 'Missed arrivals and request errors remain visible in the published data. They are not removed',
 'to obtain a clean chart. These results reflect this PC during the capture; differences from older',
 'idle-PC runs are not attributed to the code change.','',
 '## Scope and verification','',
 'The full sweep completed all 16 stages: 112 live Node/Bun string/stream browser correctness checks, twelve',
 'capacity captures, both full SSR diagnostic API modes, and the server performance suite.',
 'Capacity uses ten-second warmups, fifteen-second concurrency stages, twenty-second normal-loading',
 'stages, and twenty-second offered-load stages. Both populations are retained. SSR diagnostics use',
 '500 sequential samples and 500 concurrency waves per supported framework and runtime.','',
 'The existing client capture remains the source of browser timing,',
 'startup, and heap charts. Those measurements were not rerun or assigned the new SSR capture date.',
 'The public documentation charts are refreshed only for SSR.','',
 'The [structured capture](ssr-production-checkpoint-2026-09-12.json) preserves raw-source identities, capacity',
 'summaries, execution commands and exit statuses, validation evidence, and unchanged historical',
 'browser metadata. Per-driver tails are ranges, not averaged or pooled percentiles.','', 'An initial preloaded capture was interrupted to tighten readiness rechecking before this sweep.', 'It is retained separately and excluded from the final measurements.','']
Path('docs/performance-baselines/ssr-production-checkpoint-2026-09-12.md').write_text('\n'.join(lines),encoding='utf8')
print(json.dumps({'invalidResponses':invalid,'requestErrors':total_errors,'errorCounts':error_counts}))
