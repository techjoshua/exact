import json
from pathlib import Path
p=Path('.tmp/ssr-production-checkpoint/node-stream-arrivals.json')
for b in json.loads(p.read_text())['blocks']:
 counts={}
 for r in b['results']:
  for s in r['stages']:
   for k,v in s.get('errorDetails',{}).get('counts',{}).items():counts[k]=counts.get(k,0)+v
 print(b['id'],b['population']+1,counts)
