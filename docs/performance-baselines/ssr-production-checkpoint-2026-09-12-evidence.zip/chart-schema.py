import json
from pathlib import Path
s=json.loads(Path('apps/docs/src/data/performance-report.json').read_text())['server']
print(list(s))
for k in ['sequential','concurrent','renderOnly','retained']:
 if k in s:print(k,str(s[k])[:1100])
