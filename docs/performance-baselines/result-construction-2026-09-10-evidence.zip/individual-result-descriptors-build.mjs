import fs from 'node:fs';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
let code=fs.readFileSync(root+'result-storage-integrated/server-entry.js','utf8');
function replace(before,after){assert.equal(code.split(before).length,2);code=code.replace(before,after);}
replace('const result = Object.defineProperties({\n\t\thtml: void 0,\n\t\tstate\n\t}, stringResultDescriptors);','const result = Object.defineProperty({\n\t\thtml: void 0,\n\t\tstate\n\t}, "html", stringResultDescriptors.html);');
replace('const hydratable = Object.defineProperties({\n\t\tresumptions: void 0,\n\t\thtmlWithHydration: void 0,\n\t\thtml: void 0,\n\t\tstate: result.state,\n\t\thydrationScript\n\t}, hydratableResultDescriptors);','const hydratable = {\n\t\tresumptions: void 0,\n\t\thtmlWithHydration: void 0,\n\t\thtml: void 0,\n\t\tstate: result.state,\n\t\thydrationScript\n\t};\n\tObject.defineProperty(hydratable,"resumptions",hydratableResultDescriptors.resumptions);\n\tObject.defineProperty(hydratable,"htmlWithHydration",hydratableResultDescriptors.htmlWithHydration);\n\tObject.defineProperty(hydratable,"html",hydratableResultDescriptors.html);');
fs.mkdirSync(root+'individual-result-descriptors',{recursive:true});fs.writeFileSync(root+'individual-result-descriptors/server-entry.js',code);
fs.writeFileSync(root+'individual-result-descriptors-run.mjs',fs.readFileSync(root+'direct-result-create-run.mjs','utf8').replace("candidate:d+'direct-result-create/server-entry.js'","candidate:d+'individual-result-descriptors/server-entry.js'").replace("['assets','large']","['assets']").replace('direct-result-create-results.json','individual-result-descriptors-results.json'));
