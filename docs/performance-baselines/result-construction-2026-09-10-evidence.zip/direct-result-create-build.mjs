import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';
let code=fs.readFileSync('framework-comparison/participants/exact/dist-server/server-entry.js','utf8');
assert.equal(createHash('sha256').update(code).digest('hex'),'fe7f3f5186bd712f4f0eab4820eee07a7261dfc2a2124b92c8271c56fccae72b');
fs.mkdirSync(root+'result-storage-integrated',{recursive:true});fs.writeFileSync(root+'result-storage-integrated/server-entry.js',code);
function replace(before,after){assert.equal(code.split(before).length,2);code=code.replace(before,after);}
replace('const result = Object.defineProperties({\n\t\thtml: void 0,\n\t\tstate\n\t}, stringResultDescriptors);','const result = Object.create(Object.prototype, stringResultDescriptors);\n\tresult.state = state;');
replace('const hydratable = Object.defineProperties({\n\t\tresumptions: void 0,\n\t\thtmlWithHydration: void 0,\n\t\thtml: void 0,\n\t\tstate: result.state,\n\t\thydrationScript\n\t}, hydratableResultDescriptors);','const hydratable = Object.create(Object.prototype, hydratableResultDescriptors);\n\thydratable.state = result.state;\n\thydratable.hydrationScript = hydrationScript;');
fs.mkdirSync(root+'direct-result-create',{recursive:true});fs.writeFileSync(root+'direct-result-create/server-entry.js',code);
let runner=fs.readFileSync(root+'result-storage-run.mjs','utf8').replace("current:d+'proven-reference-integrated/server-entry.js',candidate:d+'result-storage/server-entry.js'","current:d+'result-storage-integrated/server-entry.js',candidate:d+'direct-result-create/server-entry.js'")
 .replace("['bun']","['node','bun']").replace('result-storage-results.json','direct-result-create-results.json');
fs.writeFileSync(root+'direct-result-create-run.mjs',runner);
