import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/',rows=[];
for(const variant of ['result-storage-integrated','direct-result-create','owned-result-create']){
 const path=root+variant+'/audit.mjs';
 fs.writeFileSync(path,fs.readFileSync(root+variant+'/server-entry.js','utf8')+'\nexport {createChunkedStringResult,createChunkedHydratableResult};\n');
 const {createChunkedStringResult:plain,createChunkedHydratableResult:hydrate}=await import(pathToFileURL(resolve(path)));
 const chunks=['a','b'];const value=plain(chunks,{owner:1},undefined,['preload'],7);
 assert.equal(Object.getPrototypeOf(value),Object.prototype);
 assert.deepEqual(Object.keys(value),['html','state','wallClockSnapshot','preloadLinks']);
 chunks.push('c');assert.equal(value.html,'abc');chunks.push('d');assert.equal(value.html,'abc');
 const hydrated=hydrate(value,[],'hydration');assert.equal(hydrated.htmlWithHydration,'abcdhydration');
 assert.deepEqual(Object.keys(hydrated),['resumptions','htmlWithHydration','html','state','hydrationScript','wallClockSnapshot','preloadLinks']);
 let intercepted=0;
 try{
  for(const key of ['state','hydrationScript'])Object.defineProperty(Object.prototype,key,{configurable:true,set(){intercepted++;}});
  const first=plain(['body'],{owner:2});const second=hydrate(first,[],'data');
  if(variant!=='direct-result-create'){assert.equal(intercepted,0);assert.deepEqual(second.state,{owner:2});assert.equal(second.hydrationScript,'data');}
  else assert.ok(intercepted>0);
 }finally{delete Object.prototype.state;delete Object.prototype.hydrationScript;}
 rows.push({variant,intercepted,ordinaryChecks:'passed'});
}
fs.writeFileSync(root+'owned-result-create-audit-'+(process.versions.bun?'bun':'node')+'.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));
