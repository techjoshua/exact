from pathlib import Path
p=Path('docs/performance.md')
s=p.read_text()
s=s.replace('[September 11 completion capture](performance-baselines/ssr-completion-2026-09-11.md)', '[September 11 child-normalization capture](performance-baselines/v8-normalization-full-2026-09-11.md)',1)
needle='## Earlier investigations'
insert='The [V8 bytecode follow-up](performance-baselines/v8-attribute-and-child-normalization-2026-09-11.md)\nretains one child-normalization result array instead of allocating intermediate arrays for nested\nchildren. Public composition semantics are preserved, and large nested lists avoid the former\nvariadic-call argument limit. Focused allocation improvements are separate from the current\napplication throughput measurements.\n\n'
s=s.replace(needle,insert+needle,1)
p.write_text(s)
p=Path('docs/performance-baselines/v8-attribute-and-child-normalization-2026-09-11.md')
s=p.read_text().replace('## Evidence', 'The subsequent [full benchmark checkpoint](v8-normalization-full-2026-09-11.md) refreshes\nHTTP string/stream capacity, browser, startup, heap, and framework measurements for the retained build.\nIt updates the public charts with application measurements independently of the focused results above.\n\n## Evidence',1)
p.write_text(s)
