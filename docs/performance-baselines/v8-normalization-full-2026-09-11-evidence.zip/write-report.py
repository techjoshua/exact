from pathlib import Path
import json
root=Path('.tmp/v8-full')
lines=['# Full benchmarks after child normalization, September 11, 2026','',
'This capture includes the retained child-normalization optimization: one rendering engine, separate',
'application hydration and document-shell ownership, incremental 8192-byte streaming, compiler-proven',
'static heads before blocking tasks, and automatic adaptive Node admission. Native Bun retains',
'immediate admission. React uses its unchanged framework renderer and runtime transport. Both',
'frameworks render their complete authored application and document shell for every request.',
'',
'Production Node 26.8.1 and Bun 1.4.2 ran locally on the same PC with variable foreground usage.',
'Two independent load generators validate complete response hashes. Each population reverses',
'framework order. Values below are the two populations, not a comparison with an earlier idle PC run.',
'String and stream APIs are separate. No response coalescing or cached rendered documents are used.',
'',
'## Sustained capacity','',
'Preloaded capacity isolates rendering and HTTP response delivery; normal loading includes fetching',
'the application data. Both rows use total concurrency 32. RPS is valid completed responses per second.',
'',
'| Runtime | API | Loading | eXact RPS | React RPS | eXact driver p99 ms | React driver p99 ms |',
'| --- | --- | --- | ---: | ---: | --- | --- |']
captures={}
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for lane in ['multi','normal','arrivals']:
   name=runtime+('-stream' if mode=='stream' else '')+'-'+lane
   c=json.loads((root/(name+'.json')).read_text());assert c['complete'];captures[name]=c
   if lane=='arrivals':continue
   values={}
   for id in ['exact','react']:
    rates=[];tails=[]
    for b in sorted((b for b in c['blocks'] if b['id']==id),key=lambda b:b['population']):
     ss=[next(s for s in r['stages'] if s['name']=='total-c32') for r in b['results']]
     rates.append(f'{sum(s["validRps"] for s in ss):,.0f}')
     tails.extend(s['distributions']['responseMs']['p99'] for s in ss)
    values[id]=(' / '.join(rates),f'{min(tails):.1f} to {max(tails):.1f}')
   lines.append(f'| {runtime.title()} | {mode} | {"preloaded" if lane=="multi" else "normal"} | {values["exact"][0]} | {values["react"][0]} | {values["exact"][1]} | {values["react"][1]} |')
lines+=['','## Scheduled demand','',
'Misses are requests the load generator could not start on schedule, distinct from response errors.',
'The public charts retain each runtime, API, offered rate, valid RPS, misses, errors, and response tails.',
'',
'| Runtime/API | Framework | Offered RPS | Valid RPS, two populations | Errors | Missed arrivals |',
'| --- | --- | ---: | ---: | ---: | ---: |']
error_counts={};invalid=0;total_errors=0
for name,c in captures.items():
 for b in c['blocks']:
  for r in b['results']:
   for s in r['stages']:
    if s['name']=='warmup':continue
    invalid+=s.get('invalid',0);total_errors+=s['errors']
    for k,v in s.get('errorDetails',{}).get('counts',{}).items():error_counts[k]=error_counts.get(k,0)+v
 if not name.endswith('arrivals'):continue
 for id in ['exact','react']:
  for rate in [8000,10000]:
   rates=[];errors=misses=0
   for b in sorted((b for b in c['blocks'] if b['id']==id),key=lambda b:b['population']):
    ss=[next(s for s in r['stages'] if s['name']==f'total-arrivals-{rate}') for r in b['results']]
    rates.append(f'{sum(s["validRps"] for s in ss):,.0f}')
    errors+=sum(s['errors'] for s in ss)
    misses+=sum(s['missedCapacity']+s['missedLag']+s['missedDeadline'] for s in ss)
   lines.append(f'| {c["runtimeId"].title()} {c["renderMode"]} | {"eXact" if id=="exact" else "React"} | {rate:,} | {" / ".join(rates)} | {errors:,} | {misses:,} |')

lines+=['',f'The capacity captures recorded {invalid:,} invalid responses and {total_errors:,} request errors.',
 'Error categories: '+(json.dumps(error_counts,sort_keys=True) if error_counts else 'none.'),'',
 'Missed arrivals and request errors remain visible in the published data. They are not removed',
 'to obtain a clean chart. These results reflect this PC during the capture; differences from older',
 'idle-PC runs are not attributed to the code change.','',
 '## Client measurements','',
 'All five frameworks use the common in-memory replay delivery path, with framework servers stopped',
 'during client timing. The capture includes 30 balanced navigation/interaction rounds, startup at',
 '1x/4x/6x CPU, and five heap samples per framework. Both eXact and React render their authored shells',
 'before replay capture. These client measurements are separate from HTTP capacity.','',
 '| Client metric | eXact mean | React mean | Unit |','| --- | ---: | ---: | --- |']
report=json.loads((root/'report-data.json').read_text())
for chart in report['browserCharts']:
 values={s['name']:s['stats']['mean'] for s in chart['series']}
 lines.append(f"| {chart['title']} | {values['Exact']:.3f} | {values['React']:.3f} | {chart['unit']} |")
lines+=['','## Retained change and evidence','',
 'The only retained runtime change is [child normalization](v8-attribute-and-child-normalization-2026-09-11.md):',
 'nested children append into one owned result array instead of allocating and copying intermediate',
 'arrays. Attribute-inlining and earlier validator/layout experiments remain rejected. The current',
 'benchmark app has little nested-child work, so the focused normalization speedup is not presented',
 'as an equivalent application throughput improvement.','',
 'The shared renderer, authored shell behavior, 8192-byte streaming buffer, hydration contracts, and',
 'automatic Node admission are unchanged. Bun retains its existing immediate admission behavior.',
 'No alternate renderer, cached response, request coalescing, or React optimization is introduced.','',
 'All 112 live Node/Bun string/stream browser checks passed before timing. Core and SSR tests, type',
 'checking, compiled-artifact compatibility, and platform/package boundaries were validated for the',
 'retained change. The final publication checks are recorded in the accompanying evidence.','',
 '[Full structured capture](v8-normalization-full-2026-09-11.json) preserves all source identities,',
 'raw capture links, execution journal, client/SSR reports, and supplemental framework benchmarks.',
 'All twelve capacity captures and both full SSR diagnostic modes use the same persistent telemetry',
 'control transport. Build identity verification ensures the published measurements match the',
 'retained application artifacts.','']
Path('docs/performance-baselines/v8-normalization-full-2026-09-11.md').write_text('\n'.join(lines),encoding='utf8')
print(json.dumps({'invalidResponses':invalid,'requestErrors':total_errors,'errorCounts':error_counts}))
