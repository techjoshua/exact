from pathlib import Path
import json,statistics
root=Path('.tmp/v8-full')
steps=json.loads((root/'execution.json').read_text());print('Completed',sum(s.get('code')==0 for s in steps),'stages; latest:',steps[-1]['name'])
p=root/'browser.json'
if p.exists():
 c=json.loads(p.read_text())
 for id in ['exact-controlled','react-controlled']:
  s=c['browser'][id]['samples']
  print(id,'navigation',round(statistics.mean(x['navigation']['durationMs'] for x in s),2),'FCP',round(statistics.mean(x['navigation']['firstContentfulPaintMs'] for x in s),2),'feedback',round(statistics.mean(x['optimisticFeedbackMs'] for x in s),2),'settlement',round(statistics.mean(x['settlementMs'] for x in s),2))
for p in sorted(root.glob('*-multi.json')):
 c=json.loads(p.read_text());rows=[]
 for b in c['blocks']:
  ss=[next(s for s in r['stages'] if s['name']=='total-c32') for r in b['results']]
  rows.append([b['id'],b['population'],round(sum(s['validRps'] for s in ss)),sum(s['errors'] for s in ss)])
 print(p.stem,'complete',c['complete'],rows)
