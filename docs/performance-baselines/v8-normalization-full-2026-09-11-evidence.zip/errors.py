from pathlib import Path
import json,collections
for p in sorted(Path('.tmp/v8-full').glob('*.json')):
 if not any(p.stem.endswith('-'+lane) for lane in ['multi','normal','arrivals']):continue
 c=json.loads(p.read_text());counts=collections.Counter()
 for b in c.get('blocks',[]):
  for r in b['results']:
   for s in r['stages']:
    if s['errors']:counts.update({b['id']+':'+k:v for k,v in s.get('errorDetails',{}).get('counts',{}).items()})
 if counts:print(p.stem,dict(counts))
