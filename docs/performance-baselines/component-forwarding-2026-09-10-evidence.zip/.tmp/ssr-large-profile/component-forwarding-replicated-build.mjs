import fs from 'node:fs/promises';
const root='.tmp/ssr-large-profile/';
await fs.mkdir(root+'component-forwarding-replicated',{recursive:true});
const source=(await fs.readFile(root+'structural-stack-http-run.mjs','utf8')).replaceAll('structural-stack-http','component-forwarding-replicated').replaceAll("'structural-stack'","'component-forwarding'");
await fs.writeFile(root+'component-forwarding-replicated-run.mjs',source);
