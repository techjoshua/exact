import fs from 'node:fs/promises';
import prettier from 'prettier';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'component-forwarding-integrated',{recursive:true});
for(const [source,target] of [['framework-comparison/participants/exact/dist-server/server-entry.js','server-entry.js'],['framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js','bun-server-entry.js']])await fs.copyFile(source,root+'component-forwarding-integrated/'+target);
const doc='docs/ssr-hydration.md';const config=await prettier.resolveConfig(doc);
await fs.writeFile(root+'component-forwarding/formatted-doc.md',await prettier.format(await fs.readFile(doc,'utf8'),{...config,filepath:doc}));
await fs.writeFile(root+'component-forwarding-integrated-browser.mjs',(await fs.readFile(root+'conditional-emission-browser.mjs','utf8')).replaceAll('conditional-emission','component-forwarding-integrated'));
for(const suffix of ['check.mjs','pressure.mjs','run.mjs'])await fs.writeFile(root+'component-forwarding-integrated-'+suffix,(await fs.readFile(root+'component-forwarding-'+suffix,'utf8')).replaceAll('component-forwarding','component-forwarding-integrated'));
