from pathlib import Path
from collections import defaultdict
from statistics import mean
import json,hashlib,zipfile,re
root=Path('.tmp/ssr-large-profile')
summary=json.loads((root/'component-forwarding/summary.json').read_text())
integrated=json.loads((root/'component-forwarding-integrated-results.json').read_text())
allocations=json.loads((root/'component-forwarding-integrated/allocations.json').read_text())
assert len(integrated)==24 and len(allocations)==8
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for row in integrated+allocations:assert sha(row['entry'])==row['artifactSha256']
for source,target in [('framework-comparison/participants/exact/dist-server/server-entry.js','server-entry.js'),('framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js','bun-server-entry.js')]:assert sha(source)==sha(root/'component-forwarding-integrated'/target)
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  assert '14 passed' in (root/f'component-forwarding-integrated/browser-{runtime}-{mode}.log').read_text()
test_bytes=(root/'component-forwarding/package-tests.log').read_bytes()
test_log=test_bytes.decode('utf-16' if test_bytes[:2] in [b'\xff\xfe',b'\xfe\xff'] else 'utf-8')
test_log=re.sub(r'\x1b\[[0-9;]*m','',test_log)
assert '372 passed' in test_log
groups=defaultdict(lambda:defaultdict(list))
for row in integrated:groups[(row['runtimeId'],row['scenario'])][row['variant']].append(row['usPerRender'])
table=['| Runtime / fixture | Previous | Rebuilt candidate | React |','| --- | ---: | ---: | ---: |']
for key,data in groups.items():table.append('| '+' / '.join(key)+' | '+' | '.join(f'{mean(data[v]):.2f}' for v in ['current','candidate','react'])+' |')
heap=['| Fixture | Previous bytes/render | Rebuilt candidate | Change |','| --- | ---: | ---: | ---: |']
for scenario in ['small','large']:
 values={v:mean(r['sampledBytesPerRender'] for r in allocations if r['scenario']==scenario and r['variant']==v) for v in ['current','candidate']}
 heap.append(f"| {scenario} | {values['current']:,.0f} | {values['candidate']:,.0f} | {(values['candidate']/values['current']-1)*100:+.2f}% |")
http=['| Runtime / mode | Previous RPS | Prototype RPS | React RPS |','| --- | ---: | ---: | ---: |']
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  http.append('| '+runtime+' / '+mode+' | '+' | '.join(f"{summary['http']['means'][f'{runtime} / {mode} / {v}']:,.0f}" for v in ['baseline','compiled','react'])+' |')
replicas=['| Population | Previous RPS | Prototype RPS | Change |','| --- | ---: | ---: | ---: |']
for population in [0,1]:
 old=summary['replicas']['means'][f'{population} / baseline'];new=summary['replicas']['means'][f'{population} / combined']
 replicas.append(f'| {population+1} | {old:,.0f} | {new:,.0f} | {(new/old-1)*100:+.2f}% |')
report=Path('docs/performance-baselines/component-forwarding-2026-09-10.md');assert not report.exists()
report.write_text('''# Shared component forwarding callbacks

Status: source integrated and functionally validated. Allocation reduction measured;
rebuilt HTTP confirmation remains outstanding. This is not an identified fix for
the dominant HTTP slowdown, and the overall React comparison goal remains open.

## Change and hypothesis

Earlier target-forwarding changes removed closures around prepared programs and
direct component content. component.ts still constructed two callbacks per
component boundary, capturing context and options already stored on the artifact
execution. The new shared methods use that existing execution as their receiver.
No execution wrapper, WeakSet, cache or second renderer is introduced. Descendants
retain separate executions, selected owners, publication and cleanup. This removes
two explicit closure constructions per component invocation; it does not remove
component work, validation, hydration or lifecycle boundaries.

The pre-experiment expectation was approximately 1 to 3 percent improvement on
component-heavy documents if allocation reduction mattered. The tradeoff is reading
context/options through the execution instead of closure captures. Fewer source
allocations do not, on their own, establish fewer heap bytes or faster requests.

The source change is in render/component.ts. The internal artifact-execution type
now requires its receiver explicitly for child-forwarding methods, protecting
against accidental detached calls. Engineering documentation describes that
ownership. No public API, compiler helper signature or ABI semantics changed;
public application documentation needs no change for this internal implementation.

## Prototype evidence

The scratch builder changes exactly two callback arguments at the component
boundary in both Node and native Bun artifacts. Each variant matches 16 complete
documents per runtime, including string/stream output, dynamic assets, changed
content and missing routes. Twelve forced-pressure/failure checks per runtime
match writes, outputs and failures. No validation is bypassed.

Twenty-four fresh-process string timing populations use 50,000 warmups and 20,000
measured renders, two opposite implementation orders, three/96 incidents and
production Node 26.8.1/Bun 1.4.2. Node is essentially flat in the aggregate. Bun
improves in all four individual comparisons: means 28.32 to 27.27 microseconds for
the standard fixture and 214.72 to 211.23 for the large fixture. Full document
hashes match. These portable render timings are not HTTP RPS.

The first HTTP screen uses original workers and native runtime adapters. For each
runtime/mode, current, prototype and React workers warm for ten seconds apiece,
then execute six rotated orders of 1.5-second measurement blocks. Two separate
drivers use concurrency 16 each. Processes run below normal priority; no build,
test or profiler runs concurrently. Exact responses must match completely.

'''+ '\n'.join(http)+'''

This screen has 987,205 valid measured responses and zero errors. Its apparent
23.5 percent Node string gain is not accepted as a causal estimate: a fresh-worker
replica check fails to reproduce it.

That follow-up runs two independent workers per implementation in each of two
populations, reversing implementation startup assignments. Each worker receives
100,000 validated warmup requests and eight balanced 1.5-second blocks. It uses
the original Node worker and the same component-generated complete document.

'''+ '\n'.join(replicas)+'''

The replica capture has 885,462 valid measured responses and zero errors, excluding
800,000 warmup requests and preflights. Two identical previous-build workers in
the first population average 8,061 and 10,242 RPS. This large worker variation
prevents treating the first screen's implementation difference as an improvement.
The combined label in raw replica rows refers to this forwarding prototype, as
identified by its artifact paths and hashes.

## Integrated validation and measurements

The source implementation is rebuilt through the SSR TypeScript package and the
comparison application's client, Node SSR and native Bun SSR targets. Both rebuilt
entries pass the same 16-document and 12-pressure checks per runtime. All 372 SSR
tests across 60 files pass. All 56 comparison browser checks pass across Node/Bun
and string/stream modes. Targeted ESLint and formatting, source architecture,
JSDoc, explicit-any, compiled ABI, frozen release ABI, platform boundary and package
contents checks pass.

The documentation formatter flag was line-ending normalization; applying the
formatted UTF-8 output did not rewrite its prose. The first direct package-content
command failed with Windows spawn EINVAL when attempting npm.cmd. Supplying the
installed npm CLI through the script's supported npm_execpath environment allowed
the check to complete. No package-content defect was reported and the check was
not bypassed. The explicit receiver type was added after the runtime test run;
it changes no emitted behavior and the subsequent package build succeeds.

Twenty-four further fresh-process string timing populations use the same long
warmup and measurement counts against the frozen previous artifact and React.
Mean microseconds per complete document, lower is better:

'''+ '\n'.join(table)+'''

The rebuilt Bun candidate improves in all four pairs, more modestly than the
prototype. Node's standard result is close; the large result is mixed, with one
approximately 3 percent regression and one effectively flat pair. These data do
not justify claiming a universal render-speed improvement. All artifact hashes
and complete-document identities are checked. No claim is made that the earlier
HTTP prototype numbers are measurements of this rebuilt artifact.

Eight separate Node heap-sampling populations compare previous and rebuilt code
in both orders for the standard and large fixtures. Each warms 50,000 renders and
samples 10,000, with a 16 KiB sampling interval and collected minor/major-GC objects
included. Full document hashes match. The sampling-based allocation estimates are:

'''+ '\n'.join(heap)+'''

Both pairs reduce sampled allocation in each fixture. These are estimates of
allocated bytes, not exact allocation counts, retained heap or measured GC pause
improvements. Sampling overhead makes these unsuitable as render/HTTP timings.

## Current decision and remaining work

Keep the integrated implementation available for rebuilt HTTP confirmation. It
has a measured allocation reduction and consistent modest Bun string-render gains,
with functional, lifecycle and browser coverage passing. The Node large-string
timing tradeoff and native Bun stream screen remain explicit concerns; neither is
hidden behind a minimum-improvement threshold. Do not call the change a resolved
HTTP bottleneck or claim the first screen's 23.5 percent gain.

The actual HTTP gap remains unexplained in its dominant part. Earlier pathname
copying establishes a small JSON representation contribution, while replica
variation is a separate measurement problem. Stack conversion and payload-size
equalization do not explain the dominant gap. Further work must distinguish those
facts from a claim to have found its root cause.

Current rebuilt Node artifact SHA-256: `'''+sha(root/'component-forwarding-integrated/server-entry.js')+'''`.
Current rebuilt Bun artifact SHA-256: `'''+sha(root/'component-forwarding-integrated/bun-server-entry.js')+'''`.

The adjacent archive includes scripts, frozen previous/prototype/rebuilt artifacts,
fixture, raw timings and HTTP replicas, warmup records, allocation profiles, source
files, validation logs, this report and a verified SHA-256 inventory. Workspace
dependencies are not reproduced as a complete standalone distribution.
''',encoding='utf8')
files={report,Path('.tmp/positional-leaves/data.json')}
for name in ['component-forwarding','component-forwarding-integrated','component-forwarding-replicated']:
 files.update(p for p in (root/name).rglob('*') if p.is_file())
 files.update(p for p in root.glob(name+'-*') if p.is_file())
files.update(root/'conditional-emission'/f for f in ['server-entry.js','bun-server-entry.js'])
files.add(root/'direct-execution-target-allocation-worker.mjs')
files.update(p for p in (root/'structural-count-warmup').glob('*.mjs'))
files.update(Path(p) for p in ['packages/ssr/src/render/component.ts','packages/ssr/src/render/server-artifact-context.ts','docs/ssr-hydration.md','framework-comparison/src/ssr-benchmark-worker.mjs','framework-comparison/src/ssr-worker-controller.mjs','framework-comparison/src/ssr-load-process-owner.mjs','framework-comparison/src/ssr-run-environment.mjs','scripts/development-process-lifecycle.mjs','framework-comparison/participants/react/dist-server/server-entry.js','framework-comparison/participants/react/dist-bun-server/bun-server-entry.js'])
archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={p.as_posix():sha(p) for p in sorted(files)}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files):z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,digest in json.loads(z.read('SHA256.json')).items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps({'report':str(report),'archive':str(archive),'files':len(files)},indent=2))
