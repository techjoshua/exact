import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';const rows=[];
for(const scenario of ['small','large'])for(let round=0;round<2;round++)for(const variant of round?['candidate','current']:['current','candidate']){
 const entry=root+(variant==='current'?'conditional-emission':'component-forwarding-integrated')+'/server-entry.js';
 const output=root+`component-forwarding-integrated/${scenario}-${round}-${variant}.heapprofile`;
 const result=spawnSync(process.execPath,[root+'direct-execution-target-allocation-worker.mjs',entry,scenario,output],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(result.status!==0)throw Error(result.stderr+result.stdout);
 const row={variant,round,...JSON.parse(result.stdout)};
 const prior=rows.find(r=>r.scenario===scenario);if(prior)assert.equal(row.hash,prior.hash);
 const profile=JSON.parse(fs.readFileSync(output,'utf8'));
 function total(node){return node.selfSize+node.children.reduce((n,child)=>n+total(child),0);}
 row.sampledBytesPerRender=total(profile.head)/row.iterations;
 rows.push(row);fs.writeFileSync(root+'component-forwarding-integrated/allocations.json',JSON.stringify(rows,null,2));
 console.log(scenario,round,variant,row.sampledBytesPerRender.toFixed(0));
}
