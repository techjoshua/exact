import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'component-forwarding',{recursive:true});const counts=[];
for(const file of ['server-entry.js','bun-server-entry.js']){
 const source=await fs.readFile(root+'conditional-emission/'+file,'utf8');
 const ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);const edits=[];
 function visit(n){
  if(ts.isFunctionDeclaration(n)&&n.name?.text==='renderComponentReference'){
   function inspect(child){
    if(ts.isCallExpression(child)&&child.expression.getText(ast)==='renderServerComponentArtifactOutput'){
     for(const [index,name] of [[4,'auditRenderArtifactChildren'],[5,'auditRenderArtifactChild']]){
      const arg=child.arguments[index];if(!ts.isArrowFunction(arg))throw Error('Unexpected callback');
      edits.push({start:arg.getStart(ast),end:arg.end,text:name});
     }
    }
    ts.forEachChild(child,inspect);
   }
   inspect(n);
  }
  ts.forEachChild(n,visit);
 }
 visit(ast);if(edits.length!==2)throw Error('Missing component forwarding callbacks');
 let output=source;
 for(const e of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,e.start)+e.text+output.slice(e.end);
 output+=`
/** Uses the existing artifact execution as receiver, retaining its request and options. */
function auditRenderArtifactChildren(children,owner){return renderChildren(this.context,children,owner,this.options,true);}
/** Descendant publication remains on the normal component boundary. */
function auditRenderArtifactChild(child,owner){return renderComponentReference(this.context,child,owner,this.options,true,true);}
`;
 await fs.writeFile(root+'component-forwarding/'+file,output);counts.push({file,removedClosuresPerComponent:edits.length});
}
await fs.writeFile(root+'component-forwarding/sites.json',JSON.stringify(counts,null,2));console.log(counts);
for(const suffix of ['check.mjs','run.mjs'])await fs.writeFile(root+'component-forwarding-'+suffix,(await fs.readFile(root+'writer-output-pool-'+suffix,'utf8')).replaceAll('writer-output-pool','component-forwarding'));
await fs.writeFile(root+'component-forwarding-pressure.mjs',(await fs.readFile(root+'child-drain-elision-pressure.mjs','utf8')).replaceAll('child-drain-elision','component-forwarding'));
let run=await fs.readFile(root+'component-forwarding-run.mjs','utf8');
run=run.replace("['string','stream']","['string']").replace("scenario,'5000'","scenario,'20000'").replace("fs.readFileSync(d+'final-rope-worker.mjs','utf8')","fs.readFileSync(d+'final-rope-worker.mjs','utf8').replace('warmups=Math.min(5000,count)','warmups=50000')");
await fs.writeFile(root+'component-forwarding-run.mjs',run);
