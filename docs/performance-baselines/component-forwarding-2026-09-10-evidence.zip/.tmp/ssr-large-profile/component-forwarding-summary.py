from pathlib import Path
from collections import defaultdict
from statistics import mean
import json,hashlib
root=Path('.tmp/ssr-large-profile')
sets={name:json.loads((root/file).read_text()) for name,file in [('render','component-forwarding-results.json'),('http','component-forwarding/http.json'),('replicas','component-forwarding-replicated/http.json')]}
assert [len(sets[k]) for k in ['render','http','replicas']]==[24,72,64]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
output={}
for name,rows in sets.items():
 groups=defaultdict(list);valid=errors=0
 for row in rows:
  assert sha(row['entry'])==row['artifactSha256']
  if name=='render':key=(row['runtimeId'],row['scenario'],row['variant']);value=row['usPerRender']
  elif name=='http':key=(row['runtime'],row['mode'],row['variant']);value=row['rps']
  else:
   assert sha(row['workerFile'])==row['workerSha256']
   key=(row['population'],row['implementation']);value=row['rps']
  groups[key].append(value)
  if name!='render':
   for result in row['results']:
    for stage in result['stages']:
     assert stage['started']==stage['completed']==stage['valid']
     valid+=stage['valid'];errors+=stage['errors']
 assert errors==0
 output[name]={'means':{' / '.join(map(str,k)):mean(v) for k,v in groups.items()},'valid':valid,'errors':errors}
output['replicaWorkers']={}
for population in [0,1]:
 for replica in ['replica-a','replica-b','replica-c','replica-d']:
  rows=[r for r in sets['replicas'] if r['population']==population and r['variant']==replica]
  output['replicaWorkers'][f'{population} / {replica} / {rows[0]["implementation"]}']=mean(r['rps'] for r in rows)
(root/'component-forwarding/summary.json').write_text(json.dumps(output,indent=2))
print(json.dumps(output,indent=2))
