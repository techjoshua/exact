import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const input='.tmp/ssr-large-profile/scalar-proof-shared/server-entry.js';
const output='.tmp/ssr-large-profile/direct-domain-probe/server-entry.js';
const before=readFileSync(input,'utf8');
const needle='inComponentDomain(context, () => server.render.call(frame, props))';
assert.equal(before.split(needle).length-1,3);
const after=before.replaceAll(needle,'prototypeCallServerRender(context, server, frame, props)')+`
function prototypeCallServerRender(context, server, frame, props) {
 const domain=context.componentDomain;
 if(!domain) return server.render.call(frame,props);
 const previous=componentDomainRuntimeState.activeDomain;
 componentDomainRuntimeState.activeDomain=domain;
 try { return server.render.call(frame,props); }
 finally { componentDomainRuntimeState.activeDomain=previous; }
}
`;
mkdirSync('.tmp/ssr-large-profile/direct-domain-probe',{recursive:true});
writeFileSync(output,after);
writeFileSync('.tmp/ssr-large-profile/direct-domain-probe/provenance.json',JSON.stringify({input,output,inputSha256:createHash('sha256').update(before).digest('hex'),outputSha256:createHash('sha256').update(after).digest('hex'),hypothesis:'Remove one immediately invoked domain closure per direct server render while preserving the active domain, receiver, prop access ordering, and finally restoration. Expected 0-2% small and 1-4% large improvement if closure allocation is material. Artifact-only experiment; no production change.'},null,2));
