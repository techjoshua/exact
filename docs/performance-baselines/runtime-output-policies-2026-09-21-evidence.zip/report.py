from pathlib import Path
import json
p=Path(__file__).parent
rows=json.loads((p/'summary.json').read_text())
journal=json.loads((p/'execution.json').read_text())
assert len(journal)==24 and all(x.get('code')==0 for x in journal)
comparisons=[]
for workload in ['demand','concurrency','large']:
 for runtime,mode in [('node','string'),('bun','stream'),('bun','string'),('node','stream')]:
  prefix=f'{workload}-{runtime}-{mode}'
  for stage in sorted({r['stage'] for r in rows if r['capture'].startswith(prefix)}, key=lambda x:int(x.rsplit('-',1)[-1].removeprefix('c'))):
   group={(r['variant'],r['framework']):r for r in rows if r['capture'].startswith(prefix) and r['stage']==stage}
   assert len(group)==4
   c=group['control','exact'];n=group['candidate','exact'];cr=group['control','react'];nr=group['candidate','react']
   comparisons.append(dict(workload=workload,runtime=runtime,mode=mode,stage=stage,control=c,candidate=n,reactControl=cr,reactCandidate=nr,ratioChangePercent=100*((n['validRps']/nr['validRps'])/(c['validRps']/cr['validRps'])-1)))
(p/'comparison.json').write_text(json.dumps(comparisons,indent=2)+'\n')
text=['# Runtime and output policy screening, September 21, 2026','', 'Measured source baseline: `70b73fa8`. Twenty-four private captures (12 pairs) completed. Identical renderer artifacts and complete response identities were asserted for each pair. No compiled component specialization.','', 'Decisions: reject Node string retention. Carry Bun streaming work windows forward to integration and pressure-budget experiments. Bun string shorter probes improve scheduled-demand latency but fail the small-page throughput-ratio guard; do not accept them on latency alone. Node streaming uses identical code on both sides as a negative control.','', 'This is screening evidence from dedicated output-mode hosts, not a shipped mixed-mode implementation. Each capture uses two drivers and a React comparison. Concurrency runs have 10-second warmup and four 15-second measurement stages. Demand runs have 30-second warmup and 60-second measurement at 10,000 offered RPS. Large cases expand both frameworks to 96 rows. Ratios use valid responses divided by the union of driver measurement spans, including drain. p99 ranges describe separate drivers, not confidence intervals.','']
for workload in ['demand','concurrency','large']:
 text += ['## '+workload.capitalize(),'','| Runtime/API | Stage | eXact control RPS | eXact candidate RPS | React control RPS | React candidate RPS | Ratio change |','| --- | --- | ---: | ---: | ---: | ---: | ---: |']
 for r in comparisons:
  if r['workload']!=workload:continue
  text.append(f"| {r['runtime']} {r['mode']} | {r['stage']} | {r['control']['validRps']:,.0f} | {r['candidate']['validRps']:,.0f} | {r['reactControl']['validRps']:,.0f} | {r['reactCandidate']['validRps']:,.0f} | {r['ratioChangePercent']:+.1f}% |")
 text += ['']
text += ['## Scheduled-demand latency','','| Runtime/API | Control p99 | Candidate p99 | Control capacity misses | Candidate capacity misses |','| --- | ---: | ---: | ---: | ---: |']
for r in comparisons:
 if r['workload']!='demand':continue
 c=r['control'];n=r['candidate']
 text.append(f"| {r['runtime']} {r['mode']} | {min(c['p99']):.2f}-{max(c['p99']):.2f} ms | {min(n['p99']):.2f}-{max(n['p99']):.2f} ms | {c['capacityMissPercent']:.2f}% | {n['capacityMissPercent']:.2f}% |")
text += ['', 'Raw captures preserve warmup, errors, invalid responses, and telemetry. Existing React Node-stream overload errors remain in the captures and are not treated as eXact gains. Focused results do not replace the public full-benchmark charts.','']
(p/'report.md').write_text('\n'.join(text))
print('Wrote comparison.json and report.md')
