/** Selects experimental host policies without modifying a component or renderer artifact. */
export function policyFor(runtime,mode,variant){
 if(!['node','bun'].includes(runtime)||!['string','stream'].includes(mode)||!['control','candidate'].includes(variant))throw new TypeError('Invalid experimental path');
 if(variant==='control'||(runtime==='node'&&mode==='stream'))return `${runtime}-control`;
 return `${runtime}-${mode}`;
}
/** Uses the selected adapter only for its corresponding native HTTP dispatcher. */
export async function selectRequestAdapters(runtime,mode,variant){
 const policyId=policyFor(runtime,mode,variant);
 const [node,bun]=await Promise.all([
  import(`./adapters/${runtime==='node'?policyId:'node-control'}/index.js`),
  import(`./adapters/${runtime==='bun'?policyId:'bun-control'}/index.js`)
 ]);
 return {policyId,createNodeHandler:node.createNodeHandler,createBunRequestHandler:bun.createBunRequestHandler};
}
