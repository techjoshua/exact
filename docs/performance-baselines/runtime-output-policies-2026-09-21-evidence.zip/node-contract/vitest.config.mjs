import {defineConfig} from 'vitest/config';
export default defineConfig({test:{include:['.tmp/mode-paths-2026-09-21/node-contract/*.test.ts'],exclude:[],maxWorkers:1}});
