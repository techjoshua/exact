from pathlib import Path
from shutil import copytree
import json
p=Path('.tmp/mode-paths-2026-09-21');old=Path('.tmp/bun-stream-codec-2026-09-21')
for name,src in {
 'node-control':'framework-adapters/node-adapter/dist',
 'bun-control':'framework-adapters/bun-adapter/dist',
 'node-string':str(old/'node-retained-headroom'),
 'bun-string':str(old/'bun-short-controls'),
 'bun-stream':'.tmp/bun-loop-interval-2026-09-21/budget-half'
}.items():copytree(src,p/'adapters'/name,dirs_exist_ok=True)
s=(old/'current-worker.mjs').read_text()
s=s.replace("import { createNodeHandler, writeNodeResponse } from '@exactjs/node-adapter';", "import { writeNodeResponse } from '@exactjs/node-adapter';\nimport { selectRequestAdapters } from './policies.mjs';")
s=s.replace("import { createBunRequestHandler } from './current/index.js';",'')
s=s.replace("const transport = process.argv[5];", "const transport = process.argv[5];\nconst {createNodeHandler,createBunRequestHandler,policyId}=await selectRequestAdapters(runtimeId,renderMode,process.env.EXPERIMENT_VARIANT??'control');")
s=s.replace("return { ...session, ...incidents };", "const result = { ...session, ...incidents };\n\tif (process.env.EXPERIMENT_ROWS === '96') result.incidents=Array.from({length:96},(_,i)=>({...result.incidents[i%result.incidents.length],id:'inc-'+(100+i)}));\n\treturn result;")
assert "EXPERIMENT_ROWS" in s
(p/'worker.mjs').write_text(s)
s=(old/'actual-host-matrix.mjs').read_text()
s=s.replace("artifacts.experimentalAdapter = await measureSsrArtifact(resolve('.tmp/bun-stream-codec-2026-09-21/current'));", "artifacts.experimentalAdapters = await measureSsrArtifact(resolve('.tmp/mode-paths-2026-09-21/adapters'));\nartifacts.worker=await measureSsrArtifact(resolve('.tmp/mode-paths-2026-09-21/worker.mjs'));\nartifacts.policy=await measureSsrArtifact(resolve('.tmp/mode-paths-2026-09-21/policies.mjs'));")
s=s.replace("kind:'multi-driver-preloaded-ssr',", "kind:'multi-driver-preloaded-ssr',experiment:{variant:process.env.EXPERIMENT_VARIANT??'control',rows:process.env.EXPERIMENT_ROWS??'default',order:process.env.EXPERIMENT_ORDER??'exact-first'},")
s=s.replace("population?['react','exact']:['exact','react']", "process.env.EXPERIMENT_ORDER==='react-first'?['react','exact']:['exact','react']")
s=s.replace("workerPath:resolve('.tmp/bun-stream-codec-2026-09-21/current-worker.mjs')", "workerPath:resolve('.tmp/mode-paths-2026-09-21/worker.mjs')")
s=s.replace("environment:{COMPARISON_SSR_BOUNDED_TELEMETRY:'1',", "environment:{COMPARISON_SSR_BOUNDED_TELEMETRY:'1',EXPERIMENT_VARIANT:process.env.EXPERIMENT_VARIANT??'control',EXPERIMENT_ROWS:process.env.EXPERIMENT_ROWS??'default',")
s=s.replace("report.complete=true;", "assert.deepEqual(await measureSsrArtifact(resolve('.tmp/mode-paths-2026-09-21/adapters')),artifacts.experimentalAdapters);report.complete=true;")
(p/'capture.mjs').write_text(s)
for name,source in [('concurrency','matched-plan'),('demand','demand-10000')]:
 (p/(name+'.json')).write_text((old/(source+'.json')).read_text())
(p/'smoke.json').write_text(json.dumps({'preloaded':True,'drivers':2,'stages':[{'name':'smoke','mode':'concurrency','concurrency':2,'durationMs':1000}]}))
