import {spawn} from 'node:child_process';
import {openSync,closeSync,readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {policyFor,selectRequestAdapters} from './policies.mjs';
const dir='.tmp/mode-paths-2026-09-21';
const smoke=process.argv.includes('--smoke');
const journal=[];
let caseIndex=0;
for(const workload of smoke?['smoke']:['demand','concurrency','large']){
 for(const [runtime,mode] of [['node','string'],['bun','stream'],['bun','string'],['node','stream']]){
  const pair=[];
  const variants=(caseIndex++%2)?['candidate','control']:['control','candidate'];
  for(const variant of variants){
   const policy=policyFor(runtime,mode,variant);
   const adapters=await selectRequestAdapters(runtime,mode,variant);
   assert.equal(adapters.policyId,policy);
   assert.equal(typeof adapters.createNodeHandler,'function');assert.equal(typeof adapters.createBunRequestHandler,'function');
   const name=`${workload}-${runtime}-${mode}-${variant}`;
   const plan=workload==='large'?'concurrency':workload;
   const args=[`${dir}/capture.mjs`,`${dir}/${plan}.json`,`${dir}/${name}.json`,runtime];
   const env={NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:mode,EXPERIMENT_VARIANT:variant,EXPERIMENT_ROWS:workload==='large'?'96':'default',EXPERIMENT_ORDER:caseIndex%2?'exact-first':'react-first'};
   const step={name,policy,args,env,startedAt:new Date().toISOString()};journal.push(step);
   const save=()=>writeFileSync(`${dir}/${smoke?'smoke-':''}execution.json`,JSON.stringify(journal,null,2));save();console.log('START',name,policy);
   const fd=openSync(`${dir}/${name}.log`,'w');
   try{await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{env:{...process.env,...env},stdio:['ignore',fd,fd]});step.pid=child.pid;save();child.once('error',fail);child.once('exit',code=>{step.code=code;code===0?done():fail(Error(`${name}: ${code}`));});});}
   finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}
   const capture=JSON.parse(readFileSync(`${dir}/${name}.json`));assert.equal(capture.complete,true);pair.push(capture);
   console.log('DONE',name);
  }
  assert.deepEqual(pair[0].responseIdentities,pair[1].responseIdentities,'Control and candidate must render identical responses');
  assert.deepEqual(pair[0].artifacts.exact,pair[1].artifacts.exact,'Component/renderer bundle must be identical');
  assert.deepEqual(pair[0].artifacts.react,pair[1].artifacts.react,'React control must be identical');
 }
}
console.log(smoke?'SMOKE PASSED':'MATRIX COMPLETE');
