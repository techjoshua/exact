# Coordinated runtime/API policy experiment

Source baseline: 70b73fa8. This is a private screening configuration, not a shipped API change.

`policies.mjs` selects independent request-adapter implementations using the runtime and rendering API chosen by the host. The worker's API mode also selects its existing renderer entry point. Neither component code nor renderer bundles are rebuilt or patched. The selector is outside the request hot path.

| Path | Candidate | Control |
| --- | --- | --- |
| Node string | Existing selection rules; retain responsive scheduling below 95% utilization only when rate exceeds the measured control and completions keep up with admissions | Shipping Node adapter |
| Node streaming | Shipping Node adapter, unchanged | Same shipping Node adapter |
| Bun string | Shorter control probes | Shipping Bun adapter |
| Bun streaming | Unconditional 0.5 ms work window bounded by an immediate marker | Shipping Bun adapter |

One coordinated runner serially executes small-page 10,000-RPS scheduled demand, small-page concurrency sweeps, and 96-row concurrency sweeps. All four paths are measured with candidate/control pairs and React controls. Variant order alternates by path; framework order alternates correspondingly. Each case starts fresh service, worker, and driver processes. Per-request CPU sampling remains unchanged. This is not a claim about policies on a mixed-mode server; any production integration must preserve host accounting and ownership for mixed traffic.

Preflight: eight runtime/API/variant smoke captures passed. All eXact complete-response byte lengths and SHA-256 hashes matched across all eight. Node retention candidate passed all 15 existing Node gate contract tests. Bun shorter-probe candidate previously passed all 24 existing Bun gate contract tests unchanged. Output identity and renderer-artifact identity are checked again for every timed pair.

Small-page stages: 10 seconds of warmup followed by 15 seconds each at concurrency 16, 32, 64, and 128, with two drivers. Large-page cases use the same plan and expand initial data to 96 rows for both Node and Bun and both frameworks. Demand: 30 seconds of target-rate warmup and 60 seconds of measurement, with two drivers offering a total of 10,000 RPS. This focused pass contains one population per variant; acceptance needs additional confirmation if the result is small or inconsistent.

Each path is accepted or rejected independently. A gain in another mode cannot erase a regression within a candidate's own selected mode. The unchanged Node streaming path provides a negative control. Prototypes preserve response validation, cancellation-capable schedulers, and output limits. No public chart is replaced by these focused measurements.

## Follow-up raised during the frozen run

The user proposed combining pressure and cooperative scheduling: wait for transport drain when full, otherwise yield after a time budget, and reset the budget after a genuine suspension. The current Node adapter already awaits drain after false writes; the progressive Web Stream waits for available consumer demand, and the renderer's sink readiness propagates that pressure. The present candidates keep those mechanisms unchanged and adjust admission/resumption policy separately. A combined policy is a subsequent experiment, not part of this frozen matrix. A resolved promise or Web Stream demand wait is not necessarily an event-loop turn. Small responses may never fill a transport buffer, so host-wide fairness across requests still needs consideration.
