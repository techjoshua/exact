import pathlib,json,hashlib,zipfile
d=pathlib.Path('.tmp/ssr-large-profile')
rows=json.loads((d/'publication-adoption-results.json').read_text())
assert len(rows)==4
for row in rows:
 assert 'error' not in row and not row['errors']
 result=row['result']
 assert all(result[k] for k in ['elementsRetained','textRetained','scriptRetained','textUnchanged'])
 assert result['values']==['Ready 1','Ready 2'] and result['serverTasksRestarted']==0
 assert result['disposedIndices']==[1,2]
report=pathlib.Path('docs/performance-baselines/publication-adoption-2026-09-09.md')
files=list(d.glob('publication-adoption-*'))
files += [d/f'publication-markers-{variant}-{runtime}.json' for variant in ['control','candidate'] for runtime in ['node','bun']]
files += [pathlib.Path(p) for p in ['native/typescript-go/overlay/internal/exactcompiler/jsx_element_lowering.go','native/typescript-go/overlay/internal/exactcompiler/jsx_sibling_hydration_test.go','packages/hydrate/src/bootstrap.test.ts','packages/hydrate/src/test-support/bootstrap.fixtures.tsx','docs/ssr-hydration.md','apps/docs/src/pages/AdvancedPage.tsx']]
files.append(report)
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
archive=report.with_name(report.stem+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name in manifest:z.write(name,name)
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified four browser cases and',len(manifest),'archive hashes.')
