import {chromium} from '@playwright/test';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/';
const browser=await chromium.launch({headless:true});
const rows=[];
try {
 for(const runtime of ['node','bun'])for(const variant of ['control','candidate']) {
  const recorded=JSON.parse(fs.readFileSync(d+`publication-markers-${variant}-${runtime}.json`,'utf8'));
  const html=recorded.find(row=>row.markers).html;
  const page=await browser.newPage();const errors=[];
  page.on('pageerror',error=>errors.push(error.message));
  try {
   await page.route('http://exact.test/**',route=>route.fulfill({contentType:route.request().url().endsWith('.css')?'text/css':'text/html',body:route.request().url().endsWith('.css')?'':html}));
   await page.goto('http://exact.test/');
   let bundle=fs.readFileSync(d+'publication-adoption-client.js','utf8');
   if(process.env.ADOPTION_DIAGNOSTIC==='1')bundle=bundle.replace('if (isDomRenderLimitError(error))\n        throw error;\n      return false;', 'throw error;');
   if(process.env.ADOPTION_DIAGNOSTIC==='1')bundle=bundle.replace('!isChildRangeOpening(start.data) && !listBoundary) {\n      scope.stop();', '!isChildRangeOpening(start.data) && !listBoundary) {\n      throw new Error("Child range expected " + receipt.markerId + " but found " + start?.nodeName + ":" + start?.textContent);\n      scope.stop();');
   await page.evaluate(bundle);
   let result,error;
   try {result=await page.evaluate(()=>window.runAdoption());}catch(reason){error=reason.message;}
   rows.push({runtime,variant,result,error,errors});
   fs.writeFileSync(d+'publication-adoption-results.json',JSON.stringify(rows,null,2));
   console.log(runtime,variant,JSON.stringify({result,error}));
  } finally {await page.close();}
 }
} finally {await browser.close();}
for(const row of rows){assert.equal(row.error,undefined);assert.deepEqual(row.errors,[]);assert.equal(row.result.elementsRetained,true);assert.equal(row.result.textRetained,true);assert.equal(row.result.scriptRetained,true);assert.equal(row.result.textUnchanged,true);assert.deepEqual(row.result.values,['Ready 1','Ready 2']);assert.equal(row.result.serverTasksRestarted,0);assert.deepEqual(row.result.disposedIndices,[1,2]);}
