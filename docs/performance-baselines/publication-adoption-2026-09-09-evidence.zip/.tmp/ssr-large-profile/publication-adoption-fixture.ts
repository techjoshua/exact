import { createPreparedRenderProgram as __exactPreparedRenderProgram, prepareCompiledRenderProgram as __exactPrepareRenderProgram, createExpression as __exactExpression } from "@exactjs/core/runtime/render-operations";
import { readIndexedReactiveSlot as __exactReadState, writeIndexedReactiveValue as __exactWriteState } from "@exactjs/core/runtime/reactivity";
import { markComponentContinuationTask as __exactContinuationTask, dispatchComponentContinuation as __exactDispatchContinuation, defineTask as __exactDefineTask, activateTaskForHost as __exactActivateTask } from "@exactjs/core/runtime/tasks";
import { applyCompiledProgramText as __exactApplyProgramText } from "@exactjs/dom/runtime/render-program";
import { registerComponentLifecycleHandler as __exactRegisterLifecycle } from "@exactjs/core/framework/component-lifecycle";
import { createCompiledComponentReceipt as __exactComponentReceipt, createCompiledIntrinsicReceipt as __exactIntrinsicReceipt } from "@exactjs/core/runtime/component-operations";
import { type Component } from '@exactjs/core';
import { attachExactCompiledClientComponent as __exactAttachClientComponent_1, receiveExactClientComponentProps as __exactReceiveClientProps_1, disposeExactClientComponent as __exactDisposeClientComponent_1 } from "@exactjs/core/runtime/component-operations";
import { constructRenderComponentInstance as __exactConstructRenderComponent_1 } from "@exactjs/core/runtime/component-construction/render";
import { constructDurableComponentInstance as __exactConstructDurableComponent_1 } from "@exactjs/core/runtime/component-construction/durable";
const __exactComponentContract_1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
const __exact_component_updates_1 = { bindings: [[0, 1, 0], [0, 1, 0]] as const, props: 1, apply: (__exactTargets: object[], __exactDirtyLow: number, __exactDirtyHigh: number) => {
        const __exactTarget0 = __exactTargets[0];
        if (__exactTarget0) {
            if ((__exactDirtyLow & 1) !== 0)
                __exactApplyProgramText(__exactTarget0, 0);
        }
    } };
const __exact_render_program_1 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xyda4TWT669byiGLD-mai3B", namespace: "html", ssrRootStatic: ["", [], []], template: "<strong><!---->\uE000exact:0\uE001<!----></strong>", wire: [["strong", "html", 1, 1], [[3, 0, 0, true]], [[0, 0, undefined, true], [7, 0, __exact_component_updates_1]]], directClaims: true, ssr: (__exactSsr, __exactContext, __exactInvocation) => {
        const __exactValue_0 = __exactSsr.prepareText(__exactInvocation, 0);
        if (__exactValue_0 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 1, 17, 17);
        const __exactOutput = __exactSsr.output();
        let __exactCharacters = 17;
        __exactCharacters = __exactSsr.text(__exactContext, __exactOutput, __exactValue_0, "0", __exactCharacters, true, "<strong>", "</strong>");
        return __exactOutput;
    } });
const __exact_render_program_2 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xREvbf4MdoqzCYQNvHBD-zN", namespace: "html", ssrRootStatic: [" rel=\"stylesheet\"", ["rel"], [[3, "href", "href"]]], template: "<link rel=\"stylesheet\">", wire: [["link", "html", 1, 1], [[7, 0, 0]], [[6, 0, 0]]], directClaims: true, ssr: (__exactSsr, __exactContext, __exactInvocation) => {
        const __exactValue_0 = __exactSsr.prepareAttribute(__exactInvocation, 0);
        if (__exactValue_0 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 1, 23, 23);
        const __exactOutput = __exactSsr.output();
        let __exactCharacters = 23;
        __exactSsr.static(__exactOutput, "<link rel=\"stylesheet\"");
        __exactCharacters = __exactSsr.compiledAttribute(__exactContext, __exactOutput, __exactValue_0, 3, "href", "href", "link", __exactCharacters);
        __exactSsr.static(__exactOutput, ">");
        return __exactOutput;
    } });
export let starts = 0;
export let disposals = 0;
export let disposedIndices: number[] = [];
let release: () => void;
let gate: Promise<void>;
export function reset() { starts = 0; disposals = 0; disposedIndices = []; gate = new Promise<void>(resolve => release = resolve); }
export function settle() { release(); }
const __exactImplementation_ScheduledChild_1 = function ScheduledChild(this: Component<{
    ready: boolean;
}>, props: {
    index: number;
}) {
    __exactWriteState(this.state, 0, false);
    __exactActivateTask(this, __exactDefineTask({
        label: "load",
        placement: "server",
        priority: "normal",
        concurrency: "latest",
        readiness: "blocking"
    }, __exactContinuationTask("x7U2kFAzuTZMP6bz-f8fCru", (...__exactTaskArgs: any[]) => {
        const __exactTaskContext: any = __exactTaskArgs.pop();
        return __exactDispatchContinuation(this as any, "x7U2kFAzuTZMP6bz-f8fCru", __exactTaskArgs, __exactTaskContext.signal, [], __exactTaskContext.generation);
    })));
    __exactRegisterLifecycle(this, "unmount", () => { disposals++; disposedIndices.push(__exactReadState(props, 0) as number); });
    return () => __exactPreparedRenderProgram(__exact_render_program_1, [() => __exactReadState(this.state, 0) as boolean ? 'Ready ' + (__exactReadState(props, 0) as number) : 'Waiting'], this);
};
export const ScheduledChild = /* @__PURE__ */ (() => Object.assign(__exactImplementation_ScheduledChild_1, {
    [Symbol.for("@exactjs/component")]: "x2va5QIiamUg_0vL5O6m3oC",
    [__exactComponentContract_1]: {
        version: 1,
        placement: "isomorphic",
        role: "client",
        implementations: [
            { id: "xkkR9iHTZF0YwZ3F_oThE-7", name: "ScheduledChild", role: "root", implementation: __exactImplementation_ScheduledChild_1 }
        ],
        continuations: [
            {
                kind: "task",
                id: "x7U2kFAzuTZMP6bz-f8fCru",
                componentId: "x2va5QIiamUg_0vL5O6m3oC",
                readiness: "blocking",
                concurrency: "latest",
                dependencies: [],
                stateReads: [],
                stateWrites: [
                    {
                        path: "ready",
                        kind: "write",
                        confidence: "exact"
                    }
                ],
                publicContexts: [],
                serverContexts: [],
                contextWrites: [],
                serverContextWrites: [],
                boundaries: []
            }
        ],
        executors: [],
        boundaries: [],
        artifact: {
            version: 1,
            target: "client",
            id: "x2va5QIiamUg_0vL5O6m3oC",
            instantiate: __exactImplementation_ScheduledChild_1,
            construct: __exactConstructDurableComponent_1,
            abi: 11,
            capabilities: [
                "continuations",
                "resumption"
            ],
            state: [
                "ready"
            ],
            props: [
                "index"
            ],
            attach: __exactAttachClientComponent_1,
            receive: __exactReceiveClientProps_1,
            dispose: __exactDisposeClientComponent_1,
            updates: __exact_component_updates_1,
            tasks: [],
            reactive: [
                {
                    name: "load",
                    provenance: "unknown",
                    allocation: "constant",
                    dependencies: []
                },
                {
                    name: "props",
                    provenance: "props",
                    allocation: "live-slot",
                    dependencies: []
                },
                {
                    name: "this",
                    provenance: "state",
                    allocation: "live-slot",
                    dependencies: []
                }
            ],
            render: "returned-function"
        },
        execution: {
            version: 1,
            ports: [],
            transitions: [],
            reactive: [
                {
                    name: "load",
                    provenance: "unknown",
                    allocation: "constant",
                    dependencies: []
                },
                {
                    name: "props",
                    provenance: "props",
                    allocation: "live-slot",
                    dependencies: []
                },
                {
                    name: "this",
                    provenance: "state",
                    allocation: "live-slot",
                    dependencies: []
                }
            ]
        },
        resumption: {
            componentId: "x2va5QIiamUg_0vL5O6m3oC",
            statePaths: [
                "ready"
            ],
            stateInputs: [],
            valueCaptures: [],
            contexts: [],
            boundaries: []
        }
    }
}) as typeof __exactImplementation_ScheduledChild_1)();
const __exactImplementation_StagedDocument_1 = function StagedDocument(this: object) { return () => __exactIntrinsicReceipt("html", { "data-exact-id": "xDRLUmQOyTZScXAxK5t7N4o" }, __exactIntrinsicReceipt("head", { "data-exact-id": "xJ7OubJrtYZA4m5kvKLxWBI" }, __exactPreparedRenderProgram(__exact_render_program_2, [() => "/app.css"], this, (__exactGroup, __exactApply) => {
    if (__exactGroup === 0) {
        __exactApply("href", "/app.css");
    }
})), __exactIntrinsicReceipt("body", { "data-exact-id": "xLEWf_zC-gv8BLmuzjS4iJe" }, __exactComponentReceipt(ScheduledChild, { index: __exactExpression(() => 1) }), __exactComponentReceipt(ScheduledChild, { index: __exactExpression(() => 2) }))); };
export const StagedDocument = /* @__PURE__ */ (() => Object.assign(__exactImplementation_StagedDocument_1, {
    [Symbol.for("@exactjs/component")]: "xqbcuAeJlheXbzwjrm7Dkfq",
    [__exactComponentContract_1]: {
        version: 1,
        placement: "isomorphic",
        role: "client",
        implementations: [
            { id: "xMr9n2gCvCj_IuU54CDTpmh", name: "StagedDocument", role: "root", implementation: __exactImplementation_StagedDocument_1 }
        ],
        continuations: [],
        executors: [],
        boundaries: [],
        artifact: {
            version: 1,
            target: "client",
            id: "xqbcuAeJlheXbzwjrm7Dkfq",
            instantiate: __exactImplementation_StagedDocument_1,
            construct: __exactConstructRenderComponent_1,
            abi: 1,
            capabilities: [],
            state: [],
            props: [],
            attach: __exactAttachClientComponent_1,
            receive: __exactReceiveClientProps_1,
            dispose: __exactDisposeClientComponent_1,
            tasks: [],
            reactive: [],
            render: "returned-function"
        },
        execution: {
            version: 1,
            ports: [],
            transitions: [],
            reactive: []
        }
    }
}) as typeof __exactImplementation_StagedDocument_1)();

export const adoptionRoot=__exactComponentReceipt(StagedDocument,{});
