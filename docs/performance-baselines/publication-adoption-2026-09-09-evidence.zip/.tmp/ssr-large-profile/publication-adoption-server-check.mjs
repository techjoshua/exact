import fs from 'node:fs';import {spawnSync} from 'node:child_process';import {transform} from 'esbuild';
const d='.tmp/ssr-large-profile/';const original=JSON.parse(fs.readFileSync(d+'compiled-stages-compile.json','utf8'));
const run=spawnSync('.tmp/native-compiler/exactc.exe',[],{input:JSON.stringify(original.request)+'\n',encoding:'utf8',windowsHide:true});
if(run.status!==0)throw Error(run.stderr||run.stdout);
const response=JSON.parse(run.stdout);fs.writeFileSync(d+'publication-adoption-server-check.json',JSON.stringify({sameCode:response.code===original.response.code,response},null,2));
console.log({sameCode:response.code===original.response.code,diagnostics:response.diagnostics});
