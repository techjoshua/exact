import fs from 'node:fs/promises';
const base='.tmp/ssr-large-profile/';
await fs.mkdir(base+'source-scheduler-yield',{recursive:true});
let worker=await fs.readFile(base+'source-scheduler-bun/worker.mjs','utf8');
worker=worker.replace("const sourceScheduler=createNodeRenderScheduler();",`import {scheduler} from 'node:timers/promises';
const immediateScheduler=createNodeRenderScheduler();
let yieldBatch;
function batchYield(){
 if(!yieldBatch){const batch={count:0,promise:undefined};yieldBatch=batch;batch.promise=scheduler.yield().then(()=>{if(yieldBatch===batch)yieldBatch=undefined;});}
 const batch=yieldBatch;if(++batch.count===32)yieldBatch=undefined;return batch.promise;
}
let auditVariant='scheduled';
function sourceScheduler(signal){
 if(auditVariant==='scheduled')return immediateScheduler(signal);
 if(signal)throw Error('Diagnostic yield variants require signal-free benchmark calls');
 return auditVariant==='yield'?scheduler.yield():batchYield();
}`);
const target="auditScheduled=url.searchParams.get('defer')==='1';";
if(!worker.includes(target))throw Error('Missing control');
worker=worker.replace(target,target+"auditVariant=url.searchParams.get('variant')??'scheduled';");
await fs.writeFile(base+'source-scheduler-yield/worker.mjs',worker);
let runner=(await fs.readFile(base+'source-scheduler-bun-run.mjs','utf8')).replaceAll('source-scheduler-bun/','source-scheduler-yield/').replaceAll('actual-source-scheduler-native-bun','bun-scheduler-yield-diagnostic');
runner=runner.replace("['normal','scheduled','normal']","['scheduled','yield','batch-yield','scheduled']");
runner=runner.replaceAll("phase==='scheduled'","phase!=='normal'");
runner=runner.replace("'audit-mode?defer='+(phase!=='normal'?'1':'0')","'audit-mode?defer='+(phase!=='normal'?'1':'0')+'&variant='+phase");
runner=runner.replace('report.blocks.length,16','report.blocks.length,20');
await fs.writeFile(base+'source-scheduler-yield-run.mjs',runner);
