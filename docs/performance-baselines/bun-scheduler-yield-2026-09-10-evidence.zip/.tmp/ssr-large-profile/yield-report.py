import json,hashlib,zipfile
from pathlib import Path
from statistics import mean
base=Path('.tmp/ssr-large-profile'); folder=base/'source-scheduler-yield'
d=json.loads((folder/'capture.json').read_text());assert d['complete'] and len(d['blocks'])==20
rows=[]
for mode in ('string','stream'):
 for pop in (0,1):
  blocks=[b for b in d['blocks'] if b['mode']==mode and b['population']==pop]
  normal=mean(b['rps'] for b in blocks if b['phase']=='scheduled')
  row={'mode':mode,'population':pop+1,'immediateBatch':normal}
  for phase in ('yield','batch-yield','normal'):
   row[phase]=next(b['rps'] for b in blocks if b['phase']==phase)
  rows.append(row)
for b in d['blocks']:
 assert b['after']['scheduleCalls']==(b['valid']+len(b['results']) if b['phase']!='normal' else 0)
 assert all(s['errors']==0 for r in b['results'] for s in r['stages'])
valid=sum(b['valid'] for b in d['blocks'])
(folder/'summary.json').write_text(json.dumps({'rows':rows,'valid':valid},indent=2))
report=Path('docs/performance-baselines/bun-scheduler-yield-2026-09-10.md')
lines=['# Bun scheduler.yield experiment','',
'Hypothesis: batching contributes more than the yield primitive. Compare a per-request scheduler.yield and a shared yield Promise (at most 32 starts) with the existing batched setImmediate scheduler. These are diagnostic variants; the yield variants explicitly reject signal-bearing calls and are not production cancellation implementations. No production source is changed.', '',
'Both modes use native Bun HTTP transport and the same rebuilt participants, complete authored documents and hydration. React is unchanged. Each mode runs fresh eXact/React/React/eXact workers, ten seconds of warmup, five-second blocks at concurrency 32. eXact runs immediate-batch/yield/shared-yield/immediate-batch. The two immediate controls are averaged. Workstation load can vary. Queue time is included in HTTP throughput.', '',
'| Mode | Repeat | Batched immediate RPS | Per-request yield RPS | Shared yield RPS | React RPS |',
'| --- | ---: | ---: | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['mode']} | {r['population']} | {r['immediateBatch']:,.0f} | {r['yield']:,.0f} | {r['batch-yield']:,.0f} | {r['normal']:,.0f} |")
lines+=['',f'{valid:,} measured responses passed full-body identity validation with zero errors. Scheduler invocation counts match measured requests plus driver preflights. Artifact hash guards pass. The archive preserves raw timing distributions and source. This focused experiment does not establish sparse-traffic or browser behavior.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[report,base/'yield-build.mjs',base/'yield-report.py',base/'source-scheduler-yield-run.mjs']
archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print(json.dumps(rows,indent=2));print(valid,'validated responses')
