import {readFileSync,readdirSync,writeFileSync} from 'node:fs';
import {summarizeSsrCapacityCapture} from '../../framework-comparison/src/ssr-capacity-report.mjs';
const root=import.meta.dirname,result=[];
for(const name of readdirSync(root).filter(n=>/^(body-(normal|preloaded)-|node-affinity-).*\.json$/.test(n))){const d=JSON.parse(readFileSync(root+'/'+name));if(!d.complete)continue;const rows=summarizeSsrCapacityCapture(d).filter(r=>r.concurrency===32);const exact=rows.find(r=>r.name==='eXact').rps,react=rows.find(r=>r.name==='React').rps;result.push({name,exact,react,ratio:exact/react,errors:d.blocks.reduce((n,b)=>n+b.results.reduce((n,d)=>n+d.stages.reduce((n,s)=>n+s.errors,0),0),0)});}
writeFileSync(root+'/experiment-summary.json',JSON.stringify(result,null,2)+'\n');console.log(result);
