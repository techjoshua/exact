import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync} from 'node:fs';
const root=import.meta.dirname,journal=[];
for(const [i,pin] of ['0','1','0'].entries()){
 const name=`node-affinity-${i}-${pin}`,fd=openSync(`${root}/${name}.log`,'w'),step={name,startedAt:new Date().toISOString()};journal.push(step);
 try{await new Promise((ok,fail)=>{const child=spawn(process.execPath,[root+'/affinity-runner.mjs',root+'/node-plan.json',root+`/${name}.json`,'node'],{stdio:['ignore',fd,fd],env:{...process.env,NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:'stream',PROBE_PIN:pin}});step.pid=child.pid;child.on('error',fail);child.on('exit',code=>{step.code=code;code===0?ok():fail(Error(name+' '+code))})});}finally{closeSync(fd);step.endedAt=new Date().toISOString();writeFileSync(root+'/affinity-execution.json',JSON.stringify(journal,null,2));}console.log('DONE '+name);
}
