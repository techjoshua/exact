import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync} from 'node:fs';
const root=import.meta.dirname,journal=[];
for(const lane of ['normal','preloaded'])for(const variant of ['current','before']){
 const name=`body-${lane}-${variant}`,fd=openSync(`${root}/${name}.log`,'w');const step={name,startedAt:new Date().toISOString()};journal.push(step);
 try{await new Promise((ok,fail)=>{const child=spawn(process.execPath,[root+'/capacity-runner.mjs',root+`/${lane}-plan.json`,root+`/${name}.json`,'bun'],{stdio:['ignore',fd,fd],env:{...process.env,NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:'stream',PROBE_ENTRY:root+`/bun-${variant}.js`}});step.pid=child.pid;child.on('error',fail);child.on('exit',code=>{step.code=code;code===0?ok():fail(Error(name+' '+code))})});}finally{closeSync(fd);step.endedAt=new Date().toISOString();writeFileSync(root+'/body-execution.json',JSON.stringify(journal,null,2));}console.log('DONE '+name);
}
