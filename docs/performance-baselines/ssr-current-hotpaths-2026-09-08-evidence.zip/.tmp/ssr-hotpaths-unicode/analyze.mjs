import {readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const root='.tmp/ssr-hotpaths-unicode/';
const capture=JSON.parse(await readFile(root+'capture.json','utf8'));
if(!capture.complete)throw new Error('Capture incomplete');
const bundles=new Map();
for(const id of ['exact','react']){
 const artifact=capture.artifacts[id];const lines=(await readFile(root+id+'-before.js','utf8')).split('\n');
 let region='';const regions=lines.map(line=>{if(line.startsWith('//#region '))region=line.slice(10);if(line.startsWith('//#endregion'))region='';return region;});
 bundles.set(artifact.path.toLowerCase(),regions);
}
function site(node){const f=node.callFrame;let module=f.url;
 if(f.url.startsWith('file:')){const path=fileURLToPath(f.url);const regions=bundles.get(path.toLowerCase());if(regions)module=regions[f.lineNumber]||path;}
 return {name:f.functionName||'(anonymous)',url:f.url,line:f.lineNumber+1,column:f.columnNumber+1,module};
}
function category(chain){
 const names=chain.map(s=>s.name),mods=chain.map(s=>s.module);
 const leaf=chain[0];
 if(leaf.name==='(idle)')return 'Idle';
 if(leaf.name==='(garbage collector)')return 'Garbage collection';
 if(names.includes('cpuUsage')||/ssr-load-statistics/.test(leaf.module)||leaf.name==='measureNodeRequest')return 'Benchmark telemetry';
 if(names.some(n=>/writeUtf8String|writev|writeBuffer|onWriteComplete|socketOnDrain/.test(n)) || mods.some(m=>/node:(?:_http_outgoing|net|internal\/stream_base_commons|internal\/streams\/writable)/.test(m)))return 'HTTP output and socket';
 if(mods.some(m=>/hydration-json|positional-projection/.test(m)))return 'Hydration validation and projection';
 if(names.includes('serializeJson'))return 'Hydration JSON serialization';
 if(names.includes('renderHydrationScriptValue')||mods.some(m=>/hydration-metadata/.test(m)))return 'Other hydration publication';
 if(names.includes('comparisonDocumentHtml')||names.includes('documentHtml'))return 'Document envelope and state';
 if(names.some(n=>/^(charge|escapeSsrText|renderAccountedAttribute|accountKnown|accountClosedBytes)$/.test(n)))return 'HTML escaping and byte accounting';
 if(names.includes('renderParticipantToSink')||names.includes('renderParticipant')||mods.some(m=>/react-dom-server|packages\/ssr\/dist\/render/.test(m)))return 'Other rendering and components';
 if(leaf.name==='cpuUsage'||/ssr-load-statistics/.test(leaf.module)||leaf.name==='measureNodeRequest')return 'Benchmark telemetry';
 if(mods.some(m=>/packages\/server\/dist\/response-body|node-adapter\/dist/.test(m)))return 'Response ownership and adapter';
 if(mods.some(m=>/node:_http_(?:server|common|incoming)/.test(m)))return 'HTTP input and dispatch';
 if(names.some(n=>/handleNodeControlRequest|profile-start|profile-stop/.test(n)))return 'Profile control';
 return 'Other runtime and harness';
}
const result={blocks:[],aggregate:{}};
for(const block of capture.blocks){
 const profile=JSON.parse(await readFile(root+block.profile,'utf8'));
 const nodes=new Map(profile.nodes.map(n=>[n.id,n])),parents=new Map();for(const n of profile.nodes)for(const child of n.children??[])parents.set(child,n.id);
 const chains=new Map();
 for(const n of profile.nodes){const chain=[];let id=n.id;while(id!==undefined){chain.push(site(nodes.get(id)));id=parents.get(id);}chains.set(n.id,chain);}
 const self=new Map(),inclusive=new Map(),groups={};
 const add=(map,s,us)=>{const key=s.url+':'+s.line+':'+s.column+':'+s.name;const entry=map.get(key)??{...s,sampledUs:0};entry.sampledUs+=us;map.set(key,entry);};
 for(let i=0;i<profile.samples.length;i++){
  const chain=chains.get(profile.samples[i]),us=profile.timeDeltas[i]??0;
  const group=category(chain);groups[group]=(groups[group]??0)+us;
  add(self,chain[0],us);
  const seen=new Set();for(const s of chain){const key=s.url+':'+s.line+':'+s.column;if(seen.has(key))continue;seen.add(key);add(inclusive,s,us);}
 }
 const rank=map=>[...map.values()].sort((a,b)=>b.sampledUs-a.sampledUs).map(s=>({...s,usPerRequest:s.sampledUs/block.valid}));
 const entry={id:block.id,population:block.population,valid:block.valid,cpuUsPerRequest:block.cpuUs/block.valid,bytes:block.identity.bytes,groups:Object.fromEntries(Object.entries(groups).map(([k,v])=>[k,v/block.valid])),self:rank(self).slice(0,50),inclusive:rank(inclusive).slice(0,80)};
 result.blocks.push(entry);
 console.log(block.id,block.population+1,'CPU',entry.cpuUsPerRequest.toFixed(2));console.log(JSON.stringify(entry.groups));console.log(entry.self.slice(0,12).map(s=>`${s.name} ${s.usPerRequest.toFixed(2)} (${s.module}:${s.line})`).join('\n'));
}
for(const id of ['exact','react']){
 const blocks=result.blocks.filter(b=>b.id===id);const valid=blocks.reduce((s,b)=>s+b.valid,0);
 const groups={};for(const b of blocks)for(const [k,v]of Object.entries(b.groups))groups[k]=(groups[k]??0)+v*b.valid/valid;
 result.aggregate[id]={valid,cpuUsPerRequest:blocks.reduce((s,b)=>s+b.cpuUsPerRequest*b.valid,0)/valid,groups};
}
await writeFile(root+'analysis.json',JSON.stringify(result,null,2));
