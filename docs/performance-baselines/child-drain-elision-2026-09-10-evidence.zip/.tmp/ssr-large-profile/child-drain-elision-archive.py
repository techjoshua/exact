import json,hashlib,zipfile
from pathlib import Path
root=Path('.tmp/ssr-large-profile')
rows=json.loads((root/'child-drain-elision-results.json').read_text())
assert len(rows)==48
files=set()
for p in root.glob('child-drain-elision*'):
    if p.is_file():files.add(p)
    else:files.update(f for f in p.rglob('*') if f.is_file())
for row in rows:
    path=Path(row['entry'])
    assert hashlib.sha256(path.read_bytes()).hexdigest()==row['artifactSha256']
    files.add(path)
files.add(root/'conditional-emission/bun-server-entry.js')
files.add(root/'final-rope-worker.mjs')
files.add(Path('.tmp/positional-leaves/data.json'))
files.add(Path('docs/performance-baselines/child-drain-elision-2026-09-10.md'))
archive=Path('docs/performance-baselines/child-drain-elision-2026-09-10-evidence.zip')
assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files):z.write(p,p.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified',len(files),'files and 48 measurement artifact hashes')

