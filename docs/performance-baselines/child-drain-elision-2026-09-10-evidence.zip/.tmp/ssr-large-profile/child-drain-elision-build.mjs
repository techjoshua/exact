import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'child-drain-elision',{recursive:true});const counts=[];
for(const file of ['server-entry.js','bun-server-entry.js']){
 const source=await fs.readFile(root+'conditional-emission/'+file,'utf8');
 const ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);const edits=[];
 const drained=new Set(['child','keyedChild','component','directComponent']);
 function visit(node){
  if(ts.isSwitchStatement(node)&&node.expression.getText(ast)==='__exactStage'){
   const clauses=node.caseBlock.clauses;
   for(let i=1;i<clauses.length;i++){
    const invocation=clauses[i-1].statements[0];
    if(!invocation||!ts.isExpressionStatement(invocation)||!ts.isBinaryExpression(invocation.expression))continue;
    const call=invocation.expression.right;
    if(!ts.isCallExpression(call)||!ts.isPropertyAccessExpression(call.expression)||call.expression.expression.getText(ast)!=='__exactSsr'||!drained.has(call.expression.name.text))continue;
    for(const statement of clauses[i].statements){
     if(!ts.isVariableStatement(statement))continue;
     for(const declaration of statement.declarationList.declarations){
      const init=declaration.initializer;
      if(init?.getText(ast)==='__exactOutput.sink.ready()')edits.push({start:init.getStart(ast),end:init.end,method:call.expression.name.text});
     }
    }
   }
  }
  ts.forEachChild(node,visit);
 }
 visit(ast);if(!edits.length)throw Error('No redundant checks');let output=source;
 for(const edit of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,edit.start)+'(void 0)'+output.slice(edit.end);
 await fs.writeFile(root+'child-drain-elision/'+file,output);counts.push({file,sites:edits.length,methods:edits.map(e=>e.method)});
}
await fs.writeFile(root+'child-drain-elision/sites.json',JSON.stringify(counts,null,2));console.log(counts);
for(const suffix of ['check.mjs','run.mjs']){
 const source=await fs.readFile(root+'writer-output-pool-'+suffix,'utf8');
 await fs.writeFile(root+'child-drain-elision-'+suffix,source.replaceAll('writer-output-pool','child-drain-elision'));
}
