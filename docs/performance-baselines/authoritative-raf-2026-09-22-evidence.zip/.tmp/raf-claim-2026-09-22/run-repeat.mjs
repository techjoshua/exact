import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {chromium} from 'playwright';
import {startClientBenchmarkHarness} from '../../framework-comparison/src/client-benchmark-harness.mjs';
import {waitForFirstContentfulPaint} from '../../framework-comparison/src/paint-timing.mjs';
import {assertComparisonNetwork} from '../../framework-comparison/src/network-environment.mjs';
const EARLY_SCRIPT="(()=>{\n     const originalFetch=globalThis.fetch;let pending;\n     const url='http://127.0.0.1:4310/api/incidents/inc-100/claim';\n     const body=JSON.stringify({actorId:'user-alex',expectedVersion:1});\n     document.addEventListener('click',event=>{\n      const button=event.target instanceof Element?event.target.closest('button'):null;\n      if(button?.textContent?.trim()!=='Claim incident'||pending)return;\n      pending=originalFetch(url,{method:'POST',headers:{'content-type':'application/json'},body});\n      pending.catch(()=>{});\n     },true);\n     globalThis.fetch=(input,init)=>{\n      if(input===url&&pending){\n       if(init?.body!==body)throw new Error('Early request does not match authored request');\n       globalThis.__earlyDispatchUsed=true;return pending;\n      }\n      return originalFetch(input,init);\n     };\n    })();";
new Function(EARLY_SCRIPT);
const network=assertComparisonNetwork();
const source=await readFile('framework-comparison/src/measure.mjs','utf8');
const timing=source.slice(source.indexOf('function installInteractionTiming()'),source.indexOf('\nasync function measureControlledService()'));
const participants=[{id:'exact-controlled',directory:'exact',artifact:'dist',url:'http://127.0.0.1:4401'},{id:'react-controlled',directory:'react',artifact:'dist',url:'http://127.0.0.1:4402'}];
const cases=participants.flatMap(p=>['raf-trusted','raf-synthetic'].flatMap(alignment=>['baseline','early'].map(variant=>({...p,variant,alignment}))));
const harness=await startClientBenchmarkHarness(participants);let browser;const samples=[];
try{
 browser=await chromium.launch();
 for(let round=0;round<40;round++){
  for(const participant of [...cases.slice(round%cases.length),...cases.slice(0,round%cases.length)]){
   await fetch('http://127.0.0.1:4310/__benchmark/reset',{method:'POST',headers:{'content-type':'application/json','x-benchmark-control':'fixture-reset'},body:'{}'});
   const context=await browser.newContext();
   try{
    const page=await context.newPage();const errors=[],requests=[],responses=[];
    page.on('pageerror',e=>errors.push(e.message));
    await page.addInitScript({content:`(${timing})(); ${participant.variant==='early'?EARLY_SCRIPT:''}
    document.addEventListener('click',event=>{
     if(event.target?.closest('button')?.textContent?.trim()!=='Claim incident')return;
     const t=globalThis.__frameworkComparisonTiming;t.trusted=event.isTrusted;
     t.rafToClickMs=globalThis.__rafCallbackAt===undefined?null:t.startedAt-globalThis.__rafCallbackAt;
     requestAnimationFrame(()=>{t.phasesMs['next-frame']=performance.now()-t.startedAt;});
    },true);`});

    const cdp=await context.newCDPSession(page);await cdp.send('Network.enable');await cdp.send('Network.setCacheDisabled',{cacheDisabled:true});
    if(process.env.TRACE_NETWORK!=='0') cdp.on('Network.requestWillBeSent',e=>{if(e.request.url.endsWith('/claim'))requests.push({requestId:e.requestId,method:e.request.method,timestamp:e.timestamp,type:e.type,initiator:e.initiator.type});});
    if(process.env.TRACE_NETWORK!=='0') cdp.on('Network.responseReceived',e=>{if(e.response.url.endsWith('/claim'))responses.push({requestId:e.requestId,type:e.type,timestamp:e.timestamp,status:e.response.status,timing:e.response.timing,connectionReused:e.response.connectionReused,protocol:e.response.protocol});});
    await page.goto(participant.url+'/incidents/inc-100',{waitUntil:'domcontentloaded'});
    await page.getByRole('heading',{name:'Checkout authorization failures'}).waitFor();
    await page.evaluate(waitForFirstContentfulPaint);await page.waitForLoadState('load');
    await page.locator('.connection').getByText('Live service',{exact:true}).waitFor();
    const button=page.getByRole('button',{name:'Claim incident'});
    if(participant.alignment==='locator')await button.click();
    else if(participant.alignment==='raf-trusted'){
     await button.scrollIntoViewIfNeeded();const box=await button.boundingBox();assert.ok(box);
     await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>{globalThis.__rafCallbackAt=performance.now();resolve();})));
     await page.mouse.click(box.x+box.width/2,box.y+box.height/2);
    }else{
     await button.scrollIntoViewIfNeeded();
     await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>{globalThis.__rafCallbackAt=performance.now();const button=[...document.querySelectorAll('button')].find(b=>b.textContent.trim()==='Claim incident');button.click();resolve();})));
    }
    await page.getByText('Version 2',{exact:true}).waitFor();await page.getByText('Alex Chen',{exact:true}).waitFor();
    await page.waitForFunction(()=>globalThis.__frameworkComparisonTiming.phasesMs['http-json-decoded']!==undefined);
    assert.deepEqual(errors,[]);
    assert.equal(await page.evaluate(()=>globalThis.__frameworkComparisonTiming.trusted),participant.alignment!=='raf-synthetic');
    if(participant.variant==='early') assert.equal(await page.evaluate(()=>globalThis.__earlyDispatchUsed),true);
    samples.push({round,id:participant.id,variant:participant.variant,alignment:participant.alignment,timing:await page.evaluate(()=>globalThis.__frameworkComparisonTiming),requests,responses});
   }finally{await context.close();}
  }
  console.log('Round',round+1,'/40');
 }
 await writeFile('.tmp/raf-claim-2026-09-22/results-repeat.json',JSON.stringify({diagnostic:'Request is prestarted from a fixture-specific click capture; application fetch reuses exactly that request. Not production code.',network,harness:harness.evidence(),samples},null,2));
}finally{try{await browser?.close();}finally{await harness.close();}}
