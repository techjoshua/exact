import json,statistics as st,random
from pathlib import Path
root=Path('.tmp/raf-claim-2026-09-22');d=json.loads((root/'results.json').read_text());a=d['samples'];assert len(a)==360
rows=[]
for fw in ['exact-controlled','react-controlled']:
 for alignment in ['locator','raf-trusted','raf-synthetic']:
  paired={}
  for variant in ['baseline','early']:
   samples=[s for s in a if s['id']==fw and s['alignment']==alignment and s['variant']==variant];assert len(samples)==30
   assert all(s['timing']['trusted']==(alignment!='raf-synthetic') for s in samples)
   assert all(s['timing']['settlementMs'] is not None and 'http-json-decoded' in s['timing']['phasesMs'] for s in samples)
   phases=['request-dispatched','optimistic-dom-visible','sse-incident-received','authoritative-dom-visible']
   row={'framework':fw,'alignment':alignment,'variant':variant,'samples':len(samples),'means':{p:st.mean(s['timing']['phasesMs'][p] for s in samples) for p in phases}}
   v=sorted(s['timing']['settlementMs'] for s in samples);row['settlementP50']=st.median(v);row['settlementMax']=max(v)
   if alignment!='locator':row['rafToObservationMeanMs']=st.mean(s['timing']['rafToClickMs'] for s in samples)
   rows.append(row);paired[variant]={s['round']:s['timing']['settlementMs'] for s in samples}
   print(fw,alignment,variant,{k:round(v,3) for k,v in row['means'].items()},'p50',round(row['settlementP50'],3),'max',round(row['settlementMax'],3),'raf',round(row.get('rafToObservationMeanMs',0),3))
  differences=[paired['early'][r]-paired['baseline'][r] for r in range(30)];rng=random.Random(123)
  means=sorted(st.mean(rng.choices(differences,k=30)) for _ in range(5000));print('Early minus baseline:',round(st.mean(differences),3),'paired bootstrap95',round(means[125],3),round(means[4874],3))
(root/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
