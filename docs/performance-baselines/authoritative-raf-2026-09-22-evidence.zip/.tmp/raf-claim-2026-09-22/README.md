# Frame-aligned claim diagnostics

Run the probes from the repository root with the existing comparison production artifacts, verified native loopback, and the WSL browser library environment. For example:

    unshare --user --map-root-user --net --pid --fork --mount-proc --kill-child=SIGKILL bash -c 'ip link set lo up && source .tmp/wsl-benchmark-env.sh && TRACE_NETWORK=0 exec node .tmp/raf-claim-2026-09-22/run-repeat.mjs'

run.mjs compares ordinary locator clicks, trusted mouse input delivered after a requestAnimationFrame callback through Playwright, and HTMLElement.click() executed directly inside requestAnimationFrame. It crosses these with original ordering and fixture-specific capture-phase request prestart for eXact and React, 30 samples per case, 360 total. Cases rotate by round. Normal Chromium settings and shared replay/service behavior remain intact.

run-repeat.mjs repeats the two aligned modes with 40 samples per case, 320 total. Its frame offset is captured click-start minus the frame callback timestamp. The initial run instead records frame callback to a later capture listener, so its offset includes early-fetch initiation overhead and must not be used as the precise click phase.

The early-request diagnostic starts the known fixture claim from a click capture listener, preserves the authored optimistic update, and verifies that the application fetch reuses the identical request body. It precedes authored validation and snapshot work, so it is an upper-bound diagnostic rather than the proposed production ordering. It does not establish failure/cancellation correctness for a request-first implementation.

Each completed sample checks Version 2, owner Alex Chen, HTTP JSON completion, absence of page errors, early-request reuse when applicable, and event.isTrusted matching the intended input mode. A frame callback scheduled by the click listener observes the next frame if it occurs before sample teardown. That callback is additional diagnostic work, applied to every case.

Direct rAF clicks are synthetic. Trusted input requires a driver round trip and is not guaranteed to land within the rAF callback. Neither configuration replaces ordinary user-input benchmark results. The first attempted invocation had a malformed generated init-script wrapper and produced no accepted capture; the corrected runners parse-check the early-request init script before launching the harness.
