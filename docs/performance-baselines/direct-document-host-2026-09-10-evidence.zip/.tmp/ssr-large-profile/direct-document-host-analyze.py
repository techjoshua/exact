import json, statistics
from pathlib import Path
base=Path('.tmp/ssr-large-profile/direct-document-host')
rows=json.loads((base/'screen.json').read_text())
assert len(rows)==72
result=[]
for runtime in ('node','bun'):
 for mode in ('encoded','stream'):
  selected=[r for r in rows if r['runtimeName']==runtime and r['mode']==mode]
  assert len({r['hash'] for r in selected if r['variant']!='gated'})==1
  stats={v:{k:statistics.median(r[k] for r in selected if r['variant']==v) for k in ('usPerRender','cpuMicrosPerRender')} for v in ('baseline','initial','gated')}
  wins=sum(next(r['usPerRender'] for r in selected if r['round']==i and r['variant']=='initial')<next(r['usPerRender'] for r in selected if r['round']==i and r['variant']=='baseline') for i in range(6))
  result.append(dict(runtime=runtime,mode=mode,stats=stats,wins=wins))
(base/'summary.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
