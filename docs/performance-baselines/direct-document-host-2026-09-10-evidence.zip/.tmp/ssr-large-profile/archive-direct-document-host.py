from pathlib import Path
import json,hashlib,zipfile
root=Path.cwd();base=root/'.tmp/ssr-large-profile';folder=base/'direct-document-host'
summary=json.loads((folder/'summary.json').read_text())
table='\n'.join(f"| {r['runtime'].title()} {r['mode']} | {r['stats']['baseline']['usPerRender']:.2f} | {r['stats']['initial']['usPerRender']:.2f} | {r['stats']['gated']['usPerRender']:.2f} | {r['wins']}/6 |" for r in summary)
report=root/'docs/performance-baselines/direct-document-host-2026-09-10.md'
report.write_text("""# Direct document-host execution experiment, September 10, 2026

The candidate avoids allocating the nested document-host continuation callbacks when destination
readiness, rendering, and head flushing all finish synchronously. Actual pending work transfers
host cleanup to the existing async cleanup helper. It uses the same descendant renderer and sink.
The hypothesis was a small shell-overhead reduction, without changing output or early head delivery.

## Renderer-focused measurements

Medians in microseconds per complete document, lower is better. These are not HTTP requests/s.

| Runtime/output | Prior eXact | Candidate eXact | React | Candidate faster blocks |
| --- | ---: | ---: | ---: | ---: |
"""+table+"""

All six three-variant orders ran in each of four cells, 72 fresh workers. Each worker performs
50,000 warmup renders and 20,000 measured renders. Node string output is consumed through a Response;
Node streams are fully consumed. Bun uses each framework's native exported response adapter and
consumes the response for both modes. Compare variants within a cell, not absolute Node/Bun times.
Runs use production mode and below-normal priority. The PC remains available for user workloads.
CPU time and elapsed time are both retained in the raw records. No builds, tests, or profilers run
concurrently. All eXact final outputs are byte-identical within each cell.

The initial diagnostic completed Node then failed on Bun because it expected Node-style exports.
The corrected Bun worker uses renderParticipantBunResponse. Completed Node records were preserved;
only missing cells were run. The original script and failure log are retained.

The candidate passed all 370 SSR tests, including synchronous/asynchronous ready, writer, and flush
failures, balanced host ancestry, pending-task early head delivery, cancellation and cleanup.

The candidate was rejected: elapsed-time medians were worse in all four cells, with no consistent
CPU improvement. The extra lifecycle branching was reverted. Both restored server bundles were
verified byte-identical to the pre-experiment shared-head-string build. Decision and hashes are
recorded in decision.json in the evidence archive.
Head registration remains a separate follow-up described in
[the head-registration audit](head-registration-audit-2026-09-10.md).

[Raw evidence](direct-document-host-2026-09-10-evidence.zip) includes both compiled eXact variants,
source before and candidate, measurement workers, scripts, results, and validation logs.
""",encoding='utf-8')
files={report,root/'docs/performance-baselines/head-registration-audit-2026-09-10.md',Path(__file__).resolve(),base/'flat-invocation-large-worker.mjs'}
files.update(p for p in folder.rglob('*') if p.is_file())
files.update(p for p in base.glob('direct-document-host-*') if p.is_file())
for name in ('server-entry.js','bun-server-entry.js'): files.add(base/'shared-head-string'/name)
for sub in ('dist-server/server-entry.js','dist-bun-server/bun-server-entry.js'):files.add(root/'framework-comparison/participants/react'/sub)
archive=report.with_name('direct-document-host-2026-09-10-evidence.zip');assert not archive.exists()
manifest={str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files):z.write(p,str(p.relative_to(root)).replace('\\','/'))
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print(f'Archived and verified {len(files)} files')
