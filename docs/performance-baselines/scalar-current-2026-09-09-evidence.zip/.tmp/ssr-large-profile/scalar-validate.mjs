import {spawnSync} from 'node:child_process';
import {writeFileSync,copyFileSync} from 'node:fs';
const commands=[
 ['build-core','npm.cmd run build -w @exactjs/core'],
 ['compile-core','node scripts/compile-exact-package.mjs packages/core'],
 ['build-ssr','npm.cmd run build -w @exactjs/ssr'],
 ['compile-ssr','node scripts/compile-exact-package.mjs packages/ssr'],
 ['test-core','npm.cmd run test -w @exactjs/core'],
 ['test-ssr','npm.cmd run test -w @exactjs/ssr'],
 ['typecheck','npm.cmd run typecheck:tests'],
 ['comparison','npm.cmd run build:exact -w @exactjs/framework-comparison-suite'],
];
for(const [name,command] of commands){
 const r=spawnSync(command,{shell:true,encoding:'utf8',windowsHide:true,env:process.env});
 writeFileSync(`.tmp/ssr-large-profile/scalar-${name}.log`,r.stdout+'\n'+r.stderr);
 console.log(name,r.status);if(r.status!==0)process.exit(r.status??1);
}
copyFileSync('framework-comparison/participants/exact/dist-server/server-entry.js','.tmp/ssr-large-profile/scalar-current.mjs');
