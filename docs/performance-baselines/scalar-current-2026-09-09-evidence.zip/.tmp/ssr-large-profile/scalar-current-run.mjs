import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const rows=[];const variants=['class-current','scalar-current','react'];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const scenario of ['small','large'])for(let round=0;round<(scenario==='large'?3:2);round++)for(const variant of [...variants.slice(round),...variants.slice(0,round)]){
 const entry=variant==='react'?'framework-comparison/participants/react/dist-server/server-entry.js':`.tmp/ssr-large-profile/${variant}.mjs`;
 const result=spawnSync(runtime,['.tmp/ssr-large-profile/long-worker.mjs',entry,mode,scenario,'12000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(result.status!==0)throw Error(result.stderr||result.stdout);
 const row={variant,round,runtimeId:runtime,artifactSha256:createHash('sha256').update(readFileSync(entry)).digest('hex'),...JSON.parse(result.stdout)};
 const peer=rows.find(x=>x.runtimeId===runtime&&x.mode===mode&&x.scenario===scenario&&x.variant!=='react');
 if(variant!=='react'&&peer&&peer.hash!==row.hash)throw Error('Full response changed');
 rows.push(row);writeFileSync('.tmp/ssr-large-profile/scalar-current-results.json',JSON.stringify(rows,null,2));
 console.log(runtime,mode,scenario,round,variant,row.usPerRender.toFixed(2));
}
