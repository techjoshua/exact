import {readFile,writeFile} from 'node:fs/promises';
const dir='.tmp/ssr-hydration-fusion/';
const source=await readFile(dir+'fused-shared.mjs','utf8');
const helpers=await readFile(dir+'compiled.js','utf8');
await writeFile(dir+'fused-compiled.mjs', source.replace('fusionProject(state, root.props, root.schema, 2)', 'fusionCompiledProject(state, root.props, root.schema, 2)')+'\n'+helpers);
