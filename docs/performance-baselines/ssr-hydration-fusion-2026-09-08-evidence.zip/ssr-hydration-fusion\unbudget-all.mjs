import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const dir='.tmp/ssr-hydration-fusion/';
const source=await readFile(dir+'unbudgeted.mjs','utf8');
const pattern='if (++state.nodes > state.maxNodes || depth > state.maxDepth) return state.unsafe;';
assert.equal(source.split(pattern).length-1,5);
await writeFile(dir+'unbudgeted-all.mjs',source.replaceAll(pattern,''));
