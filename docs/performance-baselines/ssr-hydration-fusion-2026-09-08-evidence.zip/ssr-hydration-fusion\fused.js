// Experimental direct-envelope encoder. Not a production implementation: generic values
// use the existing validator/JSON writer, and generated positional projectors are bypassed.
function experimentalHydration(compacted, options, resumptions) {
  const root = readPositionalRootPublication(options.state);
  const state = {nodes: 0, maxNodes: normalizeProtocolLimit(options.maxHydrationNodes, 100000), maxDepth: normalizeProtocolLimit(options.maxHydrationDepth, 100), active: []};
  function charge(depth, count = 1) {
    state.nodes += count;
    if (state.nodes > state.maxNodes || depth > state.maxDepth) throw new Error('experiment limit');
  }
  function primitive(value) {
    if (value === null) return 'null';
    switch (typeof value) {
      case 'string': return JSON.stringify(value);
      case 'boolean': return value ? 'true' : 'false';
      case 'number': if (Number.isFinite(value)) return String(value); break;
    }
    throw new Error('experiment unsupported value');
  }
  function enter(value) {
    if (state.active.includes(value)) throw new Error('experiment cycle');
    state.active.push(value);
  }
  function generic(value, depth, shape = 0) {
    charge(depth);
    if (value === null || typeof value !== 'object') return primitive(value);
    enter(value);
    try {
      if (!shape) {
        // Preserve existing generic validation, including collection encoding. Its full
        // budget is checked independently in this feasibility probe, not claimed equivalent.
        if (validateJsonSafeHydrationValue(value, {})) throw new Error('experiment generic value');
        return serializeHydrationPayload(value);
      }
      let output = '[';
      for (let index = 0; index < value.length; index++) {
        const next = shape === 2 ? 3 : shape === 4 ? 5 : shape === 3 && (index === 1 || index === 2) ? 4 : shape === 3 && index === 3 ? 6 : 0;
        if (index) output += ',';
        output += generic(value[index], depth + 1, next);
      }
      return output + ']';
    } finally { state.active.pop(); }
  }
  function project(value, schema, depth) {
    if (schema === 0) return generic(value, depth);
    charge(depth);
    if (!value || typeof value !== 'object') throw new Error('experiment shape mismatch');
    enter(value);
    try {
      let output = '[';
      if (schema[0] === 2) {
        if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype || Object.keys(value).length !== value.length) throw new Error('experiment array mismatch');
        for (let index = 0; index < value.length; index++) {
          if (!Object.hasOwn(value, index)) throw new Error('experiment ownership');
          if (index) output += ',';
          output += project(value[index], schema[1], depth + 1);
        }
      } else {
        if (Array.isArray(value) || Object.getPrototypeOf(value) !== Object.prototype || Object.keys(value).length !== (schema.length - 1) / 2) throw new Error('experiment record mismatch');
        for (let index = 1; index < schema.length; index += 2) {
          if (!Object.hasOwn(value, schema[index])) throw new Error('experiment ownership');
          if (index > 1) output += ',';
          output += project(value[schema[index]], schema[index + 1], depth + 1);
        }
      }
      return output + ']';
    } finally { state.active.pop(); }
  }
  charge(0); charge(1, 2);
  let output = '[1,' + compacted[1];
  let remaining = compacted[1] & ~16;
  let index = 2;
  while (remaining) {
    const bit = remaining & -remaining;
    remaining &= remaining - 1;
    output += ',';
    if (bit === 8 && root) {
      charge(1, 2);
      output += '[' + JSON.stringify(root.componentId) + ',' + project(root.props, root.schema, 2) + ']';
    } else output += generic(compacted[index], 1, bit === 64 && compacted[index] === resumptions ? 2 : 0);
    index++;
  }
  return (output + ']').replace(/</g, '\\u003C').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
}
