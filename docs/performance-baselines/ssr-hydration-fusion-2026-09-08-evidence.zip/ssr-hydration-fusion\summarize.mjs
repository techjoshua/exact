import {readFile,writeFile,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import os from 'node:os';
const dir='.tmp/ssr-hydration-fusion/';
const files=(await readdir(dir)).filter(name=>/^(node-\d|bun-\d|isolated-(node|bun))\.json$/.test(name));
const runs={};
for(const file of files){
  const capture=JSON.parse(await readFile(dir+file,'utf8'));
  const groups=new Map();
  for(const sample of capture.samples){const key=sample.size+':'+sample.name;const group=groups.get(key)??[];group.push(sample.microseconds);groups.set(key,group);}
  runs[file]=[...groups].map(([key,values])=>({size:Number(key.split(':')[0]),variant:key.split(':')[1],samples:values.length,meanMicroseconds:values.reduce((a,b)=>a+b,0)/values.length}));
}
const evidence={};
for(const name of await readdir(dir)){const content=await readFile(dir+name);evidence[name]={bytes:content.length,sha256:createHash('sha256').update(content).digest('hex')};}
const summary={date:'2026-09-08',environment:{node:process.version,bun:'1.4.2',os:os.type(),release:os.release(),arch:os.arch(),cpu:os.cpus()[0].model},runs,behavior:JSON.parse(await readFile(dir+'behavior.json','utf8')),evidence,decision:'No production changes. Fused serialization loses, options-copy removal is inconsistent, and removing projection budgets does not establish a Node render improvement. No HTTP capacity claim.'};
await writeFile('docs/performance-baselines/ssr-hydration-fusion-2026-09-08.json',JSON.stringify(summary,null,2)+'\n');
console.log(Object.keys(runs).length,'captures summarized');
