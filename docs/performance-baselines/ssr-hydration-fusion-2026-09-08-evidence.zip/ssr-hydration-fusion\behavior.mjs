import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
const names=['baseline','unbudgeted','fused-shared','fused-compiled'];
const entries=Object.fromEntries(await Promise.all(names.map(async name=>[name,await import(`./isolated-${name}.mjs`)])));
const values=[null,true,false,0,-0,1.5,'ASCII','</script><script>alert(1)</script>','\u2028\u2029','\ud800','\udc00','\ud83d\ude00','漢字é',{nested:[null,'<',42]},[,'hole']];
let assertions=0;
for(const value of values){
  const options={state:{value},scriptId:'probe',nonce:'<"&'};
  const expected=entries.baseline.renderHydrationScriptValue(options,undefined,[]);
  for(const name of names){assert.equal(entries[name].renderHydrationScriptValue(options,undefined,[]),expected);assertions++;}
}
const cycle={};cycle.self=cycle;
for(const value of [NaN,Infinity,-Infinity,undefined,1n,Symbol('bad'),()=>1,cycle])for(const name of names){assert.throws(()=>entries[name].renderHydrationScriptValue({state:{value}},undefined,[]));assertions++;}
await writeFile('.tmp/ssr-hydration-fusion/behavior.json',JSON.stringify({assertions,note:'Generic-state output equivalence, script/Unicode handling, and unsupported-value rejection only. This is not full contract certification of experimental fused writers.'},null,2));
console.log(assertions,'behavior assertions passed');
