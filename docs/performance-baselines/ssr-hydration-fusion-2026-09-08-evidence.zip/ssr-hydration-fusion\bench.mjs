import {readFile, writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
assert.equal(process.env.NODE_ENV, 'production');
const data = JSON.parse(await readFile('.tmp/ssr-hydration-fusion/data.json', 'utf8'));
const names = process.env.FUSION_VARIANTS?.split(',') ?? ['baseline', 'unbudgeted', 'fused', 'fused-unbudgeted'];
const entries = Object.fromEntries(await Promise.all(names.map(async name => [name, await import(`./${name}.mjs`)])));
let consumed = 0;
function render(entry, fixture) {
  let output = '';
  const bytes = entry.renderParticipantToSink(fixture, '/incidents/inc-101', value => output += value, Buffer.byteLength);
  consumed += bytes;
  return {output, bytes};
}
const samples = [];
for (const size of [3, 20, 200]) {
  const fixture = {...data, incidents: Array.from({length: size}, (_, index) => ({...data.incidents[index % data.incidents.length], id: index ? `inc-${1000 + index}` : 'inc-101'}))};
  const expected = render(entries.baseline, fixture);
  for (const name of names) {
    assert.deepEqual(render(entries[name], fixture), expected);
    for(let i = 0; i < 2000; i++) render(entries[name], fixture);
  }
  const iterations = size === 200 ? 700 : 5000;
  for(let round = 0; round < 12; round++) for(const name of round % 2 ? [...names].reverse() : names) {
    const start = performance.now();
    for(let i = 0; i < iterations; i++) render(entries[name], fixture);
    samples.push({size, name, round, microseconds: (performance.now() - start) * 1000 / iterations});
  }
  for(const name of names) console.log(size, name, samples.filter(s => s.size === size && s.name === name).reduce((n,s) => n + s.microseconds, 0) / 12);
}
await writeFile(`.tmp/ssr-hydration-fusion/${globalThis.Bun ? 'bun' : 'node'}-${process.argv[2] ?? '1'}.json`, JSON.stringify({samples, consumed}, null, 2));
