// Feasibility probe for build-time emitted schema-specific writers. Dynamic Function is used
// ONLY in this ignored experiment; a production implementation would emit code in the compiler.
const fusionWriters = new WeakMap();
function fusionCompiledProject(state, value, schema, depth) {
  let writer = fusionWriters.get(schema);
  if (!writer) {
    const functions = [];
    function emit(schema) {
      if (schema === 0) return 'fusionGeneric';
      const name = 'p' + functions.length;
      const slot = functions.length;
      functions.push('');
      let body = `function ${name}(state,value,depth) { fusionCharge(state,depth); if (!value || typeof value !== 'object') throw Error('shape'); fusionEnter(state,value); try { let output='[';`;
      if (schema[0] === 2) {
        const child = emit(schema[1]);
        body += `if(!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype||Object.keys(value).length!==value.length)throw Error('array shape'); for(let i=0;i<value.length;i++){if(!Object.hasOwn(value,i))throw Error('ownership');if(i)output+=',';output+=${child}(state,value[i],depth+1);}`;
      } else {
        body += `if(Array.isArray(value)||Object.getPrototypeOf(value)!==Object.prototype||Object.keys(value).length!==${(schema.length-1)/2})throw Error('record shape');`;
        for(let i=1;i<schema.length;i+=2) {
          const key=JSON.stringify(schema[i]);
          const child=emit(schema[i+1]);
          body += `if(!Object.hasOwn(value,${key}))throw Error('ownership');${i>1?"output+=',';":''}output+=${child}(state,value[${key}],depth+1);`;
        }
      }
      functions[slot]=body+`return output+']';}finally{state.active.pop();}}`;
      return name;
    }
    const root=emit(schema);
    writer = new Function('fusionCharge','fusionGeneric','fusionEnter',functions.join('\n')+`\nreturn ${root};`)(fusionCharge,fusionGeneric,fusionEnter);
    fusionWriters.set(schema,writer);
  }
  return writer(state,value,depth);
}
