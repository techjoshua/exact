import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const dir='.tmp/ssr-hydration-fusion/';
assert.equal(process.env.NODE_ENV,'production');
const names=['baseline','unbudgeted','fused-shared','fused-compiled'];
const entries={};
for(const name of names){
  const source=await readFile(dir+name+'.mjs','utf8');
  const signature='function renderHydrationScriptValue(options, resumptionLayouts, capturedResumptions, byteTarget) {';
  assert(source.includes(signature));
  await writeFile(dir+'isolated-'+name+'.mjs','export let hydrationInputs;\n'+source.replace(signature,signature+'\nhydrationInputs = [options, resumptionLayouts, capturedResumptions];')+'\nexport {renderHydrationScriptValue};');
  entries[name]=await import(`./isolated-${name}.mjs`);
}
const data=JSON.parse(await readFile('.tmp/ssr-hydration-fusion/data.json','utf8'));
const samples=[];
let consumed=0;
for(const size of [3,20,200]){
  const fixture={...data,incidents:Array.from({length:size},(_,index)=>({...data.incidents[index%data.incidents.length],id:index?`inc-${1000+index}`:'inc-101'}))};
  const inputs={};
  for(const name of names){entries[name].renderParticipantToSink(fixture,'/incidents/inc-101',()=>{},Buffer.byteLength);inputs[name]=entries[name].hydrationInputs;}
  const expected=entries.baseline.renderHydrationScriptValue(...inputs.baseline);
  const json=expected.slice(expected.indexOf('>')+1,expected.lastIndexOf('</script>'));
  const prepared=JSON.parse(json);
  const ops=Object.fromEntries(names.map(name=>[name,()=>entries[name].renderHydrationScriptValue(...inputs[name])]));
  ops['native-json-only']=()=>JSON.stringify(prepared);
  for(const name of names)assert.equal(ops[name](),expected);
  for(const op of Object.values(ops))for(let i=0;i<3000;i++)consumed+=op().length;
  const iterations=size===200?2000:15000;
  for(let round=0;round<12;round++)for(const name of round%2?Object.keys(ops).reverse():Object.keys(ops)){
    const start=performance.now();for(let i=0;i<iterations;i++)consumed+=ops[name]().length;
    samples.push({size,name,round,microseconds:(performance.now()-start)*1000/iterations});
  }
  for(const name of Object.keys(ops))console.log(size,name,samples.filter(s=>s.size===size&&s.name===name).reduce((n,s)=>n+s.microseconds,0)/12);
}
await writeFile(dir+`isolated-${globalThis.Bun?'bun':'node'}.json`,JSON.stringify({samples,consumed,note:'Repeated hydration publication from captured component inputs. Native JSON only uses an already projected, parsed payload; it excludes constructing and checking that representation, script escaping, markup, and byte accounting.'},null,2));
