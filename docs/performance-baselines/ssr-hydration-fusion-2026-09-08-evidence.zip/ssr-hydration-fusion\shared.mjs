import {readFile, writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const dir = '.tmp/ssr-hydration-fusion/';
const source = await readFile(dir + 'fused.mjs', 'utf8');
const start = source.lastIndexOf('  function charge(');
const end = source.indexOf('  charge(0);', start);
assert(start > 0 && end > start);
let helpers = source.slice(start, end);
const rootStart = source.lastIndexOf('function experimentalHydration(');
let root = source.slice(rootStart, start) + source.slice(end);
for(const [name, renamed] of [['charge','fusionCharge'],['primitive','fusionPrimitive'],['enter','fusionEnter'],['generic','fusionGeneric'],['project','fusionProject']]) {
  const arg = name === 'primitive' ? '' : 'state, ';
  helpers = helpers.replaceAll(name + '(', renamed + '(' + arg);
  root = root.replaceAll(name + '(', renamed + '(' + arg);
}
await writeFile(dir + 'fused-shared.mjs', source.slice(0, rootStart) + root + '\n' + helpers);
const baseline = await readFile(dir + 'baseline.mjs', 'utf8');
const pattern = /\{\s*\.\.\.hydrationScriptOptionsFromValues\(([^]*?)\),\s*markerlessRoot: true\s*\}/g;
let count = 0;
const projected = baseline.replace(pattern, (_, args) => {count++; return `markHydrationOptions(hydrationScriptOptionsFromValues(${args}))`;});
assert.equal(count, 1);
await writeFile(dir + 'options.mjs', projected + '\nfunction markHydrationOptions(options) { options.markerlessRoot = true; return options; }\n');
