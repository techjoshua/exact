import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
let source=readFileSync(dir+'scalar-current.mjs','utf8');let count=0;
source=source.replace(/(event\.html|html)\.toLowerCase\(\)\.lastIndexOf\("<\/body>"\)/g,(_,value)=>{
 count++;return `(${value}.endsWith("</body></html>") ? ${value}.length - 14 : ${value}.toLowerCase().lastIndexOf("</body>"))`;
});
if(count!==2)throw Error('Expected two document-tail searches: '+count);
writeFileSync(dir+'document-tail.mjs',source);console.log({count});
