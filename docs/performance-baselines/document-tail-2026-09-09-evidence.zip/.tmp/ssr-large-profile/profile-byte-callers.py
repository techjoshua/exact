import json,collections,pathlib
results={}
for path in pathlib.Path('.tmp/ssr-large-profile').glob('scalar-profile-bun-*-exact-large.cpuprofile'):
 p=json.loads(path.read_text(encoding='utf-8'))
 nodes={n['id']:n for n in p['nodes']}
 parents={c:n['id'] for n in p['nodes'] for c in n.get('children',[])}
 sums=collections.Counter()
 for ident,delta in zip(p['samples'],p['timeDeltas']):
  if nodes[ident]['callFrame'].get('functionName')!='byteLength':continue
  stack=[]
  for _ in range(8):
   ident=parents.get(ident)
   if ident is None:break
   stack.append(nodes[ident]['callFrame'].get('functionName') or '(anonymous)')
  sums[' <- '.join(stack)]+=delta
 results[path.stem]=sums.most_common(12)
print(json.dumps(results,indent=2))
pathlib.Path('.tmp/ssr-large-profile/scalar-byte-callers.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
