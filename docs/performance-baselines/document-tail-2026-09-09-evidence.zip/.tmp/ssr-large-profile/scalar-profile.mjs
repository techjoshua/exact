import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const dir='.tmp/ssr-large-profile',rows=[];
for(const [runtime,mode,scenario] of [['node','string','small'],['node','string','large'],['bun','string','large'],['bun','stream','large']])for(const variant of ['exact','react']){
 const name=`scalar-profile-${runtime}-${mode}-${variant}-${scenario}`;
 const entry=variant==='exact'?`${dir}/scalar-current.mjs`:'framework-comparison/participants/react/dist-server/server-entry.js';
 const count=scenario==='small'?'100000':'20000';
 const r=spawnSync(runtime,['--cpu-prof',`--cpu-prof-dir=${dir}`,`--cpu-prof-name=${name}.cpuprofile`,`${dir}/long-worker.mjs`,entry,mode,scenario,count],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 const row={name,variant,runtimeId:runtime,artifactSha256:createHash('sha256').update(readFileSync(entry)).digest('hex'),...JSON.parse(r.stdout)};
 rows.push(row);writeFileSync(`${dir}/scalar-profiles.json`,JSON.stringify(rows,null,2));console.log(name,row.usPerRender);
}
