﻿import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const rows=[];
for(const runtime of ['node','bun'])for(const scenario of ['large','small'])for(let round=0;round<(scenario==='large'?3:2);round++)for(const variant of round%2?['tail-current','scalar-current']:['scalar-current','tail-current']){
 const entry=`.tmp/ssr-large-profile/${variant}.mjs`;
 const r=spawnSync(runtime,['.tmp/ssr-large-profile/long-worker.mjs',entry,'stream',scenario,'12000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 const row={variant,round,runtimeId:runtime,artifactSha256:createHash('sha256').update(readFileSync(entry)).digest('hex'),...JSON.parse(r.stdout)};
 const peer=rows.find(x=>x.runtimeId===runtime&&x.scenario===scenario);
 if(peer&&peer.hash!==row.hash)throw Error('Output changed');
 rows.push(row);writeFileSync('.tmp/ssr-large-profile/tail-current-results.json',JSON.stringify(rows,null,2));console.log(runtime,scenario,round,variant,row.usPerRender.toFixed(2));
}

