import { renderToReadableStream, renderToString } from "react-dom/server";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
//#region participants/react/src/service-client.ts
/** Stable controlled-service origin used by this participant's browser transport. */
var serviceUrl = "http://127.0.0.1:4310";
/** Loads the controlled session and incident queue as one application resource. */
async function loadIncidentData() {
	const [sessionResponse, incidentsResponse] = await Promise.all([fetch(`${serviceUrl}/api/session`), fetch(`${serviceUrl}/api/incidents`)]);
	if (!sessionResponse.ok || !incidentsResponse.ok) throw new Error("Service unavailable");
	const session = await sessionResponse.json();
	const queue = await incidentsResponse.json();
	return {
		...session,
		...queue
	};
}
/** Sends an optimistic-concurrency claim and preserves the authoritative conflict payload. */
async function claimIncident(incidentId, actorId, expectedVersion) {
	const response = await fetch(`${serviceUrl}/api/incidents/${incidentId}/claim`, {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: JSON.stringify({
			actorId,
			expectedVersion
		})
	});
	return {
		response,
		payload: await response.json()
	};
}
/** Submits an idempotent comment mutation and returns the decoded service result. */
async function submitComment(incidentId, actorId, body, clientMutationId) {
	const response = await fetch(`${serviceUrl}/api/incidents/${incidentId}/comments`, {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: JSON.stringify({
			actorId,
			body,
			clientMutationId
		})
	});
	return {
		response,
		payload: await response.json()
	};
}
/** Starts server analysis and returns its queued job or service error. */
async function requestAnalysis(incidentId) {
	const response = await fetch(`${serviceUrl}/api/incidents/${incidentId}/analysis`, {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: "{}"
	});
	return {
		response,
		payload: await response.json()
	};
}
//#endregion
//#region participants/react/src/live-service.ts
var subscribers = /* @__PURE__ */ new Set();
var source;
var connection = "Connecting";
/** Subscribes one mounted surface and closes the shared EventSource after the last release. */
function subscribeLiveService(subscriber) {
	subscribers.add(subscriber);
	subscriber.onConnection?.(connection);
	ensureLiveService();
	let active = true;
	return () => {
		if (!active) return;
		active = false;
		subscribers.delete(subscriber);
		if (subscribers.size) return;
		source?.close();
		source = void 0;
		connection = "Connecting";
	};
}
/** Opens and wires the one transport resource shared by all mounted subscribers. */
function ensureLiveService() {
	if (source) return;
	source = new EventSource(`${serviceUrl}/api/events`);
	source.onopen = () => publishConnection("Live service");
	source.onerror = () => publishConnection("Reconnecting");
	source.addEventListener("incident", (event) => {
		const incident = JSON.parse(event.data);
		for (const subscriber of subscribers) subscriber.onIncident?.(incident);
	});
	source.addEventListener("job", (event) => {
		const job = JSON.parse(event.data);
		for (const subscriber of subscribers) subscriber.onJob?.(job);
	});
}
/** Publishes transport state to current subscribers and retains it for later ones. */
function publishConnection(status) {
	connection = status;
	for (const subscriber of subscribers) subscriber.onConnection?.(status);
}
//#endregion
//#region participants/react/src/IncidentDetail.tsx
/** Owns React detail state, optimistic mutations, and the selection-scoped version snapshot. */
function IncidentDetail({ incident, users, sessionUserId, onIncident }) {
	const [draft, setDraft] = useState("");
	const [conflict, setConflict] = useState("");
	const [job, setJob] = useState(null);
	const [busy, setBusy] = useState(false);
	const [serviceError, setServiceError] = useState("");
	const [viewVersion, setViewVersion] = useState(incident?.version ?? 0);
	useEffect(() => {
		return subscribeLiveService({ onJob: (nextJob) => setJob((current) => current?.id === nextJob.id ? nextJob : current) });
	}, []);
	const claim = async () => {
		if (!incident || !sessionUserId) return;
		const original = copyIncident(incident);
		onIncident({
			...original,
			ownerId: sessionUserId,
			status: "investigating"
		}, "optimistic");
		setConflict("");
		setServiceError("");
		try {
			const { response, payload } = await claimIncident(original.id, sessionUserId, viewVersion);
			if (response.status === 409 && payload.error?.current) {
				onIncident(payload.error.current, "authoritative");
				setViewVersion(payload.error.current.version);
				setConflict("This incident changed while you were viewing it. The latest owner is shown.");
			} else if (!response.ok) throw new Error(payload.error?.message ?? "Unable to claim incident");
			else if (payload.incident) {
				onIncident(payload.incident, "authoritative");
				setViewVersion(payload.incident.version);
			} else onIncident(original, "optimistic");
		} catch (caught) {
			onIncident(original, "optimistic");
			setServiceError(caught instanceof Error ? caught.message : "Unable to claim incident");
		}
	};
	const addComment = async (event) => {
		event.preventDefault();
		if (!incident) return;
		const body = draft.trim();
		if (!body || [...body].length > 2e3) {
			setServiceError("Comment must contain 1 to 2,000 characters.");
			return;
		}
		const original = copyIncident(incident);
		const temporary = {
			id: `pending-${crypto.randomUUID()}`,
			authorId: sessionUserId,
			body,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		onIncident({
			...original,
			comments: [...original.comments, temporary]
		}, "optimistic");
		setDraft("");
		setServiceError("");
		try {
			const { response, payload } = await submitComment(original.id, sessionUserId, body, crypto.randomUUID());
			if (!response.ok || !payload.incident) throw new Error(payload.error?.message ?? "Unable to add comment");
			onIncident(payload.incident, "authoritative");
			setViewVersion(payload.incident.version);
		} catch (caught) {
			onIncident(original, "optimistic");
			setDraft(body);
			setServiceError(caught instanceof Error ? caught.message : "Unable to add comment");
		}
	};
	const startAnalysis = async () => {
		if (!incident) return;
		setBusy(true);
		setServiceError("");
		try {
			const { response, payload } = await requestAnalysis(incident.id);
			if (!response.ok || !payload.job) throw new Error(payload.error?.message ?? "Unable to start analysis");
			setJob(payload.job);
		} catch (caught) {
			setServiceError(caught instanceof Error ? caught.message : "Unable to start analysis");
		} finally {
			setBusy(false);
		}
	};
	const ownerName = users.find((user) => user.id === incident?.ownerId)?.name ?? "Unassigned";
	return /* @__PURE__ */ jsx("section", {
		className: "detail-panel",
		"aria-label": "Incident detail",
		children: incident ? /* @__PURE__ */ jsxs(Fragment, { children: [
			/* @__PURE__ */ jsxs("div", {
				className: "detail-heading",
				children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("span", {
					className: `severity ${incident.severity}`,
					children: incident.severity
				}), /* @__PURE__ */ jsx("h2", { children: incident.title })] }), /* @__PURE__ */ jsxs("span", {
					className: "version",
					children: ["Version ", incident.version]
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "facts",
				children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("span", { children: "Owner" }), /* @__PURE__ */ jsx("strong", { children: ownerName })] }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("span", { children: "Status" }), /* @__PURE__ */ jsx("strong", { children: incident.status })] })]
			}),
			conflict ? /* @__PURE__ */ jsx("p", {
				className: "alert",
				role: "alert",
				children: conflict
			}) : null,
			serviceError ? /* @__PURE__ */ jsx("p", {
				className: "alert",
				role: "alert",
				children: serviceError
			}) : null,
			/* @__PURE__ */ jsx("button", {
				type: "button",
				className: "primary",
				onClick: () => void claim(),
				children: "Claim incident"
			}),
			/* @__PURE__ */ jsxs("section", {
				className: "analysis-card",
				children: [/* @__PURE__ */ jsxs("div", { children: [
					/* @__PURE__ */ jsx("h3", { children: "Server analysis" }),
					/* @__PURE__ */ jsx("p", {
						role: "status",
						children: job ? `Analysis ${job.status}` : "Analysis has not started"
					}),
					job?.result ? /* @__PURE__ */ jsx("strong", { children: job.result.finding }) : null
				] }), /* @__PURE__ */ jsx("button", {
					type: "button",
					className: "quiet",
					disabled: busy,
					onClick: () => void startAnalysis(),
					children: "Start analysis"
				})]
			}),
			/* @__PURE__ */ jsxs("section", {
				className: "comments",
				children: [
					/* @__PURE__ */ jsx("h3", { children: "Response log" }),
					incident.comments.length === 0 ? /* @__PURE__ */ jsx("p", {
						className: "empty",
						children: "No comments yet."
					}) : null,
					incident.comments.map((comment) => /* @__PURE__ */ jsxs("article", { children: [/* @__PURE__ */ jsx("strong", { children: users.find((user) => user.id === comment.authorId)?.name }), /* @__PURE__ */ jsx("p", { children: comment.body })] }, comment.id)),
					/* @__PURE__ */ jsxs("form", {
						onSubmit: (event) => void addComment(event),
						children: [/* @__PURE__ */ jsxs("label", { children: ["New comment", /* @__PURE__ */ jsx("textarea", {
							value: draft,
							maxLength: 2e3,
							required: true,
							onChange: (event) => setDraft(event.currentTarget.value)
						})] }), /* @__PURE__ */ jsx("button", {
							type: "submit",
							className: "primary",
							children: "Add comment"
						})]
					})
				]
			})
		] }) : /* @__PURE__ */ jsx("p", {
			className: "empty",
			children: "Select an incident to inspect its response history."
		})
	});
}
function copyIncident(incident) {
	return {
		...incident,
		comments: incident.comments.map((comment) => ({ ...comment }))
	};
}
//#endregion
//#region participants/react/src/IncidentQueue.tsx
/** Owns React-local queue filters and publishes route selection to the application shell. */
function IncidentQueue(props) {
	const [severity, setSeverity] = useState("all");
	const [status, setStatus] = useState("all");
	const filteredIncidents = useMemo(() => props.incidents.filter((incident) => (severity === "all" || incident.severity === severity) && (status === "all" || incident.status === status)), [
		props.incidents,
		severity,
		status
	]);
	return /* @__PURE__ */ jsxs("section", {
		className: "queue-panel",
		"aria-labelledby": "queue-title",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "section-heading",
				children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("span", {
					className: "eyebrow",
					children: "Active response"
				}), /* @__PURE__ */ jsx("h2", {
					id: "queue-title",
					children: "Incident queue"
				})] }), /* @__PURE__ */ jsx("button", {
					type: "button",
					className: "quiet",
					onClick: props.onRefresh,
					children: "Refresh"
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "filters",
				children: [/* @__PURE__ */ jsxs("label", { children: ["Severity", /* @__PURE__ */ jsxs("select", {
					value: severity,
					onChange: (event) => setSeverity(event.currentTarget.value),
					children: [
						/* @__PURE__ */ jsx("option", {
							value: "all",
							children: "All"
						}),
						/* @__PURE__ */ jsx("option", {
							value: "critical",
							children: "Critical"
						}),
						/* @__PURE__ */ jsx("option", {
							value: "high",
							children: "High"
						}),
						/* @__PURE__ */ jsx("option", {
							value: "medium",
							children: "Medium"
						})
					]
				})] }), /* @__PURE__ */ jsxs("label", { children: ["Status", /* @__PURE__ */ jsxs("select", {
					value: status,
					onChange: (event) => setStatus(event.currentTarget.value),
					children: [
						/* @__PURE__ */ jsx("option", {
							value: "all",
							children: "All"
						}),
						/* @__PURE__ */ jsx("option", {
							value: "open",
							children: "Open"
						}),
						/* @__PURE__ */ jsx("option", {
							value: "investigating",
							children: "Investigating"
						}),
						/* @__PURE__ */ jsx("option", {
							value: "closed",
							children: "Closed"
						})
					]
				})] })]
			}),
			props.loading ? /* @__PURE__ */ jsx("p", {
				className: "empty",
				children: "Loading incidents…"
			}) : null,
			!props.loading && props.incidents.length === 0 && !props.error ? /* @__PURE__ */ jsx("p", {
				className: "empty",
				children: "No incidents match this workspace."
			}) : null,
			props.error ? /* @__PURE__ */ jsx("p", {
				role: "alert",
				children: props.error
			}) : null,
			/* @__PURE__ */ jsx("div", {
				className: "incident-list",
				children: filteredIncidents.map((incident) => /* @__PURE__ */ jsxs("button", {
					type: "button",
					className: incident.id === props.selectedId ? "incident active" : "incident",
					onClick: () => props.onSelectedIdChanged(incident.id),
					"data-testid": "incident-row",
					children: [
						/* @__PURE__ */ jsx("span", {
							className: `severity ${incident.severity}`,
							children: incident.severity
						}),
						/* @__PURE__ */ jsx("strong", { children: incident.title }),
						/* @__PURE__ */ jsxs("small", { children: [
							incident.ownerId ? "Assigned" : "Unassigned",
							" · ",
							incident.status
						] })
					]
				}, incident.id))
			})
		]
	});
}
//#endregion
//#region participants/react/src/IncidentApp.tsx
/** Coordinates React-owned queue resources, selection, and the application live connection. */
function IncidentApp({ initialData, path } = {}) {
	const [incidents, setIncidents] = useState(initialData?.incidents ?? []);
	const [users, setUsers] = useState(initialData?.users ?? []);
	const [sessionUserId, setSessionUserId] = useState(initialData?.sessionUserId ?? "");
	const [selectedId, setSelectedId] = useState(() => incidentIdFromPath(path) || initialData?.incidents[0]?.id || "");
	const [loading, setLoading] = useState(!initialData);
	const [error, setError] = useState("");
	const [connection, setConnection] = useState("Connecting");
	const replaceIncident = useCallback((incident, mode = "authoritative") => {
		setIncidents((current) => current.map((candidate) => candidate.id !== incident.id || mode === "authoritative" && (candidate.version > incident.version || sameIncidentResource(candidate, incident)) ? candidate : incident));
	}, []);
	const loadQueue = useCallback(async () => {
		setLoading(true);
		setError("");
		try {
			const result = await loadIncidentData();
			setSessionUserId(result.sessionUserId);
			setUsers(result.users);
			setIncidents(result.incidents);
			setSelectedId((current) => current || result.incidents[0]?.id || "");
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Unable to load incidents");
		} finally {
			setLoading(false);
		}
	}, []);
	useEffect(() => {
		if (!initialData) loadQueue();
		const releaseLiveService = subscribeLiveService({
			onConnection: setConnection,
			onIncident: (incident) => replaceIncident(incident, "authoritative")
		});
		const followLocation = () => setSelectedId(incidentIdFromPath());
		window.addEventListener("popstate", followLocation);
		return () => {
			releaseLiveService();
			window.removeEventListener("popstate", followLocation);
		};
	}, [
		initialData,
		loadQueue,
		replaceIncident
	]);
	const selectIncident = (id) => {
		setSelectedId(id);
		history.pushState({}, "", `/incidents/${id}`);
	};
	const selectedIncident = incidents.find((incident) => incident.id === selectedId);
	return /* @__PURE__ */ jsxs("div", {
		className: "app-shell",
		children: [/* @__PURE__ */ jsxs("header", {
			className: "masthead",
			children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("span", {
				className: "eyebrow",
				children: "Operations workspace"
			}), /* @__PURE__ */ jsx("h1", { children: "Signal Desk" })] }), /* @__PURE__ */ jsx("span", {
				className: "connection",
				role: "status",
				children: connection
			})]
		}), /* @__PURE__ */ jsxs("main", { children: [/* @__PURE__ */ jsx(IncidentQueue, {
			incidents,
			selectedId,
			onSelectedIdChanged: selectIncident,
			loading,
			error,
			onRefresh: () => void loadQueue()
		}), /* @__PURE__ */ jsx(IncidentDetail, {
			incident: selectedIncident,
			users,
			sessionUserId,
			onIncident: replaceIncident
		}, selectedIncident?.id ?? "empty")] })]
	});
}
/** Distinguishes a duplicate transport delivery from an equal-version optimistic projection. */
function sameIncidentResource(left, right) {
	return left.version === right.version && left.ownerId === right.ownerId && left.status === right.status && left.comments.length === right.comments.length && left.comments.every((comment, index) => {
		const candidate = right.comments[index];
		return candidate?.id === comment.id && candidate.authorId === comment.authorId && candidate.body === comment.body && candidate.createdAt === comment.createdAt;
	});
}
function incidentIdFromPath(path = typeof window === "undefined" ? "/" : window.location.pathname) {
	return path.match(/^\/incidents\/([^/]+)$/)?.[1] ?? "";
}
//#endregion
//#region participants/react/src/Document.tsx
/** Owns the complete React document on Node and Bun, including initial client data. */
let diagnosticSerialized;
function Document({ initialData, path, clientTags = "" }) {
	const serialized = diagnosticSerialized ??= JSON.stringify(initialData).replaceAll("<", "\\u003c");
	return /* @__PURE__ */ jsxs("html", {
		lang: "en",
		children: [/* @__PURE__ */ jsxs("head", { children: [
			/* @__PURE__ */ jsx("meta", { charSet: "UTF-8" }),
			/* @__PURE__ */ jsx("meta", {
				name: "viewport",
				content: "width=device-width, initial-scale=1.0"
			}),
			/* @__PURE__ */ jsx("meta", {
				name: "framework-participant",
				content: "react"
			}),
			/* @__PURE__ */ jsx("title", { children: "Incident Operations" }),
			Array.from(clientTags.matchAll(/<script\b[^>]*\bsrc="([^"]+)"/g), (match) => /* @__PURE__ */ jsx("script", {
				type: "module",
				src: match[1]
			}, match[1])),
			Array.from(clientTags.matchAll(/<link\b[^>]*\bhref="([^"]+)"/g), (match) => /* @__PURE__ */ jsx("link", {
				rel: "stylesheet",
				href: match[1]
			}, match[1]))
		] }), /* @__PURE__ */ jsxs("body", { children: [/* @__PURE__ */ jsx("div", {
			id: "app",
			"data-render-mode": "ssr",
			children: /* @__PURE__ */ jsx(IncidentApp, {
				initialData,
				path
			})
		}), /* @__PURE__ */ jsx("script", {
			id: "comparison-data",
			type: "application/json",
			dangerouslySetInnerHTML: { __html: serialized }
		})] })]
	});
}
//#endregion
//#region participants/react/src/server-entry.tsx
/** Streams the same complete document through React's Web Stream API on either runtime. */
function renderParticipantStream(initialData, path, options, signal) {
	return renderToReadableStream(/* @__PURE__ */ jsx(Document, {
		initialData,
		path,
		...options
	}), { signal });
}
/** Server-renders the React participant from one authoritative controlled-service snapshot. */
function renderParticipant(initialData, path, options) {
	return "<!doctype html>" + renderToString(/* @__PURE__ */ jsx(Document, {
		initialData,
		path,
		...options
	}));
}
//#endregion
export { renderParticipant, renderParticipantStream };
