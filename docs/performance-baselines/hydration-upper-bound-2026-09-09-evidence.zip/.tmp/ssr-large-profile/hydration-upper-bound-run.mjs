import {readFileSync,writeFileSync,unlinkSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const base='.tmp/ssr-large-profile/';
const exactPath=base+'marker-current.mjs';
const reactPath='framework-comparison/participants/react/dist-server/server-entry.js';
const diagnosticReact='framework-comparison/participants/react/dist-server/hydration-upper-bound.mjs';
let exact=readFileSync(exactPath,'utf8');
const signature='function renderHydrationScriptValue(options, resumptionLayouts, capturedResumptions, byteTarget, encodedByteLength = utf8ByteLength) {';
if(!exact.includes(signature)) throw Error('Exact signature changed');
exact=exact.replace(signature,`let diagnosticHydration;
${signature}
 if (diagnosticHydration) {
  if (byteTarget) byteTarget.hydrationBytes=diagnosticHydration.bytes;
  return diagnosticHydration.html;
 }
 const target=byteTarget ?? {};
 const html=diagnosticRenderHydrationScriptValue(options,resumptionLayouts,capturedResumptions,target,encodedByteLength);
 diagnosticHydration={html,bytes:target.hydrationBytes};
 return html;
}
function diagnosticRenderHydrationScriptValue(options, resumptionLayouts, capturedResumptions, byteTarget, encodedByteLength = utf8ByteLength) {`);
writeFileSync(base+'hydration-upper-bound.mjs',exact);
let react=readFileSync(reactPath,'utf8');
const line='const serialized = JSON.stringify(initialData).replaceAll("<", "\\\\u003c");';
if(!react.includes(line)) throw Error('React serialization changed: '+line);
react=react.replace('function Document({ initialData, path, clientTags = "" }) {','let diagnosticSerialized;\nfunction Document({ initialData, path, clientTags = "" }) {').replace(line,'const serialized = diagnosticSerialized ??= JSON.stringify(initialData).replaceAll("<", "\\\\u003c");');
writeFileSync(diagnosticReact,react);
writeFileSync(base+'react-hydration-upper-bound-source.mjs',react);
const variants={exact:exactPath,'exact-cached':base+'hydration-upper-bound.mjs',react:reactPath,'react-cached':diagnosticReact};
const rows=[];
try {
 for(const runtime of ['node','bun']) for(const scenario of ['small','large']) for(let round=0;round<3;round++) {
  const names=Object.keys(variants); const order=[...names.slice(round),...names.slice(0,round)];
  for(const variant of order) {
   const entry=variants[variant];
   const result=spawnSync(runtime,[base+'long-worker.mjs',entry,'string',scenario,'12000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
   if(result.status!==0) throw Error(result.stderr||result.stdout);
   const row={variant,runtimeId:runtime,round,artifactSha256:createHash('sha256').update(readFileSync(entry)).digest('hex'),...JSON.parse(result.stdout)};
   const peer=rows.find(x=>x.runtimeId===runtime&&x.scenario===scenario&&x.round===round&&x.variant.split('-')[0]===variant.split('-')[0]);
   if(peer&&peer.hash!==row.hash) throw Error('Diagnostic changed response');
   rows.push(row); writeFileSync(base+'hydration-upper-bound-results.json',JSON.stringify(rows,null,2));
   console.log(runtime,scenario,round,variant,row.usPerRender.toFixed(2));
  }
 }
} finally { unlinkSync(diagnosticReact); }
