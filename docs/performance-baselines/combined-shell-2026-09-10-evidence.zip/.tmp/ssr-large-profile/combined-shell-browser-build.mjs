import fs from 'node:fs/promises';
const root='.tmp/ssr-large-profile/';let source=await fs.readFile(root+'application-hydration-browser.mjs','utf8');
source=source.replace("out='.tmp/ssr-large-profile/application-hydration/'","out='.tmp/ssr-large-profile/combined-shell/'");
const before="for(let i=0;i<paths.length;i++)await fs.copyFile(out+(i?'bun-server-entry.js':'server-entry.js'),paths[i]);";
const replacement=`const indexHtml=await fs.readFile('framework-comparison/participants/exact/dist/index.html','utf8');
 const clientTags=indexHtml.match(/(?:<script[^>]+src="[^"]+"[^>]*><\\/script>|<link[^>]+href="[^"]+"[^>]*>)/g)?.join('')??'';
 assert.ok(clientTags.includes('script'));
 for(let i=0;i<paths.length;i++){
  const name=i?'bun-server-entry.js':'server-entry.js';let artifact=await fs.readFile(out+name,'utf8'),count=0;
  artifact=artifact.replace(/o\\.sink\\.write\\(("(?:\\\\.|[^"\\\\])*")\\);/g,(match,literal)=>{
   let html=JSON.parse(literal);if(!html.startsWith('<head'))return match;count++;
   html=html.replace(/<script\\b[^>]*>[\\s\\S]*?<\\/script>|<link\\b[^>]*>/g,'').replace('</head>',clientTags+'</head>');
   return 'o.sink.write('+JSON.stringify(html)+');';});assert.equal(count,1);
  await fs.writeFile(out+'browser-'+name,artifact);await fs.writeFile(paths[i],artifact);
 }`;
if(!source.includes(before))throw new Error('Browser install anchor absent');source=source.replace(before,replacement);
await fs.writeFile(root+'combined-shell-browser.mjs',source);
