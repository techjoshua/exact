import fs from 'node:fs/promises';
const root='.tmp/ssr-large-profile/';let source=await fs.readFile(root+'static-shell-work-audit.mjs','utf8');
source=source.replace(/const entries=[^\r\n]+/,"const entries={baseline:root+'static-shell/server-entry.js',candidate:root+'literal-url-screen/server-entry.js'};");
source=source.replace("const functions=[","const functions=['sanitizeUrlAttribute','renderCompiledNativeAttribute',");
source=source.replace("root+'static-shell/'+variant","root+'literal-url-screen/'+variant").replace("root+'static-shell/work-counts.json'","root+'literal-url-screen/work-counts.json'");
await fs.writeFile(root+'literal-url-count.mjs',source);
