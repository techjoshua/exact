import fs from 'node:fs/promises';import {resolve} from 'node:path';import {pathToFileURL} from 'node:url';import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/',out=root+'combined-shell/';await fs.mkdir(out,{recursive:true});
for(const name of ['server-entry.js','bun-server-entry.js']){
 let source=await fs.readFile(root+'static-shell/flat-document/'+name,'utf8');
 const publication=await fs.readFile(root+'application-hydration/'+name,'utf8');
 for(const fn of ['rootPropsOptions','rootPropsForCapture','rootComponentIdentity']){
  const start=source.indexOf('function '+fn+'('),end=source.indexOf('\n}',start)+2;
  const pstart=publication.indexOf('function '+fn+'('),pend=publication.indexOf('\n}',pstart)+2;assert.ok(start>0&&pstart>0&&end>start&&pend>pstart);
  source=source.slice(0,start)+publication.slice(pstart,pend)+source.slice(end);
 }
 const helper=publication.indexOf('\nfunction auditPublicationReference(');assert.ok(helper>0);source+=publication.slice(helper);
 await fs.writeFile(out+name,source);
}
const mods=await Promise.all([root+'application-hydration/server-entry.js',out+'server-entry.js'].map(p=>import(pathToFileURL(resolve(p)))));
const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
const rows=[],script=/<script type="application\/json" id="__exact_hydration">([\s\S]*?)<\/script>/;
for(const mode of ['string','stream'])for(let request=0;request<3;request++){
 const data=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));data.incidents[1].title='Combined '+request+' <safe> 🚀';
 const html=await Promise.all(mods.map(m=>mode==='string'?m.renderParticipant(data,'/incidents/inc-101',options):new Response(m.renderParticipantStream(data,'/incidents/inc-101',options)).text()));
 const normalize=h=>h.replace(script,'').replace(/<!--[\s\S]*?-->/g,'').replace(/ data-exact-id="[^"]*"/g,'');assert.equal(normalize(html[0]),normalize(html[1]));assert.equal(html[0].match(script)[1],html[1].match(script)[1]);rows.push({mode,request,bytes:Buffer.byteLength(html[1]),hydrationBytes:Buffer.byteLength(html[1].match(script)[1])});
}
await fs.writeFile(out+'verification.json',JSON.stringify(rows,null,2));console.log('Six live Unicode application and identical hydration comparisons passed.');
let runner=await fs.readFile(root+'application-hydration-http.mjs','utf8');
runner=runner.replace("root+'application-hydration/'","root+'combined-shell/'").replace("root+'application-hydration/http.json'","root+'combined-shell/http.json'");
runner=runner.replace('assert.equal(withoutPayload(html),withoutPayload(exactDocument));','const normalize=value=>withoutPayload(value).replace(/<!--[\\s\\S]*?-->/g,\'\').replace(/ data-exact-id="[^"]*"/g,\'\');assert.equal(normalize(html),normalize(exactDocument));');
runner=runner.replace("const orders=[['baseline','compiled','react'],['react','compiled','baseline'],['compiled','baseline','react'],['react','baseline','compiled']];","const orders=[['baseline','compiled','react'],['react','compiled','baseline'],['compiled','react','baseline'],['baseline','react','compiled'],['compiled','baseline','react'],['react','baseline','compiled']];").replace('rows.length,48','rows.length,72');
await fs.writeFile(root+'combined-shell-http.mjs',runner);
