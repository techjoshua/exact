import fs from 'node:fs/promises';import {spawn} from 'node:child_process';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
const out='.tmp/ssr-large-profile/literal-url-integration/',path='framework-comparison/participants/exact/src/Document.tsx';await fs.mkdir(out,{recursive:true});
const original=await fs.readFile(path);await fs.writeFile(out+'Document.original.tsx',original);
const index=await fs.readFile('framework-comparison/participants/exact/dist/index.html','utf8');const href=index.match(/<link\b[^>]*href="([^"]+\.css)"/)[1];
let source=original.toString(),start=source.indexOf('\t\t\t\t{stylesheetSources('),end=source.indexOf('\n\t\t\t</head>',start);assert.ok(start>0&&end>start);
source=source.slice(0,start)+'\t\t\t\t<link rel="stylesheet" href="'+href+'" />'+source.slice(end);await fs.writeFile(out+'Document.literal-css.tsx',source);
async function run(args,label){const result=await new Promise((resolve,reject)=>{const child=spawn(process.execPath,args,{cwd:'framework-comparison',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});let log='';child.stdout.on('data',d=>log+=d);child.stderr.on('data',d=>log+=d);child.on('error',reject);child.on('exit',code=>resolve({code,log}));});await fs.writeFile(out+label+'.log',result.log);assert.equal(result.code,0,result.log.slice(-9000));console.log(label,'passed');}
try{
 await fs.writeFile(path,source);await run(['src/build-exact.mjs'],'literal-css-build');
 await fs.cp('framework-comparison/participants/exact/dist',out+'dist-client',{recursive:true});
 for(const [folder,name] of [['dist-server','server-entry.js'],['dist-bun-server','bun-server-entry.js']])await fs.copyFile('framework-comparison/participants/exact/'+folder+'/'+name,out+name);
 for(const runtime of ['node','bun'])for(const mode of ['string','stream']){
  process.env.COMPARISON_E2E_RUNTIME=runtime;process.env.COMPARISON_SSR_RENDER_MODE=mode;
  await run(['../node_modules/@playwright/test/cli.js','test','-c','playwright.config.ts','--grep','exact|react'],'browser-'+runtime+'-'+mode);
 }
}finally{
 await fs.writeFile(path,original);await run(['src/build-exact.mjs'],'restored-build');assert.deepEqual(await fs.readFile(path),original);
 const hashes={};for(const [folder,name] of [['dist-server','server-entry.js'],['dist-bun-server','bun-server-entry.js']]){const bytes=await fs.readFile('framework-comparison/participants/exact/'+folder+'/'+name);await fs.writeFile(out+'current-'+name,bytes);hashes[name]=createHash('sha256').update(bytes).digest('hex');}
 await fs.writeFile(out+'current-hashes.json',JSON.stringify(hashes,null,2));console.log('Original Document source restored; current compiler output captured.',hashes);
}
