import fs from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
const functions=['sanitizeUrlAttribute','renderCompiledNativeAttribute','createPreparedServerRenderProgram','createCompiledChildRangeReceipt','createPreparedServerComponentReferenceFromPlainProps','withTaskObserver','renderHydrationScriptValue','validateJsonSafeHydrationValue','rootPropsOptions','createSsrResumptionCapture','enterHostTag','renderProgramWriter','prepareComponentProps','createSelectedDirectSsrFrame','prepareDirectScheduledSsrComponentReferences','constructDirectScheduledSsrComponent','renderIssuedServerComponentChildren','executeDirectSsrComponent','scriptSources','stylesheetSources'];
const entries={baseline:root+'static-shell/server-entry.js',candidate:root+'literal-url-screen/server-entry.js'};
const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
const rows=[];
for(const [variant,entry] of Object.entries(entries)){
 let source=await fs.readFile(entry,'utf8');
 const found=[];
 for(const name of functions){
  const pattern=new RegExp('^function '+name+'\\([^\\n]*\\{','m');
  if(!pattern.test(source)){assert.ok(['scriptSources','stylesheetSources'].includes(name),name);continue;}
  found.push(name);
  source=source.replace(pattern,line=>line+'\n auditCounts['+JSON.stringify(name)+']++;'+(name==='renderProgramWriter'?' auditHosts[host??"none"]=(auditHosts[host??"none"]??0)+1;':''));
 }
 source='let auditCounts={},auditHosts={};\n'+source; source+='\nexport function auditReset(){auditCounts='+JSON.stringify(Object.fromEntries(found.map(n=>[n,0])))+';auditHosts={};}export function auditRead(){return {counts:auditCounts,hosts:auditHosts};}\n';
 const path=root+'literal-url-screen/'+variant+'-counted.js';await fs.writeFile(path,source);
 const mod=await import(pathToFileURL(resolve(path)));
 for(const mode of ['string','stream']){
  const data=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));mod.auditReset();
  const html=mode==='string'?await mod.renderParticipant(data,'/incidents/inc-101',options):await new Response(mod.renderParticipantStream(data,'/incidents/inc-101',options)).text();
  const payload=html.match(/<script type="application\/json" id="__exact_hydration">([\s\S]*?)<\/script>/)[1];
  assert.ok(JSON.parse(payload));rows.push({variant,mode,...mod.auditRead(),bytes:Buffer.byteLength(html),hydrationBytes:Buffer.byteLength(payload),payload:JSON.parse(payload)});
 }
}
await fs.writeFile(root+'literal-url-screen/work-counts.json',JSON.stringify(rows,null,2));
console.log(JSON.stringify(rows.map(({payload,...r})=>r),null,2));
