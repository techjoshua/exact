import fs from 'node:fs/promises';import {spawn} from 'node:child_process';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
const out='.tmp/ssr-large-profile/combined-shell/',main='framework-comparison/participants/exact/src/main.tsx';
const original=await fs.readFile(main);await fs.writeFile(out+'main.original.tsx',original);
const paths=['framework-comparison/participants/exact/dist-server/server-entry.js','framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js'];
const hashes=await Promise.all(paths.map(async p=>createHash('sha256').update(await fs.readFile(p)).digest('hex')));
let candidate=original.toString().replace("import { Document } from './Document.jsx';\r\n",'').replace("import { Document } from './Document.jsx';\n",'').replace('>(Document, document.documentElement)','>(IncidentApp, root)').replace('hydrateAfterNavigation(<Document {...published} />, document, profileOptions)','hydrateAfterNavigation(<IncidentApp {...published} />, root, profileOptions)');
assert.ok(candidate!==original.toString());assert.ok(!candidate.includes('Document'));
await fs.writeFile(out+'main.application.tsx',candidate);
async function run(args,label){const result=await new Promise((resolve,reject)=>{const child=spawn(process.execPath,args,{cwd:'framework-comparison',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});let log='';child.stdout.on('data',d=>log+=d);child.stderr.on('data',d=>log+=d);child.on('error',reject);child.on('exit',code=>resolve({code,log}));});await fs.writeFile(out+label+'.log',result.log);assert.equal(result.code,0,result.log.slice(-9000));console.log(label,'passed');}
try{
 await fs.writeFile(main,candidate);await run(['src/build-exact.mjs'],'application-build');
 await fs.cp('framework-comparison/participants/exact/dist',out+'dist-client',{recursive:true});
 const indexHtml=await fs.readFile('framework-comparison/participants/exact/dist/index.html','utf8');
 const clientTags=indexHtml.match(/(?:<script[^>]+src="[^"]+"[^>]*><\/script>|<link[^>]+href="[^"]+"[^>]*>)/g)?.join('')??'';
 assert.ok(clientTags.includes('script'));
 for(let i=0;i<paths.length;i++){
  const name=i?'bun-server-entry.js':'server-entry.js';let artifact=await fs.readFile(out+name,'utf8'),count=0;
  artifact=artifact.replace(/o\.sink\.write\(("(?:\\.|[^"\\])*")\);/g,(match,literal)=>{
   let html=JSON.parse(literal);if(!html.startsWith('<head'))return match;count++;
   html=html.replace(/<script\b[^>]*>[\s\S]*?<\/script>|<link\b[^>]*>/g,'').replace('</head>',clientTags+'</head>');
   return 'o.sink.write('+JSON.stringify(html)+');';});assert.equal(count,1);
  await fs.writeFile(out+'browser-'+name,artifact);await fs.writeFile(paths[i],artifact);
 }
 for(const runtime of ['node','bun'])for(const mode of ['string','stream']){
  process.env.COMPARISON_E2E_RUNTIME=runtime;process.env.COMPARISON_SSR_RENDER_MODE=mode;
  await run(['../node_modules/@playwright/test/cli.js','test','-c','playwright.config.ts','--grep','exact|react'],'browser-'+runtime+'-'+mode);
 }
}finally{
 await fs.writeFile(main,original);await run(['src/build-exact.mjs'],'restored-build');
 for(let i=0;i<paths.length;i++)assert.equal(createHash('sha256').update(await fs.readFile(paths[i])).digest('hex'),hashes[i]);
 assert.deepEqual(await fs.readFile(main),original);console.log('Original main and canonical server hashes restored.');
}
