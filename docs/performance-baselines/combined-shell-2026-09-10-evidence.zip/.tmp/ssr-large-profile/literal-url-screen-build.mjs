import fs from 'node:fs/promises';import {spawn} from 'node:child_process';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/literal-url-screen/';await fs.mkdir(root,{recursive:true});
const path='framework-comparison/participants/exact/src/Document.tsx';const original=await fs.readFile(path);
const artifacts=['framework-comparison/participants/exact/dist-server/server-entry.js','framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js'];
const hashes=await Promise.all(artifacts.map(async p=>createHash('sha256').update(await fs.readFile(p)).digest('hex')));
await fs.writeFile(root+'Document.original.tsx',original);
let candidate=original.toString();const start=candidate.indexOf('\t\t\t\t{scriptSources('),end=candidate.indexOf('\n\t\t\t</head>',start);assert.ok(start>=0&&end>start);
candidate=candidate.slice(0,start)+`\t\t\t\t<script type="module" src="/assets/app.js" />\n\t\t\t\t<script type="module" src="/assets/vendor.js" />\n\t\t\t\t<link rel="stylesheet" href="/assets/app.css" />\n\t\t\t\t<link rel="stylesheet" href="/assets/theme.css" />`+candidate.slice(end);
const helpers=candidate.indexOf('\nfunction scriptSources(');assert.ok(helpers>=0);candidate=candidate.slice(0,helpers)+'\n';
await fs.writeFile(root+'Document.static.tsx',candidate);
async function build(label){
 const result=await new Promise((resolve,reject)=>{const child=spawn(process.execPath,['src/build-exact.mjs'],{cwd:'framework-comparison',env:{...process.env,NODE_ENV:'production'},windowsHide:true});let log='';child.stdout.on('data',d=>log+=d);child.stderr.on('data',d=>log+=d);child.on('error',reject);child.on('exit',code=>resolve({code,log}));});
 await fs.writeFile(root+label+'.log',result.log);assert.equal(result.code,0,result.log.slice(-5000));console.log(label,'build passed');
}
try{
 await fs.writeFile(path,candidate);await build('candidate');
 await fs.cp('framework-comparison/participants/exact/dist',root+'dist-client',{recursive:true});
 for(let i=0;i<artifacts.length;i++)await fs.copyFile(artifacts[i],root+(i?'bun-server-entry.js':'server-entry.js'));
}finally{
 await fs.writeFile(path,original);await build('restored');
 for(let i=0;i<artifacts.length;i++)assert.equal(createHash('sha256').update(await fs.readFile(artifacts[i])).digest('hex'),hashes[i]);
 assert.deepEqual(await fs.readFile(path),original);console.log('Normal source and server artifact hashes restored.');
}
