import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
const entries={exact:'framework-comparison/participants/exact/dist-server/server-entry.js',react:'framework-comparison/participants/react/dist-server/server-entry.js'};
const hashes={exact:'2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18',react:'44914942423c766956063c2d963b8f384b64470ce1da517c44ef66c6a46a754a'};
const rows=[];
for(const runtime of ['node','bun'])for(const mode of ['encoded','stream'])for(let round=0;round<2;round++)for(const framework of round?['react','exact']:['exact','react']){
 const entry=entries[framework];
 assert.equal(createHash('sha256').update(fs.readFileSync(entry)).digest('hex'),hashes[framework]);
 const run=spawnSync(runtime,[root+'direct-execution-target-timing-worker.mjs',entry,mode,'assets','20000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 assert.equal(run.status,0,run.stderr+run.stdout);
 const row={runtimeId:runtime,framework,round,artifactSha256:hashes[framework],...JSON.parse(run.stdout)};
 assert.ok(row.processPriority>0);
 const peer=rows.find(r=>r.framework===framework&&r.mode===mode);if(peer)assert.equal(row.hash,peer.hash);
 rows.push(row);fs.writeFileSync(root+'direct-execution-react-screen.json',JSON.stringify(rows,null,2));
 console.log(runtime,mode,framework,round,row.usPerRender.toFixed(2),'us;',row.bytes,'bytes');
}
assert.equal(rows.length,16);
