import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';
const worker=root+'direct-execution-node-profile-worker.mjs';
let source=fs.readFileSync(root+'direct-execution-target-timing-worker.mjs','utf8');
source="import {Session} from 'node:inspector/promises';\n"+source;
source=source.replace('const started=performance.now();', "const profiler=new Session();profiler.connect();\nawait profiler.post('Profiler.enable');await profiler.post('Profiler.setSamplingInterval',{interval:100});await profiler.post('Profiler.start');\nconst cpuStart=process.cpuUsage();\nconst started=performance.now();");
source=source.replace('const elapsed=performance.now()-started;', "const elapsed=performance.now()-started;\nconst cpu=process.cpuUsage(cpuStart);\nconst {profile}=await profiler.post('Profiler.stop');profiler.disconnect();\nawait writeFile(process.argv[6],JSON.stringify(profile));");
source=source.replace('processPriority:os.getPriority()', 'processPriority:os.getPriority(),cpuMicrosPerRender:(cpu.user+cpu.system)/count');
fs.writeFileSync(worker,source);
const rows=[];
for(let round=0;round<2;round++)for(const framework of round?['react','exact']:['exact','react']){
 const entry=`framework-comparison/participants/${framework}/dist-server/server-entry.js`;
 const artifactSha256=createHash('sha256').update(fs.readFileSync(entry)).digest('hex');
 assert.equal(artifactSha256,framework==='exact'?'2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18':'44914942423c766956063c2d963b8f384b64470ce1da517c44ef66c6a46a754a');
 const profile=root+`direct-execution-node-${framework}-${round}.cpuprofile`;
 const run=spawnSync(process.execPath,[worker,entry,'encoded','assets','30000',profile],{windowsHide:true,encoding:'utf8',env:{...process.env,NODE_ENV:'production'}});
 assert.equal(run.status,0,run.stderr+run.stdout);
 const row={framework,round,profile,artifactSha256,...JSON.parse(run.stdout)};
 rows.push(row);fs.writeFileSync(root+'direct-execution-node-profile.json',JSON.stringify(rows,null,2));
 console.log(framework,round,'profiled CPU us/render',row.cpuMicrosPerRender.toFixed(2));
}
