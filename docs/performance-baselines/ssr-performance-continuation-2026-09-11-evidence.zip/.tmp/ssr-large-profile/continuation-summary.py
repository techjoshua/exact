import json,hashlib,zipfile
from pathlib import Path
base=Path('.tmp/ssr-large-profile');out=Path('docs/performance-baselines')
folders=['queue-trace-node','paced-bun','edge-sink','key-count','fused-json','projector-current-http'];total=0;rows=[]
for folder in folders:
 d=json.loads((base/folder/'capture.json').read_text());assert d['complete']
 for name in ('exact','react'):
  identities={(b['identity']['bytes'],b['identity']['hash']) for b in d['blocks'] if b['id']==name};assert len(identities)==1,(folder,name,identities)
 for b in d['blocks']:
  total+=b['valid']
  for result in b['results']:
   s=result['stages'][0];assert s['errors']==0 and s['valid']==s['completed']==s['started']
  expected=b['valid']+len(b['results']) if b['id']=='exact' and b['phase']!='normal' else 0;assert b['after']['scheduleCalls']==expected
 if folder in ('edge-sink','key-count','fused-json','projector-current-http'):
  for population in (0,1):
   def rate(variant,phase):
    values=[b['rps'] for b in d['blocks'] if b.get('variant')==variant and b['population']==population and b['phase']==phase]
    assert values;return sum(values)/len(values)
   for phase in ('normal','scheduled'):
    current=rate('current',phase);candidate=rate('candidate',phase)
    rows.append({'experiment':folder,'repeat':population+1,'phase':phase,'current':current,'candidate':candidate,'changePct':(candidate/current-1)*100})
summary={'validResponses':total,'zeroErrors':True,'exactCandidateHtmlIdentical':True,'experiments':rows}
(base/'continuation-summary.json').write_text(json.dumps(summary,indent=2))
lines=['# SSR performance continuation, September 11, 2026','','Status: the experiments and browser/sparse checks listed here are complete. The broader objective of beating React in every comparable workload remains unmet. No speculative scheduler, sink, serializer, or compiler change was adopted in this pass. Existing retained framework improvements remain in place.','',f'{total:,} complete measured HTTP responses across six new captures, zero errors. Every eXact candidate has the same full-document bytes and SHA-256 as its current control, across both repeats. Schedule invocation counts match requests plus identity preflights. React receives no scheduling policy or rendering change.','', '## Decisions','','| Experiment | Result | Decision |','| --- | --- | --- |',
'| Queue-wait trace | Serial batches of 8 move average gate wait from about 12 ms to 68-69 ms at Node concurrency 256 | Do not choose policy from loop lag alone |',
'| Microtask-paced Bun batches | Both one- and four-checkpoint variants lose throughput | Reject |',
'| Preserve document-edge writes | Immediate Bun strings regress; scheduled strings improve slightly | Reject for this workload |',
'| Count keys without allocating a key array | Both modes regress in both repeats | Reject |',
'| Validate and emit positional JSON together | Both modes regress substantially | Reject this prototype |',
'| Inline generated primitive checks on current HTTP path | Opposite directions across repeats; control drift remains | No compiler change |','',
'| Experiment | Repeat | Mode | Current RPS | Candidate RPS | Change |','| --- | --- | --- | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['experiment']} | {r['repeat']} | {r['phase']} | {r['current']:,.0f} | {r['candidate']:,.0f} | {r['changePct']:+.2f}% |")
d=json.loads((base/'projector-current-http/capture.json').read_text())
def overall(variant,phase):
 values=[b['rps'] for b in d['blocks'] if b.get('variant')==variant and b['phase']==phase];return sum(values)/len(values)
current=overall('current','normal');scheduled=overall('current','scheduled');react=overall('react','normal')
lines+=['','## Current remaining SSR gap','',f'In the last paired large96 native Bun string capture, mean bookended immediate eXact throughput is {current:,.0f} RPS versus React {react:,.0f} RPS, {(1-current/react)*100:.1f}% lower. Scheduled eXact is {scheduled:,.0f} RPS. These are short, production-mode, concurrency-32 HTTP blocks on a shared workstation, not cloud capacity guarantees. Reported means do not remove control drift.','',
'The small-document scheduled Node/Bun string/stream wins and the large-document Node/Bun streaming wins are recorded in the preceding production scheduler reports. This pass did not rerun those cells, and enabling scheduling is an explicit host configuration, not the default. Do not present the selected scheduled results as default framework behavior.','',
'## Browser and sparse traffic','',
'The [browser capture](scheduler-browser-performance-2026-09-11.md) passed 288 measured scenarios across Node/Bun, string/stream, local/constrained profiles and immediate eXact/scheduled eXact/React. eXact navigation medians are lower than React in all cells. Constrained first paint is broadly tied; React retains about a 1 ms optimistic-feedback advantage under CPU throttling. Scheduling has no consistent quiet-host browser benefit or penalty in these samples. This is not a controlled historical regression comparison.','',
'The [sparse check](scheduler-sparse-traffic-2026-09-11.md) passed 18 measured full responses after 30-second idle periods. Median scheduled-minus-immediate response time was approximately 0.18 ms on Node and 0.27 ms on Bun. Three samples per cell cannot establish tail percentiles or zero overhead.','',
'## Implementation and validation','',
'Production renderer, compiler, sinks and scheduling behavior are unchanged. Engineering documentation, Node adapter guidance and the public advanced page now explain that throughput, p95/p99, queue residence and document size must inform scheduling decisions. Existing serialization limits, rejection behavior, task/lifecycle guarantees and the single renderer are preserved. No ABI fixtures were regenerated.','',
'Documentation formatting, targeted docs-page ESLint and whitespace checks passed. No framework test suite was repeated for rejected scratch-bundle experiments. Previously completed production SSR, adapter, ABI, platform and browser correctness checks remain recorded in the preceding reports. All task-owned benchmark and browser server processes exited.','',
'## Evidence','',
'- [Queue residence trace](scheduler-queue-wait-trace-2026-09-11.md)',
'- [Microtask pacing](bun-paced-render-starts-2026-09-11.md)',
'- [Document edge sink](bun-deferred-document-edges-2026-09-11.md)',
'- [Hydration key counting](bun-hydration-key-count-2026-09-11.md)',
'- [Fused positional JSON](bun-fused-positional-json-2026-09-11.md)',
'- [Current generated-projector recheck](bun-current-projector-inline-http-2026-09-11.md)','',
'Each report has a SHA-256-verified evidence archive with its capture and scripts. The continuation archive adds cross-variant document-identity and invocation verification. These experiments exhaust the concrete local hypotheses evaluated in this pass, not every possible future framework optimization. The remaining Bun gap is recorded as unresolved; no universal performance-completion claim is made.','']
report=out/'ssr-performance-continuation-2026-09-11.md';assert not report.exists();report.write_text('\n'.join(lines))
files=[report,base/'continuation-summary.json',base/'continuation-summary.py'];archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps({'validResponses':total,'currentBun':current,'scheduledBun':scheduled,'reactBun':react,'gapPct':(1-current/react)*100},indent=2))
