import fs from 'node:fs';
import {spawn,spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
const worker=root+'stateful-scope-affinity-worker.mjs';
const gate="process.stdout.write('READY\\n');\nawait new Promise(resolve=>process.stdin.once('data',resolve));\nprocess.stdin.destroy();\n";
fs.writeFileSync(worker,gate+fs.readFileSync(root+'ready-props-cpu-worker.mjs','utf8'));
const rows=[];
for(let round=0;round<2;round++)for(const variant of round?['candidate','current']:['current','candidate']){
 const entry=root+(variant==='candidate'?'stateful-scope':'direct-execution-integrated')+'/server-entry.js';
 const child=spawn(process.execPath,[worker,entry,'encoded','large','20000'],{windowsHide:true,stdio:['pipe','pipe','pipe'],env:{...process.env,NODE_ENV:'production'}});
 let stdout='',stderr='';let ready;
 const readiness=new Promise(resolve=>{ready=resolve;});
 child.stdout.on('data',data=>{stdout+=data;if(stdout.startsWith('READY\n'))ready();});
 child.stderr.on('data',data=>stderr+=data);
 const completion=new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',status=>resolve(status));});
 try {
  const state=await Promise.race([readiness.then(()=>({ready:true})),completion.then(status=>({status}))]);
  assert.equal(state.ready,true,'Worker exited before readiness: '+stderr);
  assert.ok(Number.isInteger(child.pid));
  const command=`$targetProcess=[System.Diagnostics.Process]::GetProcessById(${child.pid}); $targetProcess.ProcessorAffinity=[IntPtr]16384; $targetProcess.ProcessorAffinity.ToInt64()`;
  const pin=spawnSync('powershell.exe',['-NoProfile','-NonInteractive','-Command',command],{windowsHide:true,encoding:'utf8'});
  assert.equal(pin.status,0,pin.stderr);assert.equal(pin.stdout.trim(),'16384');
  child.stdin.end('go\n');
  assert.equal(await completion,0,stderr);
  const row={variant,round,affinityMask:16384,logicalCpu:14,...JSON.parse(stdout.slice('READY\n'.length))};
  const peer=rows[0];if(peer)assert.equal(row.hash,peer.hash);
  rows.push(row);fs.writeFileSync(root+'stateful-scope-affinity.json',JSON.stringify(rows,null,2));
  console.log(variant,round,'wall',row.usPerRender.toFixed(2),'CPU',row.cpuMicrosPerRender.toFixed(2));
 } finally {
  if(child.exitCode===null){child.kill();await completion;}
 }
}
