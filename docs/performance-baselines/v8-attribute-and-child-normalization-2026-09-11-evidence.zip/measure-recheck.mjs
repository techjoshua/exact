import {spawn} from 'node:child_process';
import {openSync,closeSync,readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
const dir=resolve('.tmp/v8-ssr'),rows=[];
for(let round=0;round<3;round++)for(const runtime of ['bun'])for(const scenario of ['small'])for(const mode of ['stream']){
 for(const variant of round%2?['identical','childrenCurrent','baseline']:['baseline','childrenCurrent','identical']){
  const name=`recheck-${round}-${runtime}-${scenario}-${mode}-${variant}`;
  const fd=openSync(dir+'/'+name+'.log','w');
  const exe=runtime==='node'?process.execPath:'C:/Program Files/Bun/bun.exe';
  const args=[dir+'/worker.mjs','exact',mode,scenario,scenario==='small'?'25000':'5000'];
  args.push(dir+'/'+variant+'.mjs');
  try{await new Promise((yes,no)=>{const child=spawn(exe,args,{windowsHide:true,stdio:['ignore',fd,fd],env:{...process.env,NODE_ENV:'production',V8_AUDIT_WARMUPS:scenario==='small'?'50000':'50000',V8_AUDIT_RESULT:dir+'/'+name+'.json'}});child.once('error',no);child.once('exit',code=>code===0?yes():no(Error(name+' failed '+code)));});}finally{closeSync(fd);}
  const result=JSON.parse(readFileSync(dir+'/'+name+'.json','utf8'));rows.push({round,runtime,variant,...result});
  writeFileSync(dir+'/recheck-measurements.json',JSON.stringify(rows,null,2));console.log(name+' '+result.usPerRender.toFixed(2)+' us');
 }
}
