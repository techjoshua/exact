import {readFileSync,writeFileSync,copyFileSync} from 'node:fs';
const dir='.tmp/v8-ssr';
copyFileSync(dir+'/baseline.mjs',dir+'/identical.mjs');
const runner=readFileSync(dir+'/measure-current.mjs','utf8').replace('round<2','round<3').replace("['node','bun']","['bun']").replace("['string','stream']","['stream']").replaceAll("'react'","'identical'").replace('`current-${round}', '`recheck-${round}').replace("variant==='identical'?'identical':'exact'","'exact'").replace("if(variant!=='identical')args.push",'args.push').replace("'/current-measurements.json'","'/recheck-measurements.json'");
writeFileSync(dir+'/measure-recheck.mjs',runner);
