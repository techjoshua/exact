import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
for(const variant of ['baseline','attribute','attributeStrings'])writeFileSync(new URL(`./${variant}-attributes-check.mjs`,import.meta.url),readFileSync(new URL(`./${variant}.mjs`,import.meta.url),'utf8')+'\nexport {renderCompiledNativeAttribute as checkAttribute};\n');
const modules=await Promise.all(['baseline','attribute','attributeStrings'].map(v=>import(`./${v}-attributes-check.mjs`)));
const values=[()=>null,()=>undefined,()=>false,()=>true,()=>0,()=>NaN,()=>'',()=> 'base active',()=> '"<&>',()=> 'caf\u00e9🚀',()=>['base',{active:true}],()=>({color:'red',width:3}),()=>new Date('2026-01-01'),()=>new Date(NaN),()=> 'javascript:alert(1)',()=> '/a?b=1&c=2',()=>({toString(){throw Error('conversion');}})];
let count=0;
for(let kind=0;kind<=7;kind++)for(const make of values)for(const accounted of [false,true])for(const shape of ['none','empty','sink']){
 const name=['title','className','style','href','srcdoc','value','title','className'][kind],attributeName=kind===1||kind===7?'class':name;
 const results=modules.map(m=>{const calls=[];const context=shape==='none'?undefined:shape==='empty'?{}:{outputSink:{account(...args){calls.push(['account',...args]);},accountKnown(...args){calls.push(['known',...args]);},accountAttribute(...args){calls.push(['attr',...args]);}}};let html,error;try{html=m.checkAttribute(make(),kind,name,attributeName,'div',context,accounted);}catch(e){error=e.message;}return{html,error,calls};});
 for(const result of results.slice(1))assert.deepEqual(results[0],result);count++;
}
console.log(`${count} attribute equivalence cases passed`);
