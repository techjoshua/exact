from pathlib import Path
import json,collections,statistics,re
root=Path('.tmp/v8-ssr');out={}
for phase in ['attribute','attributeStrings','attributeStream','current','recheck','fixed','children']:
    p=root/(phase+'-measurements.json')
    if not p.exists():continue
    groups=collections.defaultdict(list);data=json.loads(p.read_text())
    for row in data:groups[(row['runtime'],row.get('scenario',row.get('fixture')),row.get('mode','normalize'),row['variant'])].append(row.get('usPerRender',row.get('usPerCall')))
    out[phase]=[dict(runtime=k[0],fixture=k[1],mode=k[2],variant=k[3],mean=statistics.mean(v),runs=v) for k,v in groups.items()]
    if phase!='children':
        hashes=collections.defaultdict(set)
        for row in data:
            if row['participant']=='exact':hashes[(row['scenario'],row['mode'])].add(row['hash'])
        assert all(len(v)==1 for v in hashes.values()),hashes
for variant in ['baseline','children']:
    text=(root/f'child-{variant}-gc.log').read_text()
    phase=text.split('PHASE measured start',1)[1].split('PHASE measured end',1)[0]
    out[variant+'-gc']={'scavenges':len(re.findall(r'"gc":"s"',phase)),'allocatedBytes':sum(map(int,re.findall(r'"allocated":(\d+)',phase))),'pausesMs':sum(map(float,re.findall(r'"pause":([\d.]+)',phase)))}
    print(variant+' GC',out[variant+'-gc'])
(root/'followup-summary.json').write_text(json.dumps(out,indent=2))
for phase in ['children','attributeStrings','attributeStream','current','recheck']:
    if phase not in out:continue
    print(phase)
    for r in out[phase]:print(r['runtime'],r['fixture'],r['mode'],r['variant'],round(r['mean'],3),[round(v,3) for v in r['runs']])
