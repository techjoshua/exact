import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const dir='.tmp/v8-ssr';
const baseline=readFileSync(dir+'/baseline.mjs');
assert.deepEqual(readFileSync('framework-comparison/participants/exact/dist-server/server-entry.js'),baseline);
const results=[];
for(const exe of [process.execPath,'C:/Program Files/Bun/bun.exe']){
 const run=spawnSync(exe,[dir+'/check-split.mjs'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 assert.equal(run.status,0,run.stderr);results.push({exe,code:run.status,stdout:run.stdout,stderr:run.stderr});
}
writeFileSync(dir+'/verification.json',JSON.stringify({baselineSha256:createHash('sha256').update(baseline).digest('hex'),canonicalUnchanged:true,results},null,2));
console.log('Canonical eXact bundle unchanged; both runtime differential checks passed.');
