from pathlib import Path
import json,collections,re
root=Path('.tmp/v8-ssr')
out={}
for name in ['exact-string','exact-stream','react-string','react-stream']:
 p=json.loads((root/(name+'.cpuprofile')).read_text());nodes={n['id']:n for n in p['nodes']};weights=collections.Counter()
 for id,dt in zip(p.get('samples',[]),p.get('timeDeltas',[])):weights[id]+=dt
 total=sum(weights.values());rows=[]
 for id,weight in weights.most_common(20):
  f=nodes[id]['callFrame'];rows.append({'function':f['functionName'],'file':f['url'],'line':f['lineNumber']+1,'ms':round(weight/1000,2),'percent':round(weight/total*100,2)})
 log=(root/(name+'-trace.log')).read_text();steady=log.split('PHASE measured start',1)[1]
 deopts=[l for l in steady.splitlines() if '[bailout ' in l]
 rejected=collections.Counter(re.findall(r'Cannot consider (.*)',log))
 out[name]={'cpu':rows,'steadyDeopts':deopts,'allDeopts':[l for l in log.splitlines() if '[bailout ' in l],'rejectedInlining':rejected.most_common(20)}
 print('\n'+name)
 for row in rows[:12]:print(row['percent'],row['function'],row['file'].split('/')[-1],row['line'])
 print('steady deopts',len(deopts));print('\n'.join(deopts[:10]))
 print('inlining refusals',sum(rejected.values()))
(root/'trace-summary.json').write_text(json.dumps(out,indent=2))
