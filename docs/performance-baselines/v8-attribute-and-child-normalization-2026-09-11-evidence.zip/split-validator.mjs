import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/v8-ssr';
const source=readFileSync(dir+'/baseline.mjs','utf8');
const boundary='\t\treturn validateValue(value, depth, state) ? value : positionalUnsafe;\n\t}\n\tif (++state.nodes > state.maxNodes || depth > state.maxDepth) return positionalUnsafe;';
if(source.split(boundary).length!==2)throw Error('Expected one boundary');
const replacement='\t\treturn validateValue(value, depth, state) ? value : positionalUnsafe;\n\t}\n\treturn validatePositionalContainer(value, schema, depth, state);\n}\nfunction validatePositionalContainer(value, schema, depth, state) {\n\tif (++state.nodes > state.maxNodes || depth > state.maxDepth) return positionalUnsafe;';
writeFileSync(dir+'/split.mjs',source.replace(boundary,replacement));
const runner=readFileSync(dir+'/measure.mjs','utf8')
 .replace('round<3','round<2')
 .replace("['react','candidate','baseline']:['baseline','candidate','react']","['split','baseline']:['baseline','split']")
 .replace('`${round}-${runtime}', '`split-${round}-${runtime}')
 .replace("'/layout-measurements.json'","'/split-measurements.json'");
writeFileSync(dir+'/measure-split.mjs',runner);
