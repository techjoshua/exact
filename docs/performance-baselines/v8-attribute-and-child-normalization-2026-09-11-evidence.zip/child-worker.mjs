import {writeFileSync} from 'node:fs';
const [variant,fixture]=process.argv.slice(2);const {checkChildren}=await import('./'+variant+'-children.mjs');
const leaf={};const flat=Array.from({length:32},(_,i)=>i%2?leaf:i);
let tree=flat;if(fixture==='nested')tree=Array.from({length:32},()=>[flat.slice(0,8),[flat.slice(8,16)]]);
if(fixture==='deep')for(let i=0;i<32;i++)tree=[tree];
const keep=new Array(32);let sum=0;for(let i=0;i<20000;i++)keep[i%32]=checkChildren(tree);
const start=performance.now();for(let i=0;i<100000;i++){const r=checkChildren(tree);sum+=r.length;keep[i%32]=r;}const usPerCall=(performance.now()-start)/100000*1000;
const result={variant,fixture,usPerCall,sum,length:keep[0].length,versions:process.versions};
console.log(JSON.stringify(result));if(process.env.CHILD_RESULT)writeFileSync(process.env.CHILD_RESULT,JSON.stringify(result,null,2));
