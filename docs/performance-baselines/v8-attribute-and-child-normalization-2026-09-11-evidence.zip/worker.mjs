import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const [participant='exact',mode='string',scenario='small',countText='40000',entryOverride]=process.argv.slice(2);
const entry=resolve(entryOverride??`framework-comparison/participants/${participant}/dist-server/server-entry.js`);
const mod=await import(pathToFileURL(entry));
const data=JSON.parse(await readFile('.tmp/v8-ssr/data.json','utf8'));
if(scenario==='large')data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
const options={clientTags:'<script type="module" src="/assets/app.js"></script><link rel="stylesheet" href="/assets/app.css">'};
const count=Number(countText),warmups=Number(process.env.V8_AUDIT_WARMUPS??6000);
let html='',bytes=0;
async function run(iterations){
 if(mode==='string')for(let i=0;i<iterations;i++){
  html=await mod.renderParticipant(data,'/incidents/inc-101',options);
  bytes+=Buffer.byteLength(html);
 }else for(let i=0;i<iterations;i++){
  html=await new Response(await mod.renderParticipantStream(data,'/incidents/inc-101',options)).text();
  bytes+=Buffer.byteLength(html);
 }
}
console.log('PHASE warmup start');await run(warmups);console.log('PHASE measured start');
const start=performance.now();await run(count);const elapsedMs=performance.now()-start;
assert.match(html,/^<!doctype html>/i);assert.match(html,/<\/body><\/html>\s*$/i);
assert.ok(html.includes('Delayed fulfillment events'));assert.ok(html.includes('/assets/app.css'));
const result={participant,mode,scenario,count,warmups,elapsedMs,usPerRender:elapsedMs/count*1000,bytes:Buffer.byteLength(html),checksum:bytes,hash:createHash('sha256').update(html).digest('hex'),entry,entrySha256:createHash('sha256').update(await readFile(entry)).digest('hex'),versions:process.versions};
console.log('RESULT '+JSON.stringify(result));
if(process.env.V8_AUDIT_RESULT)await writeFile(process.env.V8_AUDIT_RESULT,JSON.stringify(result,null,2)+'\n');
