import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/v8-ssr';
const source=readFileSync(dir+'/baseline.mjs','utf8');
writeFileSync(dir+'/children-count.mjs',source.replace('function serverComponentProps(reference) {','const childCounts = new Map();\nexport {childCounts};\nfunction serverComponentProps(reference) {\nchildCounts.set(reference.children.length,(childCounts.get(reference.children.length)??0)+1);'));
const mod=await import('./children-count.mjs');const data=JSON.parse(readFileSync(dir+'/data.json','utf8'));const results=[];
for(const scenario of ['small','large']){
 if(scenario==='large')data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
 mod.childCounts.clear();await mod.renderParticipant(data,'/incidents/inc-101',{clientTags:'<script type="module" src="/assets/app.js"></script><link rel="stylesheet" href="/assets/app.css">'});
 results.push({scenario,counts:[...mod.childCounts]});
}
writeFileSync(dir+'/child-counts.json',JSON.stringify(results,null,2));console.log(results);
