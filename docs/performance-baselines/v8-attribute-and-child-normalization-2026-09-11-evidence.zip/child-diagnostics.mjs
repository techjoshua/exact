import {spawnSync} from 'node:child_process';
import {openSync,closeSync,readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/v8-ssr';
const worker=readFileSync(dir+'/child-worker.mjs','utf8').replace('const start=performance.now();','global.gc();console.log("PHASE measured start");\nconst start=performance.now();').replace('console.log(JSON.stringify(result));','global.gc();console.log("PHASE measured end");\nconsole.log(JSON.stringify(result));');
writeFileSync(dir+'/child-gc-worker.mjs',worker);
for(const variant of ['baseline','children']){
 for(const diagnostic of ['gc','bytecode']){
  const fd=openSync(`${dir}/child-${variant}-${diagnostic}.log`,'w');
  const args=diagnostic==='gc'?['--expose-gc','--trace-gc-nvp',dir+'/child-gc-worker.mjs',variant,'nested']:['--print-bytecode','--print-bytecode-filter=normalizeChildren',dir+'/child-worker.mjs',variant,'nested'];
  const p=spawnSync(process.execPath,args,{windowsHide:true,stdio:['ignore',fd,fd],env:{...process.env,NODE_ENV:'production'}});closeSync(fd);if(p.status!==0)throw Error(variant+' '+diagnostic+' failed');
 }
}
