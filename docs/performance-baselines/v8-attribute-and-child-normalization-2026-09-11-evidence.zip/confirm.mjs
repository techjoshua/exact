import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/v8-ssr';
let runner=readFileSync(dir+'/measure-split.mjs','utf8')
 .replace('`split-${round}', '`confirm-${round}')
 .replace("'12000':'3000'","'50000':'50000'")
 .replace("'/split-measurements.json'","'/confirm-measurements.json'");
runner=runner.replace("for(const mode of ['string','stream']){", "for(const mode of ['string','stream']){\n if(scenario==='small' && mode==='string')continue;");
writeFileSync(dir+'/measure-confirm.mjs',runner);
