import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync,readFileSync,copyFileSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
const dir=resolve('.tmp/v8-ssr');mkdirSync(dir,{recursive:true});
copyFileSync('.tmp/positional-leaves/data.json',dir+'/data.json');
const steps=[];
for(const participant of ['exact','react'])for(const mode of ['string','stream']){
 const name=participant+'-'+mode;console.log('START '+name);
 const args=['--trace-opt','--trace-deopt','--trace-turbo-inlining','--trace-file-names','--cpu-prof','--cpu-prof-dir='+dir,'--cpu-prof-name='+name+'.cpuprofile',dir+'/worker.mjs',participant,mode,'small','40000'];
 const log=openSync(dir+'/'+name+'-trace.log','w');
 const step={name,args,startedAt:new Date().toISOString()};steps.push(step);
 try{await new Promise((yes,no)=>{const child=spawn(process.execPath,args,{env:{...process.env,NODE_ENV:'production',V8_AUDIT_RESULT:dir+'/'+name+'-trace.json'},windowsHide:true,stdio:['ignore',log,log]});step.pid=child.pid;child.once('error',no);child.once('exit',code=>{step.code=code;code===0?yes():no(Error(name+' failed '+code));});});}
 finally{closeSync(log);step.endedAt=new Date().toISOString();writeFileSync(dir+'/trace-execution.json',JSON.stringify(steps,null,2));}
 console.log('DONE '+name);
}
