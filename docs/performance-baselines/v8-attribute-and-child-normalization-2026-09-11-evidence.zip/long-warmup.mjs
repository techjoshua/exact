import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/v8-ssr';
const runner=readFileSync(dir+'/measure.mjs','utf8')
 .replace('round<3','round<2')
 .replace("['small','large']","['small']")
 .replace("['string','stream']","['string']")
 .replace("['react','candidate','baseline']:['baseline','candidate','react']","['react','split','candidate','baseline']:['baseline','candidate','split','react']")
 .replace('`${round}-${runtime}', '`long-${round}-${runtime}')
 .replace("'12000':'3000'","'50000':'50000'")
 .replace("'/layout-measurements.json'","'/long-measurements.json'");
writeFileSync(dir+'/measure-long.mjs',runner);
