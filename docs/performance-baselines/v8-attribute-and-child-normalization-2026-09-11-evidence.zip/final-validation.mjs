import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync,readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const dir='.tmp/v8-ssr',fd=openSync(dir+'/accepted-tests.log','w');
let code;
try{code=await new Promise((yes,no)=>{const p=spawn(process.execPath,['C:/Program Files/nodejs-v26.8.1/node_modules/npm/bin/npm-cli.js','run','test','-w','@exactjs/core','-w','@exactjs/ssr'],{windowsHide:true,stdio:['ignore',fd,fd],env:{...process.env,NODE_ENV:'test'}});p.once('error',no);p.once('exit',yes);});}finally{closeSync(fd);}
assert.equal(code,0);console.log('Rebuilt core and SSR tests passed');
const before=await import('./baseline-children.mjs');
const after=await import('./children-children.mjs');
const large=Array.from({length:200000},(_,i)=>i);let previousError;
try{before.checkChildren([large]);}catch(error){previousError={name:error.name,message:error.message};}
assert.equal(previousError?.name,'RangeError');const result=after.checkChildren([large]);assert.equal(result.length,large.length);assert.equal(result[199999],199999);
writeFileSync(dir+'/large-child-regression.json',JSON.stringify({previousError,currentLength:result.length},null,2));
console.log('Previous large-list RangeError reproduced; retained normalizer succeeds');
