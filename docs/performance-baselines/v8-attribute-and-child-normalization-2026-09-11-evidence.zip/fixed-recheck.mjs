import {spawn} from 'node:child_process';
import {openSync,closeSync,readFileSync,writeFileSync,copyFileSync} from 'node:fs';
import {resolve} from 'node:path';
const dir=resolve('.tmp/v8-ssr'),rows=[];
const orders=[['baseline','childrenCurrent','identical'],['identical','childrenCurrent','baseline'],['childrenCurrent','baseline','identical'],['identical','baseline','childrenCurrent'],['baseline','identical','childrenCurrent'],['childrenCurrent','identical','baseline']];
for(const [round,order] of orders.entries())for(const variant of order){
 const name=`fixed-${round}-${variant}`;copyFileSync(`${dir}/${variant}.mjs`,dir+'/selected.mjs');
 const fd=openSync(dir+'/'+name+'.log','w');
 try{await new Promise((yes,no)=>{const p=spawn('C:/Program Files/Bun/bun.exe',[dir+'/worker.mjs','exact','stream','small','25000',dir+'/selected.mjs'],{windowsHide:true,stdio:['ignore',fd,fd],env:{...process.env,NODE_ENV:'production',V8_AUDIT_WARMUPS:'50000',V8_AUDIT_RESULT:dir+'/'+name+'.json'}});p.once('error',no);p.once('exit',code=>code===0?yes():no(Error(name+' '+code)));});}finally{closeSync(fd);}
 const row={round,runtime:'bun',variant,...JSON.parse(readFileSync(dir+'/'+name+'.json','utf8'))};rows.push(row);writeFileSync(dir+'/fixed-measurements.json',JSON.stringify(rows,null,2));console.log(name+' '+row.usPerRender.toFixed(2)+' us');
}
