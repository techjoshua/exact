import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
for(const variant of ['baseline','split'])writeFileSync(new URL(`./${variant}-validation.mjs`,import.meta.url),readFileSync(new URL(`./${variant}.mjs`,import.meta.url),'utf8')+'\nexport {validatePositionalValue, validateValue, projectPositionalField, HydrationAncestors, positionalMismatch, positionalUnsafe};\n');
const modules=await Promise.all(['baseline','split'].map(v=>import(`./${v}-validation.mjs`)));
const cases=[... [null,'hello',true,1,0,-0,NaN,Infinity,undefined,1n,Symbol(),()=>{},[],{},[1,2],{a:1}].map(value=>()=>[value,0]),()=>[{a:1,b:'x'},[1,'a',0,'b',0]],()=>[[{a:1},{a:2}],[2,[1,'a',0]]],()=>[Object.create(null),[1]],()=>[[,1],[2,0]],()=>{const v={};v.self=v;return [v,[1,'self',0]];},()=>{const v={get a(){delete this.b;return 1;},b:2};return[v,[1,'a',0,'b',0]];},()=>[{get a(){throw Error('getter');}},[1,'a',0]],()=>{let v='x',s=0;for(let i=0;i<20;i++){v={a:v};s=[1,'a',s];}return[v,s];}];
let count=0;
for(const make of cases)for(const maxNodes of [0,1,3,100])for(const maxDepth of [0,1,100])for(const path of [false,true]){
 const results=modules.map(m=>{const [value,schema]=make();const state={active:new m.HydrationAncestors(),maxNodes,maxDepth,nodes:0,validate:m.validateValue,project:m.projectPositionalField,mismatch:m.positionalMismatch,unsafe:m.positionalUnsafe,...(path?{path:{keys:[],arrays:[]}}:{})};let result,error;try{result=m.validatePositionalValue(value,schema,0,state);}catch(e){error=e.message;}return {result:result===m.positionalMismatch?'mismatch':result===m.positionalUnsafe?'unsafe':result,error,nodes:state.nodes,path:state.path,active:state.active.values?.length??state.active.size};});assert.deepStrictEqual(results[0],results[1]);count++;
}
console.log(`${count} differential cases passed`);
