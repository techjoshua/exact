from pathlib import Path
import json,hashlib,zipfile,shutil
root=Path('.tmp/v8-ssr');summary=json.loads((root/'results-summary.json').read_text())
target=Path('docs/performance-baselines/v8-bytecode-2026-09-11.md')
def table(phase,variants):
    groups={}
    for r in summary[phase]:groups.setdefault((r['runtime'],r['scenario'],r['mode']),{})[r['variant']]=r['mean']
    lines=['| Runtime | Fixture | Mode | '+' | '.join(variants)+' |','| --- | --- | --- | '+' | '.join(['---:']*len(variants))+' |']
    for k,v in groups.items():lines.append('| '+' | '.join(k)+' | '+' | '.join(f'{v[name]:.2f}' if name in v else 'Not measured' for name in variants)+' |')
    return '\n'.join(lines)
text='''# V8 bytecode investigation, September 11, 2026

Status: investigation completed. Both isolated candidates remain unadopted. Production source,
canonical application builds, React, the shared renderer, and the published benchmark baseline are
unchanged. This is an engineering experiment, not a new public benchmark claim.

## Method

Starting commit: `8aa16396c57360411dc6741af22fae38315aa9cc`. Node 26.8.1 uses V8
14.6.202.34-node.28. Bun 1.4.2 supplies a separate cross-runtime timing check; V8 bytecode findings
do not describe Bun's JavaScript engine. All timed processes use NODE_ENV=production.

Ignition bytecode is useful for finding operations, but hot code is optimized using runtime feedback.
The investigation therefore combines `--print-bytecode`, `--trace-opt`, `--trace-deopt`,
`--trace-turbo-inlining`, CPU profiles, and `%DebugPrint` object layouts. See
[V8's explanation of feedback and optimization](https://v8.dev/blog/maglev).
Instrumented timings are excluded from acceptance comparisons.

Each process renders the full authored application and document shell with one script and one
stylesheet. Small has three incidents; large has 96. String timing includes UTF-8 byte counting of
the returned document. Streaming includes complete consumption using Response.text and byte counting.
These are render/consumer microseconds, lower is better, not HTTP requests/s or browser metrics.
No rendered HTML is cached. Full eXact hashes match across candidates and runtimes for each fixture
and mode. React renders its own tree without implementation changes.

Initial layout screening uses three fresh-process populations, reversing variant order in the middle
population. Validator screening uses two reversed populations. Small screening uses 12,000 warmups
and 25,000 measured renders; large uses 3,000 warmups and 5,000 measured renders. Confirmation uses
50,000 warmups and the same measured counts, with two reversed populations. The PC has variable
foreground usage, so small differences are observations, not guaranteed causal effects. No builds,
tests, profiles, or compression overlap timing. Earlier idle-PC results are not acceptance controls.

## Object-literal layout

`createPreparedServerRenderProgram` puts its computed symbol first. V8 emits an empty object
boilerplate followed by three keyed property definitions. Moving the two named fields before the
symbol produces a static two-field boilerplate and reduces bytecode from 85 to 77 bytes.

The actual factory, including optional metadata, was inspected. Ordinary invocation objects shrink
from 56 to 48 bytes on this build. However, adding either enhancement or deferred-task metadata now
needs a three-slot PropertyArray, whereas the original layout retains that fourth field in-object.
Both layouts need a PropertyArray when both optional fields are present. The probe runs outside an
active domain; it does not measure every domain-bearing shape or total heap allocation.

This differs from the earlier rejected [component-reference layout experiment](proven-reference-2026-09-10.md).
It preserves named-key order and descriptors, but allocation cost depends on the complete shape.
The initial Node small-string mean improves from 22.78 to 21.77 microseconds. That gain disappears
after longer warmup, while Bun becomes slower. The candidate is rejected.

## Validator inlining

V8 explicitly refuses to inline the 1,089-byte `validatePositionalValue` because it exceeds the
bytecode limit. The candidate retains its schema-zero primitive checks in a 146-byte entry function
and moves the unchanged container traversal into `validatePositionalContainer`. Recursive calls still
pass through the entry function. No budgets, finite-number checks, ownership checks, getter ordering,
cycle detection, diagnostic paths, or cleanup rules are removed.

The hypothesis was a small overall improvement from eliminating primitive-call overhead in a sampled
hot function, not removal of the entire hydration cost. Trace output confirms that V8 inlines the new
entry into container traversal and `validateDirectEnvelope`. Both Node and Bun pass 576 differential
cases each, covering primitives, records, arrays, invalid prototypes, sparse arrays, cycles, throwing
and mutating getters, depth/node budgets, diagnostic paths, and ancestor cleanup. Canonical component
code is unchanged. This differs from earlier experiments that duplicated checks in generated projectors.

The small warmed string case improves modestly, but the larger fixture and streaming checks do not
establish a consistent benefit. Containers also gain another call boundary. The split remains
unadopted; successful inlining alone does not justify changing the runtime.

## Longer-warmup results

Small strings, 50,000 warmups and 25,000 measured renders per process. `candidate` is the object-layout
experiment; `split` is the independent validator experiment. Values are means of two reversed orders.

'''+table('long',['baseline','candidate','split','react'])+'''

Remaining validator checks, 50,000 warmups. Small streams measure 25,000 renders; large modes measure
5,000. These compare baseline and split only; React was not rerun in this confirmation matrix.

'''+table('confirm',['baseline','split'])+'''

Node large strings regress in both orders: 125.42 to 131.63 and 126.48 to 128.94 microseconds.
Node large streaming is especially variable: baseline is 247.99/287.37, while split is
254.68/248.93. Its favorable mean is not a repeatable per-order improvement. Bun large strings
also change direction between orders. These details matter more than attributing every small mean
difference to the change.

## Deoptimization and remaining leads

The initial short diagnostic includes wrong-map deoptimizations in eXact's component/render helpers,
but that does not establish persistent churn. A separate small-string trace uses 50,000 warmups
followed by 100,000 measured renders. Baseline eXact, the validator split, and React each have zero
deoptimization entries in the measured phase. Warmup has 15, 15, and 100 entries respectively;
these include lazy unwinding and are not counts of independent recurring defects. This result is
specific to the fixed fixture and does not rule out shape instability in heterogeneous applications.

Other bytecode observations worth retaining:

- `renderCompiledNativeAttribute` is 650 bytes and also receives explicit inlining refusals.
  A future experiment should first count its common attribute cases, then test a genuinely small
  common-case entry without imposing an extra call on the dominant fallback path.
- `serializeJson` creates three regular-expression literals and performs three escaping passes.
  This does not prove three surviving allocations in optimized code or that a custom serializer wins.
  Prior [fresh-graph serialization measurements](completed-html-profile-2026-09-10.md) remain relevant.
- Result construction performs several property-definition operations. Its own-accessor semantics and
  previous [construction experiments](result-construction-2026-09-10.md) rule out treating an apparently
  simpler object as automatically equivalent or faster.
- The benchmark application's script/stylesheet parsing allocates regexes and callbacks too. That is
  application work, not evidence that a framework-only change can remove it.

CPU profiles cover startup, warmup, and measured work. The evidence includes self-sample aggregation
by function and source location, but those percentages are prioritization clues, not isolated cost or
allocation measurements. No HTTP gain, browser gain, or universal React lead is claimed from this audit.
No package tests or browser acceptance run is claimed for a production change because neither candidate
was integrated. The existing full benchmark baseline remains authoritative for HTTP comparisons.

## Evidence

The adjacent evidence archive contains frozen eXact baseline/candidate bundles, the React entry,
fixture, runners, bytecode, object layouts, traces, CPU profiles, differential checks, raw timing
populations, and aggregate JSON. Raw timing files retain individual populations and output identities.
Runners are repository-root-relative diagnostics, not additions to the supported benchmark CLI.
'''
shutil.copyfile('framework-comparison/participants/react/dist-server/server-entry.js',root/'react-entry.mjs')
archive=target.with_name(target.stem+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,6) as z:
    for p in sorted(root.iterdir()):
        if p.is_file():z.write(p,p.name)
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
target.write_text(text+'\nArchive SHA-256: `'+digest+'`.\n',encoding='utf8')
print(target,archive.stat().st_size,digest)
