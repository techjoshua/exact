import {spawn} from 'node:child_process';
import {openSync,closeSync,readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
const dir=resolve('.tmp/v8-ssr'),rows=[];
for(let round=0;round<3;round++)for(const runtime of ['node','bun'])for(const fixture of ['flat','nested','deep'])for(const variant of round%2?['children','baseline']:['baseline','children']){
 const name=`child-${round}-${runtime}-${fixture}-${variant}`,fd=openSync(dir+'/'+name+'.log','w');
 try{await new Promise((yes,no)=>{const p=spawn(runtime==='node'?process.execPath:'C:/Program Files/Bun/bun.exe',[dir+'/child-worker.mjs',variant,fixture],{windowsHide:true,stdio:['ignore',fd,fd],env:{...process.env,NODE_ENV:'production',CHILD_RESULT:dir+'/'+name+'.json'}});p.once('error',no);p.once('exit',code=>code===0?yes():no(Error(name+' '+code)));});}finally{closeSync(fd);}
 const row={round,runtime,...JSON.parse(readFileSync(dir+'/'+name+'.json','utf8'))};rows.push(row);writeFileSync(dir+'/children-measurements.json',JSON.stringify(rows,null,2));console.log(name+' '+row.usPerCall.toFixed(3)+' us');
}
