from pathlib import Path
import collections,json,statistics,re
root=Path('.tmp/v8-ssr')
out={}
for phase in ['layout','split','long','confirm']:
    path=root/(phase+'-measurements.json')
    if not path.exists():continue
    data=json.loads(path.read_text());groups=collections.defaultdict(list)
    for row in data:groups[(row['runtime'],row['scenario'],row['mode'],row['variant'])].append(row['usPerRender'])
    summary=[dict(runtime=k[0],scenario=k[1],mode=k[2],variant=k[3],mean=round(statistics.mean(v),3),runs=v) for k,v in groups.items()]
    out[phase]=summary
    print(phase)
    for row in summary:print(row['runtime'],row['scenario'],row['mode'],row['variant'],row['mean'])
    hashes=collections.defaultdict(set)
    for row in data:
        if row['participant']=='exact':hashes[(row['mode'],row['scenario'])].add(row['hash'])
    assert all(len(h)==1 for h in hashes.values()), hashes
for name in ['exact-string','exact-stream','react-string','react-stream']:
    p=json.loads((root/(name+'.cpuprofile')).read_text());nodes={n['id']:n for n in p['nodes']};weights=collections.Counter()
    for node,dt in zip(p.get('samples',[]),p.get('timeDeltas',[])):
        f=nodes[node]['callFrame'];weights[(f['functionName'],f['url'],f['lineNumber']+1)]+=dt
    total=sum(weights.values())
    out[name+'-cpu']=[dict(function=k[0],file=k[1],line=k[2],ms=round(v/1000,3),percent=round(v/total*100,2)) for k,v in weights.most_common(25)]
for variant in ['baseline','split','react']:
    path=root/(variant+'-steady.log')
    if not path.exists():continue
    text=path.read_text(encoding='utf8');phase=text.split('PHASE measured start')
    if len(phase)!=2:continue
    out[variant+'-deopts']={'warmup':len(re.findall(r'\[bailout ',phase[0])),'measured':len(re.findall(r'\[bailout ',phase[1]))}
    print(variant+' deopts',out[variant+'-deopts'])
(root/'results-summary.json').write_text(json.dumps(out,indent=2))
