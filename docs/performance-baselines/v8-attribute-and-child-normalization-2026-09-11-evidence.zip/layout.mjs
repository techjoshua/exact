import {readFileSync,writeFileSync,openSync,closeSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const dir='.tmp/v8-ssr';
const original=readFileSync('framework-comparison/participants/exact/dist-server/server-entry.js','utf8');
const before='\t\t[PreparedServerRenderProgram]: true,\n\t\tprogram: branded,\n\t\teagerValues';
const after='\t\tprogram: branded,\n\t\teagerValues,\n\t\t[PreparedServerRenderProgram]: true';
if(original.split(before).length!==2)throw Error('Expected one factory');
for(const [name,source] of [['baseline',original],['candidate',original.replace(before,after)]]){
 writeFileSync(`${dir}/${name}.mjs`,source);
 writeFileSync(`${dir}/${name}-inspect.mjs`,source+'\nexport {createPreparedServerRenderProgram as inspectFactory};\n');
 writeFileSync(`${dir}/inspect-${name}.mjs`, `import {inspectFactory} from './${name}-inspect.mjs';\nconst program={}; const values=[];\nfor(let i=0;i<100;i++)inspectFactory(program,values);\nfor(const [label,args] of [['plain',[program,values]],['deferred',[program,values,undefined,{host:{},read:()=>[]}]],['enhanced',[program,values,{}]],['both',[program,values,{},{host:{},read:()=>[]}]]]){console.log(label);const value=inspectFactory(...args); %DebugPrint(value); console.log(Reflect.ownKeys(value).map(String));}\n`);
 const fd=openSync(`${dir}/${name}-layout.log`,'w');
 const result=spawnSync(process.execPath,['--allow-natives-syntax','--print-bytecode','--print-bytecode-filter=createPreparedServerRenderProgram',`${dir}/inspect-${name}.mjs`],{stdio:['ignore',fd,fd]});closeSync(fd);if(result.status!==0)throw Error(name+' failed');
}
