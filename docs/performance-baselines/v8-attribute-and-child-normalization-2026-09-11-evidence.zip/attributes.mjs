import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const dir='.tmp/v8-ssr',source=readFileSync(dir+'/baseline.mjs','utf8');
assert.equal(source,readFileSync('framework-comparison/participants/exact/dist-server/server-entry.js','utf8'));
const signature='function renderCompiledNativeAttribute(value, kind, name, attributeName, tag, context, accounted = false) {';
assert.equal(source.split(signature).length,2);
writeFileSync(dir+'/attribute-count.mjs',source.replace(signature, 'const attributeCounts = new Map();\nexport {attributeCounts};\n'+signature+'\nconst key=JSON.stringify([kind,typeof value,name,accounted]);attributeCounts.set(key,(attributeCounts.get(key)??0)+1);'));
const mod=await import('./attribute-count.mjs');
const data=JSON.parse(readFileSync(dir+'/data.json','utf8'));
const results=[];
for(const scenario of ['small','large']){
 if(scenario==='large')data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
 for(const mode of ['string','stream']){
  mod.attributeCounts.clear();const opts={clientTags:'<script type="module" src="/assets/app.js"></script><link rel="stylesheet" href="/assets/app.css">'};
  if(mode==='string')await mod.renderParticipant(data,'/incidents/inc-101',opts);else await new Response(await mod.renderParticipantStream(data,'/incidents/inc-101',opts)).text();
  results.push({scenario,mode,counts:[...mod.attributeCounts].sort((a,b)=>b[1]-a[1])});
 }
}
writeFileSync(dir+'/attribute-counts.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));
