import {readFileSync,writeFileSync,copyFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const dir='.tmp/v8-ssr';
for(const [kind,file] of [['node','dist-server/server-entry.js'],['bun','dist-bun-server/bun-server-entry.js']]){
 const current=readFileSync('framework-comparison/participants/exact/'+file,'utf8');
 const baseline=readFileSync(dir+(kind==='node'?'/baseline.mjs':'/baseline-bun.mjs'),'utf8');
 const cut=s=>{const start=s.indexOf('function normalizeChildren(children) {'),end=s.indexOf('/** Normalizes one component output',start);assert.ok(start>=0&&end>start);return s.slice(0,start)+s.slice(end);};
 assert.equal(cut(current),cut(baseline));
 writeFileSync(`${dir}/childrenCurrent${kind==='bun'?'-bun':''}.mjs`,current);
 writeFileSync(`${dir}/children-${kind}-artifact.json`,JSON.stringify({onlyNormalizerChanged:true,before:createHash('sha256').update(baseline).digest('hex'),after:createHash('sha256').update(current).digest('hex')},null,2));
}
const runner=readFileSync(dir+'/measure.mjs','utf8').replace('round<3','round<2').replace("['small','large']","['small']").replaceAll("'candidate'","'childrenCurrent'").replace('`${round}-${runtime}', '`current-${round}-${runtime}').replace("'12000':'3000'","'50000':'50000'").replace("'/layout-measurements.json'","'/current-measurements.json'");
writeFileSync(dir+'/measure-current.mjs',runner);
