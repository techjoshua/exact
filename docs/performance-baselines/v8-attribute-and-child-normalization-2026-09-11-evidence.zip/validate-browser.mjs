import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
const dir=resolve('.tmp/v8-ssr'),results=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream']){
 const name=`children-browser-${runtime}-${mode}`,fd=openSync(dir+'/'+name+'.log','w');
 try{await new Promise((yes,no)=>{const p=spawn(process.execPath,[resolve('node_modules/@playwright/test/cli.js'),'test','-c','playwright.config.ts','--grep','exact'],{cwd:resolve('framework-comparison'),windowsHide:true,stdio:['ignore',fd,fd],env:{...process.env,NODE_ENV:'production',COMPARISON_E2E_RUNTIME:runtime,COMPARISON_SSR_RENDER_MODE:mode}});p.once('error',no);p.once('exit',code=>{results.push({runtime,mode,code});writeFileSync(dir+'/children-browser.json',JSON.stringify(results,null,2));code===0?yes():no(Error(name+' failed '+code));});});}finally{closeSync(fd);}
 console.log(name+' passed');
}
