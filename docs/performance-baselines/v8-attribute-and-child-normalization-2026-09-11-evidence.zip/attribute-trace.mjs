import {spawnSync} from 'node:child_process';
import {openSync,closeSync,readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/v8-ssr';
for(const variant of ['baseline','attribute','attributeStrings']){
 const fd=openSync(`${dir}/${variant}-attribute-trace.log`,'w');
 const p=spawnSync(process.execPath,['--print-bytecode','--print-bytecode-filter=renderCompiledNativeAttribute','--trace-turbo-inlining',dir+'/worker.mjs','exact','string','large','1000',dir+'/'+variant+'.mjs'],{windowsHide:true,stdio:['ignore',fd,fd],env:{...process.env,NODE_ENV:'production',V8_AUDIT_WARMUPS:'5000'}});closeSync(fd);if(p.status!==0)throw Error(variant+' failed');
}
writeFileSync(dir+'/measure-attribute-streams.mjs',readFileSync(dir+'/measure-attribute-strings.mjs','utf8').replace("['string']","['stream']").replace('`attributeStrings-${round}','`attributeStream-${round}').replace("'/attributeStrings-measurements.json'","'/attributeStream-measurements.json'"));
