import {spawn} from 'node:child_process';
import {openSync,closeSync} from 'node:fs';
import {resolve} from 'node:path';
const dir=resolve('.tmp/v8-ssr');
for(const variant of ['baseline','split','react']){
 const fd=openSync(`${dir}/${variant}-steady.log`,'w');
 const args=['--trace-opt','--trace-deopt',...(variant==='split'?['--trace-turbo-inlining','--print-bytecode','--print-bytecode-filter=validatePositionalValue']:[]),dir+'/worker.mjs',variant==='react'?'react':'exact','string','small','100000'];
 if(variant!=='react')args.push(dir+'/'+variant+'.mjs');
 try{await new Promise((yes,no)=>{const child=spawn(process.execPath,args,{windowsHide:true,stdio:['ignore',fd,fd],env:{...process.env,NODE_ENV:'production',V8_AUDIT_WARMUPS:'50000'}});child.once('error',no);child.once('exit',code=>code===0?yes():no(Error(variant+' failed '+code)));});}finally{closeSync(fd);}
 console.log(variant+' trace complete');
}
