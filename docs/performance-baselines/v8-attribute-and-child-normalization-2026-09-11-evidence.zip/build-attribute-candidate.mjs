import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const dir='.tmp/v8-ssr';
const source=readFileSync(dir+'/baseline.mjs','utf8');
const needle='\tif (kind === 7) kind = 1;';
assert.equal(source.split(needle).length,2);
const candidate=source.replace(needle,'\treturn renderGeneralCompiledNativeAttribute(value, kind, name, attributeName, tag, context, accounted);\n}\nfunction renderGeneralCompiledNativeAttribute(value, kind, name, attributeName, tag, context, accounted) {\n'+needle);
writeFileSync(dir+'/attribute.mjs',candidate);
let runner=readFileSync(dir+'/measure-split.mjs','utf8')
 .replaceAll("'split'","'attribute'")
 .replace('`split-${round}', '`attribute-${round}')
 .replace("'12000':'3000'","'50000':'50000'")
 .replace("'/split-measurements.json'","'/attribute-measurements.json'");
writeFileSync(dir+'/measure-attribute.mjs',runner);
