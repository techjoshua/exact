import {inspectFactory} from './candidate-inspect.mjs';
const program={}; const values=[];
for(let i=0;i<100;i++)inspectFactory(program,values);
for(const [label,args] of [['plain',[program,values]],['deferred',[program,values,undefined,{host:{},read:()=>[]}]],['enhanced',[program,values,{}]],['both',[program,values,{},{host:{},read:()=>[]}]]]){console.log(label);const value=inspectFactory(...args); %DebugPrint(value); console.log(Reflect.ownKeys(value).map(String));}
