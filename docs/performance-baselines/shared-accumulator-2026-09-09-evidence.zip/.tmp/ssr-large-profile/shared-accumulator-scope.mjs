import {readFileSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const dir='.tmp/ssr-large-profile/',results=[];
for(const variant of ['shared-accumulator-direct','shared-accumulator-ranges']){
 let source=readFileSync(dir+variant+'.mjs','utf8');
 const before='const shared=context.experimentalSink;';
 if(source.split(before).length!==2)throw Error('Unexpected sink selection');
 source=source.replace(before,before+'\n if(shared)sinkAudit.shared++;else sinkAudit.captured++;');
 source+='\nexport const sinkAudit={shared:0,captured:0};\n';
 const entry=dir+variant+'-scope.mjs';writeFileSync(entry,source);
 const r=spawnSync('node',[dir+'sink-audit-worker.mjs',entry],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 const result={variant,...JSON.parse(r.stdout)};results.push(result);
 for(const row of result.rows.filter(r=>r.repeat===0))console.log(variant,row.scenario,row.mode,row.counts);
}
writeFileSync(dir+'shared-accumulator-scope.json',JSON.stringify(results,null,2));
