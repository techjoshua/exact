import hashlib,json,pathlib,zipfile
root=pathlib.Path('.');work=root/'.tmp/ssr-large-profile'
variants=['shared-accumulator','shared-accumulator-direct','shared-accumulator-ranges']
populations={v:json.loads((work/(v+'-results.json')).read_text(encoding='utf-8')) for v in variants}
summary=[]
for variant,rows in populations.items():
 assert len(rows)==32
 for runtime in ['node','bun']:
  for mode in ['string','stream']:
   for scenario in ['small','large']:
    changes=[]
    for round in range(2):
     group=[r for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['round']==round]
     a=next(r for r in group if r['variant']=='marker-hex-current');b=next(r for r in group if r['variant']==variant)
     assert a['hash']==b['hash'];changes.append((b['usPerRender']/a['usPerRender']-1)*100)
    summary.append(dict(variant=variant,runtime=runtime,mode=mode,scenario=scenario,changes=changes))
scopes=json.loads((work/'shared-accumulator-scope.json').read_text(encoding='utf-8'))
dest=root/'docs/performance-baselines/shared-accumulator-2026-09-09'
dest.with_suffix('.json').write_text(json.dumps(dict(summary=summary,populations=populations,scopes=scopes),indent=2)+'\n',encoding='utf-8')
table='\n'.join(f"| {s['variant'].removeprefix('shared-accumulator') or 'initial'} | {s['runtime']} | {s['mode']} | {s['scenario']} | {s['changes'][0]:+.2f}% | {s['changes'][1]:+.2f}% |" for s in summary)
scope_table='\n'.join(f"| {s['variant']} | {r['scenario']} | {r['mode']} | {r['counts']['shared']} | {r['counts']['captured']} |" for s in scopes for r in s['rows'] if r['repeat']==0)
doc='''# Shared accumulator traversal prototypes

Date: 2026-09-09. Experimental artifacts only; no production adoption.

## Hypothesis and implementation

The prior sink audit justified testing whether avoiding recursive subtree assembly reduces full
render time by 2-8%. Three frozen-bundle prototypes modify the existing program visitor and child
traversal to write completed spans into a request-local string accumulator. They retain compiler
program execution, task issuance, ownership, hydration publication, and the existing outer string
and streaming consumers. They do not create an independently compiled benchmark renderer.

1. Initial shared accumulator: program output writes into a request-local accumulator; generic
   operations and structural marker ranges are captured locally. The visitor initially allocates
   write and continuation closures per program.
2. Direct visitor: moves continuation logic to shared functions and restores the single-string
   program shortcut. Local capture policy remains identical.
3. Shared ranges: marker pairs write their opening before content and closing afterward. Plain
   fragments, direct child ranges, and keyed ranges can retain shared accumulation. Generic operations
   and enhanced fragments still use local capture.

The initial development draft misplaced range opening markers after content. A full-output diff
identified this before timing. The first timed version restored local capture; the third version
implements ordered marker writes. All timed variants match their controls byte for byte.

These prototypes are incomplete architectural experiments. They reject uncaptured enhancement routes
and component publication boundaries that cannot yet be emitted incrementally. They retain generated
segment arrays, expose no public sink API, and finish the accumulator before existing stream consumers
publish it. They do not implement early head delivery, backpressured traversal, or compiler task-span
dependencies. They must not be presented as production implementations of the requested model.

## Method

Each variant is independently compared with marker-hex-current in 32 fresh production-mode processes:
Node/Bun, string/consumed stream, small/large documents, two reversed-order pairs per cell. Total:
96 populations. Each uses 5,000 warmups and 12,000 measured renders. Small has three incidents; large
has 96. Both include two module scripts and two stylesheet links in application-owned documents.
Both runtimes use the same Node-target artifact. Streams are consumed with Response.text(). Every
population completed and every paired full-document hash matched; no observations were discarded.

Positive means longer rendering time. Compare each variant only with its own paired control, not
absolute timings across batches. These local pairs are not confidence intervals or HTTP/browser
measurements. React was not rerun because no candidate advanced to adoption.

| Variant | Runtime | Output | Fixture | Pair 1 time change | Pair 2 time change |
| --- | --- | --- | --- | ---: | ---: |
'''+table+'''

No variant establishes a broad win. The initial version is mostly slower. Removing completed-work
callbacks improves the implementation but does not yield consistent gains across target workloads.
The range-writing variant also fails to establish a general gain. None is adopted. This rejects
these implementations, not compiler-guided incremental writing as an architectural direction.

## Scope diagnostic

Separate untimed Node runs count program invocations using the shared accumulator versus local
capture. Each fixture/mode is repeated three times. This establishes how much of the actual tree
the prototype reaches, rather than assuming that changing the root changes every descendant.

| Variant | Fixture | Output | Shared programs | Captured programs |
| --- | --- | --- | ---: | ---: |
'''+scope_table+'''

## Compiler dependency finding and next work

The user correctly identified that tasks need not delay unaffected shell content. Existing
continuation contracts carry stateReads, stateWrites (with exact/broad/unknown confidence),
contextWrites, serverContextWrites, and dependency paths. The compiler's render-program update
lowering also analyzes dependencies of text, component, structural, and attribute expressions.
These are useful inputs, not an already implemented SSR prefix-commit protocol.

Current server lowering prepares eager values before emitting a program. Scheduled components and
full-document stream settlement operate at broader boundaries. The missing connection is to map
transitive task effects onto ordered SSR spans, including structural and attribute dependencies,
and defer reads of affected spans until the required task generation settles. A prefix using settled
props can be safe even when it is not literal HTML. A head attribute or context affected by the task
must remain behind the dependency boundary; unknown effects cannot be treated as independence.

The intended traversal is: emit the compiler-proven unaffected prefix, flush after the completed
head or before required suspension, await only relevant unfinished work, emit affected content,
then publish hydration and final closing tags. Task execution and lifetime ownership remain with
the existing task machinery. This is still one shared renderer with different sinks.

Further experiments should implement that compiler/runtime connection and genuinely batched sink
writes, rather than interpreting these whole-result accumulator measurements as an early-flush test.
No new package/browser suite was run for rejected incomplete prototypes. Output equality protects
the measured fixtures only, not unsupported boundary and lifecycle behavior. Current production
remains marker-hex-current with all retained improvements. Overall React parity remains unmet.
'''
dest.with_suffix('.md').write_text(doc,encoding='utf-8')
files=[work/'marker-hex-current.mjs',work/'direct-map-worker.mjs',work/'sink-audit-worker.mjs',work/'shared-accumulator-report.py',work/'shared-accumulator-diff.mjs',work/'shared-accumulator-scope.mjs',work/'shared-accumulator-scope.json',root/'.tmp/positional-leaves/data.json',dest.with_suffix('.md'),dest.with_suffix('.json')]
for v in variants:files += [work/(v+suffix) for suffix in ['.mjs','-build.mjs','-run.mjs','-results.json']]
files += [work/(v+'-scope.mjs') for v in variants[1:]]
files += [root/p for p in ['packages/core/src/component-contracts.ts','native/typescript-go/overlay/internal/exactcompiler/continuations.go','native/typescript-go/overlay/internal/exactcompiler/jsx_render_program_updates.go','native/typescript-go/overlay/internal/exactcompiler/jsx_render_program_ssr_lowering.go']]
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps({p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(table);print(scope_table);print('Verified',archive)
