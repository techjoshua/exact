import {readFileSync,writeFileSync} from 'node:fs';
const data=JSON.parse(readFileSync('.tmp/positional-leaves/data.json','utf8'));
const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
const outputs=[];
for(const variant of ['marker-hex-current','shared-accumulator']){
 const mod=await import('./'+variant+'.mjs');
 const html=await mod.renderParticipant(data,'/incidents/inc-101',options);
 writeFileSync('.tmp/ssr-large-profile/'+variant+'-sink.html',html);
 outputs.push(html);
}
let index=0;while(outputs[0][index]===outputs[1][index]&&index<outputs[0].length)index++;
console.log({index,before:outputs[0].slice(Math.max(0,index-60),index+180),after:outputs[1].slice(Math.max(0,index-60),index+180)});
