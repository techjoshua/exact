import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
let source=readFileSync(dir+'shared-accumulator.mjs','utf8');
const start=source.indexOf('function renderProgramOutput(context,segments,render,host){');
const end=source.indexOf('//#endregion',start);
if(start<0||end<0)throw Error('Missing prototype visitor');
source=source.slice(0,start)+`function renderProgramOutput(context,segments,render,host){
 const shared=context.experimentalSink;
 if(shared&&context.enhancementOperationRoutes?.length)throw Error('Prototype requires enhancement capture');
 const sink=shared??{value:''};
 if(host&&(host==='html'||host==='head'||host==='body'||context.documentRootSeen&&context.hostStack.at(-1)==='html')){
  const entered=enterHostTag(context,host);
  if(entered.prefix)appendSharedSink(context,sink,entered.prefix);
  return withRenderCleanup(()=>visitSharedSegments(context,segments,render,0,sink,!!shared),()=>leaveHost(context,entered.tag));
 }
 if(host&&!context.hostStack.length)claimRootText(context);
 if(segments.length===1&&typeof segments[0]==='string'&&!context.enhancementOperationRoutes?.length){
  if(shared){appendSharedSink(context,sink,segments[0]);return '';}
  assertOutputCharacterBound(context,segments[0]);return segments[0];
 }
 return visitSharedSegments(context,segments,render,0,sink,!!shared);
}
function appendSharedSink(context,sink,text){
 sink.value=appendBoundedHtml(context,captureNestedEnhancementStringPrefix(context,sink.value),text);
}
function visitSharedSegments(context,segments,render,start,sink,shared){
 for(let index=start;index<segments.length;index++){
  const segment=segments[index];
  const value=typeof segment==='string'?segment:render(segment);
  if(value instanceof Promise)return value.then(html=>{appendSharedSink(context,sink,html);return visitSharedSegments(context,segments,render,index+1,sink,shared);});
  if(value!=='')appendSharedSink(context,sink,value);
 }
 return shared?'':sink.value;
}
`+source.slice(end);
writeFileSync(dir+'shared-accumulator-direct.mjs',source);
writeFileSync(dir+'shared-accumulator-direct-run.mjs',readFileSync(dir+'map-fragment-run.mjs','utf8').replaceAll('map-fragment','shared-accumulator-direct'));
