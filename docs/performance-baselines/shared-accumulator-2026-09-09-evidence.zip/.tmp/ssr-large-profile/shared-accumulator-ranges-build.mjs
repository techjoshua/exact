import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
let source=readFileSync(dir+'shared-accumulator-direct.mjs','utf8');
function replace(before,after){if(source.split(before).length!==2)throw Error('Unexpected site: '+before);source=source.replace(before,after);}
replace('function captureStructuralOutput(context,work){','function captureStructuralOutput(context,work){\n if(context.experimentalSink)return work();');
replace('function captureGenericOperation(context,child,target){','function captureGenericOperation(context,child,target){\n const fragment=readCompiledFragmentReceipt(child);\n if(context.experimentalSink&&fragment&&!fragment.enhancement)return executeOpaqueOperation(child,target);');
replace('function markerPair(context, id, render) {','function markerPair(context, id, render) {\n if(context.experimentalSink)return writeSharedMarkerPair(context,id,render);');
source+=`
function writeSharedMarkerPair(context,id,render){
 if(!context.markers)return render();
 const sink=context.experimentalSink;
 const itemKey=id.startsWith('item:')?id.slice(5):undefined;
 const opening=itemKey===undefined?(id?'<!--exact:'+id+'-->':'<!--x-->'):'<!--i:'+itemKey+'-->';
 const closing=itemKey===undefined?(id?'<!--/exact:'+id+'-->':'<!--/x-->'):'<!--/i:'+itemKey+'-->';
 context.outputSink?.accountKnown(opening,opening.length);
 appendSharedSink(context,sink,opening);
 const rendered=render();
 if(rendered instanceof Promise)return rendered.then(html=>finishSharedMarker(context,sink,html,closing));
 return finishSharedMarker(context,sink,rendered,closing);
}
function finishSharedMarker(context,sink,html,closing){
 if(html!=='')appendSharedSink(context,sink,html);
 context.outputSink?.accountKnown(closing,closing.length);
 appendSharedSink(context,sink,closing);
 return '';
}
`;
writeFileSync(dir+'shared-accumulator-ranges.mjs',source);
writeFileSync(dir+'shared-accumulator-ranges-run.mjs',readFileSync(dir+'map-fragment-run.mjs','utf8').replaceAll('map-fragment','shared-accumulator-ranges'));
