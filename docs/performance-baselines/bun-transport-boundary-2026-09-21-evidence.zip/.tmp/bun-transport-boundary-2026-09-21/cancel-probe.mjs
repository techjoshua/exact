import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
const rows=[];
for(const direct of [false,true])for(const viaResponse of [false,true]){
 let cancelCalls=0,finishCalls=0,release;
 const blocked=new Promise(resolve=>{release=resolve});
 const source={
  ...(direct?{type:'direct'}:{}),
  async pull(controller){
   try{
    if(direct){controller.write('first');controller.flush();}
    else controller.enqueue(new TextEncoder().encode('first'));
    await blocked;
   }finally{finishCalls++;}
  },
  cancel(){cancelCalls++;release();}
 };
 const stream=new ReadableStream(source,{highWaterMark:0});
 const body=viaResponse?new Response(stream).body:stream;
 const reader=body.getReader();
 const first=await reader.read();
 assert.equal(new TextDecoder().decode(first.value),'first');
 await reader.cancel('probe cancellation');
 await new Promise(resolve=>setTimeout(resolve,20));
 rows.push({direct,viaResponse,cancelCalls,finishCalls});
 if(!direct){assert.equal(cancelCalls,1);assert.equal(finishCalls,1);}
 release();
 await blocked;
 reader.releaseLock();
}
const result={bun:Bun.version,rows};
await writeFile('.tmp/bun-transport-boundary-2026-09-21/cancel-probe.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result));
