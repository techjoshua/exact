from pathlib import Path
import json,datetime,hashlib,zipfile
root=Path('.tmp/ssr-followup')
prefix=Path('docs/performance-baselines/ssr-followup-2026-09-12')
load=lambda name:json.loads((root/(name+'.json')).read_text())
bursts=load('bursts');bun=load('bun');connections=load('connections');controls=load('connections-controls');idle=load('bursts-idle')
for capture in [bursts,bun,connections,controls,idle]:assert capture['complete']
lines=['# SSR tails, adaptive admission, and connection handling, September 12, 2026','',
'This focused investigation follows the [production checkpoint capture](ssr-production-checkpoint-2026-09-12.md).',
'It does not replace the full comparison charts. Production renderer and adapter artifacts are unchanged.',
'All controls ran sequentially on the same shared Windows PC, using Node 26.8.1 and native Bun 1.4.2.',
'Load drivers use Node. Instrumentation and control overrides live in isolated diagnostic copies.',
'Response bodies remain fully consumed and validated; no errors are retried or dropped.','',
'## Node finite-burst tails','',
'Two hundred 16-request bursts per participant and loading mode alternate eXact and React order,',
'with a 20 ms gap after each pair. Twenty warmup bursts precede each lane. Two fresh populations',
'reverse HTTP-client variant order. This deliberately tests intermittent bursts, separately from',
'sustained capacity and from the five-framework public capture. Each normal request still fetches',
'both controlled-service endpoints. The HTTP control collects the same bytes using node:http;',
'it is a diagnostic client substitution, not a framework renderer optimization.','',
'| Data client | Loading | Framework | Burst mean, two populations (ms) | Burst p99, two populations (ms) |',
'| --- | --- | --- | ---: | ---: |']
for mode in ['fetch','close','http']:
 for loading in ['normal','preloaded']:
  for id in ['exact','react']:
   rows=[r for r in bursts['rows'] if r['fetchMode']==mode and r['loading']==loading and r['id']==id]
   lines.append('| '+' | '.join([mode,loading,id,' / '.join(f"{r['burst']['mean']:.2f}" for r in rows),' / '.join(f"{r['burst']['p99']:.2f}" for r in rows)])+' |')
lines+=['','Native fetch reproduces the long tail for both frameworks. Preloading removes most of it,',
'and the node:http data client substantially reduces it while retaining real service requests.',
'Closing every fetch connection raises average latency and is rejected as a remedy.','',
'## Bun streaming at concurrency 16','',
'Each fresh worker runs a six-second warmup at total concurrency 16, then twelve-second stages',
'at total concurrency 16 and 32 with two independent load drivers. Framework/policy order reverses',
'in the second population. Automatic policy uses the shipping gate. Forced-on/off controls',
'override admission decisions at both host and inherited render checkpoints, while retaining',
'the observer. The traced controller uses its own two-millisecond interval sampler; the external',
'worker histogram is a different observer and cannot establish gate activation.','',
'| Framework | Policy | Concurrency | Valid RPS, two populations | Largest driver p99, two populations (ms) |',
'| --- | --- | ---: | ---: | ---: |']
for id,policy in [('exact','auto'),('exact','off'),('exact','on'),('react','auto')]:
 rows=[r for r in bun['rows'] if r['config']==dict(id=id,policy=policy)]
 for index,c in [(1,16),(2,32)]:
  rates=[sum(x['stages'][index]['validRps'] for x in r['results']) for r in rows]
  tails=[max(x['stages'][index]['distributions']['responseMs']['p99'] for x in r['results']) for r in rows]
  lines.append('| '+' | '.join([id,policy,str(c),' / '.join(f'{x:,.0f}' for x in rates),' / '.join(f'{x:.2f}' for x in tails)])+' |')
lines+=['','The automatic gate was enabled at 31 of 48 sampling points in each concurrency-16 stage.',
'At concurrency 32 it was enabled at 43 / 44 of 48 points. These are sampled states, not the',
'fraction of individual requests queued. It does activate below concurrency 32 and retains',
'successful trials. Forced scheduling improves throughput modestly but does not remove the',
'concurrency-16 gap to React. Lowering the lag threshold is not justified by these measurements;',
'no production scheduler thresholds or retention rules were changed. All Bun control stages',
'completed without request errors or invalid responses.','',
'## Connection failures and controls','',
'Each server receives two independent drivers, a ten-second concurrency-32 warmup, and twenty-second',
'8,000- and 10,000-RPS offered-load stages. Each variant has two fresh populations with reversed',
'variant order. The minimal Node control returns a fixed 3,964-byte response without framework',
'rendering. It tests transport capacity, not equivalent application work.','',
'| Server | Control | Offered RPS | Valid RPS, two populations | Errors, two populations |',
'| --- | --- | ---: | ---: | ---: |']
variants=[(connections,0,'exact string, automatic'),(connections,1,'React streaming'),(connections,2,'fixed-response Node'),(controls,0,'React streaming, backlog 4096'),(controls,1,'React streaming, pool prepared before warmup'),(controls,2,'exact string, finite agent timeout')]
for dataset,index,label in variants:
 config=dataset['rows'][index]['config']
 rows=sorted([r for r in dataset['rows'] if r['config']==config],key=lambda r:r['population'])
 for i,rate in [(1,8000),(2,10000)]:
  rates=[sum(x['stages'][i]['validRps'] for x in r['results']) for r in rows]
  errs=[sum(x['stages'][i]['errors'] for x in r['results']) for r in rows]
  serverLabel='React streaming' if config['id']=='react' else 'fixed-response Node' if config.get('minimal') else 'eXact string'
  controlLabel='backlog 4096' if config.get('backlog') else 'prepared before warmup' if config.get('prewarm') else 'finite agent timeout' if config.get('agentTimeout') else 'no rendering' if config.get('minimal') else 'original connection policy'
  lines.append('| '+ ' | '.join([serverLabel,controlLabel,f'{rate:,}',' / '.join(f'{x:,.0f}' for x in rates),' / '.join(str(x) for x in errs)])+' |')

for name,label in [('connections-late','pool prepared immediately before demand'),('connections-gradual','pool prepared in steps of 16 immediately before demand')]:
 dataset=load(name);assert dataset['complete']
 rows=sorted(dataset['rows'],key=lambda r:r['population'])
 for i,rate in [(1,8000),(2,10000)]:
  rates=[sum(x['stages'][i]['validRps'] for x in r['results']) for r in rows]
  errs=[sum(x['stages'][i]['errors'] for x in r['results']) for r in rows]
  lines.append('| React streaming | '+label+' | '+f'{rate:,}'+' | '+' / '.join(f'{x:,.0f}' for x in rates)+' | '+' / '.join(str(x) for x in errs)+' |')
lines+=['','Connection preparation errors are retained separately from the timed stages:','',
'| Preparation | Errors, two populations |','| --- | ---: |']
for name,setting,label in [('connections-controls',True,'Before ten-second warmup'),('connections-late','late','Immediately before demand, doubling steps'),('connections-gradual','gradual','Immediately before demand, steps of 16')]:
 rows=[r for r in load(name)['rows'] if r['config'].get('prewarm')==setting]
 counts=[sum(len(x['errors']) for d in r['results'] for x in d['connectionPreparation']) for r in rows]
 lines.append('| '+label+' | '+' / '.join(str(x) for x in counts)+' |')
lines+=['','The reproduced React refusals cluster in the first second of the 8,000-RPS stage, while',
'fresh connections expand toward 512 total in flight. The workers remain alive, with no handler',
'or recorded server socket errors. Increasing the listen backlog to 4096 does not eliminate',
'refusals. Preparing a pool before the ten-second low-concurrency warmup is ineffective because',
'idle sockets expire during that warmup. Preparation immediately before offered load removes',
'measured-stage failures, but doubling the preparation concurrency still produces 24 setup',
'failures in one population. Those failures are retained rather than relabeled as successful load.',
'Growing the pool in steps of 16 per driver produces zero setup and measured errors in both',
'populations. Throughput remains about 3,900 RPS: preparing connections does not remove the',
'render/response capacity limit or the missed arrivals above that limit.','',
'These results identify a connection-growth/overload interaction in the tested Node hosting path.',
'They do not identify an incorrect React render or establish that every historical refusal had',
'the same cause. The fixed-response Node control has no errors at either offered rate. Its much',
'cheaper handler does not reproduce the saturated rendering workload.','',
'### Idle socket retirement correction','',
'The original Node load agents have no finite timeout. In Node 26.8.1 and the installed Node 24.11.1,',
'the agent starts from an idle timeout of zero and only lowers a finite value to the server hint.',
'An isolated server advertising two seconds leaves the original agent socket at timeout zero;',
'with a ten-second agent bound, Node assigns a one-second idle timeout and retires that socket',
'before the next request at 1.3 seconds. The one-second margin comes from the agent keep-alive buffer.',
'The [Node HTTP documentation](https://nodejs.org/api/http.html#requestreusedsocket) describes',
'reused-socket reset races. The built-in agent source and isolated probe are retained in the archive.','',
'The retained harness correction sets the sustained agent timeout to its request deadline and',
'uses ten seconds for the burst agent. Existing request deadlines and first-attempt error accounting',
'remain intact. The new sparse-demand regression failed before this change. A second regression',
'checks that the burst client retires a socket using the advertised server hint.','',
'Fresh eXact default and finite-timeout controls both have zero errors. Server-side idle expirations',
'drop to zero in the finite-timeout controls because clients retire idle sockets first. This proves',
'bounded lifetime management, not that the historical eXact or React ECONNRESET failures are solved.',
'The original eXact connection failures did not reproduce in these repeats.','',
'## Attribution limits and follow-up diagnostics','',
'The timer trace is intrusive: obtaining call stacks changes timing. It observes the native',
'Undici idle-validation path but does not reproduce the approximately 20 ms uninstrumented burst',
'p99 in that run. It must not be used to assign the entire burst tail to one timer. The earlier',
'[upstream scheduling change](https://github.com/nodejs/undici/pull/5606) and the existing sequential',
'probe establish a timer-related risk; the paired HTTP-client controls establish the broader',
'data-fetch path as the main target for the burst investigation. No global fetch or timer patch',
'was installed in production. A separate Node 24.11.1 run is diagnostic evidence, not a recommendation',
'to pin that historical runtime release. The final untraced Node 26 repeat restores the roughly',
'21 ms eXact tail, so the lower traced value is not accepted as a performance improvement.','',
'| Additional burst probe | Framework | Normal burst p99 (ms) |',
'| --- | --- | ---: |']
for name,label in [('bursts-idle','Node 26, timer tracing'),('bursts-node24','Node 24.11.1'),('bursts-repeat','Node 26, untraced repeat')]:
 for r in load(name)['rows']:
  if r['loading']=='normal':lines.append('| '+label+' | '+r['id']+' | '+f"{r['burst']['p99']:.2f}"+' |')
lines+=['','## Measurement policy','',
'For steady-state offered-load capacity, prepare the intended connection population immediately',
'before demand with gradual concurrency growth, and report every setup failure separately.',
'Keep abrupt connection-growth stages as a distinct transport-overload diagnostic. Changing',
'connection preparation changes the workload; it must not silently replace earlier populations.',
'The previous full baseline, its errors, and its browser measurements remain unchanged.','']
lines[4] = 'Main controls ran sequentially on the same shared Windows PC, using Node 26.8.1 and native Bun 1.4.2.'
lines += ['## Validation and retained evidence', '',
'The comparison suite passed all 90 tests, including two new idle-socket regressions. The client',
'tests also passed on Node 24 (16 tests). Build-script tests (112), docs tests (10), changed-file',
'lint, and the docs typecheck and build passed. Desktop and mobile browser checks each verified',
'17 distribution tables and five heap rows, with no page errors or horizontal overflow.', '',
'Post-capture checks verified every measured burst response against one stable body identity per',
'framework, all load-stage accounting, zero invalid load responses, and successful worker telemetry.',
'Hashes confirm that 19 renderer, adapter, and participant source files match the original capture.',
'The additional timer, Node 24, and untraced repeat probes use the corrected burst client; the',
'untraced repeat still reproduces the long tail after that pooling correction.', '',
'The [structured results](ssr-followup-2026-09-12.json) retain stage results, preparation errors,',
'validation outcomes, and source hashes. The [evidence archive](ssr-followup-2026-09-12-evidence.zip)',
'contains complete raw captures, diagnostic scripts, client sources, logs, and browser screenshots.', '']
Path(str(prefix)+'.md').write_text('\n'.join(lines)+'\n')
