import http from 'node:http';
import { performance } from 'node:perf_hooks';
import { BunRequestGate } from '../../framework-adapters/bun-adapter/dist/adaptive-gate.js';
import { AdaptiveRequestGate } from '../../framework-adapters/node-adapter/dist/requests/adaptive-gate.js';

const policy = process.env.PROBE_POLICY ?? 'auto';
const traces = [], sockets = [], decisions = { yes: 0, no: 0 };
const counts = { connections: 0, closed: 0, timeouts: 0, requests: 0, errors: 0 };
const idleTimers=[];
if(process.env.PROBE_IDLE_TRACE==='1') {
 const timeout=globalThis.setTimeout;
 globalThis.setTimeout=function(callback,delay,...args){
  if(delay!==0 || !new Error().stack.includes('scheduleIdleSocketValidation')) return timeout(callback,delay,...args);
  const start=performance.now();
  return timeout(function(...values){if(idleTimers.length<50000)idleTimers.push({at:Date.now(),wait:performance.now()-start});return callback.apply(this,values);},delay,...args);
 };
}
for (const Gate of [BunRequestGate, AdaptiveRequestGate]) {
 const sample = Gate.prototype.sample;
 Gate.prototype.sample = function () {
  const before = { at: Date.now(), phase: this.phase, enabled: this.enabled,
   lag: this.delay?.percentile(95)/1e6, highSamples: this.highSamples,
   cooldown: this.cooldown-performance.now(), elapsed:performance.now()-this.started,
   count:this.completions ?? this.arrivals-this.windowArrivals+this.windowPending-this.pendingRequests() };
  sample.call(this);
  if(traces.length<4000) traces.push({...before, nextPhase:this.phase, nextEnabled:this.enabled,
   baseline:this.baseline,trial:this.trial,controlRate:this.controlRate,controlLag:this.controlLag});
 };
 const schedule=Gate.prototype.shouldSchedule;
 Gate.prototype.shouldSchedule=function(){
  const enabled=policy==='on'?true:policy==='off'?false:schedule.call(this);
  decisions[enabled?'yes':'no']++;return enabled;
 };
}

if (!globalThis.Bun) {
 const listen=http.Server.prototype.listen;
 http.Server.prototype.listen=function(...args){
  if(process.env.PROBE_KEEPALIVE) this.keepAliveTimeout=Number(process.env.PROBE_KEEPALIVE);
  if(process.env.PROBE_BACKLOG && typeof args[0]==='number') args.splice(2,0,Number(process.env.PROBE_BACKLOG));
  return listen.apply(this,args);
 };
 const emit=http.Server.prototype.emit;
 http.Server.prototype.emit=function(event,...args){
  if(event==='connection') {
   const socket=args[0];counts.connections++;
   const row={at:Date.now(),localPort:socket.localPort,remotePort:socket.remotePort,requests:0};
   socket.probeRow=row;
   socket.once('timeout',()=>{row.timeoutAt=Date.now();counts.timeouts++;});
   socket.once('error',error=>{row.error=error.code;counts.errors++;});
   socket.once('close',hadError=>{row.closedAt=Date.now();row.hadError=hadError;counts.closed++;if(sockets.length<3000)sockets.push(row);});
  }else if(event==='request') {counts.requests++;if(args[0].socket.probeRow){args[0].socket.probeRow.requests++;args[0].socket.probeRow.lastRequestAt=Date.now();}}
  return emit.call(this,event,...args);
 };
}
const agent=new http.Agent({keepAlive:true,maxSockets:128,maxFreeSockets:128,scheduling:'lifo'});
export async function probeFetch(url){
 const mode=process.env.PROBE_FETCH ?? 'fetch';
 if(mode==='fetch')return fetch(url);
 if(mode==='close')return fetch(url,{headers:{connection:'close'}});
 return new Promise((resolve,reject)=>{
  const req=http.get(url,{agent},res=>{const parts=[];res.on('data',b=>parts.push(b));res.on('error',reject);res.on('end',()=>resolve({ok:res.statusCode===200,status:res.statusCode,json:async()=>JSON.parse(Buffer.concat(parts).toString())}));});
  req.on('error',reject);req.setTimeout(10000,()=>req.destroy(new Error('data timeout')));
 });
}
export function probeSnapshot(){return {node:process.version,undici:process.versions.undici,policy,decisions,counts,traces,sockets,idleTimers};}
