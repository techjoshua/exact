import {resolve} from 'node:path';
import {writeFile} from 'node:fs/promises';
import {setTimeout as pause} from 'node:timers/promises';
import {startSsrLoadProcess} from './load-owner.mjs';
import {startSsrWorker,stopSsrWorker,controlSsrWorker} from '../../framework-comparison/src/ssr-worker-controller.mjs';
import {availableSsrRuntimes} from '../../framework-comparison/src/ssr-run-environment.mjs';
import {runSsrBurst,resetSsrClientConnections} from '../../framework-comparison/src/ssr-benchmark-client.mjs';
import {summarizeSsrSamples,summarizeWorkerRequests} from '../../framework-comparison/src/ssr-benchmark-statistics.mjs';
import {installDevelopmentProcessLifecycle} from '../../scripts/development-process-lifecycle.mjs';
const root='.tmp/ssr-followup',rows=[];const diagnostic=process.env.PROBE_REPEAT==='1'||process.env.PROBE_IDLE_TRACE==='1'||process.env.PROBE_RUNTIME24==='1';const output=process.env.PROBE_REPEAT==='1'?'bursts-repeat':process.env.PROBE_RUNTIME24==='1'?'bursts-node24':process.env.PROBE_IDLE_TRACE==='1'?'bursts-idle':'bursts';let service,workers=[];
async function close(){for(const w of workers.splice(0))await stopSsrWorker(w);if(service){await service.close();service=undefined;}resetSsrClientConnections();}
const lifecycle=installDevelopmentProcessLifecycle({label:'SSR burst investigation',close});
try{
 for(let population=0;population<(diagnostic?1:2);population++)for(const fetchMode of diagnostic?['fetch']:population?['http','close','fetch']:['fetch','close','http']){
  service=await startSsrLoadProcess('service');
  for(const id of ['exact','react'])workers.push(await startSsrWorker({runtime:process.env.PROBE_RUNTIME24==='1'?{...availableSsrRuntimes('node')[0],command:'C:/Program Files/nodejs/node.exe'}:availableSsrRuntimes('node')[0],participantId:id,transport:'node-http',workerPath:resolve(root+'/worker.mjs'),workingDirectory:resolve('framework-comparison'),serviceUrl:service.url,environment:{PROBE_FETCH:fetchMode,COMPARISON_SSR_RENDER_MODE:'string'}}));
  for(const loading of ['normal','preloaded']){
   const urls=workers.map(w=>w.url+(loading==='preloaded'?'?__benchmarkPreloaded=true':'?__benchmarkServicePhases=true'));
   for(let i=0;i<20;i++)for(let j=0;j<workers.length;j++)await runSsrBurst(urls[j],16,16);
   for(const w of workers)await controlSsrWorker(w,'reset');
   const samples=workers.map(()=>[]);
   for(let i=0;i<200;i++){
    for(const j of (i+population)%2?[1,0]:[0,1]) samples[j].push(await runSsrBurst(urls[j],16,16));
    await pause(20);
   }
   for(let j=0;j<workers.length;j++){
    const telemetry=await controlSsrWorker(workers[j],'telemetry');
    const row={population,fetchMode,loading,id:workers[j].participantId,burst:summarizeSsrSamples(samples[j].map(x=>x.elapsedMs)),samples:samples[j],telemetry};rows.push(row);
    console.log(JSON.stringify({population,fetchMode,loading,id:row.id,burst:row.burst}));
   }
   await writeFile(root+'/'+output+'.json',JSON.stringify({complete:false,rows}));
  }
  await close();
 }
 await writeFile(root+'/'+output+'.json',JSON.stringify({complete:true,rows}));
}finally{await close();lifecycle.dispose();}
