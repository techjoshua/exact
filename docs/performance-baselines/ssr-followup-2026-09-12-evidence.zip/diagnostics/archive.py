import hashlib
import json
from pathlib import Path
import zipfile

root = Path.cwd()
work = root / '.tmp/ssr-followup'
prefix = root / 'docs/performance-baselines/ssr-followup-2026-09-12'
def read(path):
    return json.loads(path.read_text())
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

names = ['bursts', 'bursts-idle', 'bursts-node24', 'bursts-repeat', 'bun', 'connections', 'connections-controls', 'connections-late', 'connections-gradual']
summary = {'kind': 'ssr-followup-v1', 'date': '2026-09-12', 'captures': {}, 'validation': read(work / 'checks.json'), 'browser': read(work / 'docs-verification.json')}
identities = {}
for name in names:
    path = work / (name + '.json')
    data = read(path)
    assert data['complete'], name
    rows = []
    for row in data['rows']:
        if name.startswith('bursts'):
            assert len(row['samples']) == 200
            for burst in row['samples']:
                assert len(burst['samples']) == 16
                for sample in burst['samples']:
                    assert sample['meaningful'] and sample['bytes'] > 0
                    identities.setdefault(row['id'], set()).add((sample['hash'], sample['bytes']))
            rows.append({k:v for k,v in row.items() if k not in ('samples', 'telemetry')})
        else:
            results = []
            assert not row['telemetryErrors'] and not row['stderr']
            for result in row['results']:
                assert result['complete']
                stages = []
                for stage in result['stages']:
                    assert stage['invalid'] == 0
                    assert stage['started'] == stage['completed']
                    assert stage['completed'] == stage['valid'] + stage['invalid'] + stage['errors']
                    if stage['mode'] == 'arrival':
                        assert stage['offered'] == stage['started'] + stage['missedLag'] + stage['missedCapacity'] + stage['missedDeadline']
                    stages.append({k:v for k,v in stage.items() if k != 'intervals'})
                results.append({'plan': result['plan'], 'identity': result['identity'], 'connectionPreparation': result.get('connectionPreparation', []), 'stages': stages})
            rows.append({'population': row['population'], 'config': row['config'], 'results': results})
    summary['captures'][name] = {'sha256': digest(path), 'rows': rows}
assert all(len(v) == 1 for v in identities.values()), identities
summary['burstIdentities'] = {k: list(v) for k,v in identities.items()}
assert all(check['code'] == 0 for check in summary['validation'])
old = read(root / '.tmp/ssr-production-checkpoint/source-state.json')
unchanged = {}
for name, expected in old['files'].items():
    if '/src/' in name and not name.startswith('apps/docs'):
        actual = digest(root / name)
        assert actual == expected, name
        unchanged[name] = actual
summary['unchangedBaselineSources'] = unchanged
sources = ['framework-comparison/src/ssr-load-driver.mjs', 'framework-comparison/src/ssr-benchmark-client.mjs', 'framework-comparison/test/ssr-load.test.mjs', 'framework-comparison/test/ssr-benchmark-client.test.mjs']
summary['correctedClientSources'] = {name: digest(root / name) for name in sources}
Path(str(prefix) + '.json').write_text(json.dumps(summary, indent=2) + '\n')
with zipfile.ZipFile(str(prefix) + '-evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(work.iterdir()):
        if path.is_file():
            archive.write(path, 'diagnostics/' + path.name)
    for name in sources + list(unchanged):
        archive.write(root / name, 'source/' + name)
    archive.write(Path(str(prefix) + '.json'), 'summary.json')
print(json.dumps({'complete': True, 'burstIdentities': summary['burstIdentities'], 'unchangedSources': len(unchanged), 'archiveBytes': Path(str(prefix) + '-evidence.zip').stat().st_size}))
