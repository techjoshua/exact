import http from 'node:http';
import {setTimeout as pause} from 'node:timers/promises';
import {writeFile} from 'node:fs/promises';
const server=http.createServer((req,res)=>{res.setHeader('keep-alive','timeout=2');res.end('ok');});
const rows=[];
await new Promise(r=>server.listen(0,'127.0.0.1',r));
try {
 for(const timeout of [undefined,10000]){
  const agent=new http.Agent({keepAlive:true,...(timeout?{timeout}:{})});
  const free=[];agent.on('free',socket=>free.push({at:Date.now(),timeout:socket.timeout,port:socket.localPort}));
  try{
   const request=()=>new Promise((resolve,reject)=>{const req=http.get(`http://127.0.0.1:${server.address().port}`,{agent},res=>{res.resume();res.on('end',()=>resolve({reused:req.reusedSocket,localPort:req.socket.localPort}));});req.on('error',reject);});
   const first=await request();await pause(1300);const second=await request();
   rows.push({configuredTimeout:timeout??null,first,second,free});
  }finally{agent.destroy();}
 }
 console.log(rows);await writeFile('.tmp/ssr-followup/agent-idle.json',JSON.stringify(rows,null,2));
}finally{server.closeAllConnections();await new Promise(r=>server.close(r));}
