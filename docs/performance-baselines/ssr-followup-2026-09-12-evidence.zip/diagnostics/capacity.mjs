import {resolve} from 'node:path';
import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {startSsrLoadProcess} from './load-owner.mjs';
import {startSsrWorker,stopSsrWorker,controlSsrWorker} from '../../framework-comparison/src/ssr-worker-controller.mjs';
import {availableSsrRuntimes} from '../../framework-comparison/src/ssr-run-environment.mjs';
import {installDevelopmentProcessLifecycle} from '../../scripts/development-process-lifecycle.mjs';
const kind=process.argv[2], root='.tmp/ssr-followup', rows=[];
let service,worker,drivers=[],timer,polling;
async function close(){clearInterval(timer);await polling;for(const d of drivers.splice(0))await d.close();if(worker){await stopSsrWorker(worker);worker=undefined;}if(service){await service.close();service=undefined;}}
const lifecycle=installDevelopmentProcessLifecycle({label:'SSR focused capacity '+kind,close});
const configurations=kind==='connections-gradual'?[{id:'react',policy:'auto',mode:'stream',prewarm:'gradual'}]:kind==='connections-late'?[{id:'react',policy:'auto',mode:'stream',prewarm:'late'}]:kind==='connections-controls'?[
 {id:'react',policy:'auto',mode:'stream',backlog:4096},
 {id:'react',policy:'auto',mode:'stream',prewarm:true},
 {id:'exact',policy:'auto',mode:'string',agentTimeout:10000}
]:kind==='bun'?[
 {id:'exact',policy:'auto'},{id:'exact',policy:'off'},{id:'exact',policy:'on'},{id:'react',policy:'auto'}
]:[
 {id:'exact',policy:'auto',mode:'string'},{id:'react',policy:'auto',mode:'stream'},{id:'exact',policy:'off',mode:'string',minimal:true}
];
try{
 for(let population=0;population<2;population++)for(const config of population?[...configurations].reverse():configurations){
  const runtimeId=kind==='bun'?'bun':'node',mode=config.mode??'stream';
  const telemetry=[],telemetryErrors=[];
  service=await startSsrLoadProcess('service');
  worker=await startSsrWorker({runtime:availableSsrRuntimes(runtimeId)[0],participantId:config.id,transport:runtimeId==='bun'?'bun-fetch':'node-http',workerPath:resolve(root+'/worker.mjs'),workingDirectory:resolve('framework-comparison'),serviceUrl:service.url,environment:{COMPARISON_SSR_BOUNDED_TELEMETRY:'1',COMPARISON_SSR_RENDER_MODE:mode,PROBE_POLICY:config.policy,PROBE_MINIMAL:config.minimal?'1':'0',PROBE_BACKLOG:config.backlog?String(config.backlog):''}});
  const response=await fetch(worker.url+'?__benchmarkPreloaded=true');assert.equal(response.status,200);const body=Buffer.from(await response.arrayBuffer());
  const identity={bytes:body.length,hash:createHash('sha256').update(body).digest('hex')};
  await controlSsrWorker(worker,'reset');
  const stages=kind==='bun'?[
   {name:'warmup',mode:'concurrency',concurrency:8,durationMs:6000,discard:true},
   {name:'c16',mode:'concurrency',concurrency:8,durationMs:12000},
   {name:'c32',mode:'concurrency',concurrency:16,durationMs:12000}
  ]:[
   {name:'warmup',mode:'concurrency',concurrency:16,durationMs:10000,discard:true},
   {name:'arrivals8000',mode:'arrival',rate:4000,durationMs:20000},
   {name:'arrivals10000',mode:'arrival',rate:5000,durationMs:20000}
  ];
  process.env.PROBE_PREWARM=typeof config.prewarm==='string'?config.prewarm:config.prewarm?'1':'0';process.env.PROBE_AGENT_TIMEOUT=config.agentTimeout?String(config.agentTimeout):'';
  for(let i=0;i<2;i++)drivers.push(await startSsrLoadProcess('driver'));
  timer=setInterval(()=>{if(polling)return;polling=controlSsrWorker(worker,'telemetry').then(t=>telemetry.push({at:Date.now(),value:{...t,probe:undefined}}),e=>telemetryErrors.push(e.message)).finally(()=>{polling=undefined;});},1000);
  console.log('START',population,config);
  for(const d of drivers)d.run({url:worker.url+'?__benchmarkPreloaded=true',contains:'Delayed fulfillment events',expectedIdentity:identity,maxInFlight:256,maxLagMs:50,timeoutMs:10000,stages});
  const results=await Promise.race([Promise.all(drivers.map(d=>d.result)),service.result]);
  clearInterval(timer);await polling;
  const final=await controlSsrWorker(worker,'telemetry');
  for(const r of results)for(const s of r.stages){assert.equal(s.offered,s.started+s.missedCapacity+s.missedLag+s.missedDeadline);assert.equal(s.completed,s.valid+s.errors);assert.equal(s.invalid,0);}
  const row={population,config,runtimeId,mode,results,telemetry,telemetryErrors,final,stderr:worker.stderr()};rows.push(row);
  for(let i=1;i<stages.length;i++) console.log(JSON.stringify({population,...config,stage:stages[i].name,rps:results.reduce((n,r)=>n+r.stages[i].validRps,0),errors:results.reduce((n,r)=>n+r.stages[i].errors,0),p99:results.map(r=>r.stages[i].distributions.responseMs.p99),gate:final.probe.decisions}));
  await close();await writeFile(root+'/'+kind+'.json',JSON.stringify({complete:false,rows}));
 }
 await writeFile(root+'/'+kind+'.json',JSON.stringify({complete:true,rows}));
}finally{await close();lifecycle.dispose();}
