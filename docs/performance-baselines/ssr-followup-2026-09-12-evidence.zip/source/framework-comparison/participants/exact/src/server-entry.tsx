import {
	renderToHydratableString,
	renderToHydratableProgressiveHtmlStream,
	type RenderToStringOptions
} from '@exactjs/ssr';
import { Document, type DocumentOptions } from './Document.jsx';
import { IncidentApp } from './IncidentApp.jsx';
import type { InitialData } from './types.js';

/** Keeps host scheduling outside the authored document's serializable props. */
export type ParticipantRenderOptions = DocumentOptions &
	Pick<RenderToStringOptions, 'scheduleRender' | 'signal'>;

/** Uses the public progressive HTML API with the same authored document and root props. */
export function renderParticipantStream(
	initialData: InitialData,
	path: string,
	options?: ParticipantRenderOptions,
	signal?: AbortSignal
) {
	return renderToHydratableProgressiveHtmlStream(
		<IncidentApp initialData={initialData} path={path} />,
		{
			publishRootProps: true,
			signal,
			scheduleRender: options?.scheduleRender,
			documentShell: (application) => (
				<Document clientTags={options?.clientTags}>{application}</Document>
			)
		}
	);
}

/** Renders the authored document through eXact's normalization and hydration publication. */
export async function renderParticipant(
	initialData: InitialData,
	path: string,
	options?: ParticipantRenderOptions
) {
	return (
		await renderToHydratableString(<IncidentApp initialData={initialData} path={path} />, {
			publishRootProps: true,
			signal: options?.signal,
			scheduleRender: options?.scheduleRender,
			documentShell: (application) => (
				<Document clientTags={options?.clientTags}>{application}</Document>
			)
		})
	).htmlWithHydration;
}
