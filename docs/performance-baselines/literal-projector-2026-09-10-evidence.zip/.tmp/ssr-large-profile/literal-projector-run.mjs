import {spawn} from 'node:child_process';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import os from 'node:os';
os.setPriority(0,10);
const root='.tmp/ssr-large-profile/',rows=[];
for(const scenario of ['large'])for(const runtime of ['node','bun'])for(const order of [['normal','literal'],['literal','normal']])for(const variant of order){
 const entry=variant==='normal'?root+'direct-execution-integrated/server-entry.js':root+'literal-projector/server-entry.js';
 const result=await new Promise((resolve,reject)=>{
  const child=spawn(runtime,[root+'flat-invocation-large-worker.mjs',entry,'encoded',scenario,'20000'],{env:{...process.env,NODE_ENV:'production'},windowsHide:true});
  let out='',err='';child.stdout.on('data',d=>out+=d);child.stderr.on('data',d=>err+=d);child.on('error',reject);child.on('exit',code=>code===0?resolve(JSON.parse(out)):reject(Error(err||String(code))));
 });
 assert.equal(result.processPriority,10);
 const control=rows.find(r=>r.scenario===scenario);if(control)assert.equal(result.hash,control.hash);
 rows.push({variant,...result});await fs.writeFile(root+'literal-projector-results.json',JSON.stringify(rows,null,2));
 console.log(scenario,runtime,variant,result.usPerRender.toFixed(2),result.cpuMicrosPerRender.toFixed(2),result.phases?.count??0);
}
