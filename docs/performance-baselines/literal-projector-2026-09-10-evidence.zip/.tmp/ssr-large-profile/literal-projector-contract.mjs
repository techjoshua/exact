import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const root='.tmp/ssr-large-profile/';
let source=await fs.readFile(root+'literal-projector/server-entry.js','utf8');
const anchor='function registerPositionalProjector(schema, version, project) {';
assert.equal(source.split(anchor).length,2);
source='const auditProjects=[];\n'+source.replace(anchor,anchor+'\n auditProjects.push({schema,project});');
source+='\nexport {auditProjects,validateJsonSafeHydrationValue};\n';
const file=root+'literal-projector-contract-entry.mjs';
await fs.writeFile(file,source);
const mod=await import(pathToFileURL(resolve(file)));
assert.equal(mod.auditProjects.length,7);
function sample(schema){
 if(schema===0)return 'safe <script> \u2028 \u2029';
 if(schema[0]===2)return [sample(schema[1])];
 const value={};for(let i=1;i<schema.length;i+=2)value[schema[i]]=sample(schema[i+1]);return value;
}
let checks=0;
for(const {schema:record} of mod.auditProjects){
 const compiled=[1,'rows',[2,record]],interpreted=structuredClone(compiled);
 for(const mutation of ['none','missing','extra','getter','cycle','nonfinite','nullPrototype'])for(const limits of [{},{maxNodes:10},{maxDepth:2}]){
  function run(schema){
   const rows=Array.from({length:20},()=>sample(record));const first=rows[0],key=record[1],second=record[3];
   if(mutation==='missing')delete first[key];
   if(mutation==='extra')first.extra=true;
   if(mutation==='getter')Object.defineProperty(first,key,{enumerable:true,get(){delete first[second];return 'changed';}});
   if(mutation==='cycle')first[key]=first;
   if(mutation==='nonfinite')first[key]=NaN;
   if(mutation==='nullPrototype')Object.setPrototypeOf(first,null);
   const payload={state:null};
   const error=mod.validateJsonSafeHydrationValue(payload,{...limits,structurallyKnownRoot:payload,positionalRoot:{componentId:'audit',props:{rows},schema}});
   return {error,payload};
  }
  const actual=run(compiled),expected=run(interpreted);
  assert.equal(actual.error,expected.error);
  if(!actual.error)assert.deepEqual(actual.payload,expected.payload);
  checks++;
 }
}
const result={runtime:process.versions.bun??process.version,projectors:7,checks};
await fs.writeFile(root+'literal-projector-contract-'+(process.versions.bun?'bun':'node')+'.json',JSON.stringify(result,null,2));
console.log(JSON.stringify(result));
