# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: native-full-stack.spec.ts >> exact-native >> claims and comments through the framework server boundary
- Location: e2e-native\native-full-stack.spec.ts:44:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Alex Chen', { exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByText('Alex Chen', { exact: true })

```

```yaml
- banner:
  - text: Native full stack
  - heading "Signal Desk" [level=1]
  - text: Compiler server tasks
- main:
  - region "Incident queue":
    - heading "Incident queue" [level=2]
    - button "Refresh"
    - text: Severity
    - combobox "Severity":
      - option "All" [selected]
      - option "Critical"
      - option "High"
      - option "Medium"
    - text: Status
    - combobox "Status":
      - option "All" [selected]
      - option "Open"
      - option "Investigating"
    - button "critical Checkout authorization failures Assigned · investigating":
      - text: critical
      - strong: Checkout authorization failures
      - text: Assigned · investigating
    - button "high Delayed fulfillment events Assigned · investigating":
      - text: high
      - strong: Delayed fulfillment events
      - text: Assigned · investigating
    - button "medium Search index freshness warning Unassigned · open":
      - text: medium
      - strong: Search index freshness warning
      - text: Unassigned · open
  - region "Incident detail":
    - heading "Checkout authorization failures" [level=2]
    - text: Version 1 Owner
    - strong: Unassigned
    - text: Status
    - strong: open
    - button "Claim incident"
    - heading "Server analysis" [level=3]
    - status: Analysis has not started
    - button "Start analysis"
    - heading "Response log" [level=3]
    - paragraph: No comments yet.
    - text: New comment
    - textbox "New comment"
    - button "Add comment"
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test';
  2  | 
  3  | const participants = [
  4  | 	{
  5  | 		id: 'exact-native',
  6  | 		url: 'http://127.0.0.1:4501',
  7  | 		earlyClientResource: /<script\b(?=[^>]*\btype="module")(?=[^>]*\bsrc=)[^>]*>/i
  8  | 	},
  9  | 	{
  10 | 		id: 'react-native',
  11 | 		url: 'http://127.0.0.1:4502',
  12 | 		earlyClientResource: /<link\b(?=[^>]*\brel="modulepreload")(?=[^>]*\bhref=)[^>]*>/i
  13 | 	}
  14 | ];
  15 | 
  16 | for (const participant of participants) {
  17 | 	test.describe(participant.id, () => {
  18 | 		test.beforeEach(async ({ request }) => {
  19 | 			const response = await request.post(`${participant.url}/__benchmark/reset`, { data: {} });
  20 | 			expect(response.ok()).toBe(true);
  21 | 		});
  22 | 
  23 | 		test('server renders meaningful HTML and hydrates filters', async ({ browser }) => {
  24 | 			const noScript = await browser.newContext({ javaScriptEnabled: false });
  25 | 			const serverPage = await noScript.newPage();
  26 | 			const response = await serverPage.goto(`${participant.url}/incidents/inc-101`);
  27 | 			expect(response?.headers()['x-comparison-render']).toBe('ssr');
  28 | 			const documentHtml = (await response?.text()) ?? '';
  29 | 			const documentHead = documentHtml.slice(0, documentHtml.indexOf('</head>'));
  30 | 			expect(documentHead).toMatch(participant.earlyClientResource);
  31 | 			await expect(
  32 | 				serverPage.getByRole('heading', { name: 'Delayed fulfillment events' })
  33 | 			).toBeVisible();
  34 | 			await noScript.close();
  35 | 
  36 | 			const context = await browser.newContext();
  37 | 			const page = await context.newPage();
  38 | 			await page.goto(participant.url);
  39 | 			await page.getByLabel('Severity').selectOption('critical');
  40 | 			await expect(page.getByTestId('incident-row')).toHaveCount(1);
  41 | 			await context.close();
  42 | 		});
  43 | 
  44 | 		test('claims and comments through the framework server boundary', async ({ page }) => {
  45 | 			await page.goto(`${participant.url}/incidents/inc-100`);
  46 | 			await page.getByRole('button', { name: 'Claim incident' }).click();
> 47 | 			await expect(page.getByText('Alex Chen', { exact: true })).toBeVisible();
     |                                                               ^ Error: expect(locator).toBeVisible() failed
  48 | 			await expect(page.getByText('Version 2', { exact: true })).toBeVisible();
  49 | 			await page.getByLabel('New comment').fill('Checking the native server path.');
  50 | 			await page.getByRole('button', { name: 'Add comment' }).click();
  51 | 			await expect(page.getByText('Checking the native server path.')).toHaveCount(1);
  52 | 		});
  53 | 
  54 | 		test('follows asynchronous analysis over the native event stream', async ({ page }) => {
  55 | 			await page.goto(`${participant.url}/incidents/inc-102`);
  56 | 			await page.getByRole('button', { name: 'Start analysis' }).click();
  57 | 			await expect(page.getByText('Analysis completed', { exact: true })).toBeVisible();
  58 | 			await expect(page.getByText('Correlated upstream failures')).toBeVisible();
  59 | 		});
  60 | 
  61 | 		test('preserves a focused draft across a second-session mutation', async ({ browser }) => {
  62 | 			const firstContext = await browser.newContext();
  63 | 			const secondContext = await browser.newContext();
  64 | 			const first = await firstContext.newPage();
  65 | 			const second = await secondContext.newPage();
  66 | 			await Promise.all([
  67 | 				first.goto(`${participant.url}/incidents/inc-102`),
  68 | 				second.goto(`${participant.url}/incidents/inc-102`)
  69 | 			]);
  70 | 			const draft = first.getByLabel('New comment');
  71 | 			await draft.fill('My native response remains in progress.');
  72 | 			await draft.focus();
  73 | 			await second.getByLabel('New comment').fill('Second-session observation.');
  74 | 			await second.getByRole('button', { name: 'Add comment' }).click();
  75 | 			await expect(first.getByText('Second-session observation.')).toBeVisible();
  76 | 			await expect(draft).toBeFocused();
  77 | 			await expect(draft).toHaveValue('My native response remains in progress.');
  78 | 			await Promise.all([firstContext.close(), secondContext.close()]);
  79 | 		});
  80 | 	});
  81 | }
  82 | 
```