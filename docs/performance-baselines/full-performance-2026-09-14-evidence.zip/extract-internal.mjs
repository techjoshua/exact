import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,copyFileSync} from 'node:fs';
const d='.tmp/full-performance-2026-09-14',raw=JSON.parse(readFileSync('.tmp/release-performance-output.json','utf8'));
assert.ok(raw.generatedAt.startsWith('2026-09-'));
copyFileSync('.tmp/release-performance-output.json',d+'/internal-performance-output.json');
copyFileSync('.tmp/release-timings-performance.json',d+'/internal-performance-timings.json');
for(const [name,phase,marker] of [
['reactive','reactive benchmarks','REACTIVE_BENCHMARK_JSON='],
['dom-list','reactive benchmarks','DOM_LIST_BENCHMARK_JSON='],
['framework','framework client/server benchmarks','EXACT_FRAMEWORK_BENCHMARK_JSON='],
['compiler','compiler benchmarks','COMPILER_BENCHMARK_JSON='],
['devtools','DevTools inspection benchmarks','DEVTOOLS_BENCHMARK_JSON='],
['react-compat','React compatibility benchmark','REACT_COMPAT_BENCHMARK_JSON=']]){
const p=raw.phases.find(p=>p.name===phase);assert.ok(p);const line=p.output.split(/\r?\n/).find(x=>x.startsWith(marker));assert.ok(line);
writeFileSync(d+'/'+name+'.log',line+'\n');writeFileSync(d+'/'+name+'.json',JSON.stringify(JSON.parse(line.slice(marker.length)),null,2)+'\n');
}
console.log('Retained completed internal benchmark evidence.');
