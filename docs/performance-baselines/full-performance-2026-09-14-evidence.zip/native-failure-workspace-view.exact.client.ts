import { createPreparedRenderProgram as __exactPreparedRenderProgram, prepareCompiledRenderProgram as __exactPrepareRenderProgram, createCompiledChildRangeReceipt as __exactDynamic } from "@exactjs/core/runtime/render-operations";
import { createDerived as __exactDerived } from "@exactjs/core/runtime/reactivity";
import { createCompiledKeyedChildReceipt as __exactKeyedChild } from "@exactjs/core/runtime/component-operations";
import type { WorkspaceState } from "../src/contracts.js";
const __exact_render_program_1 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xrYosxDTjhjploQdWehfaDk", namespace: "html", template: "<p role=\"alert\"><!---->\uE000exact:0\uE001<!----></p>", wire: [["p", "html", 1, 1], [[3, 0, 0, true]], [[0, 0]]], directClaims: true });
const __exact_render_program_2 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xXWtsK5wiIVz5dHFBrCtZOd", namespace: "html", template: "<button data-testid=\"incident-row\"><span><!---->\uE000exact:3\uE001<!----></span><strong><!---->\uE000exact:4\uE001<!----></strong><small><!---->\uE000exact:5\uE001<!----> \u00B7 <!---->\uE000exact:6\uE001<!----></small></button>", wire: [["button", "html", 4, 7], [[0, 1, 0, "span"], [1, 1], [3, 3, 0, true], [2], [0, 2, 0, "strong"], [1, 2], [3, 4, 0, true], [2], [0, 3, 0, "small"], [1, 3], [8, [5, " \u00B7 ", 6]], [3, 5, 0, true], [3, 6, 1, true], [2], [7, 0, 0], [7, 2, 1]], [[0, 3], [0, 4], [0, 5], [0, 6], [6, 0, 0], [6, 1, 2]]], directClaims: true });
const __exact_render_program_3 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xIQAVBHrARSRrnfW62CWmlc", namespace: "html", template: "<div class=\"detail-heading\"><h2></h2><span>Version </span></div>", wire: [["div", "html", 3, 2], [[0, 1, 0, "h2"], [1, 1], [4, 0, 0], [2], [0, 2, 0, "span"], [1, 2], [4, 1, 1], [2]], [[1, 0], [1, 1]]], directClaims: true });
const __exact_render_program_4 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xOFSoJbJMXeVaEZtA8N-eix", namespace: "html", template: "<div class=\"facts\"><div><span>Owner</span><strong><!---->\uE000exact:0\uE001<!----></strong></div><div><span>Status</span><strong></strong></div></div>", wire: [["div", "html", 7, 2], [[0, 1, 0, "div"], [1, 1], [0, 3, 1, "strong"], [1, 3], [3, 0, 0, true], [2], [2], [0, 4, 0, "div"], [1, 4], [0, 6, 1, "strong"], [1, 6], [4, 1, 0], [2], [2]], [[0, 0], [1, 1]]], directClaims: true });
const __exact_render_program_5 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xM8r5qXs3oMLX3ETDi7FDnM", namespace: "html", template: "<p class=\"alert\" role=\"alert\"><!---->\uE000exact:0\uE001<!----></p>", wire: [["p", "html", 1, 1], [[3, 0, 0, true]], [[0, 0]]], directClaims: true });
const __exact_render_program_6 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xB9zQFLzwLRK-tbr3TDPbBA", namespace: "html", template: "<button class=\"primary\">Claim incident</button>", wire: [["button", "html", 1, 1], [[7, 0, 0]], [[5, 0, 0]]], directClaims: true });
const __exact_render_program_7 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xVoDp8NjEG6s1YdpK-Yj9V_", namespace: "html", template: "<strong><!---->\uE000exact:0\uE001<!----></strong>", wire: [["strong", "html", 1, 1], [[3, 0, 0, true]], [[0, 0]]], directClaims: true });
const __exact_render_program_8 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xRc2GSXRi8VF2kB6yqw5PQp", namespace: "html", template: "<section class=\"analysis-card\"><div><h3>Server analysis</h3><p role=\"status\"><!---->\uE000exact:0\uE001<!----></p></div><button class=\"quiet\">Start analysis</button></section>", wire: [["section", "html", 5, 4], [[0, 1, 0, "div"], [1, 1], [0, 3, 1, "p"], [1, 3], [3, 0, 0, true], [2], [4, 1, 0], [2], [6, 4, 17, "button"], [7, 2, 4]], [[0, 0], [1, 1], [6, 0, 2]]], directClaims: true });
const __exact_render_program_9 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xPXKGp3FgE3h6UenXdZJiJt", namespace: "html", template: "<p class=\"empty\">No comments yet.</p>", root: ["p"], work: [1, 0], directClaims: true });
const __exact_render_program_10 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "x14JFi6yQnDN4_EBSkLLysF", namespace: "html", template: "<article><strong><!---->\uE000exact:0\uE001<!----></strong><p><!---->\uE000exact:1\uE001<!----></p></article>", wire: [["article", "html", 3, 2], [[0, 1, 0, "strong"], [1, 1], [3, 0, 0, true], [2], [0, 2, 0, "p"], [1, 2], [3, 1, 0, true], [2]], [[0, 0], [0, 1]]], directClaims: true });
const __exact_render_program_11 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "x_gB1WY7KlK4kmqtMimZaz6", namespace: "html", template: "<section class=\"comments\"><h3>Response log</h3><!--x:0--><!--/x:0--><!--x:1--><!--/x:1--><form><label>New comment <textarea maxLength=\"2000\" required></textarea></label><button class=\"primary\" type=\"submit\">Add comment</button></form></section>", wire: [["section", "html", 6, 5], [[5, 0, 1, "0"], [5, 1, 0, "1"], [6, 2, 1025, "form"], [7, 2, 2], [6, 4, 1027, "textarea"], [7, 3, 4]], [[1, 0], [3, 1], [5, 0, 2], [6, 1, 3]]], directClaims: true, keyedChildren: 2 });
const __exact_render_program_12 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "x1aJp6NGwa4J1r5JQ1zbsg5", namespace: "html", template: "<p class=\"empty\">Select an incident to inspect its response history.</p>", root: ["p"], work: [1, 0], directClaims: true });
const __exact_render_program_13 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xJXvBCLToJS_cSuqStRJLgP", namespace: "html", template: "<div class=\"app-shell\"><header class=\"masthead\"><div><span class=\"eyebrow\">Native full stack</span><h1>Signal Desk</h1></div><span class=\"connection\">Compiler server tasks</span></header><main><section class=\"queue-panel\" aria-labelledby=\"queue-title\"><div class=\"section-heading\"><h2 id=\"queue-title\">Incident queue</h2><button class=\"quiet\">Refresh</button></div><div class=\"filters\"><label>Severity <select><option value=\"all\">All</option><option value=\"critical\">Critical</option><option value=\"high\">High</option><option value=\"medium\">Medium</option></select></label><label>Status <select><option value=\"all\">All</option><option value=\"open\">Open</option><option value=\"investigating\">Investigating</option></select></label></div><!--x:0--><!--/x:0--><div class=\"incident-list\"></div></section><section class=\"detail-panel\" aria-label=\"Incident detail\"></section></main></div>", wire: [["div", "html", 25, 8], [[0, 6, 1, "main"], [1, 6], [0, 7, 0, "section"], [1, 7], [5, 5, 2, "0"], [0, 23, 0, "div"], [1, 23], [4, 6, 0], [2], [2], [0, 24, 0, "section"], [1, 24], [4, 7, 0], [2], [2], [6, 10, 33554452, "button"], [7, 0, 10], [6, 13, 262165, "select"], [7, 1, 13], [6, 19, 33816597, "select"], [7, 3, 19]], [[1, 5], [3, 6], [1, 7], [5, 0, 0], [6, 1, 1], [6, 2, 3]]], directClaims: true, keyedChildren: 64 });
type WorkspaceOperations = {
    selectIncident(id: string): void;
    refresh(): void;
    claimSelected(): void;
    addComment(): void;
    startAnalysis(): void;
};
/** Describes the native workspace while state and task ownership remain in the durable component. */
export function renderWorkspace(state: WorkspaceState, operations: WorkspaceOperations) {
    ;
    const selected = __exactDerived(() => state.incidents.find((incident) => incident.id === state.selectedId));
    const owner = __exactDerived(() => state.users.find((user) => user.id === selected.get()?.ownerId)?.name ?? 'Unassigned');
    return (__exactPreparedRenderProgram(__exact_render_program_13, __exactSlot => {
        if (__exactSlot === 5) {
            return state.error ? __exactPreparedRenderProgram(__exact_render_program_1, [() => state.error], undefined) : null;
        }
        if (__exactSlot === 6) {
            const __exact_filtered_1 = state.incidents.filter((incident) => (state.severity === 'all' || incident.severity === state.severity) &&
                (state.status === 'all' || incident.status === state.status));
            return __exact_filtered_1.map((incident) => __exactKeyedChild((__exactPreparedRenderProgram(__exact_render_program_2, __exactSlot => __exactSlot === 3 ? incident.severity : __exactSlot === 4 ? incident.title : __exactSlot === 5 ? incident.ownerId ? 'Assigned' : 'Unassigned' : __exactSlot === 6 ? incident.status : undefined, undefined, (__exactGroup, __exactApply) => {
                if (__exactGroup === 0) {
                    __exactApply("className", ["incident", { "active": incident.id === state.selectedId }]);
                    __exactApply("__exactClosedInteraction:onClick", () => operations.selectIncident(incident.id));
                }
                if (__exactGroup === 1) {
                    __exactApply("className", ["severity", { "critical": incident.severity === 'critical' }, { "high": incident.severity === 'high' }, { "medium": incident.severity === 'medium' }]);
                }
            })), incident.id));
        }
        if (__exactSlot === 7) {
            const __exact_cached_selected_1 = selected.get();
            return __exact_cached_selected_1 ? ([__exactPreparedRenderProgram(__exact_render_program_3, __exactSlot => __exactSlot === 0 ? __exact_cached_selected_1.title : __exact_cached_selected_1.version, undefined), __exactPreparedRenderProgram(__exact_render_program_4, __exactSlot => __exactSlot === 0 ? owner.get() : __exact_cached_selected_1.status, undefined), __exactDynamic(() => state.conflict ? (__exactPreparedRenderProgram(__exact_render_program_5, [() => state.conflict], undefined)) : null, "x3ee-ilX7IE0UvonhlrvbkE"), __exactPreparedRenderProgram(__exact_render_program_6, [], undefined, (__exactGroup, __exactApply) => {
                    if (__exactGroup === 0) {
                        __exactApply("__exactDirectInteraction:onClick", operations.claimSelected);
                    }
                }), __exactPreparedRenderProgram(__exact_render_program_8, __exactSlot => __exactSlot === 0 ? state.job ? `Analysis ${state.job.status}` : 'Analysis has not started' : __exactSlot === 1 ? state.job?.result ? __exactPreparedRenderProgram(__exact_render_program_7, [() => state.job.result.finding], undefined) : null : undefined, undefined, (__exactGroup, __exactApply) => {
                    if (__exactGroup === 0) {
                        __exactApply("disabled", state.busy);
                        __exactApply("__exactDirectInteraction:onClick", operations.startAnalysis);
                    }
                }), __exactPreparedRenderProgram(__exact_render_program_11, __exactSlot => __exactSlot === 0 ? __exact_cached_selected_1.comments.length === 0 ? __exactPreparedRenderProgram(__exact_render_program_9, [], undefined) : null : __exactSlot === 1 ? __exact_cached_selected_1.comments.map((entry) => __exactKeyedChild((__exactPreparedRenderProgram(__exact_render_program_10, __exactSlot => __exactSlot === 0 ? state.users.find((user) => user.id === entry.authorId)?.name : entry.body, undefined)), entry.id)) : undefined, undefined, (__exactGroup, __exactApply) => {
                    if (__exactGroup === 0) {
                        __exactApply("__exactDirectInteraction:onSubmit", (event: import("@exactjs/jsx/jsx-runtime").JSX.TargetedEvent<HTMLFormElement, SubmitEvent>) => {
                            event.preventDefault();
                            operations.addComment();
                        });
                    }
                    if (__exactGroup === 1) {
                        __exactApply("value", state.draft ?? "");
                        __exactApply("__exactBindInput", (event: Event & {
                            readonly currentTarget: HTMLTextAreaElement;
                        }) => state.draft = event.currentTarget.value as any);
                    }
                })]) : (__exactPreparedRenderProgram(__exact_render_program_12, [], undefined));
        }
    }, undefined, (__exactGroup, __exactApply) => {
        if (__exactGroup === 0) {
            __exactApply("__exactDirectInteraction:onClick", operations.refresh);
        }
        if (__exactGroup === 1) {
            __exactApply("value", state.severity ?? "");
            __exactApply("__exactBindChange", (event: Event & {
                readonly currentTarget: HTMLSelectElement;
            }) => state.severity = event.currentTarget.value as any);
        }
        if (__exactGroup === 2) {
            __exactApply("value", state.status ?? "");
            __exactApply("__exactBindChange", (event: Event & {
                readonly currentTarget: HTMLSelectElement;
            }) => state.status = event.currentTarget.value as any);
        }
    }));
}
//# sourceMappingURL=workspace-view.exact.client.ts.map
