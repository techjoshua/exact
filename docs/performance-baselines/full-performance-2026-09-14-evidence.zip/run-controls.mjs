import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync,readFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
const root=resolve('.'),output=resolve('.tmp/full-performance-2026-09-14'),suite=resolve('framework-comparison');
const journal=existsSync(`${output}/execution.json`)?JSON.parse(readFileSync(`${output}/execution.json`)):[];
process.env.NODE_ENV='production';process.env.COMPARISON_SSR_RENDER_MODE='string';
async function run(name,args,cwd=root,env={}) {
 if(journal.some(s=>s.name===name&&s.code===0)){console.log('RETAIN '+name);return;}
 const step={name,args,cwd,env,startedAt:new Date().toISOString()};journal.push(step);
 const save=()=>writeFileSync(`${output}/execution.json`,JSON.stringify(journal,null,2));save();console.log('START '+name);
 const log=openSync(`${output}/${name}.log`,'w');
 try{await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{cwd,env:{...process.env,...env},stdio:['ignore',log,log],windowsHide:true});step.pid=child.pid;save();child.once('error',fail);child.once('exit',(code,signal)=>{step.code=code;step.signal=signal;code===0?done():fail(Error(`${name} failed: ${code??signal}`));});});}
 finally{closeSync(log);step.endedAt=new Date().toISOString();save();}console.log('DONE '+name);
}
await run('node-stream-gradual',[output+'/capacity-runner.mjs',output+'/gradual-arrivals-plan.json',output+'/node-stream-gradual.json','node'],root,{COMPARISON_SSR_RENDER_MODE:'stream'});
console.log('COMPLETE connection-growth control');
