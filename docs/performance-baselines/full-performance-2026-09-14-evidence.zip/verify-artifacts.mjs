import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { hashArtifactDirectory } from '../../framework-comparison/src/artifact-integrity.mjs';
const root = '.tmp/full-performance-2026-09-14';
const entries = {};
for (const [name, path] of Object.entries({
  baselineNode: `${root}/measured-exact-node.mjs`,
  baselineBun: `${root}/measured-exact-bun.mjs`,
  currentNode: 'framework-comparison/participants/exact/dist-server/server-entry.js',
  currentBun: 'framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js',
  scheduler: 'framework-adapters/node-adapter/dist/render-scheduler.js',
  gate: 'framework-adapters/node-adapter/dist/requests/adaptive-gate.js',
  admission: 'framework-adapters/node-adapter/dist/requests/admission.js',
  handler: 'framework-adapters/node-adapter/dist/requests/handler.js',
  worker: 'framework-comparison/src/ssr-benchmark-worker.mjs',
  controller: 'framework-comparison/src/ssr-worker-controller.mjs'
})) {
  const data = await readFile(path);
  entries[name] = {path, bytes: data.length, sha256: createHash('sha256').update(data).digest('hex')};
}
assert.equal(entries.baselineNode.sha256, entries.currentNode.sha256, 'Node measured bundle unchanged');
assert.equal(entries.baselineBun.sha256, entries.currentBun.sha256, 'Bun measured bundle unchanged');
const browser = JSON.parse(await readFile(`${root}/browser.json`, 'utf8'));
assert.equal(browser.harness.clientDelivery.mode, 'replay');
assert.equal(browser.harness.clientDelivery.frameworkServersStopped, true);
const clients = {};
for (const [id, directory] of Object.entries({exact:'dist', react:'dist', sveltekit:'build/client', nuxt:'.output/public', 'tanstack-start':'.output/public'})) {
  const path = `framework-comparison/participants/${id}/${directory}`;
  const hash = await hashArtifactDirectory(path);
  assert.equal(hash, browser.complexity.find(e => e.participantId === id + '-controlled').artifacts.hash, `${id} replay artifact unchanged`);
  clients[id] = {path, sha256:hash};
}
for (const runtime of ['node','bun']) for (const mode of ['','-stream']) for (const lane of ['multi','normal','arrivals']) {
  const capture = JSON.parse(await readFile(`${root}/${runtime}${mode}-${lane}.json`, 'utf8'));
  assert.equal(capture.complete, true);
  assert.equal(capture.artifacts.exact.sha256, entries[runtime === 'node' ? 'currentNode' : 'currentBun'].sha256);
}
const verification = {
  createdAt: new Date().toISOString(), entries, clients,
  configuration: 'All capacity and HTTP diagnostic captures use the committed default adapter policies, including adaptive readiness checkpoints. Both frameworks render their complete authored document.',
  history: 'Frozen measured bundles identify this capture. Previous reports are historical context, not idle-PC acceptance controls.',
  browser: 'Client replay, startup and heap captures retain identical verified client artifacts. Framework servers were stopped during client replay. Live Node/Bun string/stream browser checks are recorded in the capture execution journal and their individual logs.'
};
await writeFile(`${root}/current-build-verification.json`, JSON.stringify(verification, null, 2)+'\n');
