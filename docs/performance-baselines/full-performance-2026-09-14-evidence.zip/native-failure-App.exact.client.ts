import { readIndexedReactiveSlot as __exactReadState, writeIndexedReactiveValue as __exactWriteState } from "@exactjs/core/runtime/reactivity";
import { combineTaskSignal as __exactTaskCombinedSignal, dispatchComponentContinuation as __exactDispatchContinuation, defineTask as __exactDefineTask, bindTaskForHost as __exactBindTask } from "@exactjs/core/runtime/tasks";
import { registerComponentLifecycleHandler as __exactRegisterLifecycle } from "@exactjs/core/framework/component-lifecycle";
import { createServerBoundaryReceipt as __exactBoundary } from "@exactjs/core/runtime/component-operations";
import { peek, TaskContext, type Component } from '@exactjs/core';
import { navigateToIncident, openIncidentEvents } from "../src/browser-events.js";
import type { NativeInitialData, WorkspaceState } from "../src/contracts.js";
import { renderWorkspace } from "./workspace-view.exact.client.js";
import { attachExactCompiledClientComponent as __exactAttachClientComponent_1, receiveExactClientComponentProps as __exactReceiveClientProps_1, disposeExactClientComponent as __exactDisposeClientComponent_1 } from "@exactjs/core/runtime/component-operations";
import { constructRenderComponentInstance as __exactConstructRenderComponent_1 } from "@exactjs/core/runtime/component-construction/render";
import { constructDurableComponentInstance as __exactConstructDurableComponent_1 } from "@exactjs/core/runtime/component-construction/durable";
const __exactComponentContract_1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
const __exactImplementation_NativeIncidentPage_1 = function NativeIncidentPage(props = {}) {
    return () => __exactBoundary("xw5VwR2wOZBuywitrpAsC8C", "NativeIncidentPage", props);
};
export const NativeIncidentPage = /* @__PURE__ */ (() => Object.assign(__exactImplementation_NativeIncidentPage_1, {
    [Symbol.for("@exactjs/component")]: "x9V4J2rB3iTWeLVsUvagf2T",
    [__exactComponentContract_1]: {
        artifact: {
            version: 1,
            target: "client",
            id: "x9V4J2rB3iTWeLVsUvagf2T",
            instantiate: __exactImplementation_NativeIncidentPage_1,
            construct: __exactConstructRenderComponent_1,
            abi: 32,
            capabilities: [],
            state: [
                "initial"
            ],
            props: [
                "path"
            ],
            attach: __exactAttachClientComponent_1,
            receive: __exactReceiveClientProps_1,
            dispose: __exactDisposeClientComponent_1
        }
    }
}) as typeof __exactImplementation_NativeIncidentPage_1)();
const __exactImplementation_NativeIncidentWorkspace_1 = function NativeIncidentWorkspace(this: Component<WorkspaceState>, props: {
    initial: NativeInitialData;
    path: string;
}) {
    const state = this.state;
    __exactWriteState(this.state, 4, peek(() => (__exactReadState(props, 0) as NativeInitialData).incidents.map(copyIncident)));
    __exactWriteState(this.state, 10, peek(() => (__exactReadState(props, 0) as NativeInitialData).users.map((user) => ({ ...user }))));
    __exactWriteState(this.state, 7, peek(() => (__exactReadState(props, 0) as NativeInitialData).sessionUserId));
    const initialSelectedId = peek(() => incidentIdFromPath(__exactReadState(props, 1) as string) || (__exactReadState(props, 0) as NativeInitialData).incidents[0]?.id || '');
    __exactWriteState(this.state, 6, initialSelectedId);
    __exactWriteState(this.state, 8, 'all');
    __exactWriteState(this.state, 9, 'all');
    __exactWriteState(this.state, 2, '');
    __exactWriteState(this.state, 1, '');
    __exactWriteState(this.state, 3, '');
    __exactWriteState(this.state, 5, null);
    __exactWriteState(this.state, 0, false);
    __exactWriteState(this.state, 11, initialSelectedId);
    __exactWriteState(this.state, 12, peek(() => (__exactReadState(props, 0) as NativeInitialData).incidents.find((incident) => incident.id === initialSelectedId)?.version ?? 0));
    const refreshOnServer = __exactBindTask(this, __exactDefineTask({
        label: "refreshOnServer",
        placement: "server",
        priority: "normal",
        concurrency: "latest",
        readiness: "blocking"
    }, (...__exactTaskArgs: any[]) => {
        const __exactTaskContext: any = __exactTaskArgs.pop();
        return __exactDispatchContinuation(this as any, "xcURjiQJHbVoocCJ_AFHlhZ", __exactTaskArgs, __exactTaskContext.signal, [], __exactTaskContext.generation);
    }));
    const claimOnServer = __exactBindTask(this, __exactDefineTask({
        label: "claimOnServer",
        placement: "server",
        priority: "normal",
        concurrency: "parallel",
        readiness: "blocking"
    }, (...__exactTaskArgs: any[]) => {
        const __exactTaskContext: any = __exactTaskArgs.pop();
        return __exactDispatchContinuation(this as any, "xaRvMhU-X1O6r21Nwx6UdUz", __exactTaskArgs, __exactTaskContext.signal, [], __exactTaskContext.generation);
    }));
    const commentOnServer = __exactBindTask(this, __exactDefineTask({
        label: "commentOnServer",
        placement: "server",
        priority: "normal",
        concurrency: "parallel",
        readiness: "blocking"
    }, (...__exactTaskArgs: any[]) => {
        const __exactTaskContext: any = __exactTaskArgs.pop();
        return __exactDispatchContinuation(this as any, "xv3VvmP-iKfLWl3b5QE7NBY", __exactTaskArgs, __exactTaskContext.signal, [], __exactTaskContext.generation);
    }));
    const analyzeOnServer = __exactBindTask(this, __exactDefineTask({
        label: "analyzeOnServer",
        placement: "server",
        priority: "normal",
        concurrency: "parallel",
        readiness: "blocking"
    }, (...__exactTaskArgs: any[]) => {
        const __exactTaskContext: any = __exactTaskArgs.pop();
        return __exactDispatchContinuation(this as any, "xNsle0a4zj4xcqcOmdEcWQY", __exactTaskArgs, __exactTaskContext.signal, [], __exactTaskContext.generation);
    }));
    const replaceIncident = (incident: WorkspaceState['incidents'][number]) => {
        __exactWriteState(this.state, 4, (__exactReadState(this.state, 4) as import("../src/contracts.js").Incident[]).map((current) => current.id === incident.id ? incident : current));
    };
    const selectIncident = (id: string, _task: TaskContext = TaskContext.client()) => {
        __exactWriteState(this.state, 6, id);
        __exactWriteState(this.state, 11, id);
        __exactWriteState(this.state, 12, (__exactReadState(this.state, 4) as import("../src/contracts.js").Incident[]).find((item) => item.id === id)?.version ?? 0);
        navigateToIncident(id);
    };
    const refresh = async () => {
        __exactWriteState(this.state, 3, '');
        try {
            const result = await refreshOnServer();
            __exactWriteState(this.state, 4, result.incidents);
            __exactWriteState(this.state, 10, result.users);
            __exactWriteState(this.state, 7, result.sessionUserId);
        }
        catch (caught) {
            __exactWriteState(this.state, 3, caught instanceof Error ? caught.message : 'Unable to refresh incidents');
        }
    };
    const claimSelected = async () => {
        const incident = (__exactReadState(state, 4) as import("../src/contracts.js").Incident[]).find((item) => item.id === __exactReadState(state, 6) as string);
        if (!incident)
            return;
        const original = copyIncident(incident);
        replaceIncident({ ...original, ownerId: __exactReadState(state, 7) as string, status: 'investigating' });
        __exactWriteState(this.state, 1, '');
        __exactWriteState(this.state, 3, '');
        try {
            const result = await claimOnServer(original.id, __exactReadState(state, 7) as string, __exactReadState(state, 12) as number);
            if (result.conflict) {
                replaceIncident(result.conflict);
                __exactWriteState(this.state, 12, result.conflict.version);
                __exactWriteState(this.state, 1, 'This incident changed while you were viewing it. The latest owner is shown.');
            }
            else if (result.incident) {
                replaceIncident(result.incident);
                __exactWriteState(this.state, 12, result.incident.version);
            }
        }
        catch (caught) {
            replaceIncident(original);
            __exactWriteState(this.state, 3, caught instanceof Error ? caught.message : 'Unable to claim incident');
        }
    };
    const addComment = async () => {
        const incident = (__exactReadState(state, 4) as import("../src/contracts.js").Incident[]).find((item) => item.id === __exactReadState(state, 6) as string);
        const body = (__exactReadState(state, 2) as string).trim();
        if (!incident || !body)
            return;
        __exactWriteState(this.state, 2, '');
        try {
            const result = await commentOnServer(incident.id, __exactReadState(state, 7) as string, body, crypto.randomUUID());
            replaceIncident(result);
            __exactWriteState(this.state, 12, result.version);
        }
        catch (caught) {
            __exactWriteState(this.state, 2, body);
            __exactWriteState(this.state, 3, caught instanceof Error ? caught.message : 'Unable to add comment');
        }
    };
    const startAnalysis = async () => {
        if (!(__exactReadState(state, 6) as string))
            return;
        __exactWriteState(this.state, 0, true);
        try {
            const job = await analyzeOnServer(__exactReadState(state, 6) as string);
            __exactWriteState(this.state, 5, job);
        }
        catch (caught) {
            __exactWriteState(this.state, 3, caught instanceof Error ? caught.message : 'Unable to start analysis');
        }
        finally {
            __exactWriteState(this.state, 0, false);
        }
    };
    const connectEvents = __exactBindTask(this, __exactDefineTask({
        label: "connectEvents",
        placement: "client",
        priority: "normal",
        concurrency: "parallel",
        readiness: "nonblocking"
    }, (signal: AbortSignal, _task: TaskContext) => {
        openIncidentEvents((incident) => replaceIncident(incident), (job) => {
            if (job.id === state.job?.id)
                __exactWriteState(this.state, 5, job);
        }, __exactTaskCombinedSignal(_task.signal, signal));
    }));
    __exactRegisterLifecycle(this, "mount", ({ signal }) => {
        connectEvents(signal);
    });
    return () => renderWorkspace(this.state, {
        selectIncident,
        refresh: () => void refresh(),
        claimSelected: () => void claimSelected(),
        addComment: () => void addComment(),
        startAnalysis: () => void startAnalysis()
    });
};
export const NativeIncidentWorkspace = /* @__PURE__ */ (() => Object.assign(__exactImplementation_NativeIncidentWorkspace_1, {
    [Symbol.for("@exactjs/component")]: "xwG3ifFGDqfbDVf8eBrb1XP",
    [__exactComponentContract_1]: {
        artifact: {
            version: 1,
            target: "client",
            id: "xwG3ifFGDqfbDVf8eBrb1XP",
            instantiate: __exactImplementation_NativeIncidentWorkspace_1,
            construct: __exactConstructDurableComponent_1,
            abi: 11,
            capabilities: [
                "tasks",
                "continuations",
                "resumption"
            ],
            state: [
                "busy",
                "conflict",
                "draft",
                "error",
                "incidents",
                "job",
                "selectedId",
                "sessionUserId",
                "severity",
                "status",
                "users",
                "viewedIncidentId",
                "viewedVersion"
            ],
            props: [
                "initial",
                "path"
            ],
            serialization: [
                1,
                "initial",
                [
                    1,
                    "sessionUserId",
                    0,
                    "users",
                    [
                        2,
                        [
                            1,
                            "id",
                            0,
                            "name",
                            0
                        ]
                    ],
                    "incidents",
                    [
                        2,
                        [
                            1,
                            "id",
                            0,
                            "title",
                            0,
                            "severity",
                            0,
                            "status",
                            0,
                            "ownerId",
                            0,
                            "version",
                            0,
                            "updatedAt",
                            0,
                            "comments",
                            [
                                2,
                                [
                                    1,
                                    "id",
                                    0,
                                    "authorId",
                                    0,
                                    "body",
                                    0,
                                    "createdAt",
                                    0
                                ]
                            ]
                        ]
                    ]
                ],
                "path",
                0
            ],
            attach: __exactAttachClientComponent_1,
            receive: __exactReceiveClientProps_1,
            dispose: __exactDisposeClientComponent_1
        },
        resumption: {
            componentId: "xwG3ifFGDqfbDVf8eBrb1XP",
            statePaths: [
                "draft",
                "incidents",
                "job.id",
                "selectedId",
                "sessionUserId",
                "viewedVersion"
            ],
            stateInputs: [],
            valueCaptures: [],
            contexts: [],
            boundaries: [],
            continuations: [
                "xNsle0a4zj4xcqcOmdEcWQY",
                "xaRvMhU-X1O6r21Nwx6UdUz",
                "xcURjiQJHbVoocCJ_AFHlhZ",
                "xv3VvmP-iKfLWl3b5QE7NBY"
            ]
        }
    }
}) as typeof __exactImplementation_NativeIncidentWorkspace_1)();
function incidentIdFromPath(path: string) {
    return path.match(/^\/incidents\/([^/]+)$/)?.[1] ?? '';
}
function copyIncident(incident: WorkspaceState['incidents'][number]) {
    return { ...incident, comments: incident.comments.map((entry) => ({ ...entry })) };
}
//# sourceMappingURL=App.exact.client.ts.map
