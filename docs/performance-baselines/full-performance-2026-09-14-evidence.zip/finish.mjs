import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync,readFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
const root=resolve('.'),output=resolve('.tmp/full-performance-2026-09-14'),suite=resolve('framework-comparison');
const journal=existsSync(`${output}/publication-checks.json`)?JSON.parse(readFileSync(`${output}/publication-checks.json`)):[];
process.env.NODE_ENV='production';process.env.COMPARISON_SSR_RENDER_MODE='string';
async function run(name,args,cwd=root,env={}) {
 if(journal.some(s=>s.name===name&&s.code===0)){console.log('RETAIN '+name);return;}
 const step={name,args,cwd,env,startedAt:new Date().toISOString()};journal.push(step);
 const save=()=>writeFileSync(`${output}/publication-checks.json`,JSON.stringify(journal,null,2));save();console.log('START '+name);
 const log=openSync(`${output}/${name}.log`,'w');
 try{await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{cwd,env:{...process.env,...env},stdio:['ignore',log,log],windowsHide:true});step.pid=child.pid;save();child.once('error',fail);child.once('exit',(code,signal)=>{step.code=code;step.signal=signal;code===0?done():fail(Error(`${name} failed: ${code??signal}`));});});}
 finally{closeSync(log);step.endedAt=new Date().toISOString();save();}console.log('DONE '+name);
}
const npm=resolve(process.execPath,'..','node_modules/npm/bin/npm-cli.js');
await run('verify-artifacts',[output+'/verify-artifacts.mjs']);
await run('publish-charts',[output+'/publish.mjs']);
await run('write-report',[output+'/write-report.mjs']);
await run('format-reports',['node_modules/prettier/bin/prettier.cjs','--write','docs/performance-baselines/full-performance-2026-09-14.md','docs/performance.md','apps/docs/src/data/*.json']);
await run('comparison-tests',[npm,'run','test:framework-comparison'],root,{NODE_ENV:'test'});
await run('docs-tests',[npm,'run','test','-w','@exactjs/docs'],root,{NODE_ENV:'test'});
await run('docs-verify',[npm,'run','verify','-w','@exactjs/docs']);
await run('docs-browser',[output+'/verify-docs.mjs']);
console.log('COMPLETE chart publication checks');
