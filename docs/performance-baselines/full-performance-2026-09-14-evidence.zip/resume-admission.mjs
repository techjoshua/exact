import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync,readFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
const root=resolve('.'),output=resolve('.tmp/full-performance-2026-09-14'),suite=resolve('framework-comparison');
const journal=existsSync(`${output}/admission-resume.json`)?JSON.parse(readFileSync(`${output}/admission-resume.json`)):[];
process.env.NODE_ENV='test';process.env.EXACT_RELEASE_BUILT='1';process.env.COMPARISON_SSR_RENDER_MODE='string';
async function run(name,args,cwd=root,env={}) {
 if(journal.some(s=>s.name===name&&s.code===0)){console.log('RETAIN '+name);return;}
 const step={name,args,cwd,env,startedAt:new Date().toISOString()};journal.push(step);
 const save=()=>writeFileSync(`${output}/admission-resume.json`,JSON.stringify(journal,null,2));save();console.log('START '+name);
 const log=openSync(`${output}/${name}.log`,'w');
 try{await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{cwd,env:{...process.env,...env},stdio:['ignore',log,log],windowsHide:true});step.pid=child.pid;save();child.once('error',fail);child.once('exit',(code,signal)=>{step.code=code;step.signal=signal;code===0?done():fail(Error(`${name} failed: ${code??signal}`));});});}
 finally{closeSync(log);step.endedAt=new Date().toISOString();save();}console.log('DONE '+name);
}
const npm=resolve(process.execPath,'..','node_modules/npm/bin/npm-cli.js');
await run('application-tests',[npm,'run','test:apps']);
await run('test-typecheck',[npm,'run','typecheck:tests']);
await run('react-compatibility',[npm,'run','check:react-compat:built']);
await run('r3f-browser',[npm,'run','check:r3f-browser:built']);
await run('router-v63',[npm,'run','test:router-v63']);
await run('theme-browser',[npm,'run','test:e2e:theme']);
await run('native-corpus',[npm,'run','check:native-compiler-corpus']);
await run('internal-performance',['scripts/release-check.mjs','--profile=performance'],root,{NODE_ENV:'production',NODE_OPTIONS:''});
console.log('COMPLETE remaining admission and internal benchmarks');
