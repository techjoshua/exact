import pathlib,json,hashlib,zipfile
d=pathlib.Path('.tmp/ssr-large-profile')
for runtime in ['node','bun']:
 rows=json.loads((d/f'direct-writer-real-siblings-{runtime}.json').read_text(encoding='utf-8'))
 assert len(rows)==3 and all(r['starts']==r['disposals']==2 and r['hostDepth']==0 for r in rows)
files=[d/n for n in ['direct-writer-real-siblings-build.mjs','direct-writer-real-siblings-audit.mjs','direct-writer-real-siblings-report.py','direct-writer-real-siblings-compile.json','direct-writer-real-siblings-fixture.mjs','direct-writer-real-siblings-entry.mjs','direct-writer-real-siblings-node.json','direct-writer-real-siblings-bun.json']]
files += [pathlib.Path(n) for n in ['docs/performance-baselines/direct-writer-real-siblings-2026-09-09.md','packages/core/src/tasks/server-component-execution.ts','packages/core/src/tasks/server-component-resources.ts','packages/core/src/tasks/server-task-readiness.ts']]
manifest={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=pathlib.Path('docs/performance-baselines/direct-writer-real-siblings-2026-09-09-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p).replace('\\','/'))
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified six real-task cases and archive hashes.')
