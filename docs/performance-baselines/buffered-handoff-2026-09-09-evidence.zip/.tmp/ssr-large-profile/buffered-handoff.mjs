import {createExactBufferedResponse} from '../../packages/server/dist/index.js';
import {writeNodeResponse} from '../../framework-adapters/node-adapter/dist/index.js';
import {writeFileSync} from 'node:fs';
const html='<!doctype html><html><head></head><body>'+ 'x'.repeat(3900)+'</body></html>';
const headers={'cache-control':'no-store','content-type':'text/html; charset=utf-8'};
let written=0;
const response={statusCode:200,setHeader(){},end(value){if(value!==html)throw Error('Output mismatch');written++;}};
const iterations=200000,rows=[];
for(let round=0;round<3;round++)for(const variant of round%2?['exact','direct']:['direct','exact']){
 const run=variant==='exact'?async()=>{await writeNodeResponse(response,createExactBufferedResponse(200,{...headers},html));}:async()=>{response.statusCode=200;for(const [name,value]of Object.entries({...headers}))response.setHeader(name,value);response.end(html);};
 for(let i=0;i<10000;i++)await run();
 const start=performance.now();for(let i=0;i<iterations;i++)await run();
 const row={round,variant,iterations,usPerHandoff:(performance.now()-start)*1000/iterations,node:process.version};rows.push(row);console.log(row);
}
if(written!==1260000)throw Error('Unexpected handoff count');
writeFileSync('.tmp/ssr-large-profile/buffered-handoff-results.json',JSON.stringify(rows,null,2));
