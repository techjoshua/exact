import hashlib,json,pathlib,zipfile
root=pathlib.Path('.');work=root/'.tmp/ssr-large-profile'
dest=root/'docs/performance-baselines/buffered-handoff-2026-09-09'
raw=work/'buffered-handoff-results.json'
dest.with_suffix('.json').write_bytes(raw.read_bytes())
files=[work/'buffered-handoff.mjs',raw,work/'buffered-handoff-report.py',dest.with_suffix('.md'),dest.with_suffix('.json')]
files+=list((root/'packages/server/dist').rglob('*.js'))+list((root/'framework-adapters/node-adapter/dist').rglob('*.js'))
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps({p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print('Verified',archive)
