import fs from 'node:fs';import {spawnSync} from 'node:child_process';import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
// This is a short post-timing diagnostic, invoked separately from measurements.
const rows=[];
for(const variant of ['control','candidate']){
 let source=fs.readFileSync(root+'flat-invocation-'+variant+'/server-entry.js','utf8');const prefix='function readPreparedServerRenderProgram(value) {';assert.equal(source.split(prefix).length,2);
 source='const auditInvocations=new Map();\n'+source.replace(prefix,prefix+'\n if(value && typeof value === "object" && PreparedServerRenderProgram in value) auditInvocations.set(value.program.id,value);');
 source+='\nexport function auditReadInvocations(){return [...auditInvocations.values()];}';
 const entry=root+'flat-invocation-'+variant+'-maps-entry.mjs';fs.writeFileSync(entry,source);
 const worker=root+'flat-invocation-'+variant+'-maps-worker.mjs';
 fs.writeFileSync(worker,`import fs from 'node:fs';import os from 'node:os';os.setPriority(0,10);import {renderParticipant,auditReadInvocations} from './flat-invocation-${variant}-maps-entry.mjs';\nconst data=JSON.parse(fs.readFileSync('.tmp/positional-leaves/data.json','utf8'));await renderParticipant(data,'/incidents/inc-101',{clientTags:'<script type="module" src="/assets/app.js"></script><link rel="stylesheet" href="/assets/app.css">'});const invocations=auditReadInvocations();const groups=[];for(const value of invocations){let group=groups.find(g=>%HaveSameMap(g[0],value));if(!group)groups.push(group=[]);group.push(value);}console.log(JSON.stringify({variant:'${variant}',programs:invocations.length,maps:groups.length,groups:groups.map(g=>({keys:Object.keys(g[0]),programs:g.map(v=>v.program.id)}))}));`);
 const result=spawnSync(process.execPath,['--allow-natives-syntax',worker],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});assert.equal(result.status,0,result.stderr);rows.push(JSON.parse(result.stdout));
}
fs.writeFileSync(root+'flat-invocation-maps.json',JSON.stringify(rows,null,2));console.log(rows.map(({variant,programs,maps})=>({variant,programs,maps})));
