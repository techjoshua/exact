import ts from 'typescript';import fs from 'node:fs';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';const raw=fs.readFileSync(root+'direct-execution-integrated/server-entry.js','utf8');assert.equal(createHash('sha256').update(raw).digest('hex'),'2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18');
const file=ts.createSourceFile('input.js',raw,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS),printer=ts.createPrinter();const prep=new Set(['prepareText','prepareChild','prepareComponent','prepareComponentProps','prepareAttribute']);const helpers=new Set(['prepareSsrText','prepareSsrChild','prepareSsrComponent','prepareSsrComponentProps','prepareSsrAttribute']);const counts={constructors:0,reads:0,preparations:0,helpers:0};
const transform=context=>{const f=context.factory;function visit(original){
 let n=ts.visitEachChild(original,visit,context);
 if(ts.isCallExpression(n)&&ts.isIdentifier(n.expression)&&n.expression.text==='createPreparedServerRenderProgram'){
 assert.equal(n.arguments.length,2);assert.ok(ts.isArrayLiteralExpression(n.arguments[1]));const vals=n.arguments[1].elements;assert.ok(vals.every(v=>!ts.isSpreadElement(v)&&!ts.isOmittedExpression(v)));counts.constructors++;
 return f.createObjectLiteralExpression([f.createPropertyAssignment(f.createComputedPropertyName(f.createIdentifier('PreparedServerRenderProgram')),f.createTrue()),f.createPropertyAssignment('program',n.arguments[0]),...vals.map((v,i)=>f.createPropertyAssignment('v'+i,v))],true);
 }
 if(ts.isElementAccessExpression(n)&&ts.isPropertyAccessExpression(n.expression)&&n.expression.name.text==='eagerValues'&&ts.isNumericLiteral(n.argumentExpression)){
 counts.reads++;return f.createPropertyAccessExpression(n.expression.expression,'v'+n.argumentExpression.text);
 }
 if(ts.isCallExpression(n)&&ts.isPropertyAccessExpression(n.expression)&&ts.isIdentifier(n.expression.expression)&&n.expression.expression.text==='__exactSsr'&&prep.has(n.expression.name.text)){
 assert.equal(n.arguments.length,2);assert.ok(ts.isNumericLiteral(n.arguments[1]));counts.preparations++;
 return f.updateCallExpression(n,n.expression,n.typeArguments,[f.createPropertyAccessExpression(n.arguments[0],'v'+n.arguments[1].text)]);
 }
 return n;
}return node=>ts.visitNode(node,visit);};
const result=ts.transform(file,[transform]);let candidate=printer.printFile(result.transformed[0]);result.dispose();
for(const helper of helpers){const prefix=`function ${helper}(invocation, index) {`;assert.equal(candidate.split(prefix).length,2);candidate=candidate.replace(prefix,`function ${helper}(input) {`);counts.helpers++;}
const read='const value = unwrap(invocation.eagerValues[index]);';assert.equal(candidate.split(read).length,6);candidate=candidate.replaceAll(read,'const value = unwrap(input);');assert.equal(counts.constructors,25);
const outputs={control:printer.printFile(file),candidate};const hashes={};for(const [name,text] of Object.entries(outputs)){const folder='flat-invocation-'+name;fs.mkdirSync(root+folder,{recursive:true});fs.writeFileSync(root+folder+'/server-entry.js',text);hashes[name]=createHash('sha256').update(text).digest('hex');}
fs.writeFileSync(root+'flat-invocation-build.json',JSON.stringify({counts,hashes},null,2));console.log({counts,hashes});
fs.writeFileSync(root+'flat-invocation-pressure.mjs',fs.readFileSync(root+'stateful-scope-pressure.mjs','utf8').replaceAll('stateful-scope','flat-invocation-candidate'));
let timing=fs.readFileSync(root+'leaf-output-flag-timing.mjs','utf8').replaceAll('leaf-output-flag','flat-invocation-candidate').replaceAll('direct-execution-integrated','flat-invocation-control').replaceAll('4bcbd9b946316fc32a70891d102f9f543d07b8eba20ba58cf2dc8569ecf5fa07',hashes.candidate).replaceAll('2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18',hashes.control);
fs.writeFileSync(root+'flat-invocation-timing.mjs',timing);
