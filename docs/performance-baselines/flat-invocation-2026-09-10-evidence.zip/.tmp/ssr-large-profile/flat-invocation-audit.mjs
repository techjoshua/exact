import ts from 'typescript';import fs from 'node:fs';
const file=ts.createSourceFile('input.js',fs.readFileSync('framework-comparison/participants/exact/dist-server/server-entry.js','utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);let calls=[];
function visit(n){if(ts.isCallExpression(n)&&n.expression.getText(file)==='createPreparedServerRenderProgram')calls.push({args:n.arguments.length,array:ts.isArrayLiteralExpression(n.arguments[1]),values:n.arguments[1].getText(file).slice(0,95)});ts.forEachChild(n,visit);}visit(file);console.log(JSON.stringify(calls,null,2));
