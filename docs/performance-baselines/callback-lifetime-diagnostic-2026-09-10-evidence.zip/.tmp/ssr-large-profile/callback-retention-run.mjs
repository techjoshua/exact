import fs from 'node:fs/promises';
import {createWriteStream} from 'node:fs';
import {finished} from 'node:stream/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {setPriority} from 'node:os';
import assert from 'node:assert/strict';
import {startSsrLoadProcess} from '../../framework-comparison/src/ssr-load-process-owner.mjs';
import {startSsrWorker,stopSsrWorker,controlSsrWorker} from '../../framework-comparison/src/ssr-worker-controller.mjs';
import {availableSsrRuntimes} from '../../framework-comparison/src/ssr-run-environment.mjs';
import {installDevelopmentProcessLifecycle} from '../../scripts/development-process-lifecycle.mjs';
setPriority(0,10);
const root='.tmp/ssr-large-profile/callback-retention/';await fs.mkdir(root,{recursive:true});
let source=await fs.readFile('framework-comparison/src/ssr-benchmark-worker.mjs','utf8');
source=source.replace(/from (['"])(\.[^'"]+)\1/g,(_,q,p)=>'from '+JSON.stringify(pathToFileURL(resolve('framework-comparison/src',p)).href))
 .replace("const suiteRoot = resolve(import.meta.dirname, '..');",'const suiteRoot = '+JSON.stringify(resolve('framework-comparison'))+';');
const old='writeJson(response, await renderOnlyDiagnostic(participant, url));';assert.equal(source.split(old).length,2);
source=source.replace(old,'writeJson(response, await participant.renderOnly(10000));');
source="import { setFlagsFromString } from 'node:v8';\n"+source;
const controlStart=source.indexOf('async function handleNodeControlRequest');
const insertAt=source.indexOf('\n\tif (pathname',controlStart);assert.ok(insertAt>controlStart);
source=source.slice(0,insertAt)+"\n if (pathname === '/__exact-benchmark/jit-start') { writeJson(response, {ok:true}); setImmediate(() => setFlagsFromString('--trace-opt --trace-deopt')); return; }\n"+source.slice(insertAt);
await fs.writeFile(root+'worker.mjs',source);
const runtime=availableSsrRuntimes('node')[0];
let worker,service,drivers=[],log;
const rows=[];
async function closeDrivers(){const owned=drivers;drivers=[];for(const d of owned)await d.close();}
async function close(){try{await closeDrivers();}finally{try{if(worker){await stopSsrWorker(worker);worker=undefined;}}finally{if(service){await service.close();service=undefined;}if(log){log.end();await finished(log);log=undefined;}}}}
const lifecycle=installDevelopmentProcessLifecycle({label:'HTTP JIT context diagnostic',close});
function lower(child){setPriority(child.pid,10);}
function phase(name){log.write('\nDIAGNOSTIC_PHASE '+name+'\n');}
async function load(durationMs,identity){try{
 for(let i=0;i<2;i++){const d=await startSsrLoadProcess('driver');drivers.push(d);lower(d.child);}
 for(const d of drivers)d.run({url:worker.url+'?__benchmarkPreloaded=true',contains:'Delayed fulfillment events',expectedIdentity:identity,maxInFlight:256,maxLagMs:50,timeoutMs:10000,stages:[{name:'load',mode:'concurrency',concurrency:16,durationMs}]});
 const result=await Promise.race([Promise.all(drivers.map(d=>d.result)),service.result]);
 for(const d of result)for(const s of d.stages)assert.ok(s.errors===0&&s.started===s.completed&&s.completed===s.valid);
 return result;
}finally{await closeDrivers();}}
try{for(const variant of ['unretained','retained']){ const id='exact'; const retain=variant==='retained';
 service=await startSsrLoadProcess('service');lower(service.child);
 worker=await startSsrWorker({runtime,participantId:id,transport:'node-http',workerPath:resolve(root+'worker.mjs'),workingDirectory:resolve('framework-comparison'),serviceUrl:service.url,environment:{EXACT_DIAGNOSTIC_RETAIN_CALLBACKS:retain?'1':'0',COMPARISON_EXACT_SERVER_ENTRY:resolve(root+'server-entry.js'),COMPARISON_SSR_RENDER_MODE:'string',COMPARISON_SSR_BOUNDED_TELEMETRY:'1',COMPARISON_CLIENT_TAGS:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'}});lower(worker.child);
 log=createWriteStream(root+variant+'.jit.log');worker.child.stdout.on('data',chunk=>log?.write(chunk));worker.child.stderr.on('data',chunk=>log?.write(chunk));
 await controlSsrWorker(worker,'jit-start');
 const body=Buffer.from(await (await fetch(worker.url+'?__benchmarkPreloaded=true')).arrayBuffer());
 const identity={bytes:body.length,hash:createHash('sha256').update(body).digest('hex')};
 phase('http-warmup');await load(10000,identity);
 phase('http-before-loop');const before=await controlSsrWorker(worker,'telemetry');const loadBefore=await load(5000,identity);const after=await controlSsrWorker(worker,'telemetry');
 phase('in-worker-render-loop');const loops=[];for(let i=0;i<5;i++)loops.push(await controlSsrWorker(worker,'render-only'));
 phase('http-after-loop');const beforeAfter=await controlSsrWorker(worker,'telemetry');const loadAfter=await load(5000,identity);const afterAfter=await controlSsrWorker(worker,'telemetry');
 phase('shutdown');rows.push({id,variant,identity,before,after,loadBefore,loops,beforeAfter,afterAfter,loadAfter});
 await close();await fs.writeFile(root+'capture.json',JSON.stringify(rows,null,2));console.log(variant,'completed');
}}finally{await close();lifecycle.dispose();}
