from pathlib import Path
base=Path('.tmp/ssr-large-profile')
source=(base/'http-jit-context-analyze.py').read_text()
source=source.replace(".tmp/ssr-large-profile/http-jit-context", ".tmp/ssr-large-profile/callback-retention").replace("row['id']", "row['variant']")
(base/'callback-retention-analyze.py').write_text(source)
