import fs from 'node:fs/promises';
import ts from 'typescript';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const base='.tmp/ssr-large-profile/',root=base+'callback-retention/';await fs.mkdir(root,{recursive:true});
const prior=JSON.parse(await fs.readFile(base+'http-jit-origin/origins.json','utf8')).find(r=>r.id==='exact');
const selected=new Map(prior.events.filter(e=>e.phase==='http-after-loop'&&e.origin?.url.endsWith('/participants/exact/dist-server/server-entry.js')&&e.origin.location.startsWith(' ')).map(e=>[`${e.origin.line}:${e.origin.column}`,e.origin]));
const source=await fs.readFile(base+'conditional-emission/server-entry.js','utf8');
const ast=ts.createSourceFile('server-entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const edits=[],sites=[];
function visit(n){
 if(ts.isArrowFunction(n)||ts.isFunctionExpression(n)){
  const p=ast.getLineAndCharacterOfPosition(n.getStart(ast));const key=`${p.line+1}:${p.character+1}`;
  if(selected.has(key)){
   const index=sites.length;sites.push({index,key,...selected.get(key)});selected.delete(key);
   edits.push({pos:n.getStart(ast),text:`auditRememberCallback(${index},(`},{pos:n.end,text:'))'});
  }
 }
 ts.forEachChild(n,visit);
}
visit(ast);assert.equal(selected.size,0,JSON.stringify([...selected.keys()]));
let changed=source;
for(const e of edits.sort((a,b)=>b.pos-a.pos))changed=changed.slice(0,e.pos)+e.text+changed.slice(e.pos);
changed=`const auditRetain = process.env.EXACT_DIAGNOSTIC_RETAIN_CALLBACKS === '1';\nconst auditCallbacks = new Array(${sites.length});\nfunction auditRememberCallback(index,fn){if(auditRetain)auditCallbacks[index]=fn;return fn;}\n`+changed;
await fs.writeFile(root+'server-entry.js',changed);await fs.writeFile(root+'sites.json',JSON.stringify(sites,null,2));
const fixture=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));
const control=await import(pathToFileURL(resolve(base+'conditional-emission/server-entry.js')));
const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
for(const flag of ['0','1']){
 process.env.EXACT_DIAGNOSTIC_RETAIN_CALLBACKS=flag;
 const mod=await import(pathToFileURL(resolve(root+'server-entry.js')).href+'?retain='+flag);
 for(let i=0;i<3;i++){
  const data=structuredClone(fixture);data.incidents[1].title=`Retention ${i} café <script>`;
  for(const mode of ['string','stream']){
   const render=async m=>mode==='string'?m.renderParticipant(data,'/incidents/inc-101',options):new Response(await m.renderParticipantStream(data,'/incidents/inc-101',options)).text();
   assert.equal(await render(mod),await render(control));
  }
 }
}
delete process.env.EXACT_DIAGNOSTIC_RETAIN_CALLBACKS;
console.log('Matched',sites.length,'callback sites; 12 output comparisons passed.');
let runner=await fs.readFile(base+'http-jit-context.mjs','utf8');
runner=runner.replaceAll('http-jit-context/','callback-retention/');
runner=runner.replace("for(const id of ['exact','react']){", "for(const variant of ['unretained','retained']){ const id='exact'; const retain=variant==='retained';");
runner=runner.replace("COMPARISON_SSR_RENDER_MODE:'string'", "EXACT_DIAGNOSTIC_RETAIN_CALLBACKS:retain?'1':'0',COMPARISON_EXACT_SERVER_ENTRY:resolve(root+'server-entry.js'),COMPARISON_SSR_RENDER_MODE:'string'");
runner=runner.replace("root+id+'.jit.log'", "root+variant+'.jit.log'").replace('rows.push({id,identity,', 'rows.push({id,variant,identity,').replace("console.log(id,'completed')", "console.log(variant,'completed')");
await fs.writeFile(base+'callback-retention-run.mjs',runner);
