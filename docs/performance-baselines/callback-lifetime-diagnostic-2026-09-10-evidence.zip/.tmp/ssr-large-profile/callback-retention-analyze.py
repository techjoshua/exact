from pathlib import Path
from collections import Counter
from statistics import mean,median
import json,re
base=Path('.tmp/ssr-large-profile/callback-retention')
capture=json.loads((base/'capture.json').read_text())
results=[]
for row in capture:
    phase='before-marker';events={}
    for line in (base/(row['variant']+'.jit.log')).read_text().splitlines():
        if line.startswith('DIAGNOSTIC_PHASE '):phase=line.split(' ',1)[1];continue
        kind='deopt' if '[bailout ' in line else 'optimized' if '[completed optimizing ' in line else None
        if not kind:continue
        function=re.search(r'<JSFunction (.*?) \(sfi',line)
        reason=re.search(r'reason: ([^)]+)\)',line)
        events.setdefault(phase,[]).append(dict(kind=kind,function=function.group(1) if function else '(unnamed)',reason=reason.group(1) if reason else '',line=line))
    phases={}
    for name,a,b in [('http-before-loop',row['before'],row['after']),('http-after-loop',row['beforeAfter'],row['afterAfter'])]:
        start=a['statistics']['renderMs'];end=b['statistics']['renderMs']
        phases[name]={'renderMeanUs':1000*(end['sum']-start['sum'])/(end['count']-start['count']), 'renders':end['count']-start['count']}
    loops=[{'meanUs':mean(v['samplesMs'])*1000,'medianUs':median(v['samplesMs'])*1000,'bytes':v['responseBytes']} for v in row['loops']]
    summary={p:{'deopts':sum(e['kind']=='deopt' for e in es),'optimized':sum(e['kind']=='optimized' for e in es),'deoptFunctions':dict(Counter(e['function'] for e in es if e['kind']=='deopt'))} for p,es in events.items()}
    results.append(dict(id=row['variant'],phases=phases,loops=loops,summary=summary,events=events))
    print(row['variant'],json.dumps({'phases':phases,'loops':loops,'jit':summary},indent=2))
(base/'analysis.json').write_text(json.dumps(results,indent=2))
