import ctypes,sys,json
from ctypes import wintypes
pid,mask=map(int,sys.argv[1:]);assert pid>0 and mask>0
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];k.OpenProcess.restype=wintypes.HANDLE
k.GetProcessAffinityMask.argtypes=[wintypes.HANDLE,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)];k.GetProcessAffinityMask.restype=wintypes.BOOL
k.SetProcessAffinityMask.argtypes=[wintypes.HANDLE,ctypes.c_size_t];k.SetProcessAffinityMask.restype=wintypes.BOOL
k.CloseHandle.argtypes=[wintypes.HANDLE];k.CloseHandle.restype=wintypes.BOOL
h=k.OpenProcess(0x0200|0x0400,False,pid)
if not h:raise ctypes.WinError(ctypes.get_last_error())
try:
 old=ctypes.c_size_t();system=ctypes.c_size_t()
 if not k.GetProcessAffinityMask(h,ctypes.byref(old),ctypes.byref(system)):raise ctypes.WinError(ctypes.get_last_error())
 assert mask&system.value==mask
 if not k.SetProcessAffinityMask(h,mask):raise ctypes.WinError(ctypes.get_last_error())
 actual=ctypes.c_size_t()
 if not k.GetProcessAffinityMask(h,ctypes.byref(actual),ctypes.byref(system)):raise ctypes.WinError(ctypes.get_last_error())
 assert actual.value==mask
 print(json.dumps({'pid':pid,'previousMask':old.value,'mask':actual.value}))
finally:k.CloseHandle(h)
