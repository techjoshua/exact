import json,hashlib,zipfile
from pathlib import Path
from statistics import mean
root=Path('.tmp/ssr-large-profile');files=set();summaries={}
for name,expected in [('http-copied-path',8),('http-path-copy-cost',12)]:
    data=json.loads((root/name/'capture.json').read_text());assert data['complete'] and len(data['blocks'])==expected
    valid=0;summary=[]
    for block in data['blocks']:
        for result in block['results']:
            for s in result['stages']:
                assert s['errors']==0 and s['valid']==s['started']==s['completed'];valid+=s['valid']
    for population in [0,1]:
        for phase in sorted({b['phase'] for b in data['blocks']}):
            rows=[b for b in data['blocks'] if b['population']==population and b['phase']==phase]
            result={'population':population,'phase':phase,'rps':mean(b['rps'] for b in rows),'renderUs':mean(b['after']['telemetry']['statistics']['renderMs']['sum']*1000/b['after']['telemetry']['statistics']['renderMs']['count'] for b in rows)}
            if name=='http-copied-path':result['jsonUs']=sum(b['after']['regions']['regions']['auditNativeJson']['exclusiveMs'] for b in rows)*1000/sum(b['after']['regions']['samples'] for b in rows)
            summary.append(result)
    summaries[name]={'valid':valid,'summary':summary}
    (root/name/'summary.json').write_text(json.dumps(summaries[name],indent=2))
    for path in root.glob(name+'*'):
        if path.is_file():files.add(path)
        else:files.update(p for p in path.rglob('*') if p.is_file())
    for key in ['exact','react','worker']:
        item=data['artifacts'][key];p=Path(item['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'];files.add(p)
files.update([root/'copied-path-layout.log',root/'http-path-copy-report.py',Path('.tmp/positional-leaves/data.json')])
files={p.resolve().relative_to(Path.cwd()) for p in files}
archive=Path('docs/performance-baselines/http-path-copy-cost-2026-09-10-evidence.zip');assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files):z.write(p,p.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps(summaries,indent=2));print('Verified archive files:',len(files))
