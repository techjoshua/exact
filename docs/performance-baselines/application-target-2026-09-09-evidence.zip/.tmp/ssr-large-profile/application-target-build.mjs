import fs from 'node:fs';
const d='.tmp/ssr-large-profile/',dir=d+'application-string/';
let source=fs.readFileSync(dir+'string-sink-deferred.mjs','utf8');
function replace(a,b){if(source.split(a).length!==2)throw Error('Missing '+a);source=source.replace(a,b);}
replace(`renderPreparedServerProgram(program) {
 return renderDirectWriter(this.context,program,(segment)=>this.renderProgramSegment(segment),
  references=>prepareDirectScheduledSsrComponentReferences(this.context,references,this.parent,this.options));
 }`,`renderPreparedServerProgram(program) {
 return renderDirectWriter(this.context,program,this);
 }`);
replace('output.prepareReferences=prepareReferences;','output.prepareReferences=typeof render===\'function\'?prepareReferences:prepareWriterTargetReferences;');
replace('const rendered=output.render(value);',"const rendered=typeof output.render==='function'?output.render(value):output.render.renderProgramSegment(value);");
source+=`\nfunction prepareWriterTargetReferences(references){
 const target=this.render;
 return prepareDirectScheduledSsrComponentReferences(target.context,references,target.parent,target.options);
}\n`;
fs.writeFileSync(dir+'target-methods.mjs',source);
fs.writeFileSync(d+'application-target-run.mjs',fs.readFileSync(d+'application-leaf-run.mjs','utf8').replaceAll('leaf-callbacks','target-methods').replace('leaf-results.json','target-results.json'));
