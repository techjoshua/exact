import fs from 'node:fs';
const d='.tmp/ssr-large-profile/',dir=d+'application-string/';
let source=fs.readFileSync(dir+'string-sink-deferred.mjs','utf8');let programs=0,leaves=0;
source=source.replace(/ssr: function\(__exactSsr, __exactContext, __exactInvocation, __exactOutput\) \{([\s\S]*?)\n\t\},/g,(whole,body)=>{
 programs++;const childWork=/__exactSsr\.(?:child|keyedChild|component|directComponent)\(/.test(body);if(!childWork)leaves++;
 return 'ssrChildWork: '+childWork+',\n\t'+whole;
});
if(programs!==25||leaves!==14)throw Error('Unexpected writer classification '+JSON.stringify({programs,leaves}));
const site='renderPreparedServerProgram(program) {\n return renderDirectWriter';
if(source.split(site).length!==2)throw Error('Missing target');
source=source.replace(site,'renderPreparedServerProgram(program) {\n if(program.program.ssrChildWork===false)return renderDirectWriter(this.context,program);\n return renderDirectWriter');
const direct='return renderDirectWriter(context, content.program, (segment) => Array.isArray(segment) ? renderChildren(segment, parent) : renderOwnedComponent(segment, parent));';
if(source.split(direct).length!==2)throw Error('Missing direct content');
source=source.replace(direct,'if(content.program.program.ssrChildWork===false)return renderDirectWriter(context,content.program);\n '+direct);
fs.writeFileSync(dir+'leaf-callbacks.mjs',source);
fs.writeFileSync(dir+'leaf-build.json',JSON.stringify({programs,leaves},null,2));
let runner=fs.readFileSync(d+'application-string-deferred-run.mjs','utf8');
runner=runner.replaceAll("'current-production'","'string-sink-deferred'").replaceAll("'string-sink-deferred','string-sink-deferred'","'leaf-callbacks','string-sink-deferred'");
// Explicit reversed pairs retain the deferred-sink candidate as the sole control.
runner=runner.replace(/round\?\[[^\]]+\]:\[[^\]]+\]/,"round?['leaf-callbacks','string-sink-deferred']:['string-sink-deferred','leaf-callbacks']");
runner=runner.replace("dir+'deferred-results.json'","dir+'leaf-results.json'");
fs.writeFileSync(d+'application-leaf-run.mjs',runner);console.log({programs,leaves});
