import {SsrOutputLimitError} from '../../packages/ssr/dist/render/limits.js';

/** Experimental complete-string collector; byte validation precedes result publication. */
export class PublicationStringSink {
 #value='';#closed=false;#maxBytes;
 constructor({maxBytes=Infinity}={}){this.#maxBytes=maxBytes;}
 /** Rejects the UTF-16 lower bound before retaining more text; exact UTF-8 validation is final. */
 write(text){
  if(this.#closed)throw Error('Sink is closed');
  if(this.#value.length+text.length>this.#maxBytes){this.destroy();throw new SsrOutputLimitError(this.#maxBytes);}
  this.#value+=text;
 }
 /** String output does not wait for transport pressure. */
 ready(){return undefined;}
 /** Complete-string output has nothing to publish at a streaming flush boundary. */
 flush(){if(this.#closed)throw Error('Sink is closed');}
 /** Checks exact encoded size once before exposing a successful result. */
 finish(){
  if(this.#closed)throw Error('Sink is closed');
  const bytes=Buffer.byteLength(this.#value);
  if(bytes>this.#maxBytes){this.destroy();throw new SsrOutputLimitError(this.#maxBytes);}
  this.#closed=true;return bytes;
 }
 /** Retained UTF-16 result, valid for publication only after finish succeeds. */
 get value(){return this.#value;}
 /** Releases request-owned text on failure or after consumption. */
 destroy(){this.#value='';this.#closed=true;}
}
