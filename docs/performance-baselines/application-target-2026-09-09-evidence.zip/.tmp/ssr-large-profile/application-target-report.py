import pathlib,json,hashlib,zipfile
d=pathlib.Path('.tmp/ssr-large-profile');a=d/'application-string';v=d/'target-validation'
tables=[]
for name,candidate in [('leaf-results.json','leaf-callbacks'),('target-results.json','target-methods')]:
 rows=json.loads((a/name).read_text());assert len(rows)==16
 lines=[]
 for runtime in ['node','bun']:
  for scenario in ['assets','large']:
   cells=[]
   for pair in [0,1]:
    control=next(r for r in rows if r['runtimeId']==runtime and r['scenario']==scenario and r['round']==pair and r['variant']=='string-sink-deferred')
    changed=next(r for r in rows if r['runtimeId']==runtime and r['scenario']==scenario and r['round']==pair and r['variant']==candidate)
    assert control['hash']==changed['hash'];c=control['usPerRender'];n=changed['usPerRender'];cells.append(f'{c:.2f} / {n:.2f} ({(n/c-1)*100:+.2f}%)')
   lines.append(f'| {runtime} | {scenario} | '+' | '.join(cells)+' |')
 tables.append('\n'.join(lines))
validation=json.loads((v/'validation.json').read_text());assert len(validation)==6 and all(row['status']==0 for row in validation)
for runtime in ['node','bun']:
 audit=json.loads((a/f'target-audit-{runtime}.json').read_text());assert len(audit['rows'])==20 and audit['streamCases']==4
report=pathlib.Path('docs/performance-baselines/application-target-2026-09-09.md')
report.write_text('''# Removing direct-writer forwarding callbacks

Date: 2026-09-09. Retained prototype refinement; production unchanged.

Four Node CPU profiles compare current production with the deferred-string-sink direct writer,
using the actual comparison app at three and 96 incidents with four assets. The profiler starts
after 5,000 warmups and records 50,000 complete string renders. It includes profiler API overhead
around start/stop; it excludes module startup and warmup. Self-time samples are diagnostic, not
allocation measurements or a substitute for paired unprofiled timings.

The direct writer shows sampled work in renderDirectWriter and executePreparedDirectWriter,
while serialization and GC remain prominent in both implementations. Source inspection identifies
two forwarding closures created at each operation-target program call, including leaf programs
that never render a child or prepare a sibling. This supports experiments removing those closures;
profiles alone do not prove their exact cost.

## Leaf metadata experiment, not retained

The first candidate labels the 25 transformed programs according to child operations. Fourteen
leaf programs omit the otherwise-unused callbacks. Small cases improve, but large cases regress
in both pairs on both runtimes. No compiler metadata was added to production.

Times below are control / candidate microseconds, with percentage time change. Control is the
previous deferred-string-sink prototype, not production. Positive means slower.

| Runtime | Scenario | Pair 1 | Pair 2 |
| --- | --- | --- | --- |
'''+tables[0]+'''

## Direct target forwarding, retained in the prototype

Instead of metadata and per-leaf selection, the second candidate passes the existing operation
target to the writer. Deferred children call its existing renderProgramSegment method directly.
Sibling preparation uses one shared function whose receiver is the writer output; it reads the
target's context, parent, and options. Component-content callbacks retain their existing handling.
This removes the two operation-target forwarding closures without creating a second traversal
or changing preparation timing. It does not reuse request frames across components.

| Runtime | Scenario | Pair 1 | Pair 2 |
| --- | --- | --- | --- |
'''+tables[1]+'''

Both experiments use fresh production-mode Node 26.8.1/Bun 1.4.2 processes, 5,000 warmups and
12,000 measured string renders. Two reversed-order pairs per runtime/scenario retain all samples.
All paired complete-document hashes match, including the app shell, assets, and hydration.
No other builds or tests ran during timed measurements.

The target-forwarding candidate improves all eight pairs and is retained as the next integration
base. These modest gains do not establish a production win or React parity. The latest production
comparison remains the production-refresh report. Full compiler-native staging and broader
boundary integration remain outstanding.

## Ownership and output checks

Six Node/Bun scheduled-child cases cover success, failure before visiting the second child, and
cancellation with the task gate closed. Both tasks start and both children dispose once; host
state unwinds. These use compiler-generated child tasks and the existing controlled parent
program, exercising the new target preparation receiver.

Forty application budget cases compare the candidate with production across ASCII/hostile Unicode
and five limits. Eight consumed-stream cases match the corresponding production stream exactly.
The audit originally printed a fixed six-stream label inherited from a three-variant harness;
its counter now derives from the actual two variants, and the corrected audit passes. No browser
timing or new browser-adoption result is claimed for this candidate.

Raw profiles, summaries, both experiments, source transformations, application and lifecycle
audits, frozen artifacts and SHA-256 hashes are archived. The overall performance goal is incomplete.
''',encoding='utf8')
files=list(a.glob('*'))+list(v.glob('*'))
files += [d/n for n in ['application-string-profile.mjs','application-string-profile-summary.py','application-leaf-build.mjs','application-leaf-run.mjs','application-target-build.mjs','application-target-run.mjs','application-target-validation.mjs','application-target-report.py','application-string-deferred-sink.mjs','publication-string-sink.mjs','production-refresh-worker.mjs']]
files += [report,pathlib.Path('.tmp/positional-leaves/data.json')]
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
archive=report.with_name(report.stem+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name in manifest:z.write(name,name)
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(tables[1]);print('Verified 32 paired samples, ownership/output checks and',len(manifest),'archive hashes.')
