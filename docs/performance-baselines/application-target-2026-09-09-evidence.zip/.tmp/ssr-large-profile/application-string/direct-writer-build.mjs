import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/application-string/';
let source=readFileSync(dir+'shared-accumulator-ranges.mjs','utf8');
function replace(before,after){if(source.split(before).length!==2)throw Error('Unexpected site: '+before);source=source.replace(before,after);}
const counts={programs:0,continuations:0,childSites:0};
source=source.replace(/ssr: \(__exactSsr, __exactContext, __exactInvocation\) => \{([\s\S]*?return __exactOutput;\n\t\})/g,(_,body)=>{
 counts.programs++;
 const deferred=/__exactSsr\.(?:child|keyedChild|component|directComponent)\(/.test(body);
 if(deferred)counts.continuations++;
 if(!body.includes('const __exactOutput = __exactSsr.output();'))throw Error('Missing output declaration');
 body=body.replace('const __exactOutput = __exactSsr.output();','');
 body=body.replace(/__exactSsr\.(child|keyedChild|component|directComponent)\(/g,(_,method)=>{counts.childSites++;return 'yield __exactSsr.'+method+'(';});
 return 'ssr: '+(deferred?'function*':'function')+'(__exactSsr, __exactContext, __exactInvocation, __exactOutput) {'+body;
});
if(counts.programs<10||counts.continuations<1)throw Error('Missing generated programs');
replace('return renderProgramOutput(context, renderPreparedSsrProgram(context, content.program, parent).segments, (segment) => Array.isArray(segment) ? renderChildren(segment, parent) : renderOwnedComponent(segment, parent), content.program.program.ssrHost);',
 'return renderDirectWriter(context, content.program, (segment) => Array.isArray(segment) ? renderChildren(segment, parent) : renderOwnedComponent(segment, parent));');
const targetStart=source.indexOf('\trenderPreparedServerProgram(program) {');
const targetEnd=source.indexOf('\n\t/** Serializes one direct server reference',targetStart);
if(targetStart<0||targetEnd<0)throw Error('Missing operation target');
source=source.slice(0,targetStart)+`\trenderPreparedServerProgram(program) {
  return renderDirectWriter(this.context,program,(segment)=>{
   if(!Array.isArray(segment)&&receiptExecutionBlueprint(segment).contract.artifact.execution?.classification==='scheduled')throw Error('Prototype needs scheduled sibling preparation');
   return this.renderProgramSegment(segment);
  });
 }
`+source.slice(targetEnd);
replace('function renderPreparedSsrProgram(context, invocation, owner) {','function renderPreparedSsrProgram(context, invocation, owner) {\n throw Error("Unexpected buffered program execution in direct writer prototype");');
const appendStart=source.indexOf('function appendProgramText(output, html) {');
const appendEnd=source.indexOf('\n}',appendStart)+2;
if(appendStart<0||appendEnd<2)throw Error('Missing text append');
source=source.slice(0,appendStart)+`function appendProgramText(output,html){
 if(html!=='')appendSharedSink(output.context,output.sink,html);
}`+source.slice(appendEnd);
const childStart=source.indexOf('\tchild(opaqueContext, output, value, id, characters) {');
const childEnd=source.indexOf('\n\tattribute(opaqueContext, output, value, name, tag, characters)',childStart);
if(childStart<0||childEnd<0)throw Error('Missing deferred operations');
source=source.slice(0,childStart)+`
 child(context,output,value,id,characters){
  return writeDirectDeferred(context,output,normalizeRenderResult(value),id,characters,false);
 },
 keyedChild(output,value){
  return writeDirectDeferred(output.context,output,normalizeRenderResult(value),'',0,true);
 },
 component(context,output,value,id,characters,markerless){
  return writeDirectDeferred(context,output,value,id,characters,markerless);
 },
 directComponent(context,output,component,props,id,characters,markerless){
  return writeDirectDeferred(context,output,createPreparedServerComponentReference(component,props),id,characters,markerless);
 },`+source.slice(childEnd);
source+=`
// Experimental writer ABI: the fourth parameter owns output, instead of a segment array.
function renderDirectWriter(context,invocation,render){
 if(context.reactMarkup)throw Error('Native program cannot render React markup');
 if(context.enhancementOperationRoutes?.length)throw Error('Prototype needs explicit enhancement capture');
 const shared=context.experimentalSink;
 const output={context,sink:shared??{value:''},render,shared:!!shared};
 const host=invocation.program.ssrHost;
 if(host&&(host==='html'||host==='head'||host==='body'||context.documentRootSeen&&context.hostStack.at(-1)==='html')){
  const entered=enterHostTag(context,host);
  if(entered.prefix)appendProgramText(output,entered.prefix);
  return withRenderCleanup(()=>executeDirectWriter(invocation,output),()=>leaveHost(context,entered.tag));
 }
 if(host&&!context.hostStack.length)claimRootText(context);
 return executeDirectWriter(invocation,output);
}
function executeDirectWriter(invocation,output){
 const result=invocation.program.ssr(generatedSsrOperations,output.context,invocation,output);
 if(!result)throw Error('Generated direct writer rejected its input');
 if(typeof result.next==='function')return resumeDirectWriter(result,output,undefined);
 if(result!==output)throw Error('Unexpected generated writer result');
 return output.shared?'':output.sink.value;
}
function resumeDirectWriter(iterator,output,value){
 for(;;){
  const step=iterator.next(value);
  if(step.done){
   if(step.value!==output)throw Error('Generated direct writer rejected its input');
   return output.shared?'':output.sink.value;
  }
  value=step.value;
  if(value instanceof Promise)return value.then(
   settled=>resumeDirectWriter(iterator,output,settled),
   error=>{iterator.return();throw error;}
  );
 }
}
function writeDirectDeferred(context,output,value,id,characters,markerless){
 const marked=context.markers&&!markerless;
 const opening=marked?'<!--x:'+id+'-->':'';
 const closing=marked?'<!--/x:'+id+'-->':'';
 const next=characters+opening.length+closing.length;
 if(next>context.maxOutputBytes)throw new SsrOutputLimitError(context.maxOutputBytes);
 if(opening)appendProgramText(output,opening);
 const rendered=output.render(value);
 if(rendered instanceof Promise)return rendered.then(html=>finishDirectDeferred(output,html,closing,next));
 return finishDirectDeferred(output,rendered,closing,next);
}
function finishDirectDeferred(output,html,closing,next){
 if(html!=='')appendProgramText(output,html);
 if(closing)appendProgramText(output,closing);
 return next;
}
`;
writeFileSync(dir+'direct-writer.mjs',source);
writeFileSync(dir+'direct-writer-build.json',JSON.stringify(counts,null,2));
writeFileSync(dir+'direct-writer-run.mjs',readFileSync(dir+'map-fragment-run.mjs','utf8').replaceAll('map-fragment','direct-writer'));
console.log(counts);
