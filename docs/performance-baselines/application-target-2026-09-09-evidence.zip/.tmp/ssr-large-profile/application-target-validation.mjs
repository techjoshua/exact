import fs from 'node:fs';import {spawnSync} from 'node:child_process';
const root='.tmp/ssr-large-profile/',prior=root+'direct-current/',dir=root+'target-validation/';fs.mkdirSync(dir,{recursive:true});
fs.copyFileSync(root+'application-string/target-methods.mjs',dir+'target-methods.mjs');
for(const name of ['direct-writer-real-siblings-build','direct-writer-real-siblings-audit']){
 let source=fs.readFileSync(prior+name+'.mjs','utf8').replaceAll(prior,dir).replace("readFileSync(dir+'direct-writer-siblings.mjs'","readFileSync(dir+'target-methods.mjs'");
 fs.writeFileSync(dir+name+'.mjs',source);
}
const rows=[];
for(const [runtime,name] of [[process.execPath,'direct-writer-real-siblings-build'],['node','direct-writer-real-siblings-audit'],['bun','direct-writer-real-siblings-audit']]){
 const run=spawnSync(runtime,[dir+name+'.mjs'],{encoding:'utf8',windowsHide:true});rows.push({runtime,name,status:run.status,stdout:run.stdout,stderr:run.stderr});console.log(runtime,name,run.status,run.stdout.trim());
 if(run.status!==0)throw Error(run.stderr||run.stdout);
}
let appBuild=fs.readFileSync(root+'application-string-audit-build.mjs','utf8').replace("['current-production','string-sink-accounted','string-sink-deferred']","['target-methods']");
fs.writeFileSync(dir+'application-audit-build.mjs',appBuild);
let appAudit=fs.readFileSync(root+'application-string-audit.mjs','utf8').replace("['current-production','string-sink-accounted','string-sink-deferred']","['current-production','target-methods']").replace("'./application-string/'","'../application-string/'").replace('`audit-${','`target-audit-${');
fs.writeFileSync(dir+'application-audit.mjs',appAudit);
for(const [runtime,name] of [[process.execPath,'application-audit-build'],['node','application-audit'],['bun','application-audit']]){
 const run=spawnSync(runtime,[dir+name+'.mjs'],{encoding:'utf8',windowsHide:true});rows.push({runtime,name,status:run.status,stdout:run.stdout,stderr:run.stderr});console.log(runtime,name,run.status,run.stdout.trim());if(run.status!==0)throw Error(run.stderr||run.stdout);
}
fs.writeFileSync(dir+'validation.json',JSON.stringify(rows,null,2));
