import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
fs.writeFileSync(d+'application-string-deferred-audit.mjs',fs.readFileSync(d+'publication-string-audit.mjs','utf8').replace('./publication-string-sink.mjs','./application-string-deferred-sink.mjs'));
const dir=d+'application-string/';
for(const variant of ['target-methods']){
 let source=fs.readFileSync(dir+variant+'.mjs','utf8');
 source+='\nexport function auditRender(data,path,clientTags,options){return renderCompilerClosedToHydratableString(createPreparedServerComponentReference(Document,{initialData:data,path,clientTags}),{publishRootProps:true,...options});}\n';
 fs.writeFileSync(dir+variant+'-audit.mjs',source);
}
