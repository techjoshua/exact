import pathlib,json,collections
d=pathlib.Path('.tmp/ssr-large-profile/application-string');rows=[]
for path in d.glob('*.cpuprofile'):
 profile=json.loads(path.read_text());nodes={node['id']:node for node in profile['nodes']};weights=collections.Counter()
 for sample,delta in zip(profile['samples'],profile['timeDeltas']):
  frame=nodes[sample]['callFrame'];weights[(frame['functionName'],frame['url'],frame['lineNumber']+1)]+=delta
 total=sum(weights.values());top=[{'function':name,'url':url,'line':line,'milliseconds':value/1000,'percent':value*100/total} for (name,url,line),value in weights.most_common(25)]
 rows.append({'profile':path.name,'sampledMilliseconds':total/1000,'top':top});print(path.name,[(item['function'],round(item['percent'],1)) for item in top[:14]])
(d/'profile-summary.json').write_text(json.dumps(rows,indent=2))
