import fs from 'node:fs';import {spawnSync} from 'node:child_process';
const d='.tmp/ssr-large-profile/',dir=d+'application-string/';
let worker=fs.readFileSync(d+'production-refresh-worker.mjs','utf8');
worker="import {Session} from 'node:inspector';\n"+worker;
worker=worker.replace('const started=performance.now();',`const session=new Session();session.connect();
const send=(method)=>new Promise((resolve,reject)=>session.post(method,(error,result)=>error?reject(error):resolve(result)));
await send('Profiler.enable');await send('Profiler.start');
const started=performance.now();`);
worker=worker.replace('const elapsed=performance.now()-started;',`const elapsed=performance.now()-started;
const {profile}=await send('Profiler.stop');session.disconnect();
await writeFile(process.env.PROFILE_OUTPUT,JSON.stringify(profile));`);
fs.writeFileSync(dir+'profile-worker.mjs',worker);
const rows=[];
for(const scenario of ['assets','large'])for(const variant of ['current-production','string-sink-deferred']) {
 const run=spawnSync(process.execPath,[dir+'profile-worker.mjs',dir+variant+'.mjs','string',scenario,'50000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production',PROFILE_OUTPUT:dir+`${variant}-${scenario}.cpuprofile`}});
 if(run.status!==0)throw Error(run.stderr||run.stdout);
 rows.push({variant,...JSON.parse(run.stdout)});fs.writeFileSync(dir+'profile-results.json',JSON.stringify(rows,null,2));console.log(variant,scenario,rows.at(-1).usPerRender.toFixed(2));
}
