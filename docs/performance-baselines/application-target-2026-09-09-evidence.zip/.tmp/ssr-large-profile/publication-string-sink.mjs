import { SsrOutputBuffer } from '../../packages/ssr/dist/render/output-buffer.js';

/** Collects strings for the shared staged traversal without a byte encode/decode round trip. */
export class PublicationStringSink {
 #value = '';
 #closed = false;
 #ledger;

 /** Creates one request-owned collector with the existing UTF-8 output budget. */
 constructor({maxBytes = Infinity} = {}) {
  this.#ledger = new SsrOutputBuffer(maxBytes);
 }

 /** Accounts each incoming span once, retaining UTF-16 text until completion. */
 write(text) {
  if (this.#closed) throw new Error('Sink is closed');
  try {
   this.#ledger.accountKnown(text, Buffer.byteLength(text));
   this.#value += text;
  } catch (error) {
   this.destroy();
   throw error;
  }
 }

 /** String collection has no pending transport write. */
 ready() { return undefined; }

 /** Honors the shared sink interface without publishing a partial string. */
 flush() {
  if (this.#closed) throw new Error('Sink is closed');
 }

 /** Finalizes byte accounting and closes writes while retaining the completed result. */
 finish() {
  if (this.#closed) throw new Error('Sink is closed');
  try {
   const bytes = this.#ledger.encodedBytes();
   this.#closed = true;
   return bytes;
  } catch (error) {
   this.destroy();
   throw error;
  }
 }

 /** Reads the current text; the caller must finish before treating it as a complete document. */
 get value() { return this.#value; }

 /** Releases held text and prevents subsequent writes, including after failure. */
 destroy() { this.#value = ''; this.#closed = true; }
}
