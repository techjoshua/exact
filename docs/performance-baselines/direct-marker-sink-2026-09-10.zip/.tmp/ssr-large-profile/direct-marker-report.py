import pathlib, json, hashlib, zipfile
root=pathlib.Path.cwd(); d=root/'.tmp/ssr-large-profile'
rows=json.loads((d/'direct-marker-final-results.json').read_text()); assert len(rows)==48
lines=['# Direct marker sink experiment, 2026-09-10', '',
'Marker traversal now writes opening and closing spans to the active sink instead of capturing a subtree string. It respects opening and closing pressure and flushes before awaiting pending children. Completed resumption/refresh strings retain synchronous finalized wrapping. Client-island and server-slot wrappers capture their children locally to prevent children escaping the wrapper.', '',
'Hypothesis: removing subtree marker capture would reduce intermediate construction beyond the previous compiler-boundary condition change. The experiment does not establish a consistent speedup. Direct publication is retained as part of the shared sink architecture; performance remains unresolved.', '',
'Production Node 26.8.1, Bun 1.4.2, React 19.2.0. Each cell averages two fresh processes in reversed order, with 5,000 warmups and 12,000 measured renders per process. Both frameworks render complete application-owned documents with four asset tags. Streams are consumed completely. These are in-process timings, not HTTP throughput. Small documents contain three incidents and large documents 96. eXact complete-document hashes match the saved compiler-boundary control.', '',
'| Runtime | Mode | Document | Previous (µs) | Direct markers (µs) | React (µs) |',
'| --- | --- | --- | ---: | ---: | ---: |']
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['assets','large']:
   means=[sum(r['usPerRender'] for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['variant']==v)/2 for v in ['previous','direct','react']]
   lines.append(f'| {runtime} | {mode} | {scenario} | '+' | '.join(f'{x:.2f}' for x in means)+' |')
lines += ['', 'An earlier 48-process experiment preceded the final wrapper safeguards. Its raw results are also archived separately: Bun large streams went from 273.98 to 282.47 µs, React 265.67 µs. This possible regression prompted the final-build repeat above. Small differences on this shared workstation need further evidence; neither reduced GC nor an overall win is established.', '',
'Validation: package build, 318 SSR tests, repository test typecheck, focused ESLint, source architecture, platform boundaries, and package contents passed. Focused tests cover opening pressure before child execution, closing pressure before completion, pending-child flush, rejection without closing publication, and observing child settlement after flush failure. Existing compiled document tests compare HTML, hydration records, and cleanup against local capture. Client-boundary and keyed server-slot tests now assert that children remain inside their wrappers.', '',
'The final isolated application artifact includes wrapper safeguards and is the measured direct variant in the table. Raw samples, exact bundles, harnesses, and changed source are archived. Main comparison application outputs were not overwritten. No browser timing was run for this internal change; browser performance and full HTTP parity remain unproven. Native writer ABI migration and progressive public tree-to-transport integration remain unfinished.']
report=root/'docs/performance-baselines/direct-marker-sink-2026-09-10.md';report.write_text('\n'.join(lines)+'\n',encoding='utf8')
files=[d/n for n in ['direct-marker-run.mjs','direct-marker-results.json','direct-marker-final-run.mjs','direct-marker-final-results.json','direct-marker-report.py','production-refresh-worker.mjs']]
files += [root/r['entry'] for r in rows]+[d/'direct-marker-sink/server-entry.js']
files += [root/'packages/ssr/src'/p for p in ['markers.ts','boundaries.test.tsx','render/marker-sink.test.ts','render/operation-target.ts','render/boundaries.ts','render/server-handlers.ts','render/prepared-resumption-boundary.ts','render/resumption-boundary-capability.ts']]
with zipfile.ZipFile(report.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 hashes={}
 for p in dict.fromkeys(files):
  content=p.read_bytes(); name=p.relative_to(root).as_posix();hashes[name]=hashlib.sha256(content).hexdigest();z.writestr(name,content)
 z.writestr('sha256.json',json.dumps(hashes,indent=2))
print('\n'.join(lines[8:18]))
