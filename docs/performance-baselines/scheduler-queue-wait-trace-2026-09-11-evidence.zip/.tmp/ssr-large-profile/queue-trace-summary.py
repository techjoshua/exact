import json
from pathlib import Path
d=json.loads(Path('.tmp/ssr-large-profile/queue-trace-node/capture.json').read_text());assert d['complete']
for b in d['blocks']:
 t=b['after']['trace'];samples=t['samples'];tail=sorted(samples,key=lambda x:x['total'])[-max(1,len(samples)//20):]
 print(b['population']+1,b['id'],b['phase'],round(b['rps']), 'mean queue',round(t['queue']['mean'],2),'mean remaining',round(t['remaining']['mean'],2),'p99 queue',round(t['queue']['p99'],2),'p99 remaining',round(t['remaining']['p99'],2),'slow sample queue share',round(sum(x['queue'] for x in tail)/sum(x['total'] for x in tail)*100,1))
