from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'queue-trace-node';root.mkdir(exist_ok=True)
(root/'serial-scheduler.mjs').write_bytes((base/'serial-scheduler.mjs').read_bytes())
w=(base/'serial-backlog-node/worker.mjs').read_text()
w="import {createLoadHistogram} from 'file:///C:/Users/techj/Projects/eXact/framework-comparison/src/ssr-load-statistics.mjs';\nlet traceCount=0,traceSamples=[];const traceQueue=createLoadHistogram(),traceAfter=createLoadHistogram(),traceTotal=createLoadHistogram();\n"+w
old="const { renderParticipant, renderParticipantStream } = await import(pathToFileURL(entry).href);"
new="""const { renderParticipant: originalRender, renderParticipantStream } = await import(pathToFileURL(entry).href);
        async function renderParticipant(data,path,options){
          const started=performance.now();let waited=0;
          const gate=options.scheduleRender;
          const localOptions=gate?{...options,scheduleRender(signal){const queued=performance.now();return gate(signal).then(()=>{waited=performance.now()-queued;});}}:options;
          const result=await originalRender(data,path,localOptions);
          const total=performance.now()-started;traceQueue.record(waited);traceAfter.record(total-waited);traceTotal.record(total);
          if((traceCount++%64)===0&&traceSamples.length<8192)traceSamples.push({total,queue:waited,remaining:total-waited});
          return result;
        }"""
assert old in w;w=w.replace(old,new)
old='resetTelemetry(); audit={};auditScheduleCalls=0;'
assert old in w;w=w.replace(old,'resetTelemetry();traceCount=0;traceSamples=[];traceQueue.reset();traceAfter.reset();traceTotal.reset(); audit={};auditScheduleCalls=0;')
w=w.replace('audit,scheduleCalls:auditScheduleCalls','audit,trace:{count:traceCount,queue:traceQueue.snapshot(),remaining:traceAfter.snapshot(),total:traceTotal.snapshot(),samples:traceSamples},scheduleCalls:auditScheduleCalls')
(root/'worker.mjs').write_text(w)
r=(base/'serial-backlog-node-run.mjs').read_text().replace('serial-backlog-node/','queue-trace-node/').replace('large96-node-backlog-serial-turns','large96-node-queue-wait-trace')
(base/'queue-trace-node-run.mjs').write_text(r)
