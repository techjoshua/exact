import fs from 'node:fs/promises';
const root='.tmp/ssr-large-profile/';
const rows=JSON.parse(await fs.readFile(root+'hydration-phase-results.json','utf8'));
const summary=[];
for(const runtime of ['v26.8.1','1.4.2']){
 const selected=rows.filter(r=>r.runtime===runtime);
 const phases=selected.filter(r=>r.phases);
 const averages=Object.fromEntries(['normal','sampled'].map(variant=>{const group=selected.filter(r=>r.variant===variant);return [variant,group.reduce((sum,r)=>sum+r.usPerRender,0)/group.length];}));
 const phaseStats=phases[0].phases.phases.map((name,p)=>{
  const values=phases.flatMap(r=>r.phases.samples.filter((_,i)=>i%5===p).map(x=>x*1000)).sort((a,b)=>a-b);
  return {name,meanUs:values.reduce((sum,v)=>sum+v,0)/values.length,medianUs:values[Math.floor(values.length/2)],p90Us:values[Math.floor(values.length*.9)]};
 });
 summary.push({runtime,averages,phaseStats});
}
await fs.writeFile(root+'hydration-phase-summary.json',JSON.stringify(summary,null,2));
console.log(JSON.stringify(summary,null,2));
