import {readFileSync,writeFileSync} from 'node:fs';
const source=readFileSync('.tmp/ssr-large-profile/keyed-current.mjs','utf8');
let count=0;
const next=source.replace(/if \(!state\.validate\((cell\d+), depth \+ 1, state\)\) return state\.unsafe;/g,(_,cell)=>{count++;return `if ((typeof ${cell} === 'string' || typeof ${cell} === 'boolean' || ${cell} === null || typeof ${cell} === 'number' && Number.isFinite(${cell})) ? (++state.nodes > state.maxNodes || depth + 1 > state.maxDepth) : !state.validate(${cell}, depth + 1, state)) return state.unsafe;`;});
if(!count)throw Error('No primitive projectors');
writeFileSync('.tmp/ssr-large-profile/inline-primitives.mjs',next);console.log({count});
