import {readFileSync,writeFileSync} from 'node:fs';
const source=readFileSync('.tmp/ssr-large-profile/keyed-current.mjs','utf8');
const signature='function renderComponentReference(context, component, parent, options, hasComponentAncestor, omitCompilerOwnedBoundary = false, omitRootBoundary = false) {';
if(!source.includes(signature))throw Error('Missing component entry');
const branch=`
 const contract = receiptExecutionContract(component), artifact = contract.artifact, server = artifact.execution;
 if (!artifact.selection && !component.enhancement && server.lane === 'direct' && server.classification === 'synchronous' && server.mode === 'stateless' && server.render && !server.lifecycle && !context.onDirectComponentCreated && !context.onDirectComponentRendered && !context.onComponentAttemptCheckpoint && !context.onComponentAttemptRollback) {
  const componentId = componentMarkerId(context, component), documentProbe = context.documentProbe && context.hostStack.length === 0;
  return mapRenderValue(prepareComponentProps(serverComponentProps(component), server.deferredTaskProps, options.signal), props => {
   const issued = renderIssuedServerComponentChildren(context, options, () => inComponentDomain(context, () => server.render.call(statelessDirectSsrComponentFrame, props)), parent);
   return mapRenderValue(issued, content => {
    const write = () => mapRenderValue(renderDirectSsrContent(context, content.content, parent, (children, owner) => renderChildren(context, children, owner, options, true), (child, owner) => renderComponentReference(context, child, owner, options, true, true)), html => directComponentHtml(context, componentId, html, props, server.publication, false, documentProbe, hasComponentAncestor, omitCompilerOwnedBoundary, omitRootBoundary));
    return content.preparation ? withRenderCleanup(write, () => Promise.resolve(content.preparation[Symbol.asyncDispose]())) : write();
   });
  });
 }
`;
writeFileSync('.tmp/ssr-large-profile/component-boundary.mjs',source.replace(signature,signature+branch));
