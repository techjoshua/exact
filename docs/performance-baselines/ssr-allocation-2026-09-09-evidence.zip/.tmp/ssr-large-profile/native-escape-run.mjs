import {spawnSync} from 'node:child_process';import {readFileSync,writeFileSync} from 'node:fs';import {createHash} from 'node:crypto';
const rows=[],variants=['keyed-current','native-escape'];
for(const mode of ['string','stream'])for(const scenario of ['small','large','unicode'])for(let round=0;round<3;round++)for(const variant of (round===1?[...variants].reverse():variants)){
 const entry=`.tmp/ssr-large-profile/${variant}.mjs`;
 const r=spawnSync('bun',['.tmp/ssr-large-profile/long-worker.mjs',entry,mode,scenario,'14000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 const row={variant,round,runtimeId:'bun',artifactSha256:createHash('sha256').update(readFileSync(entry)).digest('hex'),...JSON.parse(r.stdout)};
 const peer=rows.find(x=>x.mode===mode&&x.scenario===scenario&&x.round===round);
 if(peer&&peer.hash!==row.hash)throw Error('Output changed');
 rows.push(row);console.log(mode,scenario,round,variant,row.usPerRender.toFixed(2));writeFileSync('.tmp/ssr-large-profile/native-escape-results.json',JSON.stringify(rows,null,2));
}
