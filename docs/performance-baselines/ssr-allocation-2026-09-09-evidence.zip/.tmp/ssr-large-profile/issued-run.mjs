import {spawnSync} from 'node:child_process';import {readFileSync,writeFileSync} from 'node:fs';import {createHash} from 'node:crypto';
const rows=[],variants=['marker-current','stable-issued','lazy-issued','filtered-issued'];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const scenario of ['small','large'])for(let round=0;round<2;round++)for(const variant of (round?[...variants].reverse():variants)){
 const entry=`.tmp/ssr-large-profile/${variant}.mjs`;
 const r=spawnSync(runtime,['.tmp/ssr-large-profile/long-worker.mjs',entry,mode,scenario,'14000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 const row={variant,round,runtimeId:runtime,artifactSha256:createHash('sha256').update(readFileSync(entry)).digest('hex'),...JSON.parse(r.stdout)};
 const peer=rows.find(x=>x.runtimeId===runtime&&x.mode===mode&&x.scenario===scenario&&x.round===round);
 if(peer&&peer.hash!==row.hash)throw Error('Output changed');
 rows.push(row);console.log(runtime,mode,scenario,round,variant,row.usPerRender.toFixed(2));writeFileSync('.tmp/ssr-large-profile/issued-results.json',JSON.stringify(rows,null,2));
}
