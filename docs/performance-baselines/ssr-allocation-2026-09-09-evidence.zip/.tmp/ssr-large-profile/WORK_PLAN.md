# Active SSR goal, 2026-09-09

Goal active: beat React across comparable Node/Bun string/stream. Do not declare complete after incremental gains. No subagents authorized. Preserve all compiled-document work and dirty tree.

Current baseline: baseline.mjs copied from current exact dist-server after compiled-document optimization. Prior compiled-document/baseline is older and MUST NOT be used as current baseline.

Fresh 8 large-document profiles in this directory, runs.json, summary.json, parents.mjs. Exact large-string gaps remain Node~300 vs React188 and Bun434 vs225 microseconds under profiling overhead. Do not publish profile timings as normal benchmarks.

Five isolated experiments, 48 populations each, 3 counterbalanced pairs Node/Bun x string/stream x small/large, 5000 iterations +2000 warmups:
- batch: combine adjacent static/text writes. Hypothesis5-15%large; actual0.5-3.5%large, small stream slightly worse. Not retained; compiler/ABI complexity not yet justified.
- bounded: root UTF8 upper-bound shortcut and no SsrOutputBuffer for no resource hints. Mostly neutral/slower; not retained.
- stateless: skip unused attempt/lifetime bookkeeping for compiler stateless, no lifecycle/hooks; retains descendant issuance/cleanup. Bun large string+5%, large stream+2.8%, small results worse. Implemented provisionally, needs longer combined-vs-rootprops comparison before retention.
- rootprops: compiler root object literal direct eager slot read, preserves individual attribute validation. Node +4-10%, Bun smallstring+3.5%, large neutral. Implemented.
- combined: Node string small+6%,large+1.2%; Node stream small-8.9%,large+6.4%; Bun string small+6.4%,large+5.1%; Bun stream small+1%,large+10.7%. Longer validation needed due Node smallstream regression.
All variants full raw output hashes identical to own baseline mode/scenario. React unchanged. Experimental scripts/bundles raw results retained.

Source changes now:
- native overlay jsx_render_program_ssr_lowering.go: root-attributes slot whose reader is ObjectLiteralExpression reads eagerValues[index], no prepareAttribute. All other slots unchanged.
- new jsx_render_program_ssr_lowering_test.go: root direct + nestedattr/text prep assertions.
- session_test.go: existing old emitted preparation assertion updated. Before copies under before/.
- packages/ssr/src/render/direct-component.ts: provisional stateless fast branch.
- packages/ssr/src/inspection.test.tsx: stateless observers success and failure rollback tests.
- docs/ssr-hydration.md engineering implementation notes appended.
Public semantics unchanged; public docs should not receive engineering diary. No ABI signature change.

Compiler: initial full overlay tests failed one obsolete session_test emitted-code assertion. Fixed. Native rebuild session89641 active, log compiler-final.log. Uses compiled-document/rebuild-native.mjs, changedoverlayGo files manually copied to .tmp/native-typescript-go/tsc/internal/exactcompiler first. Final build stamp must reflect exact stagedsource. No concurrent other jobs.

Next: finish native rebuild. Build/compile SSR, build exact comparison. Run SSR tests and production browser Node/Bun x string/stream (56). Longer baseline/rootprops-only/current/React comparison to determine stateless retention, focused HTTP once worthwhile. Continue experiments, especially avoiding unnecessary scheduled-reference filter/cleanup allocations for completed programs. Preserve one renderer, task issuance, cancellation, early shell, hydration/target semantics.


Update: native compiler rebuild completed, Go tests passed after updating one old generated-code expectation. SSR rebuilt and compiled; exact participant rebuilt (Node+Bun bundles). 274 SSR tests, test typecheck, and56 production browser tests passed. No correctness jobs remain running.

Active job: long renderer benchmark session24356. 96 populations, 18000 measured/5000warmup. Variants baseline, root-only-current, current, React; two workloads small/large;3rotatedrounds. Frozen current.mjs/current-bun.mjs from rebuilt source. root-only-current.mjs removes provisional stateless branch only. long-results.json grows. Node small stream now current median58.87 vsReact72.76, old shorter regression did not repeat. Node string small root-only35.72,current37.91,React26.73; large current~291 vsReact160. Must inspect finalrows before retention decision.

Prepared next experiments, NOT running:
- allocation-run.mjs: current vs stateless-separated (same stateless optimization but branch/helper outside main closure), segments-current (remove result wrapper, filtered reference arrays and empty preparation arrays; skip absent cleanup boundary), packed-projectors (generated fixed object projectors validate existing cells then return array literal, no rule removal).
- Current source unchanged during timing. These are isolated bundles only. Run after long-run finishes and avoid overlapping heavy work.


Update2:
- Long96-population benchmark complete. Current (rootprops+stateless) beats prior baseline medians in all8cells. Node string small37.91 vsReact26.73;large290.67vs160.78. Node stream small58.87vs72.76;large333.80vs429.25. Bun string small39.63vs35.69;large397.54vs230.95. Bun stream small59.29vs60.38;large460.89vs342.48. Goal not met.
- allocation-results.json complete80populations: stateless-separated, segment-wrapper/filter/lazy/cleanup combo, packedprojectors, hoistedescaperegex. Mixed/regressionsespeciallyBunlarge; NONE retained.
- scheduling-results.json complete40populations: separates segments-unwrapped, schedule-lazy, schedule-cleanup, direct-artifact. Mixed, NONEretained.
- metadata-results.json complete64populations: schedule-cleanup again, observer-snapshots onlywhenhooks, finite-classes precompiledliteralcombinationMap. FiniteclassesBunlargestring~7%gainbutNode~5%regression; othermixed. NONEretained.
- Heap diagnostic40klargeNode rendersperframework withGCbetween5kwindows: no sustainedretainedheapgrowth (exact~6.1MB,React~7.3MB). allocated field is END-OF-WINDOW liveheapbeforeGC, NOT a peak measurement. Sources/results heap-growth-*.
- keyed-results.json complete48populations (3pairs): runtime prototype reusesalreadycompiledprograminsteadkeyedwrapperafterkeyvalidation/Stringconversion. Rawhashidentical. Node large string+5.2%,large stream+5.1%;smallNode string-1.3%,smallstream+1.8%;Bunmostlysmall/neutral aggregate, individualpairs2of3usuallyfavorcandidate. Adopt compilerproof version forquality/avoidadditionalruntimebrandchecks andearlyProxyhastraps.

NEW SOURCE IN PROGRESS:
- core/component-abi/server-keyed-child.ts adds overload withthirdprogram:true proof, returns existingExactPreparedServerRenderProgram afterkeyvalidation+Stringcoercion. Generic2argcall retainswrapper; implementationdefaultfalsepreservesfunctionarity2. Typeonlyimport render-program.
- new core/component-abi/server-keyed-child.test.ts:programidentity,missingkeys,coerciononce/failure.
- native overlay jsx_collection_lowering.go marks onlyTargetServer calls tocompiler-generated preparedServerProgram withthirdtrue; component/generalkeyedvaluesunchanged. No extra helper imported.
- jsx_render_program_ssr_lowering_test.go new2caseproof test.
- engineeringdocs ssr-hydration/release-readinessupdatedinitial0.5 contract.
Corebuild+compilepassed. ACTIVE session34401 native rebuild afterstagecopy twoGo files; logkeyed-compiler.log. Firstroot/statelesssource remainsretained. No performancejobs running.
Next:finishnativebuild; build/compilecoreifneeded,SSR,comparison; core+SSRtests,typecheck,browser56,quality+ABIchecks. Freshpairedbaseline/current/ReactwithUnicodeandHTTP. ThencontinueSSRoptimizationgoal, notdone.

All benchmarkvariants isolated .mjs, Reactunchanged,fullrawoutputidentityverified. Onlyproductionchangesare rootbagprep,statelessbookkeeping,andnewkeyedproof inprogress. No agents authorized, no commits. No durable new report yet beyond .tmp WORK_PLAN/results; mustarchive/write docs/performance-baselines report andlinkdocs/performance beforefinishingthisstep. Prior compiled-document report remainsunchanged.

Potential compiler enhancementargument concern inspected: ordinary intrinsic planning rejects enhancements beforelowerRenderProgram, so do not assumebug fromunusedargumentbuilder branch. No change made.

Keyed test correction: initial fixture had no @exact key annotation, so it never exercised keyed lowering. The earlier comment aboutstateless-vsstatefullists was incomplete; idpropertyaloneisNOTthekeycontract. Fixture nowdeclares interfaceRowwith/**@exact key*/id andtests intrinsic vscomponentmap. Active nativebuild session26435, logkeyed-compiler-validated.log. Productioncodeunchangedsincethirdflagimplementation. LintpassedchangedTSfiles. PriorfailedGo logsretained.


Update after compaction: actual generated root-attribute optimization VERIFIED: baseline has24 prepareAttribute(invocation,0) calls; current and latest have0. Prior root-only/current classifications remain valid. New keyed flag initially absent because map callback body was parenthesized. Fixed compiler proof with existing unwrapRenderExpression; regression now parenthesized event-bearing intrinsic vsparenthesized component. Native Go tests/buildpassed, apprebuilt, actual Node+Bun incident/comment calls have true. Frozen keyed-current.mjs/keyed-current-bun.mjs. 251core,274SSRtests,testtypecheck,sourcearchitecturepassed. All56productionbrowsercheckspassedafterkeyed.
New isolated component-boundary.mjs removesunusedgenericexecution/publication/snapshotobjectsforunobservedstatelesscomponents, retainspropsprep,domain,descendantissuer,cleanup,sharedcontentrenderer. New json-escape.mjs combines3postJSONescapingpasses. Active boundary-run80populations (2orders,current,keyed-current,boundary,jsonescape,React,8cells),12kmeasured+5kwarm. EarlyNode large strings boundary191vskeyed202vsReact129us; Bunresultsnotcomplete. Neithernewvariantretainedyet. Reactfixtureinlinesseverityspan,exacthasSeverityBadgeperrow: potentiallegitimateframeworkboundaryoverhead, applicationsunchanged.
Next queued inline-primitives-build.mjs generatesruntimeprototypeofinlinedcommonprimitivevalidationwithinexistingpositionalprojectors; preservesnode/depthchecksandfallbackobjects. Hypothesis3-8percentlarge. Notrunyet, nobenchmarkconcurrency. Sourcechangedonlyparenthesesproofsincelastbuild; no sourceeditswhiletiming.


Latest: Boundary80pop, primitive72pop, nativeescape36pop, leaf72pop completed. Boundary/stringJSON/primitive/nativeescape NOTretained mixed/regressions. Leafdirectstrings gainedseveralpercentstrings, streamingmixed; noABIexpansionadopted. Nativeescapeparity2662casespassedbutperfnotwin. HTTPretained24popcomplete0errors: Node stringbaseline7810/current7702/React10565;stream6459/6154/4107;Bunstring8525/8717/9843;stream6605/6622/6849. ThistableisBEFOREnewmarkerchange.
Newmarkerexperiment: unused-marker conditionalprototype thenreserved-marker lazyformatprototype48pop3pairs. LargeNode/Bunstrings~6-7percentfastermedian, Bunstreamexperimentimprovedtoo. PRODUCTIONimplementedcleanrecordversion: markers.ts formatMarkerId helper; component.ts capturescomponentName/componentKey BEFOREreservingordinal beforedescendants; direct-component-output.ts ownsComponentPublicationrecordandformatsonlywhenemittingboundary. OriginalregistryidentitymustbecapturedBEFORElazyselection; prototypepassedresolvedreferencebutproductionfixcapturesoriginalfields. Deletedobsoletecomponent-markers.ts +4generateddistoutputs. AddedlazyregistryassertionretainsfacadeID. Tests274SSR,typecheck,56productionbrowserpassedagain. Frozenmarker-current.mjs,marker-current-bun.mjsactualbuild.
AllreleaseABI/platform/packagecontents/JSDoc/any/docsverificationpassedBEFOREmarkerchange. Needfinalchecksaftermarker. Newengineeringdocs marker note; docs/performance-baselines/ssr-allocation-2026-09-09.md createdwitholdlongtable,allrejections,mixedHTTPtable; linkedfromdocs/performance.md. Durablearchive/jsonNOTYETCREATED. Evidence~11MB121filesbeforelatestprofiles; includeallrawJSONscriptsbundlesandcurrentdelta, actualReact19.2.0underframework-comparison/node_modules (rootReact18.3.1notbenchmark). Reactbundlesexternalimports, preservationmustretainartifactpathunderframework-comparisonorlockdependencies.
ACTIVEsession25468 marker-profile.mjs: Node/Bun x small/large xExact/React string,100kmeasuredsmall/20klarge+5000warm. Freshprofileaftermarkerfix. Nootherjobsrunning. Nextinspectprofiles; pairfinalsourceagainstkeyed-current/baseline/React; HTTPmarkercomparison neededwhenappropriate;sourcequalitycheck+archive. ContinuegoalNOTDONE, gapstoReactremain.


Consolidation: all timed work has completed; no task-owned processes remain. Final retained renderer 72 populations completed. Issued-layout and branch-issued experiments remain unretained due to mixed results. Direct fallback script was not executed. Final marker lint, architecture, JSDoc, explicit-any, platform, compiled ABI, frozen ABI, and package contents passed. Durable report now includes final renderer medians and explicitly distinguishes the older HTTP capture. Goal remains unmet. User reports iteration feels stuck; consolidate before selecting a substantial measured cost.
