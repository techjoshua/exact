﻿import {readFileSync} from 'node:fs';
for(const name of ['bun-exact-string','bun-exact-stream','node-exact-string']){
 const p=JSON.parse(readFileSync(`.tmp/ssr-large-profile/${name}.cpuprofile`,'utf8'));const nodes=new Map(p.nodes.map(n=>[n.id,n]));const parents=new Map();for(const n of p.nodes)for(const c of n.children??[])parents.set(c,n.id);const m=new Map();
 for(let i=0;i<p.samples.length;i++){let n=nodes.get(p.samples[i]);if(!['byteLength','escapeAttr','executeSsrProgram'].includes(n.callFrame.functionName))continue;const stack=[n.callFrame.functionName];for(let j=0;j<4;j++){n=nodes.get(parents.get(n.id));if(!n)break;stack.push((n.callFrame.functionName||'(anon)')+':'+(n.callFrame.lineNumber+1));}const k=stack.join(' <- ');m.set(k,(m.get(k)||0)+p.timeDeltas[i]);}console.log(name,[...m].sort((a,b)=>b[1]-a[1]).slice(0,12));
}
