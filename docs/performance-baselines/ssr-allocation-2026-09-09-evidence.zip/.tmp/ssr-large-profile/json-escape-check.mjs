import {readFileSync,writeFileSync} from 'node:fs';import assert from 'node:assert/strict';
for(const name of ['keyed-current','json-escape']){
 const source=readFileSync(`.tmp/ssr-large-profile/${name}.mjs`,'utf8');const start=source.indexOf('function serializeJson(payload, replacer) {'),end=source.indexOf('\n}',start)+2;
 const serialize=new Function(source.slice(start,end)+';return serializeJson;')();
 const value=['</script>', '\u2028\u2029', '\ud800', '&"', null, 0, {x:'<'}];
 assert.equal(serialize(value),JSON.stringify(value).replace(/</g,'\\u003C').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029'));
}
console.log('Escaping parity verified');
