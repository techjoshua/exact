import {spawnSync} from 'node:child_process';import {writeFileSync} from 'node:fs';
const rows=[],variants=['keyed-current','reserved-marker'];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const scenario of ['small','large'])for(let round=0;round<3;round++)for(const variant of (round === 1 ? [...variants].reverse() : variants)){
 const r=spawnSync(runtime,['.tmp/ssr-large-profile/long-worker.mjs',`.tmp/ssr-large-profile/${variant}.mjs`,mode,scenario,'14000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 const row={variant,round,runtimeId:runtime,...JSON.parse(r.stdout)};
 const peer=rows.find(x=>x.runtimeId===runtime&&x.mode===mode&&x.scenario===scenario&&x.round===round);
 if(peer&&peer.hash!==row.hash)throw Error('Output changed');
 rows.push(row);console.log(runtime,mode,scenario,round,variant,row.usPerRender.toFixed(2));writeFileSync('.tmp/ssr-large-profile/reserved-marker-results.json',JSON.stringify(rows,null,2));
}
