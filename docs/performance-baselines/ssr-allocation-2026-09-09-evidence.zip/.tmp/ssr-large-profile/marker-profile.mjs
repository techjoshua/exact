import {spawnSync} from 'node:child_process';import {writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile',rows=[];
for(const runtime of ['node','bun'])for(const scenario of ['small','large'])for(const variant of ['exact','react']){
 const name=`marker-${runtime}-${variant}-${scenario}`;
 const entry=variant==='exact'?`${dir}/marker-current.mjs`:'framework-comparison/participants/react/dist-server/server-entry.js';
 const iterations=scenario==='small'?'100000':'20000';
 const r=spawnSync(runtime,['--cpu-prof',`--cpu-prof-dir=${dir}`,`--cpu-prof-name=${name}.cpuprofile`,`${dir}/long-worker.mjs`,entry,'string',scenario,iterations],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 rows.push({name,...JSON.parse(r.stdout)});console.log(JSON.stringify(rows.at(-1)));writeFileSync(`${dir}/marker-profiles.json`,JSON.stringify(rows,null,2));
}
