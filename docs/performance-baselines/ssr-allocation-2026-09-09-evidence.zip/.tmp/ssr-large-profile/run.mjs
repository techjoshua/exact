import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile',rows=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const variant of ['exact','react']){
 const name=`${runtime}-${variant}-${mode}`;
 const entry=`framework-comparison/participants/${variant}/dist-server/server-entry.js`;
 const r=spawnSync(runtime,['--cpu-prof',`--cpu-prof-dir=${dir}`,`--cpu-prof-name=${name}.cpuprofile`,'.tmp/compiled-document/renderer-worker.mjs',entry,mode,'large','20000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 rows.push({name,...JSON.parse(r.stdout)});console.log(JSON.stringify(rows.at(-1)));writeFileSync(`${dir}/runs.json`,JSON.stringify(rows,null,2));
}
