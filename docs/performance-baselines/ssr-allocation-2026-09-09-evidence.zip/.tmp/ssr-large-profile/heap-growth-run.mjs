import {spawnSync} from 'node:child_process';import {writeFileSync} from 'node:fs';
for(const variant of ['current','react']){
 const entry=variant==='react'?'framework-comparison/participants/react/dist-server/server-entry.js':'.tmp/ssr-large-profile/current.mjs';
 const r=spawnSync(process.execPath,['--expose-gc','.tmp/ssr-large-profile/heap-growth-worker.mjs',entry],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);writeFileSync(`.tmp/ssr-large-profile/heap-growth-${variant}.json`,r.stdout);const result=JSON.parse(r.stdout);console.log(variant,result.windows.map(w=>({us:w.usPerRender,retained:w.after.heapUsed,peak:w.allocated.heapUsed})));
}
