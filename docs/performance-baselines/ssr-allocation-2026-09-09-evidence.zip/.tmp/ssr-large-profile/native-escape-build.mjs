import {readFileSync,writeFileSync} from 'node:fs';
const source=readFileSync('.tmp/ssr-large-profile/keyed-current.mjs','utf8');
const replace=(s,name,code)=>{const start=s.indexOf(`function ${name}(value) {`),end=s.indexOf('\n}',start)+2;if(start<0||end<start)throw Error(name);return s.slice(0,start)+code+s.slice(end);};
let out=replace(source,'escapeText',String.raw`function escapeText(value) {
 if (globalThis.Bun && !/["']/.test(value)) return Bun.escapeHTML(value);
 return /[&<>]/.test(value) ? value.replace(/[&<>]/g, escapeHtmlCharacter) : value;
}`);
out=replace(out,'escapeAttr',String.raw`function escapeAttr(value) {
 if (globalThis.Bun && !value.includes("'")) return Bun.escapeHTML(value);
 return /[&<>"]/.test(value) ? value.replace(/[&<>"]/g, escapeHtmlCharacter) : value;
}`);
writeFileSync('.tmp/ssr-large-profile/native-escape.mjs',out);
