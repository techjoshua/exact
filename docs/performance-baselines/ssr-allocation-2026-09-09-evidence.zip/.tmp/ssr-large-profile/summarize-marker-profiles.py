from pathlib import Path
from collections import defaultdict
import json
root=Path('.tmp/ssr-large-profile');result={}
for path in root.glob('marker-*.cpuprofile'):
 p=json.loads(path.read_text(encoding='utf-8'));nodes={n['id']:n for n in p['nodes']};costs=defaultdict(float);total=sum(p['timeDeltas'])
 for ident,delta in zip(p['samples'],p['timeDeltas']):
  frame=nodes[ident]['callFrame'];key=(frame.get('functionName') or '(anonymous)',frame.get('url',''),frame.get('lineNumber',0)+1);costs[key]+=delta
 rows=[{'function':key[0],'url':key[1],'line':key[2],'percent':round(value/total*100,2),'sampledUs':value} for key,value in sorted(costs.items(),key=lambda kv:-kv[1])[:25]]
 result[path.stem]={'totalSampledUs':total,'top':rows};print(path.stem)
 for row in rows[:13]:print(row['percent'],row['function'],row['line'])
(root/'marker-profile-summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
