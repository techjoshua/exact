import {readFileSync,writeFileSync} from 'node:fs';
const source=readFileSync('.tmp/ssr-large-profile/keyed-current.mjs','utf8');
const start=source.indexOf('function serializeJson(payload, replacer) {'),end=source.indexOf('\n}',start)+2;
if(start<0||end<start)throw Error('Missing JSON serializer');
writeFileSync('.tmp/ssr-large-profile/json-escape.mjs',source.slice(0,start)+String.raw`function serializeJson(payload, replacer) {
 return JSON.stringify(payload, replacer).replace(/[<\u2028\u2029]/g, character => character === '<' ? '\\u003C' : character === '\u2028' ? '\\u2028' : '\\u2029');
}`+source.slice(end));
