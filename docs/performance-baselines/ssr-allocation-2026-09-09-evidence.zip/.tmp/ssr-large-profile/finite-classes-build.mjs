import ts from 'typescript';import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile';let source=readFileSync(`${dir}/current.mjs`,'utf8');
const sf=ts.createSourceFile('compiled.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);const plans=new Map();
function finite(node){
 if(ts.isParenthesizedExpression(node))return finite(node.expression);
 if(ts.isStringLiteral(node)||ts.isNoSubstitutionTemplateLiteral(node))return [node.text];
 if(ts.isConditionalExpression(node)){const a=finite(node.whenTrue),b=finite(node.whenFalse);return a&&b?[...new Set([...a,...b])]:undefined;}
 if(ts.isBinaryExpression(node)&&node.operatorToken.kind===ts.SyntaxKind.PlusToken){const a=finite(node.left),b=finite(node.right);if(a&&b&&a.length*b.length<=64)return [...new Set(a.flatMap(x=>b.map(y=>x+y)))];}
}
function visit(node){
 if(ts.isCallExpression(node)&&ts.isIdentifier(node.expression)&&node.expression.text==='createPreparedServerRenderProgram'){
  const [program,values]=node.arguments;
  if(ts.isIdentifier(program)&&values&&ts.isArrayLiteralExpression(values)){
   const bag=values.elements[0];if(bag&&ts.isObjectLiteralExpression(bag))for(const prop of bag.properties)if(ts.isPropertyAssignment(prop)&&prop.name.getText(sf)==='className'){
    const values=finite(prop.initializer);if(values&&values.length>1)plans.set(program.text,[...new Set([...(plans.get(program.text)||[]),...values])]);
   }
  }
 }
 ts.forEachChild(node,visit);
}
visit(sf);
const escape=s=>s.replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const added=[];
for(const [program,values]of plans){
 added.push(`if (${program}.ssrRootStatic?.[2]?.length === 1 && ${program}.ssrRootStatic[2][0][0] === 1 && ${program}.ssrRootStatic[2][0][1] === 'className') ${program}.ssrRootStatic[3] = new Map(${JSON.stringify(values.map(v=>[v,` class="${escape(v)}"`]))});`);
}
const needle='const effective = consumeTargetReceiptLayers(context, props);';
const replacement=needle+`
 if (effective === props && staticAttributes?.[3]) {
  const value=props.className;
  const html=(staticAttributes[0]??'')+(staticAttributes[3].get(value) ?? renderCompiledNativeAttribute(value,1,'className','class',tag,context));
  if(accounted)context.outputSink?.account(html);
  return html;
 }
`;
if(source.split(needle).length!==2)throw Error('Unexpected attribute function');source=source.replace(needle,replacement);
writeFileSync(`${dir}/finite-classes.mjs`,source+'\n'+added.join('\n'));
writeFileSync(`${dir}/finite-classes.json`,JSON.stringify([...plans],null,2));console.log([...plans].map(([name,v])=>[name,v.length]));
