import {readFileSync} from 'node:fs';import assert from 'node:assert/strict';
const funcs={};
for(const name of ['keyed-current','native-escape']){
 const source=readFileSync(`.tmp/ssr-large-profile/${name}.mjs`,'utf8');
 const fn=key=>{const start=source.indexOf(`function ${key}(`),end=source.indexOf('\n}',start)+2;return source.slice(start,end);};
 funcs[name]=new Function(fn('escapeHtmlCharacter')+';'+fn('escapeText')+';'+fn('escapeAttr')+';return {escapeText,escapeAttr};')();
}
const chars=['a','&','<','>','"',"'",'\u2028','\u00e9','\ud800','\udc00','\ud83d\ude80'];
for(const a of chars)for(const b of chars)for(const c of chars)for(const key of ['escapeText','escapeAttr'])assert.equal(funcs['native-escape'][key](a+b+c),funcs['keyed-current'][key](a+b+c),key+JSON.stringify(a+b+c));
console.log('Native escaping parity passed', chars.length**3*2);
