import {readFile} from 'node:fs/promises';import {pathToFileURL} from 'node:url';import {resolve} from 'node:path';
const [entry]=process.argv.slice(2);const mod=await import(pathToFileURL(resolve(entry)));
const data=JSON.parse(await readFile('.tmp/positional-leaves/data.json','utf8'));
data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
const render=()=>mod.renderParticipant(data,'/incidents/inc-101',{clientTags:''});let html;
for(let i=0;i<2000;i++)html=await render();
const windows=[];
for(let window=0;window<8;window++){
 global.gc();const before=process.memoryUsage();const start=performance.now();
 for(let i=0;i<5000;i++)html=await render();
 const elapsed=performance.now()-start;const allocated=process.memoryUsage();global.gc();const after=process.memoryUsage();
 windows.push({window,usPerRender:elapsed/5,before,allocated,after});
}
console.log(JSON.stringify({entry,bytes:Buffer.byteLength(html),windows}));
