import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile',source=readFileSync(`${dir}/marker-current.mjs`,'utf8');
const needle='inComponentDomain(context, () => server.render.call(frame, props))';if(!source.includes(needle))throw Error('Missing direct domain call');
const domain=source.replaceAll(needle,'prototypeCallInComponentDomain(context, server.render, frame, props)')+`
function prototypeCallInComponentDomain(context, work, receiver, argument) {
 if (!context.componentDomain) return work.call(receiver, argument);
 const previous = componentDomainRuntimeState.activeDomain;
 componentDomainRuntimeState.activeDomain = context.componentDomain;
 try { return work.call(receiver, argument); }
 finally { componentDomainRuntimeState.activeDomain = previous; }
}
`;
let fragment=source;
const start=fragment.indexOf('function directSsrMap('),end=fragment.indexOf('\n}',start)+2;if(start<0||end<start)throw Error('Missing frame map');
fragment=fragment.slice(0,start)+`function directSsrMap(collection, key, render, id) {
 const children = [...unwrap(collection)].map(item => createPreparedServerKeyedChild(render(item), key(item)));
 const rawKey = unwrap(id), fragmentKey = rawKey === null || rawKey === undefined ? undefined : String(rawKey);
 return { [prototypeServerFragment]: true, children, key: fragmentKey };
}`+fragment.slice(end);
const read='const keyed = readPreparedServerKeyedChild(child);';if(fragment.split(read).length!==2)throw Error('Child classifier');
fragment=fragment.replace(read,`if (typeof child === 'object' && child !== null && prototypeServerFragment in child) return mapRenderValue(target.renderDirectServerFragment(child), operationResult);\n\t${read}`);
const method='renderDirectServerChildRange(data) {';if(fragment.split(method).length!==2)throw Error('Range target');
fragment=fragment.replace(method,`renderDirectServerFragment(data) {
 return renderFragmentReceipt(this.context, data, this.parent, this.options, this.hasComponentAncestor, this.renderChildren);
 }
 ${method}`);
fragment+=`\nvar prototypeServerFragment = Symbol.for('@exactjs/server/prepared-fragment');\n`;
writeFileSync(`${dir}/direct-domain.mjs`,domain);writeFileSync(`${dir}/direct-fragment.mjs`,fragment);
const helper=domain.slice(domain.indexOf('\nfunction prototypeCallInComponentDomain'));
writeFileSync(`${dir}/direct-domain-fragment.mjs`,fragment.replaceAll(needle,'prototypeCallInComponentDomain(context, server.render, frame, props)')+helper);
console.log('domain calls',source.split(needle).length-1);
