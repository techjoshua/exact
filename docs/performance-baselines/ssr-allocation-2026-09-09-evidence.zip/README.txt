SSR investigation evidence, 2026-09-09
Reproduce from the repository root with locked workspace dependencies and Node 26.8.1 / Bun 1.4.2 on PATH.
Run node .tmp/ssr-large-profile/retained-renderer-run.mjs for the final renderer matrix. It sets production mode in child processes.
Both runtimes load the same portable Node-targeted participant artifacts in this matrix. HTTP and browser harnesses have their own runtime-specific entry points.
React imports must resolve to framework-comparison/node_modules React 19.2.0, not root React 18.3.1.
Experimental scripts include rejected and unexecuted variants. The report identifies retained changes. Historical failed logs are retained for auditability.
This is evidence plus source snapshots, not a standalone install or complete repository patch.
