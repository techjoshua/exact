import type { AnyComponentInstance } from '@exactjs/core';
import type { ExactComponentReceiptData } from '@exactjs/core/runtime/component-abi';
import type { SsrContext } from '../types.js';
import { renderChildren } from './children.js';
import type { DirectSsrComponentPublisher } from './direct-component-contracts.js';
import { directComponentHtml, type ComponentPublication } from './direct-component-output.js';
import type { SsrRenderOptions } from './entrypoints.js';
import { mapRenderValue, type RenderValue } from './execution.js';
import { renderServerComponentArtifactOutput } from './server-component-abi-execution.js';

const publishComponent: DirectSsrComponentPublisher<ComponentPublication> = (
	context,
	_component,
	_parent,
	html,
	props,
	snapshot,
	publication
) =>
	directComponentHtml(
		context,
		html,
		props,
		snapshot.contract.artifact.execution.publication,
		publication
	);

/** Renders one opaque component operation through its server artifact. */
export function renderComponentReference(
	context: SsrContext,
	component: ExactComponentReceiptData,
	parent: AnyComponentInstance | undefined,
	options: SsrRenderOptions,
	hasComponentAncestor: boolean,
	omitCompilerOwnedBoundary = false,
	omitRootBoundary = false
): RenderValue<string> {
	const output = renderServerComponentArtifactOutput(
		context,
		component,
		parent,
		options,
		(children, owner) => renderChildren(context, children, owner, options, true),
		(child, owner) => renderComponentReference(context, child, owner, options, true, true),
		publishComponent,
		{
			// Preserve the original registry identity before selection and reserve its
			// position before descendants, even when no marker will be published.
			componentName: component.contract.artifact.id,
			componentKey: component.key,
			componentOrdinal: context.nextId++,
			documentProbe: context.documentProbe && context.hostStack.length === 0,
			hasComponentAncestor,
			omitCompilerOwnedBoundary,
			omitRootBoundary
		}
	);
	return mapRenderValue(output, (value) => {
		if (value === undefined)
			throw new TypeError('Native component operation selected a non-direct server artifact');
		return value;
	});
}
