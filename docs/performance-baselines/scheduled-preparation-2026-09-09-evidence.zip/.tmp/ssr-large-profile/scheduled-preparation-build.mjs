import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const dir='.tmp/ssr-large-profile/';
const artifact=readFileSync('framework-comparison/participants/exact/dist-server/server-entry.js');
writeFileSync(dir+'scheduled-preparation-current.mjs',artifact);
writeFileSync(dir+'scheduled-preparation-run.mjs',readFileSync(dir+'map-fragment-run.mjs','utf8').replaceAll('map-fragment','scheduled-preparation-current').replaceAll('marker-hex-current','task-selection-opt-in-current'));
console.log(createHash('sha256').update(artifact).digest('hex'));
