import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
writeFileSync(dir+'scheduled-contract-generated-build.mjs',readFileSync(dir+'scheduled-preparation-build.mjs','utf8').replaceAll('scheduled-preparation','scheduled-contract'));
await import('./scheduled-contract-generated-build.mjs');
