import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const rows=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const scenario of ['small','large'])for(const variant of ['task-selection-opt-in-current','scheduled-preparation-current']){
 const r=spawnSync(runtime,['.tmp/ssr-large-profile/scheduled-preparation-audit-worker.mjs',variant,mode,scenario],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 const row={runtime,...JSON.parse(r.stdout)};
 const peer=rows.find(v=>v.runtime===runtime&&v.mode===mode&&v.scenario===scenario);
 if(peer){assert.equal(row.hash,peer.hash);assert.equal(row.calls,peer.calls);assert.equal(row.references,peer.references);assert.equal(row.filteredArrays,0);assert.equal(row.ownershipArrays,0);}
 rows.push(row);console.log(JSON.stringify(row));
}
writeFileSync('.tmp/ssr-large-profile/scheduled-preparation-audit-results.json',JSON.stringify(rows,null,2));
