import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
for(const variant of ['task-selection-opt-in-current','scheduled-preparation-current']){
 let source=readFileSync(dir+variant+'.mjs','utf8');
 const start=source.indexOf('function prepareDirectScheduledSsrComponentReferences(');
 const end=source.indexOf('function constructDirectScheduledSsrComponent(',start);
 if(start<0||end<0)throw Error('Missing scheduling module');
 let method=source.slice(start,end);
 method=method.replace(/\{\n/,`{\n preparationAudit.calls++;\n`);
 const old=variant==='task-selection-opt-in-current';
 if(old){
  if(!method.includes('const prepared = [];'))throw Error('Missing eager list');
  method=method.replace('const prepared = [];','const prepared = []; preparationAudit.ownershipArrays++;');
 }else{
  if(!method.includes('(prepared ??= []).push(record);'))throw Error('Missing lazy list');
  method=method.replace('(prepared ??= []).push(record);','if(!prepared)preparationAudit.ownershipArrays++; (prepared ??= []).push(record);');
 }
 method=method.replace('if (context.preparedDirectScheduledComponents?.has(reference))',
  'preparationAudit.references++;\n if (context.preparedDirectScheduledComponents?.has(reference))');
 source=source.slice(0,start)+method+source.slice(end);
 const filter='const references = planned.segments.filter(';
 if(old){
  if(source.split(filter).length!==2)throw Error('Missing filtered reference list');
  source=source.replace(filter,'preparationAudit.filteredArrays++;\n '+filter);
 }else if(source.includes(filter))throw Error('Filtered list remains');
 source+=`\nconst preparationAudit={calls:0,references:0,filteredArrays:0,ownershipArrays:0};
export function readPreparationAudit(){return {...preparationAudit};}\n`;
 writeFileSync(dir+variant+'-preparation-audit.mjs',source);
}
