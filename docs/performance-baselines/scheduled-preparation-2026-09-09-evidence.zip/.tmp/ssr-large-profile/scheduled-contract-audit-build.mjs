import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
let build=readFileSync(dir+'scheduled-preparation-audit-build.mjs','utf8')
 .replaceAll('scheduled-preparation-current','scheduled-contract-current')
 .replaceAll('-preparation-audit','-contract-audit')
 .replace('const preparationAudit={calls:0,references:0,filteredArrays:0,ownershipArrays:0}',
  'const preparationAudit={calls:0,references:0,filteredArrays:0,ownershipArrays:0,constructAttempts:0}')
 .replace('source=source.slice(0,start)+method+source.slice(end);',
  "method=method.replace('created = createDirectScheduledSsrComponent(', 'preparationAudit.constructAttempts++; created = createDirectScheduledSsrComponent(');\n source=source.slice(0,start)+method+source.slice(end);");
writeFileSync(dir+'scheduled-contract-audit-generated-build.mjs',build);
await import('./scheduled-contract-audit-generated-build.mjs');
writeFileSync(dir+'scheduled-contract-audit-worker.mjs',readFileSync(dir+'scheduled-preparation-audit-worker.mjs','utf8').replaceAll('-preparation-audit','-contract-audit'));
writeFileSync(dir+'scheduled-contract-audit-run.mjs',readFileSync(dir+'scheduled-preparation-audit-run.mjs','utf8').replaceAll('scheduled-preparation','scheduled-contract'));
