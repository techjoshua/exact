import assert from 'node:assert/strict';
import { PublicationByteSink as Control } from './publication-byte-sink.mjs';
import { PublicationByteSink as Candidate } from './incremental-publication-state-sink.mjs';

function render(Sink, fragments, threshold, maxBytes) {
 const chunks = [];
 const sink = new Sink((bytes, reason) => chunks.push([Buffer.from(bytes).toString('hex'), reason]), {threshold, maxBytes});
 try {
  for (let index = 0; index < fragments.length; index++) {
   sink.write(fragments[index]);
   if (index % 3 === 1) sink.flush('head');
  }
  return {chunks, bytes: sink.finish(), pending: sink.pendingCharacters};
 } catch (error) {
  assert.equal(sink.pendingCharacters, 0);
  assert.throws(() => sink.write('late'), /closed/);
  return {chunks, error: error.message};
 }
}
const input = '<html>é中😀\ud800a\udc00😃</html>';
let cases = 0;
for (const threshold of [1, 2, 3, 4, 8, 2048, 8192]) {
 for (let first = 0; first <= input.length; first++) {
  for (let second = first; second <= input.length; second++) {
   const fragments = [input.slice(0, first), '', input.slice(first, second), '', input.slice(second)];
   for (const maxBytes of [0, 8, Buffer.byteLength(input) - 1, Buffer.byteLength(input), Infinity]) {
    assert.deepEqual(render(Candidate, fragments, threshold, maxBytes), render(Control, fragments, threshold, maxBytes));
    cases++;
   }
  }
 }
}
console.log(JSON.stringify({runtime: process.versions, cases}));
