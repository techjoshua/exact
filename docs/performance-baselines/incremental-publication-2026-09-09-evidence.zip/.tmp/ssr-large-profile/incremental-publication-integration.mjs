import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
const base = new URL('./',import.meta.url);
const pressure=fs.readFileSync(new URL('publication-stages-sink.mjs',base),'utf8').replace('./publication-byte-sink.mjs','./incremental-publication-state-sink.mjs');
fs.writeFileSync(new URL('incremental-publication-pressure.mjs',base),pressure);
for(const suffix of ['audit','failure-audit']) {
 let source=fs.readFileSync(new URL(`hydration-tail-${suffix}.mjs`,base),'utf8');
 source=source.replaceAll('./publication-stages-sink.mjs','./incremental-publication-pressure.mjs');
 source=source.replaceAll('hydration-tail-failures-', 'incremental-hydration-tail-failures-');
 source=source.replaceAll("/hydration-tail-'", "/incremental-hydration-tail-'");
 const path=new URL(`incremental-hydration-tail-${suffix}.mjs`,base);
 fs.writeFileSync(path,source);
 for(const runtime of ['node','bun']) {
  const result=spawnSync(runtime,[path.pathname.replace(/^\/(\w:)/,'$1')],{encoding:'utf8',env:{...process.env,NODE_ENV:'production'}});
  if(result.status!==0)throw new Error(result.stderr||result.stdout);
  console.log(runtime,suffix,result.stdout.trim());
 }
}
