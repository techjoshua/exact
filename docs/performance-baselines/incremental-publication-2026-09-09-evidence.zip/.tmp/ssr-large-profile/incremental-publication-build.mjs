import fs from 'node:fs';
const base = new URL('./', import.meta.url);
let source = fs.readFileSync(new URL('publication-byte-sink.mjs', base), 'utf8');
function replace(from, to) {
 if (!source.includes(from)) throw new Error(`Missing input: ${from}`);
 source = source.replace(from, to);
}
replace("#pending='';#closed", "#pending='';#pendingBytes=0;#closed");
replace('this.#ledger.account(text);', `const bytes = Buffer.byteLength(text);
   this.#ledger.accountKnown(text, bytes);
   const previous = this.#pending.charCodeAt(this.#pending.length - 1);
   const first = text.charCodeAt(0);
   this.#pendingBytes += bytes;
   if (previous >= 0xd800 && previous <= 0xdbff && first >= 0xdc00 && first <= 0xdfff)
    this.#pendingBytes -= 2;`);
replace('Buffer.byteLength(this.#pending)>=this.#threshold', 'this.#pendingBytes>=this.#threshold');
replace('this.#pending=held;', 'this.#pending=held;this.#pendingBytes=held?3:0;');
replace("const tail=this.#pending;this.#pending='';", "const tail=this.#pending;this.#pending='';this.#pendingBytes=0;");
replace("destroy(){this.#pending='';", "destroy(){this.#pending='';this.#pendingBytes=0;");
fs.writeFileSync(new URL('incremental-publication-sink.mjs', base), source);
