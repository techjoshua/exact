import {SsrOutputBuffer} from '../../packages/ssr/dist/render/output-buffer.js';

/** Experimental synchronous byte publication with existing SSR limit accounting. */
export class PublicationByteSink {
 #pending='';#pendingBytes=0;#closed=false;#ledger;#publish;#threshold;#encoder=new TextEncoder();
 constructor(publish,{threshold=8192,maxBytes=Infinity}={}){
  if(!Number.isSafeInteger(threshold)||threshold<1)throw new RangeError('Invalid threshold');
  this.#publish=publish;this.#threshold=threshold;this.#ledger=new SsrOutputBuffer(maxBytes);
 }
 write(text){
  if(this.#closed)throw new Error('Sink is closed');
  try{
   const bytes = Buffer.byteLength(text);
   this.#ledger.accountKnown(text, bytes);
   const previous = this.#pending.charCodeAt(this.#pending.length - 1);
   const first = text.charCodeAt(0);
   this.#pendingBytes += bytes;
   if (previous >= 0xd800 && previous <= 0xdbff && first >= 0xdc00 && first <= 0xdfff)
    this.#pendingBytes -= 2;
   this.#pending+=text;
   if(this.#pendingBytes>=this.#threshold)this.flush('capacity');
  }catch(error){this.destroy();throw error;}
 }
 flush(reason='explicit'){
  if(this.#closed)throw new Error('Sink is closed');
  // Keep a trailing high surrogate until its following code unit or final completion is known.
  const last=this.#pending.charCodeAt(this.#pending.length-1);
  const held=last>=0xd800&&last<=0xdbff?this.#pending.slice(-1):'';
  const ready=held?this.#pending.slice(0,-1):this.#pending;
  this.#pending=held;this.#pendingBytes=held?3:0;
  if(!ready)return;
  try{this.#publish(this.#encoder.encode(ready),reason);}catch(error){this.destroy();throw error;}
 }
 finish(){
  if(this.#closed)throw new Error('Sink is closed');
  try{
   const bytes=this.#ledger.encodedBytes();
   const tail=this.#pending;this.#pending='';this.#pendingBytes=0;
   if(tail)this.#publish(this.#encoder.encode(tail),'finish');
   this.#closed=true;return bytes;
  }catch(error){this.destroy();throw error;}
 }
 destroy(){this.#pending='';this.#pendingBytes=0;this.#closed=true;}
 get pendingCharacters(){return this.#pending.length;}
}
