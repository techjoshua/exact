import pathlib, json, hashlib, zipfile

d = pathlib.Path('.tmp/ssr-large-profile')
rows = json.loads((d/'incremental-publication-state-results.json').read_text())
assert len(rows) == 32
lines = []
for runtime in ['node', 'bun']:
    for size in [3, 96]:
        for threshold in [2048, 8192]:
            values = [r for r in rows if r['runtimeName'] == runtime and r['size'] == size and r['threshold'] == threshold]
            control = [r['microseconds'] for r in values if r['variant'] == 'control']
            candidate = [r['microseconds'] for r in values if r['variant'] == 'candidate']
            assert len(control) == len(candidate) == 2
            assert len(set(r['checksum'] for r in values)) == 1
            lines.append(f'| {runtime} | {size} | {threshold} | {min(control):.2f} to {max(control):.2f} | {min(candidate):.2f} to {max(candidate):.2f} |')
report = pathlib.Path('docs/performance-baselines/incremental-publication-2026-09-09.md')
report.write_text('''# Incremental accounting in the direct-publication sink

Date: 2026-09-09. Experimental sink retained for further renderer integration. Production unchanged.

The hypothesis was that rescanning accumulated text at each flush-threshold check adds avoidable
work, especially with many short fragments and an 8 KB threshold. The first candidate counts each
incoming fragment once, shares its standalone count with the existing output ledger, and maintains
pending bytes with a correction for surrogate pairs spanning writes. Its results were mixed:
Node large/8 KB regressed in both pairs, while Bun large/8 KB improved. All measurements are retained.

Inspection identified another growing-string read in that candidate: charCodeAt on pending output
to identify the preceding surrogate. The second candidate instead retains that single state bit
across writes. This avoids examining accumulated output until publication. Results support the
hypothesis that repeated access to growing strings was expensive; they do not independently prove
the engine's internal flattening or allocation behavior.

## Focused sink measurements

Times are microseconds per synthetic document sent through the sink, not complete SSR or HTTP
requests. Both variants receive the same fragments and publish encoded chunks to a byte-counting
callback. The fixture contains an HTML shell and repeated seven-fragment incident rows. It does
not execute components, tasks, hydration serialization, or sockets. It uses ASCII and a non-ASCII
middle dot. Exact emitted bytes and failure behavior are checked separately by the differential audit.

Each cell has two reversed-order pairs in fresh production-mode processes, with 3,000 warmups
and 10,000 measured iterations per process. Node 26.8.1 and Bun 1.4.2. Ranges show both samples;
no completed sample is discarded. The second candidate is compared to the original sink.

| Runtime | Rows | Threshold bytes | Original us | Candidate us |
| --- | ---: | ---: | ---: | ---: |
''' + '\n'.join(lines) + '''

## Correctness and decision

Each candidate passes 9,660 differential cases on each runtime, including every two-split placement
in a mixed Unicode document, empty writes, explicit flushes, seven thresholds, and five output
budgets. Assertions compare exact emitted bytes, chunk boundaries, publication reasons, final
byte counts, and error messages. Failed sinks release pending text and reject further writes.
The unchanged ledger still owns output-limit enforcement and unpaired-surrogate finalization.

The second candidate also passes twelve compiled-tree hydration/cancellation cases and six
serializer, byte-budget, and blocked-publication failure cases across both runtimes. The existing
hydration validator and serializer remain in use. Markers are disabled in that controlled fixture;
this is not browser adoption coverage.

Retain the second candidate for direct-publication integration. Its 8 KB large-fixture sink cost
falls from about 229-234 to 23-24 us on Node and from 421-425 to about 20.5 us on Bun. These large
ratios describe removal of a prototype sink bottleneck, not improvement over the production
renderer or React. No public production implementation has changed, and no new React comparison
or browser timing was run. Complete renderer and transport measurements remain required.

The evidence archive retains both candidates, their original control, raw timings, differential
audits, staged hydration integration, and SHA-256 hashes. Reproduction requires built workspace
packages. The overall SSR performance objective remains incomplete.
''', encoding='utf-8')
files = list(d.glob('incremental-publication-*')) + list(d.glob('incremental-hydration-tail-*'))
files += [d/name for name in ['publication-byte-sink.mjs','hydration-tail-sink.mjs','hydration-tail-entry.mjs','hydration-tail-fixture.mjs']]
files += [report]
manifest = {p.as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
archive = report.with_name(report.stem+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name in manifest: z.write(name,name)
    z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    for name,digest in manifest.items(): assert hashlib.sha256(z.read(name)).hexdigest() == digest
print(report)
print('\n'.join(lines))
print(f'Verified {len(manifest)} archived files.')
