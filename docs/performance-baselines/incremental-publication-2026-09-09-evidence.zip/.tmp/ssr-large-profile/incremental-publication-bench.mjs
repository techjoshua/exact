import { PublicationByteSink as Control } from './publication-byte-sink.mjs';
import { PublicationByteSink as Candidate } from './incremental-publication-sink.mjs';
const [variant, size, thresholdText] = process.argv.slice(2);
const Sink = variant === 'control' ? Control : Candidate;
const threshold = Number(thresholdText);
const row = ['<li class="incident"><strong>', 'Incident 42', '</strong><small>', 'Open', ' · ', 'assigned to Joshua', '</small></li>'];
const fragments = ['<!doctype html><html><head></head><body>', ...Array.from({length: Number(size)}, () => row).flat(), '</body></html>'];
let checksum = 0;
function run() {
 const sink = new Sink(bytes => {checksum += bytes.length;}, {threshold});
 for (const value of fragments) sink.write(value);
 return sink.finish();
}
for (let i = 0; i < 3000; i++) run();
const count = 10000;
const start = performance.now();
for (let i = 0; i < count; i++) run();
console.log(JSON.stringify({variant, size: Number(size), threshold, microseconds: (performance.now()-start)*1000/count, checksum, runtime: process.versions}));
