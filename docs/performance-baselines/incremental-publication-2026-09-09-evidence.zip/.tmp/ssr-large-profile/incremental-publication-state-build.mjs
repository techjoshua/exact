import fs from 'node:fs';
const base=new URL('./',import.meta.url);
let source=fs.readFileSync(new URL('incremental-publication-sink.mjs',base),'utf8');
source=source.replace('#pendingBytes=0;#closed','#pendingBytes=0;#lastHigh=false;#closed');
source=source.replace('const previous = this.#pending.charCodeAt(this.#pending.length - 1);','const previousHigh = this.#lastHigh;');
source=source.replace('previous >= 0xd800 && previous <= 0xdbff && first >= 0xdc00','previousHigh && first >= 0xdc00');
source=source.replace('this.#pendingBytes -= 2;',`this.#pendingBytes -= 2;
   if (text.length) {
    const last = text.charCodeAt(text.length - 1);
    this.#lastHigh = last >= 0xd800 && last <= 0xdbff;
   }`);
source=source.replace("this.#pending='';this.#pendingBytes=0;", "this.#pending='';this.#pendingBytes=0;this.#lastHigh=false;");
source=source.replace("destroy(){this.#pending='';this.#pendingBytes=0;", "destroy(){this.#pending='';this.#pendingBytes=0;this.#lastHigh=false;");
fs.writeFileSync(new URL('incremental-publication-state-sink.mjs',base),source);
for(const suffix of ['audit','bench','run']) {
 let script=fs.readFileSync(new URL(`incremental-publication-${suffix}.mjs`,base),'utf8');
 script=script.replaceAll('incremental-publication-', 'incremental-publication-state-');
 fs.writeFileSync(new URL(`incremental-publication-state-${suffix}.mjs`,base),script);
}
