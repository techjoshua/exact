import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
const root = new URL('./', import.meta.url);
const results = [];
for (const runtime of ['node', 'bun']) {
 const audit = spawnSync(runtime, [new URL('incremental-publication-audit.mjs', root).pathname.replace(/^\/(\w:)/, '$1')], {encoding:'utf8', env:{...process.env, NODE_ENV:'production'}});
 if (audit.status !== 0) throw new Error(audit.stderr || audit.stdout);
 fs.writeFileSync(new URL(`incremental-publication-audit-${runtime}.json`,root),audit.stdout);
 for (const size of [3, 96]) for (const threshold of [2048, 8192]) for (let pair=0; pair<2; pair++) {
  for (const variant of pair ? ['candidate','control'] : ['control','candidate']) {
   const run = spawnSync(runtime, [new URL('incremental-publication-bench.mjs',root).pathname.replace(/^\/(\w:)/,'$1'),variant,String(size),String(threshold)], {encoding:'utf8',env:{...process.env,NODE_ENV:'production'}});
   if(run.status!==0) throw new Error(run.stderr || run.stdout);
   const result = {runtimeName:runtime,pair,...JSON.parse(run.stdout)};
   results.push(result);
   fs.writeFileSync(new URL('incremental-publication-results.json',root),JSON.stringify(results,null,2));
   console.log(JSON.stringify({runtime,pair,variant,size,threshold,us:result.microseconds}));
  }
 }
}
