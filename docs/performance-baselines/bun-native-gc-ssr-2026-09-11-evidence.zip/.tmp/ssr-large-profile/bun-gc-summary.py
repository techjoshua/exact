import json
from pathlib import Path
path=Path('.tmp/ssr-large-profile/bun-gc/capture.json');d=json.loads(path.read_text())
for b in d['blocks']:
 spans=[(x['endTime']-x['startTime'])*1000 for x in b['nativeGc']]
 print(b['population']+1,b['id'],b['phase'],round(b['rps']), 'native events',len(spans),'totalGCms',round(sum(spans),2),'maxGCms',round(max(spans,default=0),2),'GCus/request',round(sum(spans)*1000/b['valid'],2),'counts',{t:sum(x['type']==t for x in b['nativeGc']) for t in ('full','partial')},'heapMB',round(b['heapAfter']['heap']['heapSize']/1048576,2))
