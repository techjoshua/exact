from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'bun-gc';root.mkdir(exist_ok=True)
w=(base/'scheduler-large-profile/worker.mjs').read_text()
w="import {heapStats,memoryUsage} from 'bun:jsc';\n"+w
needle="if(pathname==='/__exact-benchmark/audit-stop')return jsonFetchResponse"
assert needle in w
w=w.replace(needle,"if(pathname==='/__exact-benchmark/audit-heap')return jsonFetchResponse({heap:heapStats(),memory:memoryUsage()});\n "+needle)
(root/'worker.mjs').write_text(w)
r=(base/'scheduler-large-profile-run.mjs').read_text().replace('scheduler-large-profile/','bun-gc/').replace('large96-bun-http-cpu-profiles','large96-bun-native-gc-events')
r="import {connectHeapInspector} from './bun-heap-inspector.mjs';\nlet inspector;\n"+r
old="runtime:{...runtime,arguments:[...runtime.arguments,'--cpu-prof','--cpu-prof-dir='+resolve(root),'--cpu-prof-name='+profileName]}"
assert old in r;r=r.replace(old,"runtime:{...runtime,arguments:[...runtime.arguments,'--inspect=127.0.0.1:0']}")
r=r.replace('async function close(){await closeDrivers();','async function close(){inspector?.close();inspector=undefined;await closeDrivers();')
needle='lower(service.child);lower(worker.child);';assert needle in r
r=r.replace(needle,needle+"\n  const inspectorUrl=worker.stderr().match(/ws:\\/\\/127\\.0\\.0\\.1:[^\\s]+/)[0];inspector=await connectHeapInspector(inspectorUrl);await inspector.send('Heap.enable');await inspector.send('Heap.gc');assert.ok(inspector.collections.length>0,'Native GC observer must see forced calibration');const calibration=inspector.collections.splice(0);\n")
r=r.replace('const before=await controlSsrWorker(worker,\'audit-start\');',"const heapBefore=await controlSsrWorker(worker,'audit-heap');inspector.collections.length=0;const before=await controlSsrWorker(worker,'audit-start');")
r=r.replace("const after=await controlSsrWorker(worker,'audit-stop');","const after=await controlSsrWorker(worker,'audit-stop');await inspector.send('Heap.disable');const nativeGc=inspector.collections.splice(0);const heapAfter=await controlSsrWorker(worker,'audit-heap');")
r=r.replace('let filename=profileName;','let filename;')
r=r.replace('report.blocks.push({mode,population,id,','report.blocks.push({calibration,nativeGc,heapBefore,heapAfter,mode,population,id,')
(base/'bun-gc-run.mjs').write_text(r)
