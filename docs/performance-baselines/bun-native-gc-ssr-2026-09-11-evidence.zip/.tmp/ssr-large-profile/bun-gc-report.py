import json,hashlib,zipfile
from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'bun-gc';d=json.loads((root/'capture.json').read_text());assert d['complete']
lines=['# Native Bun garbage-collection events during SSR','','Hypothesis: the large-document scheduling slowdown includes collection pressure that the generic performance observer failed to report. Six fresh native Bun workers run immediate eXact, scheduled eXact, and unchanged React, then reversed order. Each uses five seconds warmup and ten seconds measured HTTP load at concurrency 32. The full authored document and hydration are rendered per request.','',
'The loopback JSC inspector enables Heap events. A forced full collection before warmup verifies that each observer receives native events; calibration events are excluded. Events are cleared before the measured block and disabled after it. Heap snapshots of counters are taken outside the load interval. No collection is forced inside the measured interval. Inspector overhead affects these rates, so they do not replace uninstrumented throughput results.','',
'JSC exports the collection timestamps in seconds in [InspectorHeapAgent](https://github.com/WebKit/WebKit/blob/main/Source/JavaScriptCore/inspector/agents/InspectorHeapAgent.cpp); durations below convert to milliseconds. Bun exposes the events through its [Heap inspector protocol](https://github.com/oven-sh/bun/blob/main/packages/bun-inspector-protocol/src/protocol/jsc/protocol.json). GC event spans are elapsed intervals, not exclusive CPU costs, and cannot simply be subtracted from CPU profiles or response latency.','',
'| Repeat | Framework | Policy | RPS | Full GC | Partial GC | Total GC span (ms) | Max GC span (ms) | GC span per request (us) | Response p99 A / B (ms) |','| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |'];total=0
for b in d['blocks']:
 total+=b['valid'];assert b['calibration'];spans=[(x['endTime']-x['startTime'])*1000 for x in b['nativeGc']];assert all(v>=0 for v in spans)
 for r in b['results']:
  s=r['stages'][0];assert s['errors']==0 and s['started']==s['completed']==s['valid']
 assert b['after']['scheduleCalls']==(b['valid']+len(b['results']) if b['phase']=='scheduled' else 0)
 tails=' / '.join(f"{r['stages'][0]['distributions']['responseMs']['p99']:.3f}" for r in b['results'])
 full=sum(x['type']=='full' for x in b['nativeGc']);partial=sum(x['type']=='partial' for x in b['nativeGc'])
 lines.append(f"| {b['population']+1} | {b['id']} | {b['phase']} | {b['rps']:,.0f} | {full} | {partial} | {sum(spans):.2f} | {max(spans):.2f} | {sum(spans)*1000/b['valid']:.2f} | {tails} |")
lines+=['',f'{total:,} complete measured responses, zero errors. All native observers passed forced-GC calibration and all scheduling invocation guards pass.','',
'Scheduling increases full collections from 13-14 to 155-158 per measured eXact block, and GC span per request from approximately 45 us to 54-55 us. This supports an allocation-lifetime cost for scheduling the large fixture; it does not identify the exact retaining object or establish GC as the sole slowdown.','',
'Immediate eXact records about 45 us of GC span per request versus React 39-40 us. React has more collection events overall, not fewer. The remaining immediate-path gap therefore cannot be described as simply far more eXact collections. Avoiding key arrays and positional arrays already regressed measured throughput in separate experiments.','',
'Raw heap counters are retained, but they are not cumulative allocation rates. Bun documents that [heapSize and objectCount describe the last collection survivors while objectTypeCounts includes currently allocated objects](https://bun.sh/reference/bun/jsc/HeapStats). No live-heap delta is presented as total allocated bytes.','',
'The local node:inspector Session compatibility API rejected Heap.enable and HeapProfiler sampling commands. The successful capture uses the native WebSocket inspector with Heap.enable. This resolves the missing-observer evidence gap without modifying framework or React code. No production GC tuning, forced-collection policy, or allocation workaround is adopted.','']
report=Path('docs/performance-baselines/bun-native-gc-ssr-2026-09-11.md');assert not report.exists();report.write_text('\n'.join(lines)+'\n')
files=list(root.glob('*'))+[report,base/'bun-gc-build.py',base/'bun-gc-run.mjs',base/'bun-heap-inspector.mjs',base/'bun-gc-summary.py',base/'bun-gc-report.py'];archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists();manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print(total,'validated responses; archive verified')
