/** Owns a loopback JSC inspector connection and bounded command lifecycle. */
export async function connectHeapInspector(url){
 const socket=new WebSocket(url),pending=new Map(),collections=[];let sequence=0;
 await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Inspector connection timeout')),10000);socket.addEventListener('open',()=>{clearTimeout(timer);resolve();},{once:true});socket.addEventListener('error',()=>{clearTimeout(timer);reject(Error('Inspector connection failed'));},{once:true});});
 socket.addEventListener('message',event=>{
  const message=JSON.parse(event.data);
  if(message.method==='Heap.garbageCollected'){if(collections.length>=10000)throw Error('GC event capacity exceeded');collections.push(message.params.collection);}
  if(message.id){const record=pending.get(message.id);if(!record)return;pending.delete(message.id);clearTimeout(record.timer);message.error?record.reject(Error(JSON.stringify(message.error))):record.resolve(message.result);}
 });
 socket.addEventListener('close',()=>{for(const record of pending.values()){clearTimeout(record.timer);record.reject(Error('Inspector closed'));}pending.clear();});
 function send(method,params={}){return new Promise((resolve,reject)=>{const id=++sequence;const timer=setTimeout(()=>{pending.delete(id);reject(Error('Inspector command timeout: '+method));},10000);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params}));});}
 return {send,collections,close(){socket.close();}};
}
