import fs from 'node:fs/promises';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'source-scheduler-bun',{recursive:true});
let worker=(await fs.readFile(root+'source-scheduler/worker.mjs','utf8')).replaceAll('\r\n','\n');
const start='async function handleFetchControlRequest(request) {\n\tconst url = new URL(request.url);\n\tconst { pathname } = url;';
if(!worker.includes(start))throw Error('Missing native control handler');
worker=worker.replace(start,start+`
 if(pathname==='/__exact-benchmark/audit-mode'){
  auditScheduled=url.searchParams.get('defer')==='1';
  if(auditScheduled&&participantId!=='exact')throw Error('React scheduling must remain unchanged');
  return jsonFetchResponse({deferred:auditScheduled});
 }
 if(pathname==='/__exact-benchmark/audit-start'){
  resetTelemetry();audit={};auditScheduleCalls=0;await primeBunEventLoopHistogram();
  return jsonFetchResponse({cpu:process.cpuUsage(),deferred:auditScheduled});
 }
 if(pathname==='/__exact-benchmark/audit-stop')return jsonFetchResponse({cpu:process.cpuUsage(),telemetry:telemetry(),audit,scheduleCalls:auditScheduleCalls});
`);
await fs.writeFile(root+'source-scheduler-bun/worker.mjs',worker);
let runner=(await fs.readFile(root+'source-scheduler-stream-run.mjs','utf8')).replaceAll('source-scheduler-stream/','source-scheduler-bun/').replaceAll('actual-source-scheduler-node-stream','actual-source-scheduler-native-bun');
function replaceOnce(from,to){if(!runner.includes(from))throw Error('Missing '+from);runner=runner.replace(from,to);}
replaceOnce("availableSsrRuntimes('node')","availableSsrRuntimes('bun')");
replaceOnce("for(const mode of ['stream'])","for(const mode of ['string','stream'])");
runner=runner.replaceAll("'node-http'","'bun-fetch'").replaceAll("dist-server/server-entry.js","dist-bun-server/bun-server-entry.js");
replaceOnce("const loopBefore=await controlSsrWorker(worker,'audit-loop')","const loopBefore=null");
replaceOnce("const loopAfter=await controlSsrWorker(worker,'audit-loop')","const loopAfter=null");
replaceOnce('report.blocks.length,8','report.blocks.length,16');
replaceOnce("report.artifacts.nodeAdapter=await measureSsrArtifact(resolve('framework-adapters/node-adapter/dist'));","report.artifacts.nodeAdapter=await measureSsrArtifact(resolve('framework-adapters/node-adapter/dist'));report.artifacts.bunAdapter=await measureSsrArtifact(resolve('framework-adapters/bun-adapter/dist'));");
replaceOnce('assert.equal(report.blocks.length,16);',"assert.deepEqual(await measureSsrArtifact(resolve('framework-adapters/bun-adapter/dist')),report.artifacts.bunAdapter);assert.equal(report.blocks.length,16);");
await fs.writeFile(root+'source-scheduler-bun-run.mjs',runner);
console.log('Built native Bun string/stream comparison');
