import hashlib,json,zipfile
from pathlib import Path
from statistics import mean
base=Path('.tmp/ssr-large-profile');folder=base/'source-scheduler-bun'
data=json.loads((folder/'capture.json').read_text());assert data['complete'] and len(data['blocks'])==16
def latency(b,key):
    ds=[r['stages'][0]['distributions'][key] for r in b['results']]
    return sum(d['mean']*d['count'] for d in ds)/sum(d['count'] for d in ds)
rows=[]
for mode in ('string','stream'):
    for population in (0,1):
        exact=[b for b in data['blocks'] if b['mode']==mode and b['population']==population and b['id']=='exact']
        react=[b for b in data['blocks'] if b['mode']==mode and b['population']==population and b['id']=='react']
        assert [b['phase'] for b in exact]==['normal','scheduled','normal'] and len(react)==1
        controls=[exact[0],exact[2]];candidate=exact[1];baseline=react[0]
        normal=mean(b['rps'] for b in controls)
        rows.append(dict(mode=mode,population=population+1,normalRps=normal,scheduledRps=candidate['rps'],reactRps=baseline['rps'],gainVsNormalPct=(candidate['rps']/normal-1)*100,gainVsReactPct=(candidate['rps']/baseline['rps']-1)*100,normalResponseMs=mean(latency(b,'responseMs') for b in controls),scheduledResponseMs=latency(candidate,'responseMs'),reactResponseMs=latency(baseline,'responseMs'),normalTtfbMs=mean(latency(b,'ttfbMs') for b in controls),scheduledTtfbMs=latency(candidate,'ttfbMs'),reactTtfbMs=latency(baseline,'ttfbMs')))
for b in data['blocks']:
    assert b['after']['scheduleCalls']==(b['valid']+len(b['results']) if b['phase']=='scheduled' else 0)
valid=sum(b['valid'] for b in data['blocks']);errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages']);assert errors==0
(folder/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid,errors=errors),indent=2))
report=Path('docs/performance-baselines/source-render-scheduler-bun-2026-09-10.md')
lines=['# Render-start scheduling on native Bun, 2026-09-10','',
'Hypothesis: the scheduling policy may transfer to Bun, but its native response pipeline could show a smaller gain than Node; a modest gain or no improvement was plausible. This measures the actual rebuilt SSR option and exported scheduler implementation. The helper uses Bun support for node:timers. Its Node-adapter import does not change HTTP transport: both participants use bun-fetch with their original native Bun server entries and response adapters. React receives no scheduling change.', '',
'For each of string and stream modes, four fresh production Bun 1.4.2 workers run eXact/React/React/eXact. Each warms HTTP for ten seconds. Each eXact worker runs normal/scheduled/normal; each React worker runs one unchanged block. Blocks last five seconds, with two Node load-driver processes each holding 16 requests. Controls average adjacent eXact blocks within each worker. The native Bun handler does not expose the isolated-loop diagnostic, so none is run here. Workstation load can vary.', '',
'| Mode | Worker | eXact immediate RPS | eXact scheduled RPS | React unchanged RPS | Gain vs immediate | Gain vs React |',
'| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['mode']} | {r['population']} | {r['normalRps']:,.0f} | {r['scheduledRps']:,.0f} | {r['reactRps']:,.0f} | {r['gainVsNormalPct']:+.2f}% | {r['gainVsReactPct']:+.2f}% |")
lines+=['', '| Mode | Worker | eXact response ms, immediate / scheduled | React response ms | eXact TTFB ms, immediate / scheduled | React TTFB ms |','| --- | ---: | ---: | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['mode']} | {r['population']} | {r['normalResponseMs']:.3f} / {r['scheduledResponseMs']:.3f} | {r['reactResponseMs']:.3f} | {r['normalTtfbMs']:.3f} / {r['scheduledTtfbMs']:.3f} | {r['reactTtfbMs']:.3f} |")
lines+=['',f'All {valid:,} measured responses matched full document identity, with zero errors. eXact serves 4,672 bytes and React 3,660 bytes. Scheduler calls equal measured requests plus one identity preflight per driver in scheduled blocks; all other blocks have zero calls. Participant, server, Node-adapter and Bun-adapter artifact hash guards pass.', '',
'The outer renderMs timer measures obtaining a native Response, not necessarily consuming its entire body. It also includes any awaited scheduling. Do not treat it as equivalent exclusive rendering CPU time across frameworks or modes. The driver throughput and latency here include receiving and validating the complete body.', '',
'These focused concurrency-32 captures do not establish sparse-traffic behavior, browser paint timing, larger-document performance or a full benchmark baseline. Scheduling remains opt-in. The full optimization objective remains open until the remaining correctness, browser, publication and representative-workload checks complete.', '',
'The adjacent archive preserves raw results, scripts and source/artifacts with a verified SHA-256 inventory.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[report]+[base/n for n in ('source-scheduler-bun-build.mjs','source-scheduler-bun-run.mjs','source-scheduler-bun-report.py','source-scheduler-stream-run.mjs','source-scheduler/worker.mjs')]+[Path(p) for p in ('framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js','framework-comparison/participants/react/dist-bun-server/bun-server-entry.js','framework-adapters/node-adapter/src/render-scheduler.ts','framework-adapters/node-adapter/dist/render-scheduler.js','packages/ssr/src/render/render-output.ts')]
files=sorted(set(p for p in files if p.is_file()));archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps(rows,indent=2));print(valid,'valid',len(files),'verified files')
