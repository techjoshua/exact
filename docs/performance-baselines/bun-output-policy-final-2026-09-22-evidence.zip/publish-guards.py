from pathlib import Path
from datetime import datetime
import json,hashlib,zipfile
roots=[Path('.tmp/bun-string-8k-2026-09-22'),Path('.tmp/node-string-source-guard-2026-09-22')]
rows=[]
for root in roots:
 journal=json.loads((root/'execution.json').read_text());assert all(s.get('code')==0 for s in journal)
 for p in root.glob('*.json'):
  capture=json.loads(p.read_text())
  if not isinstance(capture,dict) or capture.get('kind')!='multi-driver-preloaded-ssr':continue
  assert capture['complete']
  for block in capture['blocks']:
   groups={}
   for result in block['results']:
    for stage in result['stages']:
     if not stage.get('discard'):groups.setdefault(stage['name'],[]).append(stage)
   for stage,ss in groups.items():
    def start(s):return datetime.fromisoformat(s['startedAt'].replace('Z','+00:00')).timestamp()*1000
    rows.append(dict(runtime=capture['runtimeId'],mode=capture['renderMode'],variant=capture['experiment']['variant'],framework=block['id'],stage=stage,rps=1000*sum(s['valid'] for s in ss)/(max(start(s)+s['elapsedMs'] for s in ss)-min(start(s) for s in ss)),p99=[s['distributions']['responseMs']['p99'] for s in ss],errors=sum(s['errors'] for s in ss),invalid=sum(s['invalid'] for s in ss)))
comparisons=[]
for key in sorted({(r['runtime'],r['mode'],r['stage']) for r in rows}):
 group={(r['variant'],r['framework']):r for r in rows if (r['runtime'],r['mode'],r['stage'])==key}
 assert len(group)==4
 c=group['control','exact'];n=group['candidate','exact'];cr=group['control','react'];nr=group['candidate','react']
 comparisons.append(dict(runtime=key[0],mode=key[1],stage=key[2],control=c,candidate=n,reactControl=cr,reactCandidate=nr,ratioChangePercent=100*((n['rps']/nr['rps'])/(c['rps']/cr['rps'])-1)))
prefix=Path('docs/performance-baselines/output-policy-followup-guards-2026-09-22');archive=Path(str(prefix)+'-evidence.zip');manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for root in roots:
  for p in sorted(root.rglob('*')):
   if not p.is_file():continue
   name=str(p.relative_to(root.parent));data=p.read_bytes();z.writestr(name,data);manifest[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
data={'comparisons':comparisons,'archive':{'path':str(archive),'sha256':sha,'files':len(manifest),'bytes':archive.stat().st_size}}
Path(str(prefix)+'.json').write_text(json.dumps(data,indent=2)+'\n')
text=['# Output-policy follow-up guards, September 22, 2026','','The full capture exposed a higher Bun string 8,000-RPS p99 and unfavorable high-concurrency Node ratios relative to the preceding full capture. These fresh controls test those differences after the full suite, without concurrent measurement workloads. They do not erase the unfavorable full-run observations.','','Bun uses the frozen automatic integration candidate and its original adapter control, with identical renderer bundles. The prior integration archive retains those artifacts. Node compares the exact entry SHA from the preceding full capture against the newly built entry. The only Node entry differences are the progressive-only selector and its streaming call site. Node string execution code and the Node adapter remain unchanged. Both APIs are checked. Complete HTML identities and frozen artifacts are verified.','','Each capture uses two load drivers and a React comparison. Node uses 10-second warmup and 15 seconds each at total concurrency 64 and 128. Bun uses 30-second warmup and 60-second measurement at 8,000 offered RPS. Candidate precedes control, with React measured first in each capture. RPS includes drain, and p99 ranges describe separate drivers, not confidence intervals.','','| Runtime/API | Stage | eXact control RPS | eXact candidate RPS | React control RPS | React candidate RPS | Ratio change | Control p99 | Candidate p99 |','| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for r in comparisons:
 c=r['control'];n=r['candidate'];cr=r['reactControl'];nr=r['reactCandidate'];text.append(f"| {r['runtime']}/{r['mode']} | {r['stage']} | {c['rps']:,.0f} | {n['rps']:,.0f} | {cr['rps']:,.0f} | {nr['rps']:,.0f} | {r['ratioChangePercent']:+.1f}% | {min(c['p99']):.2f}–{max(c['p99']):.2f} ms | {min(n['p99']):.2f}–{max(n['p99']):.2f} ms |")
text+=['',f'[Structured results]({prefix.name}.json) and [raw evidence]({archive.name}). Archive SHA-256: `{sha}`.','']
Path(str(prefix)+'.md').write_text('\n'.join(text));print(json.dumps(comparisons,indent=2))
