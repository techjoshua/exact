import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync} from 'node:fs';
const root=import.meta.dirname;
const scripts=['check-source-architecture','check-jsdoc','check-explicit-any','check-platform-boundaries','check-compiled-abi','check-release-abi','check-package-contents'];
const steps=scripts.map(name=>[name,['scripts/'+name+'.mjs']]);
steps.push(['lint',['node_modules/eslint/bin/eslint.js','packages/server/src/framework/render-scheduling.ts','packages/ssr/src/render/render-output.ts','packages/ssr/src/render/resume-scheduling.ts','packages/ssr/src/render/resume-scheduling.test.ts','framework-adapters/bun-adapter/src/request-handler.ts','framework-adapters/bun-adapter/src/request-handler.test.ts','framework-adapters/bun-adapter/src/render-policy.ts','framework-adapters/bun-adapter/src/render-policy.test.ts','apps/docs/src/pages/AdvancedPage.tsx']]);
const journal=[];
for(const [name,args] of steps){const step={name,args,startedAt:new Date().toISOString()};journal.push(step);const save=()=>writeFileSync(root+'/contract-checks.json',JSON.stringify(journal,null,2));save();console.log('START',name);const fd=openSync(root+'/'+name+'.log','w');try{await new Promise((done,fail)=>{const c=spawn(process.execPath,args,{env:{...process.env,npm_execpath:process.env.COMPARISON_NPM_CLI},stdio:['ignore',fd,fd]});c.once('error',fail);c.once('exit',code=>{step.code=code;code===0?done():fail(Error(name+' '+code));});});}finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}console.log('DONE',name);}
