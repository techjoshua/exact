import {readFile,writeFile} from 'node:fs/promises';
import {isDeepStrictEqual} from 'node:util';
const root=import.meta.dirname,results=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream']){
const lane=runtime+(mode==='stream'?'-stream':'')+'-multi';
const [before,after]=await Promise.all([`docs/performance-baselines/bun-stream-counting-final-2026-09-21-${lane}.json`,`${root}/${lane}.json`].map(async p=>JSON.parse(await readFile(p,'utf8'))));
const a=before.artifacts,b=after.artifacts,adapter=runtime==='bun'?'bunAdapter':'nodeAdapter';
results.push({runtime,mode,exactEntry:a.exact.sha256===b.exact.sha256,reactEntry:a.react.sha256===b.react.sha256,server:isDeepStrictEqual(a.server,b.server),adapter:isDeepStrictEqual(a[adapter],b[adapter])});
}
await writeFile(root+'/artifact-comparison.json',JSON.stringify(results,null,2)+'\n');console.log(results);

const beforeBrowser=JSON.parse(await readFile("docs/performance-baselines/bun-stream-counting-final-2026-09-21-browser.json","utf8")),afterBrowser=JSON.parse(await readFile(root+"/browser.json","utf8"));
const browserArtifacts=afterBrowser.complexity.map(row=>({participantId:row.participantId,before:beforeBrowser.complexity.find(r=>r.participantId===row.participantId).artifacts.hash,after:row.artifacts.hash})).map(row=>({...row,unchanged:row.before===row.after}));
await writeFile(root+"/browser-artifact-comparison.json",JSON.stringify(browserArtifacts,null,2)+"\n");
