import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {summarizeSsrCapacityCapture} from '../../framework-comparison/src/ssr-capacity-report.mjs';
const root=import.meta.dirname,prefix=root.split('/').at(-1);
const json=async path=>JSON.parse(await readFile(path,'utf8'));
const execution=await json(root+'/execution.json');
assert.equal(execution.length,27);assert.ok(execution.every(s=>s.code===0));
const arrivals=await json(root+'/bun-stream-arrivals.json');
const rows=summarizeSsrCapacityCapture(arrivals,{allowArrivalErrors:true}).filter(r=>r.name==='eXact');
const describe=rate=>{
 const r=rows.find(r=>r.rate===rate);
 const ss=arrivals.blocks.filter(b=>b.id==='exact'&&b.rate===rate).flatMap(b=>b.results.flatMap(r=>r.stages.filter(s=>!s.discard)));
 assert.ok(ss.every(s=>s.errors===0&&s.invalid===0));
 const miss=ss.reduce((n,s)=>n+s.missedCapacity+s.missedLag+s.missedDeadline,0),offered=ss.reduce((n,s)=>n+s.offered,0);
 return `${Math.round(r.rps).toLocaleString('en-US')} valid RPS at ${rate.toLocaleString('en-US')} offered RPS (${(100*miss/offered).toFixed(2)}% missed arrivals, ${r.p99Min.toFixed(1)}–${r.p99Max.toFixed(1)} ms p99)`;
};
let doc=await readFile('docs/performance.md','utf8');
const start=doc.indexOf('The [progressive-output follow-up]'),end=doc.indexOf('The subsequent [Bun scheduler follow-up]',start);assert.ok(start>=0&&end>start);
doc=doc.slice(0,start)+`The [Bun output-policy follow-up](performance-baselines/${prefix}.md)
is the current framework comparison baseline. All 27 build, correctness, and measurement stages
passed, including browser, startup, heap, Node/Bun string and streaming, twelve sustained-load
captures, and the native track. Bun streaming scheduled demand delivers ${describe(8000)}
and ${describe(10000)}, with zero measured request errors or invalid responses.
String API results and all unfavorable differences remain in the full report.

Bun progressive rendering selects a shared half-millisecond work window at render entry and data
resumption. The [automatic integration study](performance-baselines/bun-output-policy-integration-2026-09-22.md)
records the focused guards, including the first rejected selector.
String rendering and initial Fetch admission retain their adaptive policy. Compiled
components, transport backpressure, output limits, and Node scheduling remain unchanged.
The [preceding progressive-output capture](performance-baselines/bun-stream-counting-final-2026-09-21.md)
remains the full comparison reference.

`+doc.slice(end);
doc=doc.replace('The full capture above\nstill measures the retained implementation.', 'Those earlier captures predate the output-policy change above.');
doc=doc.replace('These dedicated-host\nexperiments do not yet establish a production mixed-mode policy or replace the full charts.', 'Those dedicated-host\nexperiments are followed by automatic output-policy integration and the full capture above.');
doc=doc.replace('The full\ncharts still refer to the preceding capture until the new complete suite is published.', 'The full\ncharts now use the complete capture above.');
await writeFile('docs/performance.md',doc);
let readme=await readFile('framework-comparison/README.md','utf8');
readme=readme.replace('The current [progressive-output follow-up](../docs/performance-baselines/bun-stream-counting-final-2026-09-21.md)',`The current [Bun output-policy follow-up](../docs/performance-baselines/${prefix}.md)`);
readme=readme.replace('windows advance to integration experiments; Node string retention', 'windows are integrated in the full capture below; Node string retention');
readme=readme.replace('The full\ncharts still refer to the preceding capture until the new complete suite is published.', 'The full\ncharts use the complete capture below.');
await writeFile('framework-comparison/README.md',readme);
console.log('Updated current benchmark references.');
