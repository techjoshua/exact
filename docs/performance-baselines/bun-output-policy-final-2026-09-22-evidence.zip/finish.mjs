import {spawn} from 'node:child_process';
import {openSync,closeSync,readFileSync,writeFileSync} from 'node:fs';
const root=import.meta.dirname;
const measured=JSON.parse(readFileSync(root+'/execution.json'));
if(measured.length!==27||!measured.every(s=>s.code===0))throw Error('Full run is not complete');
const npm='/home/techj/.npm/_npx/3c6effcf97752e7c/node_modules/npm/bin/npm-cli.js';
const steps=[
 ['artifact-comparison',[root+'/compare-artifacts.mjs']],
 ['reference-comparison',[root+'/compare-references.mjs']],
 ['publish',[root+'/publish.mjs']],
 ['report',[root+'/report.mjs']],
 ['update-docs',[root+'/update-docs.mjs']],
 ['format-docs',['node_modules/prettier/bin/prettier.cjs','--write','docs/performance.md','framework-comparison/README.md','docs/performance-baselines/bun-output-policy-final-2026-09-22.md']],
 ['docs-types',[npm,'run','typecheck','-w','@exactjs/docs']],
 ['docs-build',[npm,'run','build','-w','@exactjs/docs']],
 ['verify-docs',[root+'/verify-docs.mjs']],
 ['archive',[root+'/archive.mjs']]
];
const journal=[];
for(const [name,args] of steps){
 const step={name,args,startedAt:new Date().toISOString()};journal.push(step);
 const save=()=>writeFileSync(root+'/publication-execution.json',JSON.stringify(journal,null,2));save();console.log('START',name);
 const fd=openSync(root+'/publish-'+name+'.log','w');
 try{await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{stdio:['ignore',fd,fd]});step.pid=child.pid;save();child.once('error',fail);child.once('exit',code=>{step.code=code;code===0?done():fail(Error(name+' '+code));});});}
 finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}console.log('DONE',name);
}
