import {readFile,access} from 'node:fs/promises';
import {summarizeSsrCapacityCapture} from '../../framework-comparison/src/ssr-capacity-report.mjs';
const root=import.meta.dirname;
const read=async p=>JSON.parse(await readFile(p,'utf8'));
const steps=await read(root+'/execution.json');
console.log(steps.map(s=>`${s.code===0?'DONE':s.code===undefined?'RUNNING':'FAILED'} ${s.name}`).join('\n'));
for(const name of ['bun-stream-arrivals','bun-multi','bun-stream-multi','bun-arrivals','node-multi','node-stream-multi','node-arrivals','node-stream-arrivals']){
 try{await access(root+'/'+name+'.json');}catch{continue;}
 const c=await read(root+'/'+name+'.json');
 if(!c.complete)continue;
 console.log(name,summarizeSsrCapacityCapture(c,{allowArrivalErrors:true}).filter(r=>r.name==='eXact'));
}
