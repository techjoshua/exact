import hashlib,json,pathlib,zipfile
root=pathlib.Path('.');work=root/'.tmp/ssr-large-profile'
rows=json.loads((work/'map-fragment-results.json').read_text(encoding='utf-8'))
assert len(rows)==32
summary=[]
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['small','large']:
   changes=[]
   for round in range(2):
    group=[r for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['round']==round]
    a=next(r for r in group if r['variant']=='marker-hex-current');b=next(r for r in group if r['variant']=='map-fragment')
    assert a['hash']==b['hash'];changes.append((b['usPerRender']/a['usPerRender']-1)*100)
   summary.append(dict(runtime=runtime,mode=mode,scenario=scenario,changes=changes))
table='\n'.join(f"| {s['runtime']} | {s['mode']} | {s['scenario']} | {s['changes'][0]:+.2f}% | {s['changes'][1]:+.2f}% |" for s in summary)
dest=root/'docs/performance-baselines/map-fragment-2026-09-09'
dest.with_suffix('.json').write_text(json.dumps(dict(summary=summary,populations=rows),indent=2)+'\n',encoding='utf-8')
doc='''# Specialized server map fragment construction

Date: 2026-09-09. Rejected prototype; production implementation unchanged.

## Hypothesis and scope

Direct server maps already construct prepared keyed children, but issue their containing fragment
through the generic fragment constructor. That path destructures props, spreads mapped children
into a rest parameter, scans those known non-array child carriers for normalization, and constructs
optional metadata through object spreads. The hypothesis was a 1-4% rendering-time reduction on
the small asset fixture by avoiding this redundant work.

The prototype specializes only directSsrMap issuance. It retains the generic immutable opaque
operation, the same private fragment store and executor, optional key/domain metadata, and ordinary
fragment rendering. It materializes the iterable before invoking callbacks and preserves
render-before-key evaluation. It coerces the fragment key and reads the current domain after
constructing children, matching the existing order. Props remain an empty per-fragment object.
Only children already wrapped in prepared keyed carriers bypass normalization.

This is narrower than replacing fragments with a new direct server carrier. That architectural
change was not implemented or measured here. The existing constructor has ownership and private
payload contracts beyond simply collecting children.

## Method

Thirty-two fresh processes compare the frozen current marker-hex build with a patched copy:
Node/Bun, string/consumed stream, small/large documents, two reversed-order pairs per cell.
Each population runs NODE_ENV=production, 5,000 warmups and 12,000 measured renders.
The small document contains three incidents; large contains 96. Both contain two module scripts
and two stylesheet links. Both runtimes use the same Node-target artifact. Streams are consumed
with Response.text(). All populations completed, full-document framing checks passed, and every
paired full-body hash matched. No observation was discarded.

## Results

Positive means longer rendering time. These local pairs are descriptive observations, not
confidence intervals, HTTP throughput, browser measurements, or a new React comparison.

| Runtime | Mode | Fixture | Pair 1 time change | Pair 2 time change |
| --- | --- | --- | ---: | ---: |
'''+table+'''

Small streams improve in both pairs on both runtimes. String results do not establish a consistent
benefit, and large Bun streams regress in both pairs. The prototype is not adopted: this shared
construction path should not be split by sink to preserve a small-fixture streaming gain at the
expense of another measured workload. The current retained build remains marker-hex-current.

The experiment does not show that a direct server fragment carrier would be ineffective. It shows
that simplifying construction around the existing opaque receipt is insufficiently consistent.
Any broader carrier experiment must account for private payload redemption, domain/key metadata,
root and nested render dispatch, enhancements, and hydration boundaries.

No production source changed, so no new package or browser suite was run for this rejected
prototype. Hash equality establishes output equivalence for these fixtures, not general lifecycle
or asynchronous correctness. The previous retained validation remains documented in the marker-hex
report. Overall React parity remains unmet.

The evidence archive contains both frozen artifacts, builder, runner, worker, fixed input, raw
results, reporter, and a SHA-256 manifest. Reproduction requires the workspace dependencies.
'''
dest.with_suffix('.md').write_text(doc,encoding='utf-8')
files=[work/n for n in ['marker-hex-current.mjs','map-fragment.mjs','map-fragment-build.mjs','direct-map-worker.mjs','map-fragment-run.mjs','map-fragment-results.json','map-fragment-report.py']]+[root/'.tmp/positional-leaves/data.json',dest.with_suffix('.md'),dest.with_suffix('.json')]
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps({p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(table);print('Verified',archive)
