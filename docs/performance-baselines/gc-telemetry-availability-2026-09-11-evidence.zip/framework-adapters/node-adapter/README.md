# @exactjs/node-adapter

Low-level Node `http` adapter for eXact server endpoints.

## Usage

```ts
import { createServer } from 'node:http';
import { createExactNodeHandler } from '@exactjs/node-adapter';

const exact = createExactNodeHandler(exactRuntime);
createServer(exact).listen(3000);
```

Use this package with `http.createServer()` or beneath a custom Node server. It normalizes Node
request and response objects; protocol validation and dispatch remain in `@exactjs/server`.

For complete SSR documents, await `renderExactRequestToHtmlResponse()` from `@exactjs/ssr`
and pass the result to `writeNodeResponse(response, rendered, signal)`. Buffered output is
committed with one terminal Node write. Pass progressive responses to the same adapter when
shell publication before hydration is required.

For a busy custom Node host, `createNodeRenderScheduler({ maxBatchSize: 32 })` creates a
shared render-start gate. Create it once for the host and pass the returned function as
the SSR `scheduleRender` option. It groups waiting starts through `scheduler.yield()` from
`node:timers/promises`, falling back to `setImmediate` if yield is unavailable, and
removes canceled requests promptly. The default batch limit is 32. Rendering starts
immediately when the option is omitted. Scheduling adds a wait even when only one request
arrives, and also delays initial head output if enabled for streaming. Measure response
latency under your workload before enabling it. Compare throughput and response p95/p99 for
representative document sizes on your runtime. Lower event-loop lag alone can hide longer
request queues. The limit applies per callback, not to all pending requests or render duration.

Use `writeNodeResponseBody(response, rendered, signal)` when a custom handler owns the remainder
of the response. It consumes ordered chunks with Node backpressure and leaves the response open.
Use `cancelNodeResponseBody(rendered, reason)` for a `HEAD` response or an abandoned body. Each
body is single-consumer: write it, request its Web stream, or cancel it exactly once.

`createExactNodeHandler()` reports unexpected request, response-production, and cleanup failures
through the runtime's `logger`, or to the server console when no logger is supplied. A custom
`writeNodeResponse(response, result, signal, logger)` call can supply the same optional logger.
Error responses remain generic; original failures stay in server logs. A failing custom logger
falls back to the console without preventing response cleanup. Lower-level
`writeNodeResponseBody()` rejects on failure so its caller can report and terminate its own response.
