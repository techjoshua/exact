import json,hashlib,zipfile
from pathlib import Path
report=Path('docs/performance-baselines/gc-telemetry-availability-2026-09-11.md')
names=['framework-comparison/src/garbage-collection-meter.mjs','framework-comparison/src/ssr-load-statistics.mjs','framework-comparison/src/ssr-benchmark-worker.mjs','framework-comparison/test/garbage-collection-meter.test.mjs','scripts/component-local-target-abi/framework-comparison-ssr-adapter.mjs','scripts/component-local-target-abi/framework-comparison-adapters.test.mjs','framework-comparison/methodology.md','framework-comparison/README.md','docs/performance.md','docs/ssr-hydration.md','framework-adapters/node-adapter/README.md','apps/docs/src/pages/AdvancedPage.tsx','apps/docs/src/pages/PerformancePage.tsx','.tmp/ssr-large-profile/gc-availability-smoke.mjs','.tmp/ssr-large-profile/gc-availability-smoke.json','.tmp/ssr-large-profile/gc-availability-archive.py']
files=[Path(n) for n in names]+[report];archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists();manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print('GC telemetry correction evidence verified:',len(files),'files')
