import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {availableSsrRuntimes} from '../../framework-comparison/src/ssr-run-environment.mjs';
import {startSsrWorker,stopSsrWorker,controlSsrWorker} from '../../framework-comparison/src/ssr-worker-controller.mjs';
import {startSsrLoadProcess} from '../../framework-comparison/src/ssr-load-process-owner.mjs';
import {installDevelopmentProcessLifecycle} from '../../scripts/development-process-lifecycle.mjs';
let worker,service;const rows=[];
async function close(){if(worker){await stopSsrWorker(worker);worker=undefined;}if(service){await service.close();service=undefined;}}
const lifecycle=installDevelopmentProcessLifecycle({label:'GC availability smoke',close});
try{
 for(const runtimeId of ['node','bun'])for(const mode of ['string','stream']){
  const runtime=availableSsrRuntimes(runtimeId)[0];service=await startSsrLoadProcess('service');
  worker=await startSsrWorker({runtime,participantId:'exact',transport:runtimeId==='bun'?'bun-fetch':'node-http',workerPath:resolve('framework-comparison/src/ssr-benchmark-worker.mjs'),workingDirectory:resolve('framework-comparison'),serviceUrl:service.url,environment:{COMPARISON_SSR_RENDER_MODE:mode,COMPARISON_SSR_BOUNDED_TELEMETRY:'1'}});
  let hash;
  for(let i=0;i<2;i++){
   await controlSsrWorker(worker,'reset');const response=await fetch(worker.url+'?__benchmarkPreloaded=true');assert.equal(response.status,200);const body=Buffer.from(await response.arrayBuffer());assert.match(body.toString(),/^<!doctype html>/i);assert.match(body.toString(),/<\/body><\/html>$/i);
   const next=createHash('sha256').update(body).digest('hex');if(hash)assert.equal(next,hash);hash=next;
   const gc=(await controlSsrWorker(worker,'telemetry')).garbageCollection;
   if(runtimeId==='bun')assert.deepEqual(gc,{available:false,count:null,durationMs:null});else{assert.equal(gc.available,true);assert.equal(typeof gc.count,'number');assert.equal(typeof gc.durationMs,'number');}
   rows.push({runtimeId,mode,iteration:i,gc,bytes:body.length,hash});
  }
  console.log(runtimeId,mode,'passed');await close();
 }
 await writeFile('.tmp/ssr-large-profile/gc-availability-smoke.json',JSON.stringify(rows,null,2));
}finally{await close();lifecycle.dispose();}
