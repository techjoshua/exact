"""Archive the focused evidence after the full timed suite has finished."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

focused = Path('.tmp/bun-admission-2026-09-20')
final = Path('.tmp/bun-admission-final-2026-09-20')
first = Path('.tmp/bun-admission-first-full-2026-09-20')
prefix = Path('docs/performance-baselines/bun-admission-investigation-2026-09-20')
execution = json.loads((final / 'execution.json').read_text())
assert len(execution) == 27 and all(s.get('code') == 0 for s in execution)
captures = []
for path in sorted(focused.glob('*.json')):
    data = json.loads(path.read_text())
    if not isinstance(data, dict) or 'blocks' not in data:
        continue
    rows = []
    for block in data['blocks']:
        results = block.get('results', [])
        if not results:
            continue
        for i, stage in enumerate(results[0]['stages']):
            stages = [result['stages'][i] for result in results]
            tails = [s.get('distributions', {}).get('responseMs', {}).get('p99') for s in stages]
            rows.append({
                'framework': block.get('id'), 'stage': stage['name'],
                'discard': stage.get('discard', False),
                'validRps': sum(s.get('validRps', 0) for s in stages),
                'responseP99Ms': tails,
                **{key: sum(s.get(key, 0) for s in stages) for key in
                   ['offered', 'valid', 'errors', 'invalid', 'missedCapacity', 'missedLag', 'missedDeadline']}
            })
    captures.append({
        'path': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'complete': data.get('complete'), 'plan': data.get('plan'),
        'environment': data.get('environment'), 'artifacts': data.get('artifacts'),
        'rows': rows
    })

summary = {
    'scope': 'Focused Bun adaptive admission experiments, including rejected candidates and interrupted runs',
    'finalImplementation': '44721c11',
    'fullCapture': 'docs/performance-baselines/bun-admission-final-2026-09-20.json',
    'provenance': (focused / 'evidence-notes.md').read_text(),
    'captures': captures,
    'finalNormalRepeats': json.loads((focused / 'final-normal-summary.json').read_text()),
    'finalStreamingRepeats': json.loads((focused / 'cadence-repeat-summary.json').read_text()),
    'validation': json.loads((focused / 'validation.json').read_text()),
    'firstFullExecution': json.loads((first / 'execution.json').read_text())
}
prefix.with_suffix('.json').write_text(json.dumps(summary, indent=2) + '\n')
shutil.copyfile(focused / 'investigation.md', prefix.with_suffix('.md'))
archive = Path(str(prefix) + '-evidence.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for root, folder in [(focused, 'focused'), (first, 'first-full-attempt')]:
        for path in sorted(root.rglob('*')):
            if path.is_file() and 'candidate' not in path.relative_to(root).parts:
                output.write(path, folder + '/' + str(path.relative_to(root)))
    for name in ['publish-investigation.py', 'source-state.json', 'ratio-comparison.json']:
        output.write(final / name, 'final/' + name)
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None
summary['evidenceArchive'] = {'path': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
prefix.with_suffix('.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'captures': len(captures), 'archive': str(archive), 'bytes': archive.stat().st_size}))
