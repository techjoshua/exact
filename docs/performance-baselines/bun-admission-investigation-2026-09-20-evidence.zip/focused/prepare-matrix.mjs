import {readFileSync,writeFileSync,cpSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import ts from 'typescript';
const dir='.tmp/bun-admission-2026-09-20';
cpSync(dir+'/control',dir+'/control-clean',{recursive:true});
const source=execFileSync('git',['show','HEAD:framework-adapters/bun-adapter/src/adaptive-gate.ts'],{encoding:'utf8'});
writeFileSync(dir+'/control-clean/adaptive-gate.js',ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText);
let worker=readFileSync(dir+'/control-worker.mjs','utf8');
worker=worker.slice(worker.indexOf("import { assertComparisonWorkspaceDependencies"));
worker=worker.replace("'./control/index.js'","'./control-clean/index.js'");
writeFileSync(dir+'/control-clean-worker.mjs',worker);
for(const variant of ['control-clean','production']){
let runner=readFileSync('.tmp/arrival-policy-final-2026-09-20/capacity-runner.mjs','utf8');
runner=runner.replace('population<2','population<1');
if(variant==='control-clean')runner=runner.replace("resolve('framework-comparison/src/ssr-benchmark-worker.mjs')",`resolve('${dir}/control-clean-worker.mjs')`);
runner=runner.replace('const prior={artifacts,',`artifacts.experimentalAdapter = await measureSsrArtifact(resolve('${variant==='production'?'framework-adapters/bun-adapter/dist':dir+'/control-clean'}'));\nconst prior={artifacts,`);
writeFileSync(`${dir}/${variant}-matrix.mjs`,runner);
}
const multi=JSON.parse(readFileSync('.tmp/arrival-policy-final-2026-09-20/multi-plan.json'));for(const s of multi.stages)s.durationMs=10000;
writeFileSync(dir+'/matrix-preloaded.json',JSON.stringify(multi));
const normal=JSON.parse(readFileSync('.tmp/arrival-policy-final-2026-09-20/normal-plan.json'));normal.stages[1].durationMs=15000;
writeFileSync(dir+'/matrix-normal.json',JSON.stringify(normal));
