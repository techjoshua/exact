# Runtime signal checks

Installed Bun 1.4.2 on WSL, 2026-09-20 local time.

- `performance.eventLoopUtilization()` returned idle=active=utilization=0 before and after a 200 ms timer, and after a 100 ms synchronous busy loop. It cannot establish headroom on this runtime.
- `process.threadCpuUsage()` exists. The delta form returned 2.492 ms during a 100 ms idle timer and 97.608 ms during a 100 ms busy loop. This is a viable conservative CPU headroom signal for the event-loop thread, subject to workload validation.
- Process-wide CPU included additional threads, exceeding one core in demand-limited runs. A copied Node policy with a process-CPU <80% and lag<3 ms guard did not improve 8k scheduled-demand p99 (35.0–35.7 ms versus baseline 33.7–34.2 ms). No production change was made from that prototype.
- A 100,000-call measurement of `process.threadCpuUsage()` averaged 0.346 microseconds per call. The controller samples at window boundaries, so direct counter-read cost is far below the observed percent-level capacity variation.
