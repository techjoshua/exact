from pathlib import Path
import shutil,re,json
root=Path.cwd(); out=root/'.tmp/bun-admission-2026-09-20'
shutil.copytree(root/'framework-adapters/bun-adapter/dist',out/'control',dirs_exist_ok=True)
worker=(root/'framework-comparison/src/ssr-benchmark-worker.mjs').read_text()
worker=re.sub(r"from '([.][^']+)'",lambda m:"from '"+(root/'framework-comparison/src'/m[1]).resolve().as_uri()+"'",worker)
worker=worker.replace("const suiteRoot = resolve(import.meta.dirname, '..');",'const suiteRoot = '+json.dumps(str(root/'framework-comparison'))+';')
worker=worker.replace("from '@exactjs/bun-adapter'","from './control/index.js'")
worker="import { BunRequestGate } from './control/adaptive-gate.js';\nconst original = BunRequestGate.prototype.observeRequest;\nBunRequestGate.prototype.observeRequest = function(...args) { globalThis.observedGate = this; BunRequestGate.prototype.observeRequest = original; return original.apply(this,args); };\n"+worker
worker=worker.replace('requestErrors: requestErrors.snapshot(),',"admission: globalThis.observedGate ? Object.fromEntries(['enabled','phase','until','cooldown','controlRate','controlLag','baseline','trial','lastSample','lastCpu','arrivals','windowArrivals','windowPending','started'].map(k=>[k,globalThis.observedGate[k]])) : null, workerNow: performance.now(), requestErrors: requestErrors.snapshot(),")
(out/'control-worker.mjs').write_text(worker)
gate=out/'control/adaptive-gate.js'; s=gate.read_text(); s=s.replace('this.started = now;', 'this.lastCpu = this.traceCpu ? (process.cpuUsage(this.traceCpu).user + process.cpuUsage(this.traceCpu).system) / ((now-this.started)*1000) : null; this.traceCpu = process.cpuUsage(); this.started = now;'); s=s.replace("if (this.phase === 'trial')", "this.lastSample = sample; if (this.phase === 'trial')");gate.write_text(s)
s=(root/'.tmp/arrival-latency-2026-09-20/control-elu-capture.mjs').read_text().replace("resolve(process.env.CONTROL_EXACT_ENTRY)","resolve('framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js')").replace('.tmp/arrival-latency-2026-09-20/control-elu-worker.mjs','.tmp/bun-admission-2026-09-20/control-worker.mjs')
(out/'capture.mjs').write_text(s)
for rate in (8000,10000):
 plan={'preloaded':True,'drivers':2,'stages':[{'name':'warm-target','mode':'arrival','rate':rate//2,'durationMs':30000,'discard':True},{'name':f'total-arrivals-{rate}','mode':'arrival','rate':rate//2,'durationMs':60000}]}
 (out/f'{rate}.json').write_text(json.dumps(plan))
