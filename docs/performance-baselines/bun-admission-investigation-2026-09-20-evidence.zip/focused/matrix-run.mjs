import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync} from 'node:fs';
const dir='.tmp/bun-admission-2026-09-20',journal=[];
for(const mode of ['string','stream'])for(const lane of ['preloaded','normal'])for(const variant of mode==='string'?['control-clean','production']:['production','control-clean']){
const name=`matrix-${mode}-${variant}-${lane}`;
const fd=openSync(`${dir}/${name}.log`,'w'),row={name,start:new Date().toISOString()};journal.push(row); console.log('START',name);
try{await new Promise((done,fail)=>{const p=spawn(process.execPath,[`${dir}/${variant}-matrix.mjs`,`${dir}/matrix-${lane}.json`,`${dir}/${name}.json`,'bun'],{env:{...process.env,COMPARISON_SSR_RENDER_MODE:mode},stdio:['ignore',fd,fd]});p.once('error',fail);p.once('exit',code=>{row.code=code;code===0?done():fail(Error('exit '+code));});});}finally{closeSync(fd);row.end=new Date().toISOString();writeFileSync(dir+'/matrix-execution.json',JSON.stringify(journal,null,2));}console.log('DONE',name);
}
