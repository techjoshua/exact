import {spawn} from 'node:child_process';
import {openSync,closeSync} from 'node:fs';
const dir='.tmp/bun-admission-2026-09-20';
for(const rate of [8000,10000]){
const fd=openSync(`${dir}/demand-${rate}.log`,'w'); console.log('START demand',rate);
try{await new Promise((done,fail)=>{const p=spawn(process.execPath,[`${dir}/demand-capture.mjs`,`${dir}/${rate}.json`,`${dir}/demand-${rate}.json`,'bun'],{stdio:['ignore',fd,fd]});p.once('error',fail);p.once('exit',code=>code===0?done():fail(Error('exit '+code)));});}finally{closeSync(fd);}console.log('DONE demand',rate);
}
