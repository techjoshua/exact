import {readFileSync} from 'node:fs';
for(const file of process.argv.slice(2)) {
const r=JSON.parse(readFileSync(file)); console.log(file);
for(const b of r.blocks) {
for(let i=0;i<b.results[0].stages.length;i++) {
const stages=b.results.map(d=>d.stages[i]); console.log(stages[0].name, {rps:stages.reduce((n,s)=>n+s.validRps,0),p99:stages.map(s=>s.distributions.responseMs.p99),errors:stages.reduce((n,s)=>n+s.errors,0),misses:stages.reduce((n,s)=>n+s.missedCapacity+s.missedLag,0)});
}
const phases={};for(const t of b.telemetry){const a=t.value.admission;if(!a)continue; phases[a.phase]=(phases[a.phase]??0)+1;}
console.log('phases',phases);console.log('trace',b.telemetry.filter(t=>t.value.admission).map(t=>({t:Math.round(t.value.workerNow/1000),phase:t.value.admission.phase,cpu:t.value.admission.lastCpu,sample:t.value.admission.lastSample})).filter((t,i,all)=>!i || t.phase!==all[i-1].phase || i%10===0));
}}
