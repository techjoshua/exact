import {spawn} from 'node:child_process';
import {openSync,closeSync} from 'node:fs';
const dir='.tmp/bun-admission-2026-09-20';
for(const [variant,rate] of [['scheduled',8000],['immediate',8000],['control',10000],['scheduled',10000]]){
 const file=variant==='control'?'capture':variant+'-capture';
 const fd=openSync(`${dir}/${variant}-${rate}.log`,'w');console.log('START',variant,rate);
 try{await new Promise((done,fail)=>{const p=spawn(process.execPath,[`${dir}/${file}.mjs`,`${dir}/${rate}.json`,`${dir}/${variant}-${rate}.json`,'bun'],{stdio:['ignore',fd,fd]});p.on('error',fail);p.on('exit',code=>code===0?done():fail(Error('exit '+code)));});}finally{closeSync(fd);}
 console.log('DONE',variant,rate);
}
