import {readFileSync,writeFileSync,existsSync} from 'node:fs';
const dir=import.meta.dirname,rows=[];
for(const variant of ['control','candidate','scheduled','immediate','demand'])for(const rate of [8000,10000]){
const path=`${dir}/${variant}-${rate}.json`;if(!existsSync(path))continue;const r=JSON.parse(readFileSync(path));
const stages=r.blocks.flatMap(b=>b.results.flatMap(d=>d.stages.filter(s=>!s.discard)));
const tails=stages.map(s=>s.distributions.responseMs.p99);rows.push({variant,rate,rps:stages.reduce((n,s)=>n+s.validRps,0),p99Min:Math.min(...tails),p99Max:Math.max(...tails),errors:stages.reduce((n,s)=>n+s.errors,0),invalid:stages.reduce((n,s)=>n+s.invalid,0),capacityMisses:stages.reduce((n,s)=>n+s.missedCapacity,0),lagMisses:stages.reduce((n,s)=>n+s.missedLag,0),deadlineMisses:stages.reduce((n,s)=>n+s.missedDeadline,0)});
}
writeFileSync(dir+'/arrival-summary.json',JSON.stringify(rows,null,2));console.log(rows);
