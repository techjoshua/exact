import {spawn} from 'node:child_process';import {openSync,closeSync} from 'node:fs';
const dir='.tmp/bun-admission-2026-09-20';
for(const [i,variant] of ['production-trace','responsive','responsive','production-trace'].entries()){
const name=`responsive-check-${i}-${variant}`,fd=openSync(`${dir}/${name}.log`,'w');console.log('START',name);
try{await new Promise((done,fail)=>{const p=spawn(process.execPath,[`${dir}/${variant}-capture.mjs`,`${dir}/10000.json`,`${dir}/${name}.json`,'bun'],{stdio:['ignore',fd,fd]});p.once('error',fail);p.once('exit',code=>code===0?done():fail(Error('exit '+code)));});}finally{closeSync(fd);}console.log('DONE',name);
}
