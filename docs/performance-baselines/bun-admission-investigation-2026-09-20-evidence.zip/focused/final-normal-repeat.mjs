import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync,readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const dir='.tmp/bun-admission-2026-09-20';
const full=JSON.parse(readFileSync('.tmp/bun-admission-final-2026-09-20/execution.json'));
assert.equal(full.length,27);
assert.ok(full.every(step=>step.code===0),'Focused follow-up must not overlap full timing');
const plan={preloaded:false,drivers:2,stages:[
 {name:'warmup',mode:'concurrency',concurrency:8,durationMs:15000,discard:true},
 {name:'total-c32',mode:'concurrency',concurrency:16,durationMs:30000}
]};
writeFileSync(dir+'/final-normal-plan.json',JSON.stringify(plan,null,2));
const journal=[];
for(const [i,variant] of ['production','control-clean','control-clean','production'].entries()){
 const name=`final-normal-${i}-${variant}`;
 const args=[`${dir}/${variant}-matrix.mjs`,`${dir}/final-normal-plan.json`,`${dir}/${name}.json`,'bun'];
 const step={name,args,startedAt:new Date().toISOString()};journal.push(step);
 const save=()=>writeFileSync(dir+'/final-normal-execution.json',JSON.stringify(journal,null,2));
 save();console.log('START',name);
 const log=openSync(`${dir}/${name}.log`,'w');
 try{await new Promise((done,fail)=>{
  const child=spawn(process.execPath,args,{env:{...process.env,COMPARISON_SSR_RENDER_MODE:'stream'},stdio:['ignore',log,log]});
  step.pid=child.pid;save();child.once('error',fail);
  child.once('exit',(code,signal)=>{step.code=code;step.signal=signal;code===0?done():fail(Error(name+' exit '+(code??signal)));});
 });}finally{closeSync(log);step.endedAt=new Date().toISOString();save();}
 console.log('DONE',name);
}
