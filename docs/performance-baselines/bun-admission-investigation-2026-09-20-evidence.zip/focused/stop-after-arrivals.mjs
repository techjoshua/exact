import {readFileSync,writeFileSync} from 'node:fs';
const root='.tmp/bun-admission-final-2026-09-20';
while(true){
const journal=JSON.parse(readFileSync(root+'/execution.json'));
if(journal.some(s=>s.name==='bun-arrivals'&&s.code===0)){
const command=readFileSync('/proc/365498/cmdline','utf8');if(!command.includes('bun-admission-final-2026-09-20/run.mjs'))throw Error('Owner changed');
process.kill(365498,'SIGTERM');
for(const s of journal)if(s.code===undefined){s.interrupted=true;s.reason='Stopped after Bun arrivals: second 10k population did not reproduce latency improvement';s.endedAt=new Date().toISOString();}
writeFileSync(root+'/execution.json',JSON.stringify(journal,null,2));writeFileSync(root+'/interruption.json',JSON.stringify({at:new Date().toISOString(),reason:'Bun 10k p99 53.3–53.9 ms in second population; focused follow-up required',ownerPid:365498},null,2));console.log('Stopped task-owned namespace after completed arrivals');break;
}
await new Promise(r=>setTimeout(r,500));
}
