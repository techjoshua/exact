from pathlib import Path
p=Path('framework-adapters/bun-adapter/src/adaptive-gate.ts');s=p.read_text()
s=s.replace('type Sample = { lag: number; rate: number; count: number };','type Sample = { lag: number; rate: number; count: number; arrivals: number; utilization: number };')
s=s.replace(' * Sparse traffic creates no histogram', ' * Demand-limited trials may retain lower lag when native departures keep up with arrivals\n * and the event-loop thread has CPU headroom. Unsupported thread counters keep capacity-based\n * selection. A responsive selected policy tolerates isolated unhealthy samples before reassessment.\n * Sparse traffic creates no histogram')
s=s.replace('\tprivate controlLag = 0;', '\tprivate controlLag = 0;\n\tprivate cpu: NodeJS.CpuUsage | undefined;\n\tprivate hadHeadroom = false;\n\tprivate unhealthySamples = 0;')
s=s.replace('\t\tthis.started = now;', '\t\tthis.cpu = readThreadCpu();\n\t\tthis.started = now;')
s=s.replace("\t\t\tthis.phase = 'baseline';\n\t\t\tthis.nextPhase", "\t\t\tthis.phase = 'baseline';\n\t\t\tthis.hadHeadroom = false;\n\t\t\tthis.unhealthySamples = 0;\n\t\t\tthis.nextPhase")
s=s.replace("\t\tif (this.phase === 'enabled' && now >= this.until) {\n\t\t\tthis.restartBaseline(now);\n\t\t\treturn;\n\t\t}\n",'')
s=s.replace('\t\tconst sample: Sample = {','\t\tconst cpu = readThreadCpu();\n\t\tconst sample: Sample = {')
s=s.replace('\t\t\tcount: departures','\t\t\tcount: departures,\n\t\t\tarrivals: this.arrivals - this.windowArrivals,\n\t\t\tutilization:\n\t\t\t\tcpu && this.cpu\n\t\t\t\t\t? (cpu.user + cpu.system - this.cpu.user - this.cpu.system) / (elapsed * 1000)\n\t\t\t\t\t: Infinity')
s=s.replace('// Require evidence against both controls before retaining the trial.', '// Busy trials must beat both controls. With CPU headroom and native departures\n\t\t\t// keeping up, a lower-lag trial can instead demonstrate demand-limited capacity.')
s=s.replace('\t\t\t\tthis.trial!.rate > rate &&','\t\t\t\t(this.trial!.rate > rate || hasHeadroom(this.trial!)) &&')
s=s.replace('\t\t\tif (this.enabled) {','\t\t\tif (this.enabled) {\n\t\t\t\tthis.hadHeadroom = false;\n\t\t\t\tthis.unhealthySamples = 0;')
s=s.replace("\t\tif (this.phase === 'enabled') {\n\t\t\t// Recheck sooner when the observed benefit disappears, including a changed document mix.\n\t\t\tif (sample.rate <= this.controlRate || sample.lag >= this.controlLag)","""\t\tif (this.phase === 'enabled') {
			// Lower offered demand cannot prove a loss of capacity. Keep a responsive policy
			// while native departures keep up and the event-loop thread has spare CPU.
			if (hasHeadroom(sample)) {
				this.hadHeadroom = true;
				this.unhealthySamples = 0;
				this.resetWindow(now);
				return;
			}
			// Recent headroom tolerates two transient windows. Sustained busy work consumes
			// this grace even before the deadline, preserving prompt saturated reassessment.
			// Deferring a probe never resets its deadline.
			if (this.hadHeadroom && ++this.unhealthySamples >= 3) this.hadHeadroom = false;
			if (
				!this.hadHeadroom &&
				(now >= this.until || sample.rate <= this.controlRate || sample.lag >= this.controlLag)
			)""")
s=s.replace('\tprivate restartBaseline(now: number): void {','\tprivate restartBaseline(now: number): void {\n\t\tthis.hadHeadroom = false;\n\t\tthis.unhealthySamples = 0;')
s+='''
/**
 * Reads CPU microseconds for the event-loop thread only. Bun versions without a usable counter
 * retain capacity-based decisions; an unavailable or zeroed event-loop utilization API is not
 * evidence of spare capacity. No per-request probes or response-body interception are needed.
 */
function readThreadCpu(): NodeJS.CpuUsage | undefined {
	try {
		return process.threadCpuUsage?.();
	} catch {
		return undefined;
	}
}

/**
 * Bun's independent two-millisecond timer includes dispatch time. A sub-five-millisecond p95
 * together with 20% thread CPU headroom and native departures keeping pace identifies a responsive
 * demand-limited window. Departures include disconnects and do not assert response success.
 */
function hasHeadroom(sample: Sample): boolean {
	return (
		sample.lag < 5 &&
		sample.utilization > 0 &&
		sample.utilization < 0.8 &&
		sample.count >= sample.arrivals * 0.99
	);
}
'''
p.write_text(s)
