import {readFileSync,existsSync,writeFileSync} from 'node:fs';
const dir=import.meta.dirname,out=[];
for(const mode of ['string','stream']){
const rows=[];
for(const [i,variant] of ['production','control-clean','control-clean','production'].entries()){
const path=`${dir}/repeat-${mode}-${i}-${variant}.json`;if(!existsSync(path))continue;const r=JSON.parse(readFileSync(path));if(!r.complete)continue;
const rates=Object.fromEntries(r.blocks.map(b=>[b.id,b.results.reduce((n,d)=>n+d.stages[1].validRps,0)]));
rows.push({mode,i,variant,...rates,ratio:rates.exact/rates.react,errors:r.blocks.reduce((n,b)=>n+b.results.reduce((m,d)=>m+d.stages[1].errors,0),0)});
}
console.log(mode,rows);out.push(...rows);
if(rows.length===4){const mean=(v,k)=>rows.filter(r=>r.variant===v).reduce((n,r)=>n+r[k],0)/2;console.log('change',{absolute:100*(mean('production','exact')/mean('control-clean','exact')-1),relative:100*(mean('production','ratio')/mean('control-clean','ratio')-1)});}
}
writeFileSync(dir+'/repeat-summary.json',JSON.stringify(out,null,2));
