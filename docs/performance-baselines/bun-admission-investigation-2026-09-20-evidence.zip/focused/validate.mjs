import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync} from 'node:fs';
const dir='.tmp/bun-admission-2026-09-20',npm='/home/techj/.npm/_npx/3c6effcf97752e7c/node_modules/npm/bin/npm-cli.js',journal=[];
for(const [name,args] of [
['adapter-build',[npm,'run','build','-w','@exactjs/bun-adapter']],
['adapter-tests-final',[npm,'test','-w','@exactjs/bun-adapter']],
['native-tests-final',[npm,'run','test:bun','-w','@exactjs/bun-adapter']],
['package-contents',['scripts/check-package-contents.mjs']],
['platform-boundaries',['scripts/check-platform-boundaries.mjs']]]){
const fd=openSync(`${dir}/${name}.log`,'w'),row={name,start:new Date().toISOString()};journal.push(row);console.log('START',name);
try{await new Promise((done,fail)=>{const p=spawn(process.execPath,args,{stdio:['ignore',fd,fd]});p.once('error',fail);p.once('exit',code=>{row.code=code;code===0?done():fail(Error('exit '+code));});});}finally{closeSync(fd);row.end=new Date().toISOString();writeFileSync(dir+'/validation.json',JSON.stringify(journal,null,2));}console.log('DONE',name);
}
