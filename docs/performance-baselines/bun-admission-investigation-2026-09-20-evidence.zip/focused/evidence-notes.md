# Focused evidence provenance

All measurements ran serially with two load drivers in verified private Linux loopback namespaces. No builds or tests ran concurrently with timing.

Diagnostic `control`, `candidate`, `scheduled`, `immediate`, and `demand` arrival captures use copied adapter imports in their worker scripts. Their ordinary `artifacts.bunAdapter` field describes the installed workspace adapter, not the experimental copy. Read the worker imports and preparation scripts to identify the copy. Controller snapshots are diagnostic instrumentation, not publication-worker telemetry.

The first control and rejected process-CPU candidate ran before thread-CPU tracing was added. Their copies are reconstructed in `control-initial` and `candidate-initial` from the retained preparation scripts and control copy. The first candidate working copy was overwritten during later preparation; do not treat the `candidate` directory as its measured artifact. `reconstruct-first-prototype.py` records the reconstruction. These initial diagnostics do not claim a capture-time experimental-adapter hash.

Later `control`, `scheduled`, `immediate`, and `demand` copies retain thread-CPU tracing. Forced modes change `shouldSchedule` for diagnostics only; their internal phase labels are not their actual forced admission behavior.

The clean production matrix and repeated checks use uninstrumented admission. Each capture records `artifacts.experimentalAdapter` for the actual selected adapter, in addition to participant and workspace artifact hashes. `control-clean` was transpiled from the unchanged gate at c7d6a431. `production-focused` preserves the candidate output used in these checks. The first source commit fd135246 adds two ownership comments relative to that output, without changing its executable behavior. The interrupted first full attempt rebuilt fd135246 and retained a separate source snapshot. It is archived separately from the replacement full run.

Later copied adapters preserve each follow-up: `production-trace` is the conservative traced policy, `responsive` uses wider headroom limits, `capacity-production` adds the responsive busy-capacity rule, and `cadence-production` adds the final restored busy deadline timing. `cadence-production` corresponds to final implementation commit 44721c11. Trace workers are diagnostic; matrix, ABBA, soak, and full-publication workers are uninstrumented. The three-minute soak predates only the final busy-deadline restoration. The replacement full run rebuilds 44721c11, records a clean source snapshot, and does not combine results with the stopped first attempt.

The conservative traced control `responsive-check-3-production-trace.json` retains 17 reused-socket ECONNRESET errors. The evidence includes unfavorable results and stopped matrices. Per-second soak latency spikes remain in the raw intervals; aggregate p99 is not a latency bound.

The `final-normal-*` captures are an additional uninstrumented normal-streaming ABBA check after the replacement full run. They use the original copied adapter and the final workspace adapter against the unchanged full-run application artifacts. No production code changed between the full run and this follow-up.
