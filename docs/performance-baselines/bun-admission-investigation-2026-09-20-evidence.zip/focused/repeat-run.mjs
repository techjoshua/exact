import {spawn} from 'node:child_process';
import {openSync,closeSync} from 'node:fs';
const dir='.tmp/bun-admission-2026-09-20';
for(const mode of ['string','stream'])for(const [i,variant] of ['production','control-clean','control-clean','production'].entries()){
const name=`repeat-${mode}-${i}-${variant}`,fd=openSync(`${dir}/${name}.log`,'w');console.log('START',name);
try{await new Promise((done,fail)=>{const p=spawn(process.execPath,[`${dir}/${variant}-matrix.mjs`,`${dir}/${mode==='string'?'repeat-plan':'repeat-stream-plan'}.json`,`${dir}/${name}.json`,'bun'],{env:{...process.env,COMPARISON_SSR_RENDER_MODE:mode},stdio:['ignore',fd,fd]});p.once('error',fail);p.once('exit',code=>code===0?done():fail(Error('exit '+code)));});}finally{closeSync(fd);}console.log('DONE',name);
}
