from pathlib import Path
import shutil
out=Path('.tmp/bun-admission-2026-09-20')
for mode,enabled in [('scheduled','true'),('immediate','false')]:
 shutil.copytree(out/'control',out/mode,dirs_exist_ok=True)
 p=out/mode/'adaptive-gate.js';s=p.read_text().replace('return this.enabled;',f'return {enabled};');p.write_text(s)
 (out/f'{mode}-worker.mjs').write_text((out/'control-worker.mjs').read_text().replace('./control/',f'./{mode}/'))
 (out/f'{mode}-capture.mjs').write_text((out/'capture.mjs').read_text().replace('control-worker.mjs',f'{mode}-worker.mjs'))
