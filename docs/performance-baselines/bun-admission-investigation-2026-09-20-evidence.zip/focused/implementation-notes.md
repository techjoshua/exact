# Candidate acceptance criteria

The diagnostic copied adapter uses the existing native pending-request delta. It adds a demand-limited alternative only when main-thread CPU is below 80%, sampled timer p95 is below 5 ms, and at least 99% of arrivals have corresponding native departures in the window. It still requires trial lag to beat both surrounding controls. Three consecutive unhealthy windows exhaust grace after demonstrated headroom; sustained busy operation retains ordinary reassessment.

The 5 ms threshold is Bun-specific: the actual independent 2 ms timer observer reports roughly 3.3–3.9 ms under forced scheduling at 8k, with client p99 about 11 ms and main-thread CPU around 70%. Reusing Node's 3 ms threshold prevented any demand-limited retention.

A shipping implementation must use feature-detected thread CPU counters. Missing or unusable counters must disable the headroom exception, retaining rate/lag-based trials. It must never read the all-zero Bun event-loop utilization stub as headroom. Keep native Response ownership and cancellation unchanged.

Required checks: complete/incomplete native departures; unsupported counters; quiet cleanup; transient unhealthy recovery; sustained saturation reassessment; unchanged correctness and native body tests. Timed acceptance includes both offered rates, string and stream, normal and preloaded, and c16/32/64/128. Full suite follows only if focused candidates pass.
