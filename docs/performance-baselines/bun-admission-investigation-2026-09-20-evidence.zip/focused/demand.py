from pathlib import Path
import shutil
out=Path('.tmp/bun-admission-2026-09-20')
shutil.copytree(out/'control',out/'demand',dirs_exist_ok=True)
p=out/'demand/adaptive-gate.js';s=p.read_text()
s=s.replace("if (this.phase === 'enabled' && now >= this.until) {\n            this.restartBaseline(now);\n            return;\n        }",'')
s=s.replace('count: departures','count: departures, admissions: this.arrivals-this.windowArrivals, utilization: (()=>{const cpu=process.threadCpuUsage(this.traceThreadCpu); return (cpu.user+cpu.system)/(elapsed*1000);})()')
s=s.replace('this.trial.rate > rate &&','(this.trial.rate > rate || (this.trial.lag < 5 && this.trial.utilization < 0.8 && this.trial.count >= this.trial.admissions * 0.99)) &&')
s=s.replace("if (this.phase === 'enabled') {", """if (this.phase === 'enabled') {
            if (sample.lag < 5 && sample.utilization < 0.8 && sample.count >= sample.admissions * 0.99) {
                this.hadHeadroom = true; this.unhealthySamples = 0; this.resetWindow(now); return;
            }
            if (this.hadHeadroom && ++this.unhealthySamples >= 3) this.hadHeadroom = false;""")
s=s.replace('if (sample.rate <= this.controlRate || sample.lag >= this.controlLag)','if (!this.hadHeadroom && (now >= this.until || sample.rate <= this.controlRate || sample.lag >= this.controlLag))')
s=s.replace('this.enabled = false;', 'this.enabled = false; this.hadHeadroom = false; this.unhealthySamples = 0;')
p.write_text(s)
(out/'demand-worker.mjs').write_text((out/'control-worker.mjs').read_text().replace('./control/','./demand/'))
(out/'demand-capture.mjs').write_text((out/'capture.mjs').read_text().replace('control-worker.mjs','demand-worker.mjs'))
