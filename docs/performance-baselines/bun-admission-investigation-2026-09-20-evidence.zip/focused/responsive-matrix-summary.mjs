import {readFileSync,existsSync} from 'node:fs';
const dir='.tmp/bun-admission-2026-09-20';
for(const mode of ['string','stream'])for(const lane of ['preloaded','normal']){
 const read=v=>{const f=`${dir}/responsive-matrix-${mode}-${v}-${lane}.json`;if(!existsSync(f))return;const r=JSON.parse(readFileSync(f));return r.complete?r:undefined;};
 const a=read('control-clean'),b=read('production');if(!a||!b)continue;
 const rows=r=>r.blocks.flatMap(block=>block.results[0].stages.map((s,i)=>({id:block.id,name:s.name,rps:block.results.reduce((n,d)=>n+d.stages[i].validRps,0),errors:block.results.reduce((n,d)=>n+d.stages[i].errors,0)}))).filter(s=>s.name!=='warmup');
 const aa=rows(a),bb=rows(b);console.log(mode,lane);
 for(const x of aa.filter(s=>s.id==='exact')){const y=bb.find(s=>s.id==='exact'&&s.name===x.name),ar=aa.find(s=>s.id==='react'&&s.name===x.name),br=bb.find(s=>s.id==='react'&&s.name===x.name);console.log(x.name,{before:x.rps,after:y.rps,absolutePercent:100*(y.rps/x.rps-1),ratioPercent:100*((y.rps/br.rps)/(x.rps/ar.rps)-1),errors:x.errors+y.errors});}
}
