/**
 * Bun-owned admission controller. Lag triggers a trial; native request drain and lag
 * relative to surrounding immediate windows decide whether to retain it. Native departures include
 * disconnects, not just successful responses. Handler duration is
 * deliberately not treated as client latency because it excludes native response transmission.
 * Sparse traffic creates no histogram or timer. Idle monitoring disables and releases its timer.
 */
export declare class BunRequestGate {
    private readonly pendingRequests;
    private delay;
    private timer;
    private lastRequest;
    private recentRequests;
    private requests;
    private arrivals;
    private windowArrivals;
    private windowPending;
    private started;
    private enabled;
    private highSamples;
    private phase;
    private nextPhase;
    private until;
    private cooldown;
    private backoff;
    private baseline;
    private trial;
    private controlRate;
    private controlLag;
    /** Reads the host-wide native in-flight counter without intercepting response bodies. */
    constructor(pendingRequests: () => number);
    /** Observes every Fetch dispatch owned by this host. */
    observeRequest(): void;
    /** Whether the current request should enter the bounded render-start queue. */
    shouldSchedule(): boolean;
    private resetWindow;
    /** Reassesses capacity with immediate controls on both sides of a scheduled trial. */
    private sample;
    private restartBaseline;
}
//# sourceMappingURL=adaptive-gate.d.ts.map