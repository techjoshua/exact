import {readFile,writeFile} from 'node:fs/promises';
import {summarizeSsrCapacityCapture} from '../../framework-comparison/src/ssr-capacity-report.mjs';
const root=import.meta.dirname,prefix=root.split('/').at(-1),reference='arrival-policy-final-2026-09-20';
const json=async p=>JSON.parse(await readFile(p,'utf8'));
const source=await json(root+'/source-state.json'),report=await json(root+'/report-data.json'),raw=await json(root+'/ssr.json');
const f=(n,p=2)=>Number(n).toLocaleString('en-US',{minimumFractionDigits:p,maximumFractionDigits:p});
const lines=[`# Framework comparison after Bun admission-policy correction, September 20, 2026`,'',
`This full capture measures workspace-resolved 0.6.0 packages at revision \`${source.commit}\`, with component and render-program ABI 2. The Bun adapter now recognizes demand-limited scheduling benefits using native request departures and event-loop thread CPU. A responsive policy remains selected while native departures keep up, lag stays low, and thread CPU shows spare capacity. Recent headroom permits two transient unhealthy windows; sustained busy work retains prompt reassessment. Native body ownership, cancellation, and idle cleanup remain intact. See the [focused Bun admission investigation](bun-admission-investigation-2026-09-20.md).`,'',
`Environment: ${raw.environment.platform} ${raw.environment.platformRelease}; ${raw.environment.cpu.model}; ${raw.environment.cpu.logicalCount} logical CPUs; ${f(raw.environment.totalMemoryBytes/1024**3,1)} GiB RAM; Node ${raw.environment.runtimes.node}; Bun ${raw.environment.runtimes.bun}. All stages share one private Linux network namespace with verified native loopback. Host networking is unchanged.`,'',
'All five controlled participants are included in browser and string SSR measurements. Streaming covers eXact, React, and TanStack Start. The separate native track covers eXact and React. Browser timing uses 30 samples; startup uses ten samples at each of 1x/4x/6x CPU throttling; heap uses five samples. SSR diagnostics use 500 sequential requests, 500 16-request waves, and one 1,000 ms c32 diagnostic window. Native measurements retain seven samples. The participants retain shared presentation and all prior task, hydration, and response correctness fixes.','',
'## Sustained throughput and eXact/React ratios','',
`The concurrency protocols are unchanged from the [preceding full capture](${reference}.md): two independent drivers, reversed framework order, 10 seconds of c16 warmup, 15 seconds at each preloaded concurrency (16/32/64/128), and 20 seconds at normal-loading c32. Aggregate RPS includes drain. Ratio changes below use c32; a ratio above 1 favors eXact.`,'',
'| Runtime/API | Loading | eXact RPS | React RPS | eXact/React | Previous ratio | Ratio change |',
'| --- | --- | ---: | ---: | ---: | ---: | ---: |'];
const ratios=[],captures=[];let errors=0,invalid=0;
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const lane of ['multi','normal','arrivals']){
 const name=runtime+(mode==='stream'?'-stream':'')+'-'+lane,c=await json(root+'/'+name+'.json');captures.push(c);
 for(const b of c.blocks)for(const r of b.results)for(const s of r.stages){errors+=s.errors??0;invalid+=s.invalid??0;}
 if(lane==='arrivals')continue;
 const before=await json(`docs/performance-baselines/${reference}-${name}.json`);
 const rates=d=>{const s=summarizeSsrCapacityCapture(d).filter(r=>r.concurrency===32);const exact=s.find(r=>r.name==='eXact').rps,react=s.find(r=>r.name==='React').rps;return{exact,react,ratio:exact/react};};
 const a=rates(before),b=rates(c),change=(b.ratio/a.ratio-1)*100;
 ratios.push({runtime,mode,lane,before:a,after:b,ratioChangePercent:change});
 lines.push('| '+[runtime+'/'+mode,lane==='multi'?'preloaded':'normal',f(b.exact,0),f(b.react,0),f(b.ratio,3)+'×',f(a.ratio,3)+'×',(change>=0?'+':'')+f(change,1)+'%'].join(' | ')+' |');
}
lines.push('', 'The focused investigation compares old and new Bun adapters with unchanged participant artifacts. Full-run ratios are retained here, including unfavorable changes; the artifact comparison in the structured capture identifies which framework artifacts changed. Concurrency and scheduled-demand results answer different capacity questions.');
lines.push('','## Original reference','','Historical Windows/WSL comparisons include environment and correctness changes. Ratios remain the requested relative-performance measure, but do not isolate code changes. The [routing investigation](ssr-loopback-investigation-2026-09-20.md) demonstrates that unchanged framework artifacts can respond differently to the same network change.','','| Runtime/API | Loading | Current ratio | September 19 ratio | Ratio change |','| --- | --- | ---: | ---: | ---: |');
for(const r of await json(root+'/reference-comparisons.json')){const b=r.references['wsl-workspace-2026-09-19'];lines.push('| '+[r.runtime+'/'+r.mode,r.lane==='multi'?'preloaded':'normal',f(r.after.ratio,3)+'×',f(b.ratio,3)+'×',(b.ratioChangePercent>=0?'+':'')+f(b.ratioChangePercent,1)+'%'].join(' | ')+' |');}
lines.push('', 'These historical ratios retain the requested comparison with the original reference. Correctness and network conditions differ across older captures, so the table does not isolate those changes from the new admission policy.');
lines.push('','## Scheduled offered load','','Each framework/rate case owns fresh worker, service, and driver processes. Two drivers offer one total target rate, with 30 seconds of target-rate warmup followed by 60 seconds of measurement. The second population reverses framework and rate order. Each runtime/API capture contains eight cases. This protocol matches the immediately preceding full capture. Older sequential 20-second rate stages remain separate historical evidence.','','Valid RPS includes drain. Missed arrivals have no response-latency observation; response p99 ranges span four individual driver/population percentiles, not a pooled percentile or confidence interval. Warmup failures are retained separately.','','| Runtime/API | Framework | Offered RPS | Valid RPS | Misses | Request errors | Response p99 range, ms |','| --- | --- | ---: | ---: | ---: | ---: | ---: |');
for(const c of captures.filter(c=>c.plan.kind==='independent-arrival-rates')){
 for(const id of ['exact','react'])for(const rate of c.plan.rates){
 const blocks=c.blocks.filter(b=>b.id===id&&b.rate===rate),stages=blocks.flatMap(b=>b.results.flatMap(r=>r.stages.filter(s=>!s.discard)));
 const valid=stages.reduce((n,s)=>n+s.valid,0),offered=stages.reduce((n,s)=>n+s.offered,0),err=stages.reduce((n,s)=>n+s.errors,0),miss=stages.reduce((n,s)=>n+s.missedCapacity+s.missedLag+s.missedDeadline,0);
 const row=summarizeSsrCapacityCapture(c,{allowArrivalErrors:true}).find(r=>r.name===(id==='exact'?'eXact':'React')&&r.rate===rate);
 const tails=stages.map(s=>s.distributions.responseMs.p99);
 lines.push('| '+[c.runtimeId+'/'+c.renderMode,id,f(rate,0),f(row.rps,0),f(miss/offered*100)+'%',err,f(Math.min(...tails))+'–'+f(Math.max(...tails))].join(' | ')+' |');
 }
}
lines.push('',`Total request errors across capacity stages, including warmup: ${errors}. Invalid responses: ${invalid}.`,'','## Browser experience','','Each cell is mean / p50 / p95 / p99. Latency and memory: lower is better.','','| Metric | Unit | '+report.browserCharts[0].series.map(s=>s.name).join(' | ')+' |','| --- | --- | '+report.browserCharts[0].series.map(()=> '---:').join(' | ')+' |');
for(const c of report.browserCharts)lines.push('| '+[c.title,c.unit,...c.series.map(s=>['mean','p50','p95','p99'].map(k=>f(s.stats[k],3)).join(' / '))].join(' | ')+' |');
lines.push('','## SSR completion tails','','Completion of a 16-request wave, including data loading. Cells are mean / p95 / p99 milliseconds.','','| Runtime/API | '+report.server.burst.series.map(s=>s.name).join(' | ')+' |','| --- | '+report.server.burst.series.map(()=> '---:').join(' | ')+' |');
const stream=await json('apps/docs/src/data/ssr-stream-report.json');
for(const [mode,owner] of [['string',report.server],['stream',stream.server]])for(const runtime of ['node','bun']){const chart=(runtime==='node'?owner:owner.bun).burst;lines.push('| '+runtime+'/'+mode+' | '+report.server.burst.series.map(s=>{const r=chart.series.find(r=>r.name===s.name);return r?['mean','p95','p99'].map(k=>f(r.stats[k])).join(' / '):'unavailable';}).join(' | ')+' |');}
lines.push('','## Correctness and evidence','','Both runtimes passed 39 string and 25 streaming browser contracts before timing. The native track passed all 12 contracts. Startup CPU profiles, allocation captures, heap composition, raw response samples, and per-driver results remain separate evidence.','',`The [structured capture](${prefix}.json) links raw captures and records hashes, source state, runners, execution journal, and prior chart values. The [evidence archive](${prefix}-evidence.zip) retains source state, logs, plans, and documentation verification. Native samples are in [the native capture](${prefix}-native.json).`,'');
await writeFile(`docs/performance-baselines/${prefix}.md`,lines.join('\n'));
await writeFile(root+'/ratio-comparison.json',JSON.stringify(ratios,null,2)+'\n');
console.log(JSON.stringify({ratios,errors,invalid},null,2));
