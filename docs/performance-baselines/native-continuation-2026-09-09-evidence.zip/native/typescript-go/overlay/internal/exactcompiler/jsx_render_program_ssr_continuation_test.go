package exactcompiler

import (
	"encoding/base64"
	"strings"
	"testing"

	"github.com/microsoft/TypeScript/tsc/internal/core"
	"github.com/microsoft/TypeScript/tsc/internal/printer"
)

// The emitted fixture is also executed by the Node/Bun continuation audit. Go tests keep
// native compiler validation independent of installed JavaScript runtimes.
func TestSsrSinkContinuationEmission(t *testing.T) {
	context := printer.NewEmitContext()
	lowering := jsxLowering{factory: context.Factory}
	writer := lowering.directRenderProgramSsrSinkWriter(&renderProgramBuild{
		serverSegments: []string{"<main>", "|", "</main>"},
		serverSlots:    []int{0, 1},
		slots:          []renderProgramSlot{{kind: "child", id: "first"}, {kind: "child", id: "second"}},
	})
	emitter := printer.NewPrinter(printer.PrinterOptions{NewLine: core.NewLineKindLF, Target: core.ScriptTargetES2022}, printer.PrintHandlers{}, context)
	text := printer.NewTextWriter("\n", 0)
	emitter.Write(writer, nil, text, nil)
	code := text.String()
	if strings.Contains(code, ".output()") || strings.Contains(code, "await ") || strings.Count(code, "instanceof Promise") != 5 {
		t.Fatalf("writer lost caller-owned output or conditional settlement: %s", code)
	}
	t.Log("SSR_CONTINUATION_BASE64=" + base64.StdEncoding.EncodeToString([]byte(code)))
}

func TestSsrSinkContinuationEmptyAndWidePlans(t *testing.T) {
	for _, count := range []int{0, 512} {
		context := printer.NewEmitContext()
		lowering := jsxLowering{factory: context.Factory}
		build := &renderProgramBuild{serverSegments: make([]string, count+1)}
		for index := 0; index < count; index++ {
			build.serverSlots = append(build.serverSlots, index)
			build.slots = append(build.slots, renderProgramSlot{kind: "child", id: "item"})
		}
		writer := lowering.directRenderProgramSsrSinkWriter(build)
		emitter := printer.NewPrinter(printer.PrinterOptions{NewLine: core.NewLineKindLF, Target: core.ScriptTargetES2022}, printer.PrintHandlers{}, context)
		text := printer.NewTextWriter("\n", 0)
		emitter.Write(writer, nil, text, nil)
		if strings.Count(text.String(), "function __exactResume(") != 1 {
			t.Fatal("continuation nesting grows with the number of writes")
		}
	}
}
