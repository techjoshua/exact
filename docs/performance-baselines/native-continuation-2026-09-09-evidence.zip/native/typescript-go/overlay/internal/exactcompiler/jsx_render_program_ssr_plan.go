package exactcompiler

import "github.com/microsoft/TypeScript/tsc/internal/ast"

// renderProgramSsrWrite identifies a compiler-emitted write without rediscovering calls from
// printed JavaScript. Character assignments must resume with the settled operation result.
type renderProgramSsrWrite struct {
	statement         int
	method            string
	assignsCharacters bool
}

// renderProgramSsrPlan keeps preparation and ordered write sites in the same native AST plan.
// These are serialization boundaries, not proof that task-dependent inputs can be read early.
type renderProgramSsrPlan struct {
	statements                  []*ast.Node
	writes                      []renderProgramSsrWrite
	target, context, invocation *ast.Node
	output                      *ast.Node
	outputDeclaration           int
}

// directRenderProgramSsrWriter materializes the current writer ABI from its native emission plan.
// The output contract remains unchanged while continuation lowering is integrated separately.
func (lowering *jsxLowering) directRenderProgramSsrWriter(build *renderProgramBuild) *ast.Node {
	plan := lowering.directRenderProgramSsrPlan(build)
	parameters := lowering.factory.NewNodeList([]*ast.Node{
		lowering.factory.NewParameterDeclaration(nil, nil, plan.target, nil, nil, nil),
		lowering.factory.NewParameterDeclaration(nil, nil, plan.context, nil, nil, nil),
		lowering.factory.NewParameterDeclaration(nil, nil, plan.invocation, nil, nil, nil),
	})
	return lowering.factory.NewArrowFunction(
		nil, nil, parameters, nil, nil,
		lowering.factory.NewToken(ast.KindEqualsGreaterThanToken),
		lowering.factory.NewBlock(lowering.factory.NewNodeList(plan.statements), true),
	)
}
