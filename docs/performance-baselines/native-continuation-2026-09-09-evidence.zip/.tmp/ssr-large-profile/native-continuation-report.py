import pathlib,json,hashlib,zipfile
d=pathlib.Path('.tmp/ssr-large-profile')
for runtime in ['node','bun']:
    assert json.loads((d/f'native-continuation-{runtime}.json').read_text(encoding='utf8'))['cases']==9
assert len(json.loads((d/'native-continuation-bench.json').read_text(encoding='utf8')))==8
report=pathlib.Path('docs/performance-baselines/native-continuation-2026-09-09.md')
files=list(d.glob('native-continuation-*'))
files=[p for p in files if p.is_file()]
files += [pathlib.Path('native/typescript-go/overlay/internal/exactcompiler')/n for n in ['jsx_render_program_ssr_lowering.go','jsx_render_program_ssr_plan.go','jsx_render_program_ssr_continuation.go','jsx_render_program_ssr_continuation_test.go']]
files += [report,pathlib.Path('docs/ssr-hydration.md')]
files += [d/'native-writer-plan-audit.mjs',d/'native-writer-plan-results.json']
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=report.with_name(report.stem+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name in manifest:z.write(name,name)
    z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified',len(manifest),'archive hashes.')
