(__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
    const __exactValue_0 = __exactSsr.prepareChild(__exactInvocation, 0);
    if (__exactValue_0 === __exactSsr.unprepared)
        return;
    const __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
    if (__exactValue_1 === __exactSsr.unprepared)
        return;
    __exactSsr.begin(__exactContext, 0, 2, 14, 14);
    let __exactCharacters = 14;
    const __exactWrite_0 = __exactSsr.static(__exactOutput, "<main>");
    if (__exactWrite_0 instanceof Promise)
        return __exactWrite_0.then(__exactAfter_0);
    return __exactAfter_0(__exactWrite_0);
    function __exactAfter_0(__exactSettled_0) {
        const __exactDrain_0 = __exactOutput.sink.ready();
        if (__exactDrain_0)
            return __exactDrain_0.then(() => __exactResume_0(__exactSettled_0));
        return __exactResume_0(__exactSettled_0);
    }
    function __exactResume_0(__exactSettled_0) {
        const __exactWrite_1 = __exactSsr.child(__exactContext, __exactOutput, __exactValue_0, "first", __exactCharacters);
        if (__exactWrite_1 instanceof Promise)
            return __exactWrite_1.then(__exactAfter_1);
        return __exactAfter_1(__exactWrite_1);
        function __exactAfter_1(__exactSettled_1) {
            const __exactDrain_1 = __exactOutput.sink.ready();
            if (__exactDrain_1)
                return __exactDrain_1.then(() => __exactResume_1(__exactSettled_1));
            return __exactResume_1(__exactSettled_1);
        }
        function __exactResume_1(__exactSettled_1) {
            __exactCharacters = __exactSettled_1;
            const __exactWrite_2 = __exactSsr.static(__exactOutput, "|");
            if (__exactWrite_2 instanceof Promise)
                return __exactWrite_2.then(__exactAfter_2);
            return __exactAfter_2(__exactWrite_2);
            function __exactAfter_2(__exactSettled_2) {
                const __exactDrain_2 = __exactOutput.sink.ready();
                if (__exactDrain_2)
                    return __exactDrain_2.then(() => __exactResume_2(__exactSettled_2));
                return __exactResume_2(__exactSettled_2);
            }
            function __exactResume_2(__exactSettled_2) {
                const __exactWrite_3 = __exactSsr.child(__exactContext, __exactOutput, __exactValue_1, "second", __exactCharacters);
                if (__exactWrite_3 instanceof Promise)
                    return __exactWrite_3.then(__exactAfter_3);
                return __exactAfter_3(__exactWrite_3);
                function __exactAfter_3(__exactSettled_3) {
                    const __exactDrain_3 = __exactOutput.sink.ready();
                    if (__exactDrain_3)
                        return __exactDrain_3.then(() => __exactResume_3(__exactSettled_3));
                    return __exactResume_3(__exactSettled_3);
                }
                function __exactResume_3(__exactSettled_3) {
                    __exactCharacters = __exactSettled_3;
                    const __exactWrite_4 = __exactSsr.static(__exactOutput, "</main>");
                    if (__exactWrite_4 instanceof Promise)
                        return __exactWrite_4.then(__exactAfter_4);
                    return __exactAfter_4(__exactWrite_4);
                    function __exactAfter_4(__exactSettled_4) {
                        const __exactDrain_4 = __exactOutput.sink.ready();
                        if (__exactDrain_4)
                            return __exactDrain_4.then(() => __exactResume_4(__exactSettled_4));
                        return __exactResume_4(__exactSettled_4);
                    }
                    function __exactResume_4(__exactSettled_4) {
                        return __exactOutput;
                    }
                }
            }
        }
    }
}