import assert from 'node:assert/strict';
import {readFileSync, writeFileSync} from 'node:fs';

const writer = (0, eval)(`(${readFileSync('.tmp/ssr-large-profile/native-continuation-writer.js', 'utf8')})`);
const gate = () => { let resolve, reject; const promise = new Promise((a,b) => {resolve=a;reject=b;}); return {promise,resolve,reject}; };
function fixture({childGate, pressure, pressureAt='<main>', fail, unprepared=false}={}) {
  const events=[], counts=[];
  let draining;
  const output={sink:{ready(){return draining;}}};
  const target={
    unprepared:Symbol(),
    prepareChild(_invocation,index){return unprepared ? this.unprepared : index;},
    begin(){events.push('begin');},
    static(_output,text){
      events.push(text);
      if (text === pressureAt && pressure) {draining=pressure.promise.then(()=>{draining=undefined;});}
    },
    child(_context,_output,value,_id,characters){
      events.push(`child:${value}`);counts.push(characters);
      if (pressureAt===`child:${value}` && pressure) {draining=pressure.promise.then(()=>{draining=undefined;});}
      if (value===0 && fail) throw fail;
      if (value===0 && childGate) return childGate.promise.then(()=>characters+5);
      return characters+5;
    },
  };
  return {events,counts,output,run:()=>writer(target,{}, {},output)};
}
const expected=['begin','<main>','child:0','|','child:1','</main>'];
let cases=0;
{
  const childGate=gate(),pressure=gate(),f=fixture({childGate,pressure,pressureAt:'child:0'});
  const pending=f.run();childGate.resolve();
  await Promise.resolve();await Promise.resolve();
  assert.deepEqual(f.events,expected.slice(0,3));pressure.resolve();
  assert.equal(await pending,f.output);assert.deepEqual(f.counts,[14,19]);assert.deepEqual(f.events,expected);cases++;
}
{
  const pressure=gate(),f=fixture({pressure,pressureAt:'</main>'});
  const pending=f.run();assert.ok(pending instanceof Promise);assert.deepEqual(f.events,expected);
  let completed=false;pending.then(()=>{completed=true;});await Promise.resolve();assert.equal(completed,false);
  pressure.resolve();assert.equal(await pending,f.output);cases++;
}
{
  const f=fixture();assert.equal(f.run(),f.output);assert.deepEqual(f.events,expected);assert.deepEqual(f.counts,[14,19]);cases++;
}
{
  const childGate=gate(),f=fixture({childGate});const pending=f.run();
  assert.ok(pending instanceof Promise);assert.deepEqual(f.events,expected.slice(0,3));
  childGate.resolve();assert.equal(await pending,f.output);assert.deepEqual(f.events,expected);assert.deepEqual(f.counts,[14,19]);cases++;
}
{
  const pressure=gate(),f=fixture({pressure});const pending=f.run();
  assert.deepEqual(f.events,expected.slice(0,2));pressure.resolve();
  assert.equal(await pending,f.output);assert.deepEqual(f.events,expected);cases++;
}
for (const kind of ['child','drain','throw']) {
  const error=new Error(kind),g=gate();
  const f=fixture(kind==='child'?{childGate:g}:kind==='drain'?{pressure:g}:{fail:error});
  if (kind==='throw') assert.throws(f.run,e=>e===error);
  else {const pending=f.run();g.reject(error);await assert.rejects(pending,e=>e===error);}
  assert.deepEqual(f.events,expected.slice(0,kind==='drain'?2:3));cases++;
}
{
  const f=fixture({unprepared:true});assert.equal(f.run(),undefined);assert.deepEqual(f.events,[]);cases++;
}
const result={runtime:process.versions.bun?'bun':'node',versions:process.versions,cases};
writeFileSync(`.tmp/ssr-large-profile/native-continuation-${result.runtime}.json`,JSON.stringify(result,null,2));
console.log(JSON.stringify({runtime:result.runtime,cases}));
