package exactcompiler

import (
	"strconv"

	"github.com/microsoft/TypeScript/tsc/internal/ast"
)

// directRenderProgramSsrSinkWriter lowers the native write plan into conditional continuations.
// The supplied output owns its sink. Each operation settles before checking sink readiness;
// rejected operations or drains stop traversal. Preparation timing is deliberately unchanged.
// Runtime ABI selection remains separate until the sink contract is integrated.
func (lowering *jsxLowering) directRenderProgramSsrSinkWriter(build *renderProgramBuild) *ast.Node {
	plan := lowering.directRenderProgramSsrPlan(build)
	f := lowering.factory
	block := func(statements []*ast.Node) *ast.Node {
		return f.NewBlock(f.NewNodeList(statements), true)
	}
	property := func(receiver *ast.Node, name string) *ast.Node {
		return f.NewPropertyAccessExpression(receiver, nil, f.NewIdentifier(name), ast.NodeFlagsNone)
	}
	call := func(callee *ast.Node, args ...*ast.Node) *ast.Node {
		return f.NewCallExpression(callee, nil, nil, f.NewNodeList(args), ast.NodeFlagsNone)
	}
	constant := func(name, value *ast.Node) *ast.Node {
		return f.NewVariableStatement(nil, f.NewVariableDeclarationList(f.NewNodeList([]*ast.Node{
			f.NewVariableDeclaration(name, nil, nil, value),
		}), ast.NodeFlagsConst))
	}
	function := func(name, parameter *ast.Node, statements []*ast.Node) *ast.Node {
		return f.NewFunctionDeclaration(nil, nil, name, nil, f.NewNodeList([]*ast.Node{
			f.NewParameterDeclaration(nil, nil, parameter, nil, nil, nil),
		}), nil, nil, block(statements))
	}
	// Fold from the end so each continuation owns exactly the remaining ordered statements.
	// Declarations preceding a write retain their lexical scope across suspension.
	tail := len(plan.statements)
	var rest []*ast.Node
	for index := len(plan.writes) - 1; index >= 0; index-- {
		write := plan.writes[index]
		rest = append(append([]*ast.Node{}, plan.statements[write.statement+1:tail]...), rest...)
		expression := plan.statements[write.statement].AsExpressionStatement().Expression
		settled := f.NewIdentifier("__exactSettled_" + strconv.Itoa(index))
		if write.assignsCharacters {
			assignment := expression.AsBinaryExpression()
			rest = append([]*ast.Node{f.NewExpressionStatement(lowering.binary(assignment.Left, ast.KindEqualsToken, settled))}, rest...)
			expression = assignment.Right
		}
		result := f.NewIdentifier("__exactWrite_" + strconv.Itoa(index))
		after := f.NewIdentifier("__exactAfter_" + strconv.Itoa(index))
		resume := f.NewIdentifier("__exactResume_" + strconv.Itoa(index))
		drain := f.NewIdentifier("__exactDrain_" + strconv.Itoa(index))
		afterBody := []*ast.Node{
			constant(drain, call(property(property(plan.output, "sink"), "ready"))),
			f.NewIfStatement(drain, f.NewReturnStatement(call(property(drain, "then"), lowering.arrow(call(resume, settled)))), nil),
			f.NewReturnStatement(call(resume, settled)),
		}
		rest = []*ast.Node{
			constant(result, expression),
			f.NewIfStatement(lowering.binary(result, ast.KindInstanceOfKeyword, f.NewIdentifier("Promise")),
				f.NewReturnStatement(call(property(result, "then"), after)), nil),
			f.NewReturnStatement(call(after, result)),
			function(after, settled, afterBody),
			function(resume, settled, rest),
		}
		tail = write.statement
	}
	if len(plan.writes) == 0 {
		rest = plan.statements
	} else {
		rest = append(append([]*ast.Node{}, plan.statements[:tail]...), rest...)
	}
	// Output storage belongs to the caller, not a second compiler-generated accumulator.
	rest = append(rest[:plan.outputDeclaration:plan.outputDeclaration], rest[plan.outputDeclaration+1:]...)
	parameters := []*ast.Node{}
	for _, name := range []*ast.Node{plan.target, plan.context, plan.invocation, plan.output} {
		parameters = append(parameters, f.NewParameterDeclaration(nil, nil, name, nil, nil, nil))
	}
	return f.NewArrowFunction(nil, nil, f.NewNodeList(parameters), nil, nil,
		f.NewToken(ast.KindEqualsGreaterThanToken), block(rest))
}
