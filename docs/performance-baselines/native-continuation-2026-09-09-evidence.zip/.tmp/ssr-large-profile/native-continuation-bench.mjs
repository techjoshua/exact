import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
if(process.argv[2]==='worker') {
  const variant=process.argv[3];
  const writer=(0,eval)(`(${readFileSync(`.tmp/ssr-large-profile/native-continuation-${variant}.js`,'utf8')})`);
  const sink={ready(){return undefined;}};
  const target={unprepared:Symbol(),prepareChild(_invocation,index){return index;},begin(){},
    static(output,text){output.value+=text;},
    child(_context,output,value,_id,count){const text=`hello${value}`;output.value+=text;return count+text.length;}};
  const context={},invocation={};
  function render(){const output={value:'',sink};assert.equal(writer(target,context,invocation,output),output);return output.value;}
  assert.equal(render(),'<main>hello0|hello1</main>');
  for(let i=0;i<100000;i++)render();
  let checksum=0;const start=performance.now();
  for(let i=0;i<1000000;i++)checksum+=render().length;
  const ns=(performance.now()-start)*1000000/1000000;
  assert.equal(checksum,26000000);
  console.log(JSON.stringify({variant,runtime:process.versions.bun?'bun':'node',ns,checksum}));
} else {
  const results=[];
  for(const runtime of ['node','bun'])for(const order of [['nested','writer'],['writer','nested']])for(const variant of order){
    const r=spawnSync(runtime,[import.meta.filename,'worker',variant],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
    if(r.status!==0)throw Error(r.stderr+r.stdout);
    const sample=JSON.parse(r.stdout);results.push(sample);console.log(sample);
  }
  writeFileSync('.tmp/ssr-large-profile/native-continuation-bench.json',JSON.stringify(results,null,2));
}
