import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const r=spawnSync('go',['test','./internal/exactcompiler','-run','^TestSsrSinkContinuationEmission$','-v','-count=1'],{cwd:'.tmp/native-typescript-go/tsc',encoding:'utf8',windowsHide:true});
if(r.status!==0)throw Error(r.stderr+r.stdout);
writeFileSync('.tmp/ssr-large-profile/native-continuation-go.txt',r.stdout);
const encoded=r.stdout.match(/SSR_CONTINUATION_BASE64=([A-Za-z0-9+/=]+)/)?.[1];
if(!encoded)throw Error('Native fixture was not emitted');
writeFileSync('.tmp/ssr-large-profile/native-continuation-writer.js',Buffer.from(encoded,'base64'));
for(const runtime of ['node','bun']) {
  const audit=spawnSync(runtime,['.tmp/ssr-large-profile/native-continuation-audit.mjs'],{stdio:'inherit',windowsHide:true});
  if(audit.status!==0)process.exit(audit.status??1);
}
