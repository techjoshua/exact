import fs from 'node:fs';
const file='.tmp/ssr-large-profile/direct-list-http.json';
const rows=JSON.parse(fs.readFileSync(file,'utf8'));
if(rows.length!==24)throw Error('Incomplete HTTP capture');
let text=`

Typechecking, compiled ABI compatibility, platform boundaries, affected-file lint, source
architecture, JSDoc, and package contents pass. The canonical eXact client and both server targets
were rebuilt. All 56 production browser checks pass across Node/Bun and string/stream modes,
including hydration, navigation, live updates, focus preservation, and failure recovery. No ABI
fixture was regenerated. This stage does not rerun browser performance timings.

## Paired HTTP comparison

The previous shared-invoker build was frozen separately for Node and Bun before rebuilding the
canonical targets. Each runtime/mode uses two reversed-order populations of previous eXact,
current eXact, and React. Workers run in production mode. Two independent drivers each supply 16
concurrent requests, for 32 total, with two seconds of warmup and four seconds measured. Every
completed response is checked against its full-body hash. The three-incident controlled-service
snapshot is preloaded, and every participant renders its complete document with four asset tags.
Node uses its HTTP adapter; Bun uses the native fetch adapter. The shared machine and short run
windows limit precision. These are focused capacity samples, not a replacement public baseline.

| Runtime | Mode | Previous eXact req/s | Current eXact req/s | React req/s | eXact change |
| --- | --- | ---: | ---: | ---: | ---: |
`;
for(const runtime of ['node','bun'])for(const mode of ['string','stream']) {
 const values=['baseline','candidate','react'].map(variant=>{
  const samples=rows.filter(row=>row.runtime===runtime&&row.mode===mode&&row.variant===variant);
  if(samples.length!==2)throw Error('Missing paired population');
  return samples.reduce((sum,row)=>sum+row.rps,0)/samples.length;
 });
 text+=`| ${runtime} | ${mode} | ${values.map(v=>Math.round(v).toLocaleString('en-US')).join(' | ')} | +${((values[1]/values[0]-1)*100).toFixed(1)}% |\n`;
}
const errors=rows.reduce((sum,row)=>sum+row.errors,0);
if(errors!==0)throw Error('HTTP response errors require investigation');
text+=`
All 24 populations completed with zero response errors. The Node streaming advantage remains.
Bun streaming is approximately 1.4% below React in this capture; that difference is small relative
to shared-host uncertainty and does not establish superiority. Bun strings remain about 5.1%
below React, and Node strings about 27.2% below. The overall objective remains unmet.

The next compiler investigation should examine the emitted continuation scaffolding of small
programs. Two synchronous writes currently select the general state-machine writer, whereas one
terminal write has a compact body. Any alternative must retain readiness after each write and
resume without repeating preparation. This is an investigation target, not an implemented or
measured improvement, and it must continue using the same renderer and sink contract.

The [evidence archive](direct-server-lists-2026-09-10-evidence.zip) preserves raw renderer/HTTP
populations, production profiles, immutable before/prototype/current artifacts, source, validation
logs, runners, and a per-file hash manifest. Reproduction requires the locked workspace and matching
runtime versions. Earlier compiler source and initial-contract evidence remain in the preceding
caller-owned writer archive.
`;
fs.appendFileSync('docs/performance-baselines/direct-server-lists-2026-09-10.md',text);
