import fs from 'node:fs';
let source=fs.readFileSync('.tmp/ssr-large-profile/http.mjs','utf8');
source=source.replace("'.tmp/ssr-large-profile/baseline.mjs'", "'.tmp/ssr-large-profile/direct-list-http-before/dist-server/server-entry.js'");
source=source.replace("'.tmp/compiled-document/candidate/exact-bun.mjs'", "'.tmp/ssr-large-profile/direct-list-http-before/dist-bun-server/bun-server-entry.js'");
const tags='<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">';
source=source.replace('COMPARISON_SSR_RENDER_MODE:mode,', 'COMPARISON_SSR_RENDER_MODE:mode,COMPARISON_CLIENT_TAGS:'+JSON.stringify(tags)+',');
source=source.replace('const identity={bytes:html.length,', `for(const asset of ['/assets/app.js','/assets/vendor.js','/assets/app.css','/assets/theme.css']) assert.ok(html.toString().includes(asset));const identity={bytes:html.length,`);
fs.writeFileSync('.tmp/ssr-large-profile/direct-list-http.mjs',source);
