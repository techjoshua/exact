import { spawnSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
const directory = '.tmp/ssr-large-profile/shared-small-profile';
for (const runtime of ['node', 'bun']) for (const [variant, entry] of Object.entries({
	exact: '.tmp/ssr-large-profile/shared-invoker-current/server-entry.js',
	react: 'framework-comparison/participants/react/dist-server/server-entry.js'
})) {
	const result = spawnSync(runtime, [
		'--cpu-prof', `--cpu-prof-dir=${directory}`, `--cpu-prof-name=${runtime}-${variant}.cpuprofile`,
		'.tmp/ssr-large-profile/production-refresh-worker.mjs', entry, 'string', 'assets', '100000'
	], { encoding: 'utf8', windowsHide: true, env: { ...process.env, NODE_ENV: 'production' } });
	if (result.status !== 0) throw Error(result.stderr + result.stdout);
	writeFileSync(`${directory}/${runtime}-${variant}.json`, JSON.stringify({
		nodeEnv: 'production', ...JSON.parse(result.stdout)
	}, null, 2));
	console.log(runtime, variant, 'profile complete');
}

