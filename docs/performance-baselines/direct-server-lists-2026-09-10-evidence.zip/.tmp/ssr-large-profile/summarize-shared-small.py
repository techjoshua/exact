import json
from pathlib import Path
from collections import Counter
for p in Path('.tmp/ssr-large-profile/shared-small-profile').glob('*.cpuprofile'):
 d=json.loads(p.read_text()); nodes={n['id']:n for n in d['nodes']}; hits=Counter(d.get('samples',[])); total=sum(hits.values()); counts=Counter()
 for ident,count in hits.items():
  f=nodes[ident]['callFrame']; counts[(f['functionName'],f.get('url',''),f.get('lineNumber',0)+1)]+=count
 entries=[{'name':name,'url':url,'line':line,'hits':count,'share':round(count/total*100,2)} for (name,url,line),count in counts.most_common()]
 p.with_suffix('.summary.json').write_text(json.dumps({'total':total,'entries':entries},indent=2))
 print(p.name,total,json.dumps([{k:v for k,v in e.items() if k!='url'} for e in entries[:10]]))
