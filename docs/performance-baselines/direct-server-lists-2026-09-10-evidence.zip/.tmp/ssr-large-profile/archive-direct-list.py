from pathlib import Path
from hashlib import sha256
import json
import zipfile

root=Path.cwd()
output=root/'docs/performance-baselines/direct-server-lists-2026-09-10-evidence.zip'
paths=set()
def include(name):
    path=root/name
    if not path.exists():
        raise FileNotFoundError(path)
    if path.is_dir():
        paths.update(p for p in path.rglob('*') if p.is_file())
    else:
        paths.add(path)

for path in (root/'.tmp/ssr-large-profile').iterdir():
    if path.is_file() and path.name.startswith(('direct-list-', 'direct-fragment-current-', 'report-direct-list', 'archive-direct-list', 'profile-shared-small', 'summarize-shared-small')):
        paths.add(path)
for name in ['.tmp/ssr-large-profile/shared-small-profile',
             '.tmp/ssr-large-profile/shared-invoker-current',
             '.tmp/ssr-large-profile/direct-fragment-current',
             '.tmp/ssr-large-profile/direct-list-current',
             '.tmp/ssr-large-profile/direct-list-http-before',
             '.tmp/ssr-large-profile/final-rope-worker.mjs',
             '.tmp/ssr-large-profile/production-refresh-worker.mjs',
             '.tmp/ssr-large-profile/source-sink-build.mjs',
             '.tmp/ssr-large-profile/http.mjs',
             '.tmp/positional-leaves/data.json',
             '.tmp/native-compiler/win32-x64.build.json',
             'packages/ssr/src', 'packages/ssr/package.json',
             'framework-comparison/src', 'framework-comparison/e2e',
             'framework-comparison/playwright.config.ts', 'framework-comparison/package.json',
             'framework-comparison/participants/exact/src',
             'framework-comparison/participants/exact/dist',
             'framework-comparison/participants/exact/dist-server',
             'framework-comparison/participants/exact/dist-bun-server',
             'framework-comparison/participants/react/src',
             'framework-comparison/participants/react/dist',
             'framework-comparison/participants/react/dist-server',
             'framework-comparison/participants/react/dist-bun-server',
             'scripts/development-process-lifecycle.mjs',
             'fixtures/release-abi', 'scripts/contracts/release-abi.json',
             'docs/ssr-hydration.md', 'docs/performance-baselines/direct-server-lists-2026-09-10.md',
             'package.json', 'package-lock.json']:
    include(name)

manifest=[]
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for path in sorted(paths):
        relative=path.relative_to(root).as_posix()
        content=path.read_bytes()
        archive.writestr(relative,content)
        manifest.append({'path':relative,'bytes':len(content),'sha256':sha256(content).hexdigest()})
    archive.writestr('evidence-manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
print(json.dumps({'path':str(output),'files':len(manifest),'bytes':output.stat().st_size,
                  'sha256':sha256(output.read_bytes()).hexdigest()}))
