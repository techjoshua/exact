import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const directory='.tmp/ssr-large-profile/';
const input=directory+'shared-invoker-current/server-entry.js';
let source=fs.readFileSync(input,'utf8');
function replace(before,after){assert.equal(source.split(before).length-1,1,before);source=source.replace(before,after);}
replace('return createCompiledFragmentReceipt({ key: id }, ...[...unwrap(collection)].map((item) => createPreparedServerKeyedChild(render(item), key(item))));', `const children = [...unwrap(collection)].map((item) => createPreparedServerKeyedChild(render(item), key(item)));
 const rawKey=unwrap(id);
 return { [prototypeServerFragment]: true, children, key:rawKey==null?undefined:String(rawKey) };`);
replace('const keyed = readPreparedServerKeyedChild(child);', `if(typeof child==='object' && child!==null && prototypeServerFragment in child) return mapRenderValue(target.renderDirectServerFragment(child), operationResult);
 const keyed = readPreparedServerKeyedChild(child);`);
replace('renderDirectServerChildRange(data) {', `renderDirectServerFragment(data) {
 return renderFragmentReceipt(this.context, data, this.parent, this.options, this.hasComponentAncestor, this.renderChildren);
 }
 renderDirectServerChildRange(data) {`);
source+='\nvar prototypeServerFragment=Symbol.for("@exactjs/server/prepared-fragment-experiment");\n';
const output=directory+'direct-fragment-current';
fs.mkdirSync(output,{recursive:true});fs.writeFileSync(output+'/server-entry.js',source);
fs.writeFileSync(output+'/provenance.json',JSON.stringify({input,inputSha256:createHash('sha256').update(fs.readFileSync(input)).digest('hex'),outputSha256:createHash('sha256').update(source).digest('hex'),hypothesis:'Eliminate the server map helper generic fragment round trip, preserving existing fragment traversal.'},null,2));
