import fs from 'node:fs';
const directory='.tmp/ssr-large-profile/';
let text=`# Direct server lists, September 10, 2026

Status: renderer experiment and source integration. This report follows the
[caller-owned writer integration](caller-owned-writer-integration-2026-09-10.md).

## Profile and hypothesis

Fresh production Node and Bun profiles use the retained shared-invoker artifact and React, with
100,000 small-document string renders after warmup. The complete application-owned document has
four build asset tags. CPU samples are diagnostic, not throughput results. Frames at the same
source location are aggregated across calling contexts.

Node eXact has 11.35% of samples in garbage collection, versus React's 2.87%. Opaque-operation
creation accounts for 3.28% of eXact samples, fragment receipt creation for 2.22%, and prepared
render-program creation for 3.16%. These observations do not prove greater total allocated bytes
or identify a leak. They motivate examining the lifetime and representation of those allocations.
Bun's sample population is smaller; its largest frames include document prefix inspection and
positional validation. Asset parsing is present in both applications and remains unchanged.

The direct server frame's map helper constructed a generic fragment receipt with metadata and
private registration, then SSR immediately redeemed it to render its children and key. Hypothesis:
retaining a direct server list carrier could reduce small-document render time by 2-6% without
changing traversal. An older fragment prototype script had been written but not executed; the new
prototype is applied to the current shared-invoker build and actually measured here.

## Implementation and contract

The server-only helper now retains already-issued keyed children in a realm-branded, request-local
list carrier. The existing fragment renderer still owns marker identity, child order, backpressure,
and descendant lifetimes. Generic authored fragments continue to use their enhancement-capable
receipts. The direct map helper cannot attach enhancements to its container. No second renderer,
sink-type branch, client marker change, or new application API is introduced.

The iterable is still fully materialized before item callbacks, and each render callback precedes
its key callback. Key coercion occurs after child construction, as before. Scheduled child issuance
remains in the component issuer, independent of the list container. The optimization does not cache
request values or reuse mutable component state across requests.

## Paired renderer measurements

Each population runs in a fresh production process, warms 5,000 renders, and measures 8,000. Two
reversed-order populations cover each runtime/mode/document combination. Table entries are means
in microseconds per render, lower is better. Complete eXact document hashes match across variants.
String mode returns a complete string; encoded additionally constructs and consumes a Response
for each render. Stream mode consumes every stream through Response.text. These are renderer and
consumer measurements, not HTTP request rates. The host is shared and short-run variation remains.

| Stage | Runtime | Mode | Document | Previous | Direct list | React |
| --- | --- | --- | --- | ---: | ---: | ---: |
`;
for(const [stage,file,modes] of [['prototype','direct-fragment-current-results.json',['string','stream']],['rebuilt','direct-list-current-results.json',['string','encoded','stream']]]) {
 const rows=JSON.parse(fs.readFileSync(directory+file,'utf8'));
 for(const runtime of ['node','bun'])for(const mode of modes)for(const scenario of ['assets','large']) {
  const values=['current','direct','react'].map(variant=>{
   const samples=rows.filter(row=>row.runtimeId===runtime&&row.mode===mode&&row.scenario===scenario&&row.variant===variant);
   if(samples.length!==2)throw Error('Incomplete renderer capture');
   return (samples.reduce((sum,row)=>sum+row.usPerRender,0)/samples.length).toFixed(2);
  });
  text+=`| ${stage} | ${runtime} | ${mode} | ${scenario==='assets'?'small':'large'} | ${values.join(' | ')} |\n`;
 }
}
text+=`
The rebuilt variant improves all twelve case averages, though some large-document changes are
small and individual pairs vary. The direct list representation is retained: it removes the
generic receipt round trip and preserves the shared fragment renderer. This does not establish
React parity in the remaining string and Bun streaming cases.

## Validation

All 336 SSR tests pass, including added comparisons against generic fragment output for empty and
populated lists, marked/unmarked output, and escaped keys. Tests preserve iterable snapshot and
callback order, and verify scheduled-child disposal after completion and cancellation.
`;
fs.writeFileSync('docs/performance-baselines/direct-server-lists-2026-09-10.md',text);
