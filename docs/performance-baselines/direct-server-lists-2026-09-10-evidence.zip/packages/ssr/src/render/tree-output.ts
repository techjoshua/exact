import type { Child } from '@exactjs/core';
import { componentDomainUsesWallClock } from '@exactjs/core/framework/component-domains';
import { processExactOutput } from '@exactjs/plugin-host/runtime';
import type { RenderToStringOptions, RenderToStringResult, SsrContext } from '../types.js';
import { renderChildren } from './children.js';
import { createSsrContext } from './context.js';
import { mapRenderValue, withRenderCleanup, type RenderValue } from './execution.js';
import { assertOutputWithinLimit, countSsrNode, withTaskDeadline } from './limits.js';
import { SsrOperationTarget } from './operation-target.js';
import { StringProgramSink } from './string-program-sink.js';
import { createChunkedStringResult } from './output-result.js';
import { attachSsrRootExecutionBlueprint } from './root-execution-cache.js';
import { readServerComponentReference } from './server-component-reference.js';

/** Renders one tree under its caller's owner, returning completed output without a promise hop. */
export function renderTreeOutput(
	operation: Child,
	options: RenderToStringOptions,
	omitRootBoundary: boolean,
	outputKind: 'html' | 'stream' = 'html'
): RenderValue<RenderToStringResult> {
	if (options.outputExtensions?.length)
		return processExactOutput(
			operation,
			{ kind: 'operation', signal: options.signal },
			options.outputExtensions
		).then((value) => renderSelectedTree(value as Child, options, omitRootBoundary, outputKind));
	return renderSelectedTree(operation, options, omitRootBoundary, outputKind);
}

function renderSelectedTree(
	operation: Child,
	options: RenderToStringOptions,
	omitRootBoundary: boolean,
	outputKind: 'html' | 'stream'
): RenderValue<RenderToStringResult> {
	const renderOptions = withTaskDeadline(options);
	const context = createSsrContext(renderOptions);
	const sink = new StringProgramSink(context.maxOutputBytes);
	context.writerSink = sink;
	return withRenderCleanup(
		() =>
			renderCollectedTree(
				context,
				sink,
				operation,
				options,
				renderOptions,
				omitRootBoundary,
				outputKind
			),
		() => sink.destroy()
	);
}

/** The request owns its destination across descendant rendering and output extensions. */
function renderCollectedTree(
	context: SsrContext,
	sink: StringProgramSink,
	operation: Child,
	options: RenderToStringOptions,
	renderOptions: RenderToStringOptions,
	omitRootBoundary: boolean,
	outputKind: 'html' | 'stream'
): RenderValue<RenderToStringResult> {
	attachSsrRootExecutionBlueprint(context, operation);
	let rendered: RenderValue<string>;
	if (omitRootBoundary) {
		const component = readServerComponentReference(operation);
		if (!component) throw new TypeError('Compiler root proof requires a component operation');
		countSsrNode(context);
		rendered = new SsrOperationTarget(
			context,
			undefined,
			renderOptions,
			false,
			renderChildren
		).renderCompilerClosedRootComponent(component);
	} else rendered = renderChildren(context, [operation], undefined, renderOptions);
	return mapRenderValue(rendered, (html) => {
		if (html) sink.write(html);
		const chunks = [sink.finish(context.reactResourceHints)];
		const finish = (chunks: readonly string[]) =>
			createChunkedStringResult(
				chunks,
				options.state,
				context.hydrationTable?.value(),
				context.resourceLinkHeaders ?? [],
				context.componentDomain && componentDomainUsesWallClock(context.componentDomain)
					? context.wallClockSnapshot
					: undefined
			);
		if (!options.outputExtensions?.length) return finish(chunks);
		return processExactOutput(
			chunks.length === 1 ? chunks[0]! : chunks.join(''),
			{ kind: outputKind, signal: options.signal },
			options.outputExtensions
		).then((value) => {
			const html = value as string;
			assertOutputWithinLimit(context, html);
			return finish([html]);
		});
	});
}
