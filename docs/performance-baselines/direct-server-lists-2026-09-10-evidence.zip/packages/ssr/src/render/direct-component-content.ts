import { normalizeRenderResult, type AnyComponentInstance, type Child } from '@exactjs/core';
import {
	readPreparedServerRenderProgram,
	type ExactPreparedServerRenderProgram
} from '@exactjs/core/framework/server-render-structure';
import type { SsrContext } from '../types.js';
import type { RenderValue } from './execution.js';
import { renderPreparedSsrProgram } from './render-program.js';
import type { ServerComponentReference } from './server-component-reference.js';

/** Compiler-closed result before its program or ordinary children execute through the shared sink. */
export type DirectSsrComponentContent =
	| Readonly<{ children: Child[]; program?: never }>
	| Readonly<{ children?: never; program: ExactPreparedServerRenderProgram }>;

/** Classifies raw component output before generic child normalization loses its server ABI. */
export function readDirectSsrContent(value: unknown): DirectSsrComponentContent {
	const program = readPreparedServerRenderProgram(value);
	return program ? { program } : { children: normalizeRenderResult(value as Child | Child[]) };
}

/** Serializes direct component content through caller-owned recursive rendering operations. */
export function renderDirectSsrContent(
	context: SsrContext,
	content: DirectSsrComponentContent,
	parent: AnyComponentInstance | undefined,
	renderChildren: (
		children: readonly Child[],
		parent: AnyComponentInstance | undefined
	) => RenderValue<string>,
	renderOwnedComponent: (
		component: ServerComponentReference,
		parent: AnyComponentInstance | undefined
	) => RenderValue<string>,
	prepareReferences: (
		values: readonly unknown[],
		owner: AnyComponentInstance | undefined
	) => AsyncDisposable | undefined
): RenderValue<string> {
	if (content.children) return renderChildren(content.children, parent);
	return renderPreparedSsrProgram(
		context,
		content.program,
		(value) =>
			Array.isArray(value)
				? renderChildren(value, parent)
				: renderOwnedComponent(value as ServerComponentReference, parent),
		(values) => prepareReferences(values, parent)
	);
}
