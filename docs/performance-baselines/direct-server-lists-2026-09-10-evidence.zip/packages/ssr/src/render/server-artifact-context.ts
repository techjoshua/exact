import type { AnyComponentInstance, Child } from '@exactjs/core';
import type { SsrContext } from '../types.js';
import type { DirectSsrComponentPublisher } from './direct-component-contracts.js';
import type { SsrRenderOptions } from './entrypoints.js';
import type { RenderValue } from './execution.js';
import type { ServerComponentReference } from './server-component-reference.js';

/** Request-owned rendering and publication capabilities shared by synchronous and scheduled artifacts. */
export type ServerArtifactExecution<Publication> = Readonly<{
	context: SsrContext;
	options: SsrRenderOptions;
	publication: Publication;
	publish: DirectSsrComponentPublisher<Publication>;
	renderChildren(
		children: readonly Child[],
		parent: AnyComponentInstance | undefined
	): RenderValue<string>;
	renderOwnedComponent(
		component: ServerComponentReference,
		parent: AnyComponentInstance | undefined
	): RenderValue<string>;
}>;
