import { expect, it } from 'vitest';
import { createSsrContext } from './context.js';
import { renderProgramWriter } from './program-writer-output.js';

it.each([false, true])(
	'preserves output and releases prepared siblings with shared=%s',
	async (shared) => {
		const context = createSsrContext({ markers: false });
		let published = '';
		let disposed = 0;
		if (shared)
			context.writerSink = {
				write(html) {
					published += html;
				},
				ready() {},
				flush() {}
			};
		const result = await renderProgramWriter<string>(
			context,
			undefined,
			undefined,
			async (output) => {
				output.preparation = output.prepareReferences?.(['child']);
				output.sink.write('before');
				output.sink.write(await output.render('child'));
				output.sink.write('after');
				return output;
			},
			(value) => value,
			() => ({
				async [Symbol.asyncDispose]() {
					disposed++;
				}
			})
		);
		expect(published + result).toBe('beforechildafter');
		expect(disposed).toBe(1);
	}
);

it.each(['throw', 'reject', 'invalid'] as const)(
	'releases preparation after writer %s',
	async (failure) => {
		const context = createSsrContext({ markers: false });
		let disposed = 0;
		const error = new Error('writer failed');
		const result = renderProgramWriter(
			context,
			undefined,
			undefined,
			(output) => {
				output.preparation = {
					async [Symbol.asyncDispose]() {
						disposed++;
					}
				};
				if (failure === 'throw') throw error;
				if (failure === 'reject') return Promise.reject(error);
				return undefined;
			},
			() => ''
		);
		await expect(result).rejects.toThrow(
			failure === 'invalid' ? 'caller-owned output' : 'writer failed'
		);
		expect(disposed).toBe(1);
	}
);

it('retains document ancestry while head publication is backpressured', async () => {
	const context = createSsrContext({ markers: false });
	let release!: () => void;
	const pressure = new Promise<void>((resolve) => {
		release = resolve;
	});
	let published = '';
	context.writerSink = {
		write(html) {
			published += html;
		},
		ready() {},
		flush() {
			return pressure;
		}
	};
	const result = renderProgramWriter(
		context,
		'html',
		undefined,
		async (outer) => {
			outer.sink.write('<html>');
			await renderProgramWriter(
				context,
				'head',
				undefined,
				(head) => {
					head.sink.write('<head><title>Ready</title></head>');
					return head;
				},
				() => ''
			);
			outer.sink.write('<body></body></html>');
			return outer;
		},
		() => ''
	);
	expect(published).toBe('<!doctype html><html><head><title>Ready</title></head>');
	expect(context.hostStack).toEqual(['html', 'head']);
	release();
	expect(await result).toBe('');
	expect(context.hostStack).toEqual([]);
});

it('keeps captured enhancement prefixes local', async () => {
	const context = createSsrContext({ markers: false });
	const route = {
		identity: 'route',
		props: {},
		componentDepth: 0,
		consumed: false,
		nested: false,
		nestedBefore: undefined as string | undefined
	};
	context.enhancementOperationRoutes = [route];
	const result = await renderProgramWriter(
		context,
		undefined,
		undefined,
		(output) => {
			output.sink.write('before');
			route.nested = true;
			output.sink.write('target');
			return output;
		},
		() => ''
	);
	expect(route.nestedBefore).toBe('before');
	expect(result).toBe('target');
});
