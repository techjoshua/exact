import { startClientBenchmarkHarness } from './client-benchmark-harness.mjs';
import { brotliCompressSync, gzipSync } from 'node:zlib';
import { execFileSync } from 'node:child_process';
import { cpus, platform, release, totalmem } from 'node:os';
import { mkdir, readFile, readdir, stat, writeFile } from 'node:fs/promises';
import { extname, relative, resolve } from 'node:path';
import { performance } from 'node:perf_hooks';
import { chromium } from 'playwright';
import { measureRetainedMemory } from './browser-memory.mjs';
import { waitForFirstContentfulPaint } from './paint-timing.mjs';
import { installBrowserVitals, readBrowserVitals } from './browser-vitals.mjs';
import { summarizePercentiles, summarizeSampleMetric } from './percentile-summary.mjs';
import { hashArtifactDirectory, hashSemanticResponse } from './artifact-integrity.mjs';
import { balancedRoundNames, balancedRoundOrder } from './balanced-round-order.mjs';

if (!process.argv.includes('--correctness-passed')) {
	throw new Error('Run `npm run measure` so the shared correctness suite gates every measurement.');
}

const suiteRoot = resolve(import.meta.dirname, '..');
const repositoryRoot = resolve(suiteRoot, '..');
const sampleCount = Number(process.env.COMPARISON_SAMPLES ?? 30);
if (!Number.isSafeInteger(sampleCount) || sampleCount < 1)
	throw new Error('Invalid COMPARISON_SAMPLES');
const browserWarmupCount = 1;
const measurementRound = nonNegativeInteger(process.env.COMPARISON_MEASUREMENT_ROUND, 0);
const participants = [
	{
		id: 'exact-controlled',
		directory: 'exact',
		source: 'src',
		artifact: 'dist',
		url: 'http://127.0.0.1:4401'
	},
	{
		id: 'react-controlled',
		directory: 'react',
		source: 'src',
		artifact: 'dist',
		url: 'http://127.0.0.1:4402'
	},
	{
		id: 'sveltekit-controlled',
		directory: 'sveltekit',
		source: 'src',
		artifact: 'build/client',
		url: 'http://127.0.0.1:4403'
	},
	{
		id: 'nuxt-controlled',
		directory: 'nuxt',
		source: 'app',
		artifact: '.output/public',
		url: 'http://127.0.0.1:4404'
	},
	{
		id: 'tanstack-start-controlled',
		directory: 'tanstack-start',
		source: 'src',
		artifact: '.output/public',
		url: 'http://127.0.0.1:4405'
	}
];

const buildOrder = balancedRoundOrder(participants, measurementRound);
const builds = Object.fromEntries(
	buildOrder.map((participant) => [participant.id, measureBuild(participant.directory)])
);
const harness = await startClientBenchmarkHarness(participants);
let browser;

try {
	browser = await chromium.launch();
	const samples = Object.fromEntries(participants.map((participant) => [participant.id, []]));
	const warmupOrders = [];
	for (let round = 0; round < browserWarmupCount; round++) {
		const order = balancedRoundOrder(participants, round, measurementRound);
		warmupOrders.push(order.map((participant) => participant.id));
		for (const participant of order) await measureBrowserSample(browser, participant);
	}
	const sampleOrders = [];
	for (let round = 0; round < sampleCount; round++) {
		console.log(`Browser round ${round + 1}/${sampleCount}`);
		const order = balancedRoundOrder(participants, round, measurementRound);
		sampleOrders.push(order.map((participant) => participant.id));
		for (const participant of order)
			samples[participant.id].push(await measureBrowserSample(browser, participant));
	}
	const browserResults = Object.fromEntries(
		participants.map((participant) => [
			participant.id,
			createParticipantResult(participant, samples[participant.id])
		])
	);
	assertEquivalentBrowserResponses(browserResults);
	const result = {
		schemaVersion: 1,
		kind: 'framework-comparison-raw-run',
		createdAt: new Date().toISOString(),
		correctness: { status: 'passed', command: 'npm run test:e2e' },
		publishable: true,
		environment: environmentMetadata(),
		harness: {
			commit: git('rev-parse', 'HEAD'),
			workingTreeDirty: git('status', '--porcelain').length > 0,
			sampleCount,
			browserWarmupCount,
			measurementRound,
			buildOrder: buildOrder.map((participant) => participant.id),
			warmupOrders,
			sampleOrders,
			order: balancedRoundNames(participants, 0, measurementRound),
			measurementTopology: 'balanced-round-interleaved',
			clientDelivery: harness.evidence(),
			paintTiming: { canonical: 'first-contentful-paint.startTime' }
		},
		browser: browserResults,
		controlledService: await measureControlledService(),
		build: builds,
		complexity: await Promise.all(participants.map(profileParticipant)),
		limitations: [
			'Browser samples use local loopback without network or CPU throttling.',
			'Every timed round measures one fresh sample from each participant in balanced rotating order.',
			'Every sample uses a fresh context with HTTP cache disabled, after one discarded scenario per participant; the shared browser process is warm.',
			'Chromium heap is an experimental post-GC retained point-in-time signal, not a repeated-lifecycle leak measurement.',
			'Controlled-service requests are sequential loopback probes and do not measure framework SSR.'
		]
	};
	const output = outputPath();
	await mkdir(resolve(output, '..'), { recursive: true });
	await writeFile(output, `${JSON.stringify(result, null, 2)}\n`);
	console.log(`Raw comparison run written to ${relative(repositoryRoot, output)}`);
} finally {
	try {
		await browser?.close();
	} finally {
		await harness.close();
	}
}

function createParticipantResult(participant, samples) {
	const responseHashes = new Set(samples.map((sample) => sample.responseHash));
	if (responseHashes.size !== 1)
		throw new Error(`${participant.id} produced unstable semantic browser responses`);
	return {
		temperature: 'warm-process-cold-context',
		warmupCount: browserWarmupCount,
		heapMeasurement: 'post-interaction-post-gc-retained',
		samples,
		response: { hash: samples[0].responseHash, stable: true },
		summary: summarizeBrowser(samples)
	};
}

function assertEquivalentBrowserResponses(results) {
	const hashes = new Set(Object.values(results).map((result) => result.response.hash));
	if (hashes.size !== 1)
		throw new Error('Controlled browser participants produced different semantic responses');
}

/** Measures browser-owned event-to-mutation latency without including automation actionability waits. */
async function measureBrowserSample(browserInstance, participant) {
	await resetService({});
	const context = await browserInstance.newContext();
	try {
		const page = await context.newPage();
		const browserErrors = [];
		const failedRequests = [];
		page.on('console', (message) => {
			if (message.type() === 'error') browserErrors.push(message.text());
		});
		page.on('pageerror', (error) => browserErrors.push(error.message));
		page.on('requestfailed', (request) =>
			failedRequests.push(`${request.method()} ${request.url()}: ${request.failure()?.errorText}`)
		);
		await page.addInitScript(installInteractionTiming);
		await page.addInitScript(installBrowserVitals);
		const session = await context.newCDPSession(page);
		await session.send('Network.enable');
		await session.send('Network.setCacheDisabled', { cacheDisabled: true });
		await session.send('Performance.enable');
		// EventSource intentionally keeps the network active, so semantic readiness gates the sample.
		await page.goto(`${participant.url}/incidents/inc-100`, { waitUntil: 'domcontentloaded' });
		await page.getByRole('heading', { name: 'Checkout authorization failures' }).waitFor();
		const firstContentfulPaintMs = await page.evaluate(waitForFirstContentfulPaint);
		await page.waitForLoadState('load');
		const navigation = await page.evaluate(() => {
			const entry = performance.getEntriesByType('navigation')[0];
			const scripts = performance
				.getEntriesByType('resource')
				.filter(
					(resource) => resource.initiatorType === 'script' || /\.m?js(?:$|\?)/.test(resource.name)
				)
				.reduce((sum, resource) => sum + (resource.transferSize || 0), 0);
			return {
				durationMs: entry?.duration ?? null,
				domContentLoadedMs: entry?.domContentLoadedEventEnd ?? null,
				loadEventMs: entry?.loadEventEnd ?? null,
				transferredScriptBytes: scripts
			};
		});
		navigation.firstContentfulPaintMs = firstContentfulPaintMs;
		try {
			await page.locator('.connection').getByText('Live service', { exact: true }).waitFor();
		} catch (error) {
			throw new Error(
				`Live service readiness failed for ${participant.id}. ` +
					`Requests: ${failedRequests.join(' | ') || '<none>'}. ` +
					`Browser: ${browserErrors.join(' | ') || '<none>'}.`,
				{ cause: error }
			);
		}
		await page.getByRole('button', { name: 'Claim incident' }).click();
		await page.getByText('Alex Chen', { exact: true }).waitFor();
		await page.getByText('Version 2', { exact: true }).waitFor();
		const timing = await page.evaluate(() => globalThis.__frameworkComparisonTiming);
		if (timing?.optimisticFeedbackMs == null || timing.settlementMs == null)
			throw new Error(`Missing browser interaction timing for ${participant.id}`);
		// Collect retained memory after interaction timing. A forced collection immediately before the
		// click would turn optimistic feedback into a cold-allocation recovery measurement.
		const memory = await measureRetainedMemory(session);
		const vitals = await page.evaluate(readBrowserVitals);
		const semanticResponse = await page.evaluate(() => ({
			heading: document.querySelector('h1, h2')?.textContent?.trim() ?? null,
			owner: document.querySelector('.facts > div:first-child strong')?.textContent?.trim() ?? null,
			version: document.querySelector('.version')?.textContent?.trim() ?? null
		}));
		if (browserErrors.length || failedRequests.length)
			throw new Error(`${participant.id}: ${[...browserErrors, ...failedRequests].join(' | ')}`);
		return {
			navigation,
			vitals,
			heapBytes: memory.jsHeapUsedBytes,
			memory,
			optimisticFeedbackMs: timing.optimisticFeedbackMs,
			settlementMs: timing.settlementMs,
			phasesMs: timing.phasesMs,
			responseHash: hashSemanticResponse(semanticResponse)
		};
	} finally {
		await context.close();
	}
}

/** Installs a participant-neutral click-to-visible-mutation clock in the page's own time domain. */
function installInteractionTiming() {
	const timing = {
		startedAt: null,
		optimisticFeedbackMs: null,
		settlementMs: null,
		phasesMs: {}
	};
	globalThis.__frameworkComparisonTiming = timing;
	const mark = (phase) => {
		if (timing.startedAt === null || timing.phasesMs[phase] !== undefined) return;
		timing.phasesMs[phase] = performance.now() - timing.startedAt;
	};

	const nativeFetch = globalThis.fetch;
	globalThis.fetch = (...args) => {
		const input = args[0];
		const url = typeof input === 'string' ? input : input instanceof Request ? input.url : '';
		if (url.endsWith('/claim')) mark('request-dispatched');
		return nativeFetch(...args).then((response) => {
			if (url.endsWith('/claim')) mark('http-headers-received');
			return response;
		});
	};
	const nativeResponseJson = Response.prototype.json;
	Response.prototype.json = function () {
		return nativeResponseJson.call(this).then((value) => {
			if (this.url.endsWith('/claim')) mark('http-json-decoded');
			return value;
		});
	};
	const observedEventSources = new WeakSet();
	const nativeAddEventListener = EventSource.prototype.addEventListener;
	EventSource.prototype.addEventListener = function (type, listener, options) {
		if (type === 'incident' && !observedEventSources.has(this)) {
			observedEventSources.add(this);
			nativeAddEventListener.call(this, type, () => mark('sse-incident-received'));
		}
		return nativeAddEventListener.call(this, type, listener, options);
	};
	document.addEventListener(
		'click',
		(event) => {
			const button = event.target instanceof Element ? event.target.closest('button') : null;
			if (button?.textContent?.trim() !== 'Claim incident' || timing.startedAt !== null) return;
			timing.startedAt = performance.now();
		},
		true
	);
	new MutationObserver(() => {
		if (timing.startedAt === null) return;
		const now = performance.now();
		const owner = document.querySelector('.facts > div:first-child strong')?.textContent?.trim();
		const version = document.querySelector('.version')?.textContent?.trim();
		if (timing.optimisticFeedbackMs === null && owner === 'Alex Chen') {
			timing.optimisticFeedbackMs = now - timing.startedAt;
			timing.phasesMs['optimistic-dom-visible'] ??= timing.optimisticFeedbackMs;
		}
		if (timing.settlementMs === null && version === 'Version 2') {
			timing.settlementMs = now - timing.startedAt;
			timing.phasesMs['authoritative-dom-visible'] ??= timing.settlementMs;
		}
	}).observe(document, { childList: true, characterData: true, subtree: true });
}

async function measureControlledService() {
	await resetService({});
	const durations = [];
	const started = performance.now();
	for (let index = 0; index < 100; index += 1) {
		const requestStarted = performance.now();
		const response = await fetch('http://127.0.0.1:4310/api/incidents');
		if (!response.ok) throw new Error(`Server probe failed with ${response.status}`);
		await response.arrayBuffer();
		durations.push(performance.now() - requestStarted);
	}
	const elapsedMs = performance.now() - started;
	return {
		kind: 'controlled-service-loopback',
		samplesMs: durations,
		summary: {
			requests: durations.length,
			requestsPerSecond: (durations.length / elapsedMs) * 1_000,
			latencyMs: summarizePercentiles(durations)
		}
	};
}

function measureBuild(directory) {
	const started = performance.now();
	if (process.platform === 'win32') {
		execFileSync(
			process.env.ComSpec ?? 'cmd.exe',
			['/d', '/s', '/c', `npm.cmd run build:${directory}`],
			{ cwd: suiteRoot, stdio: 'ignore' }
		);
	} else {
		execFileSync('npm', ['run', `build:${directory}`], { cwd: suiteRoot, stdio: 'ignore' });
	}
	return { cleanBuildMs: performance.now() - started };
}

async function profileParticipant(participant) {
	const sourceRoot = resolve(suiteRoot, 'participants', participant.directory, participant.source);
	const files = await sourceFiles(sourceRoot);
	let lines = 0;
	let testLines = 0;
	let transportSites = 0;
	let synchronizationSites = 0;
	for (const path of files) {
		const source = await readFile(path, 'utf8');
		const count = source.split(/\r?\n/).length;
		if (/\.(?:test|spec)\.[cm]?[jt]sx?$/.test(path)) testLines += count;
		else lines += count;
		transportSites += (source.match(/\bfetch\s*\(|\bEventSource\s*\(/g) ?? []).length;
		synchronizationSites += (
			source.match(/optimistic|rollback|conflict|abort|latest|reconnect/gi) ?? []
		).length;
	}
	const artifact = await artifactSizes(
		resolve(suiteRoot, 'participants', participant.directory, participant.artifact)
	);
	return {
		participantId: participant.id,
		authoredProductionLines: lines,
		authoredTestLines: testLines,
		sourceFiles: files.length,
		manualTransportSites: transportSites,
		synchronizationSites,
		artifacts: artifact
	};
}

async function artifactSizes(directory) {
	const files = await allFiles(directory);
	let rawBytes = 0;
	let gzipBytes = 0;
	let brotliBytes = 0;
	for (const path of files) {
		const bytes = await readFile(path);
		rawBytes += bytes.length;
		gzipBytes += gzipSync(bytes).length;
		brotliBytes += brotliCompressSync(bytes).length;
	}
	return {
		rawBytes,
		gzipBytes,
		brotliBytes,
		files: files.length,
		hash: await hashArtifactDirectory(directory)
	};
}

async function sourceFiles(directory) {
	return (await allFiles(directory)).filter(
		(path) =>
			['.ts', '.tsx', '.js', '.jsx', '.vue', '.svelte'].includes(extname(path)) &&
			!/[\\/]routeTree\.gen\.ts$/u.test(path)
	);
}

async function allFiles(directory) {
	const result = [];
	for (const entry of await readdir(directory, { withFileTypes: true })) {
		const path = resolve(directory, entry.name);
		if (entry.isDirectory()) result.push(...(await allFiles(path)));
		else if ((await stat(path)).isFile()) result.push(path);
	}
	return result;
}

function summarizeBrowser(samples) {
	return {
		navigationMs: summarizeSampleMetric(samples, (sample) => sample.navigation.durationMs),
		domContentLoadedMs: summarizeSampleMetric(
			samples,
			(sample) => sample.navigation.domContentLoadedMs
		),
		loadEventMs: summarizeSampleMetric(samples, (sample) => sample.navigation.loadEventMs),
		transferredScriptBytes: summarizeSampleMetric(
			samples,
			(sample) => sample.navigation.transferredScriptBytes
		),
		firstContentfulPaintMs: summarizeSampleMetric(
			samples,
			(sample) => sample.navigation.firstContentfulPaintMs
		),
		largestContentfulPaintMs: summarizeSampleMetric(
			samples,
			(sample) => sample.vitals.largestContentfulPaintMs
		),
		totalBlockingTimeMs: summarizeSampleMetric(
			samples,
			(sample) => sample.vitals.totalBlockingTimeMs
		),
		longTaskCount: summarizeSampleMetric(samples, (sample) => sample.vitals.longTaskCount),
		longTaskDurationMs: summarizeSampleMetric(
			samples,
			(sample) => sample.vitals.longTaskDurationMs
		),
		domElementCount: summarizeSampleMetric(samples, (sample) => sample.vitals.domElementCount),
		domNodeCount: summarizeSampleMetric(samples, (sample) => sample.vitals.domNodeCount),
		domCommentCount: summarizeSampleMetric(samples, (sample) => sample.vitals.domCommentCount),
		domTextCount: summarizeSampleMetric(samples, (sample) => sample.vitals.domTextCount),
		heapBytes: summarizeSampleMetric(samples, (sample) => sample.heapBytes),
		jsHeapTotalBytes: summarizeSampleMetric(samples, (sample) => sample.memory.jsHeapTotalBytes),
		embedderHeapUsedBytes: summarizeSampleMetric(
			samples,
			(sample) => sample.memory.embedderHeapUsedBytes
		),
		backingStorageBytes: summarizeSampleMetric(
			samples,
			(sample) => sample.memory.backingStorageBytes
		),
		documentCount: summarizeSampleMetric(samples, (sample) => sample.memory.documents),
		retainedNodeCount: summarizeSampleMetric(samples, (sample) => sample.memory.nodes),
		eventListenerCount: summarizeSampleMetric(samples, (sample) => sample.memory.eventListeners),
		optimisticFeedbackMs: summarizeSampleMetric(samples, (sample) => sample.optimisticFeedbackMs),
		settlementMs: summarizeSampleMetric(samples, (sample) => sample.settlementMs),
		requestDispatchedMs: summarizeSampleMetric(
			samples,
			(sample) => sample.phasesMs['request-dispatched']
		),
		sseIncidentReceivedMs: summarizeSampleMetric(
			samples,
			(sample) => sample.phasesMs['sse-incident-received']
		),
		httpHeadersReceivedMs: summarizeSampleMetric(
			samples,
			(sample) => sample.phasesMs['http-headers-received']
		),
		httpJsonDecodedMs: summarizeSampleMetric(
			samples,
			(sample) => sample.phasesMs['http-json-decoded']
		)
	};
}

async function resetService(body) {
	const response = await fetch('http://127.0.0.1:4310/__benchmark/reset', {
		method: 'POST',
		headers: { 'content-type': 'application/json', 'x-benchmark-control': 'fixture-reset' },
		body: JSON.stringify(body)
	});
	if (!response.ok) throw new Error(`Fixture reset failed with ${response.status}`);
}

function environmentMetadata() {
	const cpu = cpus()[0];
	return {
		node: process.version,
		platform: platform(),
		platformRelease: release(),
		cpu: cpu ? { model: cpu.model, logicalCount: cpus().length } : null,
		totalMemoryBytes: totalmem(),
		chromium: chromium.executablePath()
	};
}

function git(...arguments_) {
	return execFileSync('git', arguments_, { cwd: repositoryRoot, encoding: 'utf8' }).trim();
}

function nonNegativeInteger(value, fallback) {
	const parsed = Number(value ?? fallback);
	if (!Number.isSafeInteger(parsed) || parsed < 0)
		throw new TypeError('Measurement round must be a non-negative integer');
	return parsed;
}

function outputPath() {
	const option = process.argv.find((argument) => argument.startsWith('--output='));
	if (option) return resolve(repositoryRoot, option.slice('--output='.length));
	return resolve(repositoryRoot, '.tmp', 'framework-comparison', `raw-${Date.now()}.json`);
}
