import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
const dir='.tmp/ssr-large-profile/', rows=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const threshold of [2048,8192])for(let pair=0;pair<2;pair++)for(const variant of pair?['candidate','control']:['control','candidate']) {
 const result=spawnSync(runtime,[dir+'publication-large-tree-worker.mjs',variant,mode,String(threshold)],{encoding:'utf8',env:{...process.env,NODE_ENV:'production'},windowsHide:true});
 if(result.status!==0)throw new Error(result.stderr||result.stdout);
 const row={runtimeName:runtime,pair,...JSON.parse(result.stdout)};
 if(rows.length && rows[0].hash!==row.hash)throw new Error('Document mismatch');
 rows.push(row);fs.writeFileSync(dir+'publication-large-tree-results.json',JSON.stringify(rows,null,2));
 console.log(runtime,mode,threshold,pair,variant,row.us.toFixed(2));
}
