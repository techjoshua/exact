import {readFileSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {transform} from 'esbuild';
const dir='.tmp/ssr-large-profile/';
const prior=JSON.parse(readFileSync(dir+'direct-writer-real-siblings-compile.json','utf8'));
const request={...prior.request,id:dir+'publication-large-stages.tsx',source:prior.request.source+`
export function StagedDocument(){return ()=><html><head><link rel="stylesheet" href="/app.css"/></head><body><ScheduledChild index={1}/><ScheduledChild index={2}/><ScheduledChild index={3}/><ScheduledChild index={4}/><ScheduledChild index={5}/><ScheduledChild index={6}/><ScheduledChild index={7}/><ScheduledChild index={8}/><ScheduledChild index={9}/><ScheduledChild index={10}/><ScheduledChild index={11}/><ScheduledChild index={12}/><ScheduledChild index={13}/><ScheduledChild index={14}/><ScheduledChild index={15}/><ScheduledChild index={16}/><ScheduledChild index={17}/><ScheduledChild index={18}/><ScheduledChild index={19}/><ScheduledChild index={20}/><ScheduledChild index={21}/><ScheduledChild index={22}/><ScheduledChild index={23}/><ScheduledChild index={24}/><ScheduledChild index={25}/><ScheduledChild index={26}/><ScheduledChild index={27}/><ScheduledChild index={28}/><ScheduledChild index={29}/><ScheduledChild index={30}/><ScheduledChild index={31}/><ScheduledChild index={32}/><ScheduledChild index={33}/><ScheduledChild index={34}/><ScheduledChild index={35}/><ScheduledChild index={36}/><ScheduledChild index={37}/><ScheduledChild index={38}/><ScheduledChild index={39}/><ScheduledChild index={40}/><ScheduledChild index={41}/><ScheduledChild index={42}/><ScheduledChild index={43}/><ScheduledChild index={44}/><ScheduledChild index={45}/><ScheduledChild index={46}/><ScheduledChild index={47}/><ScheduledChild index={48}/><ScheduledChild index={49}/><ScheduledChild index={50}/><ScheduledChild index={51}/><ScheduledChild index={52}/><ScheduledChild index={53}/><ScheduledChild index={54}/><ScheduledChild index={55}/><ScheduledChild index={56}/><ScheduledChild index={57}/><ScheduledChild index={58}/><ScheduledChild index={59}/><ScheduledChild index={60}/><ScheduledChild index={61}/><ScheduledChild index={62}/><ScheduledChild index={63}/><ScheduledChild index={64}/><ScheduledChild index={65}/><ScheduledChild index={66}/><ScheduledChild index={67}/><ScheduledChild index={68}/><ScheduledChild index={69}/><ScheduledChild index={70}/><ScheduledChild index={71}/><ScheduledChild index={72}/><ScheduledChild index={73}/><ScheduledChild index={74}/><ScheduledChild index={75}/><ScheduledChild index={76}/><ScheduledChild index={77}/><ScheduledChild index={78}/><ScheduledChild index={79}/><ScheduledChild index={80}/><ScheduledChild index={81}/><ScheduledChild index={82}/><ScheduledChild index={83}/><ScheduledChild index={84}/><ScheduledChild index={85}/><ScheduledChild index={86}/><ScheduledChild index={87}/><ScheduledChild index={88}/><ScheduledChild index={89}/><ScheduledChild index={90}/><ScheduledChild index={91}/><ScheduledChild index={92}/><ScheduledChild index={93}/><ScheduledChild index={94}/><ScheduledChild index={95}/><ScheduledChild index={96}/></body></html>;}
`};
const run=spawnSync('.tmp/native-compiler/exactc.exe',[],{input:JSON.stringify(request)+'\n',encoding:'utf8',windowsHide:true,maxBuffer:32*1024*1024});
if(run.status!==0)throw Error(run.stderr||run.stdout);
const response=JSON.parse(run.stdout);writeFileSync(dir+'publication-large-stages-compile.json',JSON.stringify({request,response},null,2));
if(response.error||response.diagnostics.some(d=>d.severity==='error'))throw Error(JSON.stringify(response.diagnostics));
let code=(await transform(response.code,{loader:'ts',format:'esm',target:'esnext'})).code;
let stages=0,programs=0;
function lower(body){
 const match=/  (__exactCharacters = )?(__exactSsr\.(?:static|rootOpening|text|child|keyedChild|component|directComponent|attribute|compiledAttribute|attributes)\([^\n]+\));/.exec(body);
 if(!match)return body;
 const id=stages++,result='__writeResult_'+id,after='__afterWrite_'+id,resume='__resumeWrite_'+id;
 return body.slice(0,match.index)+`  const ${result}=${match[2]};
  if(${result} instanceof Promise)return ${result}.then(${after});
  return ${after}(${result});
  function ${after}(settled){
   const drain=__exactOutput.sink.ready?.();
   return drain?drain.then(()=>${resume}(settled)):${resume}(settled);
  }
  function ${resume}(settled){
   ${match[1]?'__exactCharacters=settled;':''}
${lower(body.slice(match.index+match[0].length))}
  }`;
}
code=code.replace(/ssr: \(__exactSsr, __exactContext, __exactInvocation\) => \{([\s\S]*?)\n\}, ssrHost:/g,(_,body)=>{
 programs++;
 body=body.replace('const __exactOutput = __exactSsr.output();','');
 const declarations=[],refs=[];
 body=body.replace(/__exactSsr.directComponent\(__exactContext, __exactOutput, (\w+), (__exactValue_\d+),/g,(_,component,props)=>{
  const ref='__sibling_'+refs.length;refs.push(ref);declarations.push(`const ${ref}=__prepareSibling(${component},${props});`);
  return `__exactSsr.component(__exactContext, __exactOutput, ${ref},`;
 });
 if(refs.length){const index=body.indexOf('__exactSsr.begin(');body=body.slice(0,index)+declarations.join('\n')+`\nif(__exactOutput.prepareReferences)__exactOutput.preparation=__exactOutput.prepareReferences([${refs.join(',')}]);\n`+body.slice(index);}
 return 'ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {'+lower(body)+'\n}, ssrHost:';
});
if(programs<4||stages<8)throw Error('Insufficient generated stages '+JSON.stringify({programs,stages}));
code='import {createPreparedServerComponentReference as __prepareSibling} from "@exactjs/core/framework/server-render-structure";\n'+code;
if(!code.includes('issueServerComponentReceipt as __exactIssueServerComponent, '))throw Error('Missing issuer link');
code=code.replace('issueServerComponentReceipt as __exactIssueServerComponent, ','');
code='import {issueServerComponentReceipt as __exactIssueServerComponent} from "./publication-large-stages-entry.mjs";\n'+code;
let runtime=readFileSync(dir+'publication-stages-entry.mjs','utf8');
const leafEntry=' return executeDirectWriter(invocation,output);';
if(runtime.split(leafEntry).length!==2)throw Error('Missing leaf entry');
runtime=runtime.replace(leafEntry,' return mapRenderValue(output.sink.ready?.(),()=>executeDirectWriter(invocation,output));');
writeFileSync(dir+'publication-large-stages-entry.mjs',runtime+'\nexport {createSsrResumptionCapture};\nexport function issueServerComponentReceipt(component){activeComponentIssuer?.(component);return component;}\n');
writeFileSync(dir+'publication-large-stages-fixture.mjs',code);
writeFileSync(dir+'publication-large-stages-build.json',JSON.stringify({programs,stages},null,2));
console.log({programs,stages});
