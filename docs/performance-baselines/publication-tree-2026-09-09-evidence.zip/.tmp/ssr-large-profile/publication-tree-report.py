import pathlib,json,hashlib,zipfile
d=pathlib.Path('.tmp/ssr-large-profile')
tables=[]
for size,prefix in [(2,'publication-tree'),(96,'publication-large-tree')]:
 rows=json.loads((d/f'{prefix}-results.json').read_text())
 assert len(rows)==32
 assert len({r['hash'] for r in rows})==1
 for runtime in ['node','bun']:
  for mode in ['string','stream']:
   for threshold in [2048,8192]:
    cell=[r for r in rows if r['runtimeName']==runtime and r['mode']==mode and r['threshold']==threshold]
    control=[r['us'] for r in cell if r['variant']=='control']
    candidate=[r['us'] for r in cell if r['variant']=='candidate']
    changes=[]
    for pair in [0,1]:
     a=next(r['us'] for r in cell if r['pair']==pair and r['variant']=='control')
     b=next(r['us'] for r in cell if r['pair']==pair and r['variant']=='candidate')
     changes.append((b/a-1)*100)
    tables.append(f'| {size} | {runtime} | {mode} | {threshold} | {min(control):.2f}-{max(control):.2f} | {min(candidate):.2f}-{max(candidate):.2f} | {changes[0]:+.2f}%, {changes[1]:+.2f}% |')
report=pathlib.Path('docs/performance-baselines/publication-tree-2026-09-09.md')
report.write_text('''# Incremental publication through compiled document trees

Date: 2026-09-09. Experimental renderer integration, production unchanged.

This tests whether the previous sink-only improvement survives actual compiler-generated component
execution, task settlement, resumption capture, hydration serialization, and complete document
collection. The hypothesis is that its benefit grows with component output volume, while task
and hydration costs can dominate small documents.

The small fixture has two scheduled children. The large fixture is independently compiled from
TSX containing 96 scheduled children. Five render programs become 108 staged operations in the
large fixture. Both use the same shared experimental engine and existing hydration serializer;
only the byte sink differs. Task gates are settled before traversal, while the compiled task
callbacks still run and publish their state. This measures throughput, not delayed-task latency.

Each document includes its own doctype, html, head, stylesheet link, body, child contents,
hydration envelope, and closing tags. Markers are disabled. All paired complete-document hashes
match, output byte counts agree, and all children dispose once. This is not browser hydration
validation or the framework-comparison application.

The string column collects the byte sink into Buffer.concat and decodes at completion. It is a
collection control for this experiment, not the production string sink or a recommended string
implementation. The stream column enqueues into a Web ReadableStream consumed through
Response.text. It does not use HTTP sockets or a transport with enforced slow-consumer pressure.
Prior differential and cancellation tests cover the sink pressure wrapper separately.

Node 26.8.1 and Bun 1.4.2 run in production mode. Each cell has two reversed-order pairs in fresh
processes. Small: 2,000 warmups and 6,000 measured renders. Large: 1,000 warmups and 2,000 measured
renders. Every completed sample is retained. An initial small-fixture harness assertion incorrectly
required a bare html opening tag; it was corrected to accept compiler-owned attributes before
the paired run. No renderer change was needed.

Times are microseconds per complete fixture render. Positive time changes mean slower.

| Children | Runtime | Collection | Threshold bytes | Original us | Optimized us | Pair time changes |
| --- | --- | --- | ---: | ---: | ---: | ---: |
'''+'\n'.join(tables)+'''

The synthetic sink speedup must not be presented as a complete-renderer speedup. These measurements
include substantial scheduled-component and hydration work that the sink change cannot remove.
Retain the incremental sink as the candidate for integration, while resolving native compiler
staging, required markers, browser adoption, and public transport coverage before production
adoption. React was not measured here. The original performance objective remains incomplete.

The evidence archive includes raw timings, build scripts, transformed fixtures/runtime, both sink
implementations, collection workers, and a verified SHA-256 manifest. Built workspace packages
and the native compiler are required for reproduction.
''',encoding='utf8')
files=[]
for pattern in ['publication-tree-*','publication-large-*']:
 files.extend(d.glob(pattern))
files.extend(d/n for n in ['publication-stages-sink.mjs','publication-byte-sink.mjs','incremental-publication-pressure.mjs','incremental-publication-state-sink.mjs','hydration-tail-sink.mjs','hydration-tail-entry.mjs','hydration-tail-fixture.mjs','publication-stages-entry.mjs','direct-writer-real-siblings-compile.json','compiled-stages-build.mjs'])
files.append(report)
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
with zipfile.ZipFile(report.with_name(report.stem+'-evidence.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 for name in manifest:z.write(name,name)
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(report.with_name(report.stem+'-evidence.zip')) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('\n'.join(tables))
print('Verified archive:',len(manifest),'files')
