import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const d='.tmp/ssr-large-profile/';
const input=d+'proven-reference-integrated/server-entry.js';
let source=fs.readFileSync(input,'utf8');
const changes=[
 ['return program ? { program } : { children: normalizeRenderResult(value) };','return program ?? normalizeRenderResult(value);'],
 ['if (content.children) return renderChildren(content.children, parent);','if (Array.isArray(content)) return renderChildren(content, parent);'],
 ['return renderPreparedSsrProgram(context, content.program,','return renderPreparedSsrProgram(context, content,']
];
for(const [before,after] of changes){assert.equal(source.split(before).length,2);source=source.replace(before,after);}
fs.mkdirSync(d+'direct-content-unwrapped',{recursive:true});
fs.writeFileSync(d+'direct-content-unwrapped/server-entry.js',source);
fs.writeFileSync(d+'direct-content-unwrapped/provenance.json',JSON.stringify({input,sha256:createHash('sha256').update(fs.readFileSync(input)).digest('hex'),changes},null,2));
let runner=fs.readFileSync(d+'complete-proof-run.mjs','utf8').replaceAll('complete-proof/server-entry.js','direct-content-unwrapped/server-entry.js').replaceAll('complete-proof-results.json','direct-content-unwrapped-results.json');
fs.writeFileSync(d+'direct-content-unwrapped-run.mjs',runner);
