import fs from 'node:fs';
let runner=fs.readFileSync('.tmp/ssr-large-profile/direct-content-unwrapped-run.mjs','utf8');
runner=runner.replace("['string','encoded','stream']","['string','encoded']").replace("['assets','large']","['large']").replace("'10000'","'20000'").replaceAll('direct-content-unwrapped-results.json','direct-content-unwrapped-confirm-results.json');
fs.writeFileSync('.tmp/ssr-large-profile/direct-content-unwrapped-confirm.mjs',runner);
