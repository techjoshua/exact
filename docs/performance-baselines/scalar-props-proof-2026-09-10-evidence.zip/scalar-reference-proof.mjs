import fs from 'node:fs';
import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/';
let source=fs.readFileSync(d+'static-invocation-final/server-entry.js','utf8');
const needle='__exactSsr.reference(SeverityBadge, __exactValue_1)';
assert.equal(source.split(needle).length,3);
source=source.replaceAll(needle,'referenceKnownScalarProps(__exactSsr, SeverityBadge, __exactValue_1)');
source=source.replace('function executeDirectSsrComponent(context, contract, rawProps, parent, options, sink) {','function executeDirectSsrComponent(context, contract, rawProps, parent, options, sink, scalarPropsProof) {');
source=source.replace('mapRenderValue(prepareComponentProps(rawProps, server.deferredTaskProps, options.signal),','mapRenderValue(scalarPropsProof === rawProps ? rawProps : prepareComponentProps(rawProps, server.deferredTaskProps, options.signal),');
const begin=source.indexOf('function executeSynchronousArtifact('),end=source.indexOf('\nfunction requireSynchronousArtifactOutput',begin);
const body=source.slice(begin,end);
assert.ok(body.includes('\n\t});\n\treturn output instanceof Promise'));
source=source.slice(0,begin)+body.replace('\n\t});\n\treturn output instanceof Promise','\n\t}, reference.scalarPropsProof);\n\treturn output instanceof Promise')+source.slice(end);
source=`function referenceKnownScalarProps(operations, component, props) {
 const reference = operations.reference(component, props);
 const value = props.severity;
 if (value === null || (typeof value !== 'object' && typeof value !== 'function')) reference.scalarPropsProof = props;
 return reference;
}
`+source;
fs.mkdirSync(d+'scalar-reference-proof',{recursive:true});
fs.writeFileSync(d+'scalar-reference-proof/server-entry.js',source);
