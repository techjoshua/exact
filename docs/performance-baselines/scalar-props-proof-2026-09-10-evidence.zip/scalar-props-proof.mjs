import fs from 'node:fs';
import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/';
let source=fs.readFileSync(d+'static-invocation-final/server-entry.js','utf8');
const needle='__exactSsr.reference(SeverityBadge, __exactValue_1)';
assert.equal(source.split(needle).length,3);
source=source.replaceAll(needle,'__exactSsr.reference(SeverityBadge, markKnownScalarProps(__exactValue_1))');
source=source.replace('function prepareComponentProps(props, deferredTaskProps, signal) {','function prepareComponentProps(props, deferredTaskProps, signal) {\n if (scalarPropsProof.has(props)) return props;');
source=`const scalarPropsProof = new WeakSet();
function markKnownScalarProps(props) {
 const value = props.severity;
 if (value === null || (typeof value !== 'object' && typeof value !== 'function')) scalarPropsProof.add(props);
 return props;
}
`+source;
fs.mkdirSync(d+'scalar-props-proof',{recursive:true});
fs.writeFileSync(d+'scalar-props-proof/server-entry.js',source);
