import fs from 'node:fs';
const root='.tmp/ssr-large-profile/';
let worker=fs.readFileSync(root+'projector-warm50-worker.mjs','utf8');
worker="import {PerformanceObserver} from 'node:perf_hooks';\n"+worker;
worker=worker.replace('const started=performance.now();',`const collections=[];
const observer=new PerformanceObserver(list=>collections.push(...list.getEntries()));
observer.observe({entryTypes:['gc']});
const started=performance.now();`);
worker=worker.replace('const elapsed=performance.now()-started;',`const ended=performance.now();
const elapsed=ended-started;
await new Promise(resolve=>setImmediate(resolve));
await new Promise(resolve=>setImmediate(resolve));
collections.push(...observer.takeRecords());observer.disconnect();
const gcEntries=collections.filter(entry=>entry.startTime>=started&&entry.startTime<ended);
const gc={count:gcEntries.length,durationMs:gcEntries.reduce((sum,entry)=>sum+entry.duration,0),byKind:{}};
for(const entry of gcEntries){const kind=entry.detail.kind;const group=gc.byKind[kind]??={count:0,durationMs:0};group.count++;group.durationMs+=entry.duration;}`);
worker=worker.replace('{reactResolution,entry,mode,scenario,iterations:count','{gc,reactResolution,entry,mode,scenario,iterations:count');
fs.writeFileSync(root+'direct-child-boundary-gc-worker.mjs',worker);
let runner=fs.readFileSync(root+'direct-child-boundary-run.mjs','utf8')
 .replace("candidate:d+'direct-child-boundary/server-entry.js'","candidate:d+'direct-child-boundary/server-entry.js',react:'framework-comparison/participants/react/dist-server/server-entry.js'")
 .replace("['node','bun']","['node']").replace('projector-warm50-worker.mjs','direct-child-boundary-gc-worker.mjs')
 .replace('direct-child-boundary-results.json','direct-child-boundary-gc-results.json');
fs.writeFileSync(root+'direct-child-boundary-gc-run.mjs',runner);
