import fs from 'node:fs';
const root='.tmp/ssr-large-profile/',rows=[];
for(const scenario of ['assets','large'])for(const variant of ['current','react']){
 const raw=fs.readFileSync(root+`survival-trace-${variant}-${scenario}.log`,'utf8');
 const measured=raw.split('MEASUREMENT_START\n')[1].split('MEASUREMENT_END\n')[0];
 const events=[...measured.matchAll(/GC: (\{[^\r\n]*\})/g)].map(match=>JSON.parse(match[1]));
 const row={variant,scenario,completeInteriorEvents:events.length,byKind:{}};
 for(const event of events){const group=row.byKind[event.gc]??={count:0,pauseMs:0,promoted:0,newSpaceSurvived:0,capacity:0};group.count++;group.pauseMs+=event.pause??0;group.promoted+=event.promoted??0;group.newSpaceSurvived+=event.new_space_survived??0;group.capacity+=event.new_space_capacity??0;}
 rows.push(row);console.log(JSON.stringify(row));
}
fs.writeFileSync(root+'survival-trace-results.json',JSON.stringify(rows,null,2));
