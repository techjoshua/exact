import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
const worker=root+'direct-child-boundary-allocation-worker.mjs';
fs.writeFileSync(worker,fs.readFileSync(root+'allocation-sample-worker.mjs','utf8').replace('i<5000','i<50000').replace("clientTags:''", "clientTags:'<script type=\"module\" src=\"/assets/app.js\"></script><script type=\"module\" src=\"/assets/vendor.js\"></script><link rel=\"stylesheet\" href=\"/assets/app.css\"><link rel=\"stylesheet\" href=\"/assets/theme.css\">'"));
const rows=[];
for(const scenario of ['small','large'])for(const variant of ['current','candidate']) {
 const entry=root+(variant==='current'?'proven-reference-integrated':'direct-child-boundary')+'/server-entry.js';
 const profile=root+`direct-child-boundary-${variant}-${scenario}.heapprofile`;
 const run=spawnSync('node',[worker,entry,scenario,profile],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 assert.equal(run.status,0,run.stderr+run.stdout);
 const row={variant,...JSON.parse(run.stdout)};
 const peer=rows.find(r=>r.scenario===scenario);if(peer)assert.equal(row.hash,peer.hash);
 let bytes=0;const sites=new Map();
 function visit(node){bytes+=node.selfSize;const key=node.callFrame.functionName;sites.set(key,(sites.get(key)??0)+node.selfSize);for(const child of node.children??[])visit(child);}
 visit(JSON.parse(fs.readFileSync(profile)).head);
 row.estimatedBytesPerRender=bytes/row.iterations;
 row.sites=[...sites.entries()].sort((a,b)=>b[1]-a[1]).map(([name,bytes])=>({name,bytesPerRender:bytes/row.iterations}));
 rows.push(row);fs.writeFileSync(root+'direct-child-boundary-allocations.json',JSON.stringify(rows,null,2));
 console.log(variant,scenario,row.estimatedBytesPerRender.toFixed(1));
}

