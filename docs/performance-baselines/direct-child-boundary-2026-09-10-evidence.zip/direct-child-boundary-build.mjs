import fs from 'node:fs';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
let code=fs.readFileSync(root+'proven-reference-integrated/server-entry.js','utf8');
assert.equal(code,fs.readFileSync('framework-comparison/participants/exact/dist-server/server-entry.js','utf8'));
function replace(before,after,count=1){assert.equal(code.split(before).length,count+1,before);code=code.replaceAll(before,after);}
replace('function writeProgramBoundary(context, sink, opening, closing, render) {','function writeProgramBoundary(context, sink, opening, closing, render, value) {');
replace('renderBoundary(context, sink, closing, render)','renderBoundary(context, sink, closing, render, value)',3);
replace('function renderBoundary(context, sink, closing, render, value) {\n\tconst rendered = render();','function renderBoundary(context, sink, closing, render, value) {\n\tconst rendered = render(value);');
replace('writeProgramBoundary(context, output.sink, opening, closing, () => output.render(value))','writeProgramBoundary(context, output.sink, opening, closing, output.render, value)');
fs.mkdirSync(root+'direct-child-boundary',{recursive:true});
fs.writeFileSync(root+'direct-child-boundary/server-entry.js',code);
fs.writeFileSync(root+'direct-child-boundary-run.mjs',fs.readFileSync(root+'shared-child-callback-run.mjs','utf8').replaceAll('shared-child-callback','direct-child-boundary'));
fs.writeFileSync(root+'direct-child-boundary-allocations.mjs',fs.readFileSync(root+'shared-child-callback-allocations.mjs','utf8').replaceAll('shared-child-callback','direct-child-boundary'));
