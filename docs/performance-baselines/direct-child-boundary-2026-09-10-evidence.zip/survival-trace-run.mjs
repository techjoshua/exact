import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
let worker=fs.readFileSync(root+'projector-warm50-worker.mjs','utf8');
worker="import {writeSync} from 'node:fs';\n"+worker;
worker=worker.replace('const started=performance.now();',"writeSync(1,'MEASUREMENT_START\\n');\nconst started=performance.now();")
 .replace('const elapsed=performance.now()-started;',"const elapsed=performance.now()-started;\nwriteSync(1,'MEASUREMENT_END\\n');");
fs.writeFileSync(root+'survival-trace-worker.mjs',worker);
const rows=[];
for(const scenario of ['assets','large'])for(const variant of ['current','react']){
 const entry=variant==='current'?root+'proven-reference-integrated/server-entry.js':'framework-comparison/participants/react/dist-server/server-entry.js';
 const run=spawnSync('node',['--trace-gc-nvp',root+'survival-trace-worker.mjs',entry,'string',scenario,'20000'],{encoding:'utf8',windowsHide:true,maxBuffer:32*1024*1024,env:{...process.env,NODE_ENV:'production'}});
 assert.equal(run.status,0,run.stderr);fs.writeFileSync(root+`survival-trace-${variant}-${scenario}.log`,run.stdout);
 const measured=run.stdout.split('MEASUREMENT_START\n')[1]?.split('MEASUREMENT_END\n')[0];assert.ok(measured);
 const events=[...measured.matchAll(/GC: (\{[^\r\n]*\})/g)].map(match=>JSON.parse(match[1]));
 const summary={variant,scenario,events:events.length,byKind:{}};
 for(const event of events){const group=summary.byKind[event.gc]??={count:0,pauseMs:0,allocated:0,promoted:0,newSpaceSurvived:0};group.count++;group.pauseMs+=event.pause??0;group.allocated+=event.allocated??0;group.promoted+=event.promoted??0;group.newSpaceSurvived+=event.new_space_survived??0;}
 rows.push(summary);fs.writeFileSync(root+'survival-trace-results.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(summary));
}
