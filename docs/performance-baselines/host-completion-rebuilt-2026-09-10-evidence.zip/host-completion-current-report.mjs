import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
const rows=JSON.parse(fs.readFileSync(d+'host-completion-current-results.json','utf8'));
let table='| Runtime | Mode | Size | Current | Rebuilt candidate | React |\n| --- | --- | --- | ---: | ---: | ---: |\n';
for(const runtime of ['node','bun'])for(const mode of ['string','encoded','stream'])for(const scenario of ['assets','large']){
 const mean=variant=>{const selected=rows.filter(r=>r.runtimeId===runtime&&r.mode===mode&&r.scenario===scenario&&r.variant===variant);return (selected.reduce((n,r)=>n+r.usPerRender,0)/selected.length).toFixed(2)};
 table+=`| ${runtime} | ${mode} | ${scenario==='assets'?'small':'large'} | ${mean('current')} | ${mean('candidate')} | ${mean('react')} |\n`;
}
fs.appendFileSync('docs/performance-baselines/host-completion-2026-09-10.md',`
## Rebuilt comparison

The corrected source build completed the same 72-population matrix, preserving complete
document hashes. These measurements are separate from the prototype window:

${table}

The rebuilt results remain mixed. Small Bun string and encoded means improve, but Node small
string and Bun small stream regress. Large results fluctuate across populations. The source
change remains provisional; no canonical application or public performance chart incorporates
it. SSR package output currently contains the candidate for isolated validation. A final
accept/reject decision and, if accepted, production browser checks remain outstanding.

The adjacent host-completion-rebuilt-2026-09-10-evidence.zip preserves this runner, capture,
artifact, and successful TypeScript build/typecheck logs. All timed processes completed.
`);
console.log(table);
