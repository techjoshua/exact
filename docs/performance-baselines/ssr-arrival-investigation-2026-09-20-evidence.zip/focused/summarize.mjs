import {readFile,writeFile,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const root=import.meta.dirname,json=async name=>JSON.parse(await readFile(root+'/'+name));
const captures=[];
for(const name of await readdir(root)){
 if(!name.endsWith('.json')||name==='summary.json')continue;
 const c=await json(name);if(!c.blocks||!c.complete)continue;
 const rows=c.blocks.flatMap(b=>b.results[0].stages.filter(s=>!s.discard).map(s=>{
 const stages=b.results.map(r=>r.stages.find(x=>x.name===s.name));
 const start=Math.min(...stages.map(s=>Date.parse(s.startedAt))),end=Math.max(...stages.map(s=>Date.parse(s.startedAt)+s.elapsedMs));
 return {stage:s.name,rps:stages.reduce((n,s)=>n+s.valid,0)*1000/(end-start),p99Min:Math.min(...stages.map(s=>s.distributions.responseMs.p99)),p99Max:Math.max(...stages.map(s=>s.distributions.responseMs.p99)),errors:stages.reduce((n,s)=>n+s.errors,0),invalid:stages.reduce((n,s)=>n+s.invalid,0),misses:stages.reduce((n,s)=>n+s.missedCapacity+s.missedLag+s.missedDeadline,0)};
 }));
 captures.push({name,sha256:createHash('sha256').update(await readFile(root+'/'+name)).digest('hex'),plan:c.plan,environment:c.environment,artifacts:c.artifacts,rows});
}
const adapters={};
for(const variant of ['control','tolerant','headroom','stable','demand']){adapters[variant]={};for(const entry of await readdir(root+'/'+variant,{recursive:true,withFileTypes:true}))if(entry.isFile()){const path=entry.parentPath+'/'+entry.name;adapters[variant][path.slice(root.length+1)]=createHash('sha256').update(await readFile(path)).digest('hex');}}
await writeFile(root+'/summary.json',JSON.stringify({scope:'Focused Node adaptive admission experiments; diagnostic populations are not full publication captures',captures,adapterCopies:adapters},null,2)+'\n');
for(const c of captures.filter(c=>/elu-independent|headroom-repeat|matrix-(string|stream)/.test(c.name)))console.log(c.name,JSON.stringify(c.rows));
