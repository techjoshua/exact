import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'ready-elision',{recursive:true});const counts=[];
for(const file of ['server-entry.js','bun-server-entry.js']){
 const source=await fs.readFile(root+'conditional-emission/'+file,'utf8');
 const ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);const edits=[];
 function visit(node){if(ts.isCallExpression(node)&&ts.isPropertyAccessExpression(node.expression)&&node.expression.name.text==='ready')edits.push({start:node.getStart(ast),end:node.end});ts.forEachChild(node,visit);}
 visit(ast);if(!edits.length)throw Error('No ready calls');let output=source;
 for(const edit of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,edit.start)+'(void 0)'+output.slice(edit.end);
 await fs.writeFile(root+'ready-elision/'+file,output);counts.push({file,sites:edits.length});
}
await fs.writeFile(root+'ready-elision/sites.json',JSON.stringify(counts,null,2));console.log(counts);
for(const suffix of ['check.mjs','run.mjs']){
 const source=await fs.readFile(root+'writer-output-pool-'+suffix,'utf8');
 await fs.writeFile(root+'ready-elision-'+suffix,source.replaceAll('writer-output-pool','ready-elision'));
}
