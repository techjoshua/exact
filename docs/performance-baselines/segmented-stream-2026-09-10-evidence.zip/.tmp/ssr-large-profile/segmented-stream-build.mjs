import fs from 'node:fs';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
const input='.tmp/ssr-large-profile/scalar-proof-shared/server-entry.js';
for(const size of [2048,8192]){
 let s=fs.readFileSync(input,'utf8');
 const replace=(a,b)=>{assert.equal(s.split(a).length-1,1,a);s=s.replace(a,b);};
 replace('const sink = new StringProgramSink(context.maxOutputBytes);',`const sink = outputKind === 'stream' ? new PrototypeChunkSink(context.maxOutputBytes) : new StringProgramSink(context.maxOutputBytes);`);
 replace('const chunks = [sink.finish(context.reactResourceHints)];',`const completed=sink.finish(context.reactResourceHints); const chunks=typeof completed==='string'?[completed]:completed;`);
 replace('renderTreeOutput(operation, shellOptions, false)',`renderTreeOutput(operation, shellOptions, false, settleDocumentShell?'stream':'html')`);
 replace('renderTreeOutput(operation, capture.options, false)',`renderTreeOutput(operation, capture.options, false, settleDocumentShell?'stream':'html')`);
 replace('isExactDocumentHtml(shell.html)',`startsExactDocument(htmlChunksOf(shell)??[shell.html])`);
 for(const name of ['shell','final'])replace(`await emit({\n\t\t\tevent: "shell",\n\t\t\tversion: 1,\n\t\t\thtml: ${name}.html\n\t\t});`,`await emit(prototypeShellEvent(${name}));`);
 replace('function progressiveHtmlChunk(event, options, document) {',`function progressiveHtmlChunk(event, options, document) {
 if(event.event==='shell' && event[prototypeChunks] && startsExactDocument(event[prototypeChunks])) {
  const chunks=event[prototypeChunks], at=findLastBodyClose(chunks);
  if(!at) throw Error('Normalized eXact document output is missing its closing </body> element.');
  document.tail=chunks[at.chunkIndex].slice(at.offset)+chunks.slice(at.chunkIndex+1).join('');
  const body=chunks.slice(0,at.chunkIndex);
  if(at.offset)body.push(chunks[at.chunkIndex].slice(0,at.offset));
  return body;
 }`);
 replace('if (chunk) await emit(chunk);',`if(Array.isArray(chunk)) { for(const part of chunk) if(part) await emit(part); } else if (chunk) await emit(chunk);`);
 s+=`
var prototypeChunks=Symbol('prototype-shell-chunks');
function prototypeShellEvent(result) {
 return {event:'shell',version:1,get html(){return result.html},[prototypeChunks]:htmlChunksOf(result)};
}
class PrototypeChunkSink {
 value=''; chunks=[]; characters=0; closed=false;
 constructor(maxBytes){this.maxBytes=maxBytes}
 write(html){
  if(this.closed)throw Error('SSR string sink is closed');
  this.characters+=html.length;
  if(this.characters>this.maxBytes){this.destroy();throw new SsrOutputLimitError(this.maxBytes)}
  this.value+=html;
  if(this.value.length>=${size}) {
   const last=this.value.charCodeAt(this.value.length-1);
   if(last>=0xD800&&last<=0xDBFF){this.chunks.push(this.value.slice(0,-1));this.value=this.value.slice(-1)}
   else {this.chunks.push(this.value);this.value=''}
  }
 }
 ready(){} flush(){}
 finish(prefix=[]){
  if(this.closed)throw Error('SSR string sink is closed');
  let n=this.characters;for(const part of prefix)n+=part.length;
  const result=prefix.length?[...prefix,...this.chunks]:this.chunks;
  if(this.value)result.push(this.value);
  this.destroy();
  if(n>this.maxBytes || (n>this.maxBytes/3 && utf8ByteLength(result.join(''))>this.maxBytes))throw new SsrOutputLimitError(this.maxBytes);
  return result;
 }
 destroy(){this.value='';this.chunks=[];this.closed=true}
}
`;
 const out='.tmp/ssr-large-profile/segmented-stream-'+size;fs.mkdirSync(out,{recursive:true});fs.writeFileSync(out+'/server-entry.js',s);
 fs.writeFileSync(out+'/provenance.json',JSON.stringify({input,size,inputSha256:createHash('sha256').update(fs.readFileSync(input)).digest('hex'),outputSha256:createHash('sha256').update(s).digest('hex'),hypothesis:'Preserve bounded rope chunks through the existing progressive shell handoff, avoiding a complete shell flatten. Expect 3-8% large Bun stream benefit, possibly extra small-case overhead. String sink remains unchanged. This is an isolated prototype, not public early tree publication.'},null,2));
}
