import fs from 'node:fs';import {spawnSync} from 'node:child_process';import assert from 'node:assert/strict';import vm from 'node:vm';
const root='.tmp/ssr-large-profile/';const entries={current:root+'scalar-proof-shared/server-entry.js',s2048:root+'segmented-stream-2048/server-entry.js',s8192:root+'segmented-stream-8192/server-entry.js'};
let checked=0;for(const size of [2048,8192]){
 const source=fs.readFileSync(entries['s'+size],'utf8');const cls=source.slice(source.indexOf('class PrototypeChunkSink {'));
 const Sink=vm.runInNewContext(cls+';PrototypeChunkSink',{SsrOutputLimitError:RangeError,utf8ByteLength:Buffer.byteLength});
 for(const parts of [['a'.repeat(size-1),'\ud83d','\ude80','tail'],['a'.repeat(size),'\ud83d','x'],['\ud83d','\ude80'],['\u65e5'.repeat(size),'end'],['']]){
  const expected=parts.join(''),bytes=Buffer.byteLength(expected);
  for(const cap of [Math.max(0,bytes-1),bytes,bytes+1]){
   const sink=new Sink(cap);let result;
   if(cap<bytes)assert.throws(()=>{for(const p of parts)sink.write(p);sink.finish()});
   else {for(const p of parts)sink.write(p);result=sink.finish();assert.equal(result.join(''),expected);assert.deepEqual(Buffer.concat(result.map(p=>Buffer.from(p))),Buffer.from(expected));assert.throws(()=>sink.write('late'));}
   checked++;
  }
 }
}
const rows=[];for(const runtime of ['node','bun'])for(const scenario of ['assets','large','unicode']){
 let hash;for(const [variant,entry]of Object.entries(entries)){
  const r=spawnSync(runtime,[root+'final-rope-worker.mjs',entry,'stream',scenario,'1'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});if(r.status!==0)throw Error(r.stderr+r.stdout);const row={runtime,variant,...JSON.parse(r.stdout)};if(hash)assert.equal(row.hash,hash);else hash=row.hash;rows.push(row);
 }
}
fs.writeFileSync(root+'segmented-stream-check.json',JSON.stringify({sinkChecks:checked,rows},null,2));console.log(checked,'sink checks and',rows.length,'complete-document checks passed');
