import json,hashlib,zipfile
from pathlib import Path
from statistics import mean
base=Path('.tmp/ssr-large-profile');root=base/'scheduler-large';rows=[];valid=0
for runtime in ('node','bun'):
 d=json.loads((root/runtime/'capture.json').read_text());assert d['complete'] and len(d['blocks'])==16
 for mode in ('string','stream'):
  for pop in (0,1):
   blocks=[b for b in d['blocks'] if b['mode']==mode and b['population']==pop]
   e=[b for b in blocks if b['id']=='exact'];r=next(b for b in blocks if b['id']=='react')
   assert [b['phase'] for b in e]==['normal','scheduled','normal']
   normal=mean(b['rps'] for b in (e[0],e[2]));candidate=e[1]
   rows.append(dict(runtime=runtime,mode=mode,population=pop+1,immediateRps=normal,scheduledRps=candidate['rps'],reactRps=r['rps'],gainPct=(candidate['rps']/normal-1)*100,vsReactPct=(candidate['rps']/r['rps']-1)*100,exactBytes=candidate['identity']['bytes'],reactBytes=r['identity']['bytes']))
 for b in d['blocks']:
  assert b['after']['scheduleCalls']==(b['valid']+len(b['results']) if b['phase']=='scheduled' else 0)
  assert all(s['errors']==0 for result in b['results'] for s in result['stages'])
 valid+=sum(b['valid'] for b in d['blocks'])
(root/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid),indent=2))
report=Path('docs/performance-baselines/scheduler-large96-2026-09-11.md')
lines=['# Scheduling with 96 incidents, Node and Bun','',
'Hypothesis: render-start scheduling continues to help with larger documents, but its relative gain shrinks as per-request rendering and output take more time. The source scheduler prefers node:timers/promises scheduler.yield and retains per-request cancellation. All participants render their complete authored documents. React is unchanged.', '',
'The controlled service fixture is expanded from three incidents to 96 at initial data load, cycling the original three records with distinct IDs inc-100 through inc-195. Both frameworks receive the same data. Preloaded input data is reused as in the earlier diagnostic; HTML and hydration are rendered for each request. Each mode runs fresh eXact/React/React/eXact workers, ten-second warmup and five-second blocks at concurrency 32. eXact runs immediate/scheduled/immediate with averaged controls. Node uses node-http; Bun uses native bun-fetch. Workstation load may vary.', '',
'| Runtime | Mode | Repeat | Immediate RPS | Scheduled RPS | React RPS | vs immediate | vs React |',
'| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['runtime']} | {r['mode']} | {r['population']} | {r['immediateRps']:,.0f} | {r['scheduledRps']:,.0f} | {r['reactRps']:,.0f} | {r['gainPct']:+.2f}% | {r['vsReactPct']:+.2f}% |")
lines+=['',f'{valid:,} complete measured responses validated with zero errors. Scheduler call counts include the expected driver identity preflights. Participant and dependency artifact guards pass. Document sizes and full raw distributions are preserved in the summary and capture files.', '',
'Scheduling remains opt-in. These loaded measurements do not establish sparse-traffic latency or browser paint effects. The optimization objective remains open pending the remaining checks and any gaps shown here.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=[p for p in root.rglob('*') if p.is_file()]+[report,base/'scheduler-large-build.py',base/'scheduler-large-report.py',base/'scheduler-large-node-run.mjs',base/'scheduler-large-bun-run.mjs']+[Path(p) for p in ('framework-adapters/node-adapter/src/render-scheduler.ts','framework-adapters/node-adapter/dist/render-scheduler.js')]
archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print(json.dumps(rows,indent=2));print(valid,'validated responses')
