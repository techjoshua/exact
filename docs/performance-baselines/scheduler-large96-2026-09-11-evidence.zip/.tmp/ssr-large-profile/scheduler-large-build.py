import json
from pathlib import Path
base=Path('.tmp/ssr-large-profile'); root=base/'scheduler-large';root.mkdir(exist_ok=True)
fixture=json.loads(Path('.tmp/positional-leaves/data.json').read_text())
fixture['incidents']=[dict(fixture['incidents'][i%3],id=f'inc-{100+i}') for i in range(96)]
(root/'fixture.json').write_text(json.dumps(fixture))
w=(base/'source-scheduler-bun/worker.mjs').read_text()
needle='return { ...session, ...incidents };';assert w.count(needle)==1
w=w.replace(needle,"const data={ ...session, ...incidents }; data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)})); return data;")
(root/'worker.mjs').write_text(w)
for runtime in ('node','bun'):
 folder=root/runtime;folder.mkdir(exist_ok=True)
 (folder/'worker.mjs').write_text(w.replace("'../../../framework-adapters/","'../../../../framework-adapters/"))
 r=(base/'source-scheduler-bun-run.mjs').read_text().replace('source-scheduler-bun/',f'scheduler-large/{runtime}/').replace('actual-source-scheduler-native-bun',f'large96-scheduler-{runtime}')
 if runtime=='node':r=r.replace("availableSsrRuntimes('bun')","availableSsrRuntimes('node')").replace("transport:'bun-fetch'","transport:'node-http'").replace('dist-bun-server/bun-server-entry.js','dist-server/server-entry.js')
 (base/f'scheduler-large-{runtime}-run.mjs').write_text(r)
