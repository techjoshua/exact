import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
const worker=root+'ready-props-gc-cpu-worker.mjs';
let source=fs.readFileSync(root+'direct-child-boundary-gc-worker.mjs','utf8');
source="import os from 'node:os';\nos.setPriority(0,os.constants.priority.PRIORITY_BELOW_NORMAL);\n"+source;
source=source.replace('runtime:process.versions.bun??process.version','runtime:process.versions.bun??process.version,processPriority:os.getPriority()');
source=source.replace('const started=performance.now();','const cpuStart=process.cpuUsage();\nconst started=performance.now();');
source=source.replace('const ended=performance.now();','const ended=performance.now();\nconst cpu=process.cpuUsage(cpuStart);');
source=source.replace('processPriority:os.getPriority()','processPriority:os.getPriority(),cpuMicrosPerRender:(cpu.user+cpu.system)/count');
fs.writeFileSync(worker,source);
const rows=[];
for(const scenario of ['large'])for(const mode of ['string','encoded'])for(let round=0;round<2;round++)for(const variant of round?['candidate','integrated']:['integrated','candidate']){
 const entry=root+(variant==='candidate'?'ready-props-stable':'direct-execution-integrated')+'/server-entry.js';
 const artifactSha256=createHash('sha256').update(fs.readFileSync(entry)).digest('hex');
 assert.equal(artifactSha256,variant==='candidate'?'99f76e4e06e41960c5a6da7a1a6669e197051160e5987f5ba6eefb17cbd9d3ba':'2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18');
 const run=spawnSync(process.execPath,[worker,entry,mode,scenario,'20000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 assert.equal(run.status,0,run.stderr+run.stdout);
 const row={variant,round,artifactSha256,...JSON.parse(run.stdout)};
 assert.ok(row.processPriority>0);
 const peer=rows.find(r=>r.scenario===scenario);if(peer)assert.equal(row.hash,peer.hash);
 rows.push(row);fs.writeFileSync(root+'ready-props-gc-cpu.json',JSON.stringify(rows,null,2));
 console.log(variant,mode,scenario,round,'CPU',row.cpuMicrosPerRender.toFixed(2),'GC count',row.gc.count,'durationMs',row.gc.durationMs.toFixed(2));
}
assert.equal(rows.length,8);
