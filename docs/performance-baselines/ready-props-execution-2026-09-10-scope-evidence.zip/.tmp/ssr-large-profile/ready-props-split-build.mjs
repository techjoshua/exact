import fs from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
let code=fs.readFileSync(root+'ready-props-stable/server-entry.js','utf8');
assert.equal(createHash('sha256').update(code).digest('hex'),'99f76e4e06e41960c5a6da7a1a6669e197051160e5987f5ba6eefb17cbd9d3ba');
const start=code.indexOf('function executePreparedDirectComponent(');
const split=code.indexOf('\n\tconst frame = stateless ?',start);
const end=code.indexOf('\nfunction performanceNow()',split);
assert.ok(start>0&&split>start&&end>split);
const tail=code.slice(split,end);assert.ok(tail.endsWith('\n}'));
code=code.slice(0,split)+`
 return executeStatefulPreparedComponent(context, contract, props, parent, options, sink, artifact, server, stateless);
}
function executeStatefulPreparedComponent(context, contract, props, parent, options, sink, artifact, server, stateless) {`+tail+code.slice(end);
fs.mkdirSync(root+'ready-props-split',{recursive:true});fs.writeFileSync(root+'ready-props-split/server-entry.js',code);
console.log(createHash('sha256').update(code).digest('hex'));
let pressure=fs.readFileSync(root+'ready-props-stable-pressure.mjs','utf8').replaceAll('ready-props-stable-pressure','ready-props-split-pressure').replace("root+'ready-props-stable/server-entry.js'","root+'ready-props-split/server-entry.js'");
fs.writeFileSync(root+'ready-props-split-pressure.mjs',pressure);
