import hashlib,json,pathlib,statistics,zipfile
root=pathlib.Path('.');work=root/'.tmp/ssr-large-profile'
rows=json.loads((work/'current-comparison-results.json').read_text(encoding='utf-8'));summary=[]
assert len(rows)==48
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['empty','assets','large']:
   vals={v:statistics.median(r['usPerRender'] for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['variant']==v) for v in ['exact','react']}
   summary.append(dict(runtime=runtime,mode=mode,scenario=scenario,exact=vals['exact'],react=vals['react'],timeDifferencePercent=(vals['exact']/vals['react']-1)*100))
table='\n'.join(f"| {s['runtime']} | {s['mode']} | {s['scenario']} | {s['exact']:.2f} | {s['react']:.2f} | {s['timeDifferencePercent']:+.1f}% |" for s in summary)
dest=root/'docs/performance-baselines/current-renderer-comparison-2026-09-09'
dest.with_suffix('.json').write_text(json.dumps(dict(summary=summary,populations=rows),indent=2)+'\n',encoding='utf-8')
doc='''# Current retained renderer comparison after shell and marker improvements

Date: 2026-09-09. Overall React parity remains unmet.

The current eXact build includes direct server map carriers, compiled empty external scripts with
preserved client item boundaries, and shared UTF-8/hex marker encoding, as well as earlier retained
optimizations. The frozen artifact marker-hex-current.mjs matches the built Node participant exactly:
SHA-256 b8a3bd6ec50d504280de2b86f9a8b20ca250f2b7a345d8a4980a492ff12efd5f.

## Method

Forty-eight fresh processes compare eXact and React on Node 26.8.1 and Bun 1.4.2, string and consumed
stream rendering, with two reversed-order pairs per cell. Scenario order also reverses. Every
population uses NODE_ENV=production, 5,000 warmups, and 12,000 measured renders. Both frameworks
construct complete application-owned documents from identical input/options.

- empty: three incidents, no client asset tags.
- assets: three incidents, two module scripts and two stylesheet links.
- large: 96 incidents, the same four asset tags.

The same Node-target participant artifact is used on both runtimes for each framework. Streams
are consumed with Response.text(). This measures renderer completion, not the actual HTTP adapters,
socket throughput, early-shell latency, asset downloads, or browser performance. The prior HTTP
comparison remains a separate historical capture; no RPS claims are derived from these timings.

All populations completed. The worker checks full-document framing and asset presence where
applicable. Repeated populations preserve each framework's full-body hash. Framework hashes are
not expected to match each other because their hydration/markup differ. No result was discarded.

## Median microseconds per render

Lower is better. Positive time difference means eXact took longer. These are descriptive medians
of two local populations, not confidence intervals. The Node empty-string and several Bun small
populations varied substantially; raw observations are included.

| Runtime | Output | Fixture | eXact | React | eXact time difference |
| --- | --- | --- | ---: | ---: | ---: |
'''+table+'''

Node streaming favors eXact in every pair. String rendering favors React on both runtimes and all
fixtures. Small Bun streaming is mixed by pair; large Bun streaming favors React in both pairs.
The retained improvements have not met the overall objective.

These data should guide further work toward Node string rendering and large-document publication.
They do not isolate the causal effect of the last three improvements, because the older eXact
build was not included in this capture. Do not compare absolute values across captures as if
workstation load were constant, or multiply earlier improvement percentages into this table.

No production code changed for this measurement. Prior implementation validation is documented
in direct-map-2026-09-09.md, compiled-script-2026-09-09.md, and marker-hex-2026-09-09.md, including
core/SSR/native tests and 56 browser checks. This run adds renderer output checks, not a new browser
suite or public full-benchmark baseline. Public charts remain unchanged. All benchmark subprocesses
exited; a final process inventory found only the unrelated Codex CLI Node process.

The evidence archive includes frozen artifacts, fixed data, runner/worker, raw populations,
reporter, dependency versions, and hashes. Reproduction requires the locked workspace dependencies.
'''
dest.with_suffix('.md').write_text(doc,encoding='utf-8')
files=[work/n for n in ['marker-hex-current.mjs','current-comparison-run.mjs','current-comparison-worker.mjs','current-comparison-results.json','current-comparison-report.py','long-worker.mjs']]+[root/'.tmp/positional-leaves/data.json',root/'framework-comparison/participants/react/dist-server/server-entry.js',root/'framework-comparison/node_modules/react/package.json',root/'framework-comparison/node_modules/react-dom/package.json',dest.with_suffix('.md'),dest.with_suffix('.json')]
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps({p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(table);print('Verified',archive)
