import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const dir='.tmp/ssr-large-profile/';
let worker=readFileSync(dir+'long-worker.mjs','utf8');
worker=worker.replace('const render=',`const clientTags=scenario==='empty'?'':'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">';\nconst render=`).replaceAll("clientTags:''",'clientTags');
worker=worker.replace('console.log(JSON.stringify(',`if(scenario!=='empty')for(const asset of ['/assets/app.js','/assets/vendor.js','/assets/app.css','/assets/theme.css'])if(!html.includes(asset))throw Error('Missing asset '+asset);\nconsole.log(JSON.stringify(`);
writeFileSync(dir+'current-comparison-worker.mjs',worker);
const rows=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(let round=0;round<2;round++)for(const scenario of round?['large','assets','empty']:['empty','assets','large'])for(const variant of round?['react','exact']:['exact','react']){
 const entry=variant==='exact'?dir+'marker-hex-current.mjs':'framework-comparison/participants/react/dist-server/server-entry.js';
 const result=spawnSync(runtime,[dir+'current-comparison-worker.mjs',entry,mode,scenario,'12000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(result.status!==0)throw Error(result.stderr||result.stdout);
 const row={variant,round,runtimeId:runtime,artifactSha256:createHash('sha256').update(readFileSync(entry)).digest('hex'),...JSON.parse(result.stdout)};
 const peer=rows.find(x=>x.variant===variant&&x.mode===mode&&x.scenario===scenario&&x.runtimeId===runtime);
 if(peer&&peer.hash!==row.hash)throw Error('Unstable output');
 rows.push(row);writeFileSync(dir+'current-comparison-results.json',JSON.stringify(rows,null,2));console.log(runtime,mode,scenario,round,variant,row.usPerRender.toFixed(2));
}
