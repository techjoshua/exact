import zipfile,hashlib,json
from pathlib import Path
base=Path('.tmp/ssr-large-profile'); root=base/'source-scheduler-preferred';root.mkdir(exist_ok=True)
with zipfile.ZipFile('docs/performance-baselines/source-render-scheduler-bun-2026-09-10-evidence.zip') as z:
 name='framework-adapters/node-adapter/dist/render-scheduler.js';data=z.read(name)
 assert hashlib.sha256(data).hexdigest()==json.loads(z.read('SHA256.json'))[name]
 (root/'old-scheduler.mjs').write_bytes(data)
w=(base/'source-scheduler-bun/worker.mjs').read_text()
w=w.replace('const sourceScheduler=createNodeRenderScheduler();',"import {createNodeRenderScheduler as createOldScheduler} from './old-scheduler.mjs';\nconst oldScheduler=createOldScheduler(),newScheduler=createNodeRenderScheduler();\nlet auditVariant='scheduled';\nfunction sourceScheduler(signal){return (auditVariant==='preferred'?newScheduler:oldScheduler)(signal);}")
t="auditScheduled=url.searchParams.get('defer')==='1';";assert t in w
w=w.replace(t,t+"auditVariant=url.searchParams.get('variant')??'scheduled';")
(root/'worker.mjs').write_text(w)
r=(base/'source-scheduler-bun-run.mjs').read_text().replace('source-scheduler-bun/','source-scheduler-preferred/').replace('actual-source-scheduler-native-bun','preferred-yield-production-bun')
r=r.replace("['normal','scheduled','normal']","['scheduled','preferred','scheduled']").replace("phase==='scheduled'","phase!=='normal'")
r=r.replace("'audit-mode?defer='+(phase!=='normal'?'1':'0')","'audit-mode?defer='+(phase!=='normal'?'1':'0')+'&variant='+phase")
(base/'source-scheduler-preferred-run.mjs').write_text(r)
