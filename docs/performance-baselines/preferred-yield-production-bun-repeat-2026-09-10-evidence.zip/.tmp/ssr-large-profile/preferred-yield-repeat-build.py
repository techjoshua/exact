from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'source-scheduler-preferred-repeat';root.mkdir(exist_ok=True)
for name in ('worker.mjs','old-scheduler.mjs'):
 (root/name).write_bytes((base/'source-scheduler-preferred'/name).read_bytes())
r=(base/'source-scheduler-preferred-run.mjs').read_text().replace('source-scheduler-preferred/','source-scheduler-preferred-repeat/').replace('preferred-yield-production-bun','preferred-yield-production-bun-repeat')
r=r.replace("['string','stream']","['stream']").replace('report.blocks.length,16','report.blocks.length,8')
(base/'source-scheduler-preferred-repeat-run.mjs').write_text(r)
p=(base/'preferred-yield-report.py').read_text().replace("base/'source-scheduler-preferred'","base/'source-scheduler-preferred-repeat'").replace("len(d['blocks'])==16","len(d['blocks'])==8").replace("('string','stream')","('stream',)").replace('preferred-yield-production-bun-2026-09-10','preferred-yield-production-bun-repeat-2026-09-10').replace('production implementation on Bun','production implementation on Bun, streaming repeat').replace("base/'preferred-yield-report.py'","base/'preferred-yield-repeat-report.py',base/'preferred-yield-repeat-build.py'").replace("base/'source-scheduler-preferred-run.mjs'","base/'source-scheduler-preferred-repeat-run.mjs'")
p=p.replace('Hypothesis: preferring','The preceding streaming repeat had old controls drifting from 6,590 to 8,086 RPS, so a focused repeat was required. Hypothesis: preferring')
(base/'preferred-yield-repeat-report.py').write_text(p)
