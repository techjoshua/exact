import { clearImmediate, setImmediate } from 'node:timers';
/**
 * Creates a host-owned scheduler for the SSR `scheduleRender` option. Share one
 * scheduler across requests to batch starts in Node's check phase. Cancellation
 * rejects promptly and removes the queued continuation. Batches release at most
 * maxBatchSize starts; render work and response ownership remain with SSR.
 */
export function createNodeRenderScheduler(options = {}) {
    const limit = options.maxBatchSize ?? 32;
    if (!Number.isSafeInteger(limit) || limit < 1)
        throw new RangeError('maxBatchSize must be a positive safe integer');
    let pending;
    return (signal) => new Promise((resolve, reject) => {
        if (signal?.aborted) {
            reject(signal.reason);
            return;
        }
        const batch = pending ?? { starts: [], active: 0, timer: undefined };
        if (!pending) {
            pending = batch;
            batch.timer = setImmediate(() => {
                if (pending === batch)
                    pending = undefined;
                batch.timer = undefined;
                for (const start of batch.starts)
                    start?.();
                batch.starts = [];
            });
        }
        const index = batch.starts.length;
        batch.active++;
        if (signal) {
            const abort = () => {
                batch.starts[index] = undefined;
                signal.removeEventListener('abort', abort);
                if (--batch.active === 0 && batch.timer !== undefined) {
                    clearImmediate(batch.timer);
                    batch.timer = undefined;
                    batch.starts = [];
                    if (pending === batch)
                        pending = undefined;
                }
                reject(signal.reason);
            };
            batch.starts.push(() => {
                signal.removeEventListener('abort', abort);
                resolve();
            });
            signal.addEventListener('abort', abort, { once: true });
        }
        else
            batch.starts.push(resolve);
        if (batch.starts.length === limit)
            pending = undefined;
    });
}
//# sourceMappingURL=render-scheduler.js.map