import fs from 'node:fs';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
const input='.tmp/ssr-large-profile/proven-reference-integrated/server-entry.js';let s=fs.readFileSync(input,'utf8');const a=s.indexOf('function createPreparedServerComponentReferenceFromPlainProps(');const b=s.indexOf('\n/** Reads only the direct reference',a);assert.ok(a>0&&b>a);
s=s.slice(0,a)+`function createPreparedServerComponentReferenceFromPlainProps(type,props) {
 const domain=currentComponentDomain(),contract=readPreparedExactExecutableComponentContract(type);
 return domain ? {contract,props,children:emptyServerComponentChildren,domain,[PreparedServerComponentReference]:true}
 : {contract,props,children:emptyServerComponentChildren,[PreparedServerComponentReference]:true};
}`+s.slice(b);
const dir='.tmp/ssr-large-profile/proven-reference-shaped';fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(dir+'/server-entry.js',s);fs.writeFileSync(dir+'/provenance.json',JSON.stringify({input,inputSha256:createHash('sha256').update(fs.readFileSync(input)).digest('hex'),outputSha256:createHash('sha256').update(s).digest('hex'),hypothesis:'Named fields before the computed brand avoid the domain PropertyArray observed in Node V8, retaining the same prototype and own key order. Expected 1-3% large-tree benefit with lower reference allocation.'},null,2));
