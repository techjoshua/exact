import {prototypeOperations as op,PrototypeChild as child} from './proven-reference/server-entry.js';import assert from 'node:assert/strict';
const invocation={},props={severity:'high'};const first=op.reference(child,props,'severity',invocation);assert.equal(first.props,props);assert.deepEqual(Reflect.ownKeys(props),['severity']);
props.key='later';const repeated=op.reference(child,props,'severity',invocation);assert.equal(repeated.key,'later');assert.equal(Object.hasOwn(repeated.props,'key'),false);assert.notEqual(repeated.props,props);
let reads=0;try{Object.defineProperty(Object.prototype,'key',{configurable:true,get(){reads++;return 'inherited'},set(v){Object.defineProperty(this,'key',{value:v,writable:true,configurable:true,enumerable:true})}});const ref=op.reference(child,{severity:'low'},'severity',{});assert.equal(ref.key,'inherited');assert.ok(reads>0);}finally{delete Object.prototype.key}
console.log('Fresh, reused, and inherited-metadata reference checks passed');
