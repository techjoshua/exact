import fs from 'node:fs';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';const input=root+'scalar-proof-shared/server-entry.js';let s=fs.readFileSync(input,'utf8');
const a=s.indexOf('reference(component, props, scalarPropKey, proofInvocation) {');const b=s.indexOf('\n\tprepareText:',a);assert.ok(a>0&&b>a);
const part=s.slice(a,b).replace('const reference = createPreparedServerComponentReference(component, props);',`const reference = privateProps && !proofInvocation[scalarPropsAttempted]
 ? prototypePlainReference(component,props)
 : createPreparedServerComponentReference(component, props);`);s=s.slice(0,a)+part+s.slice(b);
s+=`
function prototypePlainReference(component,props) {
 const domain=currentComponentDomain();
 const reference={ [PreparedServerComponentReference]:true, contract:readPreparedExactExecutableComponentContract(component), props, children:emptyServerComponentChildren };
 if(domain)reference.domain=domain;
 return reference;
}
export {generatedSsrOperations as prototypeOperations,SeverityBadge as PrototypeChild};
`;
const dir=root+'proven-reference';fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(dir+'/server-entry.js',s);fs.writeFileSync(dir+'/provenance.json',JSON.stringify({input,inputSha256:createHash('sha256').update(fs.readFileSync(input)).digest('hex'),outputSha256:createHash('sha256').update(s).digest('hex'),hypothesis:'Reuse the compiler fresh private prop bag proof to omit reserved metadata normalization on first issuance. Reused invocations and inherited metadata keep ordinary reference construction. Expected 1-3% large-tree improvement. No second rendering engine.'},null,2));
