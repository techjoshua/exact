from pathlib import Path
base=Path('.tmp/ssr-large-profile'); root=base/'serial-backlog-node';root.mkdir(exist_ok=True)
for name in ('worker.mjs','serial-scheduler.mjs'):
 (root/name).write_bytes((base/'serial-scheduler'/name).read_bytes())
r=(base/'serial-scheduler-run.mjs').read_text()
for old,new in [('serial-scheduler/','serial-backlog-node/'),("availableSsrRuntimes('bun')","availableSsrRuntimes('node')"),('large96-bun-serial-batch-turns','large96-node-backlog-serial-turns'),('dist-bun-server/bun-server-entry.js','dist-server/server-entry.js'),("transport:'bun-fetch'","transport:'node-http'"),('for(const concurrency of [32])','for(const concurrency of [256])'),('concurrency:concurrency===1?1:16','concurrency:concurrency/2'),("['normal','serial-32','serial-8','serial-4','scheduled-32','normal']","['normal','serial-32','serial-8','scheduled-32','normal']"),("['normal','scheduled-32','serial-4','serial-8','serial-32','normal']","['normal','scheduled-32','serial-8','serial-32','normal']"),('report.blocks.length,14','report.blocks.length,12')]:
 assert old in r,old
 r=r.replace(old,new)
(base/'serial-backlog-node-run.mjs').write_text(r)
