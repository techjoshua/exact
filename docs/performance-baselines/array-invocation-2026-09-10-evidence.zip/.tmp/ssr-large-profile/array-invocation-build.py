from pathlib import Path
import hashlib
root=Path('.tmp/ssr-large-profile')
raw=Path('framework-comparison/participants/exact/dist-server/server-entry.js').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18'
source=raw.decode()
old='\tconst invocation = {\n\t\t[PreparedServerRenderProgram]: true,\n\t\tprogram: branded,\n\t\teagerValues\n\t};'
source=source.replace('\r\n','\n')
assert source.count(old)==1
source=source.replace(old,'\tconst invocation = eagerValues;\n\tinvocation[PreparedServerRenderProgram] = true;\n\tinvocation.program = branded;\n\tinvocation.eagerValues = eagerValues;')
for old,new in [('if (Array.isArray(child)) normalized.push(...normalizeChildren(child));','if (Array.isArray(child) && !readPreparedServerRenderProgram(child)) normalized.push(...normalizeChildren(child));'),('if (!Array.isArray(result)) return [result];','if (!Array.isArray(result) || readPreparedServerRenderProgram(result)) return [result];'),('for (const child of result) if (Array.isArray(child)) return normalizeChildren(result);','for (const child of result) if (Array.isArray(child) && !readPreparedServerRenderProgram(child)) return normalizeChildren(result);')]:
 assert source.count(old)==1
 source=source.replace(old,new)
(root/'array-invocation').mkdir(exist_ok=True)
(root/'array-invocation/server-entry.js').write_text(source, encoding='utf-8')
p=(root/'stateful-scope-pressure.mjs').read_text().replace('stateful-scope','array-invocation')
(root/'array-invocation-pressure.mjs').write_text(p, encoding='utf-8')
print(hashlib.sha256((root/'array-invocation/server-entry.js').read_bytes()).hexdigest())

