import os from 'node:os';os.setPriority(0,10);
import {auditCreate} from './array-invocation-layout-entry.mjs';
const values=['a','b'];const invocation=auditCreate({id:'audit'},values);
%DebugPrint(invocation);%DebugPrint(invocation.eagerValues);
