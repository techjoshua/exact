import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
for(const variant of ['direct-execution-integrated','array-invocation']){
 const code=fs.readFileSync(root+variant+'/server-entry.js','utf8')+'\nexport {createPreparedServerRenderProgram as auditCreate};\n';
 const exposed=root+variant+'-layout-entry.mjs';fs.writeFileSync(exposed,code);
 const worker=root+variant+'-layout-worker.mjs';
 fs.writeFileSync(worker,`import os from 'node:os';os.setPriority(0,10);\nimport {auditCreate} from './${variant}-layout-entry.mjs';\nconst values=['a','b'];const invocation=auditCreate({id:'audit'},values);\n%DebugPrint(invocation);%DebugPrint(invocation.eagerValues);\n`);
 const result=spawnSync(process.execPath,['--allow-natives-syntax',worker],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 assert.equal(result.status,0,result.stderr);fs.writeFileSync(root+variant+'-layout.log',result.stdout+result.stderr);
 console.log(variant,result.stdout);
}
