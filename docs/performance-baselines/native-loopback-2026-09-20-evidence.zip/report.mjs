import {readFile,writeFile} from 'node:fs/promises';
import {summarizeSsrCapacityCapture} from '../../framework-comparison/src/ssr-capacity-report.mjs';
const root=import.meta.dirname, prefix=root.split('/').at(-1);
const reference=process.env.COMPARISON_REFERENCE ?? 'correctness-followup-2026-09-20';
const baselineLabel=reference==='wsl-framework-2026-09-18'?'Published 0.5.1 installation on WSL':'Previous mirrored-loopback capture';
const json=async p=>JSON.parse(await readFile(p,'utf8'));
const source=await json(root+'/source-state.json'), report=await json(root+'/report-data.json'), raw=await json(root+'/ssr.json');
const f=(n,p=2)=>Number(n).toLocaleString('en-US',{minimumFractionDigits:p,maximumFractionDigits:p});
const title='Framework comparison on verified native Linux loopback';
const lines=[`# ${title}, September 20, 2026`,'',
'This full capture measures the repository implementation through workspace-resolved compiler, runtime, and adapter packages. Source revision: `'+source.commit+'` with the recorded source state. Package release target: 0.6.0; component and render-program ABI: 2.','',
'This capture repeats the full suite after identifying the mirrored WSL IPv4 localhost route as a cause of the relative throughput shift. The entire build, correctness, and measurement job runs in one private Linux network namespace with native `lo` routing. Host networking and LAN access remain unchanged. See the [controlled routing investigation](ssr-loopback-investigation-2026-09-20.md) for unchanged-artifact controls, reversed order, IPv6 verification, and rejected rendering candidates.','',
`Environment: ${raw.environment.platform} ${raw.environment.platformRelease}; ${raw.environment.cpu.model}; ${raw.environment.cpu.logicalCount} logical CPUs; ${f(raw.environment.totalMemoryBytes/1024**3,1)} GiB RAM; Node ${raw.environment.runtimes.node}; Bun ${raw.environment.runtimes.bun}.`,'',
'All five controlled participants are included in browser and string SSR measurements. Streaming covers eXact, React, and TanStack Start. The separate native track covers eXact and React. Browser timing uses 30 samples; startup uses ten samples at each of 1x/4x/6x CPU throttling; heap uses five samples. SSR diagnostics use 500 sequential requests, 500 16-request waves, and one 1,000 ms c32 diagnostic window. Native measurements retain seven samples. Sustained comparisons use all twelve original Windows plans with two independent drivers and reversed framework order.','',
'The participants retain one shared stylesheet. This run retains task callback discovery, encoded list hydration, and the Bun streaming response contract fixes. No renderer or adapter optimization was added for this capture. Desktop and mobile presentation gates compare server HTML and settled interactions before timing. Earlier five-framework paint comparisons included different visual workloads and must not be interpreted as isolated framework overhead. See the [presentation and paint investigation](presentation-parity-investigation-2026-09-20.md) for same-asset Windows/WSL controls, compiler corrections, and Bun concurrency experiments.','',
'## Sustained throughput and eXact/React ratios','',
'At total concurrency 32, RPS counts valid completed responses and divides by the union of simultaneous driver spans, summed over both populations and including drain. A ratio above 1 favors eXact. The ratio change is the requested relative-performance measure; it is not a direct percentage change in eXact RPS. The route experiment demonstrates that the same network change can affect the frameworks differently, so cross-route ratios alone do not identify a renderer regression.','',
`Reference: [${baselineLabel}](${reference}.md).`,'',
'| Runtime/API | Loading | eXact RPS | React RPS | eXact/React | Reference ratio | Ratio change |',
'| --- | --- | ---: | ---: | ---: | ---: | ---: |'];
const ratios=[];let errors=0,invalid=0;const captures=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const lane of ['multi','normal','arrivals']){
 const name=runtime+(mode==='stream'?'-stream':'')+'-'+lane,c=await json(root+'/'+name+'.json');captures.push(c);
 for(const b of c.blocks)for(const r of b.results)for(const s of r.stages){errors+=s.errors??0;invalid+=s.invalid??s.invalidResponses??0;}
 if(lane==='arrivals')continue;
 const before=await json(`docs/performance-baselines/${reference}-${name}.json`);
 const rates=d=>{const s=summarizeSsrCapacityCapture(d).filter(r=>r.concurrency===32);const exact=s.find(r=>r.name==='eXact').rps,react=s.find(r=>r.name==='React').rps;return{exact,react,ratio:exact/react};};
 const a=rates(before),b=rates(c),change=(b.ratio/a.ratio-1)*100;
 ratios.push({runtime,mode,lane,before:a,after:b,ratioChangePercent:change});
 lines.push('| '+[runtime+'/'+mode,lane==='multi'?'preloaded':'normal',f(b.exact,0),f(b.react,0),f(b.ratio,3)+'×',f(a.ratio,3)+'×',(change>=0?'+':'')+f(change,1)+'%'].join(' | ')+' |');
}
const references=await json(root+'/reference-comparisons.json');
lines.push('','## Original reference and recovery checks','','The original reference is the [corrected September 19 workspace capture](wsl-workspace-2026-09-19.md). The [route and artifact investigation](ssr-loopback-investigation-2026-09-20.md) explains the network correction and records the remaining differences without attributing all timing movement to framework code.','','| Runtime/API | Loading | Current ratio | Original ratio | Ratio change |','| --- | --- | ---: | ---: | ---: |');
for(const r of references){const b=r.references['wsl-workspace-2026-09-19'];lines.push('| '+[r.runtime+'/'+r.mode,r.lane==='multi'?'preloaded':'normal',f(r.after.ratio,3)+'×',f(b.ratio,3)+'×',(b.ratioChangePercent>=0?'+':'')+f(b.ratioChangePercent,1)+'%'].join(' | ')+' |');}
lines.push('','All eight comparisons improve on the preceding mirrored-loopback capture. Six exceed the original reference. Node streaming remains 2.5% below the original preloaded ratio and 1.0% below with normal loading. No runtime or renderer source change is credited for the network recovery. Further artifact controls and a rejected streaming-specific lookup candidate remain separate evidence.','',
'Bun string throughput falls about 8% from c64 to c128 in both populations. There are no request errors or invalid responses in that sweep; the previously observed large collapse does not recur.','',
'### Renderer-only diagnostic','',
'These 1,000-render sequential diagnostics exclude request sockets and service fetching. They use a different execution history from saturated HTTP and cannot be added to HTTP cost components.','',
'| Capture | eXact mean, µs | React mean, µs | eXact/React time |','| --- | ---: | ---: | ---: |');
for(const r of await json(root+'/render-diagnostic-comparison.json'))lines.push(`| ${r.capture} | ${f(r.exact,1)} | ${f(r.react,1)} | ${f(r.ratio,3)}× |`);
lines.push('','The current renderer-only ratio moves back toward the September 19 recovery result. The routing controls establish the end-to-end network effect; they do not establish that routing directly changes a socket-free render operation.','');
lines.push('','## Browser experience','','Each cell is mean / p50 / p95 / p99. Latency and memory: lower is better.','',
'| Metric | Unit | '+report.browserCharts[0].series.map(s=>s.name).join(' | ')+' |','| --- | --- | '+report.browserCharts[0].series.map(()=> '---:').join(' | ')+' |');
for(const c of report.browserCharts)lines.push('| '+[c.title,c.unit,...c.series.map(s=>['mean','p50','p95','p99'].map(k=>f(s.stats[k],3)).join(' / '))].join(' | ')+' |');
lines.push('','## SSR completion tails','','Completion of a 16-request wave, including data loading. Cells are mean / p95 / p99 milliseconds.','',
'| Runtime/API | '+report.server.burst.series.map(s=>s.name).join(' | ')+' |','| --- | '+report.server.burst.series.map(()=> '---:').join(' | ')+' |');
const stream=await json('apps/docs/src/data/ssr-stream-report.json');
for(const [mode,owner] of [['string',report.server],['stream',stream.server]])for(const runtime of ['node','bun']){const chart=(runtime==='node'?owner:owner.bun).burst;lines.push('| '+runtime+'/'+mode+' | '+report.server.burst.series.map(s=>{const r=chart.series.find(r=>r.name===s.name);return r?['mean','p95','p99'].map(k=>f(r.stats[k])).join(' / '):'unavailable';}).join(' | ')+' |');}
lines.push('','## Scheduled offered load','','Errors, drain time, and missed arrivals remain part of the reported results.','',
'| Runtime/API | Framework | Offered RPS | Valid RPS, populations | Request errors | Missed arrivals |','| --- | --- | ---: | ---: | ---: | ---: |');
for(const c of captures.filter(c=>c.plan.stages.some(s=>s.mode==='arrival')))for(const id of ['exact','react'])for(const rate of [8000,10000]){let e=0,m=0;const rates=[];for(const b of c.blocks.filter(b=>b.id===id).sort((a,b)=>a.population-b.population)){const ss=b.results.map(r=>r.stages.find(s=>s.name==='total-arrivals-'+rate));rates.push(f(ss.reduce((a,s)=>a+s.validRps,0),0));for(const s of ss){e+=s.errors;m+=s.missedCapacity+s.missedLag+s.missedDeadline;}}lines.push('| '+[c.runtimeId+'/'+c.renderMode,id,f(rate,0),rates.join(' / '),e,m].join(' | ')+' |');}
lines.push('',`Total request errors across capacity stages, including warmup: ${errors}. Invalid responses: ${invalid}.`,'',
'## Correctness and evidence','',
'Both runtimes passed 39 string and 25 streaming browser contracts before timing. The native track passed all 12 contracts. Native timing, startup CPU profiles, allocation captures, heap composition, raw response samples, and per-driver results remain separate evidence.','',
`The [structured capture](${prefix}.json) links all raw captures and records hashes, source state, exact runners, execution journal, and prior chart values. The [evidence archive](${prefix}-evidence.zip) retains the source patch, logs, load plans, and documentation verification. Native samples are in [the native capture](${prefix}-native.json).`,'');
await writeFile(`docs/performance-baselines/${prefix}.md`,lines.join('\n'));
await writeFile(root+'/ratio-comparison.json',JSON.stringify(ratios,null,2)+'\n');
console.log(JSON.stringify({reference,ratios,errors,invalid},null,2));
