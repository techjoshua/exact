import {execFileSync} from 'node:child_process';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
const roots=['packages','component-libraries','framework-adapters','react-adapters','plugins','native','framework-comparison','scripts','package.json','package-lock.json'];
const git=(...args)=>execFileSync('git',args,{encoding:'utf8',maxBuffer:64*1024*1024});
const paths=git('ls-files','--cached','--others','--exclude-standard','-z','--',...roots).split('\0').filter(p=>p&&existsSync(p));
const files=Object.fromEntries(paths.sort().map(p=>[p,createHash('sha256').update(readFileSync(p)).digest('hex')]));
writeFileSync('.tmp/native-loopback-2026-09-20/source-state.json',JSON.stringify({commit:git('rev-parse','HEAD').trim(),capturedAt:new Date().toISOString(),trackedStatus:git('status','--short','--untracked-files=no'),files},null,2));
writeFileSync('.tmp/native-loopback-2026-09-20/source.patch',execFileSync('git',['diff','--binary','HEAD','--',...roots],{maxBuffer:64*1024*1024}));
