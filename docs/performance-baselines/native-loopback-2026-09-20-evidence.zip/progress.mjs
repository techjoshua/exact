import {readFileSync,existsSync} from 'node:fs';
import {summarizeSsrCapacityCapture} from '../../framework-comparison/src/ssr-capacity-report.mjs';
const dir=import.meta.dirname;
const read=p=>JSON.parse(readFileSync(p));
for(const runtime of ['node','bun'])for(const mode of ['','-stream'])for(const lane of ['multi','normal']){
 const name=runtime+mode+'-'+lane,path=dir+'/'+name+'.json';if(!existsSync(path))continue;const d=read(path);if(!d.complete)continue;
 const rate=c=>{const r=summarizeSsrCapacityCapture(c).filter(x=>x.concurrency===32);const e=r.find(x=>x.name==='eXact').rps,t=r.find(x=>x.name==='React').rps;return {exact:e,react:t,ratio:e/t}};
 const now=rate(d),before=rate(read('docs/performance-baselines/correctness-followup-2026-09-20-'+name+'.json'));
 console.log(name,JSON.stringify({...now,change:100*(now.ratio/before.ratio-1)}));
}
