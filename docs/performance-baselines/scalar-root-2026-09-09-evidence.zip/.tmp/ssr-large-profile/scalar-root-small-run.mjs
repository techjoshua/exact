﻿import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const rows=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(let round=0;round<2;round++)for(const variant of round%2?['scalar-root','scalar-root-control']:['scalar-root-control','scalar-root']){
 const entry=`.tmp/ssr-large-profile/${variant}.mjs`;
 const result=spawnSync(runtime,['.tmp/ssr-large-profile/long-worker.mjs',entry,mode,'small','12000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(result.status!==0)throw Error(result.stderr||result.stdout);
 const row={variant,round,runtimeId:runtime,artifactSha256:createHash('sha256').update(readFileSync(entry)).digest('hex'),...JSON.parse(result.stdout)};
 const peer=rows.find(x=>x.runtimeId===runtime&&x.mode===mode);
 if(peer&&peer.hash!==row.hash)throw Error('Full response changed');
 rows.push(row);writeFileSync('.tmp/ssr-large-profile/scalar-root-small-results.json',JSON.stringify(rows,null,2));
 console.log(runtime,mode,round,variant,row.usPerRender.toFixed(2));
}

