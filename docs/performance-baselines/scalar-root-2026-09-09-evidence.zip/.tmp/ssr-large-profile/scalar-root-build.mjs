import ts from 'typescript';
import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
const source=readFileSync(dir+'class-current.mjs','utf8');
const sf=ts.createSourceFile('input.mjs',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const targets=new Map();
function discover(node){
 if(ts.isCallExpression(node)&&ts.isIdentifier(node.expression)&&node.expression.text==='createPreparedServerRenderProgram'&&ts.isIdentifier(node.arguments[0])&&ts.isArrayLiteralExpression(node.arguments[1])){
  const [program,values]=node.arguments;const root=values.elements[0];
  if(ts.isObjectLiteralExpression(root)){
   const dynamic=root.properties.filter(p=>!ts.isPropertyAssignment(p)||!ts.isStringLiteral(p.initializer));
   if(dynamic.length===1&&ts.isPropertyAssignment(dynamic[0])&&dynamic[0].name.getText(sf)==='className')targets.set(program.text,{root,dynamic:dynamic[0]});
  }
 }
 ts.forEachChild(node,discover);
}
discover(sf);
if(targets.size!==2)throw Error('Expected two closed class roots, found '+targets.size);
let calls=0,plans=0;
const result=ts.transform(sf,[context=>{
 const f=context.factory;
 function visit(node){
  if(ts.isCallExpression(node)&&ts.isIdentifier(node.expression)&&node.expression.text==='createPreparedServerRenderProgram'&&ts.isIdentifier(node.arguments[0])&&targets.has(node.arguments[0].text)){
   calls++;const [program,values]=node.arguments;const target=targets.get(program.text);
   return f.updateCallExpression(node,node.expression,node.typeArguments,[program,f.updateArrayLiteralExpression(values,[target.dynamic.initializer,...values.elements.slice(1)])]);
  }
  if(ts.isVariableDeclaration(node)&&ts.isIdentifier(node.name)&&targets.has(node.name.text)){
   const target=targets.get(node.name.text);const call=node.initializer;const descriptor=call.arguments[0];
   const properties=descriptor.properties.map(p=>{
    if(p.name?.getText(sf)!=='ssrRootStatic')return p;
    plans++;
    const fallback=f.createArrowFunction(undefined,undefined,[f.createParameterDeclaration(undefined,undefined,'value')],undefined,f.createToken(ts.SyntaxKind.EqualsGreaterThanToken),f.createParenthesizedExpression(f.createObjectLiteralExpression(target.root.properties.map(prop=>prop===target.dynamic?f.updatePropertyAssignment(prop,prop.name,f.createIdentifier('value')):prop))));
    return f.updatePropertyAssignment(p,p.name,f.updateArrayLiteralExpression(p.initializer,[...p.initializer.elements,fallback]));
   });
   return f.updateVariableDeclaration(node,node.name,node.exclamationToken,node.type,f.updateCallExpression(call,call.expression,call.typeArguments,[f.updateObjectLiteralExpression(descriptor,properties)]));
  }
  return ts.visitEachChild(node,visit,context);
 }
 return root=>ts.visitNode(root,visit);
}]);
let output=ts.createPrinter().printFile(result.transformed[0]);
const signature='function renderSsrRootAttributes(context, value, tag, staticAttributes, accounted = false) {';
if(!output.includes(signature))throw Error('Missing root serializer');
output=output.replace(signature,signature+`
    if (staticAttributes?.[3]) {
        const layers = context.targetReceiptLayers;
        if (!layers?.some(layer => !layer.consumed)) {
            const prefix = staticAttributes[0] ?? '';
            if (accounted) context.outputSink?.account(prefix);
            const attribute = staticAttributes[2][0];
            return prefix + renderCompiledNativeAttribute(value, attribute[0], attribute[1], attribute[2], tag, context, accounted);
        }
        value = staticAttributes[3](value);
    }
`);
if(calls!==2||plans!==2)throw Error(JSON.stringify({calls,plans}));
writeFileSync(dir+'scalar-root.mjs',output);
// Printer-only control prevents formatting differences from being confused with the transformation.
writeFileSync(dir+'scalar-root-control.mjs',ts.createPrinter().printFile(sf));
result.dispose();
console.log({calls,plans,targets:[...targets.keys()]});
