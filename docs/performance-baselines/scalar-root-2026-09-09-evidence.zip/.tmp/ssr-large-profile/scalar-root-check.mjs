import {readFileSync,writeFileSync,unlinkSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
const dir='.tmp/ssr-large-profile/';
const files=[];
try {
 const modules=[];
 for(const name of ['scalar-root-control','scalar-root']){
  const file=dir+name+'-probe.mjs';files.push(file);
  writeFileSync(file,readFileSync(dir+name+'.mjs','utf8')+'\nexport {renderSsrRootAttributes as probe, __exact_render_program_4$2 as rowProgram, __exact_render_program_6$1 as badgeProgram};\n');
  modules.push(await import(pathToFileURL(resolve(file))));
 }
 let checks=0;
 for(const root of ['rowProgram','badgeProgram'])for(const layers of [undefined,[],[{consumed:true,props:{className:'unused'}}],[{consumed:false,props:{className:'a"b',title:'<title>',style:{color:'red'}}}],[{consumed:false,props:{className:'outer'}},{consumed:false,props:{className:'inner'}}]]){
  const value=root==='rowProgram'?'incident active':'severity critical';
  const props=root==='rowProgram'?{'data-exact-id':'x2z5E3iecU3S7epOGWeUiVR',type:'button',className:value,'data-testid':'incident-row'}:{className:value};
  const results=modules.map((mod,index)=>{
   let accounted=0;
   const context={targetReceiptLayers:structuredClone(layers),outputSink:{account(text){accounted+=Buffer.byteLength(text)},accountKnown(text,bytes){accounted+=bytes}}};
   const html=mod.probe(context,index?value:props,root==='rowProgram'?'button':'span',mod[root].ssrRootStatic,true);
   assert.equal(accounted,Buffer.byteLength(html));
   return {html,layers:context.targetReceiptLayers};
  });
  assert.deepEqual(results[1],results[0]);checks++;
 }
 console.log(JSON.stringify({checks,status:'passed'}));
} finally {for(const file of files)unlinkSync(file);}
