import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { JSDOM } from 'jsdom';
import { startSsrLoadProcess } from '../../framework-comparison/src/ssr-load-process-owner.mjs';
import { startSsrWorker, stopSsrWorker } from '../../framework-comparison/src/ssr-worker-controller.mjs';
import { availableSsrRuntimes } from '../../framework-comparison/src/ssr-run-environment.mjs';
const results = [];
const mode = process.env.COMPARISON_SSR_RENDER_MODE ?? 'string';
for (const runtime of availableSsrRuntimes('node,bun')) for (const participantId of ['exact', 'react']) {
  let service, worker;
  try {
    service = await startSsrLoadProcess('service');
    worker = await startSsrWorker({ runtime, participantId, transport: runtime.id === 'bun' ? 'bun-fetch' : 'node-http', workerPath: resolve('framework-comparison/src/ssr-benchmark-worker.mjs'), workingDirectory: resolve('framework-comparison'), serviceUrl: service.url, environment: { COMPARISON_SSR_BOUNDED_TELEMETRY: '1' } });
    for (const preloaded of [false, true]) {
      const response = await fetch(worker.url + (preloaded ? '?__benchmarkPreloaded=true' : ''));
      assert.equal(response.status, 200);
      const bytes = Buffer.from(await response.arrayBuffer());
      const html = bytes.toString('utf8');
      assert.match(html, /^<!doctype html>/i);
      assert.match(html, /<head(?:\s[^>]*)?>[\s\S]*<\/head><body(?:\s[^>]*)?>[\s\S]*<\/body><\/html>$/i);
      const dom = new JSDOM(html);
      try {
        const document = dom.window.document;
        assert.equal(document.title, 'Incident Operations');
        assert.equal(document.querySelector('meta[name="framework-participant"]').content, participantId);
        const app = document.querySelector('#app');
        assert.equal(app.querySelector('h1').textContent, 'Signal Desk');
        assert.ok(app.querySelector('main'));
        assert.ok(app.textContent.includes('Delayed fulfillment events'));
        assert.ok(app.querySelectorAll('button').length > 0);
        assert.ok(app.querySelectorAll('select').length > 0);
        const hydration = document.querySelector(participantId === 'exact' ? '#__exact_hydration' : '#comparison-data');
        assert.ok(hydration);
        JSON.parse(hydration.textContent);
        results.push({ runtime: runtime.id, participantId, preloaded, renderMode: mode, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex'), elements: app.querySelectorAll('*').length, buttons: app.querySelectorAll('button').length, selects: app.querySelectorAll('select').length, fullDocument: true, applicationMarkupAndHydration: true });
      } finally { dom.window.close(); }
      await writeFile(`.tmp/render-modes-performance/sanity-${mode}-${runtime.id}-${participantId}-${preloaded ? 'preloaded' : 'normal'}.html`, html);
    }
  } finally {
    try { if (worker) await stopSsrWorker(worker); }
    finally { if (service) await service.close(); }
  }
}
await writeFile(`.tmp/render-modes-performance/sanity-responses-${mode}.json`, JSON.stringify(results, null, 2) + '\n');
console.log(JSON.stringify(results, null, 2));
