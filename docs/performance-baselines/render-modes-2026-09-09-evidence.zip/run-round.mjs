import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync,readFileSync,copyFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
const root=resolve('.');
const output=resolve('.tmp/render-modes-performance');
const suite=resolve('framework-comparison');
const npm=resolve(process.env.APPDATA,'npm/node_modules/npm/bin/npm-cli.js');
const journal=process.argv.includes('--resume')?JSON.parse(readFileSync(`${output}/execution.json`)):[];
process.env.COMPARISON_SSR_RENDER_MODE='string';
async function run(name,args,cwd=root,env={}){
  const previous=journal.find(step=>step.name===name);
  if(previous?.code===0){console.log('RETAIN '+name);return;}
  let attempts=previous?.attempts??[];
  if(previous){const archived={...previous};delete archived.attempts;const suffix='attempt'+(attempts.length+1);archived.log=name+'-'+suffix+'.log';copyFileSync(output+'/'+name+'.log',output+'/'+archived.log);for(const ext of ['.json','.json.timed.json'])if(existsSync(output+'/'+name+ext))copyFileSync(output+'/'+name+ext,output+'/'+name+'-'+suffix+ext);attempts=[...attempts,archived];journal.splice(journal.indexOf(previous),1);}
  const step={name,args,cwd,env,startedAt:new Date().toISOString(),...(attempts.length?{attempts}:{})};journal.push(step);
  writeFileSync(`${output}/execution.json`,JSON.stringify(journal,null,2));
  console.log(`START ${name}`);
  const log=openSync(`${output}/${name}.log`,'w');
  try{await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{cwd,env:{...process.env,...env},stdio:['ignore',log,log],windowsHide:true});step.pid=child.pid;child.once('error',fail);child.once('exit',(code,signal)=>{step.code=code;step.signal=signal;code===0?done():fail(new Error(`${name} failed: ${code ?? signal}`));});});}
  finally{closeSync(log);step.endedAt=new Date().toISOString();writeFileSync(`${output}/execution.json`,JSON.stringify(journal,null,2));}
  console.log(`DONE ${name}`);
}
await run('build',[npm,'run','build']);
await run('comparison-build',[npm,'run','build','-w','@exactjs/framework-comparison-suite']);
await run('node-correctness',[resolve('node_modules/@playwright/test/cli.js'),'test','-c','playwright.config.ts'],suite);
await run('node-stream-correctness',[resolve('node_modules/@playwright/test/cli.js'),'test','-c','playwright.config.ts','--grep','exact|react|tanstack-start'],suite,{COMPARISON_SSR_RENDER_MODE:'stream'});
await run('bun-preparation',['src/prepare-bun-measurement.mjs'],suite);
await run('bun-stream-correctness',[resolve('node_modules/@playwright/test/cli.js'),'test','-c','playwright.config.ts','--grep','exact|react|tanstack-start'],suite,{COMPARISON_SSR_RENDER_MODE:'stream',COMPARISON_E2E_RUNTIME:'bun'});
await run('ssr-tests',[resolve('node_modules/vitest/vitest.mjs'),'run'],resolve('packages/ssr'));
await run('hydrate-tests',[resolve('node_modules/vitest/vitest.mjs'),'run'],resolve('packages/hydrate'));
await run('abi',['scripts/check-compiled-abi.mjs']);
await run('response-sanity',[`${output}/sanity-responses.mjs`]);
await run('stream-response-sanity',[`${output}/sanity-responses.mjs`],root,{COMPARISON_SSR_RENDER_MODE:'stream'});
await run('build-identity',[`${output}/verify-current.mjs`]);
await run('browser',['src/measure.mjs','--correctness-passed',`--output=${output}/browser.json`],suite,{COMPARISON_SAMPLES:'50',COMPARISON_MEASUREMENT_ROUND:'10'});
for(const mode of ['string','stream'])for(const runtime of ['node','bun'])for(const lane of ['multi','normal','arrivals']){
 const suffix=mode==='string'?'':'-stream';
 await run(runtime+suffix+'-'+lane,[output+'/capacity-runner.mjs',output+'/'+lane+'-plan.json',output+'/'+runtime+suffix+'-'+lane+'.json',runtime],root,{COMPARISON_SSR_RENDER_MODE:mode});
}
await run('heap',['src/measure-heap.mjs','--correctness-passed'],suite,{COMPARISON_HEAP_SAMPLES:'10',COMPARISON_HEAP_OUTPUT:`${output}/heap.json`});
await run('ssr',['src/measure-ssr.mjs','--correctness-passed'],suite,{
  COMPARISON_SSR_OUTPUT:`${output}/ssr.json`,COMPARISON_SSR_SAMPLES:'500',COMPARISON_SSR_WARMUPS:'100',COMPARISON_SSR_CONCURRENCY_WAVES:'500',COMPARISON_SSR_SATURATION_WINDOWS:'1',COMPARISON_SSR_SATURATION_WINDOW_MS:'1000',COMPARISON_SSR_SATURATION_CONCURRENCY:'32',COMPARISON_SSR_ATTRIBUTION_WINDOWS:'1',COMPARISON_SSR_ATTRIBUTION_CONCURRENCY:'32',COMPARISON_SSR_MEASUREMENT_ROUND:'10'
});
await run('ssr-stream',['src/measure-ssr.mjs','--correctness-passed'],suite,{
  COMPARISON_SSR_RENDER_MODE:'stream',COMPARISON_SSR_OUTPUT:`${output}/ssr-stream.json`,COMPARISON_SSR_SAMPLES:'500',COMPARISON_SSR_WARMUPS:'100',COMPARISON_SSR_CONCURRENCY_WAVES:'500',COMPARISON_SSR_SATURATION_WINDOWS:'1',COMPARISON_SSR_SATURATION_WINDOW_MS:'1000',COMPARISON_SSR_SATURATION_CONCURRENCY:'32',COMPARISON_SSR_ATTRIBUTION_WINDOWS:'1',COMPARISON_SSR_ATTRIBUTION_CONCURRENCY:'32',COMPARISON_SSR_MEASUREMENT_ROUND:'10'
});
await run('startup',['src/measure-startup-cpu.mjs','--correctness-passed',`--output=${output}/startup.json`],suite,{COMPARISON_STARTUP_SAMPLES:'30',COMPARISON_CPU_RATES:'1,4,6',COMPARISON_MEASUREMENT_ROUND:'10'});
await run('reactive',['scripts/benchmark-reactive.mjs']);
await run('dom-list',['scripts/benchmark-dom-list.mjs']);
await run('collections',['scripts/benchmark-collection-transactions.mjs',`--output=${output}/collections.json`]);
await run('framework',['scripts/benchmark-framework-performance.mjs',`--output=${output}/framework.json`]);
await run('server',['scripts/benchmark-server-performance.mjs']);
await run('foundations',['scripts/benchmark-performance-foundations.mjs',`--output=${output}/foundations.json`]);
await run('compiler',['scripts/benchmark-compiler-workflow.mjs']);
await run('devtools',['scripts/benchmark-devtools.mjs']);
await run('react-compat',['scripts/benchmark-react-compat.mjs']);
await run('react-adapters',['scripts/benchmark-react-compat-adapters.mjs']);
console.log('COMPLETE: all measurement lanes');
