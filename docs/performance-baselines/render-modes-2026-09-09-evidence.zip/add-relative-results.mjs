import {readFile,writeFile} from 'node:fs/promises';
const prefix='docs/performance-baselines/render-modes-2026-09-09';
const archive=JSON.parse(await readFile(`${prefix}.json`,'utf8'));
const rows=[];
for(const mode of ['string','stream'])for(const runtime of ['node','bun'])for(const concurrency of [16,32,64,128]){
 const capacity=(mode==='string'?archive.capacities:archive.capacitiesStream)[runtime];
 const pick=name=>capacity.preloaded.find(r=>r.name===name&&r.concurrency===concurrency).rps;
 rows.push({mode,runtime,concurrency,ratio:pick('eXact')/pick('React')});
}
archive.relativeComparison={throughput:rows};
await writeFile(`${prefix}.json`,JSON.stringify(archive,null,2)+'\n');
const lines=['## Relative performance against React','','Ratios divide eXact valid RPS by React valid RPS within the same runtime and rendering API. Above 1 means higher eXact throughput. Separate framework blocks still experience host variation. Historical captures used different shell ownership and API selections, so they are not used to estimate an optimization effect here.','','| Runtime | API | Concurrency | eXact / React |','| --- | --- | ---: | ---: |',...rows.map(r=>`| ${r.runtime} | ${r.mode} | ${r.concurrency} | ${r.ratio.toFixed(3)} |`),''];
const markdown=await readFile(`${prefix}.md`,'utf8');
await writeFile(`${prefix}.md`,markdown.replace('## Browser results',lines.join('\n')+'\n## Browser results'));
console.log('Added within-lane relative throughput for both APIs.');
