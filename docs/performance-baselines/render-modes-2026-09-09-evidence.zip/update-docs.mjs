import fs from 'node:fs';
let p='apps/docs/src/pages/SsrCapacity.tsx';let s=fs.readFileSync(p,'utf8');
s="import nodeStreamReport from '../data/ssr-node-stream-capacity-report.json' with { type: 'json' };\nimport bunStreamReport from '../data/ssr-bun-stream-capacity-report.json' with { type: 'json' };\n"+s;
s=s.replace('[nodeReport, bunReport].map','[nodeReport, bunReport, nodeStreamReport, bunStreamReport].map');
s=s.replace('label: `eXact fixed-concurrency SSR (${report.runtime})`', 'label: `eXact ${report.renderMode} API SSR (${report.runtime})`');
s=s.replace('runtimeId="node"','runtimeId="node-string"').replace('runtimeId="bun"','runtimeId="bun-string"');
s=s.replace('<RuntimeCapacity report={bunReport} runtimeId="bun-string" />','<RuntimeCapacity report={bunReport} runtimeId="bun-string" />\n<RuntimeCapacity report={nodeStreamReport} runtimeId="node-stream" />\n<RuntimeCapacity report={bunStreamReport} runtimeId="bun-stream" />');
s=s.replace('const report = props.report;', "const report = props.report;\nconst modeLabel = report.renderMode === 'stream' ? 'streaming API' : 'string API';");
s=s.replace('{report.runtime} SSR capacity','{report.runtime} SSR capacity: {modeLabel}');
s=s.replace('<h3>Rendering and response handling with data preloaded</h3>', '<p>Both frameworks use the {modeLabel} and render their own complete application document and hydration data.</p>\n<h3>Rendering and response handling with data preloaded</h3>');
s=s.replace('Preloaded SSR throughput: ${report.runtime}', 'Preloaded SSR throughput: ${report.runtime}, ${modeLabel}');
s=s.replace('capacity by concurrency: {report.runtime}', 'capacity by concurrency: {report.runtime}, {modeLabel}');
s=s.replace('sustained throughput: {report.runtime}', 'sustained throughput: {report.runtime}, {modeLabel}');
s=s.replace('scheduled demand: {report.runtime}', 'scheduled demand: {report.runtime}, {modeLabel}');
fs.writeFileSync(p,s);
p='apps/docs/src/pages/PerformancePage.tsx';s=fs.readFileSync(p,'utf8');
s="import streamReport from '../data/ssr-stream-report.json' with { type: 'json' };\n"+s;
const start=s.indexOf('<Callout title="Capture scope">');const end=s.indexOf('</Callout>',start)+10;
if(start<0)throw Error('Missing capture scope');
s=s.slice(0,start)+`<Callout title="Rendering API scope">
<p>String and streaming API results use separate charts. Each framework renders its complete application document and hydration data. Browser measurements use string rendering. The streaming lane includes eXact, React, and TanStack Start; the current Nuxt and SvelteKit document paths do not expose an equivalent streaming API.</p>
<p>eXact's progressive API currently buffers an authored full document until hydration data is ready. These charts measure the selected API, not a guarantee of early document delivery.</p>
</Callout>`+s.slice(end);
s=s.replace('Server response time and memory: Node ${report.metadata.ssrDiagnosticsEnvironment.runtimes.node}', 'Server response time and memory: Node ${report.metadata.ssrDiagnosticsEnvironment.runtimes.node}, string API');
s=s.replace('Server response time and memory: Bun ${report.server.bun.runtime}', 'Server response time and memory: Bun ${report.server.bun.runtime}, string API');
s=s.replace("React's Bun streaming renderer", "React's string renderer");
const marker='<ValueSection\n\t\t\t\ttitle="Response payload: Node"';
const streamSections=`<MetricSection title={'Server response time and memory: Node ' + streamReport.metadata.ssrDiagnosticsEnvironment.runtimes.node + ', streaming API'} description="Complete-response diagnostics using the streaming APIs of eXact, React, and TanStack Start. Nuxt and SvelteKit are unavailable for this lane. eXact currently buffers authored full documents internally." charts={[streamReport.server.burst, streamReport.server.sequential, streamReport.server.retention]} />
<MetricSection title={'Server response time and memory: Bun ' + streamReport.server.bun.runtime + ', streaming API'} description="The same streaming-API workload on native Bun servers. These results are separate from string rendering and from the sustained capacity captures." charts={[streamReport.server.bun.burst, streamReport.server.bun.sequential, streamReport.server.bun.retention]} />
`;
if(!s.includes(marker))throw Error('Missing response section');s=s.replace(marker,streamSections+marker);
s=s.replace('title="Response payload: Node"','title="Response payload: Node, string API"').replace('title="Response payload: Bun"','title="Response payload: Bun, string API"');
fs.writeFileSync(p,s);
