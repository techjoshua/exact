import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const root = '.tmp/ssr-large-profile/';
const out = root + 'structural-composition-shell/';
await fs.mkdir(out, { recursive: true });
const control = await import(pathToFileURL(resolve(root + 'conditional-emission/server-entry.js')));
const fixture = JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json', 'utf8'));
const sample = await control.renderParticipant(fixture, '/incidents/inc-101', { clientTags: '' });
const opening = sample.match(/^<!doctype html>(<html[^>]*>)/)[1];
const headOpening = sample.match(/<head\b[\s\S]*?<\/title>/)[0];
const bodyOpening = sample.match(/<body[^>]*>/)[0];
const divOpening = sample.match(/<div id="app"[^>]*>/)[0];
const code = `
function auditShellScope(context, host, render) {
    countSsrNode(context);
    enterSsrTreeDepth(context);
    let entered;
    return withRenderCleanup(() => {
        if (host) entered = enterHostTag(context, host);
        return render();
    }, () => {
        if (entered) leaveHost(context, entered.tag);
        leaveSsrTreeDepth(context);
    });
}
var auditDynamicShell = prepareCompiledRenderProgram({ version: 1, id: 'audit-dynamic-shell', namespace: 'html', ssrHost: 'html',
    ssr(s, c, i, o) {
        s.begin(c, 1, 3, 13, 13);
        s.static(o, ${JSON.stringify(opening)});
        return mapRenderValue(o.sink.ready(), () => mapRenderValue(auditShellScope(c, 'head', () => {
            s.begin(c, 5, 3, 190, 190);
            s.static(o, ${JSON.stringify(headOpening)});
            return mapRenderValue(o.sink.ready(), () => mapRenderValue(s.keyedChild(o, i.eagerValues[0]), () =>
                mapRenderValue(s.keyedChild(o, i.eagerValues[1]), () => {
                    s.static(o, '</head>');
                    return mapRenderValue(o.sink.ready(), () => o.sink.flush('head'));
                })));
        }), () => mapRenderValue(auditShellScope(c, 'body', () => {
            s.begin(c, 1, 2, 13, 13);
            s.static(o, ${JSON.stringify(bodyOpening)});
            return mapRenderValue(o.sink.ready(), () => mapRenderValue(auditShellScope(c, undefined, () => {
                const child = s.reference(IncidentApp, i.eagerValues[2]);
                if (o.prepareReferences) o.preparation = o.prepareReferences([child]);
                s.begin(c, 1, 2, 11, 11);
                s.static(o, ${JSON.stringify(divOpening)});
                return mapRenderValue(o.sink.ready(), () => mapRenderValue(s.component(c, o, child, '0', 11 + ${divOpening.length - 5}, true), () => {
                    s.static(o, '</div>');
                    return o.sink.ready();
                }));
            }), () => { s.static(o, '</body>'); return o.sink.ready(); }));
        }), () => { s.static(o, '</html>'); return mapRenderValue(o.sink.ready(), () => o); })));
    }
});
`;
for (const name of ['server-entry.js', 'bun-server-entry.js']) {
    let source = await fs.readFile(root + 'conditional-emission/' + name, 'utf8');
    const start = source.indexOf('var __exactImplementation_Document_1 = function Document(props) {');
    const end = source.indexOf('\nvar Document =', start);
    assert.ok(start > 0 && end > start);
    const original = source.slice(start, end);
    const receipts = original.split('\n').filter(line => line.includes('createCompiledChildRangeReceipt(() => this.map(')).map(line => line.trim().replace(/,$/, ''));
    assert.equal(receipts.length, 2);
    const definition = `var __exactImplementation_Document_1 = function Document(props) { return createPreparedServerRenderProgram(auditDynamicShell, [${receipts.join(',')}, { initialData: props.initialData, path: props.path }]); };`;
    source = source.slice(0, start) + code + definition + source.slice(end);
    await fs.writeFile(out + name, source);
}
const candidate = await import(pathToFileURL(resolve(out + 'server-entry.js')));
const rows = [];
for (const mode of ['string', 'stream']) for (let request = 0; request < 4; request++) {
    const data = structuredClone(fixture);
    data.incidents[1].title = `Live ${request} <script> café 🚀`;
    const options = { clientTags: request === 0 ? '' : `<script type="module" src="/assets/app${request}.js"></script><script type="module" src="/assets/vendor${request}.js"></script><link rel="stylesheet" href="/assets/theme${request}.css">` };
    const run = async mod => mode === 'string' ? mod.renderParticipant(data, '/incidents/inc-101', options) : new Response(await mod.renderParticipantStream(data, '/incidents/inc-101', options)).text();
    const expected = await run(control), actual = await run(candidate);
    assert.equal(actual, expected);
    rows.push({ mode, request, bytes: Buffer.byteLength(actual) });
}
await fs.writeFile(out + 'verification.json', JSON.stringify(rows, null, 2));
console.log('Eight byte-identical dynamic shell and hydration comparisons passed.');
const runner = (await fs.readFile(root + 'keyed-program-screen.mjs', 'utf8')).replaceAll('keyed-program', 'structural-composition-shell');
await fs.writeFile(root + 'structural-composition-shell-screen.mjs', runner);
