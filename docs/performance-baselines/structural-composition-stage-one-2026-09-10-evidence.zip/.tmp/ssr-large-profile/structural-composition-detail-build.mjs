import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import ts from 'typescript';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const base='.tmp/ssr-large-profile/', out=base+'structural-composition/';
await fs.mkdir(out,{recursive:true});
const selected=new Map([['__exact_render_program_1$2','auditHeading'],['__exact_render_program_2$1','auditFacts'],['__exact_render_program_7','auditAnalysis'],['__exact_render_program_10','auditComments']]);
for(const name of ['server-entry.js','bun-server-entry.js']) {
 let source=await fs.readFile(base+'structural-composition-shell/'+name,'utf8');
 const ast=ts.createSourceFile(name,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
 const writers=new Map();let detail,rootWriter;
 function visit(n) {
  if(ts.isVariableDeclaration(n)&&ts.isIdentifier(n.name)) {
   if(n.name.text==='__exactImplementation_IncidentDetail_1')detail=n.initializer;
   if((selected.has(n.name.text)||n.name.text==='__exact_render_program_12')&&ts.isCallExpression(n.initializer)) {
    const obj=n.initializer.arguments[0];assert.ok(ts.isObjectLiteralExpression(obj));
    const ssr=obj.properties.find(p=>p.name?.getText(ast)==='ssr');
    assert.ok(ts.isPropertyAssignment(ssr));
    if(n.name.text==='__exact_render_program_12')rootWriter=ssr.initializer;
    else writers.set(n.name.text,ssr.initializer.getText(ast));
   }
  }
  ts.forEachChild(n,visit);
 }
 visit(ast);assert.ok(detail&&rootWriter);assert.equal(writers.size,4);
 const edits=[];let replacements=0;
 function replaceCalls(n) {
  if(ts.isCallExpression(n)&&n.expression.getText(ast)==='createPreparedServerRenderProgram'&&selected.has(n.arguments[0]?.getText(ast))) {
   assert.equal(n.arguments.length,2);assert.ok(ts.isArrayLiteralExpression(n.arguments[1]));
   edits.push({start:n.getStart(ast),end:n.end,text:n.arguments[1].getText(ast)});replacements++;return;
  }
  ts.forEachChild(n,replaceCalls);
 }
 replaceCalls(detail);assert.equal(replacements,4);
 const original=rootWriter.getText(ast);
 const needle='__exactSsr.keyedChild(__exactOutput, __exactValue_1)';assert.equal(original.split(needle).length,2);
 edits.push({start:rootWriter.getStart(ast),end:rootWriter.end,text:original.replace(needle,'auditDetailChildren(__exactOutput, __exactValue_1)')});
 for(const e of edits.sort((a,b)=>b.start-a.start))source=source.slice(0,e.start)+e.text+source.slice(e.end);
 for(const [descriptor,writer] of writers) {


  let body=writer.replaceAll('__exactInvocation.eagerValues[','__exactInvocation[')
   .replaceAll('__exactInvocation.program.ssrRootStatic',descriptor+'.ssrRootStatic')
   .replace(/__exactSsr\.prepare(Text|Child|Component|ComponentProps|Attribute)\(__exactInvocation, (\d+)\)/g,(_,kind,index)=>`auditPrepare${kind}(__exactInvocation[${index}])`);
  assert.ok(!body.includes('__exactInvocation.program'));
  source+=`\nvar ${selected.get(descriptor)} = ${body};\nfunction ${selected.get(descriptor)}Invoke(output, values) { return ${selected.get(descriptor)}(generatedSsrOperations, output.context, values, output); }\n`;
 }
 source+=`
function auditPrepareComponentProps(raw) { const value=unwrap(raw); return value instanceof Promise || (value!==null && typeof value!=='object') ? unpreparedSsrValue : value; }
function auditPrepareText(raw) { const value=unwrap(raw); return value instanceof Promise || typeof value==='object' && value!==null ? unpreparedSsrValue : value; }
function auditPrepareChild(raw) { const value=unwrap(raw); return value instanceof Promise ? unpreparedSsrValue : value; }
function auditPrepareAttribute(raw) { const value=unwrap(raw); return value instanceof Promise ? unpreparedSsrValue : value; }
function auditInlinePart(output, values, invoke) {
 const context=output.context;
 countSsrNode(context);enterSsrTreeDepth(context);
 return withRenderCleanup(
  () => renderProgramWriter(context,undefined,values,invoke,output.target ?? output.render,output.prepareReferences),
  () => leaveSsrTreeDepth(context)
 );
}
function auditDetailChildren(output, children) {
 if(!Array.isArray(children))return generatedSsrOperations.keyedChild(output,children);
 if(children.length!==7 || !output.context.writerSink || output.context.hostStack.at(-1)==='html')throw new Error('Outside conditional fragment diagnostic domain');
 return mapRenderValue(writeProgramBoundary(output.context,output.sink,'','',()=>auditDetailSequence(output,children,0)),()=>undefined);
}
function auditDetailSequence(output,children,index) {
 while(index<children.length) {
  const position=index++,value=children[position];
  const result=position===0 ? auditInlinePart(output,value,auditHeadingInvoke) : position===1 ? auditInlinePart(output,value,auditFactsInvoke) : position===5 ? auditInlinePart(output,value,auditAnalysisInvoke) : position===6 ? auditInlinePart(output,value,auditCommentsInvoke) : output.render([value]);
  if(result instanceof Promise)return awaitSsrProgramSink(output.sink,result).then(html=>{if(html)output.sink.write(html);return mapRenderValue(output.sink.ready(),()=>auditDetailSequence(output,children,index));});
  if(result)output.sink.write(result);
  const pending=output.sink.ready();
  if(pending)return pending.then(()=>auditDetailSequence(output,children,index));
 }
 return '';
}
`;
 await fs.writeFile(out+name,source);
}
const modules=await Promise.all(['conditional-emission','structural-composition'].map(dir=>import(pathToFileURL(resolve(base+dir+'/server-entry.js')))));
const rows=[];
for(const mode of ['string','stream'])for(let request=0;request<5;request++) {
 const data=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));
 data.incidents[1].title=`Conditional ${request} <script> café 🚀`;
 if(request===3)data.incidents[1].comments=[];
 const options={clientTags:request===0?'':`<script type="module" src="/assets/app${request}.js"></script><link rel="stylesheet" href="/assets/theme${request}.css">`};
 const path=request===4?'/incidents/missing':'/incidents/inc-101';
 const results=[];
 for(const mod of modules)results.push(mode==='string'?await mod.renderParticipant(data,path,options):await new Response(await mod.renderParticipantStream(data,path,options)).text());
 assert.equal(results[0],results[1]);rows.push({mode,request,bytes:Buffer.byteLength(results[1])});
}
await fs.writeFile(out+'verification.json',JSON.stringify(rows,null,2));
let runner=await fs.readFile(base+'dynamic-shell-fusion-http.mjs','utf8');
await fs.writeFile(base+'structural-composition-http.mjs',runner.replaceAll('dynamic-shell-fusion','structural-composition').replace('Dynamic shell fusion','Conditional fragment'));
let trace=await fs.readFile(base+'dynamic-shell-fusion-trace.mjs','utf8');
trace=trace.replaceAll('dynamic-shell-fusion','structural-composition').replace('const selected=/^(','const selected=/^(auditInlinePart|auditDetail|');
await fs.writeFile(base+'structural-composition-trace.mjs',trace);
console.log('Ten full-output comparisons passed');
