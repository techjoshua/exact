from pathlib import Path

base = Path('.tmp/ssr-large-profile')
# Keep original experiment sources and artifacts intact.
shell = (base / 'dynamic-shell-fusion-build.mjs').read_text(encoding='utf-8')
shell = shell.replace('dynamic-shell-fusion', 'structural-composition-shell')
(base / 'structural-composition-shell-build.mjs').write_text(shell, encoding='utf-8')

detail = (base / 'conditional-fragment-build.mjs').read_text(encoding='utf-8')
detail = detail.replace('conditional-fragment', 'structural-composition')
detail = detail.replace("base+'conditional-emission/'+name", "base+'structural-composition-shell/'+name")
detail = detail.replace("const selected=new Map([[", "const selected=new Map([['__exact_render_program_1$2','auditHeading'],[")
detail = detail.replace('assert.equal(writers.size,3)', 'assert.equal(writers.size,4)')
detail = detail.replace('assert.equal(replacements,3)', 'assert.equal(replacements,4)')
detail = detail.replace("  assert.ok(!writer.includes('prepareReferences'),'Borrowed output must not acquire sibling preparation');", '')
detail = detail.replace("  assert.ok(!writer.includes('.reference('),'Prototype does not fuse a component boundary');", '')
needle = '  source+=`\\nvar ${selected.get(descriptor)} = ${body};\\n`;'
assert detail.count(needle) == 1
detail = detail.replace(needle, '  source+=`\\nvar ${selected.get(descriptor)} = ${body};\\nfunction ${selected.get(descriptor)}Invoke(output, values) { return ${selected.get(descriptor)}(generatedSsrOperations, output.context, values, output); }\\n`;')
start = detail.index('function auditInlinePart(output, values, writer) {')
end = detail.index('\nfunction auditDetailChildren', start)
detail = detail[:start] + '''function auditInlinePart(output, values, invoke) {
 const context=output.context;
 countSsrNode(context);enterSsrTreeDepth(context);
 return withRenderCleanup(
  () => renderProgramWriter(context,undefined,values,invoke,output.target ?? output.render,output.prepareReferences),
  () => leaveSsrTreeDepth(context)
 );
}''' + detail[end:]
detail = detail.replace('const result=position===1 ?', 'const result=position===0 ? auditInlinePart(output,value,auditHeadingInvoke) : position===1 ?')
for name in ['auditFacts','auditAnalysis','auditComments']:
    detail = detail.replace(f'output,value,{name})', f'output,value,{name}Invoke)')
detail = detail.replace('function auditPrepareText(raw)', '''function auditPrepareComponentProps(raw) { const value=unwrap(raw); return value instanceof Promise || (value!==null && typeof value!=='object') ? unpreparedSsrValue : value; }
function auditPrepareText(raw)''')
(base / 'structural-composition-detail-build.mjs').write_text(detail, encoding='utf-8')
print('Built isolated shell and detail transformation scripts; no timing runner invoked')
