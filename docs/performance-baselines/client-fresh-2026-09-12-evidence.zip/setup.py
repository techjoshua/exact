from pathlib import Path
p=Path('.tmp/client-fresh')
s=Path('.tmp/client-full/run.mjs').read_text().replace('client-full','client-fresh')
s=s[:s.index("execFileSync('git'")]+"""
await run('correctness-before',['../node_modules/@playwright/test/cli.js','test','-c','playwright.config.ts'],suite);
await run('browser',['src/measure.mjs','--correctness-passed','--output='+output+'/browser.json'],suite,{COMPARISON_SAMPLES:'30',COMPARISON_MEASUREMENT_ROUND:'16'});
await run('correctness-built',['../node_modules/@playwright/test/cli.js','test','-c','playwright.config.ts'],suite);
await run('startup',['src/measure-startup-cpu.mjs','--correctness-passed','--output='+output+'/startup.json'],suite,{COMPARISON_STARTUP_SAMPLES:'10',COMPARISON_CPU_RATES:'1,4,6',COMPARISON_MEASUREMENT_ROUND:'16'});
await run('heap',['src/measure-heap.mjs','--correctness-passed'],suite,{COMPARISON_HEAP_SAMPLES:'5',COMPARISON_HEAP_OUTPUT:output+'/heap.json'});
console.log('COMPLETE client measurements');
"""
(p/'run.mjs').write_text(s)
for f in Path('apps/docs/src/data').glob('*report.json'):
 (p/('before-'+f.name)).write_bytes(f.read_bytes())
