import assert from 'node:assert/strict';
import {readFile,writeFile,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {summarizePercentiles} from '../../framework-comparison/src/percentile-summary.mjs';
import {createHeapCompositionReport} from '../../framework-comparison/src/browser-heap-composition.mjs';
import {adaptFrameworkComparisonBrowserRun,adaptFrameworkComparisonStartupCpu} from '../../scripts/component-local-target-abi/framework-comparison-adapters.mjs';
const root='.tmp/client-fresh',prefix='docs/performance-baselines/client-fresh-2026-09-12';
const json=async p=>JSON.parse(await readFile(p,'utf8'));
const browser=await json(root+'/browser.json'),startup=await json(root+'/startup.json'),heap=await json(root+'/heap.json'),previous=await json(root+'/before-performance-report.json');
assert.equal(browser.publishable,true);assert.equal(startup.complete,true);assert.equal(startup.publishable,true);
adaptFrameworkComparisonBrowserRun(browser);adaptFrameworkComparisonStartupCpu(startup);
for(const entry of heap.participants){const id=entry.id+'-controlled';const hash=browser.complexity.find(v=>v.participantId===id).artifacts.hash;assert.equal(entry.artifactHash,hash);assert.equal(startup.artifacts[id],hash);}
const readers={'Navigation completion':s=>s.navigation.durationMs,'First contentful paint':s=>s.navigation.firstContentfulPaintMs,'Optimistic feedback':s=>s.optimisticFeedbackMs,'Authoritative settlement':s=>s.settlementMs,'Warm browser used heap':s=>s.heapBytes/1e6};
const ids={Exact:'exact-controlled',React:'react-controlled',SvelteKit:'sveltekit-controlled',Nuxt:'nuxt-controlled','TanStack Start':'tanstack-start-controlled'};
const browserCharts=previous.browserCharts.map(chart=>({...chart,series:chart.series.map(series=>({name:series.name,stats:summarizePercentiles(browser.browser[ids[series.name]].samples.map(readers[chart.title]))}))}));
const mean=title=>browserCharts.find(c=>c.title===title).series.find(s=>s.name==='Exact').stats.mean;
const sources={};
for(const name of ['browser','startup','heap']){const path=prefix+'-'+name+'.json';await copyFile(root+'/'+name+'.json',path);sources[name]={path,sha256:createHash('sha256').update(await readFile(path)).digest('hex')};}
const report={...previous,browserCharts,summary:[{label:'Optimistic mean',value:mean('Optimistic feedback').toFixed(2)+' ms',context:'visible client feedback'},{label:'Warm browser heap',value:mean('Warm browser used heap').toFixed(2)+' MB',context:'post-GC used heap'}],metadata:{...previous.metadata,createdAt:new Date().toISOString(),capture:'client-fresh-2026-09-12',commit:browser.harness.commit.slice(0,8)+(browser.harness.workingTreeDirty?'+worktree':''),browserCommit:browser.harness.commit,browserCreatedAt:browser.createdAt,browserSamples:browser.harness.sampleCount,browserDelivery:browser.harness.clientDelivery,browserEnvironment:browser.environment,browserSource:sources.browser,startupCreatedAt:startup.createdAt,startupSamples:startup.harness.sampleCount,sources:{...previous.metadata.sources,browser:sources.browser,heap:sources.heap,startupCpu:sources.startup}}};
assert.deepEqual(report.server,previous.server);
for(const name of ['ssr-stream-report','ssr-capacity-report','ssr-bun-capacity-report','ssr-node-stream-capacity-report','ssr-bun-stream-capacity-report'])assert.deepEqual(await json('apps/docs/src/data/'+name+'.json'),await json(root+'/before-'+name+'.json'));
const execution=await json(root+'/execution.json');assert.equal(execution.length,5);assert.ok(execution.every(s=>s.code===0));
const heapReport=createHeapCompositionReport(heap);
await writeFile('apps/docs/src/data/performance-report.json',JSON.stringify(report,null,2)+'\n');
await writeFile('apps/docs/src/data/performance-heap-report.json',JSON.stringify(heapReport,null,2)+'\n');
await writeFile(prefix+'.json',JSON.stringify({createdAt:report.metadata.createdAt,sources,execution,report,heapReport,previousReport:previous,environment:{browser:browser.environment,startup:startup.environment},harness:{browser:browser.harness,startup:startup.harness},artifactIdentities:browser.complexity.map(e=>({participant:e.participantId,artifact:e.artifacts})),sourceIdentity:'Uncommitted working tree based on browser.harness.commit; SSR capture remains separately identified'},null,2)+'\n');
console.log('Published fresh client charts; SSR data verified unchanged.');
