from pathlib import Path
import json, hashlib, zipfile, subprocess
root=Path('.tmp/client-fresh');prefix=Path('docs/performance-baselines/client-fresh-2026-09-12')
def load(p):return json.loads(p.read_text())
capture=load(Path(str(prefix)+'.json')); report=capture['report']; startup=load(root/'startup.json')
lines=['# Fresh client benchmarks, September 12, 2026','','This capture refreshes browser timing, startup CPU diagnostics, and retained heap composition','for eXact, React, SvelteKit, Nuxt, and TanStack Start. The preceding','[client capture](client-full-2026-09-11.md) remains historical evidence; the','[fresh SSR capture](ssr-fresh-2026-09-12.md) retains its own results and metadata.','','The harness rebuilt client artifacts and ran the shared 35-test browser correctness suite before','measurement and again after the browser build. Browser timing uses 30 fresh contexts per framework','after a discarded warmup round. Startup profiling uses ten samples per framework at each of','1x, 4x, and 6x CPU throttling. Heap composition uses five snapshots per framework after warmup.','','Measurements run sequentially on the shared Windows PC, with balanced framework order. Browser','delivery uses the common replay transport, serving each framework\'s captured production document','and assets after stopping its SSR server. Application interactions still use the controlled service.','HTTP cache is disabled. These are warm-browser-process, fresh-context results, not cold process','startup or production network measurements. Heap snapshots describe post-GC retained composition,','not allocation rate or proof of a leak.','','The measured working tree is uncommitted, based on `'+report['metadata']['browserCommit']+'`.','Artifact hashes match across browser timing, startup profiling, and heap capture. Older measurements','were taken at different times on this shared machine; differences are not isolated causal estimates.','','## Browser results','','| Metric | Framework | Mean | p95 | p99 | Previous mean |','| --- | --- | ---: | ---: | ---: | ---: |']
for chart in report['browserCharts']:
 old=next(c for c in capture['previousReport']['browserCharts'] if c['title']==chart['title'])
 for series in chart['series']:
  prev=next(s for s in old['series'] if s['name']==series['name'])
  st=series['stats'];lines.append(f"| {chart['title']} ({chart['unit']}) | {series['name']} | {st['mean']:.3f} | {st['p95']:.3f} | {st['p99']:.3f} | {prev['stats']['mean']:.3f} |")
lines+=['','## Startup CPU diagnostics','','These diagnostic profiles remain in the raw evidence and this report. The public browser charts','retain their existing metric selection. Tracing and CPU throttling distinguish these samples','from the ordinary browser timing lane.','','| CPU throttle | Framework | Ready mean ms | Script mean ms | Compile mean ms | Total blocking mean ms |','| --- | --- | ---: | ---: | ---: | ---: |']
for rate, entries in startup['profiles'].items():
 for name,entry in entries.items():
  s=entry['summary'];v=[s[k]['mean'] for k in ['readyMs','scriptDurationMs','v8CompileDurationMs','totalBlockingTimeMs']]
  lines.append('| '+rate+' | '+name.replace('-controlled','')+' | '+' | '.join(f'{n:.3f}' for n in v)+' |')
heap=capture['heapReport']
lines+=['','## Retained heap composition','','| Framework | Total MB |','| --- | ---: |']
lines += [f'| {n} | {v:.3f} |' for n,v in zip(heap['categories'],heap['totals'])]
lines+=['','Heap composition follows a separate standardized scenario and may differ from the browser','timing lane\'s warm used-heap metric. Both remain separately labeled in the documentation.','','## Evidence and validation','','The [structured report](client-fresh-2026-09-12.json) links complete raw captures and artifact hashes.','The [evidence archive](client-fresh-2026-09-12-evidence.zip) retains runners, logs, diagnostics,','source state, prior chart data, and chart verification screenshots. The SSR chart payloads and','server section were verified unchanged when publishing this client refresh.','']
checks=load(root/'checks.json');assert all(c.get('code')==0 for c in checks)
capture['validation']={'checks':checks,'docsBrowser':load(root/'docs-verification.json')}
lines+=['Fresh validation passed: 90 harness tests, 112 build-script tests, 10 docs tests, docs typecheck','and build, and desktop/mobile chart checks. The two live correctness runs each passed all 35 tests.','Browser checks compare rendered tables with source values and check page errors and horizontal overflow.','']
Path(str(prefix)+'.md').write_text('\n'.join(lines)+'\n')
sourcePatch=subprocess.check_output(['git','diff','--binary','--','packages','framework-adapters','framework-comparison','plugins'])
(root/'source.patch').write_bytes(sourcePatch)
for name, source in capture['sources'].items():assert hashlib.sha256(Path(source['path']).read_bytes()).hexdigest()==source['sha256']
with zipfile.ZipFile(str(prefix)+'-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(root).as_posix())
 for name in subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','packages','framework-adapters','framework-comparison','plugins'],text=True).splitlines():
  p=Path(name)
  if p.is_file():z.write(p,'untracked-source/'+name)
capture['evidenceArchive']={'path':str(prefix).replace('\\','/')+'-evidence.zip','sha256':hashlib.sha256(Path(str(prefix)+'-evidence.zip').read_bytes()).hexdigest()}
Path(str(prefix)+'.json').write_text(json.dumps(capture,indent=2)+'\n')
print('Archived fresh client evidence')
