import fs from 'node:fs/promises';
import { spawn } from 'node:child_process';
import assert from 'node:assert/strict';
const root = '.tmp/ssr-large-profile/';
const orders = [['baseline','initial','gated'],['baseline','gated','initial'],['initial','baseline','gated'],['initial','gated','baseline'],['gated','baseline','initial'],['gated','initial','baseline']];
const entries = { baseline: 'scoped-capture', initial: 'early-head', gated: 'early-head-gated' };
const rows = [];
for (const [round, order] of orders.entries()) for (const variant of order) {
  const result = await new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [root+'flat-invocation-large-worker.mjs', root+entries[variant]+'/server-entry.js', 'encoded', 'small', '20000'], { windowsHide: true, env: { ...process.env, NODE_ENV: 'production' } });
    let stdout = '', stderr = '';
    child.stdout.on('data', data => stdout += data);
    child.stderr.on('data', data => stderr += data);
    child.on('error', reject);
    child.on('exit', code => resolve({ code, stdout, stderr }));
  });
  assert.equal(result.code, 0, result.stderr);
  const row = { round, variant, ...JSON.parse(result.stdout.trim()) };
  rows.push(row);
  await fs.writeFile(root+'early-head-gated/screen.json', JSON.stringify(rows, null, 2));
  console.log(round, variant, row.usPerRender.toFixed(2));
}
assert.equal(new Set(rows.map(row => row.hash)).size, 1);
