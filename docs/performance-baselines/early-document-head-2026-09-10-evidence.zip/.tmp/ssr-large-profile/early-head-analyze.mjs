import fs from 'node:fs/promises';import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/early-head/';const rows=JSON.parse(await fs.readFile(root+'http.json','utf8'));assert.equal(rows.length,72);
const summary=[];for(const runtime of ['node','bun'])for(const mode of ['string','stream']){
 const selected=rows.filter(r=>r.runtime===runtime&&r.mode===mode),rps=Object.fromEntries(['baseline','compiled','react'].map(v=>[v,selected.filter(r=>r.variant===v).reduce((n,r)=>n+r.rps,0)/6]));
 summary.push({runtime,mode,rps,changePercent:(rps.compiled/rps.baseline-1)*100,improvedBlocks:[0,1,2,3,4,5].filter(b=>selected.find(r=>r.block===b&&r.variant==='compiled').rps>selected.find(r=>r.block===b&&r.variant==='baseline').rps).length});
}
const result={valid:rows.reduce((n,r)=>n+r.results.reduce((n,d)=>n+d.stages[0].valid,0),0),errors:rows.reduce((n,r)=>n+r.results.reduce((n,d)=>n+d.stages[0].errors,0),0),summary};await fs.writeFile(root+'summary.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
