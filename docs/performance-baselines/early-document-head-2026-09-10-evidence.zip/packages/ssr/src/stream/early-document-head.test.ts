import { expect, it, vi } from 'vitest';
import { setTimeout, clearTimeout } from 'node:timers';
import { renderToHydratableProgressiveHtmlStream } from '../render/entrypoints.js';
import { createOperation } from '../test-support/native-operations.js';
import {
	SinkDocument,
	resetSinkFixture,
	sinkFixtureDisposals,
	sinkFixtureStarts
} from '../render/program-sink.fixtures.test.js';

it('delivers the document head to the stream consumer before a body task settles', async () => {
	const settle = resetSinkFixture();
	const reader = renderToHydratableProgressiveHtmlStream(
		createOperation(SinkDocument, {})
	).getReader();
	let timer: ReturnType<typeof setTimeout> | undefined;
	try {
		const first = await Promise.race([
			reader.read(),
			new Promise<undefined>((resolve) => {
				timer = setTimeout(() => resolve(undefined), 1000);
			})
		]);
		expect(first, 'the head must arrive while the body task is still pending').toBeDefined();
		const html = new TextDecoder().decode(first?.value);
		expect(html).toContain('</head>');
		expect(html).toContain('/app.css');
		expect(html).not.toContain('Ready');
		expect(html).not.toContain('</body>');
		settle();
		let tail = '';
		for (;;) {
			const chunk = await reader.read();
			if (chunk.done) break;
			tail += new TextDecoder().decode(chunk.value);
		}
		expect(tail).toContain('Ready');
		expect(tail).toContain('__exact_hydration');
		expect(tail).toMatch(/<\/body><\/html>$/);
		expect(sinkFixtureDisposals()).toBe(1);
	} finally {
		if (timer) clearTimeout(timer);
		settle();
		await reader.cancel();
		reader.releaseLock();
	}
});

it('cancels pending body work and releases ownership after the head was delivered', async () => {
	const settle = resetSinkFixture();
	const reader = renderToHydratableProgressiveHtmlStream(
		createOperation(SinkDocument, {})
	).getReader();
	try {
		expect(new TextDecoder().decode((await reader.read()).value)).toContain('</head>');
		await vi.waitFor(() => expect(sinkFixtureStarts()).toBe(1));
		await reader.cancel(new Error('consumer disconnected'));
		await vi.waitFor(() => expect(sinkFixtureDisposals()).toBe(1));
	} finally {
		settle();
		await reader.cancel();
		reader.releaseLock();
	}
});
