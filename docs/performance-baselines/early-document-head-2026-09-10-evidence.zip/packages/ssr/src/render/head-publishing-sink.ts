import { isExactDocumentHtml } from '../document.js';
import { StringProgramSink } from './string-program-sink.js';
import { SsrOutputLimitError } from './limits.js';
import { utf8ByteLength } from './utf8.js';

/** Retains the final document while publishing its committed head through the same writer. */
export class HeadPublishingSink extends StringProgramSink {
	private head = '';
	private published = false;
	constructor(
		private readonly maxHeadBytes: number,
		private readonly publish: (html: string) => Promise<void>
	) {
		super(maxHeadBytes);
	}
	/** Tracks only the prefix needed for the first document head boundary. */
	override write(html: string): void {
		super.write(html);
		if (!this.published) this.head += html;
	}
	/** Applies transport pressure before rendering can proceed past the committed head. */
	override flush(reason?: 'head' | 'await'): Promise<void> | undefined {
		if (reason !== 'head' || this.published || !isExactDocumentHtml(this.head)) return;
		this.published = true;
		const head = this.head;
		this.head = '';
		if (head.length > this.maxHeadBytes / 3 && utf8ByteLength(head) > this.maxHeadBytes) {
			this.destroy();
			throw new SsrOutputLimitError(this.maxHeadBytes);
		}
		return this.publish(head);
	}
	/** Releases both retained document output and any uncommitted head prefix. */
	override destroy(): void {
		this.head = '';
		super.destroy();
	}
}
