import { expect, it, vi } from 'vitest';
import { HeadPublishingSink } from './head-publishing-sink.js';
import { SsrOutputLimitError } from './limits.js';

it('checks the exact UTF-8 limit before publishing a multibyte head', () => {
	const head = '<!doctype html><html><head>' + '🚀'.repeat(40) + '</head>';
	const publish = vi.fn(async () => {});
	const sink = new HeadPublishingSink(head.length, publish);
	sink.write(head);
	expect(() => sink.flush('head')).toThrow(SsrOutputLimitError);
	expect(publish).not.toHaveBeenCalled();
	expect(() => sink.write('tail')).toThrow('closed');
});
