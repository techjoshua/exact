import {createNodeHandler} from '../../framework-adapters/node-adapter/dist/index.js';
import {createBunRequestHandler} from '../../framework-adapters/bun-adapter/dist/index.js';
export async function selectRequestAdapters(runtime,mode,variant){return {policyId:`node-source-${variant}`,createNodeHandler,createBunRequestHandler};}
