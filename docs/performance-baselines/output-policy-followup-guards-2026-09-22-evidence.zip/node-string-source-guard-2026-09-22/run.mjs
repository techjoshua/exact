import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync,readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const root=import.meta.dirname,source='.tmp/node-string-source-guard-2026-09-22';
const journal=[];
for (const mode of ['string','stream']) {
const captures=[];
for(const variant of ['candidate','control']){
 const args=[source+'/capture.mjs',root+'/plan.json',root+'/'+mode+'-'+variant+'.json','node'];
 const env={NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:mode,EXPERIMENT_VARIANT:variant,EXPERIMENT_ROWS:'default',EXPERIMENT_ORDER:'react-first'};
 const step={mode,variant,args,env,startedAt:new Date().toISOString()};journal.push(step);const save=()=>writeFileSync(root+'/execution.json',JSON.stringify(journal,null,2));save();console.log('START',variant);
 const fd=openSync(root+'/'+mode+'-'+variant+'.log','w');try{await new Promise((done,fail)=>{const c=spawn(process.execPath,args,{env:{...process.env,...env},stdio:['ignore',fd,fd]});c.once('error',fail);c.once('exit',code=>{step.code=code;code===0?done():fail(Error(variant+' '+code));});});}finally{closeSync(fd);step.endedAt=new Date().toISOString();save();}
 captures.push(JSON.parse(readFileSync(root+'/'+mode+'-'+variant+'.json')));console.log('DONE',variant);
}
assert.deepEqual(captures[0].responseIdentities,captures[1].responseIdentities);assert.notEqual(captures[0].artifacts.exact.sha256,captures[1].artifacts.exact.sha256);console.log('PASS identities');

}
