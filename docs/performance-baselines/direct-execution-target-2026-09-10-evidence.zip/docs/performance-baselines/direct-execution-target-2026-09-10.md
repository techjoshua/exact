# Direct component execution as a render target

Status: isolated prototype, not adopted. Source audit and focused correctness probes justify a performance experiment; allocation, timing and HTTP measurements remain pending while workstation load testing is paused.

## Hypothesis and ownership

The integrated operation-target change removes two closures around nested prepared programs. Direct component content still enters `renderDirectSsrContent`, which creates two forwarding closures. Its caller also creates a sibling-preparation closure. These survive the preceding change because direct components use the callback form of the same writer.

Each artifact execution already has a request-local execution object, allocated by `renderServerComponentArtifactOutput`. The prototype retains the actual render owner on that object and gives it shared child-rendering and sibling-preparation methods. `renderDirectSsrContent` passes the execution object into the existing target-capable writer. Three closure constructions per direct content call are removed, at the cost of three fields on the existing execution object. No additional wrapper, separate renderer, sink mode branch or WeakMap lookup is added to the candidate. The publication callback is unchanged, so this is distinct from the earlier rejected publication-receiver experiment.

Before performance measurement, the working expectation is a small allocation reduction, roughly 1-4% on these component-heavy fixtures, with a possible 0-3% timing benefit. Those are hypotheses, not measurements. The added fields and indirect dispatch could offset savings or regress either runtime.

Ownership follows source control flow: each recursive artifact execution creates a distinct execution object. Synchronous component content receives the selected owner from component preparation. Scheduled attempts reuse their scheduled component's owner, and `writeScheduledFrame` awaits a candidate's output before retrying. Per-program preparation remains on the writer output. A shared mutable request-global owner would be unsafe; this prototype does not introduce one.

The source integration would still need an explicit internal contract for binding the render owner. Merely asserting that all observed owners match is not enough to establish correctness for every enhancement, task, observer and error path.

## Focused probes

The frozen integrated build is the control. Three requests with distinct titles run concurrently for each small/large fixture and string/stream mode under both Node and Bun. Instrumentation makes every third ready call suspend in StringProgramSink and CapturedProgramSink. All 24 complete-output comparisons pass, preserving application-owned documents, hydration data and four asset tags.

| Fixture | Mode | Requests per runtime | Induced suspensions | Execution objects | Direct content calls |
| --- | --- | ---: | ---: | ---: | ---: |
| 3 incidents | String | 3 | 183 | 24 | 24 |
| 3 incidents | Stream | 3 | 105 | 24 | 24 |
| 96 incidents | String | 3 | 1,113 | 303 | 303 |
| 96 incidents | Stream | 3 | 663 | 303 | 303 |

Both runtimes have the same counts. Thus these fixtures exercise 8 and 101 direct content calls per request. Source-level closure constructions removed are 24 and 303 per request. This does not measure how many closures the engine actually allocates after optimization or how many bytes they occupy.

Diagnostic-only instrumentation also tracks execution-to-owner associations with a WeakMap and rejects changes. It observes no changes, but the call counts show one content call per execution in these fixtures. Consequently this probe does not exercise scheduled retries or prove their owner stability. The diagnostic WeakMap exists only in the pressure entry, not the candidate bundle used for future performance tests.

No runtime source changed. Broad package/browser acceptance, scheduled retries, enhancement rejection, observer and cleanup cases remain required if performance results justify integration. Prior integrated package-content, release-ABI, explicit-any and platform-boundary checks were separately recovered by successful reruns; they do not validate this prototype.

## Evidence

Control SHA-256: `6d92194f2ee395f4e4e5267b8719bc1160a96ce7bc16f1a6bbdc74f98aba4997`.

Candidate SHA-256: `b4df40493dea5ac6172ffdf8a1d4511face4212852eeb60894d218abce544078`.

`direct-execution-target-2026-09-10-evidence.zip` preserves the asserted builder, control and prototype bundles, pressure runner and instrumented entry, both result files, fixture data, relevant source snapshots and reports. Production remains the integrated operation-target build. No new claim about the gap to React is supported by these correctness probes.
