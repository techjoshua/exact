import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {summarizeSsrCapacityCapture} from '../../framework-comparison/src/ssr-capacity-report.mjs';
const root=import.meta.dirname,prefix=root.split('/').at(-1);
const json=async path=>JSON.parse(await readFile(path,'utf8'));
const execution=await json(root+'/execution.json');
assert.equal(execution.length,27);assert.ok(execution.every(s=>s.code===0));
const arrivals=await json(root+'/bun-stream-arrivals.json');
const rows=summarizeSsrCapacityCapture(arrivals,{allowArrivalErrors:true}).filter(r=>r.name==='eXact');
const describe=rate=>{
 const r=rows.find(r=>r.rate===rate);
 const ss=arrivals.blocks.filter(b=>b.id==='exact'&&b.rate===rate).flatMap(b=>b.results.flatMap(r=>r.stages.filter(s=>!s.discard)));
 assert.ok(ss.every(s=>s.errors===0&&s.invalid===0));
 const miss=ss.reduce((n,s)=>n+s.missedCapacity+s.missedLag+s.missedDeadline,0),offered=ss.reduce((n,s)=>n+s.offered,0);
 return `${Math.round(r.rps).toLocaleString('en-US')} valid RPS at ${rate.toLocaleString('en-US')} offered RPS (${(100*miss/offered).toFixed(2)}% missed arrivals, ${r.p99Min.toFixed(1)}–${r.p99Max.toFixed(1)} ms p99)`;
};
let doc=await readFile('docs/performance.md','utf8');
const start=doc.indexOf('The [Bun admission-policy follow-up]'),end=doc.indexOf('The [routing investigation]',start);assert.ok(start>=0&&end>start);
doc=doc.slice(0,start)+`The [progressive-output follow-up](performance-baselines/${prefix}.md)
is the current framework comparison baseline. All 27 build, correctness, and measurement stages
passed, including browser, startup, heap, Node/Bun string and streaming, twelve sustained-load
captures, and the native track. Bun streaming scheduled demand delivers ${describe(8000)}
and ${describe(10000)}, with zero measured request errors or invalid responses.
String API results and all unfavorable differences remain in the full report.

The [streaming-output investigation](performance-baselines/bun-stream-counting-investigation-2026-09-21.md)
records CPU profiles, rejected queue and encoding candidates, Unicode/limit checks, and focused
controls. On Bun, the document sink groups uncounted fragments and uses conservative UTF-8 bounds before
performing exact byte counts. It preserves output limits, flush thresholds, backpressure, and
cancellation. Node retains its original sink. Both admission controllers retain their existing policies.
The [callback-interval investigation](performance-baselines/bun-loop-interval-investigation-2026-09-21.md)
records the preceding rejected scheduling simplifications. Fixed-concurrency gains alone did not
establish recovery under scheduled demand.

The [preceding Bun capture](performance-baselines/bun-admission-final-2026-09-20.md) and its
[CPU/departure-policy investigation](performance-baselines/bun-admission-investigation-2026-09-20.md)
remain historical evidence, as do the [Node admission capture](performance-baselines/arrival-policy-final-2026-09-20.md)
and its [investigation](performance-baselines/ssr-arrival-investigation-2026-09-20.md).
Each published offered-rate case owns fresh worker, service, and driver processes, with 30 seconds
of target-rate warmup and 60 seconds of measurement. Warmup failures and missed arrivals remain
visible. The current and preceding full captures use the same protocol; older sequential-rate
captures do not isolate runtime changes from protocol changes.

`+doc.slice(end);await writeFile('docs/performance.md',doc);
let readme=await readFile('framework-comparison/README.md','utf8');
readme=readme.replace('The current [Bun admission-policy follow-up](../docs/performance-baselines/bun-admission-final-2026-09-20.md)',`The current [progressive-output follow-up](../docs/performance-baselines/${prefix}.md)`);
readme=readme.replace('[Bun admission investigation](../docs/performance-baselines/bun-admission-investigation-2026-09-20.md)\nrecords the Bun correction, rejected candidates, focused controls, and extended soak.', '[streaming-output investigation](../docs/performance-baselines/bun-stream-counting-investigation-2026-09-21.md)\nrecords the buffering change, profiles, rejected candidates, and focused controls.');
await writeFile('framework-comparison/README.md',readme);
console.log('Updated current benchmark references.');
