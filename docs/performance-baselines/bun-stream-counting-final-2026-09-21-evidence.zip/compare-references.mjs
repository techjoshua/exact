import {readFile,writeFile} from 'node:fs/promises';
import {summarizeSsrCapacityCapture} from '../../framework-comparison/src/ssr-capacity-report.mjs';
const root=import.meta.dirname;
const json=async p=>JSON.parse(await readFile(p,'utf8'));
const rates=c=>{const rows=summarizeSsrCapacityCapture(c).filter(r=>r.concurrency===32);const exact=rows.find(r=>r.name==='eXact').rps,react=rows.find(r=>r.name==='React').rps;return{exact,react,ratio:exact/react};};
const results=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const lane of ['multi','normal']){
 const name=runtime+(mode==='stream'?'-stream':'')+'-'+lane;
 const after=rates(await json(`${root}/${name}.json`));
 const references={};
 for(const reference of ['wsl-workspace-2026-09-19','wsl-recovery-final-2026-09-19','correctness-followup-2026-09-20','native-loopback-2026-09-20','arrival-policy-final-2026-09-20','bun-admission-final-2026-09-20']){
  const before=rates(await json(`docs/performance-baselines/${reference}-${name}.json`));
  references[reference]={...before,ratioChangePercent:100*(after.ratio/before.ratio-1)};
 }
 results.push({runtime,mode,lane,after,references});
}
await writeFile(root+'/reference-comparisons.json',JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify(results,null,2));
