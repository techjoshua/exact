import hashlib,json,zipfile,shutil
from pathlib import Path
root=Path('.tmp/bun-stream-counting-final-2026-09-21')
steps=json.loads((root/'publication-execution.json').read_text())
assert len(steps)==10 and all(s.get('code')==0 for s in steps)
shutil.copyfile(root/'publication-execution.json',root/'evidence/publication-execution.json')
shutil.copyfile(root/'publish-archive.log',root/'evidence/publish-archive.log')
manifest={}
archive=Path('docs/performance-baselines/bun-stream-counting-final-2026-09-21-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted((root/'evidence').rglob('*')):
  if not p.is_file():continue
  name=str(p.relative_to(root/'evidence'));b=p.read_bytes();manifest[name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};z.writestr(name,b)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print('Archived',len(manifest),'files',archive.stat().st_size,'bytes')
