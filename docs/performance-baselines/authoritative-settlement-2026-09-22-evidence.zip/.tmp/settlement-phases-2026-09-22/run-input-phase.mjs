import {Server,ServerResponse} from 'node:http';
import {IncidentStore} from '../../framework-comparison/src/incident-store.mjs';
let serviceMarks=[];
const markService=(name)=>serviceMarks.push({name,at:performance.now()});
const emit=Server.prototype.emit;
Server.prototype.emit=function(name,...args){
 if(name==='request' && args[0].socket.localPort===4310){
  const [req,res]=args;
  if(req.url.endsWith('/claim')){
   markService(req.method+'-incoming');req.once('end',()=>markService(req.method+'-body-end'));
   res.once('finish',()=>markService(req.method+'-finish'));
   const head=res.writeHead;res.writeHead=function(...args){markService(req.method+'-headers');return head.apply(this,args);};
  }
  if(req.url==='/api/events'){
   const write=res.write;res.write=function(chunk,...args){if(String(chunk).includes('event: incident'))markService('sse-write');return write.call(this,chunk,...args);};
  }
 }
 return emit.call(this,name,...args);
};
const claim=IncidentStore.prototype.claimIncident;
IncidentStore.prototype.claimIncident=function(...args){markService('claim-start');const result=claim.apply(this,args);markService('claim-end');return result;};
import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {chromium} from 'playwright';
import {startClientBenchmarkHarness} from '../../framework-comparison/src/client-benchmark-harness.mjs';
import {waitForFirstContentfulPaint} from '../../framework-comparison/src/paint-timing.mjs';
import {assertComparisonNetwork} from '../../framework-comparison/src/network-environment.mjs';
const network=assertComparisonNetwork();
const source=await readFile('framework-comparison/src/measure.mjs','utf8');
const timing=source.slice(source.indexOf('function installInteractionTiming()'),source.indexOf('\nasync function measureControlledService()'));
const participants=[{id:'exact-controlled',directory:'exact',artifact:'dist',url:'http://127.0.0.1:4401'},{id:'react-controlled',directory:'react',artifact:'dist',url:'http://127.0.0.1:4402'}];
const harness=await startClientBenchmarkHarness(participants);let browser;const samples=[];
try{
 browser=await chromium.launch();
 const cases=participants.flatMap(p=>[-1,0,4,8,12].map(offset=>({...p,offset}))); 
 for(let round=0;round<10;round++){
  for(const participant of round%2?[...cases].reverse():cases){
   await fetch('http://127.0.0.1:4310/__benchmark/reset',{method:'POST',headers:{'content-type':'application/json','x-benchmark-control':'fixture-reset'},body:'{}'});
   const context=await browser.newContext();
   try{
    const page=await context.newPage();const errors=[],requests=[],responses=[];
    page.on('pageerror',e=>errors.push(e.message));
    await page.addInitScript({content:`(${timing})();`});
    const cdp=await context.newCDPSession(page);await cdp.send('Network.enable');await cdp.send('Network.setCacheDisabled',{cacheDisabled:true});
    if(process.env.TRACE_NETWORK!=='0') cdp.on('Network.requestWillBeSent',e=>{if(e.request.url.endsWith('/claim'))requests.push({requestId:e.requestId,method:e.request.method,timestamp:e.timestamp,type:e.type,initiator:e.initiator.type});});
    if(process.env.TRACE_NETWORK!=='0') cdp.on('Network.responseReceived',e=>{if(e.response.url.endsWith('/claim'))responses.push({requestId:e.requestId,type:e.type,timestamp:e.timestamp,status:e.response.status,timing:e.response.timing,connectionReused:e.response.connectionReused,protocol:e.response.protocol});});
    await page.goto(participant.url+'/incidents/inc-100',{waitUntil:'domcontentloaded'});
    await page.getByRole('heading',{name:'Checkout authorization failures'}).waitFor();
    await page.evaluate(waitForFirstContentfulPaint);await page.waitForLoadState('load');
    await page.locator('.connection').getByText('Live service',{exact:true}).waitFor();
    serviceMarks=[];
    const button=page.getByRole('button',{name:'Claim incident'});
    await page.evaluate(()=>document.addEventListener('click',()=>requestAnimationFrame(()=>{globalThis.__frameworkComparisonTiming.phasesMs['next-frame']=performance.now()-globalThis.__frameworkComparisonTiming.startedAt;}),{once:true,capture:true}));
    if(participant.offset===-1){await button.click();}else{
     const box=await button.boundingBox();assert.ok(box);
     await page.evaluate(offset=>new Promise(resolve=>requestAnimationFrame(()=>setTimeout(resolve,offset))),participant.offset);
     await page.mouse.click(box.x+box.width/2,box.y+box.height/2);
    }
    await page.getByText('Version 2',{exact:true}).waitFor();await page.getByText('Alex Chen',{exact:true}).waitFor();
    await page.waitForFunction(()=>globalThis.__frameworkComparisonTiming.phasesMs['http-json-decoded']!==undefined);
    assert.deepEqual(errors,[]);
    samples.push({round,offset:participant.offset,id:participant.id,timing:await page.evaluate(()=>globalThis.__frameworkComparisonTiming),requests,responses,serviceMarks});
   }finally{await context.close();}
  }
  console.log('Round',round+1,'/20');
 }
 await writeFile('.tmp/settlement-phases-2026-09-22/results-input-phase.json',JSON.stringify({network,harness:harness.evidence(),samples},null,2));
}finally{try{await browser?.close();}finally{await harness.close();}}
