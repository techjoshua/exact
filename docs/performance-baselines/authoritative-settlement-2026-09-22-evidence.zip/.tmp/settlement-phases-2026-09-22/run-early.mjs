import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {chromium} from 'playwright';
import {startClientBenchmarkHarness} from '../../framework-comparison/src/client-benchmark-harness.mjs';
import {waitForFirstContentfulPaint} from '../../framework-comparison/src/paint-timing.mjs';
import {assertComparisonNetwork} from '../../framework-comparison/src/network-environment.mjs';
const network=assertComparisonNetwork();
const source=await readFile('framework-comparison/src/measure.mjs','utf8');
const timing=source.slice(source.indexOf('function installInteractionTiming()'),source.indexOf('\nasync function measureControlledService()'));
const participants=[{id:'exact-controlled',directory:'exact',artifact:'dist',url:'http://127.0.0.1:4401'},{id:'react-controlled',directory:'react',artifact:'dist',url:'http://127.0.0.1:4402'}];
const cases=participants.flatMap(p=>['baseline','early'].map(variant=>({...p,variant})));
const harness=await startClientBenchmarkHarness(participants);let browser;const samples=[];
try{
 browser=await chromium.launch();
 for(let round=0;round<20;round++){
  for(const participant of round%2?[...cases].reverse():cases){
   await fetch('http://127.0.0.1:4310/__benchmark/reset',{method:'POST',headers:{'content-type':'application/json','x-benchmark-control':'fixture-reset'},body:'{}'});
   const context=await browser.newContext();
   try{
    const page=await context.newPage();const errors=[],requests=[],responses=[];
    page.on('pageerror',e=>errors.push(e.message));
    await page.addInitScript({content:`(${timing})();`});
    if(participant.variant==='early') await page.addInitScript(()=>{
     const originalFetch=globalThis.fetch;let pending;
     const url='http://127.0.0.1:4310/api/incidents/inc-100/claim';
     const body=JSON.stringify({actorId:'user-alex',expectedVersion:1});
     document.addEventListener('click',event=>{
      const button=event.target instanceof Element?event.target.closest('button'):null;
      if(button?.textContent?.trim()!=='Claim incident'||pending)return;
      pending=originalFetch(url,{method:'POST',headers:{'content-type':'application/json'},body});
      pending.catch(()=>{});
     },true);
     globalThis.fetch=(input,init)=>{
      if(input===url&&pending){
       if(init?.body!==body)throw new Error('Early request does not match authored request');
       globalThis.__earlyDispatchUsed=true;return pending;
      }
      return originalFetch(input,init);
     };
    });
    const cdp=await context.newCDPSession(page);await cdp.send('Network.enable');await cdp.send('Network.setCacheDisabled',{cacheDisabled:true});
    if(process.env.TRACE_NETWORK!=='0') cdp.on('Network.requestWillBeSent',e=>{if(e.request.url.endsWith('/claim'))requests.push({requestId:e.requestId,method:e.request.method,timestamp:e.timestamp,type:e.type,initiator:e.initiator.type});});
    if(process.env.TRACE_NETWORK!=='0') cdp.on('Network.responseReceived',e=>{if(e.response.url.endsWith('/claim'))responses.push({requestId:e.requestId,type:e.type,timestamp:e.timestamp,status:e.response.status,timing:e.response.timing,connectionReused:e.response.connectionReused,protocol:e.response.protocol});});
    await page.goto(participant.url+'/incidents/inc-100',{waitUntil:'domcontentloaded'});
    await page.getByRole('heading',{name:'Checkout authorization failures'}).waitFor();
    await page.evaluate(waitForFirstContentfulPaint);await page.waitForLoadState('load');
    await page.locator('.connection').getByText('Live service',{exact:true}).waitFor();
    await page.getByRole('button',{name:'Claim incident'}).click();
    await page.getByText('Version 2',{exact:true}).waitFor();await page.getByText('Alex Chen',{exact:true}).waitFor();
    await page.waitForFunction(()=>globalThis.__frameworkComparisonTiming.phasesMs['http-json-decoded']!==undefined);
    assert.deepEqual(errors,[]);
    if(participant.variant==='early') assert.equal(await page.evaluate(()=>globalThis.__earlyDispatchUsed),true);
    samples.push({round,id:participant.id,variant:participant.variant,timing:await page.evaluate(()=>globalThis.__frameworkComparisonTiming),requests,responses});
   }finally{await context.close();}
  }
  console.log('Round',round+1,'/20');
 }
 await writeFile('.tmp/settlement-phases-2026-09-22/results-early.json',JSON.stringify({diagnostic:'Request is prestarted from a fixture-specific click capture; application fetch reuses exactly that request. Not production code.',network,harness:harness.evidence(),samples},null,2));
}finally{try{await browser?.close();}finally{await harness.close();}}
