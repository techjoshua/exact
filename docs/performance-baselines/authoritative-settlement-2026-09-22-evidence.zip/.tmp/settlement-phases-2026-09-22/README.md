# Authoritative-settlement diagnostics

Source/artifacts unchanged from the published output-policy baseline (source dd3d7e69, publication e579e586). These private diagnostic captures do not replace the public charts. Each variant has 20 samples per framework, fresh contexts, shared native-loopback service, retained click/SSE/DOM/HTTP phase hooks, and alternating participant order. Paired experiments alternate the order of all framework/variant cases.

The traced run adds CDP request/response observations. All 20 claims per framework required preflight; measured preflight and POST wire phases were similar. The untraced repeat retained the historical upstream gap. This does not establish whether tracing or run variation accounts for the difference between those captures.

Early-dispatch is a fixture-specific diagnostic: a capture listener prestarts the exact same claim, and the authored fetch reuses it. It moves network dispatch ahead of application claim work while retaining the original optimistic update. eXact settlement did not improve (12.870 to 12.915 ms).

Network-only deliberately suppresses the authored claim handler, retaining the existing authoritative SSE subscription. It omits optimistic behavior and cannot ship. eXact SSE delivery stayed essentially unchanged (12.030 versus 12.055 ms), while settlement rose from 12.435 to 12.890 ms. Its first attempt timed out because suppressing the handler also removed the JSON consumer awaited by the diagnostic; the corrected probe explicitly consumes the response and completed all samples.

Service instrumentation, browser timelines, input-deferral controls, and shifted trusted-input samples completed. See docs/performance-baselines/authoritative-settlement-2026-09-22.md for the resulting attribution. No production changes accepted. Raw phase differences do not prove that framework rendering causes the upstream interval. Do not change the published protocol or remove optimistic behavior to manufacture a lower settlement score.
