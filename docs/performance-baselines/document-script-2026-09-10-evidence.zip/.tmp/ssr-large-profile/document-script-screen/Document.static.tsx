import { IncidentApp } from './IncidentApp.jsx';
import type { InitialData } from './types.js';

/** Trusted build-generated asset tags used by the application document. */
export type DocumentOptions = { clientTags?: string };

/** Root document shared by server rendering and browser document adoption. */
export function Document(props: DocumentOptions & { initialData?: InitialData; path?: string }) {
	return () => (
		<html lang="en">
			<head>
				<meta charSet="UTF-8" />
				<meta name="viewport" content="width=device-width, initial-scale=1.0" />
				<meta name="framework-participant" content="exact" />
				<title>Incident Operations</title>
				<script type="module" src="/assets/app.js" />
				<script type="module" src="/assets/vendor.js" />
				<link rel="stylesheet" href="/assets/app.css" />
				<link rel="stylesheet" href="/assets/theme.css" />
			</head>
			<body>
				<div id="app" data-render-mode="ssr">
					<IncidentApp initialData={props.initialData} path={props.path} />
				</div>
			</body>
		</html>
	);
}

