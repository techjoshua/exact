from pathlib import Path
import hashlib
import json
import zipfile

root = Path.cwd()
base = root / '.tmp/ssr-large-profile'
target = root / 'docs/performance-baselines/document-script-2026-09-10-evidence.zip'
assert not target.exists(), target
files = set()
for name in ('document-script-screen', 'document-script-integration'):
    files.update(p for p in (base / name).rglob('*') if p.is_file())
for pattern in ('document-script*.mjs', 'document-script*.log'):
    files.update(base.glob(pattern))
files.add(Path(__file__).resolve())
files.add(base / 'literal-url-screen/server-entry.js')
files.add(base / 'flat-invocation-large-worker.mjs')
for name in ('document-script-coalescing-2026-09-10.md', 'document-hydration-ownership-audit-2026-09-10.md'):
    files.add(root / 'docs/performance-baselines' / name)
for name in ('jsx_render_program_script.go', 'jsx_render_program_script_test.go', 'jsx_render_program_lowering.go', 'jsx_render_program_static_attributes.go', 'jsx_render_program_spread_attributes.go',
             'jsx_render_program_static_attributes_test.go', 'jsx_render_program_attributes.go',
             'jsx_render_program_document.go', 'jsx_render_program_ssr_attributes.go'):
    files.add(root / 'native/typescript-go/overlay/internal/exactcompiler' / name)
for name in ('packages/ssr/src/compiled-documents.test.ts',
             'packages/ssr/src/compiled-documents.fixtures.test.tsx',
             'framework-comparison/e2e/controlled-service.spec.ts'):
    files.add(root / name)
manifest = {}
with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(files):
        data = path.read_bytes()
        name = path.relative_to(root).as_posix()
        manifest[name] = hashlib.sha256(data).hexdigest()
        archive.writestr(name, data)
    archive.writestr('SHA256.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    for name, expected in manifest.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == expected
for name, expected in json.loads((base / 'document-script-integration/current-hashes.json').read_text()).items():
    folder = 'dist-bun-server' if name.startswith('bun-') else 'dist-server'
    actual = root / 'framework-comparison/participants/exact' / folder / name
    assert hashlib.sha256(actual.read_bytes()).hexdigest() == expected
assert (root / 'framework-comparison/participants/exact/src/main.tsx').read_bytes() == (base / 'combined-shell/main.original.tsx').read_bytes()
assert (root / 'framework-comparison/participants/exact/src/Document.tsx').read_bytes() == (base / 'document-script-integration/Document.original.tsx').read_bytes()
print(json.dumps({'archive': str(target), 'verifiedFiles': len(manifest), 'restoration': 'verified'}))
