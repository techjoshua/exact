import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const d='.tmp/ssr-large-profile/';
const pairs=[
 ['packages/ssr/src/render/direct-component-support.ts',d+'in-place-server-list-source-before.ts'],
 ['packages/ssr/src/render/direct-component-support.test.ts',d+'in-place-server-list-test-before.ts'],
 ['framework-comparison/participants/exact/dist-server/server-entry.js',d+'in-place-server-list-http-before/dist-server/server-entry.js'],
 ['framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js',d+'in-place-server-list-http-before/dist-bun-server/bun-server-entry.js']
];
const results=pairs.map(([file,before])=>{const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');const currentHash=hash(file);assert.equal(currentHash,hash(before),file);return {file,before,sha256:currentHash};});
fs.writeFileSync(d+'in-place-server-list-restoration.json',JSON.stringify(results,null,2));
console.log('Restored source, tests, Node and Bun artifacts match saved retained hashes.');
