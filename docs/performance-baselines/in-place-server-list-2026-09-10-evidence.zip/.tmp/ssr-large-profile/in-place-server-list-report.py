import json,pathlib,zipfile,hashlib
root=pathlib.Path('.')
d=root/'.tmp/ssr-large-profile'
report=root/'docs/performance-baselines/in-place-server-list-2026-09-10.md'
archive=report.with_name('in-place-server-list-2026-09-10-evidence.zip')
text=['# Private server list snapshot experiment, September 10, 2026','','Status: rejected after isolated renderer, source validation, and paired HTTP measurements. Source, tests, and canonical applications restored to the preceding retained implementation.','','## Hypothesis and implementation','','The direct server map helper snapshots its iterable and then maps that snapshot into a second array. The candidate replaces consumed snapshot entries in place. It preserves completion of iteration before callbacks, render-before-key evaluation, key coercion, list identity, and the existing shared rendering and child-issuance paths. It never writes to the application input array. The expected gain was small (roughly 1-3% on list-heavy documents) through one fewer array construction and mapping closure per list. No heap-volume reduction was measured; source-level construction counts are not allocation-profiler evidence.','','Earlier lazy issuer/preparation-array and conditional result-layout experiments were reviewed and not repeated. Asset parsing was also checked: both applications parse the supplied build tags, so it was not removed from only one participant.','','The bundle prototype changes only directSsrMap. The source implementation uses a private unknown[] snapshot and narrows each unconsumed element to the input type. The completed array contains only keyed children. A regression check mutates the application source array inside a callback and verifies traversal still uses the original snapshot.','','## Validation','','The source candidate passed the SSR TypeScript build, test type checking, targeted ESLint, and all 351 SSR tests in 55 files. Existing list tests cover iterator and callback ordering, keyed markup, and scheduled child cleanup on completion and abort. The added source-mutation test passed. Both canonical runtime applications rebuilt successfully. Browser and ABI acceptance checks were not run for this rejected candidate. No public API or compiler-emitted ABI change was proposed.','','## Focused renderer measurements','','Fresh production processes use 5,000 warmups and two reversed orders per runtime/mode/document combination. The prototype measures 10,000 renders per process (72 processes); the rebuilt source measures 15,000 (72 processes). Both variants match retained eXact complete-document hashes. Encoded mode constructs a Response from the string and consumes its text; streaming mode consumes the full stream. These are renderer/consumer timings, not HTTP rates. All raw populations are preserved. Means below are microseconds per render, lower is better.']
for title,file in [('Bundle prototype','in-place-server-list-results.json'),('Rebuilt source','in-place-server-list-integrated-results.json')]:
 rows=json.loads((d/file).read_text())
 text+=['','### '+title,'','| Runtime | Mode | Document | Retained | Candidate | React |','| --- | --- | --- | ---: | ---: | ---: |']
 for key in dict.fromkeys((r['runtimeId'],r['mode'],r['scenario']) for r in rows):
  means=[]
  for variant in ['current','candidate','react']:
   values=[r['usPerRender'] for r in rows if (r['runtimeId'],r['mode'],r['scenario'])==key and r['variant']==variant]
   assert len(values)==2
   means.append(sum(values)/2)
  text.append('| '+' | '.join(key)+' | '+' | '.join(f'{v:.2f}' for v in means)+' |')
text+=['','## HTTP comparison','','Twenty-four populations use two load-driver processes with 16 concurrent requests each, 2 seconds warmup and 4 seconds measurement, two reversed orders for Node/Bun string/stream. Both frameworks render complete application-owned documents. Each response is checked against its expected full-body identity; retained and candidate eXact markup is compared as well. All measured populations have zero response errors. Means below are valid requests per second, higher is better.','','| Runtime | Mode | Retained | Candidate | React |','| --- | --- | ---: | ---: | ---: |']
rows=json.loads((d/'in-place-server-list-http.json').read_text())
assert len(rows)==24 and all(r['errors']==0 for r in rows)
for key in dict.fromkeys((r['runtime'],r['mode']) for r in rows):
 means=[]
 for variant in ['baseline','candidate','react']:
  vals=[r['rps'] for r in rows if (r['runtime'],r['mode'])==key and r['variant']==variant]
  assert len(vals)==2
  means.append(sum(vals)/2)
 text.append('| '+' | '.join(key)+' | '+' | '.join(f'{v:.1f}' for v in means)+' |')
text+=['','The initial string improvements did not repeat consistently in the rebuilt renderer. Node string HTTP throughput fell in both orders. The mixed outcomes do not justify replacing the existing implementation: reducing one private array construction did not establish an end-to-end improvement. The retained build remains the proven-reference implementation, and React parity across all workloads remains unresolved.','','All task-owned benchmark processes were closed. The initial incremental restore retained stale emitted list code because copying back the source preserved its older timestamp. Hash verification caught this. A forced TypeScript rebuild followed by rebuilding both canonical applications restored byte-identical Node and Bun artifacts, and source/test hashes also match the saved retained files. The candidate source and tests remain only in the evidence archive.']
files=[]
for p in d.glob('in-place-server-list*'):
 files.extend([p] if p.is_file() else [f for f in p.rglob('*') if f.is_file()])
files += [d/'proven-reference-integrated/server-entry.js',d/'final-rope-worker.mjs',root/'.tmp/positional-leaves/data.json',root/'framework-comparison/participants/react/dist-server/server-entry.js',root/'framework-comparison/participants/react/dist-bun-server/bun-server-entry.js']
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for file in dict.fromkeys(files): z.write(file,file.as_posix())
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
text+=['',f'Evidence: `{archive.name}`, SHA-256 `{sha}`. Includes patch/build/run scripts, source before and candidate copies, fixtures, frozen artifacts, raw measurements, validation and restoration logs.','']
report.write_text('\n'.join(text),encoding='utf-8')
print(report)
print(sha)
print('\n'.join(text[-13:]))

