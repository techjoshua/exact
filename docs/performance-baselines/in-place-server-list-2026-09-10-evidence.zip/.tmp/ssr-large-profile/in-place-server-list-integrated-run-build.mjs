import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
const runner=fs.readFileSync(d+'in-place-server-list-run.mjs','utf8').replaceAll('in-place-server-list/server-entry.js','in-place-server-list-integrated/server-entry.js').replaceAll('in-place-server-list-results.json','in-place-server-list-integrated-results.json').replace("'10000'","'15000'");
fs.writeFileSync(d+'in-place-server-list-integrated-run.mjs',runner);
