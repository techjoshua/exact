import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const d='.tmp/ssr-large-profile/';
const input=d+'proven-reference-integrated/server-entry.js';
let source=fs.readFileSync(input,'utf8');
const before='return createServerList([...unwrap(collection)].map((item) => createPreparedServerKeyedChild(render(item), key(item))), id);';
const after=`const children = [...unwrap(collection)];
 for (let index = 0; index < children.length; index++) {
  const item = children[index];
  children[index] = createPreparedServerKeyedChild(render(item), key(item));
 }
 return createServerList(children, id);`;
assert.equal(source.split(before).length,2);
source=source.replace(before,after);
fs.mkdirSync(d+'in-place-server-list',{recursive:true});
fs.writeFileSync(d+'in-place-server-list/server-entry.js',source);
fs.writeFileSync(d+'in-place-server-list/provenance.json',JSON.stringify({input,sha256:createHash('sha256').update(fs.readFileSync(input)).digest('hex'),before,after},null,2));
let runner=fs.readFileSync(d+'complete-proof-run.mjs','utf8').replaceAll('complete-proof/server-entry.js','in-place-server-list/server-entry.js').replaceAll('complete-proof-results.json','in-place-server-list-results.json');
fs.writeFileSync(d+'in-place-server-list-run.mjs',runner);
