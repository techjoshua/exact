import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
for(const [name,args] of [
 ['typecheck',['run','typecheck:tests']],
 ['tests',['exec','--','vitest','run','--config','vitest.packages.config.ts','packages/ssr','--testTimeout=30000']],
 ['lint',['exec','--','eslint','packages/ssr/src/render/direct-component-support.ts','packages/ssr/src/render/direct-component-support.test.ts']]
]){
 const r=spawnSync('npm.cmd',args,{shell:true,windowsHide:true,encoding:'utf8',env:process.env,maxBuffer:32*1024*1024});
 fs.writeFileSync(d+'in-place-server-list-'+name+'.log',(r.stdout??'')+'\n'+(r.stderr??''));
 console.log(name,r.status); if(r.status!==0)process.exit(r.status??1);
}
