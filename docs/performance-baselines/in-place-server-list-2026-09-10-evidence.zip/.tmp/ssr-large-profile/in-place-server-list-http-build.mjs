import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
fs.writeFileSync(d+'in-place-server-list-http.mjs',fs.readFileSync(d+'proven-reference-http.mjs','utf8').replaceAll('proven-reference-http-before','in-place-server-list-http-before'));
