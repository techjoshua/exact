import json
from pathlib import Path
from statistics import mean

folder=Path('.tmp/ssr-large-profile/http-inlining')
data=json.loads((folder/'capture.json').read_text())
rows=[]
def timing(audit,key):
    s=audit[key];return s['sumMs']/s['count']*1000
for b in data['blocks']:
    isolated=mean(timing(b[k]['audit'],'renderInvocation') for k in ('loopBefore','loopAfter'))
    http=timing(b['after']['audit'],'renderInvocation')
    rows.append(dict(framework=b['id'],population=b['population']+1,inlining=b['inlining'],rps=b['rps'],
                     isolatedInvocationUs=isolated,httpInvocationUs=http,gapUs=http-isolated,httpLoopRatio=http/isolated,
                     isolatedAfterReturnUs=mean(timing(b[k]['audit'],'renderAfterReturn') for k in ('loopBefore','loopAfter')),
                     httpAfterReturnUs=timing(b['after']['audit'],'renderAfterReturn')))
print(json.dumps(dict(complete=data['complete'],rows=rows),indent=2))
if data['complete']:
    assert len(rows)==8
    valid=sum(b['valid'] for b in data['blocks'])
    errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages'])
    assert errors==0
    (folder/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid,errors=errors),indent=2))
    print('VALID',valid)
