import hashlib
import json
import zipfile
from pathlib import Path
from statistics import mean

base=Path('.tmp/ssr-large-profile');folder=base/'http-inlining'
capture=json.loads((folder/'capture.json').read_text());assert capture['complete']
summary=json.loads((folder/'summary.json').read_text());assert summary['errors']==0
report=Path('docs/performance-baselines/http-inlining-2026-09-10.md')
lines=['# JavaScript inlining and the HTTP rendering gap, 2026-09-10','','## Hypothesis','',
'Isolated rendering and HTTP execute under different callers. Different inlining',
'could change their cost even without a measured-phase deoptimization. Compare',
'default V8 with JavaScript inlining disabled for both eXact and React, inspecting',
'the HTTP-to-isolated invocation ratio rather than expecting disabling it to help.', '',
'## Method','',
'The installed Node 26.8.1 lists --turbo-inlining and --maglev-inlining as enabled',
'by default. Diagnostic workers receive --no-turbo-inlining and',
'--no-maglev-inlining together. The worker reports process.execArgv and the runner',
'asserts both flags. Load drivers and the controlled service keep normal settings.',
'These are diagnostic flags, not production recommendations or a claim to disable',
'all native/builtin optimization.', '',
'Eight fresh workers cover both frameworks/settings twice, reversing framework',
'and setting order in the second population. Each warms HTTP for ten seconds,',
'then measures a five-second window with two fresh drivers at concurrency 16',
'each. Isolated loops before/after HTTP warm and measure 10,000 renders each.',
'Each worker compares its own isolated and HTTP invocation intervals. Cross-worker',
'RPS comparisons remain subject to workstation and worker variation.', '',
'The render timer splits synchronous function invocation from time after return',
'until awaited settlement. Tables below use synchronous invocation, avoiding',
'confusion with queueing after a render returns its promise. These are elapsed',
'intervals, not exclusive CPU samples. The same production artifacts, full',
'application documents and original response adapters are retained.', '',
'## Results','',
'Arithmetic means across the two workers per framework/setting:', '',
'| Framework | Inlining | RPS | Isolated invocation us | HTTP invocation us | HTTP/isolated |',
'| --- | --- | ---: | ---: | ---: | ---: |']
for framework in ('exact','react'):
    for setting in ('default','disabled'):
        rows=[r for r in summary['rows'] if r['framework']==framework and r['inlining']==setting]
        values={k:mean(r[k] for r in rows) for k in ('rps','isolatedInvocationUs','httpInvocationUs','httpLoopRatio')}
        lines.append(f"| {framework} | {setting} | {values['rps']:,.0f} | {values['isolatedInvocationUs']:.2f} | {values['httpInvocationUs']:.2f} | {values['httpLoopRatio']:.2f}x |")
lines+=['','Individual invocation ratios:', '',
'| Framework | Worker | Default | Disabled |','| --- | ---: | ---: | ---: |']
for framework in ('exact','react'):
    for population in (1,2):
        rows={r['inlining']:r for r in summary['rows'] if r['framework']==framework and r['population']==population}
        lines.append(f"| {framework} | {population} | {rows['default']['httpLoopRatio']:.3f} | {rows['disabled']['httpLoopRatio']:.3f} |")
lines+=['',f"All {summary['valid']:,} measured responses are valid, zero errors, excluding",
'warmups and preflights. The complete eXact document is 4,672 bytes and React is',
'3,660 bytes. Identity hashes match within each framework; flags change neither',
'document. Source artifacts and server/adapter inventories are checked before',
'and after. Owned worker/load processes close. No production source changes.', '',
'## Interpretation','',
'Disabling inlining slows both workloads. It does not remove eXact\'s larger',
'HTTP-to-isolated ratio; that result repeats in both populations. This does not',
'prove identical inlining or rule out all JIT effects, but the proposed explanation',
'does not account for the dominant gap under this control. Do not tune production',
'inlining flags based on these numbers.', '',
'The dominant HTTP slowdown remains unresolved. Prior microtask deferral did not',
'restore isolated speed; a distinct future control could move invocation out of',
'the socket-read callback through an event-loop turn, while measuring queueing',
'separately and retaining both frameworks. That is a hypothesis, not a diagnosed',
'cause or an implemented optimization. Stop removing objects solely on allocation',
'counts, since the combined-output experiments reduced allocation and ran slower.', '',
'The adjacent archive includes scripts, worker, raw data, current participant',
'artifacts, summaries and verified SHA-256 inventory. Workspace dependencies are',
'not packaged as a standalone distribution.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[report]+[base/n for n in ('http-inlining-build.mjs','http-inlining-run.mjs','http-inlining-analyze.py','http-inlining-report.py','http-invocation-trace-run.mjs','http-invocation-trace/worker.mjs','component-forwarding-integrated/server-entry.js')]+[Path('framework-comparison/participants/react/dist-server/server-entry.js')]
files=sorted(set(f for f in files if f.is_file()));archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={f.as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in files:z.write(f,f.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(report,len(files),'verified files')
