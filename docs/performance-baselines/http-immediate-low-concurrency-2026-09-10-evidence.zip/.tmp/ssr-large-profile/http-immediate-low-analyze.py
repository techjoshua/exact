import hashlib
import json
import zipfile
from pathlib import Path
from statistics import mean

base = Path('.tmp/ssr-large-profile')
folder = base / 'http-immediate-low'
data = json.loads((folder / 'capture.json').read_text())
assert data['complete'] and len(data['blocks']) == 24

def latency(block, key):
    values = [r['stages'][0]['distributions'][key] for r in block['results']]
    assert len(values) == 1
    return values[0]

rows = []
for population in (0, 1):
    for framework in ('exact', 'react'):
        for concurrency in (1, 4):
            blocks = [b for b in data['blocks'] if b['population'] == population and b['id'] == framework and b['concurrency'] == concurrency]
            assert [b['phase'] for b in blocks] == ['normal', 'immediate', 'normal']
            controls = [blocks[0], blocks[2]]
            candidate = blocks[1]
            assert candidate['after']['audit']['renderQueue']['count'] == candidate['after']['audit']['renderInvocation']['count']
            assert all('renderQueue' not in b['after']['audit'] for b in controls)
            normal = mean(b['rps'] for b in controls)
            row = dict(framework=framework, population=population+1, concurrency=concurrency, normalRps=normal, deferredRps=candidate['rps'], gainPct=(candidate['rps']/normal-1)*100)
            for key in ('responseMs', 'ttfbMs'):
                row[key] = dict(normal={k: mean(latency(b, key)[k] for b in controls) for k in ('mean', 'p50', 'p95', 'p99')}, deferred={k: latency(candidate, key)[k] for k in ('mean', 'p50', 'p95', 'p99')})
            rows.append(row)
errors = sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages'])
assert errors == 0
valid = sum(b['valid'] for b in data['blocks'])
summary = dict(rows=rows, valid=valid, errors=errors)
(folder / 'summary.json').write_text(json.dumps(summary, indent=2))
report = Path('docs/performance-baselines/http-immediate-low-concurrency-2026-09-10.md')
assert not report.exists()
lines = ['# Low-concurrency rendering deferral, 2026-09-10', '',
'Follow-up to the concurrency-32 setImmediate experiment. Hypothesis: moving rendering to a later event-loop phase may improve batching under load but add latency when requests arrive individually. This diagnostic tests whether the earlier throughput gain justifies unconditional scheduling.', '',
'Production Node 26.8.1, unchanged full-document participants and adapters. Four fresh workers run eXact/React/React/eXact, with one load driver and concurrency one or four. Each worker warms HTTP for ten seconds and runs normal/deferred/normal three-second blocks at each concurrency. The second population reverses concurrency order. Controls are averaged within each worker. Workstation load may vary. Queue delay is included in response latency. This is a worker-only string-rendering experiment, not a production implementation.', '',
'| Framework | Worker | Concurrency | Normal RPS | Deferred RPS | Change | Response mean ms, normal / deferred |',
'| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for r in rows:
    lines.append(f"| {r['framework']} | {r['population']} | {r['concurrency']} | {r['normalRps']:,.0f} | {r['deferredRps']:,.0f} | {r['gainPct']:+.2f}% | {r['responseMs']['normal']['mean']:.3f} / {r['responseMs']['deferred']['mean']:.3f} |")
lines += ['', '| Framework | Worker | Concurrency | TTFB mean ms, normal / deferred | TTFB p95 ms, normal / deferred |', '| --- | ---: | ---: | ---: | ---: |']
for r in rows:
    t = r['ttfbMs']
    lines.append(f"| {r['framework']} | {r['population']} | {r['concurrency']} | {t['normal']['mean']:.3f} / {t['deferred']['mean']:.3f} | {t['normal']['p95']:.3f} / {t['deferred']['p95']:.3f} |")
lines += ['', 'Control quantiles above are averages of the two adjacent block quantiles, not quantiles of a pooled distribution.', '',
f'All {valid:,} measured responses passed complete-document validation, with zero errors. Artifact and adapter hash guards passed. No production code changed.', '',
'The concurrency-one result does not reproduce the large gain at concurrency 32, and one eXact repetition regresses. The evidence does not justify an unconditional yield before every render. Scheduling remains a load-dependent experimental direction. Its benefit in both frameworks does not explain the remaining relative gap.', '',
'A production experiment must use an actual framework-owned dispatch boundary, preserve immediate request-body consumption and synchronous response-body claiming, and separately validate streaming head delivery and browser latency. Delaying before claiming an already-created response body can change ownership semantics. These results do not authorize that change.', '',
'The adjacent evidence archive includes raw results, scripts and a verified SHA-256 inventory. This is a focused diagnostic, not a new full benchmark baseline.', '']
report.write_text('\n'.join(lines), encoding='utf8')
files = [p for p in folder.glob('*') if p.is_file()] + [report, base/'http-immediate-low-build.mjs', base/'http-immediate-low-run.mjs', Path(__file__), base/'http-immediate/worker.mjs', base/'component-forwarding-integrated/server-entry.js', Path('framework-comparison/participants/react/dist-server/server-entry.js')]
files = sorted(set(p.resolve().relative_to(Path.cwd().resolve()) for p in files))
archive = report.with_name(report.stem+'-evidence.zip')
assert not archive.exists()
manifest = {p.as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in files:
        z.write(p, p.as_posix())
    z.writestr('SHA256.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, digest in manifest.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == digest
print(report.read_text())
print(len(files), 'verified files')
