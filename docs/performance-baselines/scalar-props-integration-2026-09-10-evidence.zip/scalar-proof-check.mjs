import fs from 'node:fs';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const d='.tmp/ssr-large-profile/';
const source=fs.readFileSync(d+'scalar-reference-proof/server-entry.js','utf8');
fs.writeFileSync(d+'scalar-reference-proof/check-entry.js',source+'\nexport { referenceKnownScalarProps as proofProbe };\n');
const {proofProbe}=await import(pathToFileURL(resolve(d+'scalar-reference-proof/check-entry.js')));
const operations={reference:(_component,props)=>({props})};
for(const value of [null,undefined,'critical',0,false]){
 const props={severity:value};assert.equal(proofProbe(operations,null,props).scalarPropsProof,props);
}
for(const value of [{},()=>{},Promise.resolve('critical')]){
 const props={severity:value};assert.equal(proofProbe(operations,null,props).scalarPropsProof,undefined);
}
console.log('Eight scalar/object/function/promise proof-selection checks passed.');
