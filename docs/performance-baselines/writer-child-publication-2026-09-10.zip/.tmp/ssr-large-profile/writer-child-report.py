import pathlib,json,hashlib,zipfile
root=pathlib.Path.cwd();d=root/'.tmp/ssr-large-profile'
rows=json.loads((d/'writer-child-results.json').read_text());assert len(rows)==32
lines=['# Shared writer child publication, 2026-09-10','',
'The staged caller-output writer now has direct child/component publication through writeProgramChild. It checks delimiter budgets before child execution, preserves marked and marker-free output, flushes before pending child work, and retains prepared-sibling ownership through flush failure. Current marker rendering reuses the same writeProgramBoundary implementation. Components remain independent of sink type.', '',
'This is migration work, not the completed compiler cutover. writeProgramChild is covered by focused tests but not yet selected by generated production writers. The current production change is the shared marker-boundary implementation. The timing check below guards that refactor; it does not measure removal of segment arrays.', '',
'Production Node 26.8.1 and Bun 1.4.2. Each cell averages two fresh processes in reversed order, with 5,000 warmups and 12,000 measured complete app-owned document renders per process. Streams are fully consumed. These are in-process timings, not HTTP throughput. Small documents contain three incidents, large documents 96, and both include four asset tags. Complete document hashes match the saved += control. React was not rerun for this refactor guard.', '',
'| Runtime | Mode | Document | Previous (µs) | Shared publication (µs) |',
'| --- | --- | --- | ---: | ---: |']
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['assets','large']:
   means=[sum(r['usPerRender'] for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['variant']==v)/2 for v in ['previous','shared']]
   lines.append(f'| {runtime} | {mode} | {scenario} | '+' | '.join(f'{x:.2f}' for x in means)+' |')
lines += ['', 'Small differences on the shared workstation do not establish a repeatable gain. The shared implementation is retained to keep boundary semantics consistent during compiler integration.', '',
'Validation: all 331 SSR tests passed, including marker pressure/failure tests and four new cases covering shared/local children with all marker combinations, delimiter-budget rejection before child execution, and prepared-sibling disposal only after pending child settlement when flushing fails. Package build, repository test typecheck, focused ESLint, source architecture, platform boundaries, and package contents passed.', '',
'The scheduling review confirmed that references issued later inside the generated writer must explicitly participate in sibling preparation; the outer component render issuer does not observe that later work. Full integration still requires core writer/operation types, native emitter selection, direct operation helpers, both runtime entry points, compiled fixture validation, and initial ABI documentation. No browser/HTTP benchmark was run for this guard. React parity remains unfinished.']
report=root/'docs/performance-baselines/writer-child-publication-2026-09-10.md';report.write_text('\n'.join(lines)+'\n',encoding='utf8')
files=[d/n for n in ['writer-child-run.mjs','writer-child-results.json','writer-child-report.py','production-refresh-worker.mjs']]+[root/r['entry'] for r in rows]
files += [root/'packages/ssr/src'/n for n in ['markers.ts','render/program-boundary.ts','render/program-boundary.test.ts','render/program-writer-output.ts','render/program-writer-output.test.ts']]
with zipfile.ZipFile(report.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 hashes={}
 for p in dict.fromkeys(files):
  content=p.read_bytes();name=p.relative_to(root).as_posix();hashes[name]=hashlib.sha256(content).hexdigest();z.writestr(name,content)
 z.writestr('sha256.json',json.dumps(hashes,indent=2))
print('\n'.join(lines[8:16]))
