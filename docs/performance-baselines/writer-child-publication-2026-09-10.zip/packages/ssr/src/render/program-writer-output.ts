import type { SsrContext } from '../types.js';
import { mapRenderValue, withRenderCleanup, type RenderValue } from './execution.js';
import { claimRootText, enterHostTag, leaveHost } from './host.js';
import { appendBoundedHtml } from './limits.js';
import { captureNestedEnhancementStringPrefix } from './operation-enhancement-routes.js';
import type { SsrProgramSink } from './program-sink.js';

/** Caller-owned output and preparation lifetime consumed by a generated continuation writer. */
export interface SsrProgramWriterOutput<T> {
	/** Destination shared by all completed spans in this program. */
	readonly sink: SsrProgramSink;
	/** Renders one prepared child or component through the existing recursive renderer. */
	readonly render: (value: T) => RenderValue<string>;
	/** Starts scheduled sibling work before serial traversal reaches its positions. */
	readonly prepareReferences?: (values: readonly T[]) => AsyncDisposable | undefined;
	/** Sibling frames not consumed during traversal remain owned until this program settles. */
	preparation?: AsyncDisposable;
}

/**
 * Executes a caller-output writer within document ancestry and prepared-sibling ownership.
 * Shared destinations remain request-owned. Captured programs retain local text through the
 * same writer operations, without exposing output before enhancement or retry boundaries commit.
 */
export function renderProgramWriter<T>(
	context: SsrContext,
	host: string | undefined,
	invoke: (output: SsrProgramWriterOutput<T>) => RenderValue<SsrProgramWriterOutput<T> | undefined>,
	render: (value: T) => RenderValue<string>,
	prepareReferences?: (values: readonly T[]) => AsyncDisposable | undefined
): RenderValue<string> {
	const local = context.writerSink ? undefined : new CapturedProgramSink(context);
	const output: SsrProgramWriterOutput<T> = {
		sink: context.writerSink ?? local!,
		render,
		prepareReferences
	};
	const execute = () =>
		withRenderCleanup(
			() =>
				mapRenderValue(invoke(output), (completed) => {
					if (completed !== output)
						throw new TypeError('Native server writer rejected its caller-owned output');
					return local?.value ?? '';
				}),
			() =>
				output.preparation ? Promise.resolve(output.preparation[Symbol.asyncDispose]()) : undefined
		);
	if (
		host &&
		(host === 'html' ||
			host === 'head' ||
			host === 'body' ||
			(context.documentRootSeen && context.hostStack.at(-1) === 'html'))
	) {
		const entered = enterHostTag(context, host);
		return withRenderCleanup(
			() => {
				if (entered.prefix) output.sink.write(entered.prefix);
				return mapRenderValue(output.sink.ready(), () =>
					mapRenderValue(execute(), (html) =>
						mapRenderValue(host === 'head' ? output.sink.flush('head') : undefined, () => html)
					)
				);
			},
			() => leaveHost(context, entered.tag)
		);
	}
	if (host && !context.hostStack.length) claimRootText(context);
	return execute();
}

/** Local capture owns text only; the enclosing request retains exact byte validation. */
class CapturedProgramSink implements SsrProgramSink {
	value = '';
	constructor(private readonly context: SsrContext) {}
	/** Retains routed prefixes before appending the next completed span. */
	write(html: string): void {
		this.value = appendBoundedHtml(
			this.context,
			captureNestedEnhancementStringPrefix(this.context, this.value),
			html
		);
	}
	/** Local text collection introduces no transport pressure. */
	ready(): void {}
	/** Captured markup stays private until its owning boundary commits. */
	flush(): void {}
}
