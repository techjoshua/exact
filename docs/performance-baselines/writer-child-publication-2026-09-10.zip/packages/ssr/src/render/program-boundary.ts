import type { SsrContext } from '../types.js';
import { mapRenderValue, type RenderValue } from './execution.js';
import { SsrOutputLimitError } from './limits.js';
import { awaitSsrProgramSink, type SsrProgramSink } from './program-sink.js';
import type { SsrProgramWriterOutput } from './program-writer-output.js';

/**
 * Publishes an ordered boundary through a shared sink. Opening pressure precedes child work;
 * child rejection never emits the closing span. Pending descendants settle before flush failure
 * unwinds their owner's scope. Completion includes the closing span's drain.
 */
export function writeProgramBoundary(
	context: SsrContext,
	sink: SsrProgramSink,
	opening: string,
	closing: string,
	render: () => RenderValue<string>
): RenderValue<string> {
	if (opening) {
		context.outputSink?.accountKnown(opening, opening.length);
		sink.write(opening);
	}
	return mapRenderValue(sink.ready(), () => {
		const rendered = render();
		return mapRenderValue(
			rendered instanceof Promise ? awaitSsrProgramSink(sink, rendered) : rendered,
			(html) => {
				if (html) sink.write(html);
				return mapRenderValue(sink.ready(), () => {
					if (closing) {
						context.outputSink?.accountKnown(closing, closing.length);
						sink.write(closing);
					}
					return mapRenderValue(sink.ready(), () => '');
				});
			}
		);
	});
}

/** Publishes a generated child/component position without collecting a deferred segment array. */
export function writeProgramChild<T>(
	context: SsrContext,
	output: SsrProgramWriterOutput<T>,
	value: T,
	id: string,
	characters: number,
	markerless = false
): RenderValue<number> {
	const marked = context.markers && !markerless;
	const opening = marked ? `<!--x:${id}-->` : '';
	const closing = marked ? `<!--/x:${id}-->` : '';
	const nextCharacters = characters + opening.length + closing.length;
	if (nextCharacters > context.maxOutputBytes)
		throw new SsrOutputLimitError(context.maxOutputBytes);
	return mapRenderValue(
		writeProgramBoundary(context, output.sink, opening, closing, () => output.render(value)),
		() => nextCharacters
	);
}
