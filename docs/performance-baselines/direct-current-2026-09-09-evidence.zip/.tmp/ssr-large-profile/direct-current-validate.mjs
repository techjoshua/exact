import {readFileSync,writeFileSync,copyFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const root='.tmp/ssr-large-profile/',dir=root+'direct-current/';
for(const name of ['direct-writer-real-siblings-build','direct-writer-real-siblings-audit'])writeFileSync(dir+name+'.mjs',readFileSync(root+name+'.mjs','utf8').replaceAll(root,dir));
for(const [runtime,name] of [[process.execPath,'direct-writer-real-siblings-build'],['node','direct-writer-real-siblings-audit'],['bun','direct-writer-real-siblings-audit']]){
 const run=spawnSync(runtime,[dir+name+'.mjs'],{encoding:'utf8',windowsHide:true});
 if(run.status!==0)throw Error(run.stderr+run.stdout);
 console.log(run.stdout);
}
copyFileSync(root+'direct-map-worker.mjs',dir+'direct-map-worker.mjs');
let runner=readFileSync(root+'unowned-program-run.mjs','utf8').replaceAll(root,dir).replaceAll('unowned-program-current','direct-writer-siblings').replaceAll('text-surroundings-current','current-production');
writeFileSync(dir+'run.mjs',runner);
