import pathlib,json,hashlib,zipfile
root=pathlib.Path('.tmp/ssr-large-profile');d=root/'direct-current'
rows=json.loads((d/'direct-writer-siblings-results.json').read_text(encoding='utf-8'))
assert len(rows)==32
report='''# Direct writer rebased on retained production improvements

Date: 2026-09-09. Experimental bundle; not adopted.

The direct writer is rebuilt from the actual current participant entry rather than patching the
older prototype with selected module replacements. Its control SHA-256 is
`fe5c90d02d7b6e9a2c26a0e7fce5be8c0347ebfc6f2fa9650ffccf16d3eb591a`.
The reproducible transformation chain retains current compiler text-surroundings emission and
current runtime modules, then replaces the buffered traversal with the experimental continuation
writer and sibling preparation scope. Twenty-five generated writers include 11 continuation
programs and 18 child sites. Four programs prepare five known direct-component references.

The hypothesis is that removing intermediate traversal stages could help total rendering time.
This rebase tests whether that remains true after the retained compiler/runtime improvements.
Thirty-two production processes cover Node/Bun, string/consumed stream, three/96 incidents with
four assets, and two reversed-order pairs per cell. Each uses 5,000 warmups and 12,000 measured
renders. All paired complete-document hashes match; no completed sample was discarded.
Positive percentages mean slower rendering. These are local renderer timings, not HTTP rates.

| Runtime | Mode | Fixture | Pair 1 time change | Pair 2 time change |
| --- | --- | --- | ---: | ---: |
'''
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['small','large']:
   changes=[]
   for round in range(2):
    pair=[r for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['round']==round]
    assert len(pair)==2 and pair[0]['hash']==pair[1]['hash']
    old=next(r for r in pair if r['variant']=='current-production')
    new=next(r for r in pair if r['variant']=='direct-writer-siblings')
    changes.append((new['usPerRender']/old['usPerRender']-1)*100)
   report+=f'| {runtime} | {mode} | {scenario} | {changes[0]:+.2f}% | {changes[1]:+.2f}% |\n'
report+='''
The current prototype is not a throughput improvement. Its direct traversal has extra output
context and cleanup machinery, so eliminating segments alone is insufficient. In particular,
the experimental execution wrapper unconditionally creates cleanup callbacks even for programs
that acquire no sibling resources. The retained production scope-elision optimization is present
in the input but superseded by this experimental execution implementation. A next isolated
experiment should retain that ownership optimization in the new writer. It must prove preparation
is acquired synchronously before the first suspension before omitting a pending cleanup wrapper.

The rebased candidate passes six real scheduled-child cases: success, failure before the second
child is visited, and abort while the task gate remains closed, on Node and Bun. Both children
start before the gate opens and each is disposed once. These use compiler-generated child tasks
and a hand-built parent writer, as detailed in the real-siblings report. This is not full compiler
integration or browser validation.

The prototype still needs general component preparation, enhancement and boundary captures,
selective waiting, early head flushing, and transport backpressure. It uses string accumulation
on both runtimes in this comparison; the earlier Bun batching variant is not included. No public
or production source changed. React was not rerun, and the overall goal remains unmet.

The archive preserves the full transformation chain, frozen artifacts, raw measurements, task
fixture and results, fixed benchmark input, and a verified SHA-256 manifest.
'''
target=pathlib.Path('docs/performance-baselines/direct-current-2026-09-09')
target.with_suffix('.md').write_text(report,encoding='utf-8')
files=list(d.glob('*'))+[root/'direct-current-build.mjs',root/'direct-current-validate.mjs',root/'direct-current-report.py',pathlib.Path('.tmp/positional-leaves/data.json'),target.with_suffix('.md')]
files=[p for p in files if p.is_file()]
manifest={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=pathlib.Path(str(target)+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p).replace('\\','/'))
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(report)
