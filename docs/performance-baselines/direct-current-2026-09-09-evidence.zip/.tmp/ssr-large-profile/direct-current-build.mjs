import {readFileSync,writeFileSync,mkdirSync,copyFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/',dir=root+'direct-current/';
mkdirSync(dir,{recursive:true});
const entry='framework-comparison/participants/exact/dist-server/server-entry.js';
copyFileSync(entry,dir+'current-production.mjs');
copyFileSync(root+'map-fragment-run.mjs',dir+'map-fragment-run.mjs');
const stages=['shared-accumulator-build','shared-accumulator-direct-build','shared-accumulator-ranges-build','direct-writer-build','direct-writer-continuation-build'];
for(const stage of stages){
 let code=readFileSync(root+stage+'.mjs','utf8').replaceAll(root,dir);
 if(stage==='shared-accumulator-build')code=code.replace('marker-hex-current.mjs','current-production.mjs');
 writeFileSync(dir+stage+'.mjs',code);
 const run=spawnSync(process.execPath,[dir+stage+'.mjs'],{encoding:'utf8',windowsHide:true});
 if(run.status!==0)throw Error(stage+': '+run.stderr+run.stdout);
}
let sibling=readFileSync(root+'direct-writer-siblings-build.mjs','utf8').replaceAll(root,dir).replace('direct-writer-current-node.mjs','direct-writer-continuation.mjs');
writeFileSync(dir+'direct-writer-siblings-build.mjs',sibling);
const run=spawnSync(process.execPath,[dir+'direct-writer-siblings-build.mjs'],{encoding:'utf8',windowsHide:true});
if(run.status!==0)throw Error(run.stderr+run.stdout);
writeFileSync(dir+'build.json',JSON.stringify({entry,sha256:createHash('sha256').update(readFileSync(entry)).digest('hex'),stages:[...stages,'direct-writer-siblings-build']},null,2));
console.log(run.stdout);
