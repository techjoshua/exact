import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/direct-current/';
let source=readFileSync(dir+'direct-writer-continuation.mjs','utf8');
let programs=0,references=0;
source=source.replace(/ssr: function\(__exactSsr, __exactContext, __exactInvocation, __exactOutput\) \{([\s\S]*?)\n\t\}/g,(_,body)=>{
 const declarations=[],values=[];
 body=body.replace(/__exactSsr.directComponent\(__exactContext, __exactOutput, (\w+), (__exactValue_\d+),/g,(_,component,props)=>{
  const name='__exactPreparedSibling_'+values.length;
  declarations.push(`const ${name}=createPreparedServerComponentReference(${component},${props});`);
  values.push(name);references++;
  return `__exactSsr.component(__exactContext, __exactOutput, ${name},`;
 });
 if(values.length){
  const index=body.indexOf('__exactSsr.begin(');
  if(index<0)throw Error('Missing validation boundary');
  body=body.slice(0,index)+declarations.join('\n')+`\nif(__exactOutput.prepareReferences)__exactOutput.preparation=__exactOutput.prepareReferences([${values.join(',')}]);\n`+body.slice(index);
  programs++;
 }
 return 'ssr: function(__exactSsr, __exactContext, __exactInvocation, __exactOutput) {'+body+'\n\t}';
});
if(programs!==4||references!==5)throw Error('Unexpected direct sibling sites '+JSON.stringify({programs,references}));
const start=source.indexOf('\trenderPreparedServerProgram(program) {');
const end=source.indexOf('\n\t/** Serializes one direct server reference',start);
if(start<0||end<0)throw Error('Missing target');
source=source.slice(0,start)+`\trenderPreparedServerProgram(program) {
 return renderDirectWriter(this.context,program,(segment)=>this.renderProgramSegment(segment),
  references=>prepareDirectScheduledSsrComponentReferences(this.context,references,this.parent,this.options));
 }
`+source.slice(end);
source=source.replace('function renderDirectWriter(context,invocation,render){','function renderDirectWriter(context,invocation,render,prepareReferences){');
const object='const output={context,sink:shared??{value:\'\'},render,shared:!!shared};';
if(!source.includes(object))throw Error('Missing output context');
source=source.replace(object,object+'\n output.prepareReferences=prepareReferences;');
source=source.replace('function executeDirectWriter(invocation,output){',`function executeDirectWriter(invocation,output){
 return withRenderCleanup(()=>executePreparedDirectWriter(invocation,output),()=>output.preparation?.[Symbol.asyncDispose]());
}
function executePreparedDirectWriter(invocation,output){`);
writeFileSync(dir+'direct-writer-siblings.mjs',source);
writeFileSync(dir+'direct-writer-siblings-build.json',JSON.stringify({programs,references},null,2));
console.log({programs,references});
