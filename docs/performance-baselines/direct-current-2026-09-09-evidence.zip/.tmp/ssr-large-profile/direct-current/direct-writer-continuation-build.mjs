import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/direct-current/';
let source=readFileSync(dir+'direct-writer.mjs','utf8');
let programs=0,sites=0;
function lowerContinuations(body){
 const match=/([ \t]*)(__exactCharacters = )?yield ([^\n]+);/.exec(body);
 if(!match)return body;
 const id=sites++;
 const next='__exactContinue_'+id,pending='__exactPending_'+id;
 return body.slice(0,match.index)+`
 const ${pending}=${match[3]};
 if(${pending} instanceof Promise)return ${pending}.then(${next});
 return ${next}(${pending});
 function ${next}(__exactSettled){
 ${match[2]?'__exactCharacters=__exactSettled;':''}
 ${lowerContinuations(body.slice(match.index+match[0].length))}
 }
 `;
}
source=source.replace(/ssr: function\*\(__exactSsr, __exactContext, __exactInvocation, __exactOutput\) \{([\s\S]*?return __exactOutput;)\n\t\}/g,(_,body)=>{
 programs++;
 return 'ssr: function(__exactSsr, __exactContext, __exactInvocation, __exactOutput) {'+lowerContinuations(body)+'\n\t}';
});
if(programs!==11||sites!==18)throw Error('Unexpected compiler continuation count');
const before="if(typeof result.next==='function')return resumeDirectWriter(result,output,undefined);";
if(source.split(before).length!==2)throw Error('Missing generator driver');
source=source.replace(before,`if(result instanceof Promise)return result.then(value=>{
 if(value!==output)throw Error('Generated direct writer rejected its input');
 return output.shared?'':output.sink.value;
 });`);
writeFileSync(dir+'direct-writer-continuation.mjs',source);
writeFileSync(dir+'direct-writer-continuation-build.json',JSON.stringify({programs,sites},null,2));
writeFileSync(dir+'direct-writer-continuation-run.mjs',readFileSync(dir+'map-fragment-run.mjs','utf8').replaceAll('map-fragment','direct-writer-continuation'));
console.log({programs,sites});
