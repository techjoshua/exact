import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/direct-current/';
let source=readFileSync(dir+'current-production.mjs','utf8');
function replace(before,after){if(source.split(before).length!==2)throw Error('Unexpected site: '+before);source=source.replace(before,after);}
const start=source.indexOf('function renderProgramOutput(context, segments, render, host) {');
const end=source.indexOf('//#endregion',start);
if(start<0||end<0)throw Error('Missing program visitor');
source=source.slice(0,start)+`function renderProgramOutput(context,segments,render,host){
 const shared=context.experimentalSink;
 if(shared&&context.enhancementOperationRoutes?.length)throw Error('Prototype requires enhancement capture');
 const sink=shared??{value:''};
 const write=(text)=>{sink.value=appendBoundedHtml(context,captureNestedEnhancementStringPrefix(context,sink.value),text);};
 let entered;
 if(host&&(host==='html'||host==='head'||host==='body'||context.documentRootSeen&&context.hostStack.at(-1)==='html')){
  entered=enterHostTag(context,host);
  if(entered.prefix)write(entered.prefix);
 }else if(host&&!context.hostStack.length)claimRootText(context);
 const visit=(start)=>{
  for(let index=start;index<segments.length;index++){
   const segment=segments[index];
   const value=typeof segment==='string'?segment:render(segment);
   if(value instanceof Promise)return value.then(html=>{write(html);return visit(index+1);});
   write(value);
  }
  return shared?'':sink.value;
 };
 return entered?withRenderCleanup(()=>visit(0),()=>leaveHost(context,entered.tag)):visit(0);
}
`+source.slice(end);
replace('const context = createSsrContext(renderOptions);','const context = createSsrContext(renderOptions);\n context.experimentalSink={value:""};');
replace('const output = new SsrOutputBuffer(context.maxOutputBytes);','html=context.experimentalSink.value+html;\n const output = new SsrOutputBuffer(context.maxOutputBytes);');
replace('const executed = executeOpaqueOperation(child, target);','const executed = captureGenericOperation(context,child,target);');
replace('target.renderDirectServerChildRange(range), operationResult','captureStructuralOutput(context,()=>target.renderDirectServerChildRange(range)), operationResult');
replace('target.renderDirectServerKeyedChild(keyed), operationResult','captureStructuralOutput(context,()=>target.renderDirectServerKeyedChild(keyed)), operationResult');
replace('function directComponentHtml(context, html, props, publication, boundary) {',`function directComponentHtml(context, html, props, publication, boundary) {
 if(context.experimentalSink&&!((boundary.documentProbe&&context.documentRootSeen)||boundary.omitRootBoundary||(boundary.omitCompilerOwnedBoundary&&(publication?.kind!=='resumption'||context.resumptionCapture!==undefined))))throw Error('Prototype requires component boundary capture');`);
replace('append(result) {\n\t\tthis.html = captureNestedEnhancementStringPrefix(this.context, this.html);',`append(result) {
  if(this.context.experimentalSink){
   const sink=this.context.experimentalSink;
   if(this.context.textSeparators&&result.text&&this.previousWasText)sink.value=appendBoundedHtml(this.context,sink.value,'<!-- -->');
   if(result.html!=='')sink.value=appendBoundedHtml(this.context,sink.value,result.html);
   this.previousWasText=result.text;
   return;
  }
  this.html = captureNestedEnhancementStringPrefix(this.context, this.html);`);
source+=`
function captureStructuralOutput(context,work){
 const prior=context.experimentalSink;
 context.experimentalSink=undefined;
 let result;
 try{result=work();}catch(error){context.experimentalSink=prior;throw error;}
 if(result instanceof Promise)return result.finally(()=>{context.experimentalSink=prior;});
 context.experimentalSink=prior;
 return result;
}
function captureGenericOperation(context,child,target){
 const prior=context.experimentalSink;
 context.experimentalSink=undefined;
 let executed;
 try{executed=executeOpaqueOperation(child,target);}catch(error){context.experimentalSink=prior;throw error;}
 if(executed?.value instanceof Promise)return {value:executed.value.finally(()=>{context.experimentalSink=prior;})};
 context.experimentalSink=prior;
 return executed;
}
`;
writeFileSync(dir+'shared-accumulator.mjs',source);
writeFileSync(dir+'shared-accumulator-run.mjs',readFileSync(dir+'map-fragment-run.mjs','utf8').replaceAll('map-fragment','shared-accumulator'));
