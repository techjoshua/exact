import { createPreparedServerRenderProgram as __exactPreparedServerRenderProgram, prepareCompiledRenderProgram as __exactPrepareRenderProgram } from "@exactjs/core/framework/server-render-structure";
import { registerDirectSsrLifecycleHandler as __exactRegisterDirectSsrLifecycle } from "@exactjs/ssr/runtime/direct-lifecycle";
import { awaitServerComponentTask as __exactServerTaskAwait, activateServerComponentTaskForHost as __exactActivateServerTask } from "@exactjs/core/framework/server-component-execution";
import "@exactjs/ssr/runtime/resumption-boundaries";
import { issueExactServerComponent as __exactIssueServerComponent_1, writeExactServerComponent as __exactWriteServerComponent_1, disposeExactServerComponent as __exactDisposeServerComponent_1 } from "@exactjs/core/runtime/component-operations";
import { rejectDirectServerComponentConstruction as __exactRejectDirectServerConstruction_1 } from "@exactjs/core/runtime/component-construction/direct-server";
import { directSsrLifecycle as __exactDirectSsrLifecycle_1 } from "@exactjs/ssr/runtime/direct-lifecycle";
const __exactComponentContract_1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
const __exact_server_task_slice_1 = [[], [[0, ["ready"]]], "blocking", "load"];
const __exact_render_program_1 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xSrZfZ2vL5bqieAxBny_yIz", namespace: "html", ssrRootStatic: ["", [], []], ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
  const __exactValue_0 = __exactInvocation.eagerValues[0];
  const __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
  if (__exactValue_1 === __exactSsr.unprepared)
    return;
  __exactSsr.begin(__exactContext, 1, 2, 17, 17);
  
  let __exactCharacters = 17;
  __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "strong", "<strong", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
  __exactCharacters = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "", "</strong>");
  return __exactOutput;
}, ssrHost: "strong" });
let starts = 0;
let disposals = 0;
let disposedIndices = [];
let release;
let gate;
function reset() {
  starts = 0;
  disposals = 0;
  disposedIndices = [];
  gate = new Promise((resolve) => release = resolve);
}
function settle() {
  release();
}
const __exactImplementation_ScheduledChild_1 = function ScheduledChild(props) {
  this.state.ready = false;
  __exactActivateServerTask(this, __exact_server_task_slice_1, "xOJZsG8qeNwCeYMu9H7JJ0q", async (_task) => {
    starts++;
    await __exactServerTaskAwait(_task.signal, gate);
    this.state.ready = true;
  });
  __exactRegisterDirectSsrLifecycle(this, "unmount", () => {
    disposals++;
    disposedIndices.push(props.index);
  });
  return () => __exactPreparedServerRenderProgram(__exact_render_program_1, [{}, this.state.ready ? "Ready " + props.index : "Waiting"]);
};
const ScheduledChild2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_ScheduledChild_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "x0M1Jrha6I34ViXzd6ogIgT",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "executor",
    implementations: [
      { id: "x4Zwx2FC9VHlBQv4a1K2-QW", name: "ScheduledChild", role: "root", implementation: __exactImplementation_ScheduledChild_1 }
    ],
    continuations: [
      {
        kind: "task",
        id: "xOJZsG8qeNwCeYMu9H7JJ0q",
        componentId: "x0M1Jrha6I34ViXzd6ogIgT",
        readiness: "blocking",
        concurrency: "latest",
        dependencies: [],
        stateReads: [],
        stateWrites: [
          {
            path: "ready",
            kind: "write",
            confidence: "exact"
          }
        ],
        publicContexts: [],
        serverContexts: [],
        contextWrites: [],
        serverContextWrites: [],
        boundaries: []
      }
    ],
    executors: [
      {
        id: "xOJZsG8qeNwCeYMu9H7JJ0q",
        componentId: "x0M1Jrha6I34ViXzd6ogIgT",
        execute: async (__exactActivation_1, __exactExecution_1) => {
          const __exactComponent_1 = { state: __exactActivation_1.state };
          const __exactContextWrites_1 = {};
          await (async (_task) => {
            starts++;
            await __exactServerTaskAwait(_task.signal, gate);
            __exactComponent_1.state.ready = true;
          })(__exactExecution_1.task);
          return { state: __exactComponent_1.state, contexts: __exactContextWrites_1 };
        }
      }
    ],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "x0M1Jrha6I34ViXzd6ogIgT",
      instantiate: __exactImplementation_ScheduledChild_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 11,
      capabilities: [
        "tasks",
        "continuations",
        "resumption"
      ],
      state: [
        "ready"
      ],
      props: [
        "index"
      ],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "scheduled",
        lane: "direct",
        render: __exactImplementation_ScheduledChild_1,
        lifecycle: __exactDirectSsrLifecycle_1,
        publication: {
          kind: "resumption",
          name: "ScheduledChild"
        }
      },
      tasks: [
        "xOJZsG8qeNwCeYMu9H7JJ0q"
      ],
      reactive: [
        {
          name: "load",
          provenance: "unknown",
          allocation: "constant",
          dependencies: []
        },
        {
          name: "props",
          provenance: "props",
          allocation: "live-slot",
          dependencies: []
        },
        {
          name: "this",
          provenance: "state",
          allocation: "live-slot",
          dependencies: []
        }
      ],
      render: "returned-function"
    },
    resumption: {
      componentId: "x0M1Jrha6I34ViXzd6ogIgT",
      statePaths: [
        "ready"
      ],
      stateInputs: [],
      valueCaptures: [],
      contexts: [],
      boundaries: [],
      stateDefaults: [
        [
          "ready",
          false
        ]
      ]
    }
  }
}))();
export {
  ScheduledChild2 as ScheduledChild,
  disposals,
  disposedIndices,
  reset,
  settle,
  starts
};
