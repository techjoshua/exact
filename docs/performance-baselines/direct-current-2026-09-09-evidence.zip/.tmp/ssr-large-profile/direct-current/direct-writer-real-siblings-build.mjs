import {spawnSync} from 'node:child_process';
import {writeFileSync,readFileSync} from 'node:fs';
import {transform} from 'esbuild';
const dir='.tmp/ssr-large-profile/direct-current/';
const source=`import {TaskContext,type Component} from '@exactjs/core';
export let starts=0;export let disposals=0;export let disposedIndices:number[]=[];
let release:()=>void;let gate:Promise<void>;
export function reset(){starts=0;disposals=0;disposedIndices=[];gate=new Promise<void>(resolve=>release=resolve);}
export function settle(){release();}
export function ScheduledChild(this:Component<{ready:boolean}>,props:{index:number}){
 this.state.ready=false;
 const load=async (_task:TaskContext=TaskContext.server().blocking())=>{starts++;await gate;this.state.ready=true;};
 load();this.onUnmount(()=>{disposals++;disposedIndices.push(props.index);});
 return ()=><strong>{this.state.ready?'Ready '+props.index:'Waiting'}</strong>;
}`;
const request={id:dir+'direct-writer-real-siblings.tsx',kind:'compile',target:'server',source};
const run=spawnSync('.tmp/native-compiler/exactc.exe',[],{input:JSON.stringify(request)+'\n',encoding:'utf8',windowsHide:true,maxBuffer:16*1024*1024});
if(run.status!==0)throw Error(run.stderr||run.stdout);
const response=JSON.parse(run.stdout);
writeFileSync(dir+'direct-writer-real-siblings-compile.json',JSON.stringify({request,response},null,2));
if(response.error||response.diagnostics.some(d=>d.severity==='error'))throw Error(JSON.stringify(response.diagnostics));
let code=(await transform(response.code,{loader:'ts',format:'esm',target:'esnext'})).code;
const signature='ssr: (__exactSsr, __exactContext, __exactInvocation) => {';
if(code.split(signature).length!==2)throw Error('Expected one leaf writer');
code=code.replace(signature,'ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {');
code=code.replace('const __exactOutput = __exactSsr.output();','');
writeFileSync(dir+'direct-writer-real-siblings-fixture.mjs',code);
writeFileSync(dir+'direct-writer-real-siblings-entry.mjs',readFileSync(dir+'direct-writer-siblings.mjs','utf8')+'\nexport {createSsrContext,SsrOperationTarget,renderChildren,createPreparedServerComponentReference,prepareCompiledRenderProgram,createPreparedServerRenderProgram};\n');
