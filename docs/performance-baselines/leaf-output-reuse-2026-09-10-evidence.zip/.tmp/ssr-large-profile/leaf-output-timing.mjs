import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';
const worker=root+'leaf-output-remaining-worker.mjs';
let source=fs.readFileSync(root+'ready-props-stable-timing-worker.mjs','utf8');
source=source.replace('const started=performance.now();','const cpuStart=process.cpuUsage();\nconst started=performance.now();');
source=source.replace('const elapsed=performance.now()-started;', 'const elapsed=performance.now()-started;\nconst cpu=process.cpuUsage(cpuStart);');
source=source.replace('processPriority:os.getPriority()','processPriority:os.getPriority(),cpuMicrosPerRender:(cpu.user+cpu.system)/count');
fs.writeFileSync(worker,source);
const rows=[];
for(const [runtime,scenario] of [['node','assets'],['bun','assets']])for(let round=0;round<2;round++)for(const variant of round?['split','current']:['current','split']){
 const entry=root+(variant==='split'?'leaf-output':variant==='candidate'?'ready-props-split':'direct-execution-integrated')+'/server-entry.js';
 const artifactSha256=createHash('sha256').update(fs.readFileSync(entry)).digest('hex');
 assert.equal(artifactSha256,variant==='split'?'48231f87535442428554a955b8afa83bbcac7866fae064385b3d7647a9cba7a7':variant==='candidate'?'a454621b5c878a28cbf574f54bc8b73d1cb026809ef24f421be9e61c6f13000d':'2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18');
 const run=spawnSync(runtime,[worker,entry,'encoded',scenario,'20000'],{windowsHide:true,encoding:'utf8',env:{...process.env,NODE_ENV:'production'}});
 assert.equal(run.status,0,run.stderr+run.stdout);
 const row={runtimeId:runtime,variant,round,artifactSha256,...JSON.parse(run.stdout)};
 const peer=rows.find(r=>r.scenario===scenario);if(peer)assert.equal(row.hash,peer.hash);
 rows.push(row);fs.writeFileSync(root+'leaf-output-remaining.json',JSON.stringify(rows,null,2));
 console.log(runtime,variant,round,'wall',row.usPerRender.toFixed(2),'CPU',row.cpuMicrosPerRender.toFixed(2),'us/render');
}

assert.equal(rows.length,8);
