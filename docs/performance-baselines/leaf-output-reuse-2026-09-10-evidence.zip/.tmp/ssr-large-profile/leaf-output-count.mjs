import fs from 'node:fs';import {pathToFileURL} from 'node:url';import {resolve} from 'node:path';
const root='.tmp/ssr-large-profile/';
let code=fs.readFileSync(root+'leaf-output/server-entry.js','utf8');
code='let auditCounts={total:0,eligible:0,created:0};\n'+code;
code=code.replace('function renderProgramWriter(context, host, invocation, invoke, render, prepareReferences) {','function renderProgramWriter(context, host, invocation, invoke, render, prepareReferences) {auditCounts.total++;');
code=code.replace('function auditReadLeafOutput(context){','function auditReadLeafOutput(context){auditCounts.eligible++;');
code=code.replace('return context.auditLeafOutput=Object.freeze','auditCounts.created++;return context.auditLeafOutput=Object.freeze');
code+='\nexport function auditReset(){auditCounts={total:0,eligible:0,created:0};}export function auditRead(){return auditCounts;}';
const entry=root+'leaf-output-count-entry.mjs';fs.writeFileSync(entry,code);
const mod=await import(pathToFileURL(resolve(entry)));const rows=[];
for(const scenario of ['small','large']){
 const data=JSON.parse(fs.readFileSync('.tmp/positional-leaves/data.json','utf8'));
 if(scenario==='large')data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
 mod.auditReset();await mod.renderParticipant(data,'/incidents/inc-101',{clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'});rows.push({scenario,...mod.auditRead()});
}
fs.writeFileSync(root+'leaf-output-counts.json',JSON.stringify(rows,null,2));console.log(rows);
