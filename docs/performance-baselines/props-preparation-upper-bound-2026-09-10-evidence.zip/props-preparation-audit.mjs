import fs from 'node:fs';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
const d='.tmp/ssr-large-profile/';
const source=fs.readFileSync(d+'static-invocation-final/server-entry.js','utf8');
const start=source.indexOf('function prepareComponentProps('),end=source.indexOf('\nfunction settledValue(',start);
assert.ok(start>0&&end>start);
const body=source.slice(start,end);
const audited=body.replace('let resolved;','globalThis.__propAudit.calls++; let resolved;').replace('const value = props[key];','globalThis.__propAudit.fields++; const value = props[key];').replace('const source = serverComponentDependencyForValue(value)', 'globalThis.__propAudit.lookups++; const source = serverComponentDependencyForValue(value)').replace('const snapshot = source.read();','globalThis.__propAudit.sources++; const snapshot = source.read();');
fs.mkdirSync(d+'props-preparation-audit',{recursive:true});
fs.writeFileSync(d+'props-preparation-audit/server-entry.js','globalThis.__propAudit={calls:0,fields:0,lookups:0,sources:0};\n'+source.slice(0,start)+audited+source.slice(end));
fs.mkdirSync(d+'props-preparation-upper',{recursive:true});
fs.writeFileSync(d+'props-preparation-upper/server-entry.js',source.slice(0,start)+'function prepareComponentProps(props) { return props; }'+source.slice(end));
const worker=fs.readFileSync(d+'final-rope-worker.mjs','utf8').replace('JSON.stringify({reactResolution,','JSON.stringify({propAudit:globalThis.__propAudit,reactResolution,');
fs.writeFileSync(d+'props-preparation-audit-worker.mjs',worker);
const rows=[];
for(const runtime of ['node','bun'])for(const scenario of ['assets','large']){
 const r=spawnSync(runtime,[d+'props-preparation-audit-worker.mjs',d+'props-preparation-audit/server-entry.js','encoded',scenario,'1'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 assert.equal(r.status,0,r.stderr+r.stdout);const row={runtimeId:runtime,...JSON.parse(r.stdout)};
 assert.equal(row.propAudit.sources,0,'Upper-bound probe would bypass a real dependency');
 rows.push(row);console.log(runtime,scenario,row.propAudit);
}
fs.writeFileSync(d+'props-preparation-audit.json',JSON.stringify(rows,null,2));
