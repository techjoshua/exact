import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
const rows=['props-preparation-upper-results.json','props-preparation-upper-large-results.json'].flatMap(f=>JSON.parse(fs.readFileSync(d+f,'utf8')));
let table='| Runtime | Mode | Size | Current | Preparation bypass | React |\n| --- | --- | --- | ---: | ---: | ---: |\n';
for(const runtime of ['node','bun'])for(const mode of ['string','encoded','stream'])for(const scenario of ['assets','large']){
 const mean=variant=>{const selected=rows.filter(r=>r.runtimeId===runtime&&r.mode===mode&&r.scenario===scenario&&r.variant===variant);return (selected.reduce((n,r)=>n+r.usPerRender,0)/selected.length).toFixed(2)};
 table+=`| ${runtime} | ${mode} | ${scenario==='assets'?'small':'large'} | ${mean('current')} | ${mean('candidate')} | ${mean('react')} |\n`;
}
fs.writeFileSync('docs/performance-baselines/props-preparation-upper-bound-2026-09-10.md',`# Component-prop preparation upper bound, September 10, 2026

Status: diagnostic only. No production change. The bypass is unsafe for general applications
because it omits resolution of compiler-propagated component and task dependencies.

## Audit and hypothesis

The retained build's prepareComponentProps enumerates own inputs, excludes deferred task inputs,
and checks object/function values for dependency sources. Ordinary values already pass through
without a props copy. The fresh Bun profile attributed 3.61% of samples to this function.

Instrumentation on the actual full-document fixtures found these counts per render:

| Size | Preparation calls | Visited fields | Object/function lookups | Sources found |
| --- | ---: | ---: | ---: | ---: |
| Small | 8 | 18 | 5 | 0 |
| Large, 96 incidents | 101 | 111 | 5 | 0 |

Each raw audit executes one warmup plus one render, so its counters are twice these values.
Node and Bun agree. The extra large-document calls correspond to repeated SeverityBadge
components with scalar severity props. The absence of sources is a property of these fixtures,
not a compiler proof about arbitrary applications.

Hypothesis: removing all preparation could save roughly the sampled 2-4% on small documents
and potentially more when repeated scalar-only components increase the call count. This measures
the opportunity before designing safe compiler assistance. The isolated bypass returns props
unchanged and is never eligible for production adoption as written.

## Measurements

Seventy-two fresh production processes compare retained eXact, the diagnostic bypass, and React
in two reversed variant orders. Each has 5,000 warmups and 10,000 measured renders. Both applications
own their complete document and render four asset tags. Encoded mode consumes string output
through Response.text(); stream mode fully consumes the framework stream. Complete eXact hashes
match. These are microseconds per render, lower is better, not HTTP throughput.

${table}

The large string means improve by approximately 4.6% on Node and 6.3% on Bun. This supports
investigating safe compiler-assisted preparation. It does not show that all of that saving is
recoverable, isolate an individual enumeration or lookup cost, or establish confidence intervals.
The bypass still does not beat React's string-rendering means. All raw populations are retained.

## Design constraints and next action

Do not infer settled values from TypeScript prop types alone: compiler-propagated pending values
can represent those inputs. Do not skip preparation for all stateless components; their inputs
can still depend on scheduled work. Prepared server references may retain their original props
object, so a generic runtime optimization must not assume every bag is a fresh plain data object.
Live ownership checks and authored access behavior must be preserved.

A next experiment should evaluate explicit compiler proof or construction-time knowledge for
finite scalar prop bags, while retaining ordinary preparation for dynamic or pending values.
That requires measuring the overhead of the proof itself and protecting task settlement,
cancellation, and input ownership. No second rendering engine or sink-specific component API is
proposed. Full package/browser validation is unnecessary for this discarded diagnostic bypass;
it will be required for any actual implementation.

Audit scripts, instrumented and bypass artifacts, raw captures, runners, and the retained eXact
artifact are preserved in props-preparation-upper-bound-2026-09-10-evidence.zip. Production
remains the static-input reuse build. The overall performance objective is still unmet.
`);
console.log(table);
