import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import ts from 'typescript';
const base='.tmp/ssr-large-profile/',out=base+'structural-assets/';
await fs.mkdir(out,{recursive:true});
for(const file of ['server-entry.js','bun-server-entry.js']){
 let source=await fs.readFile(base+'structural-composition/'+file,'utf8');
 for(const index of [0,1]){
  const old=`s.keyedChild(o, i.eagerValues[${index}])`;
  assert.equal(source.split(old).length,2);
  source=source.replace(old,`auditAssetRange(o, i.eagerValues[${index}])`);
 }
 const ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
 let body;
 function visit(node){
  if(ts.isArrowFunction(node)&&ts.isBlock(node.body)&&node.body.statements.some(s=>ts.isVariableStatement(s)&&s.declarationList.declarations.some(d=>d.name.getText(ast)==='child'&&d.initializer?.getText(ast)==='s.reference(IncidentApp, i.eagerValues[2])')))body=node.body;
  ts.forEachChild(node,visit);
 }
 visit(ast);assert.ok(body);
 const original=body.getText(ast).slice(1,-1).replace(/\bo\b/g,'childOutput');
 const replacement=`{ const childOutput={...o,preparation:undefined}; return withRenderCleanup(()=>{${original}},()=>childOutput.preparation?Promise.resolve(childOutput.preparation[Symbol.asyncDispose]()):undefined); }`;
 source=source.slice(0,body.getStart(ast))+replacement+source.slice(body.end);
 source+=`
function auditAssetScope(context, run) {
 countSsrNode(context);enterSsrTreeDepth(context);
 return withRenderCleanup(run,()=>leaveSsrTreeDepth(context));
}
function auditAssetRange(output, value) {
 const context=output.context;
 if(!context.writerSink)throw new Error('Asset diagnostic requires shared sink');
 return mapRenderValue(writeProgramBoundary(context,output.sink,'','',()=>auditAssetScope(context,()=>{
  const range=readPreparedServerChildRange(value);
  if(!range)throw new Error('Expected compiler asset range');
  const list=readServerList(unwrap(range.value));
  if(!list)throw new Error('Expected prepared asset list');
  return markerPair(context,'',()=>auditAssetScope(context,()=>markerPair(context,markerId(context,'fragment',undefined,list.key),()=>auditAssetItems(output,list.children,0))));
 })),()=>undefined);
}
function auditAssetItems(output, children, index) {
 while(index<children.length){
  const child=children[index++];
  const value=auditAssetScope(output.context,()=>{
   const keyed=readPreparedServerKeyedChild(child);
   if(!keyed)throw new Error('Expected keyed asset');
   const program=readPreparedServerRenderProgram(keyed.value);
   if(!program||!['script','link'].includes(program.program.ssrHost))throw new Error('Expected script or stylesheet program');
   const render=()=>renderPreparedSsrProgram(output.context,program,output.target??output.render,output.prepareReferences);
   return program.program.ssrHost==='script'?markerPair(output.context,markerId(output.context,'item',undefined,keyed.key),()=>auditAssetScope(output.context,render)):render();
  });
  if(value instanceof Promise)return awaitSsrProgramSink(output.sink,value).then(html=>{if(html)output.sink.write(html);return mapRenderValue(output.sink.ready(),()=>auditAssetItems(output,children,index));});
  if(value)output.sink.write(value);
  const pending=output.sink.ready();
  if(pending)return pending.then(()=>auditAssetItems(output,children,index));
 }
 return '';
}
`;
 await fs.writeFile(out+file,source);
}
console.log('Created isolated asset traversal and local preparation-scope prototype');
