import fs from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {setPriority} from 'node:os';
import assert from 'node:assert/strict';
setPriority(0,10);
const base='.tmp/ssr-large-profile/',out=base+'structural-assets-limits/';
await fs.mkdir(out,{recursive:true});
const modules=[];
for(const [label,folder] of [['current','conditional-emission'],['candidate','structural-assets']]){
 const source=await fs.readFile(base+folder+'/server-entry.js','utf8');
 const appended=`\nexport async function auditLimited(data, tags, limits) { return (await renderCompilerClosedToHydratableString(createPreparedServerComponentReference(Document,{initialData:data,path:'/incidents/inc-101',clientTags:tags}),{publishRootProps:true,...limits})).htmlWithHydration; }\n`;
 await fs.writeFile(out+label+'.js',source+appended);
 modules.push(await import(pathToFileURL(resolve(out+label+'.js'))));
}
const data=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));
const tags='<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">';
const rows=[];
for(const [key,values] of [['maxTreeNodes',Array.from({length:500},(_,i)=>i+1)],['maxTreeDepth',Array.from({length:30},(_,i)=>i+1)],['maxOutputBytes',Array.from({length:80},(_,i)=>(i+1)*64)]]){
 for(const value of values){
  const outcomes=[];
  for(const mod of modules){try{outcomes.push({ok:true,html:await mod.auditLimited(data,tags,{[key]:value})});}catch(error){outcomes.push({ok:false,name:error.name,message:error.message});}}
  const same=JSON.stringify(outcomes[0])===JSON.stringify(outcomes[1]);
  rows.push({key,value,same,outcomes:outcomes.map(({html,...rest})=>({...rest,...(html?{characters:html.length}:{})}))});
 }
}
await fs.writeFile(out+'results.json',JSON.stringify(rows,null,2));
for(const key of ['maxTreeNodes','maxTreeDepth','maxOutputBytes']){
 const selected=rows.filter(row=>row.key===key);
 console.log(JSON.stringify({key,cases:selected.length,mismatches:selected.filter(row=>!row.same),firstSuccess:selected.find(row=>row.outcomes[0].ok)?.value,candidateFirstSuccess:selected.find(row=>row.outcomes[1].ok)?.value}));
}
assert.equal(rows.length,610);
