from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'bun-encoded-body';root.mkdir(exist_ok=True)
source=Path('framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js').read_text()
(root/'current.mjs').write_text(source)
needle='return new Response(body ? body.kind === "produced" ? body.toReadableStream() : body.toText() : result.stream ?? result.body ?? "", {'
assert source.count(needle)==1
candidate=source.replace(needle,needle.replace('body.toText()','Buffer.from(body.toText(), "utf8")'))
(root/'candidate.mjs').write_text(candidate)
(root/'worker.mjs').write_bytes((base/'prefix-native/worker.mjs').read_bytes())
r=(base/'prefix-native-run.mjs').read_text().replace('prefix-native/','bun-encoded-body/').replace('large96-bun-native-prefix-experiment','large96-bun-encoded-response-body')
(base/'bun-encoded-body-run.mjs').write_text(r)
