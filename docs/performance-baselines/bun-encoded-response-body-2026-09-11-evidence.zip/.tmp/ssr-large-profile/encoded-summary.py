import json
from pathlib import Path
from statistics import mean
p=Path('.tmp/ssr-large-profile/bun-encoded-body');d=json.loads((p/'capture.json').read_text());assert d['complete']
rows=[]
for pop in (0,1):
 for phase in ('normal','scheduled'):
  b=[b for b in d['blocks'] if b['population']==pop and b['phase']==phase]
  x=mean(b['rps'] for b in b if b['variant']=='current');y=mean(b['rps'] for b in b if b['variant']=='candidate')
  rows.append(dict(population=pop+1,phase=phase,current=x,encoded=y,changePct=(y/x-1)*100))
print(json.dumps(rows,indent=2));(p/'summary.json').write_text(json.dumps(rows,indent=2))
