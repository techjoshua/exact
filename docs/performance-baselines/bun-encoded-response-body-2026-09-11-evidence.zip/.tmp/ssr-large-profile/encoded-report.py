import json,hashlib,zipfile
from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'bun-encoded-body';d=json.loads((root/'capture.json').read_text());rows=json.loads((root/'summary.json').read_text());assert d['complete']
for b in d['blocks']:
 assert all(s['errors']==0 for r in b['results'] for s in r['stages'])
 assert b['after']['scheduleCalls']==(b['valid']+len(b['results']) if b['phase']=='scheduled' else 0)
valid=sum(b['valid'] for b in d['blocks'])
report=Path('docs/performance-baselines/bun-encoded-response-body-2026-09-11.md')
lines=['# Explicit UTF-8 encoding before native Bun Response','',
'Hypothesis: converting completed eXact HTML to an owned Buffer before constructing Response could recover 5-20% if native string conversion contributes to the large-document cost. The scratch bundle changes only the buffered-text branch of the Bun response adapter to Buffer.from(body.toText(), "utf8"). The shared renderer and document/hydration content remain unchanged. React is unchanged.', '',
'Native Bun string HTTP, 96 incidents, concurrency 32, five-second blocks after ten-second warmup. Fresh current/candidate/React workers then reversed order. Each eXact worker runs immediate/scheduled/immediate. Machine workload varied materially; candidate first-repeat immediate controls fell from 2,851 to 2,378 RPS, so their mean is not a stable baseline.', '',
'| Repeat | Mode | Current RPS | Encoded RPS | Change |','| --- | --- | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['population']} | {r['phase']} | {r['current']:,.0f} | {r['encoded']:,.0f} | {r['changePct']:+.2f}% |")
lines+=['',f'{valid:,} complete measured responses validated with zero errors. Artifact and invocation guards pass.', '',
'Encoding did not improve the scheduled path and the immediate-path apparent gains are confounded by drift. No production change adopted. User steering moved the next investigation to adaptive lag-triggered scheduling and limiting total batch starts per event-loop turn.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(root.glob('*'))+[report,base/'bun-encoded-body-build.py',base/'bun-encoded-body-run.mjs',base/'encoded-summary.py',base/'encoded-report.py'];archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists();manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print(valid,'validated responses; archive verified')
