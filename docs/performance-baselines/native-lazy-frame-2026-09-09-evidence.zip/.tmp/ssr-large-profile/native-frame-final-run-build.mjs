import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
fs.writeFileSync(d+'native-frame-final-run.mjs',fs.readFileSync(d+'native-lazy-frame-full-run.mjs','utf8')
  .replace('native-lazy-frame-full-results.json','native-frame-final-results.json'));
