import ts from 'typescript';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/';
let programs=0,sites=0;
/** Experiments on native-emitted functions. Only pending branches allocate a saved frame. */
function lower(source){
  const file=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
  const edits=[];
  function visit(node){
    if(ts.isPropertyAssignment(node)&&node.name.getText(file)==='ssr'&&ts.isArrowFunction(node.initializer)&&ts.isBlock(node.initializer.body)){
      const writer=node.initializer;
      const statements=writer.body.statements;
      const continuation=statements.find(s=>ts.isFunctionDeclaration(s)&&s.name?.text==='__exactResume');
      if(continuation){
        const start=statements.findIndex(s=>ts.isReturnStatement(s));
        assert.ok(start>=0);
        const locals=[];
        const prefix=statements.slice(0,start).map(s=>{
          if(!ts.isVariableStatement(s))return s.getText(file);
          return s.declarationList.declarations.map(declaration=>{
            assert.ok(ts.isIdentifier(declaration.name)&&declaration.initializer);
            locals.push(declaration.name.text);
            return `${declaration.name.text}=${declaration.initializer.getText(file)};`;
          }).join('\n');
        }).join('\n');
        let body=continuation.body.statements[0].getText(file);
        const snapshot=(stage)=>`[__exactSsr,__exactContext,__exactInvocation,__exactOutput,${stage},undefined,${locals.join(',')}]`;
        const resume='__exactRun(__exactSaved[0],__exactSaved[1],__exactSaved[2],__exactSaved[3],__exactSaved)';
        body=body.replace(/if \(__exactSettled instanceof Promise\)\s+return __exactSettled\.then\(\((__exactSettled\d*)\) => __exactResume\((\d+), \1\)\);/g,(_,value,stage)=>{
          sites++;return `if(__exactSettled instanceof Promise){const __exactSaved=${snapshot(stage)};return __exactSettled.then(value=>{__exactSaved[5]=value;return ${resume};});}`;
        });
        body=body.replace(/if \((__exactDrain_\d+)\)\s+return \1\.then\(\(\) => __exactResume\((\d+)\)\);/g,(_,drain,stage)=>{
          sites++;return `if(${drain}){const __exactSaved=${snapshot(stage)};return ${drain}.then(()=>${resume});}`;
        });
        assert.ok(!body.includes('__exactResume('));
        const restored=locals.map((name,index)=>`${name}=__exactFrame[${index+6}];`).join('\n');
        const replacement=`function __exactRun(__exactSsr,__exactContext,__exactInvocation,__exactOutput,__exactFrame=undefined){
          let ${locals.join(',')};let __exactStage=0,__exactSettled;
          if(__exactFrame){__exactStage=__exactFrame[4];__exactSettled=__exactFrame[5];${restored}}
          else{${prefix}}
          ${body}
        }`;
        edits.push({start:writer.getStart(file),end:writer.end,code:replacement});programs++;
      }
    }
    ts.forEachChild(node,visit);
  }
  visit(file);
  for(const edit of edits.sort((a,b)=>b.start-a.start))source=source.slice(0,edit.start)+edit.code+source.slice(edit.end);
  return source;
}
fs.writeFileSync(d+'native-lazy-frame.mjs',lower(fs.readFileSync(d+'native-sink-application.mjs','utf8')));
const application={programs,sites};
assert.ok(programs>0&&sites>0);
fs.writeFileSync(d+'native-lazy-frame-fixture.mjs',lower(fs.readFileSync(d+'native-sink-fixture.mjs','utf8')));
fs.writeFileSync(d+'native-lazy-frame-build.json',JSON.stringify({application,total:{programs,sites}},null,2));
let run=fs.readFileSync(d+'native-sink-pending-run.mjs','utf8')
  .replace("pending:d+'native-sink-pending.mjs'","pending:d+'native-lazy-frame.mjs'")
  .replace('native-sink-pending-results.json','native-lazy-frame-results.json');
fs.writeFileSync(d+'native-lazy-frame-run.mjs',run);
console.log({application,total:{programs,sites}});
