import pathlib,json,hashlib,zipfile,statistics
d=pathlib.Path('.tmp/ssr-large-profile')
final=json.loads((d/'native-frame-final-results.json').read_text(encoding='utf8'))
initial=json.loads((d/'native-lazy-frame-results.json').read_text(encoding='utf8'))
intermediate=json.loads((d/'native-lazy-frame-full-results.json').read_text(encoding='utf8'))
assert (len(final),len(initial),len(intermediate))==(64,16,64)
def mean(rows,runtime,mode,scenario,variant):
    values=[r['usPerRender'] for r in rows if (r['runtimeId'],r['mode'],r['scenario'],r['variant'])==(runtime,mode,scenario,variant)]
    assert len(values)==2
    return statistics.mean(values)
lines=['# Lazy SSR continuation frames','',
'Date: 2026-09-09. Native compiler integration experiment; production selection unchanged.','',
'Two Node CPU profiles compare the preceding target-methods prototype and the then-current native',
'continuation emitter on the actual 96-incident application. Profiling starts after 5,000 warmups',
'and covers 50,000 complete string renders. The hottest generated continuation frame accounts for',
'2.4% of sampled time; GC accounts for about 10% in both profiles. Profiles identify work, not exact',
'allocation counts. The stated pre-experiment hypothesis was a 3 to 8 microsecond reduction in large',
'Node string rendering by avoiding an always-created continuation closure around prepared locals.','',
'## Implementation','',
'The generated writer now falls through its switch in the initial invocation. A pending child or',
'sink drain selects a resume stage and exits the switch. Only that path reaches a block-scoped',
'snapshot and callback. Reentry restores the saved locals, character count, and issued sibling',
'references, then continues at the selected stage. Preparation and task startup do not repeat.','',
'A first syntax-level experiment duplicated the snapshot literal at every pending branch. Native',
'integration instead emits one suspension postlude per program. This avoids quadratic generated',
'code growth for wide programs while retaining lazy frame creation. A single synchronous terminal',
'write keeps the previously tested direct completion and final-drain behavior. No second renderer',
'or synchronous compatibility engine is introduced.','',
'Validation also found that authored Promise and undefined bindings could capture the new emitted',
'references. The former could skip a real child wait and produce closing tags before child output;',
'the latter could enter frame restoration incorrectly. The continuation now uses the runtime',
'operations table\'s promise constructor and void 0 for empty frame values. Before/after regressions',
'cover both bindings on Node and Bun. This protects these continuation references, not a claim',
'that all other compiler intrinsic references have been audited.','',
'## Initial directional experiment','',
'Two reversed-order pairs, fresh production-mode processes, 5,000 warmups and 12,000 measured',
'renders each. Microseconds per complete document, lower is better. This first candidate was an',
'AST-located transformation of the emitted writer; the final candidate below is emitted by Go.','',
'| Runtime | Document | Previous emitter | Lazy-frame prototype | Change |',
'| --- | --- | ---: | ---: | ---: |']
for rt in ['node','bun']:
    for sc in ['assets','large']:
        a,b=[mean(initial,rt,'string',sc,k) for k in ['refined','pending']]
        lines.append(f'| {rt} | {sc} | {a:.2f} | {b:.2f} | {(b/a-1)*100:+.1f}% |')
lines += ['',
'The raw initial harness labels the candidate pending; its entry path and hash identify the',
'lazy-frame artifact. It is distinct from the earlier rejected pending-property experiment.','',
'## Final paired comparison','',
'The corrected native emitter builds all 25 comparison-app programs with an isolated compiler.',
'Program IDs and component bindings are verified while linking these emitted functions to the',
'existing shared-sink prototype. Node 26.8.1 and Bun 1.4.2 each run both string and fully consumed',
'stream modes, with three or 96 incidents and four assets. Both frameworks render their own full',
'document shell and hydration/bootstrap output. React resolves React DOM 19.2.0 from its participant',
'directory. Each cell below averages two reversed-order samples, with 5,000 warmups and 12,000',
'measured renders per sample. No build or test ran concurrently with timing. All samples and exact',
'eXact document-hash comparisons are retained. These are renderer timings, not HTTP requests/s.','',
'| Runtime | Mode | Document | Current production | Previous emitter | Lazy-frame emitter | React |',
'| --- | --- | --- | ---: | ---: | ---: | ---: |']
for rt in ['node','bun']:
    for mode in ['string','stream']:
        for sc in ['assets','large']:
            values=[mean(final,rt,mode,sc,k) for k in ['production','previous','native','react']]
            lines.append(f'| {rt} | {mode} | {sc} | '+' | '.join(f'{v:.2f}' for v in values)+' |')
lines += ['','Large string gaps within that final paired run:','',
'| Runtime | Previous excess time vs React | Final excess time vs React |',
'| --- | ---: | ---: |']
for rt in ['node','bun']:
    a,b,c=[mean(final,rt,'string','large',k) for k in ['previous','native','react']]
    lines.append(f'| {rt} | {(a/c-1)*100:.1f}% | {(b/c-1)*100:.1f}% |')
lines += ['',
'The emitter recovers the large Node string regression and improves the large Bun string result.',
'It still does not beat React in string rendering. Node streaming remains slower than current',
'production eXact even though it beats React. Bun\'s large streaming lead over React is modest.',
'Small string rendering remains a substantial gap, especially on Node.','',
'A separate complete run preceded the intrinsic-shadowing fixes. Its frozen artifact and all 64',
'samples are preserved, but those figures are not relabeled as measurements of the final code.','',
'## Validation and remaining work','',
'Thirteen native-emitted writer cases pass on each runtime, including interleaved requests that',
'settle in reverse order, no rereading of prepared inputs, settled character accounting, pending',
'child and final drains, rejection, and unprepared input. The two shadowing regressions also pass',
'on each runtime. The original shadowing probe wrote child output synchronously, which masked the',
'Promise-shadow failure; moving the observable child write into its pending callback exposed the',
'ordering defect before the fix. The preserved failing results use that corrected probe.','',
'The native-generated scheduled document remains byte-identical to production with and without',
'markers on both runtimes (553/747 bytes). Twelve pressure/cancellation cases cover 1-, 8-, and',
'8,192-byte thresholds, task startup, one outstanding transport write, cleanup, and hydration-tail',
'publication. Real Chromium adopts both runtimes\' marked documents without replacing elements,',
'text nodes, or the hydration script, restarting server tasks, or losing cleanup. Forty application',
'budget cases and eight consumed-stream comparisons match production. Native compiler and command',
'tests and the source-architecture check pass. Native wide-plan tests enforce one snapshot postlude.','',
'Production compiler selection and package runtime artifacts remain unchanged. The final compiler',
'emitter still needs integration into the production sink/runtime contract, including broader',
'enhancement and ownership coverage. The full-app streaming experiment still collects the document;',
'progressive publication is exercised by the separate scheduled fixture, not measured as browser',
'performance here. The objective of beating React across all comparable workloads is not met.','']
report=pathlib.Path('docs/performance-baselines/native-lazy-frame-2026-09-09.md')
report.write_text('\n'.join(lines),encoding='utf8')
files=[]
for prefix in ['native-lazy-frame','native-frame','native-before-lazy']:
    files += [p for p in d.glob(prefix+'*') if p.is_file()]
files += [d/n for n in ['native-sink-profile.mjs','native-sink-profile-results.json','native-sink-profile-summary.py','native-sink-profile-summary.json','native-sink-native.cpuprofile','native-sink-previous.cpuprofile','production-refresh-worker.mjs','application-string-deferred-sink.mjs','publication-string-sink.mjs','hydration-tail-sink.mjs','incremental-publication-pressure.mjs','incremental-publication-state-sink.mjs','publication-adoption-client.js','native-continuation-writer.js','native-continuation-terminal.js','native-continuation-audit.mjs','native-continuation-build.mjs','native-continuation-go.txt','native-continuation-node.json','native-continuation-bun.json']]
files += [p for p in d.glob('native-sink-*') if p.is_file() and p.suffix not in ['.cpuprofile']]
files += [p for p in (d/'native-sink-application').rglob('*') if p.is_file()]
files += [d/'application-string/target-methods.mjs',d/'application-string/profile-worker.mjs',pathlib.Path('.tmp/positional-leaves/data.json'),report,pathlib.Path('docs/ssr-hydration.md')]
files += [pathlib.Path('native/typescript-go/overlay/internal/exactcompiler')/n for n in ['jsx_render_program_ssr_lowering.go','jsx_render_program_ssr_plan.go','jsx_render_program_ssr_continuation.go','jsx_render_program_ssr_siblings.go','jsx_render_program_ssr_frame.go','jsx_render_program_ssr_continuation_test.go']]
for variant,entry in [('production','framework-comparison/participants/exact/dist-server/server-entry.js'),('react','framework-comparison/participants/react/dist-server/server-entry.js'),('native',str(d/'native-sink-application.mjs')),('previous',str(d/'native-before-lazy.mjs'))]:
    p=pathlib.Path(entry);digest=hashlib.sha256(p.read_bytes()).hexdigest()
    assert all(r['artifactSha256']==digest for r in final if r['variant']==variant)
    files.append(p)
assert all(r['status']==0 for r in json.loads((d/'native-sink-validation.json').read_text(encoding='utf8')))
assert all(r['result']['elementsRetained'] and not r['errors'] for r in json.loads((d/'native-sink-adoption-results.json').read_text(encoding='utf8')))
for rt in ['node','bun']:
    assert json.loads((d/f'native-continuation-{rt}.json').read_text(encoding='utf8'))['cases']==13
    assert all(r['success'] for r in json.loads((d/f'native-frame-shadow-after-{rt}.json').read_text(encoding='utf8')))
    assert all(not r['success'] for r in json.loads((d/f'native-frame-shadow-before-{rt}.json').read_text(encoding='utf8')))
    budget=json.loads((d/f'native-sink-budget-{rt}.json').read_text(encoding='utf8'))
    assert len(budget['rows'])==20 and budget['streamCases']==4
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=report.with_name(report.stem+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name in manifest:z.write(name,name)
    z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified',len(manifest),'archive hashes, all final benchmark artifacts, and recorded correctness results.')
