import pathlib,json,collections
d=pathlib.Path('.tmp/ssr-large-profile')
rows=[]
for variant in ['previous','native']:
    profile=json.loads((d/f'native-sink-{variant}.cpuprofile').read_text(encoding='utf8'))
    nodes={node['id']:node for node in profile['nodes']};weights=collections.Counter()
    for sample,delta in zip(profile['samples'],profile['timeDeltas']):
        frame=nodes[sample]['callFrame'];weights[(frame['functionName'],frame['url'],frame['lineNumber']+1)]+=delta
    total=sum(weights.values())
    top=[{'function':name,'url':url,'line':line,'milliseconds':value/1000,'percent':value*100/total} for (name,url,line),value in weights.most_common(30)]
    rows.append({'variant':variant,'sampledMilliseconds':total/1000,'top':top})
    print(variant,[(item['function'],round(item['percent'],2)) for item in top[:18]])
(d/'native-sink-profile-summary.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
