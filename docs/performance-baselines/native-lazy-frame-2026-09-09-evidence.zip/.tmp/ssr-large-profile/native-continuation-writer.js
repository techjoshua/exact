function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame = void 0) {
    let __exactValue_0, __exactValue_1, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
    if (__exactFrame) {
        __exactValue_0 = __exactFrame[6];
        __exactValue_1 = __exactFrame[7];
        __exactCharacters = __exactFrame[8];
        __exactStage = __exactFrame[4];
        __exactSettled = __exactFrame[5];
    }
    else {
        __exactValue_0 = __exactSsr.prepareChild(__exactInvocation, 0);
        if (__exactValue_0 === __exactSsr.unprepared)
            return;
        __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
        if (__exactValue_1 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 0, 2, 14, 14);
        __exactCharacters = 14;
    }
    switch (__exactStage) {
        case 0: __exactSettled = __exactSsr.static(__exactOutput, "<main>");
        case 1:
            const __exactDrain_0 = __exactOutput.sink.ready();
            if (__exactDrain_0) {
                __exactPending = __exactDrain_0;
                __exactStage = 2;
                break;
            }
        case 2:
            __exactSettled = __exactSsr.child(__exactContext, __exactOutput, __exactValue_0, "first", __exactCharacters);
            if (__exactSettled instanceof __exactSsr.promise) {
                __exactPending = __exactSettled;
                __exactStage = 3;
                break;
            }
        case 3:
            __exactCharacters = __exactSettled;
            const __exactDrain_1 = __exactOutput.sink.ready();
            if (__exactDrain_1) {
                __exactPending = __exactDrain_1;
                __exactStage = 4;
                break;
            }
        case 4: __exactSettled = __exactSsr.static(__exactOutput, "|");
        case 5:
            const __exactDrain_2 = __exactOutput.sink.ready();
            if (__exactDrain_2) {
                __exactPending = __exactDrain_2;
                __exactStage = 6;
                break;
            }
        case 6:
            __exactSettled = __exactSsr.child(__exactContext, __exactOutput, __exactValue_1, "second", __exactCharacters);
            if (__exactSettled instanceof __exactSsr.promise) {
                __exactPending = __exactSettled;
                __exactStage = 7;
                break;
            }
        case 7:
            __exactCharacters = __exactSettled;
            const __exactDrain_3 = __exactOutput.sink.ready();
            if (__exactDrain_3) {
                __exactPending = __exactDrain_3;
                __exactStage = 8;
                break;
            }
        case 8: __exactSettled = __exactSsr.static(__exactOutput, "</main>");
        case 9:
            const __exactDrain_4 = __exactOutput.sink.ready();
            if (__exactDrain_4) {
                __exactPending = __exactDrain_4;
                __exactStage = 10;
                break;
            }
        case 10: return __exactOutput;
    }
    {
        const __exactSaved = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactCharacters];
        return __exactPending.then(__exactResult => {
            __exactSaved[5] = __exactResult;
            return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
        });
    }
}