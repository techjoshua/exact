import fs from 'node:fs';
import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/';
const source=fs.readFileSync(d+'native-continuation-writer.js','utf8');
const rows=[];
for(const shadow of ['Promise','undefined']){
  const writer=new Function('Promise','undefined',`return (${source});`)(shadow==='Promise'?class AuthoredPromise{}:Promise,shadow==='undefined'?37:undefined);
  const output={text:'',sink:{ready(){}}};let starts=0;
  const operations={promise:Promise,unprepared:Symbol(),prepareChild(_invocation,index){return index;},begin(){starts++;},
    static(out,text){out.text+=text;},child(_context,out,index,_id,count){return Promise.resolve().then(()=>{out.text+=index;return count+1;});}};
  let error;
  try{assert.equal(await writer(operations,{},{},output),output);assert.equal(output.text,'<main>0|1</main>');assert.equal(starts,1);}
  catch(reason){error=reason.message;}
  rows.push({shadow,error,success:!error});
}
const phase=process.argv[2]??'after';
fs.writeFileSync(d+`native-frame-shadow-${phase}-${process.versions.bun?'bun':'node'}.json`,JSON.stringify(rows,null,2));
console.log(rows);
if(phase!=='before')assert.ok(rows.every(row=>row.success));
