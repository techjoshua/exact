import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
const run=fs.readFileSync(d+'native-sink-application-run.mjs','utf8')
  .replace("previous:d+'application-string/target-methods.mjs'","previous:d+'native-before-lazy.mjs'")
  .replace('native-sink-application-results.json','native-lazy-frame-full-results.json');
fs.writeFileSync(d+'native-lazy-frame-full-run.mjs',run);
