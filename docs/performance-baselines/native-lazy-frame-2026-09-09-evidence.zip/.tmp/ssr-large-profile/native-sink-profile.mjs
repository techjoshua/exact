import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
const d='.tmp/ssr-large-profile/';
const entries={previous:d+'application-string/target-methods.mjs',native:d+'native-sink-application.mjs'};
const rows=[];
for(const [variant,entry] of Object.entries(entries)){
  const result=spawnSync(process.execPath,[d+'application-string/profile-worker.mjs',entry,'string','large','50000'],{
    encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production',PROFILE_OUTPUT:d+`native-sink-${variant}.cpuprofile`}});
  if(result.status!==0)throw Error(result.stderr+result.stdout);
  rows.push({variant,...JSON.parse(result.stdout)});console.log(variant,rows.at(-1).usPerRender);
}
fs.writeFileSync(d+'native-sink-profile-results.json',JSON.stringify(rows,null,2));
