import fs from 'node:fs';
import ts from 'typescript';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const directory='.tmp/ssr-large-profile/';
const input=directory+'direct-list-current/server-entry.js';
let source=fs.readFileSync(input,'utf8');
const tree=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
function literal(node){
 if(ts.isStringLiteral(node)||ts.isNumericLiteral(node)||[ts.SyntaxKind.TrueKeyword,ts.SyntaxKind.FalseKeyword,ts.SyntaxKind.NullKeyword].includes(node.kind))return true;
 if(ts.isArrayLiteralExpression(node))return node.elements.every(literal);
 if(ts.isObjectLiteralExpression(node))return node.properties.every(property=>ts.isPropertyAssignment(property)&&!ts.isComputedPropertyName(property.name)&&literal(property.initializer));
 return false;
}
const edits=[];
function visit(node){
 if(ts.isCallExpression(node)&&ts.isIdentifier(node.expression)&&node.expression.text==='createPreparedServerRenderProgram'&&node.arguments.length===2&&ts.isIdentifier(node.arguments[0])&&literal(node.arguments[1])){
  const name='__staticInvocation_'+edits.length;
  edits.push({start:node.getStart(tree),end:node.end,name,expression:node.getText(tree)});
 }else ts.forEachChild(node,visit);
}
visit(tree);assert.ok(edits.length>0);
for(const edit of [...edits].reverse())source=source.slice(0,edit.start)+edit.name+source.slice(edit.end);
let instrumented=fs.readFileSync(input,'utf8');
for(const [index,edit] of [...edits.entries()].reverse())instrumented=instrumented.slice(0,edit.start)+`(__staticInvocationCounts[${index}]++, ${edit.name})`+instrumented.slice(edit.end);
const declarations='\n'+edits.map(edit=>`const ${edit.name}=${edit.expression};`).join('\n')+'\n';
source+='\n'+edits.map(edit=>`const ${edit.name}=${edit.expression};`).join('\n')+'\n';
const output=directory+'static-invocation';fs.mkdirSync(output,{recursive:true});fs.writeFileSync(output+'/server-entry.js',source);
fs.writeFileSync(output+'/instrumented-entry.js',instrumented+declarations+`\nexport const __staticInvocationCounts=Array(${edits.length}).fill(0);\n`);
fs.writeFileSync(output+'/sites.json',JSON.stringify(edits.map(edit=>({name:edit.name,expression:edit.expression})),null,2));
fs.writeFileSync(output+'/provenance.json',JSON.stringify({input,inputSha256:createHash('sha256').update(fs.readFileSync(input)).digest('hex'),outputSha256:createHash('sha256').update(source).digest('hex'),invocations:edits.length,hypothesis:'Reuse compiler-owned entirely literal server invocations, avoiding per-render carrier and slot-array allocation.'},null,2));
console.log('Hoisted invocations:',edits.length);
