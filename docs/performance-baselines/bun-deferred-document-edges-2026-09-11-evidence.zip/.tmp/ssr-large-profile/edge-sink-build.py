from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'edge-sink';root.mkdir(exist_ok=True)
source=Path('framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js').read_text();(root/'current.mjs').write_text(source)
insertion='''
class DeferredEdgeStringSink extends StringProgramSink {
 first='';middle='';last='';characters=0;
 write(html){
  if(this.closed)throw Error('SSR string sink is closed');
  if(this.characters+html.length>this.maxBytes){this.destroy();throw new SsrOutputLimitError(this.maxBytes);}
  if(!html)return;
  this.characters+=html.length;
  if(!this.first)this.first=html;else{this.middle+=this.last;this.last=html;}
 }
 finishChunks(prefix=[]){
  if(this.closed)throw Error('SSR string sink is closed');
  let hints='',characters=this.characters;for(const part of prefix){characters+=part.length;hints+=part;}
  if(characters>this.maxBytes){this.destroy();throw new SsrOutputLimitError(this.maxBytes);}
  const chunks=[hints+this.first,this.middle,this.last];
  this.destroy();
  if(characters>this.maxBytes/3){let html='';for(const part of chunks)html+=part;if(utf8ByteLength(html)>this.maxBytes)throw new SsrOutputLimitError(this.maxBytes);}
  return chunks;
 }
 finish(prefix=[]){let html='';for(const part of this.finishChunks(prefix))html+=part;return html;}
 destroy(){super.destroy();this.first='';this.middle='';this.last='';this.characters=0;}
}
'''
needle='var HeadPublishingSink = class extends StringProgramSink {';assert needle in source
c=source.replace(needle,insertion+needle)
old='new StringProgramSink(context.maxOutputBytes)';assert c.count(old)==1;c=c.replace(old,'new DeferredEdgeStringSink(context.maxOutputBytes)')
old='const chunks = [sink.finish(context.reactResourceHints)];';assert old in c;c=c.replace(old,'const chunks = sink instanceof DeferredEdgeStringSink ? sink.finishChunks(context.reactResourceHints) : [sink.finish(context.reactResourceHints)];')
old='html: chunks.length === 1 ? chunks[0] : chunks.join(""),';assert old in c;c=c.replace(old,'html: chunks.length === 1 ? chunks[0] : chunks.reduce((html, part) => html + part, ""),',1)
(root/'candidate.mjs').write_text(c)
(root/'worker.mjs').write_bytes((base/'prefix-native/worker.mjs').read_bytes())
r=(base/'prefix-native-run.mjs').read_text().replace('prefix-native/','edge-sink/').replace('large96-bun-native-prefix-experiment','large96-bun-deferred-edge-sink')
(base/'edge-sink-run.mjs').write_text(r)
