import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const rows=[];
for(const scenario of ['small','large'])for(const variant of ['exact','react']){
 const entry=variant==='exact'?'.tmp/ssr-large-profile/tail-current.mjs':'framework-comparison/participants/react/dist-server/server-entry.js';
 const output=`.tmp/ssr-large-profile/allocation-${variant}-${scenario}.heapprofile`;
 const r=spawnSync(process.execPath,['.tmp/ssr-large-profile/allocation-sample-worker.mjs',entry,scenario,output],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 rows.push({variant,...JSON.parse(r.stdout)});writeFileSync('.tmp/ssr-large-profile/allocation-samples.json',JSON.stringify(rows,null,2));console.log(variant,scenario,'complete');
}
