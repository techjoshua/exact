import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';const source=readFileSync(dir+'tail-current.mjs','utf8');
const start=source.indexOf('function executeSynchronousArtifact('),end=source.indexOf('\nfunction publishFrame(',start);
if(start<0||end<0)throw Error('Missing synchronous artifact boundary');
const replacement=`function requireSynchronousArtifactOutput(value) {
 if(value===undefined)throw new TypeError("Synchronous server artifact did not execute its request-owned sink");
 return value;
}
function executeSynchronousArtifact(execution, contract, reference, parent, props) {
 const output=executeDirectSsrComponent(execution.context,contract,props,parent,execution.options,(content,owner,preparedProps,snapshot)=>{
  const html=reference.enhancement
   ? renderOperationEnhancements(execution.context,reference.enhancement,()=>renderDirectSsrContent(execution.context,content,owner,execution.renderChildren,execution.renderOwnedComponent),owner,execution.options,(_context,children,childParent)=>execution.renderChildren(children,childParent))
   : renderDirectSsrContent(execution.context,content,owner,execution.renderChildren,execution.renderOwnedComponent);
  if(html instanceof Promise)return html.then(value=>execution.publish(execution.context,reference,parent,value,preparedProps,snapshot,execution.publication));
  return execution.publish(execution.context,reference,parent,html,preparedProps,snapshot,execution.publication);
 });
 return output instanceof Promise?output.then(requireSynchronousArtifactOutput):requireSynchronousArtifactOutput(output);
}
`;
writeFileSync(dir+'sync-callback.mjs',source.slice(0,start)+replacement+source.slice(end));
