import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';let source=readFileSync(dir+'sync-callback.mjs','utf8');
source=source.replace('  const html=reference.enhancement','  let html;\n  try { html=reference.enhancement');
const boundary='   : renderDirectSsrContent(execution.context,content,owner,execution.renderChildren,execution.renderOwnedComponent);';
if(!source.includes(boundary))throw Error('Missing direct render');
source=source.replace(boundary,boundary+'\n  } catch(error) { return Promise.reject(error); }');
writeFileSync(dir+'sync-callback-safe.mjs',source);
