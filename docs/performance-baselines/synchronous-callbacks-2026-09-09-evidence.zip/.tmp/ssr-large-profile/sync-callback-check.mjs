import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
let checks=0;
for(const kind of ['plain','enhanced'])for(const scenario of ['sync','pending','throw','reject','publish-throw']){
 const outputs=[];
 for(const variant of ['tail-current','sync-callback-safe']){
  const source=readFileSync(`.tmp/ssr-large-profile/${variant}.mjs`,'utf8');
  const start=source.indexOf(variant==='tail-current'?'function executeSynchronousArtifact(':'function requireSynchronousArtifactOutput(');
  const end=source.indexOf('\nfunction publishFrame(',start);
  const failure=new Error('expected');
  const render=()=>{if(scenario==='throw')throw failure;if(scenario==='reject')return Promise.reject(failure);return scenario==='pending'?Promise.resolve('html'):'html';};
  const execute=new Function('executeDirectSsrComponent','renderOperationEnhancements','renderDirectSsrContent','mapRenderValue',source.slice(start,end)+'\nreturn executeSynchronousArtifact;')(
   (_ctx,_contract,props,parent,_opts,sink)=>sink({},parent,props,{}),
   (_ctx,_enhance,plain)=>{try{return plain();}catch(error){return Promise.reject(error);}},
   render,(value,read)=>value instanceof Promise?value.then(read):read(value));
  const execution={context:{},options:{},publish:(_ctx,_ref,_parent,html)=>{if(scenario==='publish-throw')throw failure;return html+'!';}};
  let value,thrown;
  try {value=execute(execution,{},kind==='enhanced'?{enhancement:{}}:{},undefined,{});}catch(error){thrown=error;}
  const async=value instanceof Promise;
  if(!thrown){try{value=await value;}catch(error){thrown=error;}}
  if(thrown)assert.equal(thrown,failure);
  outputs.push({async,failed:!!thrown,value:thrown?undefined:value});
 }
 assert.deepEqual(outputs[1],outputs[0]);checks++;
}
console.log(JSON.stringify({checks,status:'passed'}));
