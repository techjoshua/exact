import json,pathlib,statistics,zipfile,hashlib
root=pathlib.Path.cwd();tmp=root/'.tmp/ssr-large-profile';base=root/'docs/performance-baselines/synchronous-callbacks-2026-09-09'
rows=json.loads((tmp/'callback-current-results.json').read_text(encoding='utf-8'));assert len(rows)==60
alloc=json.loads((tmp/'allocation-sample-summary.json').read_text(encoding='utf-8'))
summary=[]
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for size in ['small','large']:
   group=[r for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==size]
   med={v:statistics.median(r['usPerRender'] for r in group if r['variant']==v) for v in ['tail-current','callback-current','react']}
   pairs=[]
   for i in sorted({r['round'] for r in group}):
    values={r['variant']:r['usPerRender'] for r in group if r['round']==i}
    pairs.append(100*(1-values['callback-current']/values['tail-current']))
   summary.append(dict(runtime=runtime,mode=mode,size=size,previousUs=med['tail-current'],currentUs=med['callback-current'],reactUs=med['react'],pairedReductions=pairs,medianPairedReduction=statistics.median(pairs)))
base.with_suffix('.json').write_text(json.dumps(dict(summary=summary,allocations=alloc,populations=rows),indent=2)+'\n',encoding='utf-8')
table='\n'.join(f"| {s['runtime']} | {s['mode']} | {s['size']} | {s['previousUs']:.2f} | {s['currentUs']:.2f} | {s['reactUs']:.2f} | {s['medianPairedReduction']:+.1f}% |" for s in summary)
allocationTable='\n'.join(f"| {size} | {alloc['allocation-exact-'+size]['estimatedBytesPerRender']/1000:.1f} | {alloc['allocation-callback-'+size]['estimatedBytesPerRender']/1000:.1f} | {alloc['allocation-react-'+size]['estimatedBytesPerRender']/1000:.1f} |" for size in ['small','large'])
report='''# Synchronous publication callbacks, September 9, 2026

Status: implemented, validated, and retained with an explicit Bun streaming tradeoff. The overall
performance goal remains open.

## Evidence and hypothesis

Node heap allocation sampling after 5,000 warmup renders found estimated allocation of 556.5 KB
per large eXact render versus 443.7 KB for React. On small documents eXact was lower, 67.7 KB versus
74.6 KB. The largest eXact large attribution was executeSynchronousArtifact at approximately 78 KB
per render. Attribution can include inlined allocations and is not a precise count of callbacks.
These observations shifted attention from hydration alone to repeated component execution.

The synchronous publication path allocated callbacks for absent enhancements, already-completed
render output, and output validation. Hypothesis: allocating them only when needed would reduce
large render time by 2-5% without changing the shared engine or component ownership.

The first prototype bypassed the enhancement wrapper but also changed synchronous render errors
from rejected promises to throws. It was not adopted. The corrected prototype catches those render
errors and returns the same rejection, while publication failures retain their original behavior.
Ten focused isolated checks compare sync/pending output, thrown/rejected render failures, and
publication failure with and without enhancement delegation. Full integration validation follows.

## Implementation

Plain synchronous component output calls the existing renderer and publisher directly. Enhancement
callbacks are constructed only for enhanced operations; promise continuations only for pending
output. Missing-output validation uses a shared function. Synchronous publication now has its own
module, with a shared execution-context type used by scheduled artifact execution. The source
architecture check caught the original enlarged module, prompting this separation by responsibility.

No API, ABI, hydration format, task scheduling, cancellation, or output-limit contract changes.
Engineering documentation explains the execution behavior. Public docs and historical performance
charts are unchanged because no public behavior or full benchmark baseline changed.

## Rebuilt renderer comparison

Sixty fresh sequential production processes compare the retained document-tail build, rebuilt
callback build, and React. Each population warms 5,000 renders and measures 12,000. Large cases
have 96 incidents and rotate all three positions over three rounds; small cases have 3 incidents
and two rotations, which are not fully position-balanced. Both runtimes use the same portable
renderer bundle. Streams are fully consumed via Response.text. Applications render their complete
document shells with empty asset tags. Every eXact population verifies document framing and its
final complete-response hash against the previous artifact.

Median microseconds per complete render, lower is better. Paired reduction is the median of
per-round percentage reductions versus previous eXact, not a ratio of independent medians.

| Runtime | Mode | Size | Previous eXact | Current eXact | React | Paired reduction |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
'''+table+'''

The change is retained for reduced allocation volume and consistent Node/string improvements.
Large median paired reductions are 4.7% for Node strings, 2.9% for Node streams, and 6.1% for Bun
strings. Large Bun streams regress by a median paired 0.8%; all three pairs are slower, including
one 12.6% outlier. Small Bun streaming has one 9.6% regression and one essentially unchanged pair.
The accepted tradeoff must remain visible, and further work should investigate it rather than
claim a universal improvement. Small Bun strings have a large noisy control outlier, so the apparent
12.3% paired improvement is not a precise effect estimate.

Current eXact remains behind React on strings and large Bun streams. It leads on Node streams;
small Bun streams are close in this capture. These results do not satisfy the complete goal.

These short shared-PC measurements are not confidence intervals, HTTP throughput, or browser
timings. The full objective cannot be declared complete from these renderer samples alone.

## Allocation follow-up

Estimated KB allocated per Node string render (decimal KB):

| Size | Previous eXact | Current eXact | React |
| --- | ---: | ---: | ---: |
'''+allocationTable+'''

The inspector sampled at 16,384-byte intervals across 10,000 renders after warmup, including objects
collected by minor and major GC. These are allocation-volume estimates, not retained heap, peak
memory, or leak measurements. Samples were collected separately from timing. Source attribution
and sampling variance limit conclusions about individual allocation sites.

## Validation and reproduction

All 282 SSR tests, test type checking, 56 production browser checks across both runtimes/modes,
affected-file lint, architecture, JSDoc, explicit-any, platform boundaries, compiled/frozen ABI,
and package contents pass. New public-render regressions verify disposal after an output-limit
failure and preservation of a publication failure while disposing the synchronous component.
Existing tests cover pending children, enhancements, and primary-error/cleanup precedence.

The evidence ZIP includes before/current/React bundles, the two prototypes, scripts, fixed input,
raw timings, allocation profiles and summaries, source snapshots, and passing validation logs.
The initial prototype's results are retained as exploratory evidence, not as results of the
corrected implementation. All benchmark and browser process ownership is released after capture.
'''
base.with_suffix('.md').write_text(report,encoding='utf-8')
files=[base.with_suffix('.md'),base.with_suffix('.json')]
files+=list(tmp.glob('allocation-*.heapprofile'))
files+=[tmp/n for n in ['allocation-sample-worker.mjs','allocation-sample-run.mjs','allocation-sample-summary.py','allocation-samples.json','allocation-sample-summary.json','allocation-callback-large.json','allocation-callback-small.json','tail-current.mjs','callback-current.mjs','sync-callback.mjs','sync-callback-safe.mjs','sync-callback-build.mjs','sync-callback-safe-build.mjs','sync-callback-check.mjs','sync-callback-check.log','sync-callback-results.json','sync-callback-safe-results.json','sync-callback-run.mjs','sync-callback-safe-run.mjs','callback-current-run.mjs','callback-current-results.json','callback-report.py','callback-checks.mjs','long-worker.mjs','browser.mjs']]
files+=list(tmp.glob('callback-*.log'))
files+=[tmp/f'browser-{runtime}-{mode}.log' for runtime in ['node','bun'] for mode in ['string','stream']]
files+=[root/p for p in ['.tmp/positional-leaves/data.json','framework-comparison/participants/react/dist-server/server-entry.js','framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js','packages/ssr/src/render/server-component-abi-execution.ts','packages/ssr/src/render/server-artifact-context.ts','packages/ssr/src/render/synchronous-artifact.ts','packages/ssr/src/component-rendering.test.ts','docs/ssr-hydration.md']]
archive=base.parent/(base.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(root).as_posix())
 z.writestr('sha256.json',json.dumps({p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 print(json.dumps(dict(files=len(z.namelist()),bytes=archive.stat().st_size,summary=summary,allocationTable=allocationTable),indent=2))
