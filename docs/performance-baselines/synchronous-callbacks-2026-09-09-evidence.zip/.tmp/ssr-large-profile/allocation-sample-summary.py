import json,pathlib,collections
root=pathlib.Path('.tmp/ssr-large-profile');result={}
for path in root.glob('allocation-*.heapprofile'):
 p=json.loads(path.read_text(encoding='utf-8'));allocations=collections.Counter()
 def visit(node):
  frame=node['callFrame'];key=(frame.get('functionName') or '(anonymous)',frame.get('url',''),frame.get('lineNumber',0)+1)
  allocations[key]+=node.get('selfSize',0)
  for child in node.get('children',[]):visit(child)
 visit(p['head']);total=sum(allocations.values())
 rows=[dict(function=k[0],url=k[1],line=k[2],estimatedBytes=v,bytesPerRender=v/10000,percent=100*v/total) for k,v in allocations.most_common(20)]
 result[path.stem]=dict(estimatedBytes=total,estimatedBytesPerRender=total/10000,top=rows)
 print(path.stem,round(total/10000),[(r['function'],r['line'],round(r['bytesPerRender'])) for r in rows[:12]])
(root/'allocation-sample-summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
