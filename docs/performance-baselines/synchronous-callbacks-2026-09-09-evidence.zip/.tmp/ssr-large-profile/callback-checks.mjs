﻿import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const commands=[
 ['eslint','node node_modules/eslint/bin/eslint.js packages/ssr/src/render/server-component-abi-execution.ts packages/ssr/src/component-rendering.test.ts packages/ssr/src/render/server-artifact-context.ts packages/ssr/src/render/synchronous-artifact.ts'],
 ['architecture','npm.cmd run check:source-architecture'],
 ['jsdoc','npm.cmd run check:jsdoc'],
 ['explicit-any','npm.cmd run check:explicit-any'],
 ['platform','npm.cmd run check:platform-boundaries'],
 ['compiled-abi','node scripts/check-compiled-abi.mjs'],
 ['release-abi','node scripts/check-release-abi.mjs'],
 ['package-contents','npm.cmd exec -- node scripts/check-package-contents.mjs'],
 ['browser','node .tmp/ssr-large-profile/browser.mjs'],
];
for(const [name,command] of commands){
 const r=spawnSync(command,{shell:true,encoding:'utf8',windowsHide:true,env:process.env});
 writeFileSync(`.tmp/ssr-large-profile/callback-${name}.log`,r.stdout+'\n'+r.stderr);
 console.log(name,r.status);if(r.status!==0)process.exit(r.status??1);
}



