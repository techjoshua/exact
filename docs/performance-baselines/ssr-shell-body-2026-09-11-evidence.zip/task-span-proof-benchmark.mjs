import {readFile,writeFile} from 'node:fs/promises';
import {performance} from 'node:perf_hooks';
import assert from 'node:assert/strict';
const code=await readFile('.tmp/ssr-completion/task-span-trace.compiled.mjs','utf8');
assert.equal((code.match(/documentRoot: true/g)||[]).length,2);
await writeFile('.tmp/ssr-completion/task-span-trace-unproven.mjs',code.replace(/\s*documentRoot: true,/,''));
const candidates={unproven:await import('./task-span-trace-unproven.mjs'),proven:await import('./task-span-trace.compiled.mjs')};
const report=[]; let expected;
async function once(candidate){
 candidate.reset(); const stream=candidate.start(false);const reader=stream.getReader();const release=setImmediate(()=>candidate.settle());let html='';
 try {for(;;){const next=await reader.read();if(next.done)break;html+=new TextDecoder().decode(next.value);}}
 finally {clearImmediate(release);candidate.settle();await reader.cancel();reader.releaseLock();}
 if(expected===undefined)expected=html;else assert.equal(html,expected);
 const events=candidate.trace();return events.filter(e=>e.startsWith('read:')).length;
}
for(const candidate of Object.values(candidates))for(let n=0;n<5000;n++)await once(candidate);
for(let population=0;population<2;population++)for(const id of population?['proven','unproven']:['unproven','proven']){
 const candidate=candidates[id];for(let n=0;n<1000;n++)await once(candidate);
 const start=performance.now();let reads=0;const iterations=10000;for(let n=0;n<iterations;n++)reads+=await once(candidate);
 const elapsedMs=performance.now()-start;report.push({id,population,iterations,elapsedMs,usPerRender:elapsedMs*1000/iterations,reads});
 console.log(report.at(-1));
}
await writeFile('.tmp/ssr-completion/task-span-proof-benchmark.json',JSON.stringify({kind:'serial gated document rendering, no HTTP',report},null,2));
