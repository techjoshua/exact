import { createPreparedServerComponentReference as __exactComponentReceipt, createPreparedServerRenderProgram as __exactPreparedServerRenderProgram, prepareCompiledRenderProgram as __exactPrepareRenderProgram, createExpression as __exactExpression, createCompiledChildRangeReceipt as __exactDynamic } from "@exactjs/core/framework/server-render-structure";
import { issueServerComponentReceipt as __exactIssueServerComponent, awaitServerComponentTask as __exactServerTaskAwait, activateServerComponentTaskForHost as __exactActivateServerTask } from "@exactjs/core/framework/server-component-execution";
import { renderToHydratableProgressiveHtmlStream } from "@exactjs/ssr";
import { issueExactServerComponent as __exactIssueServerComponent_1, writeExactServerComponent as __exactWriteServerComponent_1, disposeExactServerComponent as __exactDisposeServerComponent_1 } from "@exactjs/core/runtime/component-operations";
import { rejectDirectServerComponentConstruction as __exactRejectDirectServerConstruction_1 } from "@exactjs/core/runtime/component-construction/direct-server";
const __exactComponentContract_1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
const __exact_server_task_slice_1 = [[], [[0, ["value"]]], "blocking", "load"];
const __exact_server_task_slice_2 = [[], [[0, ["value"]]], "blocking", "load"];
const __exact_render_program_1 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xpMhGFZ2_nXiK6v-v1VLVHo", namespace: "html", ssrRootStatic: [' data-exact-id="x_ZxpMviV1h3QB117D4WKVo"', ["data-exact-id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
  const __exactValue_0 = __exactInvocation.eagerValues[0];
  __exactSsr.begin(__exactContext, 3, 1, 78, 78);
  let __exactCharacters = 78;
  __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "head", "<head", '><title>Static head</title><link rel="stylesheet" href="/app.css"></head>', __exactCharacters, __exactInvocation.program.ssrRootStatic);
  const __exactDrain = __exactOutput.sink.ready();
  if (__exactDrain)
    return __exactDrain.then(() => __exactOutput);
  return __exactOutput;
}, ssrHost: "head" });
const __exact_server_invocation_1 = /* @__PURE__ */ __exactPreparedServerRenderProgram(__exact_render_program_1, [{ "data-exact-id": "x_ZxpMviV1h3QB117D4WKVo" }]);
const __exact_render_program_2 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xQdovbq8Ex2gcgdEhkqsphK", namespace: "html", ssrRootStatic: ["", [], []], ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
  let __exactValue_0, __exactValue_1, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
  if (__exactFrame) {
    __exactValue_0 = __exactFrame[6];
    __exactValue_1 = __exactFrame[7];
    __exactCharacters = __exactFrame[8];
    __exactStage = __exactFrame[4];
    __exactSettled = __exactFrame[5];
  } else {
    __exactValue_0 = __exactInvocation.eagerValues[0];
    __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
    if (__exactValue_1 === __exactSsr.unprepared)
      return;
    __exactSsr.begin(__exactContext, 1, 2, 13, 13);
    __exactCharacters = 13;
  }
  switch (__exactStage) {
    case 0:
      __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "main", "<main", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
    case 1:
      __exactCharacters = __exactSettled;
      const __exactDrain_0 = __exactOutput.sink.ready();
      if (__exactDrain_0) {
        __exactPending = __exactDrain_0;
        __exactStage = 2;
        break;
      }
    case 2:
      __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "", "</main>");
    case 3:
      __exactCharacters = __exactSettled;
      const __exactDrain_1 = __exactOutput.sink.ready();
      if (__exactDrain_1) {
        __exactPending = __exactDrain_1;
        __exactStage = 4;
        break;
      }
    case 4:
      return __exactOutput;
  }
  {
    const __exactSaved = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactCharacters];
    return __exactPending.then((__exactResult) => {
      __exactSaved[5] = __exactResult;
      return __exactRun(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
    });
  }
}, ssrHost: "main" });
const __exact_render_program_3 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "x0KlUH-pMz6EG_cd2DwAb3y", namespace: "html", ssrRootStatic: [' data-exact-id="xc82FvweYRflSznrCsQR-Oh"', ["data-exact-id"], []], ssr: function __exactRun2(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
  let __exactValue_0, __exactValue_1, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
  if (__exactFrame) {
    __exactValue_0 = __exactFrame[6];
    __exactValue_1 = __exactFrame[7];
    __exactCharacters = __exactFrame[8];
    __exactStage = __exactFrame[4];
    __exactSettled = __exactFrame[5];
  } else {
    __exactValue_0 = __exactInvocation.eagerValues[0];
    __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
    if (__exactValue_1 === __exactSsr.unprepared)
      return;
    __exactSsr.begin(__exactContext, 1, 2, 13, 13);
    __exactCharacters = 13;
  }
  switch (__exactStage) {
    case 0:
      __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "body", "<body", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
    case 1:
      __exactCharacters = __exactSettled;
      const __exactDrain_0 = __exactOutput.sink.ready();
      if (__exactDrain_0) {
        __exactPending = __exactDrain_0;
        __exactStage = 2;
        break;
      }
    case 2:
      __exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_1);
      if (__exactSettled instanceof __exactSsr.promise) {
        __exactPending = __exactSettled;
        __exactStage = 3;
        break;
      }
    case 3:
      const __exactDrain_1 = __exactOutput.sink.ready();
      if (__exactDrain_1) {
        __exactPending = __exactDrain_1;
        __exactStage = 4;
        break;
      }
    case 4:
      __exactSettled = __exactSsr.static(__exactOutput, "</body>", 0);
    case 5:
      const __exactDrain_2 = __exactOutput.sink.ready();
      if (__exactDrain_2) {
        __exactPending = __exactDrain_2;
        __exactStage = 6;
        break;
      }
    case 6:
      return __exactOutput;
  }
  {
    const __exactSaved = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactCharacters];
    return __exactPending.then((__exactResult) => {
      __exactSaved[5] = __exactResult;
      return __exactRun2(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
    });
  }
}, ssrHost: "body" });
const __exact_render_program_4 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xTyKiJL0EAQo3jK2Z0DGxVo", namespace: "html", ssrRootStatic: [' data-exact-id="x5mL5cs3-ZafP_vduxGMT9F"', ["data-exact-id"], []], ssr: function __exactRun3(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
  let __exactValue_0, __exactValue_1, __exactValue_2, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
  if (__exactFrame) {
    __exactValue_0 = __exactFrame[6];
    __exactValue_1 = __exactFrame[7];
    __exactValue_2 = __exactFrame[8];
    __exactCharacters = __exactFrame[9];
    __exactStage = __exactFrame[4];
    __exactSettled = __exactFrame[5];
  } else {
    __exactValue_0 = __exactInvocation.eagerValues[0];
    __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
    if (__exactValue_1 === __exactSsr.unprepared)
      return;
    __exactValue_2 = __exactSsr.prepareChild(__exactInvocation, 2);
    if (__exactValue_2 === __exactSsr.unprepared)
      return;
    __exactSsr.begin(__exactContext, 1, 3, 13, 13);
    __exactCharacters = 13;
  }
  switch (__exactStage) {
    case 0:
      __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "html", "<html", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
    case 1:
      __exactCharacters = __exactSettled;
      const __exactDrain_0 = __exactOutput.sink.ready();
      if (__exactDrain_0) {
        __exactPending = __exactDrain_0;
        __exactStage = 2;
        break;
      }
    case 2:
      __exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_1);
      if (__exactSettled instanceof __exactSsr.promise) {
        __exactPending = __exactSettled;
        __exactStage = 3;
        break;
      }
    case 3:
      const __exactDrain_1 = __exactOutput.sink.ready();
      if (__exactDrain_1) {
        __exactPending = __exactDrain_1;
        __exactStage = 4;
        break;
      }
    case 4:
      __exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_2);
      if (__exactSettled instanceof __exactSsr.promise) {
        __exactPending = __exactSettled;
        __exactStage = 5;
        break;
      }
    case 5:
      const __exactDrain_2 = __exactOutput.sink.ready();
      if (__exactDrain_2) {
        __exactPending = __exactDrain_2;
        __exactStage = 6;
        break;
      }
    case 6:
      __exactSettled = __exactSsr.static(__exactOutput, "</html>");
    case 7:
      const __exactDrain_3 = __exactOutput.sink.ready();
      if (__exactDrain_3) {
        __exactPending = __exactDrain_3;
        __exactStage = 8;
        break;
      }
    case 8:
      return __exactOutput;
  }
  {
    const __exactSaved = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactValue_2, __exactCharacters];
    return __exactPending.then((__exactResult) => {
      __exactSaved[5] = __exactResult;
      return __exactRun3(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
    });
  }
}, ssrHost: "html" });
const __exact_render_program_5 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xP7NViNzceKy0hgite_R_qS", namespace: "html", ssrRootStatic: ["", [], []], ssr: function __exactRun4(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
  let __exactValue_0, __exactValue_1, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
  if (__exactFrame) {
    __exactValue_0 = __exactFrame[6];
    __exactValue_1 = __exactFrame[7];
    __exactCharacters = __exactFrame[8];
    __exactStage = __exactFrame[4];
    __exactSettled = __exactFrame[5];
  } else {
    __exactValue_0 = __exactInvocation.eagerValues[0];
    __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
    if (__exactValue_1 === __exactSsr.unprepared)
      return;
    __exactSsr.begin(__exactContext, 1, 2, 13, 13);
    __exactCharacters = 13;
  }
  switch (__exactStage) {
    case 0:
      __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "main", "<main", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
    case 1:
      __exactCharacters = __exactSettled;
      const __exactDrain_0 = __exactOutput.sink.ready();
      if (__exactDrain_0) {
        __exactPending = __exactDrain_0;
        __exactStage = 2;
        break;
      }
    case 2:
      __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "", "</main>");
    case 3:
      __exactCharacters = __exactSettled;
      const __exactDrain_1 = __exactOutput.sink.ready();
      if (__exactDrain_1) {
        __exactPending = __exactDrain_1;
        __exactStage = 4;
        break;
      }
    case 4:
      return __exactOutput;
  }
  {
    const __exactSaved = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactCharacters];
    return __exactPending.then((__exactResult) => {
      __exactSaved[5] = __exactResult;
      return __exactRun4(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
    });
  }
}, ssrHost: "main" });
const __exact_render_program_6 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xbHPahMe4_kDAnRhx_jKCAk", namespace: "html", ssrRootStatic: [' data-exact-id="xVf2-oQzhT9T8XVnCZjnHoJ"', ["data-exact-id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
  const __exactValue_0 = __exactInvocation.eagerValues[0];
  __exactSsr.begin(__exactContext, 3, 1, 78, 78);
  let __exactCharacters = 78;
  __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "head", "<head", '><title>Static head</title><link rel="stylesheet" href="/app.css"></head>', __exactCharacters, __exactInvocation.program.ssrRootStatic);
  const __exactDrain = __exactOutput.sink.ready();
  if (__exactDrain)
    return __exactDrain.then(() => __exactOutput);
  return __exactOutput;
}, ssrHost: "head" });
const __exact_server_invocation_2 = /* @__PURE__ */ __exactPreparedServerRenderProgram(__exact_render_program_6, [{ "data-exact-id": "xVf2-oQzhT9T8XVnCZjnHoJ" }]);
const __exact_render_program_7 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xsUqpJJS1X1PS65CBddoFwn", namespace: "html", ssrRootStatic: [' data-exact-id="xL2VkEbk0en7C78WiCfG9GT"', ["data-exact-id"], []], ssr: function __exactRun5(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
  let __exactValue_0, __exactValue_1, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
  if (__exactFrame) {
    __exactValue_0 = __exactFrame[6];
    __exactValue_1 = __exactFrame[7];
    __exactCharacters = __exactFrame[8];
    __exactStage = __exactFrame[4];
    __exactSettled = __exactFrame[5];
  } else {
    __exactValue_0 = __exactInvocation.eagerValues[0];
    __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
    if (__exactValue_1 === __exactSsr.unprepared)
      return;
    __exactSsr.begin(__exactContext, 1, 2, 13, 13);
    __exactCharacters = 13;
  }
  switch (__exactStage) {
    case 0:
      __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "body", "<body", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
    case 1:
      __exactCharacters = __exactSettled;
      const __exactDrain_0 = __exactOutput.sink.ready();
      if (__exactDrain_0) {
        __exactPending = __exactDrain_0;
        __exactStage = 2;
        break;
      }
    case 2:
      __exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_1);
      if (__exactSettled instanceof __exactSsr.promise) {
        __exactPending = __exactSettled;
        __exactStage = 3;
        break;
      }
    case 3:
      const __exactDrain_1 = __exactOutput.sink.ready();
      if (__exactDrain_1) {
        __exactPending = __exactDrain_1;
        __exactStage = 4;
        break;
      }
    case 4:
      __exactSettled = __exactSsr.static(__exactOutput, "</body>", 0);
    case 5:
      const __exactDrain_2 = __exactOutput.sink.ready();
      if (__exactDrain_2) {
        __exactPending = __exactDrain_2;
        __exactStage = 6;
        break;
      }
    case 6:
      return __exactOutput;
  }
  {
    const __exactSaved = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactCharacters];
    return __exactPending.then((__exactResult) => {
      __exactSaved[5] = __exactResult;
      return __exactRun5(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
    });
  }
}, ssrHost: "body" });
const __exact_render_program_8 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "x6ZLOS9Wr-wQ_h222Gf1RaO", namespace: "html", ssrRootStatic: [' data-exact-id="xc5sOnbJiyvN6V8ualTmbT-"', ["data-exact-id"], []], ssr: function __exactRun6(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame) {
  let __exactValue_0, __exactValue_1, __exactValue_2, __exactCharacters, __exactStage = 0, __exactSettled, __exactPending;
  if (__exactFrame) {
    __exactValue_0 = __exactFrame[6];
    __exactValue_1 = __exactFrame[7];
    __exactValue_2 = __exactFrame[8];
    __exactCharacters = __exactFrame[9];
    __exactStage = __exactFrame[4];
    __exactSettled = __exactFrame[5];
  } else {
    __exactValue_0 = __exactInvocation.eagerValues[0];
    __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
    if (__exactValue_1 === __exactSsr.unprepared)
      return;
    __exactValue_2 = __exactSsr.prepareChild(__exactInvocation, 2);
    if (__exactValue_2 === __exactSsr.unprepared)
      return;
    __exactSsr.begin(__exactContext, 1, 3, 13, 13);
    __exactCharacters = 13;
  }
  switch (__exactStage) {
    case 0:
      __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "html", "<html", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
    case 1:
      __exactCharacters = __exactSettled;
      const __exactDrain_0 = __exactOutput.sink.ready();
      if (__exactDrain_0) {
        __exactPending = __exactDrain_0;
        __exactStage = 2;
        break;
      }
    case 2:
      __exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_1);
      if (__exactSettled instanceof __exactSsr.promise) {
        __exactPending = __exactSettled;
        __exactStage = 3;
        break;
      }
    case 3:
      const __exactDrain_1 = __exactOutput.sink.ready();
      if (__exactDrain_1) {
        __exactPending = __exactDrain_1;
        __exactStage = 4;
        break;
      }
    case 4:
      __exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_2);
      if (__exactSettled instanceof __exactSsr.promise) {
        __exactPending = __exactSettled;
        __exactStage = 5;
        break;
      }
    case 5:
      const __exactDrain_2 = __exactOutput.sink.ready();
      if (__exactDrain_2) {
        __exactPending = __exactDrain_2;
        __exactStage = 6;
        break;
      }
    case 6:
      __exactSettled = __exactSsr.static(__exactOutput, "</html>");
    case 7:
      const __exactDrain_3 = __exactOutput.sink.ready();
      if (__exactDrain_3) {
        __exactPending = __exactDrain_3;
        __exactStage = 8;
        break;
      }
    case 8:
      return __exactOutput;
  }
  {
    const __exactSaved = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactValue_2, __exactCharacters];
    return __exactPending.then((__exactResult) => {
      __exactSaved[5] = __exactResult;
      return __exactRun6(__exactSaved[0], __exactSaved[1], __exactSaved[2], __exactSaved[3], __exactSaved);
    });
  }
}, ssrHost: "html" });
let events = [];
let gate;
let release;
function reset() {
  events = [];
  gate = new Promise((resolve) => {
    release = resolve;
  });
}
function settle() {
  events.push("release");
  release();
}
function trace() {
  return [...events];
}
function read(value) {
  events.push("read:" + value);
  return value;
}
const __exactImplementation_DocumentTask_1 = function DocumentTask() {
  this.state.value = "pending";
  __exactActivateServerTask(this, __exact_server_task_slice_1, "x2uHvP0IW82amcDsZL97hf1", async (_task) => {
    events.push("task-start");
    await __exactServerTaskAwait(_task.signal, gate);
    this.state.value = "ready";
    events.push("task-complete");
  });
  return () => __exactPreparedServerRenderProgram(__exact_render_program_4, [{ "data-exact-id": "x5mL5cs3-ZafP_vduxGMT9F" }, __exact_server_invocation_1, __exactPreparedServerRenderProgram(__exact_render_program_3, [], void 0, { host: this, read: () => [{ "data-exact-id": "xc82FvweYRflSznrCsQR-Oh" }, __exactPreparedServerRenderProgram(__exact_render_program_2, [{}, this.state.value])] })]);
};
const DocumentTask2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_DocumentTask_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "xbOrQWojscfsAJZ9xJzDwnP",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "server",
    role: "executor",
    implementations: [
      { id: "xnoE3fV4ptAOLUH4PCACvC2", name: "DocumentTask", role: "root", implementation: __exactImplementation_DocumentTask_1 }
    ],
    continuations: [
      {
        kind: "task",
        id: "x2uHvP0IW82amcDsZL97hf1",
        componentId: "xbOrQWojscfsAJZ9xJzDwnP",
        readiness: "blocking",
        concurrency: "latest",
        dependencies: [],
        stateReads: [],
        stateWrites: [
          {
            path: "value",
            kind: "write",
            confidence: "exact"
          }
        ],
        publicContexts: [],
        serverContexts: [],
        contextWrites: [],
        serverContextWrites: [],
        boundaries: []
      }
    ],
    executors: [
      {
        id: "x2uHvP0IW82amcDsZL97hf1",
        componentId: "xbOrQWojscfsAJZ9xJzDwnP",
        execute: async (__exactActivation_1, __exactExecution_1) => {
          const __exactComponent_1 = { state: __exactActivation_1.state };
          const __exactContextWrites_1 = {};
          await (async (_task) => {
            events.push("task-start");
            await __exactServerTaskAwait(_task.signal, gate);
            __exactComponent_1.state.value = "ready";
            events.push("task-complete");
          })(__exactExecution_1.task);
          return { state: __exactComponent_1.state, contexts: __exactContextWrites_1 };
        }
      }
    ],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "xbOrQWojscfsAJZ9xJzDwnP",
      instantiate: __exactImplementation_DocumentTask_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 9,
      capabilities: [
        "tasks",
        "continuations"
      ],
      state: [
        "value"
      ],
      props: [],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "scheduled",
        lane: "direct",
        documentRoot: true,
        streamingDocument: true,
        render: __exactImplementation_DocumentTask_1
      },
      tasks: [
        "x2uHvP0IW82amcDsZL97hf1"
      ],
      reactive: [
        {
          name: "load",
          provenance: "unknown",
          allocation: "constant",
          dependencies: []
        },
        {
          name: "this",
          provenance: "state",
          allocation: "live-slot",
          dependencies: []
        }
      ],
      render: "returned-function"
    }
  }
}))();
const __exactImplementation_ApplicationTask_1 = function ApplicationTask() {
  this.state.value = "pending";
  __exactActivateServerTask(this, __exact_server_task_slice_2, "xa428YuGuFeBGTummEeMdmR", async (_task) => {
    events.push("task-start");
    await __exactServerTaskAwait(_task.signal, gate);
    this.state.value = "ready";
    events.push("task-complete");
  });
  return () => __exactPreparedServerRenderProgram(__exact_render_program_5, [{}, read(this.state.value)]);
};
const ApplicationTask2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_ApplicationTask_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "x-oPSpfa6gJBybOwjUk6Zix",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "server",
    role: "executor",
    implementations: [
      { id: "x5p4Y_s0JJewdrbMqZbhat0", name: "ApplicationTask", role: "root", implementation: __exactImplementation_ApplicationTask_1 }
    ],
    continuations: [
      {
        kind: "task",
        id: "xa428YuGuFeBGTummEeMdmR",
        componentId: "x-oPSpfa6gJBybOwjUk6Zix",
        readiness: "blocking",
        concurrency: "latest",
        dependencies: [],
        stateReads: [],
        stateWrites: [
          {
            path: "value",
            kind: "write",
            confidence: "exact"
          }
        ],
        publicContexts: [],
        serverContexts: [],
        contextWrites: [],
        serverContextWrites: [],
        boundaries: []
      }
    ],
    executors: [
      {
        id: "xa428YuGuFeBGTummEeMdmR",
        componentId: "x-oPSpfa6gJBybOwjUk6Zix",
        execute: async (__exactActivation_2, __exactExecution_2) => {
          const __exactComponent_2 = { state: __exactActivation_2.state };
          const __exactContextWrites_2 = {};
          await (async (_task) => {
            events.push("task-start");
            await __exactServerTaskAwait(_task.signal, gate);
            __exactComponent_2.state.value = "ready";
            events.push("task-complete");
          })(__exactExecution_2.task);
          return { state: __exactComponent_2.state, contexts: __exactContextWrites_2 };
        }
      }
    ],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "x-oPSpfa6gJBybOwjUk6Zix",
      instantiate: __exactImplementation_ApplicationTask_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 9,
      capabilities: [
        "tasks",
        "continuations"
      ],
      state: [
        "value"
      ],
      props: [],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "scheduled",
        lane: "direct",
        render: __exactImplementation_ApplicationTask_1
      },
      tasks: [
        "xa428YuGuFeBGTummEeMdmR"
      ],
      reactive: [
        {
          name: "load",
          provenance: "unknown",
          allocation: "constant",
          dependencies: []
        },
        {
          name: "this",
          provenance: "state",
          allocation: "live-slot",
          dependencies: []
        }
      ],
      render: "returned-function"
    }
  }
}))();
const __exactImplementation_DocumentShell_1 = function DocumentShell(props) {
  return __exactPreparedServerRenderProgram(__exact_render_program_8, [{ "data-exact-id": "xc5sOnbJiyvN6V8ualTmbT-" }, __exact_server_invocation_2, __exactPreparedServerRenderProgram(__exact_render_program_7, [{ "data-exact-id": "xL2VkEbk0en7C78WiCfG9GT" }, __exactDynamic(() => props.children, "xxnfNGk_3fD0w2_w6he0BE7")])]);
};
const DocumentShell2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_DocumentShell_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "x9Ibo3NodYJsGXpThGpSS8T",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "executor",
    implementations: [
      { id: "xv9MUtJKSR4RybuPRfXnmEq", name: "DocumentShell", role: "root", implementation: __exactImplementation_DocumentShell_1 }
    ],
    continuations: [],
    executors: [],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "x9Ibo3NodYJsGXpThGpSS8T",
      instantiate: __exactImplementation_DocumentShell_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 1,
      capabilities: [],
      state: [],
      props: [
        "children"
      ],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "synchronous",
        lane: "direct",
        documentRoot: true,
        render: __exactImplementation_DocumentShell_1,
        mode: "stateless"
      },
      tasks: [],
      reactive: [
        {
          name: "props",
          provenance: "props",
          allocation: "live-slot",
          dependencies: []
        }
      ],
      render: "returned-function"
    }
  }
}))();
function start(separate) {
  return separate ? renderToHydratableProgressiveHtmlStream(__exactIssueServerComponent(__exactComponentReceipt(ApplicationTask2, {})), { documentShell: (app) => __exactComponentReceipt(DocumentShell2, {}, __exactExpression(() => app)) }) : renderToHydratableProgressiveHtmlStream(__exactIssueServerComponent(__exactComponentReceipt(DocumentTask2, {})));
}
export {
  reset,
  settle,
  start,
  trace
};
