import {createServer} from 'node:http';
import {Readable} from 'node:stream';
import {pipeline} from 'node:stream/promises';
import {once} from 'node:events';
import {performance} from 'node:perf_hooks';
import {writeFile} from 'node:fs/promises';
import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import {start,reset,settle,trace} from './task-region-trace.compiled.mjs';
let timer,browser,cssBeforeRelease=false,cssMs,releaseMs,startMs;const failures=[];
const server=createServer((request,response)=>{
 if(request.url==='/app.css') {cssMs=performance.now()-startMs;cssBeforeRelease=!trace().includes('release');response.setHeader('content-type','text/css');response.end('body{background:rgb(240,245,250)}');return;}
 if(request.url!=='/') {response.writeHead(404).end();return;}
 reset();startMs=performance.now();timer=setTimeout(()=>{releaseMs=performance.now()-startMs;settle();},250);
 response.setHeader('content-type','text/html; charset=utf-8');
 pipeline(Readable.fromWeb(start(false)),response).catch(error=>failures.push(String(error)));
});
try {
 server.listen(0,'127.0.0.1');await once(server,'listening');
 browser=await chromium.launch();const page=await browser.newPage();await page.goto('http://127.0.0.1:'+server.address().port,{waitUntil:'load'});
 assert.equal(await page.locator('main').innerText(),'ready');assert.equal(cssBeforeRelease,true);assert.deepEqual(failures,[]);
 assert.equal(await page.locator('body').evaluate(el=>getComputedStyle(el).backgroundColor),'rgb(240, 245, 250)');
 const result={cssBeforeRelease,cssMs,releaseMs,taskEvents:trace()};await writeFile('.tmp/ssr-completion/task-region-browser.json',JSON.stringify(result,null,2));console.log(result);
} finally {clearTimeout(timer);settle();await browser?.close();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}

