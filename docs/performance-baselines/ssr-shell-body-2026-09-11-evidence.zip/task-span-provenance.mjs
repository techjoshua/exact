import {writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {measureSsrArtifact} from '../../framework-comparison/src/ssr-run-environment.mjs';
const artifacts={};for(const name of ['core','ssr'])artifacts[name]=await measureSsrArtifact(resolve('packages/'+name+'/dist'));
await writeFile('.tmp/ssr-completion/task-span-runtime-artifacts.json',JSON.stringify({createdAt:new Date().toISOString(),node:process.version,artifacts},null,2));
