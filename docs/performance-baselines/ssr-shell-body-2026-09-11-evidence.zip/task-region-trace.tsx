import { TaskContext, type Component, type Child } from '@exactjs/core';
import { renderToHydratableProgressiveHtmlStream } from '@exactjs/ssr';
let events: string[] = [];
let gate: Promise<void>;
let release: () => void;
export function reset() { events = []; gate = new Promise<void>(resolve => { release = resolve; }); }
export function settle() { events.push('release'); release(); }
export function trace() { return [...events]; }
function read(value: string) { events.push('read:' + value); return value; }
function DocumentTask(this: Component<{value:string}>) {
 this.state.value = 'pending';
 const load = async (_task: TaskContext = TaskContext.server().blocking()) => {
  events.push('task-start'); await gate; this.state.value = 'ready'; events.push('task-complete');
 };
 load();
 return () => <html><head><title>Static head</title><link rel="stylesheet" href="/app.css" /></head><body><main>{this.state.value}</main></body></html>;
}
function ApplicationTask(this: Component<{value:string}>) {
 this.state.value = 'pending';
 const load = async (_task: TaskContext = TaskContext.server().blocking()) => {
  events.push('task-start'); await gate; this.state.value = 'ready'; events.push('task-complete');
 };
 load();
 return () => <main>{read(this.state.value)}</main>;
}
function DocumentShell(props: {children?:Child}) {
 return () => <html><head><title>Static head</title><link rel="stylesheet" href="/app.css" /></head><body>{props.children}</body></html>;
}
export function start(separate: boolean) {
 return separate ? renderToHydratableProgressiveHtmlStream(<ApplicationTask />, {documentShell: app => <DocumentShell>{app}</DocumentShell>}) : renderToHydratableProgressiveHtmlStream(<DocumentTask />);
}
