import { createPreparedServerComponentReference as __exactComponentReceipt, createPreparedServerRenderProgram as __exactPreparedServerRenderProgram, prepareCompiledRenderProgram as __exactPrepareRenderProgram, createExpression as __exactExpression, createCompiledChildRangeReceipt as __exactDynamic } from "@exactjs/core/framework/server-render-structure";
import { issueServerComponentReceipt as __exactIssueServerComponent, awaitServerComponentTask as __exactServerTaskAwait, activateServerComponentTaskForHost as __exactActivateServerTask } from "@exactjs/core/framework/server-component-execution";
import { TaskContext, type Component, type Child } from '@exactjs/core';
import { renderToHydratableProgressiveHtmlStream } from '@exactjs/ssr';
import { issueExactServerComponent as __exactIssueServerComponent_1, writeExactServerComponent as __exactWriteServerComponent_1, disposeExactServerComponent as __exactDisposeServerComponent_1 } from "@exactjs/core/runtime/component-operations";
import { rejectDirectServerComponentConstruction as __exactRejectDirectServerConstruction_1 } from "@exactjs/core/runtime/component-construction/direct-server";
const __exactComponentContract_1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
const __exact_server_task_slice_1 = [[], [[0, ["value"]]], "blocking", "load"] as const;
const __exact_server_task_slice_2 = [[], [[0, ["value"]]], "blocking", "load"] as const;
const __exact_render_program_1 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xJQ4JKLRnk1HuydCluQy21v", namespace: "html", ssrRootStatic: [" data-exact-id=\"xrhcrGTi0EjpGeSk4GAeUBt\"", ["data-exact-id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
        const __exactValue_0 = __exactInvocation.eagerValues[0];
        __exactSsr.begin(__exactContext, 3, 1, 78, 78);
        let __exactCharacters = 78;
        __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "head", "<head", "><title>Static head</title><link rel=\"stylesheet\" href=\"/app.css\"></head>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
        const __exactDrain = __exactOutput.sink.ready();
        if (__exactDrain)
            return __exactDrain.then(() => __exactOutput);
        return __exactOutput;
    }, ssrHost: "head" });
const __exact_server_invocation_1 = /* @__PURE__ */ __exactPreparedServerRenderProgram(__exact_render_program_1, [{ "data-exact-id": "xrhcrGTi0EjpGeSk4GAeUBt" }]);
const __exact_render_program_2 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xRYeVJ2W9zo_eRV_pAVBmED", namespace: "html", ssrRootStatic: ["", [], []], ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame?: unknown[]): (typeof __exactOutput | undefined) | Promise<typeof __exactOutput | undefined> {
        let __exactValue_0: unknown, __exactValue_1: unknown, __exactCharacters: number, __exactStage = 0, __exactSettled: unknown, __exactPending;
        if (__exactFrame) {
            __exactValue_0 = __exactFrame[6] as unknown;
            __exactValue_1 = __exactFrame[7] as unknown;
            __exactCharacters = __exactFrame[8] as number;
            __exactStage = __exactFrame[4] as number;
            __exactSettled = __exactFrame[5];
        }
        else {
            __exactValue_0 = __exactInvocation.eagerValues[0];
            __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
            if (__exactValue_1 === __exactSsr.unprepared)
                return;
            __exactSsr.begin(__exactContext, 1, 2, 13, 13);
            __exactCharacters = 13;
        }
        switch (__exactStage) {
            case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "main", "<main", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
            case 1:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_0 = __exactOutput.sink.ready();
                if (__exactDrain_0) {
                    __exactPending = __exactDrain_0;
                    __exactStage = 2;
                    break;
                }
            case 2: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "", "</main>");
            case 3:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_1 = __exactOutput.sink.ready();
                if (__exactDrain_1) {
                    __exactPending = __exactDrain_1;
                    __exactStage = 4;
                    break;
                }
            case 4: return __exactOutput;
        }
        {
            const __exactSaved: unknown[] = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactCharacters];
            return (__exactPending!).then(__exactResult => {
                __exactSaved[5] = __exactResult;
                return __exactRun(__exactSaved[0] as typeof __exactSsr, __exactSaved[1] as typeof __exactContext, __exactSaved[2] as typeof __exactInvocation, __exactSaved[3] as typeof __exactOutput, __exactSaved);
            });
        }
    }, ssrHost: "main" });
const __exact_render_program_3 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "x8Y4W1z8ufgUCyjwLod-ywG", namespace: "html", ssrRootStatic: [" data-exact-id=\"xWFnXZM0OREKpEYqP2sNaZ0\"", ["data-exact-id"], []], ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame?: unknown[]): (typeof __exactOutput | undefined) | Promise<typeof __exactOutput | undefined> {
        let __exactValue_0: unknown, __exactValue_1: unknown, __exactCharacters: number, __exactStage = 0, __exactSettled: unknown, __exactPending;
        if (__exactFrame) {
            __exactValue_0 = __exactFrame[6] as unknown;
            __exactValue_1 = __exactFrame[7] as unknown;
            __exactCharacters = __exactFrame[8] as number;
            __exactStage = __exactFrame[4] as number;
            __exactSettled = __exactFrame[5];
        }
        else {
            __exactValue_0 = __exactInvocation.eagerValues[0];
            __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
            if (__exactValue_1 === __exactSsr.unprepared)
                return;
            __exactSsr.begin(__exactContext, 1, 2, 13, 13);
            __exactCharacters = 13;
        }
        switch (__exactStage) {
            case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "body", "<body", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
            case 1:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_0 = __exactOutput.sink.ready();
                if (__exactDrain_0) {
                    __exactPending = __exactDrain_0;
                    __exactStage = 2;
                    break;
                }
            case 2:
                __exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_1);
                if (__exactSettled instanceof __exactSsr.promise) {
                    __exactPending = __exactSettled;
                    __exactStage = 3;
                    break;
                }
            case 3:
                const __exactDrain_1 = __exactOutput.sink.ready();
                if (__exactDrain_1) {
                    __exactPending = __exactDrain_1;
                    __exactStage = 4;
                    break;
                }
            case 4: __exactSettled = __exactSsr.static(__exactOutput, "</body>", 0);
            case 5:
                const __exactDrain_2 = __exactOutput.sink.ready();
                if (__exactDrain_2) {
                    __exactPending = __exactDrain_2;
                    __exactStage = 6;
                    break;
                }
            case 6: return __exactOutput;
        }
        {
            const __exactSaved: unknown[] = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactCharacters];
            return (__exactPending!).then(__exactResult => {
                __exactSaved[5] = __exactResult;
                return __exactRun(__exactSaved[0] as typeof __exactSsr, __exactSaved[1] as typeof __exactContext, __exactSaved[2] as typeof __exactInvocation, __exactSaved[3] as typeof __exactOutput, __exactSaved);
            });
        }
    }, ssrHost: "body" });
const __exact_render_program_4 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xVy9Da1lIUEhr7QNvtWqNTd", namespace: "html", ssrRootStatic: [" data-exact-id=\"xAxmpIf1oj6xmSwtoscTOqD\"", ["data-exact-id"], []], ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame?: unknown[]): (typeof __exactOutput | undefined) | Promise<typeof __exactOutput | undefined> {
        let __exactValue_0: unknown, __exactValue_1: unknown, __exactValue_2: unknown, __exactCharacters: number, __exactStage = 0, __exactSettled: unknown, __exactPending;
        if (__exactFrame) {
            __exactValue_0 = __exactFrame[6] as unknown;
            __exactValue_1 = __exactFrame[7] as unknown;
            __exactValue_2 = __exactFrame[8] as unknown;
            __exactCharacters = __exactFrame[9] as number;
            __exactStage = __exactFrame[4] as number;
            __exactSettled = __exactFrame[5];
        }
        else {
            __exactValue_0 = __exactInvocation.eagerValues[0];
            __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
            if (__exactValue_1 === __exactSsr.unprepared)
                return;
            __exactValue_2 = __exactSsr.prepareChild(__exactInvocation, 2);
            if (__exactValue_2 === __exactSsr.unprepared)
                return;
            __exactSsr.begin(__exactContext, 1, 3, 13, 13);
            __exactCharacters = 13;
        }
        switch (__exactStage) {
            case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "html", "<html", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
            case 1:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_0 = __exactOutput.sink.ready();
                if (__exactDrain_0) {
                    __exactPending = __exactDrain_0;
                    __exactStage = 2;
                    break;
                }
            case 2:
                __exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_1);
                if (__exactSettled instanceof __exactSsr.promise) {
                    __exactPending = __exactSettled;
                    __exactStage = 3;
                    break;
                }
            case 3:
                const __exactDrain_1 = __exactOutput.sink.ready();
                if (__exactDrain_1) {
                    __exactPending = __exactDrain_1;
                    __exactStage = 4;
                    break;
                }
            case 4:
                __exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_2);
                if (__exactSettled instanceof __exactSsr.promise) {
                    __exactPending = __exactSettled;
                    __exactStage = 5;
                    break;
                }
            case 5:
                const __exactDrain_2 = __exactOutput.sink.ready();
                if (__exactDrain_2) {
                    __exactPending = __exactDrain_2;
                    __exactStage = 6;
                    break;
                }
            case 6: __exactSettled = __exactSsr.static(__exactOutput, "</html>");
            case 7:
                const __exactDrain_3 = __exactOutput.sink.ready();
                if (__exactDrain_3) {
                    __exactPending = __exactDrain_3;
                    __exactStage = 8;
                    break;
                }
            case 8: return __exactOutput;
        }
        {
            const __exactSaved: unknown[] = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactValue_2, __exactCharacters];
            return (__exactPending!).then(__exactResult => {
                __exactSaved[5] = __exactResult;
                return __exactRun(__exactSaved[0] as typeof __exactSsr, __exactSaved[1] as typeof __exactContext, __exactSaved[2] as typeof __exactInvocation, __exactSaved[3] as typeof __exactOutput, __exactSaved);
            });
        }
    }, ssrHost: "html" });
const __exact_render_program_5 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "x01Uh_MTm0EqEqJM712NKte", namespace: "html", ssrRootStatic: ["", [], []], ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame?: unknown[]): (typeof __exactOutput | undefined) | Promise<typeof __exactOutput | undefined> {
        let __exactValue_0: unknown, __exactValue_1: unknown, __exactCharacters: number, __exactStage = 0, __exactSettled: unknown, __exactPending;
        if (__exactFrame) {
            __exactValue_0 = __exactFrame[6] as unknown;
            __exactValue_1 = __exactFrame[7] as unknown;
            __exactCharacters = __exactFrame[8] as number;
            __exactStage = __exactFrame[4] as number;
            __exactSettled = __exactFrame[5];
        }
        else {
            __exactValue_0 = __exactInvocation.eagerValues[0];
            __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
            if (__exactValue_1 === __exactSsr.unprepared)
                return;
            __exactSsr.begin(__exactContext, 1, 2, 13, 13);
            __exactCharacters = 13;
        }
        switch (__exactStage) {
            case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "main", "<main", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
            case 1:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_0 = __exactOutput.sink.ready();
                if (__exactDrain_0) {
                    __exactPending = __exactDrain_0;
                    __exactStage = 2;
                    break;
                }
            case 2: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "", "</main>");
            case 3:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_1 = __exactOutput.sink.ready();
                if (__exactDrain_1) {
                    __exactPending = __exactDrain_1;
                    __exactStage = 4;
                    break;
                }
            case 4: return __exactOutput;
        }
        {
            const __exactSaved: unknown[] = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactCharacters];
            return (__exactPending!).then(__exactResult => {
                __exactSaved[5] = __exactResult;
                return __exactRun(__exactSaved[0] as typeof __exactSsr, __exactSaved[1] as typeof __exactContext, __exactSaved[2] as typeof __exactInvocation, __exactSaved[3] as typeof __exactOutput, __exactSaved);
            });
        }
    }, ssrHost: "main" });
const __exact_render_program_6 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xkbT_tjIOfGVI1d2o1v4H0F", namespace: "html", ssrRootStatic: [" data-exact-id=\"xIBNx6CBVYRpWTfegz4_ziU\"", ["data-exact-id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
        const __exactValue_0 = __exactInvocation.eagerValues[0];
        __exactSsr.begin(__exactContext, 3, 1, 78, 78);
        let __exactCharacters = 78;
        __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "head", "<head", "><title>Static head</title><link rel=\"stylesheet\" href=\"/app.css\"></head>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
        const __exactDrain = __exactOutput.sink.ready();
        if (__exactDrain)
            return __exactDrain.then(() => __exactOutput);
        return __exactOutput;
    }, ssrHost: "head" });
const __exact_server_invocation_2 = /* @__PURE__ */ __exactPreparedServerRenderProgram(__exact_render_program_6, [{ "data-exact-id": "xIBNx6CBVYRpWTfegz4_ziU" }]);
const __exact_render_program_7 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xIiRKbSL68d0TTv7CDQ-1m8", namespace: "html", ssrRootStatic: [" data-exact-id=\"xe7LuyOX3BcsT9c317PhkZB\"", ["data-exact-id"], []], ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame?: unknown[]): (typeof __exactOutput | undefined) | Promise<typeof __exactOutput | undefined> {
        let __exactValue_0: unknown, __exactValue_1: unknown, __exactCharacters: number, __exactStage = 0, __exactSettled: unknown, __exactPending;
        if (__exactFrame) {
            __exactValue_0 = __exactFrame[6] as unknown;
            __exactValue_1 = __exactFrame[7] as unknown;
            __exactCharacters = __exactFrame[8] as number;
            __exactStage = __exactFrame[4] as number;
            __exactSettled = __exactFrame[5];
        }
        else {
            __exactValue_0 = __exactInvocation.eagerValues[0];
            __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
            if (__exactValue_1 === __exactSsr.unprepared)
                return;
            __exactSsr.begin(__exactContext, 1, 2, 13, 13);
            __exactCharacters = 13;
        }
        switch (__exactStage) {
            case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "body", "<body", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
            case 1:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_0 = __exactOutput.sink.ready();
                if (__exactDrain_0) {
                    __exactPending = __exactDrain_0;
                    __exactStage = 2;
                    break;
                }
            case 2:
                __exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_1);
                if (__exactSettled instanceof __exactSsr.promise) {
                    __exactPending = __exactSettled;
                    __exactStage = 3;
                    break;
                }
            case 3:
                const __exactDrain_1 = __exactOutput.sink.ready();
                if (__exactDrain_1) {
                    __exactPending = __exactDrain_1;
                    __exactStage = 4;
                    break;
                }
            case 4: __exactSettled = __exactSsr.static(__exactOutput, "</body>", 0);
            case 5:
                const __exactDrain_2 = __exactOutput.sink.ready();
                if (__exactDrain_2) {
                    __exactPending = __exactDrain_2;
                    __exactStage = 6;
                    break;
                }
            case 6: return __exactOutput;
        }
        {
            const __exactSaved: unknown[] = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactCharacters];
            return (__exactPending!).then(__exactResult => {
                __exactSaved[5] = __exactResult;
                return __exactRun(__exactSaved[0] as typeof __exactSsr, __exactSaved[1] as typeof __exactContext, __exactSaved[2] as typeof __exactInvocation, __exactSaved[3] as typeof __exactOutput, __exactSaved);
            });
        }
    }, ssrHost: "body" });
const __exact_render_program_8 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xAIGOufYMmp3neDOEpHkUl6", namespace: "html", ssrRootStatic: [" data-exact-id=\"xMT5Kq1pT1_JJwW2068uKjR\"", ["data-exact-id"], []], ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame?: unknown[]): (typeof __exactOutput | undefined) | Promise<typeof __exactOutput | undefined> {
        let __exactValue_0: unknown, __exactValue_1: unknown, __exactValue_2: unknown, __exactCharacters: number, __exactStage = 0, __exactSettled: unknown, __exactPending;
        if (__exactFrame) {
            __exactValue_0 = __exactFrame[6] as unknown;
            __exactValue_1 = __exactFrame[7] as unknown;
            __exactValue_2 = __exactFrame[8] as unknown;
            __exactCharacters = __exactFrame[9] as number;
            __exactStage = __exactFrame[4] as number;
            __exactSettled = __exactFrame[5];
        }
        else {
            __exactValue_0 = __exactInvocation.eagerValues[0];
            __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
            if (__exactValue_1 === __exactSsr.unprepared)
                return;
            __exactValue_2 = __exactSsr.prepareChild(__exactInvocation, 2);
            if (__exactValue_2 === __exactSsr.unprepared)
                return;
            __exactSsr.begin(__exactContext, 1, 3, 13, 13);
            __exactCharacters = 13;
        }
        switch (__exactStage) {
            case 0: __exactSettled = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "html", "<html", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
            case 1:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_0 = __exactOutput.sink.ready();
                if (__exactDrain_0) {
                    __exactPending = __exactDrain_0;
                    __exactStage = 2;
                    break;
                }
            case 2:
                __exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_1);
                if (__exactSettled instanceof __exactSsr.promise) {
                    __exactPending = __exactSettled;
                    __exactStage = 3;
                    break;
                }
            case 3:
                const __exactDrain_1 = __exactOutput.sink.ready();
                if (__exactDrain_1) {
                    __exactPending = __exactDrain_1;
                    __exactStage = 4;
                    break;
                }
            case 4:
                __exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_2);
                if (__exactSettled instanceof __exactSsr.promise) {
                    __exactPending = __exactSettled;
                    __exactStage = 5;
                    break;
                }
            case 5:
                const __exactDrain_2 = __exactOutput.sink.ready();
                if (__exactDrain_2) {
                    __exactPending = __exactDrain_2;
                    __exactStage = 6;
                    break;
                }
            case 6: __exactSettled = __exactSsr.static(__exactOutput, "</html>");
            case 7:
                const __exactDrain_3 = __exactOutput.sink.ready();
                if (__exactDrain_3) {
                    __exactPending = __exactDrain_3;
                    __exactStage = 8;
                    break;
                }
            case 8: return __exactOutput;
        }
        {
            const __exactSaved: unknown[] = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactValue_2, __exactCharacters];
            return (__exactPending!).then(__exactResult => {
                __exactSaved[5] = __exactResult;
                return __exactRun(__exactSaved[0] as typeof __exactSsr, __exactSaved[1] as typeof __exactContext, __exactSaved[2] as typeof __exactInvocation, __exactSaved[3] as typeof __exactOutput, __exactSaved);
            });
        }
    }, ssrHost: "html" });
let events: string[] = [];
let gate: Promise<void>;
let release: () => void;
export function reset() { events = []; gate = new Promise<void>(resolve => { release = resolve; }); }
export function settle() { events.push('release'); release(); }
export function trace() { return [...events]; }
function read(value: string) { events.push('read:' + value); return value; }
const __exactImplementation_DocumentTask_1 = function DocumentTask(this: Component<{
    value: string;
}>) {
    this.state.value = 'pending';
    __exactActivateServerTask(this, __exact_server_task_slice_1, "xhl4cQzkLj0owBa8j4MX-WY", async (_task: TaskContext) => {
        events.push('task-start');
        await __exactServerTaskAwait(_task.signal, gate);
        this.state.value = 'ready';
        events.push('task-complete');
    });
    return () => __exactPreparedServerRenderProgram(__exact_render_program_4, [{ "data-exact-id": "xAxmpIf1oj6xmSwtoscTOqD" }, __exact_server_invocation_1, __exactPreparedServerRenderProgram(__exact_render_program_3, [{ "data-exact-id": "xWFnXZM0OREKpEYqP2sNaZ0" }, __exactPreparedServerRenderProgram(__exact_render_program_2, [{}, read(this.state.value)])])]);
};
const DocumentTask = /* @__PURE__ */ (() => Object.assign(__exactImplementation_DocumentTask_1, {
    [Symbol.for("@exactjs/component")]: "x883Dn1Alf6I1bBIW2NUNRX",
    [__exactComponentContract_1]: {
        version: 1,
        placement: "server",
        role: "executor",
        implementations: [
            { id: "x3nozdsS6clIKNtQn7FA-Gn", name: "DocumentTask", role: "root", implementation: __exactImplementation_DocumentTask_1 }
        ],
        continuations: [
            {
                kind: "task",
                id: "xhl4cQzkLj0owBa8j4MX-WY",
                componentId: "x883Dn1Alf6I1bBIW2NUNRX",
                readiness: "blocking",
                concurrency: "latest",
                dependencies: [],
                stateReads: [],
                stateWrites: [
                    {
                        path: "value",
                        kind: "write",
                        confidence: "exact"
                    }
                ],
                publicContexts: [],
                serverContexts: [],
                contextWrites: [],
                serverContextWrites: [],
                boundaries: []
            }
        ],
        executors: [
            {
                id: "xhl4cQzkLj0owBa8j4MX-WY",
                componentId: "x883Dn1Alf6I1bBIW2NUNRX",
                execute: async (__exactActivation_1: any, __exactExecution_1: any) => {
                    const __exactComponent_1 = { state: __exactActivation_1.state } as {
                        state: {
                            value: string;
                        };
                    };
                    const __exactContextWrites_1 = {};
                    await (async (_task: TaskContext) => {
                        events.push('task-start');
                        await __exactServerTaskAwait(_task.signal, gate);
                        __exactComponent_1.state.value = 'ready';
                        events.push('task-complete');
                    })(__exactExecution_1.task);
                    return { state: __exactComponent_1.state, contexts: __exactContextWrites_1 };
                }
            }
        ],
        boundaries: [],
        artifact: {
            version: 1,
            target: "server",
            id: "x883Dn1Alf6I1bBIW2NUNRX",
            instantiate: __exactImplementation_DocumentTask_1,
            construct: __exactRejectDirectServerConstruction_1,
            abi: 9,
            capabilities: [
                "tasks",
                "continuations"
            ],
            state: [
                "value"
            ],
            props: [],
            issue: __exactIssueServerComponent_1,
            write: __exactWriteServerComponent_1,
            dispose: __exactDisposeServerComponent_1,
            execution: {
                version: 1,
                classification: "scheduled",
                lane: "direct",
                documentRoot: true,
                render: __exactImplementation_DocumentTask_1
            },
            tasks: [
                "xhl4cQzkLj0owBa8j4MX-WY"
            ],
            reactive: [
                {
                    name: "load",
                    provenance: "unknown",
                    allocation: "constant",
                    dependencies: []
                },
                {
                    name: "this",
                    provenance: "state",
                    allocation: "live-slot",
                    dependencies: []
                }
            ],
            render: "returned-function"
        }
    }
}) as typeof __exactImplementation_DocumentTask_1)();
const __exactImplementation_ApplicationTask_1 = function ApplicationTask(this: Component<{
    value: string;
}>) {
    this.state.value = 'pending';
    __exactActivateServerTask(this, __exact_server_task_slice_2, "xWx7-_OkvWhrxWmvlpREmv9", async (_task: TaskContext) => {
        events.push('task-start');
        await __exactServerTaskAwait(_task.signal, gate);
        this.state.value = 'ready';
        events.push('task-complete');
    });
    return () => __exactPreparedServerRenderProgram(__exact_render_program_5, [{}, read(this.state.value)]);
};
const ApplicationTask = /* @__PURE__ */ (() => Object.assign(__exactImplementation_ApplicationTask_1, {
    [Symbol.for("@exactjs/component")]: "xu46A03d3usQzjHkqUzemBg",
    [__exactComponentContract_1]: {
        version: 1,
        placement: "server",
        role: "executor",
        implementations: [
            { id: "xIrJHZcLTKv57uWrOaMkpxI", name: "ApplicationTask", role: "root", implementation: __exactImplementation_ApplicationTask_1 }
        ],
        continuations: [
            {
                kind: "task",
                id: "xWx7-_OkvWhrxWmvlpREmv9",
                componentId: "xu46A03d3usQzjHkqUzemBg",
                readiness: "blocking",
                concurrency: "latest",
                dependencies: [],
                stateReads: [],
                stateWrites: [
                    {
                        path: "value",
                        kind: "write",
                        confidence: "exact"
                    }
                ],
                publicContexts: [],
                serverContexts: [],
                contextWrites: [],
                serverContextWrites: [],
                boundaries: []
            }
        ],
        executors: [
            {
                id: "xWx7-_OkvWhrxWmvlpREmv9",
                componentId: "xu46A03d3usQzjHkqUzemBg",
                execute: async (__exactActivation_2: any, __exactExecution_2: any) => {
                    const __exactComponent_2 = { state: __exactActivation_2.state } as {
                        state: {
                            value: string;
                        };
                    };
                    const __exactContextWrites_2 = {};
                    await (async (_task: TaskContext) => {
                        events.push('task-start');
                        await __exactServerTaskAwait(_task.signal, gate);
                        __exactComponent_2.state.value = 'ready';
                        events.push('task-complete');
                    })(__exactExecution_2.task);
                    return { state: __exactComponent_2.state, contexts: __exactContextWrites_2 };
                }
            }
        ],
        boundaries: [],
        artifact: {
            version: 1,
            target: "server",
            id: "xu46A03d3usQzjHkqUzemBg",
            instantiate: __exactImplementation_ApplicationTask_1,
            construct: __exactRejectDirectServerConstruction_1,
            abi: 9,
            capabilities: [
                "tasks",
                "continuations"
            ],
            state: [
                "value"
            ],
            props: [],
            issue: __exactIssueServerComponent_1,
            write: __exactWriteServerComponent_1,
            dispose: __exactDisposeServerComponent_1,
            execution: {
                version: 1,
                classification: "scheduled",
                lane: "direct",
                render: __exactImplementation_ApplicationTask_1
            },
            tasks: [
                "xWx7-_OkvWhrxWmvlpREmv9"
            ],
            reactive: [
                {
                    name: "load",
                    provenance: "unknown",
                    allocation: "constant",
                    dependencies: []
                },
                {
                    name: "this",
                    provenance: "state",
                    allocation: "live-slot",
                    dependencies: []
                }
            ],
            render: "returned-function"
        }
    }
}) as typeof __exactImplementation_ApplicationTask_1)();
const __exactImplementation_DocumentShell_1 = function DocumentShell(props: {
    children?: Child;
}) {
    return __exactPreparedServerRenderProgram(__exact_render_program_8, [{ "data-exact-id": "xMT5Kq1pT1_JJwW2068uKjR" }, __exact_server_invocation_2, __exactPreparedServerRenderProgram(__exact_render_program_7, [{ "data-exact-id": "xe7LuyOX3BcsT9c317PhkZB" }, __exactDynamic(() => props.children, "xUiurJhb_JBDdTN9OlXv-_r")])]);
};
const DocumentShell = /* @__PURE__ */ (() => Object.assign(__exactImplementation_DocumentShell_1, {
    [Symbol.for("@exactjs/component")]: "xakuAzklseUf1FWsMHoBVx8",
    [__exactComponentContract_1]: {
        version: 1,
        placement: "isomorphic",
        role: "executor",
        implementations: [
            { id: "xRkcWYnWX510f9NWX017xcK", name: "DocumentShell", role: "root", implementation: __exactImplementation_DocumentShell_1 }
        ],
        continuations: [],
        executors: [],
        boundaries: [],
        artifact: {
            version: 1,
            target: "server",
            id: "xakuAzklseUf1FWsMHoBVx8",
            instantiate: __exactImplementation_DocumentShell_1,
            construct: __exactRejectDirectServerConstruction_1,
            abi: 1,
            capabilities: [],
            state: [],
            props: [
                "children"
            ],
            issue: __exactIssueServerComponent_1,
            write: __exactWriteServerComponent_1,
            dispose: __exactDisposeServerComponent_1,
            execution: {
                version: 1,
                classification: "synchronous",
                lane: "direct",
                documentRoot: true,
                render: __exactImplementation_DocumentShell_1,
                mode: "stateless"
            },
            tasks: [],
            reactive: [
                {
                    name: "props",
                    provenance: "props",
                    allocation: "live-slot",
                    dependencies: []
                }
            ],
            render: "returned-function"
        }
    }
}) as typeof __exactImplementation_DocumentShell_1)();
export function start(separate: boolean) {
    return separate ? renderToHydratableProgressiveHtmlStream(__exactIssueServerComponent(__exactComponentReceipt(ApplicationTask, {})), { documentShell: app => __exactComponentReceipt(DocumentShell, {}, __exactExpression(() => app)) }) : renderToHydratableProgressiveHtmlStream(__exactIssueServerComponent(__exactComponentReceipt(DocumentTask, {})));
}
