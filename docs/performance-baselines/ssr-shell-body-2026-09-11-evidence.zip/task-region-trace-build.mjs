import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {transformSource,createCompilerSession} from '../../packages/compiler/dist/index.js';
import {transform} from 'esbuild';
const file=resolve('.tmp/ssr-completion/task-region-trace.tsx');
const session=createCompilerSession();
try {
 const result=transformSource(await readFile(file,'utf8'),{filename:file,target:'server',session,reactCompatibility:false});
 await writeFile('.tmp/ssr-completion/task-region-trace.compiled.ts',result.code);
 const js=await transform(result.code,{loader:'ts',format:'esm',target:'esnext'});
 await writeFile('.tmp/ssr-completion/task-region-trace.compiled.mjs',js.code);
} finally {session.dispose();}
