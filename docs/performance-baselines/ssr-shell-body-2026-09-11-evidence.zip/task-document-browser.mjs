import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
for(const runtime of ['node','bun'])for(const mode of ['string','stream']){
 const r=spawnSync(process.execPath,['../node_modules/@playwright/test/cli.js','test','-c','playwright.config.ts','--grep','exact|react'],{cwd:'framework-comparison',windowsHide:true,encoding:'utf8',env:{...process.env,NODE_ENV:'production',COMPARISON_E2E_RUNTIME:runtime,COMPARISON_SSR_RENDER_MODE:mode}});
 writeFileSync(`.tmp/ssr-completion/task-document-browser-${runtime}-${mode}.log`,r.stdout+'\n'+r.stderr);
 console.log(runtime,mode,r.status,r.stdout.slice(-300));if(r.status!==0)process.exit(r.status??1);
}

