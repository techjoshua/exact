import {setTimeout} from 'node:timers/promises';
import {writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {reset,settle,trace,start} from './task-span-trace.compiled.mjs';
const reports=[];
for(const separate of [false,true]) {
 reset(); const events=[]; const reader=start(separate).getReader(); let html='';
 const consume=(async()=>{for(;;){const next=await reader.read(); if(next.done)break; const part=new TextDecoder().decode(next.value);html+=part;events.push({event:'chunk',head:part.includes('</head>'),bytes:next.value.length,taskEvents:trace()});}})();
 try {
  await setTimeout(50);
  const beforeRelease={events:[...events],taskEvents:trace()};
  settle();await consume;
  assert.match(html,/<\/body><\/html>$/);assert.match(html,/ready/);assert.doesNotMatch(html,/>pending</);
  reports.push({separate,beforeRelease,events,taskEvents:trace(),bytes:Buffer.byteLength(html)});
 } finally {settle();await reader.cancel();reader.releaseLock();}
}
await writeFile('.tmp/ssr-completion/task-span-trace.json',JSON.stringify(reports,null,2));
console.log(JSON.stringify(reports,null,2));
