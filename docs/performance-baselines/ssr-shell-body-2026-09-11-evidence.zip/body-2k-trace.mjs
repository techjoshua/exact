import {createHook} from 'node:async_hooks';
import {readFile,writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
const hook=createHook({init(id,type){if(active && type==='PROMISE')active.promises++;}}); hook.enable(); const original=Buffer.byteLength;
let active;
Buffer.byteLength=function(value,...args){
 if(active && typeof value==='string'){
  active.calls++; active.characters+=value.length;
  const bucket=value.length<32?'under32':value.length<256?'under256':'larger';
  active[bucket]++;
 }
 return original.call(this,value,...args);
};
const fixture=JSON.parse(await readFile('framework-comparison/fixtures/baseline.json','utf8'));
const data={users:fixture.users,sessionUserId:fixture.sessionUserId,incidents:Array.from({length:96},(_,i)=>({...fixture.incidents[i%fixture.incidents.length],id:'inc-'+(100+i)}))};
const reports=[];
try {
 for(const [id,path] of [['eightKB','.tmp/ssr-completion/body-2k-baseline-node.mjs'],['twoKBFixedQueue','.tmp/ssr-completion/body-2k-fixed-node.mjs'],['twoKBSmallQueue','.tmp/ssr-completion/body-2k-small-node.mjs']]){
  const module=await import(pathToFileURL(resolve(path)).href);
  active={promises:0,calls:0,characters:0,under32:0,under256:0,larger:0};
  const reader=module.renderParticipantStream(data,'/',{clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'},AbortSignal.timeout(5000)).getReader();
  const chunks=[];
  try {for(;;){const next=await reader.read();if(next.done)break;chunks.push(Buffer.from(next.value));}}
  finally {await reader.cancel();reader.releaseLock();}
  const counts=active;active=undefined;
  const body=Buffer.concat(chunks);
  const report={id,...counts,chunks:chunks.map(b=>b.length),bytes:body.length,sha256:createHash('sha256').update(body).digest('hex')};
  reports.push(report);console.log(report);
 }
} finally {Buffer.byteLength=original;hook.disable();}
await writeFile('.tmp/ssr-completion/body-2k-trace.json',JSON.stringify(reports,null,2));

