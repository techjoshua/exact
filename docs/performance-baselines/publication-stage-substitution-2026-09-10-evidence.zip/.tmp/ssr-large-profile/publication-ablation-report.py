import hashlib
import json
import zipfile
from pathlib import Path

base=Path('.tmp/ssr-large-profile')
root=base/'publication-ablation-v2'
capture=json.loads((root/'capture.json').read_text())
assert capture['complete']
summary=json.loads((root/'summary.json').read_text())
report=Path('docs/performance-baselines/publication-stage-substitution-2026-09-10.md')
lines=['# Publication preparation substitutions, 2026-09-10','','## Scope and hypothesis','',
'Follow the [hydration stage experiment](hydration-stage-substitution-2026-09-10.md)',
'by isolating root-prop preparation, publication options, compact metadata',
'construction and payload byte counting. Hypothesis: metadata construction alone',
'is below roughly 2 percent of HTTP throughput; root-prop object copies and',
'publication records could offer a larger, approximately 1 to 5 percent gain.', '',
'Each diagnostic reuses a precalculated fixed-input result in the same warmed',
'Node string worker. The normal shared renderer, validation and JSON encoding',
'remain active. Root mode reuses prepared root options. Options mode reuses',
'publication options after rendering. Metadata mode copies the precalculated',
'envelope and inserts current state and resumption references. Bytes mode reuses',
'the computed payload byte length while retaining the limit comparison.', '',
'Metadata still allocates an envelope, so this measures its construction work',
'against copying and patching a known layout, not total allocation elimination.',
'Reusing records can affect downstream allocation, optimization and memory access.',
'These substitutions are valid only for this fixed fixture and are not proposed',
'production caches or exclusive CPU measurements.', '',
'## Controls and correction','',
'Two fresh workers each warm HTTP for ten seconds, then run nine three-second',
'blocks: four substitutions bracketed by normal execution. Worker two reverses',
'treatment order. Two fresh load drivers per block each hold 16 requests in',
'flight. The paired control is the mean of immediately adjacent normal blocks.',
'Isolated loops before/after each block independently prime caches to avoid',
'confounding literal versus URL-derived pathname representation.', '',
'The first diagnostic version copied cached metadata without restoring current',
'resumption identity. The validator uses that identity to choose structural',
'validation. That version is excluded from conclusions and retained in evidence.',
'The corrected version restores current state and resumption references, while',
'preserving a fresh mutable envelope for positional projection.', '',
'Ten normal/escaped full-document parity cases pass for the corrected version.',
f"All {summary['valid']:,} measured HTTP responses match the complete 4,672-byte",
'document, with zero errors. Stage counters confirm the selected operation is',
'skipped and the other measured stages still run. Artifact and adapter hashes',
'remain unchanged over the experiment. Owned worker/load processes are closed.', '',
'## Corrected results','',
'| Stage | Worker | Normal RPS | Substituted RPS | Change |',
'| --- | ---: | ---: | ---: | ---: |']
for stage in ('root','options','metadata','bytes'):
    for r in summary['rows']:
        if r['stage']==stage:
            lines.append(f"| {stage} | {r['population']} | {r['normalRps']:,.0f} | {r['stubRps']:,.0f} | {r['gainPct']:+.2f}% |")
lines+=['','Raw isolated and HTTP render durations are preserved in summary.json and',
'capture.json in the evidence archive. Small changes require caution given',
'background workstation load and instrumentation. This experiment does not',
'establish an eXact versus React result or recoverable production speedup.', '',
'## Decision','',
'Do not redesign publication metadata based on these small substitutions alone.',
'The earlier JSON substitution provides the stronger consistent signal. Continue',
'by separating per-component state capture and the tree-rendering stage, preserving',
'full output and normal ownership for the portions that still execute. The broader',
'Node/Bun string/stream performance objective remains open. No framework behavior',
'or public documentation changes are justified by this diagnostic.', '',
'The adjacent evidence archive contains both diagnostic versions, frozen current',
'artifacts, runner/check sources, raw results, fixture and a verified SHA-256',
'inventory. Workspace dependencies are not packaged as a standalone distribution.','']
assert not report.exists()
report.write_text('\n'.join(lines),encoding='utf8')
files=list(root.glob('*'))+list((base/'publication-ablation').glob('*'))
files += [base/n for n in ('publication-ablation-build.mjs','publication-ablation-v2-build.mjs','publication-ablation-v2-generated-build.mjs','publication-ablation-check.mjs','publication-ablation-v2-check.mjs','publication-ablation-run.mjs','publication-ablation-v2-run.mjs','publication-ablation-analyze.py','publication-ablation-report.py','hydration-ablation-run.mjs','hydration-ablation-check.mjs','hydration-ablation/worker.mjs','component-forwarding-integrated/server-entry.js')]
files += [Path('.tmp/positional-leaves/data.json'),report]
files=sorted(set(f for f in files if f.is_file()))
archive=report.with_name(report.stem+'-evidence.zip')
assert not archive.exists()
manifest={f.as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in files:z.write(f,f.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(report,len(files),'verified files')
