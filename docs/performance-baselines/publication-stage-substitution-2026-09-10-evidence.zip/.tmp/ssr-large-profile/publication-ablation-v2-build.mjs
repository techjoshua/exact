import fs from 'node:fs/promises';
let builder=await fs.readFile('.tmp/ssr-large-profile/publication-ablation-build.mjs','utf8');
builder=builder.replaceAll('publication-ablation','publication-ablation-v2');
builder=builder.replace("const copy=stage==='metadata'?'.slice()':'';",`const copy=stage==='metadata'?'.slice()':'';
  const replay=stage==='metadata'?
   "const envelope=auditCache.metadata.slice();if(auditMetadataState>=0)envelope[auditMetadataState]=options.state;if(auditMetadataResumptions>=0)envelope[auditMetadataResumptions]=resumptions;return envelope;":
   'return auditCache.'+stage+';';
  const prepare=stage==='metadata'?
   "let index=2,remaining=auditResult[1]&~16;while(remaining){const bit=remaining&-remaining;remaining&=remaining-1;if(bit===8)auditMetadataState=index;if(bit===64)auditMetadataResumptions=index;index++;}":'';`);
builder=builder.replace("if(auditStage==='${stage}')return auditCache.${stage}${copy};","if(auditStage==='${stage}'){${replay}}");
builder=builder.replace('if(auditCache.${stage}===undefined)auditCache.${stage}=auditResult${copy};return auditResult;', 'if(auditCache.${stage}===undefined){auditCache.${stage}=auditResult${copy};${prepare}}return auditResult;');
builder=builder.replace("let auditStage='none',auditCache={}","let auditMetadataState=-1,auditMetadataResumptions=-1,auditStage='none',auditCache={}");
builder=builder.replace("auditStage='none';auditCache={};auditClearCounts();", "auditMetadataState=-1;auditMetadataResumptions=-1;auditStage='none';auditCache={};auditClearCounts();");
await fs.writeFile('.tmp/ssr-large-profile/publication-ablation-v2-generated-build.mjs',builder);
await import('./publication-ablation-v2-generated-build.mjs');
