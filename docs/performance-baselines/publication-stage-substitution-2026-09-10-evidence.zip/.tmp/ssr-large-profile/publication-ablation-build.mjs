import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';
await fs.mkdir(root+'publication-ablation',{recursive:true});
const source=(await fs.readFile(root+'component-forwarding-integrated/server-entry.js','utf8')).replaceAll('\r\n','\n');
const ast=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const edits=[];let replaced=0;
const stages={rootPropsOptions:'root',hydrationScriptOptions:'options',createDirectHydrationMetadata:'metadata'};
function visit(n){
 if(ts.isFunctionDeclaration(n)&&stages[n.name?.text]){
  const name=n.name.text,stage=stages[name];
  edits.push({start:n.name.getStart(ast),end:n.name.end,text:'auditOriginal_'+name});
  const args=n.parameters.map(p=>p.name.getText(ast)).join(',');
  const copy=stage==='metadata'?'.slice()':'';
  edits.push({start:n.end,end:n.end,text:`\nfunction ${name}(${args}) {
   if(auditStage==='${stage}')return auditCache.${stage}${copy};
   ++auditCounts.${stage};const auditResult=auditOriginal_${name}(${args});
   if(auditCache.${stage}===undefined)auditCache.${stage}=auditResult${copy};return auditResult;
  }\n`});replaced++;
 }
 if(ts.isFunctionDeclaration(n)&&n.name?.text==='renderHydrationScriptValue'){
  function inner(v){
   if(ts.isVariableDeclaration(v)&&v.name.getText(ast)==='payloadBytes'){
    edits.push({start:v.initializer.getStart(ast),end:v.initializer.end,text:`auditStage==='bytes'?auditCache.bytes:(++auditCounts.bytes,${v.initializer.getText(ast)})`});
    edits.push({start:v.parent.parent.end,end:v.parent.parent.end,text:'\nif(auditCache.bytes===undefined)auditCache.bytes=payloadBytes;'});replaced++;
   }
   ts.forEachChild(v,inner);
  }inner(n.body);
 }
 ts.forEachChild(n,visit);
}
visit(ast);if(replaced!==4)throw Error('Stage boundary missing');
let output=source;
for(const e of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,e.start)+e.text+output.slice(e.end);
output=`let auditStage='none',auditCache={},auditCounts={root:0,options:0,metadata:0,bytes:0};\n`+output+`
export function auditClearCounts(){auditCounts={root:0,options:0,metadata:0,bytes:0};}
export function auditReset(){auditStage='none';auditCache={};auditClearCounts();}
export function auditSelect(stage){if(!['none','root','options','metadata','bytes'].includes(stage))throw Error('Invalid stage');if(stage!=='none'&&Object.keys(auditCache).length!==4)throw Error('Not primed');auditStage=stage;}
export function auditRead(){return {stage:auditStage,counts:{...auditCounts},ready:Object.keys(auditCache).length===4};}
`;
await fs.writeFile(root+'publication-ablation/server-entry.js',output);
await fs.copyFile(root+'hydration-ablation/worker.mjs',root+'publication-ablation/worker.mjs');
let runner=(await fs.readFile(root+'hydration-ablation-run.mjs','utf8')).replaceAll('hydration-ablation/','publication-ablation/').replaceAll('within-worker-hydration-stage-substitution','within-worker-publication-stage-substitution');
runner=runner.replaceAll("'none','hydration','none','validation','none','escape','none','json','none'","'none','bytes','none','metadata','none','options','none','root','none'").replaceAll("'none','json','none','escape','none','validation','none','hydration','none'","'none','root','none','options','none','metadata','none','bytes','none'");
await fs.writeFile(root+'publication-ablation-run.mjs',runner);
let check=(await fs.readFile(root+'hydration-ablation-check.mjs','utf8')).replaceAll('hydration-ablation/','publication-ablation/').replace("['none','validation','json','escape','hydration']","['none','root','options','metadata','bytes']").replace("['hydration','validation','json','escape']","['root','options','metadata','bytes']").replace("stage==='hydration'||stage===name&&stage!=='none'?0:1","stage===name?0:1");
await fs.writeFile(root+'publication-ablation-check.mjs',check);
console.log({replaced});
