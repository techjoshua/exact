import json
from pathlib import Path
from statistics import mean

root=Path('.tmp/ssr-large-profile/publication-ablation-v2')
data=json.loads((root/'capture.json').read_text())
rows=[]
for population in (0,1):
    blocks=[b for b in data['blocks'] if b['population']==population]
    for i,b in enumerate(blocks):
        if b['phase']=='none' or i+1==len(blocks):continue
        controls=[blocks[i-1],blocks[i+1]]
        assert all(c['phase']=='none' for c in controls)
        for name,count in b['after']['ablation']['counts'].items():
            assert (count==0)==(name==b['phase']), (name,b['phase'],count)
        def render(x):
            s=x['after']['telemetry']['statistics']['renderMs']
            return s['sum']/s['count']*1000
        def loop(x):return mean(x[k]['meanMs'] for k in ('loopBefore','loopAfter'))*1000
        baseline=mean(c['rps'] for c in controls)
        rows.append(dict(population=population+1,stage=b['phase'],normalRps=baseline,
                         stubRps=b['rps'],gainPct=(b['rps']/baseline-1)*100,
                         normalHttpUs=mean(render(c) for c in controls),stubHttpUs=render(b),
                         normalLoopUs=mean(loop(c) for c in controls),stubLoopUs=loop(b)))
print(json.dumps({'complete':data['complete'],'rows':rows},indent=2))
if data['complete']:
    assert len(rows)==8
    valid=sum(b['valid'] for b in data['blocks'])
    errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages'])
    assert errors==0
    (root/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid,errors=errors),indent=2))
    print('VALID',valid)
