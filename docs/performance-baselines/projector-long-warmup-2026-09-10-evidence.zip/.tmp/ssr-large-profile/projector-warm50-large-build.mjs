import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
let code=fs.readFileSync(d+'projector-inline-primitives-run.mjs','utf8').replaceAll('projector-inline-primitives/server-entry.js','projector-inline-primitives-integrated/server-entry.js').replaceAll('final-rope-worker.mjs','projector-warm50-worker.mjs').replace("'10000'","'20000'").replaceAll('projector-inline-primitives-results.json','projector-warm50-large-results.json');
fs.writeFileSync(d+'projector-warm50-large-run.mjs',code);
