import fs from 'node:fs';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';import {createComparisonService} from '../../framework-comparison/src/service.mjs';
const fixture=JSON.parse(fs.readFileSync('framework-comparison/fixtures/baseline.json','utf8'));
const service=createComparisonService(fixture);
try {
 const session=await (await service.fetch(new Request('http://fixture/api/session'))).json();
 const incidents=await (await service.fetch(new Request('http://fixture/api/incidents'))).json();
 const actual={...session,...incidents};const expected=JSON.parse(fs.readFileSync('.tmp/positional-leaves/data.json','utf8'));assert.deepEqual(actual,expected);
 fs.writeFileSync('.tmp/ssr-large-profile/projector-long-fixture-check.json',JSON.stringify({match:true,sha256:createHash('sha256').update(JSON.stringify(actual)).digest('hex')},null,2));
 console.log('Focused input matches controlled session/incidents responses.');
} finally {service.dispose();}

