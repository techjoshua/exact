import hashlib
import json
import zipfile
from pathlib import Path

base=Path('.tmp/ssr-large-profile');folder=base/'http-immediate'
capture=json.loads((folder/'capture.json').read_text());assert capture['complete']
summary=json.loads((folder/'summary.json').read_text());assert summary['errors']==0
report=Path('docs/performance-baselines/http-immediate-2026-09-10.md')
lines=['# Event-loop deferral before rendering, 2026-09-10','','## Hypothesis and method','',
'Earlier microtask deferral and disabled-inlining controls did not remove the',
'larger HTTP rendering cost. Test a distinct boundary: await a promise resolved',
'by setImmediate before starting the synchronous render timer. This lets socket',
'processing and rendering run in different event-loop phases. That description',
'does not establish why any performance change occurs.', '',
'A diagnostic-only worker switch applies the same deferral to eXact and React.',
'Every request still renders its full application-owned document. The actual',
'render entry points and original output adapters are unchanged. Queue wait is',
'timed separately. Isolated loops explicitly bypass deferral, verified by counters.',
'This is a benchmark-worker experiment, not a shipped Node-adapter optimization.', '',
'Four fresh production Node 26.8.1 workers run eXact/React/React/eXact. Each warms',
'HTTP for ten seconds, then runs normal/deferred/normal for five seconds each.',
'Two fresh load drivers per block each hold 16 requests in flight. The normal',
'control is the average of adjacent blocks within the same worker. Before/after',
'isolated loops each warm and measure 10,000 renders. Workstation load can vary.', '',
'## Throughput and synchronous invocation','',
'| Framework | Worker | Normal RPS | Deferred RPS | Change | Normal invocation us | Deferred invocation us |',
'| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for r in summary['rows']:
    lines.append(f"| {r['framework']} | {r['population']} | {r['normalRps']:,.0f} | {r['deferredRps']:,.0f} | {r['gainPct']:+.2f}% | {r['normalInvocationUs']:.2f} | {r['deferredInvocationUs']:.2f} |")
lines+=['','## Queue wait and complete response latency','',
'Response means are request-weighted across the two drivers; adjacent control',
'means are then averaged. Queue wait is included in end-to-end response latency,',
'but excluded from the synchronous invocation timer above.', '',
'| Framework | Worker | Added queue mean ms | Normal response mean ms | Deferred response mean ms |',
'| --- | ---: | ---: | ---: | ---: |']
for r in summary['rows']:
    lines.append(f"| {r['framework']} | {r['population']} | {r['queueUs']/1000:.3f} | {r['normalResponseMs']:.3f} | {r['deferredResponseMs']:.3f} |")
lines+=['',f"All {summary['valid']:,} measured responses match their complete document",
'identity, zero errors. eXact serves 4,672 bytes and React 3,660 bytes. Queue',
'counters match render-invocation counters only in deferred HTTP blocks. Normal',
'HTTP and all isolated loops have no queue counter. Artifact and adapter hashes',
'remain unchanged. Owned workers and load processes close.', '',
'## Interpretation and adoption gates','',
'Scheduling materially affects HTTP invocation cost and throughput in this setup.',
'Both repetitions improve response latency despite queue wait. Both frameworks',
'benefit, so this does not explain or eliminate the relative gap: deferred eXact',
'remains approximately 21 percent below deferred React in each population.',
'These effects are not additive with previous substitutions. They do not identify',
'whether batching, execution locality, socket behavior or another mechanism is',
'responsible, nor prove an optimal scheduling strategy.', '',
'Before adoption, measure low-concurrency latency and early streaming/browser',
'behavior. Locate a corresponding framework-owned scheduling boundary instead',
'of changing only the benchmark. Current createExactNodeHandler starts body',
'consumption immediately before asynchronous dispatch; that must remain true.',
'Queued cancellation, request-body failures, context initialization and produced',
'response ownership need appropriate regression coverage. The benchmark string',
'path currently renders before calling writeNodeResponse, whereas a lazy produced',
'body can render during adapter consumption. Those locations are not equivalent.', '',
'No production changes or new benchmark baseline are claimed here. The complete',
'Node/Bun string/stream performance objective remains open.', '',
'The adjacent archive includes scripts, raw results, summaries, participant',
'artifacts and verified SHA-256 inventory. Workspace dependencies are not a',
'standalone distribution.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[report]+[base/n for n in ('http-immediate-build.mjs','http-immediate-run.mjs','http-immediate-analyze.py','http-immediate-report.py','http-invocation-trace-run.mjs','http-invocation-trace/worker.mjs','component-forwarding-integrated/server-entry.js')]+[Path('framework-comparison/participants/react/dist-server/server-entry.js')]
files=sorted(set(f for f in files if f.is_file()));archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={f.as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in files:z.write(f,f.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(report,len(files),'verified files')
