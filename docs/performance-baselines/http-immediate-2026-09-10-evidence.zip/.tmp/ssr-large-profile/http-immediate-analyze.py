import json
from pathlib import Path
from statistics import mean

folder=Path('.tmp/ssr-large-profile/http-immediate')
data=json.loads((folder/'capture.json').read_text())
def duration(audit,key):
    s=audit.get(key);return s['sumMs']/s['count']*1000 if s else 0
def response(x):
    values=[r['stages'][0]['distributions']['responseMs'] for r in x['results']]
    return sum(s['mean']*s['count'] for s in values)/sum(s['count'] for s in values)
rows=[]
for population in (0,1):
    for framework in ('exact','react'):
        blocks=[b for b in data['blocks'] if b['population']==population and b['id']==framework]
        if len(blocks)!=3:continue
        assert [b['phase'] for b in blocks]==['normal','immediate','normal']
        controls=[blocks[0],blocks[2]];b=blocks[1]
        assert b['after']['audit']['renderQueue']['count']==b['after']['audit']['renderInvocation']['count']
        assert all('renderQueue' not in c['after']['audit'] for c in controls)
        for c in blocks:
            assert 'renderQueue' not in c['loopBefore']['audit'] and 'renderQueue' not in c['loopAfter']['audit']
        baseline=mean(c['rps'] for c in controls)
        rows.append(dict(framework=framework,population=population+1,normalRps=baseline,deferredRps=b['rps'],gainPct=(b['rps']/baseline-1)*100,
                         normalInvocationUs=mean(duration(c['after']['audit'],'renderInvocation') for c in controls),deferredInvocationUs=duration(b['after']['audit'],'renderInvocation'),
                         queueUs=duration(b['after']['audit'],'renderQueue'),normalResponseMs=mean(response(c) for c in controls),deferredResponseMs=response(b),
                         normalLoopInvocationUs=mean(duration(c[k]['audit'],'renderInvocation') for c in controls for k in ('loopBefore','loopAfter')),
                         deferredLoopInvocationUs=mean(duration(b[k]['audit'],'renderInvocation') for k in ('loopBefore','loopAfter'))))
print(json.dumps(dict(complete=data['complete'],rows=rows),indent=2))
if data['complete']:
    assert len(rows)==4
    valid=sum(b['valid'] for b in data['blocks'])
    errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages']);assert errors==0
    (folder/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid,errors=errors),indent=2))
    print('VALID',valid)
