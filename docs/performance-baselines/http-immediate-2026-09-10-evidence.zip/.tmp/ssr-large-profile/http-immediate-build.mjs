import fs from 'node:fs/promises';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'http-immediate',{recursive:true});
let worker=(await fs.readFile(root+'http-invocation-trace/worker.mjs','utf8')).replaceAll('\r\n','\n');
worker='let auditDefer=false,auditLoopMode=false;\n'+worker;
worker=worker.replace('async function measureAsyncPhase(name, work) {',`async function measureAsyncPhase(name, work) {
 if(name==='renderMs'&&auditDefer&&!auditLoopMode){const queued=performance.now();await new Promise(resolve=>setImmediate(resolve));auditAdd('renderQueue',performance.now()-queued);}
`);
worker=worker.replace(" if (pathname === '/__exact-benchmark/audit-start')", " if(pathname==='/__exact-benchmark/audit-mode'){auditDefer=url.searchParams.get('defer')==='1';writeJson(response,{deferred:auditDefer});return;}\n if (pathname === '/__exact-benchmark/audit-start')");
worker=worker.replace('writeJson(response,{cpu:process.cpuUsage()});','writeJson(response,{cpu:process.cpuUsage(),deferred:auditDefer});');
const old=" if (pathname === '/__exact-benchmark/audit-loop') { await participant.renderOnly(10000); audit={}; resetTelemetry(); const result=await participant.renderOnly(10000); writeJson(response,{audit,responseBytes:result.responseBytes}); return; }";
if(!worker.includes(old))throw Error('Missing loop control');
worker=worker.replace(old," if(pathname==='/__exact-benchmark/audit-loop'){auditLoopMode=true;try{await participant.renderOnly(10000);audit={};resetTelemetry();const result=await participant.renderOnly(10000);writeJson(response,{audit,responseBytes:result.responseBytes,meanMs:result.samplesMs.reduce((a,b)=>a+b,0)/result.samplesMs.length});}finally{auditLoopMode=false;}return;}");
await fs.writeFile(root+'http-immediate/worker.mjs',worker);
let runner=(await fs.readFile(root+'http-invocation-trace-run.mjs','utf8')).replaceAll('http-invocation-trace/','http-immediate/').replaceAll('paired-steady-state-cpu-profile','same-worker-event-loop-deferral');
runner=runner.replace("exact:'framework-comparison/participants/exact/dist-server/server-entry.js'","exact:'.tmp/ssr-large-profile/component-forwarding-integrated/server-entry.js'");
runner=runner.replace("for(const phase of ['http']){","for(const phase of ['normal','immediate','normal']){\n const modeResult=await controlSsrWorker(worker,'audit-mode?defer='+(phase==='immediate'?'1':'0'));assert.equal(modeResult.deferred,phase==='immediate');");
runner=runner.replace("const before=await controlSsrWorker(worker,'audit-start');","const before=await controlSsrWorker(worker,'audit-start');assert.equal(before.deferred,phase==='immediate');");
runner=runner.replace('report.complete=true;',"assert.equal(report.blocks.length,12);report.complete=true;");
await fs.writeFile(root+'http-immediate-run.mjs',runner);
