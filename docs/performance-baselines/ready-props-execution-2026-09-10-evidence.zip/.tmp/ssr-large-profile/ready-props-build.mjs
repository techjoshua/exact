import fs from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
let code=fs.readFileSync(root+'direct-execution-integrated/server-entry.js','utf8');
assert.equal(createHash('sha256').update(code).digest('hex'),'2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18');
const start=code.indexOf('function executeDirectSsrComponent(');
const end=code.indexOf('\nfunction performanceNow()',start);
assert.ok(start>0&&end>start);
const old=code.slice(start,end);
const marker='\t\tconst stateless =';
const bodyStart=old.indexOf(marker);
assert.ok(bodyStart>0);assert.ok(old.endsWith('\n\t});\n}'));
const body=old.slice(bodyStart,-'\n\t});\n}'.length).replace(/^\t/gm,'');
const replacement=`function executeDirectSsrComponent(context, contract, rawProps, parent, options, sink, scalarPropsProven = false) {
 const server = contract.artifact.execution;
 if (server?.lane !== "direct" || server.classification !== "synchronous" || !server.render) return void 0;
 const props = scalarPropsProven ? rawProps : prepareComponentProps(rawProps, server.deferredTaskProps, options.signal);
 return props instanceof Promise ? props.then((prepared) => executePreparedDirectComponent(context, contract, prepared, parent, options, sink)) : executePreparedDirectComponent(context, contract, props, parent, options, sink);
}
function executePreparedDirectComponent(context, contract, props, parent, options, sink) {
 const artifact = contract.artifact;
 const server = artifact.execution;
${body}
}`;
code=code.slice(0,start)+replacement+code.slice(end);
fs.mkdirSync(root+'ready-props',{recursive:true});fs.writeFileSync(root+'ready-props/server-entry.js',code);
const hash=createHash('sha256').update(code).digest('hex');console.log(hash);
let pressure=fs.readFileSync(root+'direct-execution-integrated-pressure.mjs','utf8').replaceAll('direct-execution-integrated-pressure','ready-props-pressure');
pressure=pressure.replace("root+'direct-execution-integrated/server-entry.js'","root+'ready-props/server-entry.js'").replace("root+'current-target-integrated/server-entry.js'","root+'direct-execution-integrated/server-entry.js'");
fs.writeFileSync(root+'ready-props-pressure.mjs',pressure);
let allocations=fs.readFileSync(root+'direct-execution-target-allocations.mjs','utf8');
const begin=allocations.indexOf('const variants={');const finish=allocations.indexOf('\nconst worker=',begin);
assert.ok(begin>0&&finish>begin);
allocations=allocations.slice(0,begin)+`const variants={
 previous:['current-target-integrated','6d92194f2ee395f4e4e5267b8719bc1160a96ce7bc16f1a6bbdc74f98aba4997'],
 integrated:['direct-execution-integrated','2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18'],
 candidate:['ready-props','${hash}']
};`+allocations.slice(finish);
allocations=allocations.replaceAll('direct-execution-target-allocations','ready-props-allocations').replaceAll('direct-execution-allocation-','ready-props-allocation-');
fs.writeFileSync(root+'ready-props-allocations.mjs',allocations);
