import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';
let code=fs.readFileSync(root+'ready-props/server-entry.js','utf8');
assert.equal(createHash('sha256').update(code).digest('hex'),'0db2388cc9aa4d3f6b56c6a27eafe4b03ccb110dd1aca0242b6b302948df514f');
function replace(from,to){assert.equal(code.split(from).length-1,1,from);code=code.replace(from,to);}
replace(' const server = contract.artifact.execution;',' const artifact = contract.artifact;\n const server = artifact.execution;');
replace('executePreparedDirectComponent(context, contract, prepared, parent, options, sink)', 'executePreparedDirectComponent(context, contract, prepared, parent, options, sink, artifact, server)');
replace(' : executePreparedDirectComponent(context, contract, props, parent, options, sink);', ' : executePreparedDirectComponent(context, contract, props, parent, options, sink, artifact, server);');
replace('function executePreparedDirectComponent(context, contract, props, parent, options, sink) {\n const artifact = contract.artifact;\n const server = artifact.execution;', 'function executePreparedDirectComponent(context, contract, props, parent, options, sink, artifact, server) {');
fs.mkdirSync(root+'ready-props-stable',{recursive:true});fs.writeFileSync(root+'ready-props-stable/server-entry.js',code);
console.log(createHash('sha256').update(code).digest('hex'));
let pressure=fs.readFileSync(root+'ready-props-pressure.mjs','utf8').replaceAll('ready-props-pressure','ready-props-stable-pressure').replace("root+'ready-props/server-entry.js'","root+'ready-props-stable/server-entry.js'");
fs.writeFileSync(root+'ready-props-stable-pressure.mjs',pressure);
