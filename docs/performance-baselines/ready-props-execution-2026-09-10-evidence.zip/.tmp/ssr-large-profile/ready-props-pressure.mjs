import fs from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
let code=fs.readFileSync(root+'ready-props/server-entry.js','utf8');
code=code+`
const auditPressure=Symbol('auditPressure');
let auditSuspensions=0;
for(const Sink of [StringProgramSink,CapturedProgramSink]){
const auditOriginalReady=Sink.prototype.ready;
Sink.prototype.ready=function(){
 const pending=auditOriginalReady.call(this);if(pending)return pending;
 const count=this[auditPressure]=(this[auditPressure]??0)+1;
 if(count%3===0){auditSuspensions++;return Promise.resolve();}
};
}

export function auditReadSuspensions(){return auditSuspensions;}
`;
const path=root+'ready-props-pressure-entry.mjs';fs.writeFileSync(path,code);
const candidate=await import(pathToFileURL(resolve(path))),control=await import(pathToFileURL(resolve(root+'direct-execution-integrated/server-entry.js')));
const rows=[];
for(const scenario of ['small','large'])for(const mode of ['string','stream']){
 const before=candidate.auditReadSuspensions();
 await Promise.all(Array.from({length:3},async(_,request)=>{
  const data=JSON.parse(fs.readFileSync('.tmp/positional-leaves/data.json'));
  if(scenario==='large')data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
  data.incidents[0].title='Distinct request '+request;
  const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
  const render=mod=>mode==='string'?mod.renderParticipant(data,'/incidents/inc-101',options):Promise.resolve(mod.renderParticipantStream(data,'/incidents/inc-101',options)).then(value=>new Response(value).text());
  const [expected,actual]=await Promise.all([render(control),render(candidate)]);assert.equal(actual,expected);
 }));
 const suspensions=candidate.auditReadSuspensions()-before;assert.ok(suspensions>0,scenario+' '+mode+' did not suspend');
 rows.push({scenario,mode,requests:3,suspensions});
}

fs.writeFileSync(root+'ready-props-pressure-'+(process.versions.bun?'bun':'node')+'.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));
