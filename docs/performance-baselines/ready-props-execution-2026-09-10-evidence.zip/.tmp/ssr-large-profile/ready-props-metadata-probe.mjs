import fs from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';const rows=[];
for(const variant of ['direct-execution-integrated','ready-props','ready-props-stable']){
 const path=root+variant+'-metadata-entry.mjs';
 fs.writeFileSync(path,fs.readFileSync(root+variant+'/server-entry.js','utf8')+'\nexport {executeDirectSsrComponent,createSsrContext};\n');
 const mod=await import(pathToFileURL(resolve(path)));
 for(const pending of [false,true]){
  let reads=0;
  const artifact=value=>({id:value,execution:{lane:'direct',classification:'synchronous',mode:'stateless',render(){return value;}}});
  const first=artifact('selected-first'),second=artifact('selected-again');
  const contract={get artifact(){reads++;return reads===1?first:second;}};
  const output=await mod.executeDirectSsrComponent(mod.createSsrContext({}),contract,{value:pending?Promise.resolve('ready'):'ready'},undefined,{},content=>content.children.join(''));
  assert.equal(reads,variant==='ready-props'?2:1);
  assert.equal(output,variant==='ready-props'?'selected-again':'selected-first');
  rows.push({variant,pending,reads,output});
 }
}
fs.writeFileSync(root+'ready-props-metadata-'+(process.versions.bun?'bun':'node')+'.json',JSON.stringify(rows,null,2));
console.log(JSON.stringify(rows));
