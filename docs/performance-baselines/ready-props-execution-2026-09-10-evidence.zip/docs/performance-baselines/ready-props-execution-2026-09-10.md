# Direct execution after props preparation

Status: two isolated prototypes, neither integrated. The first reduces sampled allocation but changes metadata read timing. The corrected variant preserves the original selected metadata and passes focused probes; its performance remains unmeasured. Production remains the validated execution-target integration.

## Hypothesis

`executeDirectSsrComponent` passes its entire execution body as a callback to mapRenderValue even when props are already ready. The experiment extracts that body into a regular internal function, calls it directly for available props, and creates a continuation only for pending props. Child issuance, component frames, publication, observer hooks, rollback and disposal still run through the existing implementation. No second rendering engine or sink mode branch is introduced.

The working hypothesis is a small reduction in allocation, approximately 1-3%, with a possible 0-3% timing benefit from avoiding one callback per synchronous component. Those timing expectations have not been tested. Remaining nested callbacks and their captured state still exist, and optimized allocation cannot be inferred from source closure counts alone.

## Allocation capture and integration confirmation

Twelve fresh Node 26.8.1 production processes use two reversed orders for three variants and two fixture sizes. Each process performs 50,000 warmups and samples 10,000 renders with a 16 KiB interval, including minor-collected and major-collected objects. One process runs at a time with below-normal priority 10 while the user uses the PC. Complete document hashes match. Values are estimated allocated bytes per render, not retained memory or exact object counts.

| Fixture | Before execution-target integration | Integrated current build | First props prototype |
| --- | ---: | ---: | ---: |
| 3 incidents | 70,077 | 67,679 | 66,591 |
| 96 incidents | 525,233 | 497,411 | 485,082 |

Both pairs improve for both comparisons and fixture sizes. The preceding-to-integrated comparison confirms the retained source optimization: approximately 3.4% lower allocation for the small page and 5.3% lower for the large page. The first props prototype reduces allocation a further 1.6% and 2.5%, respectively. These results do not establish throughput, GC count or GC duration changes.

## Read-order correction

The first extraction reads `contract.artifact` and `artifact.execution` again inside the helper. The original implementation retains the values selected before props preparation. Although compiler metadata is normally frozen data, freezing alone does not make accessor results stable. There is no reason for this optimization to add metadata reads or move selection across props settlement.

The corrected prototype passes the already selected artifact and execution metadata into the helper, retaining original read order for both ready and pending props. It adds two internal arguments instead of allocating a wrapper. The first prototype's allocation numbers must not be attributed to this revised code before measuring it.

A diagnostic exposes the existing internal executor from each frozen bundle and supplies an artifact getter returning distinct selections on successive reads. This is a read-order probe, not a claim that such hand-authored metadata is a public application API. On both Node and Bun, with ready and promised props:

- the control reads once and renders the first selection;
- the first prototype reads twice and renders the second selection;
- the corrected prototype reads once and renders the first selection.

Both prototypes separately pass 24 complete-output comparisons across Node/Bun string/stream with three concurrent requests per fixture and forced ready-call suspension. Each runtime induces 183/105 small string/stream suspensions and 1,113/663 large suspensions. These probes supplement rather than replace acceptance coverage for props rejection, lifecycle failures, observers and scheduled work.

## Remaining work and evidence

The corrected variant needs allocation and response-consumption measurements before a source integration decision. If retained, the internal executor should document selected metadata ownership and preserve the complete existing lifecycle behavior. No source API or compiler ABI changed during this experiment.

Preceding control SHA-256: `6d92194f2ee395f4e4e5267b8719bc1160a96ce7bc16f1a6bbdc74f98aba4997`.

Current integrated SHA-256: `2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18`.

First prototype SHA-256: `0db2388cc9aa4d3f6b56c6a27eafe4b03ccb110dd1aca0242b6b302948df514f`.

Corrected prototype SHA-256: `99f76e4e06e41960c5a6da7a1a6669e197051160e5987f5ba6eefb17cbd9d3ba`.

`ready-props-execution-2026-09-10-evidence.zip` preserves the four frozen bundles, asserted builders, allocation driver and worker, twelve heap profiles and summary, suspension and metadata probes/results, relevant source snapshots and this report. The preceding integrated optimization's performance confirmation is now available; the overall Node string and HTTP comparison work remains unfinished.
