import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/';
const entries={};
for(const [variant,source]of [['control_a','proven-reference-integrated/server-entry.js'],['control_b','proven-reference-integrated/server-entry.js'],['candidate','projector-inline-primitives-integrated/server-entry.js']]){
 const dir=d+'projector-aa-'+variant;fs.mkdirSync(dir,{recursive:true});entries[variant]=dir+'/server-entry.js';fs.copyFileSync(d+source,entries[variant]);
}
const orders=[['control_a','control_b','candidate'],['candidate','control_b','control_a'],['control_b','candidate','control_a'],['control_a','candidate','control_b'],['candidate','control_a','control_b'],['control_b','control_a','candidate']];
const rows=[];
for(let round=0;round<orders.length;round++)for(const variant of orders[round]){
 const entry=entries[variant];
 const r=spawnSync('bun',[d+'final-rope-worker.mjs',entry,'string','assets','20000'],{windowsHide:true,encoding:'utf8',env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr+r.stdout);
 const row={round,variant,artifactSha256:createHash('sha256').update(fs.readFileSync(entry)).digest('hex'),...JSON.parse(r.stdout)};
 if(rows.length)assert.equal(row.hash,rows[0].hash);
 rows.push(row);fs.writeFileSync(d+'projector-aa-results.json',JSON.stringify(rows,null,2));console.log(round,variant,row.usPerRender.toFixed(2));
}
