import {readFile,writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
const [entry,mode='string',scenario='small',iterationsText='8000']=process.argv.slice(2);
const packageRequire=createRequire(resolve(entry));
const reactResolution=entry.includes('participants/react/')?{version:packageRequire('react-dom/package.json').version,entry:packageRequire.resolve('react-dom/server')}:undefined;
const mod=await import(pathToFileURL(resolve(entry)));
const data=JSON.parse(await readFile('.tmp/positional-leaves/data.json','utf8'));
if(scenario==='large')data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
if(scenario==='unicode')for(const row of data.incidents)row.title+=' caf\u00e9 \ud83d\ude80 \u65e5\u672c\u8a9e'.repeat(100);
const clientTags=scenario==='empty'?'':'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">';
const render=()=>mod.renderParticipant(data,'/incidents/inc-101',{clientTags});
const stream=async()=>new Response(await mod.renderParticipantStream(data,'/incidents/inc-101',{clientTags})).text();
const count=100000;let html;const windows=[];
for(let block=0;block<20;block++){
 const started=performance.now();for(let i=0;i<5000;i++)html=await render();
 windows.push({block,completed:(block+1)*5000,usPerRender:(performance.now()-started)/5000*1000});
}
const elapsed=windows.reduce((n,w)=>n+w.usPerRender*5,0);
if(!/^<!doctype html>/i.test(html)||!/<\/body><\/html>\s*$/i.test(html))throw Error('Incomplete document');
if(scenario!=='empty')for(const asset of ['/assets/app.js','/assets/vendor.js','/assets/app.css','/assets/theme.css'])if(!html.includes(asset))throw Error('Missing asset '+asset);
console.log(JSON.stringify({windows,reactResolution,entry,mode,scenario,iterations:count,elapsedMs:elapsed,usPerRender:elapsed/count*1000,bytes:Buffer.byteLength(html),hash:createHash('sha256').update(html).digest('hex'),structuralHash:createHash('sha256').update(html.replace(/(<!--\/?exact:fragment:)[0-9a-z]+(:)/g,'$1<ordinal>$2')).digest('hex'),runtime:process.versions.bun??process.version}));
