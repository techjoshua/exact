import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
let source=readFileSync(dir+'marker-hex-current.mjs','utf8');
const before='value.length >= 16 && !state.path ? readPositionalProjector(schema[1]) : void 0';
if(source.split(before).length!==2)throw Error('Unexpected projector selection site');
source=source.replace(before,'(value.length >= 16 || value.length > 0 && state.active instanceof Set) && !state.path ? readPositionalProjector(schema[1]) : void 0');
writeFileSync(dir+'projector-warm.mjs',source);
const runner=readFileSync(dir+'map-fragment-run.mjs','utf8').replaceAll('map-fragment','projector-warm');
writeFileSync(dir+'projector-warm-run.mjs',runner);
