import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
fs.writeFileSync(d+'projector-warm50-node-run.mjs',fs.readFileSync(d+'projector-warm50-run.mjs','utf8').replace("['bun']","['node']").replaceAll('projector-warm50-results.json','projector-warm50-node-results.json'));
