import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
let worker=fs.readFileSync(d+'final-rope-worker.mjs','utf8');
const start=worker.indexOf('const count=Number(iterationsText)');const end=worker.indexOf('if(!/^<!doctype html>',start);
if(start<0||end<start)throw Error('Worker boundaries changed');
worker=worker.slice(0,start)+`const count=100000;let html;const windows=[];
for(let block=0;block<20;block++){
 const started=performance.now();for(let i=0;i<5000;i++)html=await render();
 windows.push({block,completed:(block+1)*5000,usPerRender:(performance.now()-started)/5000*1000});
}
const elapsed=windows.reduce((n,w)=>n+w.usPerRender*5,0);
`+worker.slice(end);
worker=worker.replace('JSON.stringify({reactResolution,','JSON.stringify({windows,reactResolution,');
fs.writeFileSync(d+'projector-warmup-worker.mjs',worker);
