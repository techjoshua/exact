import fs from 'node:fs';import {spawnSync} from 'node:child_process';import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/';const entries={current:d+'proven-reference-integrated/server-entry.js',candidate:d+'projector-inline-primitives-integrated/server-entry.js',react:'framework-comparison/participants/react/dist-server/server-entry.js'};const rows=[];
for(let round=0;round<2;round++)for(const variant of (round?Object.keys(entries).reverse():Object.keys(entries))){
 const result=spawnSync('bun',[d+'projector-warmup-worker.mjs',entries[variant],'string','assets'],{windowsHide:true,encoding:'utf8',env:{...process.env,NODE_ENV:'production'}});
 if(result.status!==0)throw Error(result.stderr+result.stdout);
 const row={round,variant,...JSON.parse(result.stdout)};const peer=rows.find(r=>(r.variant==='react')===(variant==='react'));if(peer)assert.equal(row.hash,peer.hash);
 rows.push(row);fs.writeFileSync(d+'projector-warmup-results.json',JSON.stringify(rows,null,2));console.log(variant,round,row.windows.map(w=>w.usPerRender.toFixed(1)).join(' '));
}
