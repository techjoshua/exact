import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
fs.writeFileSync(d+'projector-warm50-worker.mjs',fs.readFileSync(d+'final-rope-worker.mjs','utf8').replace('warmups=Math.min(5000,count)','warmups=50000'));
let runner=fs.readFileSync(d+'projector-inline-primitives-small-bun-confirm.mjs','utf8').replace('round<4','round<2').replaceAll('final-rope-worker.mjs','projector-warm50-worker.mjs').replaceAll('projector-inline-primitives-small-bun-confirm-results.json','projector-warm50-results.json');
fs.writeFileSync(d+'projector-warm50-run.mjs',runner);
