import fs from 'node:fs';
import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/';
let code=fs.readFileSync(d+'proven-reference-http.mjs','utf8');
const before="population?['react','candidate','baseline']:['baseline','candidate','react']";
assert.ok(code.includes(before));
code=code.replace(before,"population?['react','baseline']:['baseline','react']");
code=code.replaceAll('proven-reference-http-before','projector-inline-primitives-http-before').replaceAll('durationMs:2000','durationMs:10000').replaceAll('durationMs:4000','durationMs:6000');
fs.writeFileSync(d+'projector-warm-http.mjs',code);
