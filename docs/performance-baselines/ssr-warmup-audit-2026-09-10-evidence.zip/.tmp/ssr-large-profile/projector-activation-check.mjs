import fs from 'node:fs';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const d='.tmp/ssr-large-profile/';
const results=[];
for(const [variant,entry] of [['current','proven-reference-integrated/server-entry.js'],['candidate','projector-inline-primitives-integrated/server-entry.js']]){
 let source=fs.readFileSync(d+entry,'utf8');
 const marker='function registerPositionalProjector(schema, version, project) {';assert.equal(source.split(marker).length,2);
 source='var __projectorCalls = 0;\n'+source.replace(marker,marker+'\nconst original = project; project = function(...args){__projectorCalls++;return original.apply(this,args);};');
 source+='\nexport function resetProjectorCalls(){__projectorCalls=0;} export function readProjectorCalls(){return __projectorCalls;}';
 const file=d+'projector-activation-'+variant+'.mjs';fs.writeFileSync(file,source);
 const mod=await import(pathToFileURL(resolve(file)));
 for(const count of [3,96])for(const mode of ['string','stream']){
  const data=JSON.parse(fs.readFileSync('.tmp/positional-leaves/data.json','utf8'));
  data.incidents=Array.from({length:count},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
  mod.resetProjectorCalls();
  const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
  const html=mode==='string'?await mod.renderParticipant(data,'/incidents/inc-101',options):await new Response(await mod.renderParticipantStream(data,'/incidents/inc-101',options)).text();
  const calls=mod.readProjectorCalls();assert.equal(calls,count===3?0:96);assert.ok(html.endsWith('</body></html>'));
  results.push({variant,count,mode,calls});
 }
}
fs.writeFileSync(d+'projector-activation-results.json',JSON.stringify({runtime:process.versions,results},null,2));
console.log(results);
