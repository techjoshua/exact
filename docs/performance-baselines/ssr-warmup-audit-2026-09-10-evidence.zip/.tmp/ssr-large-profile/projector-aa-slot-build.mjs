import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
let code=fs.readFileSync(d+'projector-aa-run.mjs','utf8');
code=code.replace('const rows=[];',"const slot=d+'projector-aa-slot';fs.mkdirSync(slot,{recursive:true});\nconst rows=[];");
code=code.replace('const entry=entries[variant];',"const entry=slot+'/server-entry.js';fs.copyFileSync(entries[variant],entry);");
code=code.replaceAll('projector-aa-results.json','projector-aa-slot-results.json');
fs.writeFileSync(d+'projector-aa-slot-run.mjs',code);
