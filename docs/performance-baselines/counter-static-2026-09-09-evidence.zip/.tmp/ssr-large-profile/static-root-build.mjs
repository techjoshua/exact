import ts from 'typescript';
import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';const source=readFileSync(dir+'tail-current.mjs','utf8');
const sf=ts.createSourceFile('input.mjs',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const hoisted=[];
const result=ts.transform(sf,[context=>{
 const f=context.factory;
 function visit(node){
  node=ts.visitEachChild(node,visit,context);
  if(!ts.isCallExpression(node)||!ts.isIdentifier(node.expression)||node.expression.text!=='createPreparedServerRenderProgram'||!ts.isArrayLiteralExpression(node.arguments[1]))return node;
  const values=node.arguments[1],bag=values.elements[0];
  if(!bag||!ts.isObjectLiteralExpression(bag)||!bag.properties.every(p=>ts.isPropertyAssignment(p)&&(ts.isIdentifier(p.name)||ts.isStringLiteral(p.name))&&p.name.text!=='__proto__'&&(ts.isStringLiteral(p.initializer)||ts.isNumericLiteral(p.initializer)||[ts.SyntaxKind.TrueKeyword,ts.SyntaxKind.FalseKeyword,ts.SyntaxKind.NullKeyword].includes(p.initializer.kind))))return node;
  const id=f.createIdentifier('__staticRootExperiment_'+hoisted.length);hoisted.push({id,bag});
  return f.updateCallExpression(node,node.expression,node.typeArguments,[node.arguments[0],f.updateArrayLiteralExpression(values,[id,...values.elements.slice(1)]),...node.arguments.slice(2)]);
 }
 return root=>ts.visitNode(root,visit);
}]);
const printer=ts.createPrinter();
const declarations=hoisted.map(({id,bag})=>`const ${id.text}=Object.freeze(${printer.printNode(ts.EmitHint.Expression,bag,sf)});`).join('\n');
writeFileSync(dir+'static-root.mjs',declarations+'\n'+printer.printFile(result.transformed[0]));
writeFileSync(dir+'static-root-control.mjs',printer.printFile(sf));result.dispose();
console.log({hoisted:hoisted.length});
