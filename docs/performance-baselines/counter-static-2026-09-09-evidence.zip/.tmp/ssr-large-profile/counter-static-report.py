import pathlib,json,statistics,hashlib,zipfile
root=pathlib.Path.cwd();tmp=root/'.tmp/ssr-large-profile';base=root/'docs/performance-baselines/counter-static-2026-09-09'
results={};tables={}
for name,file,previous,current,count in [('counter','byte-counter-results.json','tail-current','portable-counter',32),('static','static-root-results.json','static-root-control','static-root',24)]:
 rows=json.loads((tmp/file).read_text(encoding='utf-8'));assert len(rows)==count
 summary=[]
 for runtime,mode,scenario in sorted({(r['runtimeId'],r['mode'],r['scenario']) for r in rows}):
  group=[r for r in rows if (r['runtimeId'],r['mode'],r['scenario'])==(runtime,mode,scenario)]
  before=statistics.median(r['usPerRender'] for r in group if r['variant']==previous)
  after=statistics.median(r['usPerRender'] for r in group if r['variant']==current)
  pairs=[]
  for i in sorted({r['round'] for r in group}):
   values={r['variant']:r['usPerRender'] for r in group if r['round']==i}
   pairs.append(100*(values[current]/values[previous]-1))
  summary.append(dict(runtime=runtime,mode=mode,scenario=scenario,previousUs=before,candidateUs=after,pairedChanges=pairs,medianPairedChange=statistics.median(pairs)))
 results[name]=dict(summary=summary,populations=rows)
 tables[name]='\n'.join(f"| {s['runtime']} | {s['mode']} | {s['scenario']} | {s['previousUs']:.2f} | {s['candidateUs']:.2f} | {s['medianPairedChange']:+.1f}% |" for s in summary)
base.with_suffix('.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
header='| Runtime | Mode | Scenario | Control us | Candidate us | Paired change |\n| --- | --- | --- | ---: | ---: | ---: |\n'
report='''# Byte-counter and static-root experiments, September 9, 2026

Status: neither prototype adopted. The retained build remains document-tail plus scalar-root and
earlier improvements. No production source, API, ABI, or public benchmark chart changed here.

## Root byte-count audit and experiment

The prior profile attributed substantial Bun self-samples to native byteLength through the root
sink's charge/append. Inspection of render/tree-output.ts confirms that this is the exact root
UTF-8 check after rendering with a conservative UTF-16 character bound. It is not a second count
of already-accounted descendant bytes. It remains necessary for exact output-limit enforcement.

Hypothesis: the existing portable counter might outperform the host counter on mostly ASCII
documents by using native regex searches to skip ASCII spans, yielding at most a few percent overall.
The bundle-only experiment changes only utf8ByteLength dispatch to the existing portable function.
It does not change encoding, counters, limits, surrogate handling, or the algorithms themselves.

Thirty-two fresh production processes cover Node/Bun, string/stream, the 96-incident large case,
and the existing Unicode case (3 incidents with repeated accented, astral, and Japanese title text).
Each uses 5,000 warmups and 12,000 measured renders, with two reversed-order pairs per combination.

Median microseconds per complete render, lower is better. Positive paired change means slower.
Paired change is the median of each round's percentage change, not a ratio of independent medians.

'''+header+tables['counter']+'''

Native counting wins throughout these cases, including every paired Unicode result. Portable
counting is retained as the host-capability fallback, not selected as a performance optimization.
The result rejects this hypothesis without weakening validation or adding runtime-specific dispatch.

## Static-root allocation experiment

Hypothesis: sharing immutable static attribute objects could reduce small-document rendering time
by roughly 1-3%. An AST pass hoists 21 call-site root objects whose properties are all literal
primitives or absent, freezes them once, and reuses them in prepared program invocations. It skips
spreads, computed keys, prototype keys, and nonliteral initializers. Dynamic roots are unchanged.
Twenty-one is the number of eligible source sites, not the number exercised on each request.

The control is the same retained bundle passed through the same TypeScript printer. Twenty-four
fresh processes cover Node/Bun and string/stream on the small 3-incident case, with 5,000 warmups,
20,000 measured renders, and three alternating-order pairs per combination.

'''+header+tables['static']+'''

Results are mixed. Bun strings show a small gain in two of three pairs, while Node strings regress
in two of three pairs. Stream results also vary. These short shared-PC runs do not establish a
consistent benefit, so the experiment does not justify a compiler change at this point. This is not
evidence that immutable hoisting can never help; it lowers its priority relative to the measured
hydration projection and allocation costs. No minimum percentage cutoff was used for acceptance.

## Scope and evidence

All 56 timing populations validate full-document framing and final complete-response SHA-256
against their eXact control. Streams are fully consumed through Response.text, asset tags are empty,
and both runtimes use the same portable renderer artifact. These are renderer experiments, not
HTTP or browser timing. React was not rerun. No production tests were rerun for discarded bundle
experiments; existing UTF-8 tests already compare native and portable counters with platform
encoding across all UTF-16 code units and mixed surrogate boundaries.

The JSON and accompanying ZIP retain raw populations, artifact hashes, prototypes and controls,
builders, runners, fixed input, and the production sources inspected. Child processes exited and
no benchmark server was started. Next work should investigate hydration projection allocation and
repeated shape/field work rather than remove exact byte accounting or retry this counter dispatch.
'''
base.with_suffix('.md').write_text(report,encoding='utf-8')
files=[base.with_suffix('.md'),base.with_suffix('.json')]+[tmp/n for n in ['tail-current.mjs','portable-counter.mjs','byte-counter-build.mjs','byte-counter-run.mjs','byte-counter-run.log','byte-counter-results.json','static-root.mjs','static-root-control.mjs','static-root-build.mjs','static-root-run.mjs','static-root-run.log','static-root-results.json','long-worker.mjs','counter-static-report.py']]
files += [root/p for p in ['.tmp/positional-leaves/data.json','packages/ssr/src/render/tree-output.ts','packages/ssr/src/render/output-buffer.ts','packages/ssr/src/render/utf8.ts','packages/ssr/src/render/utf8-encoding.ts','packages/ssr/src/render/utf8.test.ts']]
archive=base.parent/(base.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(root).as_posix())
 z.writestr('sha256.json',json.dumps({p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 print(json.dumps(dict(files=len(z.namelist()),bytes=archive.stat().st_size,summary={k:v['summary'] for k,v in results.items()}),indent=2))
