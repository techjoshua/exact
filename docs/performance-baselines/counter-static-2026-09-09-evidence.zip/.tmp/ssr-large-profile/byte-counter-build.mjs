import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
const source=readFileSync(dir+'tail-current.mjs','utf8');
const original='return nativeUtf8ByteLength ? nativeUtf8ByteLength(value) : portableUtf8ByteLength(value);';
if(source.split(original).length!==2)throw Error('Byte counter dispatch not unique');
writeFileSync(dir+'portable-counter.mjs',source.replace(original,'return portableUtf8ByteLength(value);'));
