import fs from 'node:fs';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/',input=root+'proven-reference-integrated/server-entry.js';let s=fs.readFileSync(input,'utf8');
const call='createPreparedServerComponentReferenceFromPlainProps(component, props)';assert.equal(s.split(call).length-1,1);s=s.replace(call,'createPreparedServerComponentReferenceFromPlainProps(component, props, scalarPropKey)');
const a=s.indexOf('function createPreparedServerComponentReferenceFromPlainProps('),b=s.indexOf('\n/** Reads only the direct reference',a);assert.ok(a>0&&b>a);
s=s.slice(0,a)+`function createPreparedServerComponentReferenceFromPlainProps(type,props,key) {
 const domain=currentComponentDomain(),contract=readPreparedExactExecutableComponentContract(type);
 const value=key===null?null:props[key];
 if(value===null || (typeof value!=='object' && typeof value!=='function'))
  return domain?{contract,props,children:emptyServerComponentChildren,domain,[PreparedServerComponentReference]:true,[scalarPropsProof]:props}
  :{contract,props,children:emptyServerComponentChildren,[PreparedServerComponentReference]:true,[scalarPropsProof]:props};
 const reference={[PreparedServerComponentReference]:true,contract,props,children:emptyServerComponentChildren};
 if(domain)reference.domain=domain;return reference;
}`+s.slice(b);
const dir=root+'complete-proof';fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(dir+'/server-entry.js',s);fs.writeFileSync(dir+'/provenance.json',JSON.stringify({input,inputSha256:createHash('sha256').update(fs.readFileSync(input)).digest('hex'),outputSha256:createHash('sha256').update(s).digest('hex'),hypothesis:'Initialize the complete eligible scalar reference including its proof, retaining prototype/own-key order and fallback behavior. Node V8 complete six-field literal uses in-object fields without a PropertyArray. Expected 1-3% large-tree improvement, with possible extra cost from repeated scalar checks. Isolated prototype only.'},null,2));
for(const [name,source]of [['current',fs.readFileSync(input,'utf8')],['candidate',s]])fs.writeFileSync(root+'complete-proof-check-'+name+'.mjs',source+'\nexport {generatedSsrOperations as ops,SeverityBadge as Child,consumeScalarPropsProof as consume,currentComponentDomain as domain};\n');
