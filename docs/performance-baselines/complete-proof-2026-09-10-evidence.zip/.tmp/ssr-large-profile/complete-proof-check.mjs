import assert from 'node:assert/strict';
const before=await import('./complete-proof-check-current.mjs'),after=await import('./complete-proof-check-candidate.mjs');
for(const value of ['high',null,{},()=>{}]){
 const outputs=[];for(const mod of [before,after]){
  const props={severity:value},inv={};const ref=mod.ops.reference(mod.Child,props,'severity',inv);
  outputs.push({prototype:Object.getPrototypeOf(ref),keys:Reflect.ownKeys(ref).map(x=>typeof x==='symbol'?Symbol.keyFor(x):x),proof:mod.consume(ref,props)});
  props.key='changed';const second=mod.ops.reference(mod.Child,props,'severity',inv);assert.equal(second.key,'changed');assert.equal(mod.consume(second,second.props),false);
 }assert.deepEqual(outputs[0],outputs[1]);
}
console.log('Final prototype, own keys, scalar/object/function handling and reuse match');
