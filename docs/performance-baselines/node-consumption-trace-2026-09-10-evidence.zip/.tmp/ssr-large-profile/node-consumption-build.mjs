import fs from 'node:fs/promises';
const root = '.tmp/ssr-large-profile/';
await fs.mkdir(root + 'node-consumption', { recursive: true });
let worker = await fs.readFile(root + 'flat-invocation-large-worker.mjs', 'utf8');
worker = worker.replace("const render=()=>mod.renderParticipant(data,'/incidents/inc-101',{clientTags});", `const render=()=>mod.renderParticipant(data,'/incidents/inc-101',{clientTags});
const counted=async()=>{ const html=await render(); Buffer.byteLength(html); return html; };`);
worker = worker.replaceAll("html=mode==='string'?await render():", "html=mode==='counted'?await counted():mode==='string'?await render():");
await fs.writeFile(root + 'node-consumption-worker.mjs', worker);
