from pathlib import Path
import hashlib, json, zipfile
root = Path.cwd()
base = root / '.tmp/ssr-large-profile'
def archive(stem, files):
    report = root / 'docs/performance-baselines' / (stem + '-2026-09-10.md')
    files.update([report, Path(__file__).resolve()])
    for filename, sub in [('server-entry.js', 'dist-server'), ('bun-server-entry.js', 'dist-bun-server')]:
        retained = base / 'conditional-emission' / filename
        current = root / 'framework-comparison/participants/exact' / sub / filename
        assert retained.read_bytes() == current.read_bytes()
        files.update([retained, current, root / 'framework-comparison/participants/react' / sub / filename])
    files.add(root / '.tmp/positional-leaves/data.json')
    files.add(root / 'framework-comparison/src/ssr-benchmark-worker.mjs')
    files.add(root / 'framework-adapters/node-adapter/src/handler.ts')
    files.add(root / 'packages/server/src/response-body.ts')
    output = report.with_suffix('').with_name(stem + '-2026-09-10-evidence.zip')
    assert not output.exists()
    manifest = {f.relative_to(root).as_posix(): hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(files)}
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in sorted(files): z.write(f, f.relative_to(root).as_posix())
        z.writestr('SHA256.json', json.dumps(manifest, indent=2))
    with zipfile.ZipFile(output) as z:
        assert z.testzip() is None
        for name, digest in manifest.items(): assert hashlib.sha256(z.read(name)).hexdigest() == digest
    print(stem, 'verified', len(files), 'files')
files = set(f for f in (base / 'keyed-program-http').iterdir() if f.is_file())
files.update(f for f in base.glob('keyed-program-http*') if f.is_file())
files.update(f for f in (base / 'keyed-program').iterdir() if f.is_file())
archive('keyed-program-http', files)
files = set()
for folder in ['node-consumption', 'node-http-trace']:
    files.update(f for f in (base / folder).iterdir() if f.is_file())
for pattern in ['node-consumption*', 'node-http-trace*', 'node-http-identity*']:
    files.update(f for f in base.glob(pattern) if f.is_file())
archive('node-consumption-trace', files)
