import fs from 'node:fs/promises';
import { spawn } from 'node:child_process';
import assert from 'node:assert/strict';
const root = '.tmp/ssr-large-profile/';
const rows = [];
for (let round = 0; round < 4; round++) for (const mode of (round % 2 ? ['encoded', 'counted'] : ['counted', 'encoded'])) for (const variant of (round % 2 ? ['react', 'exact'] : ['exact', 'react'])) {
    const entry = variant === 'exact' ? root + 'conditional-emission/server-entry.js' : 'framework-comparison/participants/react/dist-server/server-entry.js';
    const result = await new Promise((resolve, reject) => {
        const child = spawn(process.execPath, [root + 'node-consumption-worker.mjs', entry, mode, 'small', '20000'], { windowsHide: true, env: { ...process.env, NODE_ENV: 'production' } });
        let stdout = '', stderr = '';
        child.stdout.on('data', data => stdout += data);
        child.stderr.on('data', data => stderr += data);
        child.on('error', reject);
        child.on('exit', code => resolve({ code, stdout, stderr }));
    });
    assert.equal(result.code, 0, result.stderr);
    const row = { round, variant, ...JSON.parse(result.stdout.trim()) };
    rows.push(row);
    await fs.writeFile(root + 'node-consumption/results.json', JSON.stringify(rows, null, 2));
    console.log(round, mode, variant, row.usPerRender.toFixed(2), row.cpuMicrosPerRender.toFixed(2));
}
for (const variant of ['exact', 'react']) assert.equal(new Set(rows.filter(r => r.variant === variant).map(r => r.hash)).size, 1);
