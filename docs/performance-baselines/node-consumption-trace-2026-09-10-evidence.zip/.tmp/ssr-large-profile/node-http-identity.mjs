import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { startSsrLoadProcess } from '../../framework-comparison/src/ssr-load-process-owner.mjs';
import { startSsrWorker, stopSsrWorker } from '../../framework-comparison/src/ssr-worker-controller.mjs';
import { availableSsrRuntimes } from '../../framework-comparison/src/ssr-run-environment.mjs';
process.env.NODE_ENV = 'production';
const root = '.tmp/ssr-large-profile/';
const folder = root + 'node-consumption/';
const options = { clientTags: '<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">' };
const fixture = JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json', 'utf8'));
let service, worker;
const rows = [];
try {
    service = await startSsrLoadProcess('service');
    const [session, incidents] = await Promise.all(['session', 'incidents'].map(async path => (await fetch(service.url + '/api/' + path)).json()));
    const data = { ...session, ...incidents };
    assert.deepEqual(data, fixture);
    await fs.writeFile(folder + 'http-data.json', JSON.stringify(data, null, 2));
    for (const id of ['exact', 'react']) {
        const entry = resolve(id === 'exact' ? root + 'conditional-emission/server-entry.js' : 'framework-comparison/participants/react/dist-server/server-entry.js');
        worker = await startSsrWorker({ runtime: availableSsrRuntimes('node')[0], participantId: id, transport: 'node-http', workerPath: resolve('framework-comparison/src/ssr-benchmark-worker.mjs'), workingDirectory: resolve('framework-comparison'), serviceUrl: service.url,
            environment: { COMPARISON_SSR_RENDER_MODE: 'string', COMPARISON_SSR_BOUNDED_TELEMETRY: '1', COMPARISON_CLIENT_TAGS: options.clientTags, ...(id === 'exact' ? { COMPARISON_EXACT_SERVER_ENTRY: entry } : {}) } });
        const response = await fetch(worker.url + '?__benchmarkPreloaded=true');
        const http = await response.text();
        const mod = await import(pathToFileURL(entry));
        const local = await mod.renderParticipant(data, '/incidents/inc-101', options);
        const prior = await mod.renderParticipant(fixture, '/incidents/inc-101', options);
        assert.equal(http, local);
        await fs.writeFile(folder + id + '-http.html', http);
        await fs.writeFile(folder + id + '-fixture.html', prior);
        rows.push({ id, headers: Object.fromEntries(response.headers), bytes: Buffer.byteLength(http), httpHash: createHash('sha256').update(http).digest('hex'), fixtureHash: createHash('sha256').update(prior).digest('hex'), exactFixtureBytes: http === prior });
        await stopSsrWorker(worker); worker = undefined;
    }
    await fs.writeFile(folder + 'http-identity.json', JSON.stringify(rows, null, 2));
    console.log(JSON.stringify(rows, null, 2));
} finally {
    try { if (worker) await stopSsrWorker(worker); }
    finally { if (service) await service.close(); }
}
