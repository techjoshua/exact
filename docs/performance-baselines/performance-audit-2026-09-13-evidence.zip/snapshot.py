from pathlib import Path
import subprocess, hashlib, json, zipfile
root=Path('.tmp/performance-audit-2026-09-13')
files=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z']).decode().split('\0')
state={}
for name in sorted(set(files)):
 p=Path(name)
 if not p.is_file() or p.suffix not in ['.ts','.tsx','.js','.jsx','.mjs','.cjs','.go','.json','.css']:continue
 if name.split('/')[0] not in ['packages','native','framework-adapters','framework-comparison','scripts','component-libraries','plugins','react-adapters','apps'] and name not in ['package.json','package-lock.json']:continue
 if name.startswith('apps/docs/src/data/'):continue
 state[name]=hashlib.sha256(p.read_bytes()).hexdigest()
record={'baseCommit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'files':state}
for dest in [root,Path('.tmp/client-audit-2026-09-13'),Path('.tmp/ssr-audit-2026-09-13')]:
 (dest/'source-state.json').write_text(json.dumps(record,indent=2)+'\n')
(root/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD']))
with zipfile.ZipFile(root/'measured-sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in state:z.write(name,name)
print('Recorded',len(state),'source identities and exact source archive')
