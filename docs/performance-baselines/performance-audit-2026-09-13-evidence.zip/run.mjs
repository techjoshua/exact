import { spawn } from 'node:child_process';
import { openSync, closeSync, writeFileSync, readFileSync, existsSync, copyFileSync } from 'node:fs';
import { resolve } from 'node:path';
const root=resolve('.'), output=resolve('.tmp/performance-audit-2026-09-13');
const suite=resolve('framework-comparison'), client=resolve('.tmp/client-audit-2026-09-13'), ssr=resolve('.tmp/ssr-audit-2026-09-13');
const npm='C:/Program Files/nodejs-v26.8.1/node_modules/npm/bin/npm-cli.js';
process.env.npm_execpath=npm;
const journal=existsSync(output+'/execution.json')?JSON.parse(readFileSync(output+'/execution.json')):[];
async function run(name,args,cwd=root){
 if(journal.some(s=>s.name===name&&s.code===0)){console.log('RETAIN '+name);return;}
 const step={name,args,cwd,startedAt:new Date().toISOString()};journal.push(step);
 const save=()=>writeFileSync(output+'/execution.json',JSON.stringify(journal,null,2));save();
 console.log('START '+name);
 const log=openSync(output+'/'+name+'.log','w');
 try { await new Promise((done,fail)=>{const child=spawn(process.execPath,args,{cwd,env:process.env,stdio:['ignore',log,log],windowsHide:true});step.pid=child.pid;save();child.once('error',fail);child.once('exit',(code,signal)=>{step.code=code;step.signal=signal;code===0?done():fail(Error(name+' failed: '+(code??signal)));});}); }
 finally {closeSync(log);step.endedAt=new Date().toISOString();save();}
 console.log('DONE '+name);
}
await run('compiler-regression',['node_modules/vitest/vitest.mjs','run','--config','vitest.packages.config.ts','packages/hydrate/src/independent-islands.test.ts','packages/compiler/src/component-computation/preprocess.test.ts']);
await run('comparison-build',[npm,'run','build','-w','@exactjs/framework-comparison-suite']);
await run('client',[client+'/run.mjs']);
await run('bun-build',['src/build-bun.mjs'],suite);
for(const runtime of ['node','bun']) copyFileSync(suite+'/participants/exact/dist-'+(runtime==='bun'?'bun-':'')+'server/'+(runtime==='bun'?'bun-':'')+'server-entry.js',ssr+'/measured-exact-'+runtime+'.mjs');
await run('ssr',[ssr+'/run.mjs']);
await run('prepared',[ssr+'/prepared-run.mjs']);
console.log('COMPLETE benchmark capture');
