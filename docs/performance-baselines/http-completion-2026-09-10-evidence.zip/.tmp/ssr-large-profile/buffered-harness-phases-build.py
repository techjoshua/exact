from pathlib import Path
p=Path('.tmp/ssr-large-profile')
(p/'buffered-harness-phases').mkdir(exist_ok=True)
s=(p/'buffered-harness-http.mjs').read_text()
s=s.replace("for(const d of drivers)d.run(","const before=await (await fetch(worker.controlUrl+'/telemetry')).json();\nfor(const d of drivers)d.run(")
s=s.replace("const begin=Math.min", "const after=await (await fetch(worker.controlUrl+'/telemetry')).json();\nconst begin=Math.min")
s=s.replace('return {results,rps:', 'return {before,after,results,rps:')
s=s.replace("root+'buffered-harness/http.json'", "root+'buffered-harness-phases/http.json'")
(p/'buffered-harness-phases-http.mjs').write_text(s)
