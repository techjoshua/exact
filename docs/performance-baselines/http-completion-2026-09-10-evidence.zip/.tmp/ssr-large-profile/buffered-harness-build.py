from pathlib import Path
p=Path('.tmp/ssr-large-profile')
(p/'buffered-harness').mkdir(exist_ok=True)
s=(p/'buffered-completion-http.mjs').read_text().replace('buffered-completion','buffered-harness').replace('Buffered completion','Buffered harness')
(p/'buffered-harness-http.mjs').write_text(s)
