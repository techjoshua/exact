import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { setPriority } from 'node:os';
import { startSsrLoadProcess } from '../../framework-comparison/src/ssr-load-process-owner.mjs';
import { startSsrWorker, stopSsrWorker } from '../../framework-comparison/src/ssr-worker-controller.mjs';
import { availableSsrRuntimes } from '../../framework-comparison/src/ssr-run-environment.mjs';
const root = '.tmp/ssr-large-profile/';
await fs.mkdir(root + 'buffered-completion-trace', { recursive: true });
let service, worker;
try {
    service = await startSsrLoadProcess('service'); setPriority(service.child.pid, 10);
    for (const id of ['exact']) {
        const entry = resolve(root + 'conditional-emission/server-entry.js');
        const output = resolve(root + 'buffered-completion-trace/' + id + '.json');
        worker = await startSsrWorker({ runtime: availableSsrRuntimes('node')[0], participantId: id, transport: 'node-http', workerPath: resolve('framework-comparison/src/ssr-benchmark-worker.mjs'), workingDirectory: resolve('framework-comparison'), serviceUrl: service.url,
            environment: { NODE_OPTIONS: `${process.env.NODE_OPTIONS ?? ''} --import=${pathToFileURL(resolve(root + 'buffered-completion-hook.mjs'))} --import=${pathToFileURL(resolve(root + 'node-http-trace-hook.mjs'))}`, COMPARISON_TRACE_OUTPUT: output, COMPARISON_SSR_RENDER_MODE: 'string', COMPARISON_SSR_BOUNDED_TELEMETRY: '1', COMPARISON_CLIENT_TAGS: '<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">', ...(id === 'exact' ? { COMPARISON_EXACT_SERVER_ENTRY: entry } : {}) } });
        setPriority(worker.child.pid, 10);
        let expected;
        for (let i = 0; i < 100; i++) expected = await (await fetch(worker.url + '?__benchmarkPreloaded=true')).text();
        const response = await fetch(worker.url + '?__benchmarkPreloaded=true&__trace=true');
        const actual = await response.text(); assert.equal(actual, expected);
        await stopSsrWorker(worker); worker = undefined;
        const trace = JSON.parse(await fs.readFile(output, 'utf8'));
        console.log(id, JSON.stringify(trace.counts), 'bytes', Buffer.byteLength(actual));
    }
} finally {
    try { if (worker) await stopSsrWorker(worker); }
    finally { if (service) await service.close(); }
}
