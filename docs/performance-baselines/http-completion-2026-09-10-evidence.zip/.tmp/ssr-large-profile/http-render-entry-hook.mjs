import { registerHooks } from 'node:module';
import assert from 'node:assert/strict';
registerHooks({ load(url, context, nextLoad) {
    const result = nextLoad(url, context);
    if (!url.endsWith('/framework-comparison/src/ssr-benchmark-worker.mjs')) return result;
    const source = String(result.source);
    const before = 'const { renderParticipant, renderParticipantStream } = await import(pathToFileURL(entry).href);';
    assert.equal(source.split(before).length, 2);
    const after = `const { renderParticipant: originalRenderParticipant, renderParticipantStream } = await import(pathToFileURL(entry).href);
        function renderParticipant(...args) {
            const started = performance.now();
            try { return originalRenderParticipant(...args); }
            finally { statistics.envelopeMs.push(performance.now() - started); }
        }`;
    return { ...result, source: source.replace(before, after) };
} });
