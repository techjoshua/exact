from pathlib import Path
from statistics import mean
import json, hashlib
base=Path('.tmp/ssr-large-profile')
all_results={}
for name in ['buffered-completion','buffered-harness','buffered-harness-phases','http-render-entry']:
    rows=json.loads((base/name/'http.json').read_text())
    assert len(rows)==18
    exact=[r for r in rows if r['variant']!='react']
    assert len({r['identity']['hash'] for r in exact})==1
    stages=[d['stages'][0] for r in rows for d in r['results']]
    assert all(s['errors']==0 and s['valid']==s['completed']==s['started'] for s in stages)
    for r in rows: assert hashlib.sha256(Path(r['entry']).read_bytes()).hexdigest()==r['artifactSha256']
    rates={v:mean(r['rps'] for r in rows if r['variant']==v) for v in ['baseline','compiled','react']}
    result=dict(rps=rates,valid=sum(s['valid'] for s in stages),errors=0,
                changePercent=(rates['compiled']/rates['baseline']-1)*100,
                wins=sum(next(r['rps'] for r in rows if r['variant']=='compiled' and r['block']==b)>next(r['rps'] for r in rows if r['variant']=='baseline' and r['block']==b) for b in range(6)))
    if 'before' in rows[0]:
        phases={}
        for v in rates:
            group=[r for r in rows if r['variant']==v]
            values={}
            for key in ['renderMs','envelopeMs','firstByteMs','participantWorkMs']:
                count=sum(r['after']['statistics'][key]['count']-r['before']['statistics'][key]['count'] for r in group)
                values[key]=None if not count else 1000*sum(r['after']['statistics'][key]['sum']-r['before']['statistics'][key]['sum'] for r in group)/count
            values['gcCount']=sum(r['after']['garbageCollection']['count']-r['before']['garbageCollection']['count'] for r in group)
            phases[v]=values
        result['phases']=phases
    (base/name/'summary.json').write_text(json.dumps(result,indent=2))
    all_results[name]=result
(base/'http-completion-summary.json').write_text(json.dumps(all_results,indent=2))
print(json.dumps(all_results,indent=2))
