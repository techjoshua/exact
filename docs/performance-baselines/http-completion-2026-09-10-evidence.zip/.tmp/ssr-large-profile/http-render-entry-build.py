from pathlib import Path
p=Path('.tmp/ssr-large-profile')
(p/'http-render-entry').mkdir(exist_ok=True)
s=(p/'buffered-harness-phases-http.mjs').read_text()
s=s.replace("variant==='compiled'?{NODE_OPTIONS:", "variant!=='baseline'?{NODE_OPTIONS:")
s=s.replace('./buffered-harness-hook.mjs','./http-render-entry-hook.mjs')
s=s.replace("root+'buffered-harness-phases/http.json'", "root+'http-render-entry/http.json'")
(p/'http-render-entry-run.mjs').write_text(s)
