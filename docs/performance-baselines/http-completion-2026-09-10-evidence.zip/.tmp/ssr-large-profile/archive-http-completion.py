from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();base=root/'.tmp/ssr-large-profile'
report=root/'docs/performance-baselines/http-completion-2026-09-10.md'
summary=json.loads((base/'http-completion-summary.json').read_text())
assert sum(r['valid'] for r in summary.values())==1106045
files={report,Path(__file__).resolve(),base/'http-completion-summary.json',base/'http-completion-analyze.py',base/'buffered-traces-build.py'}
for prefix in ['buffered-completion','buffered-harness','http-render-entry']:
    for f in base.glob(prefix+'*'):
        if f.is_file():files.add(f)
        elif f.is_dir():files.update(x for x in f.rglob('*') if x.is_file())
for name in ['node-http-trace-hook.mjs','node-http-trace-run.mjs']:files.add(base/name)
for sub in ['dist-server/server-entry.js','dist-bun-server/bun-server-entry.js']:
    retained=base/'conditional-emission'/Path(sub).name
    current=root/'framework-comparison/participants/exact'/sub
    assert retained.read_bytes()==current.read_bytes()
    files.update([retained,current,root/'framework-comparison/participants/react'/sub])
for rel in ['framework-comparison/src/ssr-benchmark-worker.mjs','framework-adapters/node-adapter/src/handler.ts','framework-adapters/node-adapter/dist/handler.js','packages/server/src/response-body.ts']:
    files.add(root/rel)
archive=report.with_name('http-completion-2026-09-10-evidence.zip');assert not archive.exists()
manifest={f.relative_to(root).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(files)}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(files):z.write(f,f.relative_to(root).as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified',len(files),'files')
