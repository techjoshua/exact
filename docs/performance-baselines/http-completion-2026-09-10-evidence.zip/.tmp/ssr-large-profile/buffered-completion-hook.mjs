import { registerHooks } from 'node:module';
import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
registerHooks({ load(url, context, nextLoad) {
    const result = nextLoad(url, context);
    if (url.endsWith('/framework-adapters/node-adapter/dist/handler.js')) {
        let source = String(result.source);
        const start = source.indexOf('export async function writeNodeResponse(response, result, signal, logger) {');
        const split = source.indexOf("    if (body?.kind === 'produced'", start);
        assert.ok(start > 0 && split > start);
        const prefix = source.slice(start, split).replace('export async function', 'export function');
        const replacement = prefix + `
    if (body?.kind === 'buffered') {
        try { throwIfAborted(signal); response.end(body.toText()); return; }
        catch (error) { return failBufferedCompletion(response, result, signal, logger, error); }
    }
    return pendingNodeResponse(response, result, signal, logger, body);
}
async function failBufferedCompletion(response, result, signal, logger, error) {
    if (!signal?.aborted || error !== signal.reason) reportNodeError(error, 'response', logger);
    try { await cancelNodeResponseBody(result, error); }
    catch (cleanupError) { if (cleanupError !== error) reportNodeError(cleanupError, 'cleanup', logger); }
    if (!response.destroyed) response.destroy(error);
}
async function pendingNodeResponse(response, result, signal, logger, body) {
`;
        source = source.slice(0, start) + replacement + source.slice(split);
        if (process.env.COMPARISON_COMPLETION_OUTPUT) writeFileSync(process.env.COMPARISON_COMPLETION_OUTPUT + '/handler.js', source);
        return { ...result, source };
    }
    if (url.endsWith('/framework-comparison/src/ssr-benchmark-worker.mjs')) {
        const before = 'await writeNodeResponse(response, result, request.signal, responseLogger);';
        const source = String(result.source);
        assert.equal(source.split(before).length, 2);
        const after = source.replace(before, 'const completion = writeNodeResponse(response, result, request.signal, responseLogger); if (completion) await completion;');
        if (process.env.COMPARISON_COMPLETION_OUTPUT) writeFileSync(process.env.COMPARISON_COMPLETION_OUTPUT + '/worker.mjs', after);
        return { ...result, source: after };
    }
    return result;
} });
