import { registerHooks } from 'node:module';
import { writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';
registerHooks({ load(url, context, nextLoad) {
    const result = nextLoad(url, context);
    if (!url.endsWith('/framework-comparison/src/ssr-benchmark-worker.mjs')) return result;
    let source = String(result.source);
    const start = source.indexOf("\t\t\t\tif (id === 'exact') {\n\t\t\t\t\tconst result = await createExactBufferedDocument(");
    const end = source.indexOf('\t\t\t\tstatistics.renderedBytes.push(Buffer.byteLength(document));', start);
    assert.ok(start > 0 && end > start);
    const replacement = `
                const document = await measureAsyncPhase('renderMs', () =>
                    renderParticipant(initialData, url.pathname, documentOptions)
                );
                if (id === 'exact') {
                    const result = createExactBufferedDocument(document, benchmarkPayloadTarget(url));
                    await writeNodeResponse(response, result, request.signal, responseLogger);
                    return;
                }
`;
    source = source.slice(0, start) + replacement + source.slice(end);
    const helper = source.indexOf('async function createExactBufferedDocument(initialData, path, payloadTarget, renderParticipant) {');
    const body = source.indexOf('\tconst renderedBytes = Buffer.byteLength(html);', helper);
    assert.ok(helper > 0 && body > helper);
    source = source.slice(0, helper) + 'function createExactBufferedDocument(html, payloadTarget) {\n' + source.slice(body);
    if (process.env.COMPARISON_COMPLETION_OUTPUT) writeFileSync(process.env.COMPARISON_COMPLETION_OUTPUT + '/worker.mjs', source);
    return { ...result, source };
} });
