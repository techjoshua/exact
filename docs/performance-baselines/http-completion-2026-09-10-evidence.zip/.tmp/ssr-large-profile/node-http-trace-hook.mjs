import { registerHooks } from 'node:module';
import { createHook } from 'node:async_hooks';
import { writeFileSync } from 'node:fs';
import { performance } from 'node:perf_hooks';
import assert from 'node:assert/strict';
let active = false, origin = 0, events = [], counts = {}, resources = new Map();
const restores = [];
function event(name, phase, args) {
    if (active) events.push({ name, ph: phase, ts: (performance.now() - origin) * 1000, pid: process.pid, tid: 1, args });
}
const hook = createHook({
    init(id, type, trigger) {
        if (!active) return;
        resources.set(id, type);
        counts[type] = (counts[type] ?? 0) + 1;
        event('resource init', 'i', { id, type, trigger });
    },
    before(id) { if (resources.has(id)) event('callback ' + resources.get(id), 'B', { id }); },
    after(id) { if (resources.has(id)) event('callback ' + resources.get(id), 'E', { id }); }
});
function invoke(name, work) {
    if (!active) return work();
    event(name, 'B');
    try { return work(); }
    finally { event(name, 'E'); }
}
function wrap(object, name) {
    const original = object[name];
    if (typeof original !== 'function') return;
    const own = Object.getOwnPropertyDescriptor(object, name);
    object[name] = function (...args) {
        return invoke(name, () => original.apply(this, args));
    };
    restores.push(() => own ? Object.defineProperty(object, name, own) : delete object[name]);
}
globalThis.__httpTrace = {
    invoke,
    begin(request, response) {
        if (!request.url.includes('__trace=true')) return;
        assert.equal(active, false);
        origin = performance.now(); events = []; counts = {}; resources = new Map();
        active = true; hook.enable();
        event('request', 'B');
        for (const name of ['setHeader', 'writeHead', 'write', 'end']) wrap(response, name);
        for (const name of ['write', '_write', '_writev', 'cork', 'uncork']) wrap(response.socket, name);
        response.once('finish', () => {
            event('response finish', 'i');
            setImmediate(() => {
                event('request', 'E'); active = false; hook.disable();
                for (const restore of restores.splice(0)) restore();
                writeFileSync(process.env.COMPARISON_TRACE_OUTPUT, JSON.stringify({ counts, traceEvents: events }, null, 2));
            });
        });
    }
};
registerHooks({ load(url, context, nextLoad) {
    const result = nextLoad(url, context);
    if (!url.endsWith('/framework-comparison/src/ssr-benchmark-worker.mjs')) return result;
    let source = String(result.source);
    const edits = [
        ['handleNodeRequest(request, response) {', 'handleNodeRequest(request, response) { globalThis.__httpTrace.begin(request, response);'],
        ['const { renderParticipant, renderParticipantStream } = await import(pathToFileURL(entry).href);',
         'const { renderParticipant: originalRenderParticipant, renderParticipantStream } = await import(pathToFileURL(entry).href); const renderParticipant = (...args) => globalThis.__httpTrace.invoke("render synchronous entry", () => originalRenderParticipant(...args));']
    ];
    for (const [before, after] of edits) { assert.equal(source.split(before).length, 2); source = source.replace(before, after); }
    return { ...result, source };
} });
