from pathlib import Path
p=Path('.tmp/ssr-large-profile')
original=(p/'node-http-trace-run.mjs').read_text()
for candidate in ['buffered-completion', 'buffered-harness']:
    s=original.replace("['exact', 'react']", "['exact']")
    s=s.replace("root + 'node-http-trace'", "root + '"+candidate+"-trace'")
    s=s.replace("root + 'node-http-trace/'", "root + '"+candidate+"-trace/'")
    token="--import=${pathToFileURL(resolve(root + 'node-http-trace-hook.mjs'))}"
    assert s.count(token)==1
    s=s.replace(token,"--import=${pathToFileURL(resolve(root + '"+candidate+"-hook.mjs'))} "+token)
    (p/(candidate+'-trace-run.mjs')).write_text(s)
