import fs from 'node:fs';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {types} from 'node:util';
const root='.tmp/ssr-large-profile/';
let code=fs.readFileSync(root+'completed-html-result-integrated/server-entry.js','utf8');
const target='function serializeJson(payload, replacer) {';
assert.equal(code.split(target).length,2);
code='let auditPayload; let auditReplacer;\n'+code.replace(target,target+'\n auditPayload=payload; auditReplacer=replacer;')+'\nexport function auditSerialization(){return {payload:auditPayload,replacer:auditReplacer};}\n';
const path=root+'hydration-payload-audit-entry.mjs';fs.writeFileSync(path,code);
const app=await import(pathToFileURL(resolve(path)));
const results=[];
for(const scenario of ['small','large']){
 const data=JSON.parse(fs.readFileSync('.tmp/positional-leaves/data.json'));
 if(scenario==='large')data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
 await app.renderParticipant(data,'/incidents/inc-101',{clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'});
 const {payload,replacer}=app.auditSerialization();
 const seen=new Set(),stats={scenario,containers:0,arrays:0,objects:0,proxies:[],accessors:[],symbols:[],holes:0,toJSON:[],jsonBytes:Buffer.byteLength(JSON.stringify(payload,replacer)),hasReplacer:!!replacer};
 function visit(value,path){
  if(value===null||typeof value!=='object'||seen.has(value))return;
  seen.add(value);stats.containers++;const array=Array.isArray(value);stats[array?'arrays':'objects']++;
  if(types.isProxy(value))stats.proxies.push(path);
  if('toJSON' in value)stats.toJSON.push(path);
  const symbols=Object.getOwnPropertySymbols(value);if(symbols.length)stats.symbols.push({path,symbols:symbols.map(String)});
  if(array)for(let i=0;i<value.length;i++)if(!Object.hasOwn(value,i))stats.holes++;
  for(const key of Object.keys(value)){
   const descriptor=Object.getOwnPropertyDescriptor(value,key);
   if(!('value' in descriptor)){stats.accessors.push(path+'.'+key);continue;}
   visit(descriptor.value,path+'.'+key);
  }
 }
 visit(payload,'$');results.push(stats);
}
fs.writeFileSync(root+'hydration-payload-audit.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));
