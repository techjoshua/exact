import fs from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
const path=root+'hydration-serialization-replay-entry.mjs';
fs.writeFileSync(path,fs.readFileSync(root+'hydration-payload-audit-entry.mjs','utf8')+'\nexport {serializeJson};\n');
const app=await import(pathToFileURL(resolve(path)));
const rows=[];
for(const scenario of ['small','large']){
 const data=JSON.parse(fs.readFileSync('.tmp/positional-leaves/data.json'));
 if(scenario==='large')data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
 await app.renderParticipant(data,'/incidents/inc-101',{clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'});
 const {payload,replacer}=app.auditSerialization();assert.equal(replacer,undefined);
 const native=JSON.stringify(payload);
 const serialize={current:()=>app.serializeJson(payload),native:()=>JSON.stringify(payload),undefinedArgument:()=>JSON.stringify(payload,undefined)};
 for(let round=0;round<2;round++)for(const variant of round?Object.keys(serialize).reverse():Object.keys(serialize)){
  const run=serialize[variant];let text;
  for(let i=0;i<20000;i++)text=run();
  const start=performance.now();
  for(let i=0;i<100000;i++)text=run();
  const us=(performance.now()-start)*1000/100000;
  assert.equal(text,variant==='current'?native.replace(/</g,'\\u003C').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029'):native);
  rows.push({scenario,variant,round,us,bytes:Buffer.byteLength(text)});
 }
}
fs.writeFileSync(root+'hydration-serialization-replay-'+(process.versions.bun?'bun':'node')+'.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));
