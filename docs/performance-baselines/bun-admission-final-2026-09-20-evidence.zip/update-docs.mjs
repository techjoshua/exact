import assert from 'node:assert/strict';
import {readFile, writeFile} from 'node:fs/promises';
import {summarizeSsrCapacityCapture} from '../../framework-comparison/src/ssr-capacity-report.mjs';

const root=import.meta.dirname;
const read=async path=>JSON.parse(await readFile(path,'utf8'));
const execution=await read(root+'/execution.json');
assert.equal(execution.length,27);
assert.ok(execution.every(step=>step.code===0));
const arrivals=await read(root+'/bun-arrivals.json');
const rows=summarizeSsrCapacityCapture(arrivals,{allowArrivalErrors:true}).filter(row=>row.name==='eXact');
const describe=rate=>{
 const row=rows.find(row=>row.rate===rate);
 return `${Math.round(row.rps).toLocaleString('en-US')} valid RPS at ${rate.toLocaleString('en-US')} offered RPS (${row.p99Min.toFixed(1)}–${row.p99Max.toFixed(1)} ms p99)`;
};
const measurementStages=arrivals.blocks.filter(block=>block.id==='exact').flatMap(block=>block.results.flatMap(result=>result.stages.filter(stage=>!stage.discard)));
assert.ok(measurementStages.every(stage=>stage.errors===0&&stage.invalid===0));
let doc=await readFile('docs/performance.md','utf8');
const start=doc.indexOf('The [Node admission-policy follow-up]');
const end=doc.indexOf('The [routing investigation]',start);
assert.ok(start>=0&&end>start);
doc=doc.slice(0,start)+`The [Bun admission-policy follow-up](performance-baselines/bun-admission-final-2026-09-20.md)
is the current framework comparison baseline. All 27 build, correctness, and measurement stages
passed, including browser, startup, heap, Node/Bun string and streaming, twelve sustained-load
captures, and the native track. Bun string scheduled demand now delivers ${describe(8000)}
and ${describe(10000)}, with zero measured request errors or invalid responses.
The preceding p99 ranges were 31.1–39.6 ms and 48.6–50.2 ms, respectively.

The [Bun admission investigation](performance-baselines/bun-admission-investigation-2026-09-20.md)
records the runtime probes, rejected candidates, interrupted first full attempt, focused capacity
comparisons, and extended soak. Bun uses event-loop thread CPU and native request departures to
recognize responsive demand-limited work. Busy trials retain capacity controls and prompt deadline
checks. The full report retains all measured ratios, including unfavorable differences.

The [preceding Node admission capture](performance-baselines/arrival-policy-final-2026-09-20.md)
and its [focused investigation](performance-baselines/ssr-arrival-investigation-2026-09-20.md)
remain historical evidence. Each published offered-rate case owns fresh worker, service, and
driver processes, with 30 seconds of target-rate warmup and 60 seconds of measurement. Warmup
failures and missed arrivals remain visible. The current and preceding full captures use the same
protocol; older sequential-rate captures do not isolate runtime changes from protocol changes.

`+doc.slice(end);
await writeFile('docs/performance.md',doc);
let readme=await readFile('framework-comparison/README.md','utf8');
readme=readme.replace('The current [admission-policy follow-up](../docs/performance-baselines/arrival-policy-final-2026-09-20.md)', 'The current [Bun admission-policy follow-up](../docs/performance-baselines/bun-admission-final-2026-09-20.md)');
readme=readme.replace('[admission investigation](../docs/performance-baselines/ssr-arrival-investigation-2026-09-20.md)\nrecords the Node correction and its focused controls.', '[Bun admission investigation](../docs/performance-baselines/bun-admission-investigation-2026-09-20.md)\nrecords the Bun correction, rejected candidates, focused controls, and extended soak. The\n[preceding Node investigation](../docs/performance-baselines/ssr-arrival-investigation-2026-09-20.md)\nretains the earlier Node correction.');
await writeFile('framework-comparison/README.md',readme);
let focused=await readFile('.tmp/bun-admission-2026-09-20/investigation.md','utf8');
focused+=`\n## Final full verification\n\nThe [replacement full capture](bun-admission-final-2026-09-20.md) completed all 27 build, correctness, and measurement stages against implementation 44721c11. Both runtimes passed 39 string and 25 streaming browser contracts, and the native track passed 12 contracts. Browser timing, startup, heap, all twelve sustained-load captures, string/stream diagnostics, and native timing were rerun. Using the suite's nearest-rank percentile convention, eXact measured 44 ms FCP at p50 and 49.2 ms mean; the other four frameworks measured 48 ms at p50.\n\nBun string demand measured ${describe(8000)} and ${describe(10000)}. Those eXact measurement windows had zero capacity misses, zero scheduling-lag misses, zero request errors, and zero invalid responses. The raw captures retain deadline misses and warmup behavior. The preceding full capture measured p99 ranges of 31.1–39.6 ms and 48.6–50.2 ms. Each final range spans four driver/population percentiles. These are observed distribution changes, not guaranteed latency bounds.\n\nThe full report contains sustained string and streaming throughput, all eXact/React ratio changes, and the original historical comparison. It retains unfavorable results as well as improvements. Its artifact comparison checks participant entries and server code independently from the adapter.\n\nThe [structured investigation](bun-admission-investigation-2026-09-20.json) records diagnostic summaries and hashes. The [evidence archive](bun-admission-investigation-2026-09-20-evidence.zip) contains raw captures, copied adapters, preparation scripts, traces, validation logs, and the separate stopped first full attempt. Its provenance notes distinguish reconstructed initial copies from later capture-time artifact hashes. The overwritten initial candidate directory is excluded.\n`;
assert.ok(measurementStages.every(stage=>stage.missedCapacity===0&&stage.missedLag===0));
focused+='\n### Full-run Bun saturated capacity\n\nThe following rows compare the final full capture with the immediately preceding full capture. They retain small unfavorable differences alongside gains. The isolated longer streaming ABBA comparison above uses the original and final adapters within the same experimental sequence.\n\n| API | Concurrency | eXact RPS | React RPS | Absolute eXact change | eXact/React ratio change |\n| --- | ---: | ---: | ---: | ---: | ---: |\n';
for(const mode of ['string','stream']){
 const lane='bun'+(mode==='stream'?'-stream':'')+'-multi';
 const before=summarizeSsrCapacityCapture(await read('docs/performance-baselines/arrival-policy-final-2026-09-20-'+lane+'.json'));
 const after=summarizeSsrCapacityCapture(await read(root+'/'+lane+'.json'));
 const rate=(rows,name,concurrency)=>rows.find(row=>row.name===name&&row.concurrency===concurrency).rps;
 const percent=value=>(value>=0?'+':'')+value.toFixed(1)+'%';
 for(const concurrency of [16,32,64,128]){
  const a=rate(before,'eXact',concurrency),b=rate(after,'eXact',concurrency);
  const ar=rate(before,'React',concurrency),br=rate(after,'React',concurrency);
  focused+=`| ${mode} | ${concurrency} | ${Math.round(b).toLocaleString('en-US')} | ${Math.round(br).toLocaleString('en-US')} | ${percent(100*(b/a-1))} | ${percent(100*((b/br)/(a/ar)-1))} |\n`;
 }
}
await writeFile('.tmp/bun-admission-2026-09-20/investigation.md',focused);
console.log('Updated engineering and investigation prose.');
