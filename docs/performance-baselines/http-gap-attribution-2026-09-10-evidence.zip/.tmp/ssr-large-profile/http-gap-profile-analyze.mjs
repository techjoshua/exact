import fs from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/http-gap-profile/';
const capture=JSON.parse(await fs.readFile(root+'capture.json','utf8'));assert.ok(capture.complete);
const regions=new Map();
for(const id of ['exact','react']) {
 const path=capture.artifacts[id].path;
 let region='';regions.set(path.toLowerCase(),(await fs.readFile(path,'utf8')).split('\n').map(line=>{if(line.startsWith('//#region '))region=line.slice(10);if(line.startsWith('//#endregion'))region='';return region;}));
}
function site(node){const f=node.callFrame;let module=f.url;if(f.url.startsWith('file:')){const p=fileURLToPath(f.url);module=regions.get(p.toLowerCase())?.[f.lineNumber]||p;}return {name:f.functionName||'(anonymous)',module,line:f.lineNumber+1,url:f.url};}
function group(chain){
 const leaf=chain[0];
 if(leaf.name==='(idle)')return 'Idle';
 if(leaf.name==='(garbage collector)')return 'GC';
 for(const s of chain){
  const m=s.module.replaceAll('\\','/'),n=s.name;
  if(n==='cpuUsage'||m.includes('ssr-load-statistics')||n==='measureNodeRequest')return 'Telemetry';
  if(/writeUtf8String|writev|writeBuffer|onWriteComplete|socketOnDrain/.test(n)||/node:(?:_http_outgoing|net|internal\/stream_base_commons|internal\/streams\/writable)/.test(m))return 'HTTP output';
  if(/node:_http_(?:server|common|incoming)/.test(m))return 'HTTP input';
  if(/^(serializeJson|validatePositionalValue|renderHydrationScriptValue|renderHydrationScript)$/.test(n)||/hydration-json|hydration-metadata|positional-projection|resumption-serialization|document-hydration/.test(m))return 'Exact hydration';
  if(/node-adapter\/dist|server\/dist\/response-body/.test(m))return 'Response adapter';
  if(/ssr\/dist\/(?:html|markup)\.js|render\/(?:limits|utf8|utf8-encoding)\.js/.test(m))return 'Exact escaping/accounting';
  if(/render\/(?:output-result|output-buffer|output-text|document-root-output)\.js/.test(m))return 'Exact result assembly';
  if(/render\/(?:render-program|render-program-values|render-program-attributes|program-writer-output|program-boundary|children|operation-target|string-program-sink)\.js/.test(m)||n==='__exactRun')return 'Exact program/traversal';
  if(/react-dom-server/.test(m))return 'React rendering';
  if(/participants\/react/.test(m))return 'React application/serialization';
  if(/render\/(?:direct-|synchronous-artifact|server-component-abi-execution|component\.js|component-props)/.test(m)||/core\/dist\/server\/(?:component|tasks)/.test(m))return 'Exact component preparation/ownership';
  if(/participants\/exact/.test(m)||/Incident(?:App|Queue|Detail)|SeverityBadge|^Document$|scriptSources|stylesheetSources/.test(n))return 'Exact application/asset preparation';
  if(n==='renderParticipant'||n==='renderParticipantToSink')return 'Other renderer';
  if(n==='handleNodeControlRequest')return 'Profile control';
 }
 return 'Other runtime/harness';
}
const blocks=[];
for(const b of capture.blocks){
 const p=JSON.parse(await fs.readFile(root+b.profile,'utf8'));
 const nodes=new Map(p.nodes.map(n=>[n.id,n])),parents=new Map();for(const n of p.nodes)for(const child of n.children??[])parents.set(child,n.id);
 const chains=new Map();for(const n of p.nodes){let id=n.id,c=[];while(id!==undefined){c.push(site(nodes.get(id)));id=parents.get(id);}chains.set(n.id,c);}
 const groups={},self=new Map();let longIntervals=0,longIntervalUs=0;
 for(let i=0;i<p.samples.length;i++){
  const c=chains.get(p.samples[i]),g=group(c),us=p.timeDeltas[i]??0;
  const bucket=groups[g]??={samples:0,wallUs:0};bucket.samples++;bucket.wallUs+=us;
  if(us>5000){longIntervals++;longIntervalUs+=us;}
  const s=c[0],key=JSON.stringify(s),entry=self.get(key)??{...s,samples:0,wallUs:0};entry.samples++;entry.wallUs+=us;self.set(key,entry);
 }
 const active=p.samples.length-(groups.Idle?.samples??0);
 const gc=b.after.telemetry.garbageCollection;
 const phases=Object.fromEntries(['renderMs','firstByteMs','participantWorkMs'].map(k=>{const s=b.after.telemetry.statistics[k];return [k,{count:s.count,meanUs:s.sum*1000/s.count}];}));
 const block={id:b.id,population:b.population,valid:b.valid,cpuUsPerRequest:b.cpuUs/b.valid,gcCount:gc.count,gcUsPerRequest:1000*gc.durationMs/b.valid,phases,samples:p.samples.length,activeSamples:active,longIntervals,longIntervalUs,groups:Object.fromEntries(Object.entries(groups).map(([k,v])=>[k,{...v,activePercent:100*v.samples/active,wallUsPerRequest:v.wallUs/b.valid}])),self:[...self.values()].sort((a,b)=>b.samples-a.samples).slice(0,55)};
 blocks.push(block);
 console.log(JSON.stringify({id:b.id,population:b.population,cpu:block.cpuUsPerRequest,gcUs:block.gcUsPerRequest,gcCount:block.gcCount,phases}));
 console.log(Object.entries(block.groups).filter(([k])=>k!=='Idle').map(([k,v])=>`${k}: ${v.activePercent.toFixed(2)}%`).join('\n'));
 console.log(block.self.filter(s=>s.name!=='(idle)').slice(0,12).map(s=>`${s.samples} ${s.name} ${s.module}:${s.line}`).join('\n'));
}
await fs.writeFile(root+'analysis.json',JSON.stringify({blocks},null,2));
