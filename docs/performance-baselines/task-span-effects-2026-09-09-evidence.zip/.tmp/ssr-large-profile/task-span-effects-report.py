from pathlib import Path
import hashlib
import json
import zipfile

root = Path.cwd()
stem = root / 'docs/performance-baselines/task-span-effects-2026-09-09'
raw = root / '.tmp/ssr-large-profile/task-span-effects-audit-results.json'
data = json.loads(raw.read_text(encoding='utf-8'))
assert len(data['requests']) == len(data['responses']) == 13
assert len(data['checks']) == 38
stem.with_suffix('.json').write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
files = [
    stem.with_suffix('.md'), stem.with_suffix('.json'),
    root / '.tmp/ssr-large-profile/task-span-effects-audit.mjs',
    Path(__file__).resolve(),
]
for name in ['element_island_analysis.go', 'policy.go', 'callable_effects.go', 'contracts.go']:
    files.append(root / 'native/typescript-go/overlay/internal/exactcompiler' / name)
manifest = {str(p.relative_to(root)).replace('\\', '/'): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive = Path(str(stem) + '-evidence.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in files:
        z.write(p, str(p.relative_to(root)).replace('\\', '/'))
    z.writestr('SHA256.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, expected in manifest.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == expected
print(f'Archived and verified {len(files)} files; 13 cases, 38 checks.')
