import { spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';

const cases = [
  { name: 'nested-sibling', write: 'this.state.page.body="ready";', head: 'this.state.page.title' },
  { name: 'ancestor-replacement', write: 'this.state.page={title:"ready",body:"ready"};', head: 'this.state.page.title' },
  { name: 'descendant-read-parent', write: 'this.state.page.title="ready";', head: 'JSON.stringify(this.state.page)' },
  { name: 'dynamic-write', write: 'this.state.page[props.field]="ready";', head: 'this.state.page.title' },
  { name: 'dynamic-read', write: 'this.state.page.title="ready";', head: 'this.state.page[props.field]' },
  { name: 'write-alias', write: 'const page=this.state.page;page.title="ready";', head: 'this.state.page.title' },
  { name: 'read-alias', helper: 'const page=this.state.page;', write: 'this.state.page.title="ready";', head: 'page.title' },
  { name: 'helper-chain', helper: 'const readTitle=()=>this.state.page.title;const title=()=>readTitle();', write: 'this.state.page.title="ready";', head: 'title()' },
  { name: 'helper-write', helper: 'const setTitle=()=>{this.state.page.title="ready";};', write: 'setTitle();', head: 'this.state.page.title' },
  { name: 'helper-parameter', helper: 'const title=(page:{title:string})=>page.title;', write: 'this.state.page.title="ready";', head: 'title(this.state.page)' },
  { name: 'conditional-structure', write: 'this.state.visible=true;', head: 'this.state.visible ? this.state.page.title : "Hidden"' },
  { name: 'opaque-read', imports: 'import {title} from "external-title";', write: 'this.state.page.title="ready";', head: 'title(this.state.page)' },
  { name: 'opaque-write', imports: 'import {update} from "external-update";', write: 'update(this.state.page);', head: 'this.state.page.title' },
];
const executable='.tmp/native-compiler/exactc.exe';
const requests=cases.map(c=>({id:`task-span-effects-${c.name}.tsx`,kind:'compile',target:'server',source:`
import {TaskContext,type Component} from '@exactjs/core';
${c.imports??''}
export function Document(this:Component<{page:{title:string;body:string};visible:boolean}>,props:{field:'title'|'body'}){
 this.state.page={title:'Initial',body:'loading'};this.state.visible=false;
 ${c.helper??''}
 const load=async (_task:TaskContext=TaskContext.server().blocking())=>{await Promise.resolve();${c.write}};
 load();
 return ()=><html><head><title>{${c.head}}</title></head><body>{this.state.page.body}</body></html>;
}`}));
const run=spawnSync(executable,[],{input:requests.map(r=>JSON.stringify(r)).join('\n')+'\n',encoding:'utf8',windowsHide:true,maxBuffer:32*1024*1024});
if(run.status!==0)throw Error(run.stderr||run.stdout);
const responses=run.stdout.trim().split('\n').map(JSON.parse);
if(responses.length!==requests.length)throw Error('Incomplete compiler responses');
const summary=responses.map((r,i)=>({
 name:cases[i].name,error:r.error,diagnostics:r.diagnostics,
 tasks:r.analysis?.tasks.map(t=>({id:t.id,writes:t.writes,reads:t.reads,diagnostics:t.diagnostics})),
 reads:r.analysis?.stateReads,
 callables:r.analysis?.callables.map(c=>({name:c.name,reads:c.stateReads,writes:c.stateWrites,calls:c.calls,safe:c.reevaluationSafe}))
}));
const checks=[];
function check(name, predicate) { assert.ok(predicate,name);checks.push(name); }
for(const row of summary){
 check(`${row.name}: compiler completed`,!row.error);
 check(`${row.name}: expected diagnostics`,row.name==='dynamic-write'
   ? row.diagnostics.some(d=>d.code==='EXACT2001' && d.message.includes('dynamic computed path'))
   : row.diagnostics.length===0);
}
const row=name=>summary.find(r=>r.name===name);
const writes=(name,path)=>row(name).tasks.some(t=>t.writes.some(w=>w.path===path));
const reads=(name,path)=>row(name).reads.some(r=>r.path.join('.')===path);
check('nested sibling write remains precise',writes('nested-sibling','page.body'));
check('ancestor replacement remains an ancestor write',writes('ancestor-replacement','page'));
check('whole-object read retains parent dependency',reads('descendant-read-parent','page'));
check('dynamic read carries broad wildcard dependency',row('dynamic-read').reads.some(r=>r.path.join('.')==='page.*'&&r.confidence==='broad'));
check('write alias resolves to component state',writes('write-alias','page.title'));
check('read alias resolves to component state',reads('read-alias','page.title'));
check('helper chain propagates transitive state read',row('helper-chain').callables.some(c=>c.name==='title'&&c.reads.some(r=>r.path==='page.title')));
check('helper write propagates into task',writes('helper-write','page.title'));
check('state object passed to helper retains parent dependency',reads('helper-parameter','page'));
check('conditional output retains controlling dependency',reads('conditional-structure','visible'));
check('opaque read retains argument dependency',reads('opaque-read','page'));
check('opaque task illustrates incomplete negative write evidence',row('opaque-write').tasks.every(t=>t.writes.length===0)&&row('opaque-write').callables.some(c=>c.name==='load'&&c.calls.some(call=>call.moduleSpecifier==='external-update'&&!call.resolved)));
writeFileSync('.tmp/ssr-large-profile/task-span-effects-audit-results.json',JSON.stringify({compilerSha256:createHash('sha256').update(readFileSync(executable)).digest('hex'),requests,responses,summary,checks},null,2));
for(const r of summary)console.log(JSON.stringify({name:r.name,diagnostics:r.diagnostics.map(d=>d.code),writes:r.tasks.flatMap(t=>t.writes),reads:r.reads.map(v=>({path:v.path,confidence:v.confidence}))}));
console.log(`${checks.length} characterization checks passed; no render or timing experiment performed.`);
