import re
from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'projector-current-http';root.mkdir(exist_ok=True)
s=Path('framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js').read_text();(root/'current.mjs').write_text(s)
def replace(m):
 cell=m[1]
 return f'''if ({cell} === null || typeof {cell} === "string" || typeof {cell} === "boolean") {{
 if (++state.nodes > state.maxNodes || depth + 1 > state.maxDepth) return state.unsafe;
 }} else if (!state.validate({cell}, depth + 1, state)) return state.unsafe;'''
c,n=re.subn(r'if \(!state\.validate\((cell\d+), depth \+ 1, state\)\) return state\.unsafe;',replace,s);assert n==37,n
(root/'candidate.mjs').write_text(c)
(root/'worker.mjs').write_bytes((base/'prefix-native/worker.mjs').read_bytes())
r=(base/'prefix-native-run.mjs').read_text().replace('prefix-native/','projector-current-http/').replace('large96-bun-native-prefix-experiment','large96-bun-current-projector-inline-http')
(base/'projector-current-http-run.mjs').write_text(r)
