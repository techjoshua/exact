import json,hashlib
from pathlib import Path
root=Path('.tmp/ssr-large-profile/http-json-shape')
data=json.loads((root/'capture.json').read_text())
assert data['complete'] and len(data['blocks'])==2
baseline=None;rows=[]
for block in data['blocks']:
    for stage in ['loopBefore','after','loopAfter']:
        payloads=block[stage]['regions']['payloads']
        assert len(payloads)==8
        for payload in payloads:
            assert all(a['sameMapAsFirst'] for a in payload['arrays'])
            assert all(payload[k]==0 for k in ['objects','accessors','holes','toJSON','symbols'])
            assert payload['hasReplacer'] is False
            assert len(payload['arrays'])==19
            if baseline is None:baseline=payload
            assert payload==baseline
        rows.append({'population':block['population'],'stage':stage,'samples':len(payloads),'arrays':len(payloads[0]['arrays']),'holeyElements':sum(a['elements']['holey'] for a in payloads[0]['arrays']),'jsonBytes':len(payloads[0]['json'].encode()),'jsonSha256':hashlib.sha256(payloads[0]['json'].encode()).hexdigest()})
(root/'shape-summary.json').write_text(json.dumps(rows,indent=2))
print('All 48 captured payloads have equal JSON, graph descriptors and element kinds; maps match within each worker.')
