import fs from 'node:fs/promises';
const root='.tmp/ssr-large-profile/',dir=root+'http-json-shape/';await fs.mkdir(dir,{recursive:true});
let source=await fs.readFile(root+'http-json-regions/server-entry.js','utf8');
source=source.replace('function auditOriginal_auditNativeJson(payload,replacer){return JSON.stringify(payload,replacer);}',`function auditOriginal_auditNativeJson(payload,replacer){if(auditActive&&auditCaptured.length<8)auditCaptured.push({payload,replacer});return JSON.stringify(payload,replacer);}`);
if(!source.includes('auditCaptured.push'))throw Error('Missing native JSON function');
source=source.replace('export function regionReset(){','export function regionReset(){auditCaptured=[];');
source=source.replace('return {samples:auditSamples,regions:auditRegions};','return {samples:auditSamples,regions:auditRegions,payloads:auditDescribePayloads()};');
source=`import {setFlagsFromString as auditV8Flags} from 'node:v8';
auditV8Flags('--allow-natives-syntax');
const auditElements=new Function('v','return {holey:%HasHoleyElements(v),packed:%HasFastPackedElements(v),smi:%HasSmiElements(v),double:%HasDoubleElements(v),object:%HasObjectElements(v),dictionary:%HasDictionaryElements(v)};');
const auditSameMap=new Function('a','b','return %HaveSameMap(a,b);');
let auditCaptured=[],auditFirstShapes;
`+source+`
function auditDescribePayloads(){return auditCaptured.map(({payload,replacer})=>{
 const arrays=[];const references=[];let objects=0,accessors=0,holes=0,toJSON=0,symbols=0;
 function visit(value,path){
  if(!value||typeof value!=='object')return;
  if('toJSON' in value)toJSON++;symbols+=Object.getOwnPropertySymbols(value).length;
  if(Array.isArray(value)){
   const index=arrays.length;references.push(value);let present=0;
   for(let i=0;i<value.length;i++)if(Object.hasOwn(value,i))present++;
   holes+=value.length-present;
   arrays.push({path,length:value.length,present,prototypeIsArray:Object.getPrototypeOf(value)===Array.prototype,extensible:Object.isExtensible(value),elements:auditElements(value),sameMapAsFirst:!auditFirstShapes||auditSameMap(value,auditFirstShapes[index])});
  }else objects++;
  for(const [key,descriptor] of Object.entries(Object.getOwnPropertyDescriptors(value))){if(key==='length'&&Array.isArray(value))continue;if('value' in descriptor)visit(descriptor.value,path+'.'+key);else accessors++;}
 }
 visit(payload,'$');auditFirstShapes??=references;
 return {json:JSON.stringify(payload,replacer),hasReplacer:replacer!==undefined,arrays,objects,accessors,holes,toJSON,symbols};
});}
`;
await fs.writeFile(dir+'server-entry.js',source);
await fs.copyFile(root+'http-json-regions/worker.mjs',dir+'worker.mjs');
for(const suffix of ['run.mjs','check.mjs','report.py']){
 let script=await fs.readFile(root+'http-json-regions-'+suffix,'utf8');script=script.replaceAll('http-json-regions','http-json-shape');
 await fs.writeFile(root+'http-json-shape-'+suffix,script);
}
