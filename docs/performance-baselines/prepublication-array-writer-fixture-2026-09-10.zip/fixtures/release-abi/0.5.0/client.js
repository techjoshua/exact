// Frozen compiler output from eXact 0.5.0. Do not regenerate for compatible releases.
import { createPreparedRenderProgram as __exactPreparedRenderProgram, prepareCompiledRenderProgram as __exactPrepareRenderProgram } from "@exactjs/core/runtime/render-operations";
import { readIndexedReactiveSlot as __exactReadState, writeIndexedReactiveValue as __exactWriteState, updateIndexedReactiveValueWithResult as __exactUpdateStateResult, mutateReactiveArray as __exactArrayMutation } from "@exactjs/core/runtime/reactivity";
import { defineTask as __exactDefineTask, bindTaskForHost as __exactBindTask } from "@exactjs/core/runtime/tasks";
import { mapExactCompiledKeyedChildren as __exactMapKeyedChildren } from "@exactjs/core/runtime/lists";
import "@exactjs/core/runtime/component-execution";
import { applyCompiledProgramText as __exactApplyProgramText } from "@exactjs/dom/runtime/render-program";
import { registerComponentLifecycleHandler as __exactRegisterLifecycle } from "@exactjs/core/framework/component-lifecycle";
import { createCompiledComponentReceipt as __exactComponentReceipt } from "@exactjs/core/runtime/component-operations";
import { attachExactCompiledClientComponent as __exactAttachClientComponent_1, receiveExactClientComponentProps as __exactReceiveClientProps_1, disposeExactClientComponent as __exactDisposeClientComponent_1 } from "@exactjs/core/runtime/component-operations";
import { constructDurableComponentInstance as __exactConstructDurableComponent_1 } from "@exactjs/core/runtime/component-construction/durable";
const __exactComponentContract_1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
const __exact_component_updates_1 = { bindings: [[0, 1, 0]], apply: (__exactTargets, __exactDirtyLow, __exactDirtyHigh) => {
  const __exactTarget0 = __exactTargets[0];
  if (__exactTarget0) {
    if ((__exactDirtyLow & 1) !== 0)
      __exactApplyProgramText(__exactTarget0, 1, 0, 0, "Count ", "");
  }
} };
const __exact_render_program_1 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xPhpF5wDFrCMNUG5Sr-x9Cq", namespace: "html", ssrRootStatic: [' id="positive"', ["id"], []], template: '<strong id="positive">positive</strong>', root: ["strong"], work: [1, 0], directClaims: true, ssr: (__exactSsr, __exactContext, __exactInvocation) => {
  __exactSsr.begin(__exactContext, 1, 0, 39, 39);
  const __exactOutput = __exactSsr.output();
  let __exactCharacters = 39;
  __exactSsr.static(__exactOutput, '<strong id="positive">positive</strong>');
  return __exactOutput;
} });
const __exact_render_program_2 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xKD6X_g9xgXok07f8Vh1NBZ", namespace: "html", ssrRootStatic: ["", [], [[0, "data-id", "data-id"]]], template: "<li><!---->\uE000exact:1\uE001<!----></li>", wire: [["li", "html", 1, 2], [[3, 1, 0, true], [7, 0, 0]], [[0, 1], [5, 0, 0]]], directClaims: true, ssr: (__exactSsr, __exactContext, __exactInvocation) => {
  const __exactValue_0 = __exactSsr.prepareAttribute(__exactInvocation, 0);
  if (__exactValue_0 === __exactSsr.unprepared)
    return;
  const __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
  if (__exactValue_1 === __exactSsr.unprepared)
    return;
  __exactSsr.begin(__exactContext, 1, 2, 9, 9);
  const __exactOutput = __exactSsr.output();
  let __exactCharacters = 9;
  __exactSsr.static(__exactOutput, "<li");
  __exactCharacters = __exactSsr.compiledAttribute(__exactContext, __exactOutput, __exactValue_0, 0, "data-id", "data-id", "li", __exactCharacters);
  __exactSsr.static(__exactOutput, ">");
  __exactCharacters = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true);
  __exactSsr.static(__exactOutput, "</li>");
  return __exactOutput;
} });
const __exact_render_program_3 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xPjQ-K1ObICDzMh2jDCFH0H", namespace: "html", ssrRootStatic: ["", [], []], template: '<section><button id="increment"><!---->\uE000exact:1\uE001<!----></button><button id="reverse">Reverse</button><!--x:1--><!--/x:1--><ul></ul></section>', wire: [["section", "html", 4, 5], [[0, 1, 0, "button"], [1, 1], [3, 1, 0, true], [2], [5, 3, 1, "1"], [0, 3, 0, "ul"], [1, 3], [4, 4, 0], [2], [7, 0, 1], [6, 2, 17, "button"], [7, 2, 2]], [[11, 1, ["Count ", "", true, 0, 0]], [1, 3], [3, 4], [5, 0, 0], [5, 1, 2], [9, 0, __exact_component_updates_1]]], directClaims: true, keyedChildren: 16, ssr: (__exactSsr, __exactContext, __exactInvocation) => {
  const __exactValue_0 = __exactSsr.prepareAttribute(__exactInvocation, 0);
  if (__exactValue_0 === __exactSsr.unprepared)
    return;
  const __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
  if (__exactValue_1 === __exactSsr.unprepared)
    return;
  const __exactValue_2 = __exactSsr.prepareAttribute(__exactInvocation, 2);
  if (__exactValue_2 === __exactSsr.unprepared)
    return;
  const __exactValue_3 = __exactSsr.prepareChild(__exactInvocation, 3);
  if (__exactValue_3 === __exactSsr.unprepared)
    return;
  const __exactValue_4 = __exactSsr.prepareChild(__exactInvocation, 4);
  if (__exactValue_4 === __exactSsr.unprepared)
    return;
  __exactSsr.begin(__exactContext, 4, 5, 103, 103);
  const __exactOutput = __exactSsr.output();
  let __exactCharacters = 103;
  __exactSsr.static(__exactOutput, '<section><button id="increment"');
  __exactCharacters = __exactSsr.compiledAttribute(__exactContext, __exactOutput, __exactValue_0, 0, "__exactClosedInteraction:onClick", "__exactClosedInteraction:onClick", "button", __exactCharacters);
  __exactSsr.static(__exactOutput, ">");
  __exactCharacters = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "Count ", "");
  __exactSsr.static(__exactOutput, '</button><button id="reverse"');
  __exactCharacters = __exactSsr.compiledAttribute(__exactContext, __exactOutput, __exactValue_2, 0, "__exactClosedInteraction:onClick", "__exactClosedInteraction:onClick", "button", __exactCharacters);
  __exactSsr.static(__exactOutput, ">Reverse</button>");
  __exactCharacters = __exactSsr.child(__exactContext, __exactOutput, __exactValue_3, "1", __exactCharacters);
  __exactSsr.static(__exactOutput, "<ul>");
  __exactSsr.keyedChild(__exactOutput, __exactValue_4);
  __exactSsr.static(__exactOutput, "</ul></section>");
  return __exactOutput;
} });
const __exactImplementation_Counter_1 = function Counter() {
  __exactWriteState(this.state, 0, 0);
  __exactWriteState(this.state, 1, [{ id: 1, label: "one" }, { id: 2, label: "two" }]);
  __exactRegisterLifecycle(this, "unmount", () => {
    globalThis.exactAbiDisposals++;
  });
  const increment = __exactBindTask(this, __exactDefineTask({
    label: "increment",
    placement: "client",
    priority: "normal",
    concurrency: "parallel",
    readiness: "nonblocking"
  }, (_task) => {
    __exactUpdateStateResult(this.state, 0, (previous) => {
      const result = previous++;
      return [previous, result];
    });
  }));
  return () => __exactPreparedRenderProgram(__exact_render_program_3, (__exactSlot) => __exactSlot === 0 ? () => increment() : __exactSlot === 2 ? () => __exactArrayMutation(this.state, ["rows"], "reverse", () => []) : __exactSlot === 3 ? __exactReadState(this.state, 0) > 0 && __exactPreparedRenderProgram(__exact_render_program_1, [], this) : __exactSlot === 4 ? __exactMapKeyedChildren(this, __exactReadState(this.state, 1), (row) => row.id, (row) => __exactPreparedRenderProgram(__exact_render_program_2, (__exactSlot2) => __exactSlot2 === 0 ? row.id : row.label, this, (__exactGroup, __exactApply) => {
    if (__exactGroup === 0) {
      __exactApply("data-id", row.id);
    }
  }), "xz6VSGIHsqeJlEon9ZRSKXo", void 0, "member:id") : void 0, this, (__exactGroup, __exactApply) => {
    if (__exactGroup === 0) {
      __exactApply("__exactClosedInteraction:onClick", () => increment());
    }
    if (__exactGroup === 1) {
      __exactApply("__exactClosedInteraction:onClick", () => __exactArrayMutation(this.state, ["rows"], "reverse", () => []));
    }
  });
};
const Counter2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Counter_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "xlgRHfFirRks2a7KO2XGVmI",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "client",
    implementations: [
      { id: "xEmZCizcsC1uZDrXaa67gPo", name: "Counter", role: "root", implementation: __exactImplementation_Counter_1 }
    ],
    continuations: [],
    executors: [],
    boundaries: [],
    artifact: {
      version: 1,
      target: "client",
      id: "xlgRHfFirRks2a7KO2XGVmI",
      instantiate: __exactImplementation_Counter_1,
      construct: __exactConstructDurableComponent_1,
      abi: 15,
      capabilities: [
        "tasks",
        "resumption",
        "interactions"
      ],
      state: [
        "count",
        "rows"
      ],
      props: [],
      attach: __exactAttachClientComponent_1,
      receive: __exactReceiveClientProps_1,
      dispose: __exactDisposeClientComponent_1,
      updates: __exact_component_updates_1,
      tasks: [
        "xn8-Jb7hOr_aQrKKzyWvcNR"
      ],
      reactive: [
        {
          name: "increment",
          provenance: "unknown",
          allocation: "constant",
          dependencies: []
        },
        {
          name: "this",
          provenance: "state",
          allocation: "live-slot",
          dependencies: []
        }
      ],
      render: "returned-function"
    },
    execution: {
      version: 1,
      ports: [
        [
          "state",
          "count",
          "output"
        ]
      ],
      transitions: [
        [
          "xn8-Jb7hOr_aQrKKzyWvcNR",
          "xn8-Jb7hOr_aQrKKzyWvcNR",
          "interaction",
          "client",
          "nonblocking",
          "parallel",
          [],
          [
            0
          ]
        ]
      ],
      reactive: [
        {
          name: "increment",
          provenance: "unknown",
          allocation: "constant",
          dependencies: []
        },
        {
          name: "this",
          provenance: "state",
          allocation: "live-slot",
          dependencies: []
        }
      ]
    },
    resumption: {
      componentId: "xlgRHfFirRks2a7KO2XGVmI",
      statePaths: [
        "count",
        "rows"
      ],
      stateInputs: [],
      valueCaptures: [],
      contexts: [],
      boundaries: []
    }
  }
}))();
function view() {
  return __exactComponentReceipt(Counter2, {});
}
export {
  view
};
