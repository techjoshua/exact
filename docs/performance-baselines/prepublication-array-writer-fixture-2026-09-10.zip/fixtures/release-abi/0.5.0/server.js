// Frozen compiler output from eXact 0.5.0. Do not regenerate for compatible releases.
import { createPreparedServerComponentReference as __exactComponentReceipt, createPreparedServerKeyedChild as __exactKeyedChild, createPreparedServerRenderProgram as __exactPreparedServerRenderProgram, prepareCompiledRenderProgram as __exactPrepareRenderProgram } from "@exactjs/core/framework/server-render-structure";
import { registerDirectSsrLifecycleHandler as __exactRegisterDirectSsrLifecycle } from "@exactjs/ssr/runtime/direct-lifecycle";
import { issueExactServerComponent as __exactIssueServerComponent_1, writeExactServerComponent as __exactWriteServerComponent_1, disposeExactServerComponent as __exactDisposeServerComponent_1 } from "@exactjs/core/runtime/component-operations";
import { rejectDirectServerComponentConstruction as __exactRejectDirectServerConstruction_1 } from "@exactjs/core/runtime/component-construction/direct-server";
import { directSsrLifecycle as __exactDirectSsrLifecycle_1 } from "@exactjs/ssr/runtime/direct-lifecycle";
const __exactComponentContract_1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
const __exact_render_program_1 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xPhpF5wDFrCMNUG5Sr-x9Cq", namespace: "html", ssrRootStatic: [' id="positive"', ["id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
  const __exactValue_0 = __exactSsr.prepareAttribute(__exactInvocation, 0);
  if (__exactValue_0 === __exactSsr.unprepared)
    return;
  __exactSsr.begin(__exactContext, 1, 1, 25, 25);
  const __exactOutput = __exactSsr.output();
  let __exactCharacters = 25;
  __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "strong", "<strong", ">positive</strong>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
  return __exactOutput;
} });
const __exact_render_program_2 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xKD6X_g9xgXok07f8Vh1NBZ", namespace: "html", ssrRootStatic: ["", [], [[0, "data-id", "data-id"]]], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
  const __exactValue_0 = __exactSsr.prepareAttribute(__exactInvocation, 0);
  if (__exactValue_0 === __exactSsr.unprepared)
    return;
  const __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
  if (__exactValue_1 === __exactSsr.unprepared)
    return;
  __exactSsr.begin(__exactContext, 1, 2, 9, 9);
  const __exactOutput = __exactSsr.output();
  let __exactCharacters = 9;
  __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "li", "<li", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
  __exactCharacters = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true);
  __exactSsr.static(__exactOutput, "</li>");
  return __exactOutput;
} });
const __exact_render_program_3 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xPjQ-K1ObICDzMh2jDCFH0H", namespace: "html", ssrRootStatic: [' data-exact-id="xYOU46HIFt0AchVPp06KDNT"', ["data-exact-id"], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
  const __exactValue_0 = __exactSsr.prepareAttribute(__exactInvocation, 0);
  if (__exactValue_0 === __exactSsr.unprepared)
    return;
  const __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
  if (__exactValue_1 === __exactSsr.unprepared)
    return;
  const __exactValue_2 = __exactSsr.prepareChild(__exactInvocation, 2);
  if (__exactValue_2 === __exactSsr.unprepared)
    return;
  const __exactValue_3 = __exactSsr.prepareChild(__exactInvocation, 3);
  if (__exactValue_3 === __exactSsr.unprepared)
    return;
  __exactSsr.begin(__exactContext, 4, 4, 103, 103);
  const __exactOutput = __exactSsr.output();
  let __exactCharacters = 103;
  __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "section", "<section", '><button id="increment">', __exactCharacters, __exactInvocation.program.ssrRootStatic);
  __exactCharacters = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "Count ", "");
  __exactSsr.static(__exactOutput, '</button><button id="reverse">Reverse</button>');
  __exactCharacters = __exactSsr.child(__exactContext, __exactOutput, __exactValue_2, "1", __exactCharacters);
  __exactSsr.static(__exactOutput, "<ul>");
  __exactSsr.keyedChild(__exactOutput, __exactValue_3);
  __exactSsr.static(__exactOutput, "</ul></section>");
  return __exactOutput;
} });
const __exactImplementation_Counter_1 = function Counter() {
  this.state.count = 0;
  this.state.rows = [{ id: 1, label: "one" }, { id: 2, label: "two" }];
  __exactRegisterDirectSsrLifecycle(this, "unmount", () => {
    globalThis.exactAbiDisposals++;
  });
  ;
  return __exactPreparedServerRenderProgram(__exact_render_program_3, [{ "data-exact-id": "xYOU46HIFt0AchVPp06KDNT" }, this.state.count, this.state.count > 0 && __exactPreparedServerRenderProgram(__exact_render_program_1, [{ id: "positive" }]), this.state.rows.map((row) => __exactKeyedChild(__exactPreparedServerRenderProgram(__exact_render_program_2, [{ "data-id": row.id }, row.label]), row.id))]);
};
const Counter2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Counter_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "xlgRHfFirRks2a7KO2XGVmI",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "executor",
    implementations: [
      { id: "xMpq3WvJOljax5bFrqjVaN2", name: "Counter_ExactServer_1", role: "server-part", implementation: __exactImplementation_Counter_1 }
    ],
    continuations: [],
    executors: [],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "xlgRHfFirRks2a7KO2XGVmI",
      instantiate: __exactImplementation_Counter_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 3,
      capabilities: [
        "resumption"
      ],
      state: [
        "count",
        "rows"
      ],
      props: [],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "synchronous",
        lane: "direct",
        render: __exactImplementation_Counter_1,
        mode: "direct",
        lifecycle: __exactDirectSsrLifecycle_1
      },
      tasks: [],
      reactive: [
        {
          name: "increment",
          provenance: "unknown",
          allocation: "constant",
          dependencies: []
        },
        {
          name: "this",
          provenance: "state",
          allocation: "live-slot",
          dependencies: []
        }
      ],
      render: "returned-function"
    },
    resumption: {
      componentId: "xlgRHfFirRks2a7KO2XGVmI",
      statePaths: [
        "count",
        "rows"
      ],
      stateInputs: [],
      valueCaptures: [],
      contexts: [],
      boundaries: [],
      stateDefaults: [
        [
          "count",
          0
        ]
      ]
    }
  }
}))();
function view() {
  return __exactComponentReceipt(Counter2, {});
}
export {
  Counter2 as Counter_ExactServer_1,
  view
};
