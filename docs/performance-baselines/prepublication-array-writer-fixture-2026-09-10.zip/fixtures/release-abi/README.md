# Published component ABI fixtures

The versioned directories preserve compiler output from public ABI baselines. Compatibility tests
bundle these artifacts against the current runtime without invoking the compiler or regenerating
the files. Authored source is retained only to explain the observable contract under test.

Never refresh an existing baseline to make a runtime change pass. Add a new baseline for a major
ABI generation and retain old fixtures for every supported generation. The first baseline is 0.5.0.
