import {readFile,writeFile} from 'node:fs/promises';
const rows=[];
for(const lane of ['node-multi','node-normal','node-stream-multi','bun-multi','bun-normal'])for(const [label,prefix] of [['previous','docs/performance-baselines/wsl-recovery-final-2026-09-19-'],['current','.tmp/presentation-parity-2026-09-20/']]){
 const raw=JSON.parse(await readFile(prefix+lane+'.json'));
 for(const block of raw.blocks){
 const stage=block.results[0].stages.find(s=>s.name==='total-c32');if(!stage)continue;
 const start=Date.parse(stage.startedAt),end=start+stage.elapsedMs;
 const nearest=t=>block.telemetry.reduce((a,b)=>Math.abs(a.epochMs-t)<Math.abs(b.epochMs-t)?a:b);
 const a=nearest(start),b=nearest(end),span=b.epochMs-a.epochMs;
 const stats=b.value.statistics.totalMs,old=a.value.statistics.totalMs,count=stats.count-old.count;
 const user=b.value.cpu.user-a.value.cpu.user,system=b.value.cpu.system-a.value.cpu.system;
 rows.push({lane,label,framework:block.id,population:block.population,workerCpuPercent:(user+system)/span/10,userMicrosecondsPerResponse:user/count,systemMicrosecondsPerResponse:system/count,workerMeasuredTotalMs:(stats.sum-old.sum)/count,eventLoopP95Ms:b.value.eventLoopDelayMs.p95,rssMB:b.value.memory.rss/1e6});
 }
}
await writeFile('.tmp/presentation-parity-2026-09-20/identical-artifact-observations.json',JSON.stringify(rows,null,2)+'\n');
for(const row of rows)console.log(JSON.stringify(row));
