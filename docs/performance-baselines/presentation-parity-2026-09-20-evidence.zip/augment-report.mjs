import {readFile,writeFile} from 'node:fs/promises';
import {summarizeSsrCapacityCapture as summarize} from '../../framework-comparison/src/ssr-capacity-report.mjs';
const root='.tmp/presentation-parity-2026-09-20',prefix='docs/performance-baselines/presentation-parity-2026-09-20';
const json=async p=>JSON.parse(await readFile(p));
const comparisons=[],identities=[];
const lines=['## Comparison with the immediately preceding publication','','The September 19 recovery capture is separate from the earlier workspace reference above. Negative ratio changes are retained. Server entries and runtime adapters in these repeated lanes are identical; these differences are observations across captures, not changes introduced by the shared CSS or guarded DOM corrections.','','| Runtime/API | Loading | Previous eXact/React | Current eXact/React | Ratio change |','| --- | --- | ---: | ---: | ---: |'];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const lane of ['multi','normal']){
 const name=runtime+(mode==='stream'?'-stream':'')+'-'+lane;
 const a=await json('docs/performance-baselines/wsl-recovery-final-2026-09-19-'+name+'.json'),b=await json(root+'/'+name+'.json');
 const ratio=r=>{const rows=summarize(r).filter(s=>s.concurrency===32);return rows.find(s=>s.name==='eXact').rps/rows.find(s=>s.name==='React').rps;};
 const before=ratio(a),current=ratio(b),change=(current/before-1)*100;
 comparisons.push({name,before,current,change});
 lines.push(`| ${runtime}/${mode} | ${lane==='multi'?'preloaded':'normal'} | ${before.toFixed(3)}× | ${current.toFixed(3)}× | ${change>=0?'+':''}${change.toFixed(1)}% |`);
 for(const key of Object.keys(a.artifacts)){
 const hash=x=>x.sha256??x.hash;
 identities.push({lane:name,artifact:key,previous:hash(a.artifacts[key]),current:hash(b.artifacts[key]),identical:hash(a.artifacts[key])===hash(b.artifacts[key])});
 }
}
const source=await readFile(prefix+'.md','utf8');
await writeFile(prefix+'.md',source.replace('## Browser experience',lines.join('\n')+'\n\n## Browser experience'));
await writeFile(root+'/artifact-comparison.json',JSON.stringify(identities,null,2)+'\n');
await writeFile(root+'/previous-publication-comparison.json',JSON.stringify(comparisons,null,2)+'\n');
console.log(JSON.stringify({comparisons,allServerArtifactsIdentical:identities.every(i=>i.identical)},null,2));
