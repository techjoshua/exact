import {writeFile} from 'node:fs/promises';
import {chromium} from 'playwright';

import {waitForFirstContentfulPaint} from '../../framework-comparison/src/paint-timing.mjs';
const participants=['exact','react','sveltekit','nuxt','tanstack-start'].map((id,i)=>({id:id+'-controlled',directory:id,artifact:['dist','dist','build/client','.output/public','.output/public'][i],url:'http://127.0.0.1:'+(4401+i)}));
let browser;const samples=[];
try {
 browser=await chromium.launch();
 for(let round=0;round<11;round++)for(const participant of round%2?[...participants].reverse():participants)for(const enabled of round%2?[false,true,'native']:['native',true,false]){
  await fetch('http://127.0.0.1:4310/__benchmark/reset',{method:'POST',headers:{'content-type':'application/json','x-benchmark-control':'fixture-reset'},body:'{}'});
  const context=await browser.newContext();
  try{
   const page=await context.newPage(),cdp=await context.newCDPSession(page);
   if(enabled !== 'native')await page.route('**/*',route=>!enabled&&route.request().resourceType()==='script'?route.abort():route.continue());
   await cdp.send('Network.enable');await cdp.send('Network.setCacheDisabled',{cacheDisabled:true});await cdp.send('Performance.enable');
   await page.goto(participant.url+'/incidents/inc-100',{waitUntil:'domcontentloaded'});
   await page.getByRole('heading',{name:'Checkout authorization failures',exact:true}).waitFor();
   const fcp=await page.evaluate(waitForFirstContentfulPaint);
   const navigation=await page.evaluate(()=>performance.getEntriesByType('navigation')[0].toJSON());
   const {metrics}=await cdp.send('Performance.getMetrics');
   let fonts;if(round===0&&enabled==='native'){await cdp.send('DOM.enable');await cdp.send('CSS.enable');const {root}=await cdp.send('DOM.getDocument');const {nodeId}=await cdp.send('DOM.querySelector',{nodeId:root.nodeId,selector:'h1'});fonts=await cdp.send('CSS.getPlatformFontsForNode',{nodeId});}
   samples.push({fonts,round,participant:participant.id,variant:enabled==='native'?'native':enabled?'intercepted':'blocked',applicationScriptsEnabled:enabled!==false,fcp,navigation,metrics});
   console.log('sample',round,participant.id,enabled,fcp);
  }finally{await context.close();}
 }
 await writeFile(import.meta.dirname+'/paint-confirm-'+process.argv[2]+'.json',JSON.stringify({note:'Diagnostic JS-disabled counterfactual, not a production performance claim',browserVersion:browser.version(),executable:chromium.executablePath(),platform:process.platform,node:process.version,samples},null,2));
 for(const p of participants)for(const enabled of ['native','intercepted','blocked']){const xs=samples.filter(s=>s.round>0&&s.participant===p.id&&s.variant===enabled).map(s=>s.fcp).sort((a,b)=>a-b);console.log(p.id,enabled,{mean:xs.reduce((a,b)=>a+b,0)/xs.length,p50:xs[Math.ceil(xs.length/2)-1],min:xs[0],max:xs.at(-1)});}
}finally{await browser?.close();}
