import json,statistics,datetime
for name in ['full-performance-2026-09-14','enhancement-framework-2026-09-18','wsl-workspace-2026-09-19','wsl-recovery-final-2026-09-19']:
 r=json.load(open('docs/performance-baselines/'+name+'-startup.json'));print(name,r['environment']['chromium'])
 for k in ['exact-controlled','react-controlled','sveltekit-controlled']:
  v=r['profiles']['1x'][k];print(k,{key:round(s['mean'],2) for key,s in v['summary'].items() if isinstance(s,dict) and 'mean' in s and any(t in key.lower() for t in ['paint','duration','trace'])})
  if k=='exact-controlled':print('TRACE',str(v['samples'][0].get('trace',{}))[:1500])
r=json.load(open('docs/performance-baselines/wsl-recovery-final-2026-09-19-bun-multi.json'))
for b in r['blocks']:
 print('BLOCK',b['id'],b['population'])
 for si in [3,4]:
  stages=[x['stages'][si] for x in b['results']];a=stages[0];start=datetime.datetime.fromisoformat(a['startedAt'].replace('Z','+00:00')).timestamp()*1000;ts=[t for t in b['telemetry'] if start<=t['epochMs']<=start+a['elapsedMs']]
  first,last=ts[0],ts[-1];dt=(last['epochMs']-first['epochMs'])/1000
  cpu={k:round((last['value']['cpu'][k]-first['value']['cpu'][k])/dt/10000,1) for k in ['user','system']}
  stats=[i['process']['cpuPercentOfOneCore'] for st in stages for i in st['intervals'] if i.get('process')]
  print(a['name'],'worker CPU%',cpu,'driver CPU%mean',round(statistics.mean(stats),1),'workerRSSMB',round(last['value']['memory']['rss']/1e6,1),'latencymean',round(statistics.mean(s['distributions']['responseMs']['mean'] for s in stages),2))
