(function() {
  let e3 = document.createElement(`link`).relList;
  if (e3 && e3.supports && e3.supports(`modulepreload`)) return;
  for (let e4 of document.querySelectorAll(`link[rel="modulepreload"]`)) n2(e4);
  new MutationObserver((e4) => {
    for (let t3 of e4) if (t3.type === `childList`) for (let e5 of t3.addedNodes) e5.tagName === `LINK` && e5.rel === `modulepreload` && n2(e5);
  }).observe(document, { childList: true, subtree: true });
  function t2(e4) {
    let t3 = {};
    return e4.integrity && (t3.integrity = e4.integrity), e4.referrerPolicy && (t3.referrerPolicy = e4.referrerPolicy), t3.credentials = e4.crossOrigin === `use-credentials` ? `include` : e4.crossOrigin === `anonymous` ? `omit` : `same-origin`, t3;
  }
  function n2(e4) {
    if (e4.ep) return;
    e4.ep = true;
    let n3 = t2(e4);
    fetch(e4.href, n3);
  }
})();
function e(e3) {
  e3.activationsDeferred = true;
}
function t(e3, t2) {
  e3.activationsDeferred = false;
  for (let n2 of e3.activationRegistrations) n2.start(t2(n2.task));
}
var n = /* @__PURE__ */ Symbol.for(`@exactjs/task-owner-host`);
function r(e3, t2) {
  Object.defineProperty(e3, n, { value: t2, configurable: true, enumerable: false, writable: false }), t2.host = e3;
}
function i(e3) {
  return e3[n];
}
var a = /* @__PURE__ */ Symbol.for(`@exactjs/continuation-task`);
function o(e3) {
  return e3[a];
}
var s = /* @__PURE__ */ new WeakMap(), c = /* @__PURE__ */ new WeakMap(), l = [], u = [], d = [], f = [], p = false;
function m(e3, t2) {
  let n2 = d[d.length - 1];
  if (n2 !== void 0 && l.length <= n2) return false;
  let r2 = l[l.length - 1];
  return r2 ? (g(r2, e3, t2), true) : false;
}
function h(e3, t2, n2) {
  let r2 = c.get(e3);
  return r2 || c.set(e3, r2 = /* @__PURE__ */ new Map()), r2.set(t2, n2), () => {
    let r3 = c.get(e3);
    r3?.get(t2) === n2 && (r3.delete(t2), r3.size || c.delete(e3));
  };
}
function g(e3, t2, n2) {
  _(e3, y(t2, n2));
}
function _(e3, t2) {
  let n2 = t2.subscribers, r2 = u[u.length - 1], i2 = r2?.reaction === e3;
  if (n2 === e3 || n2 instanceof Set && n2.has(e3)) {
    i2 && !r2.seen?.has(t2) && ((r2.seen ??= /* @__PURE__ */ new Set()).add(t2), e3.deps.push(t2));
    return;
  }
  i2 && (r2.seen ??= /* @__PURE__ */ new Set()).add(t2);
  let a2 = n2 === void 0;
  t2.subscribers = n2 === void 0 ? e3 : n2 instanceof Set ? n2.add(e3) : /* @__PURE__ */ new Set([n2, e3]), e3.deps.push(t2), a2 && ie(c.get(t2.target)?.get(t2.key)?.onObserved);
}
function v(e3) {
  return e3.deps;
}
function y(e3, t2) {
  let n2 = s.get(e3);
  n2 || s.set(e3, n2 = /* @__PURE__ */ new Map());
  let r2 = n2.get(t2);
  return r2 || (r2 = { target: e3, key: t2 }, n2.set(t2, r2)), r2;
}
function b(e3) {
  for (let t2 of u) if (t2.reaction === e3) {
    for (let n2 of t2.previous) x(e3, n2);
    t2.previous = [];
  }
  for (let t2 of e3.deps) x(e3, t2);
  e3.deps.length = 0;
}
function x(e3, t2) {
  let n2 = t2.subscribers;
  if (n2 === e3) t2.subscribers = void 0;
  else if (n2 instanceof Set && n2.delete(e3)) n2.size === 1 ? t2.subscribers = n2.values().next().value : n2.size === 0 && (t2.subscribers = void 0);
  else return;
  t2.subscribers === void 0 && re(t2);
}
function ee(e3, t2) {
  let n2 = s.get(e3)?.get(t2), r2 = n2?.subscribers;
  if (r2 instanceof Set) for (let e4 of [...r2]) ne(e4, n2) && e4.schedule();
  else r2 && ne(r2, n2) && r2.schedule();
}
function te(e3) {
  if (!e3.size) return;
  let t2 = /* @__PURE__ */ new Set();
  for (let [n2, r2] of e3) {
    let e4 = s.get(n2);
    if (e4) for (let n3 of r2) {
      let r3 = e4.get(n3), i2 = r3?.subscribers;
      if (i2 instanceof Set) for (let e5 of i2) ne(e5, r3) && t2.add(e5);
      else i2 && ne(i2, r3) && t2.add(i2);
    }
  }
  for (let e4 of t2) e4.schedule();
}
function ne(e3, t2) {
  for (let n2 = u.length - 1; n2 >= 0; n2--) {
    let r2 = u[n2];
    if (r2.reaction === e3) return r2.seen?.has(t2) ?? false;
  }
  return true;
}
function S(e3, t2) {
  let n2 = { reaction: e3, previous: e3.deps, seen: void 0 };
  e3.deps = [], u.push(n2), l.push(e3);
  try {
    t2();
  } finally {
    l.pop(), u.pop();
    for (let t3 of n2.previous) n2.seen?.has(t3) || x(e3, t3);
    e3.active || b(e3);
  }
}
function C(e3) {
  d.push(l.length);
  try {
    return e3();
  } finally {
    d.pop();
  }
}
function re(e3) {
  ie(c.get(e3.target)?.get(e3.key)?.onUnobserved);
  let t2 = s.get(e3.target);
  t2?.get(e3.key) === e3 && t2.delete(e3.key), t2 && !t2.size && s.delete(e3.target);
}
function ie(e3) {
  if (e3 && (f.push(e3), !p)) {
    p = true;
    try {
      for (; f.length; ) f.pop()();
    } finally {
      p = false;
    }
  }
}
var w = [], ae = /* @__PURE__ */ new WeakMap(), oe = 0;
function T(e3, t2) {
  let n2 = D(e3, t2), r2 = he(e3, t2), i2 = w[w.length - 1];
  if (i2) {
    let a2 = i2.triggers.get(e3);
    a2 || (a2 = /* @__PURE__ */ new Set(), i2.triggers.set(e3, a2)), a2.add(t2), i2.versionRanges && ve(i2.versionRanges, e3, t2, n2, r2);
    return;
  }
  Ce(e3, t2);
}
function se(e3) {
  let t2 = w[w.length - 1], n2 = _e(true, !!t2?.versionRanges);
  w.push(n2);
  let r2;
  try {
    r2 = e3();
  } catch (e4) {
    throw w.pop(), me(n2), e4;
  }
  return w.pop(), fe(t2, n2), r2;
}
function ce(e3) {
  let t2 = w[w.length - 1], n2 = _e(!!t2?.undos, !!t2?.versionRanges);
  w.push(n2);
  let r2;
  try {
    r2 = e3();
  } catch (e4) {
    throw w.pop(), fe(t2, n2), e4;
  }
  return w.pop(), fe(t2, n2), r2;
}
function E(e3, t2, n2) {
  w[w.length - 1]?.undos?.push({ apply: e3, target: t2, key: n2 });
}
function le() {
  return !!w[w.length - 1]?.undos;
}
function ue() {
  return w.length > 0;
}
function de(e3, t2) {
  e3.undos && t2.undos && e3.undos.push(...t2.undos), pe(e3.triggers, t2.triggers), e3.versionRanges && t2.versionRanges && ye(e3.versionRanges, t2.versionRanges);
}
function fe(e3, t2) {
  e3 ? de(e3, t2) : Se(t2.triggers);
}
function pe(e3, t2) {
  for (let [n2, r2] of t2) {
    let t3 = e3.get(n2);
    t3 || (t3 = /* @__PURE__ */ new Set(), e3.set(n2, t3));
    for (let e4 of r2) t3.add(e4);
  }
}
function me(e3, t2) {
  let n2 = e3.undos;
  if (!n2) return;
  let r2 = /* @__PURE__ */ new Map(), i2 = { allows: (e4, n3, r3 = 0) => !t2 || D(e4, n3) === (t2.get(e4)?.get(n3) ?? r3), mark: (e4, t3) => be(r2, e4, t3) };
  for (let e4 = n2.length - 1; e4 >= 0; e4--) {
    let t3 = n2[e4];
    t3.target && t3.key !== void 0 && !i2.allows(t3.target, t3.key) || (t3.apply(i2), t3.target && t3.key !== void 0 && i2.mark(t3.target, t3.key));
  }
  xe(r2);
}
function he(e3, t2) {
  let n2 = ae.get(e3);
  n2 || ae.set(e3, n2 = /* @__PURE__ */ new Map());
  let r2 = (n2.get(t2) ?? 0) + 1;
  return n2.set(t2, r2), r2;
}
function D(e3, t2) {
  return ae.get(e3)?.get(t2) ?? 0;
}
function ge() {
  return oe;
}
function _e(e3, t2 = false) {
  return { ...e3 ? { undos: [] } : {}, triggers: /* @__PURE__ */ new Map(), ...t2 ? { versionRanges: /* @__PURE__ */ new Map() } : {} };
}
function ve(e3, t2, n2, r2, i2) {
  let a2 = e3.get(t2);
  a2 || e3.set(t2, a2 = /* @__PURE__ */ new Map());
  let o2 = a2.get(n2);
  o2 ? o2.end = i2 : a2.set(n2, { start: r2, end: i2 });
}
function ye(e3, t2) {
  for (let [n2, r2] of t2) {
    let t3 = e3.get(n2);
    t3 || e3.set(n2, t3 = /* @__PURE__ */ new Map());
    for (let [e4, n3] of r2) {
      let r3 = t3.get(e4);
      r3 ? r3.end = n3.end : t3.set(e4, { ...n3 });
    }
  }
}
function be(e3, t2, n2) {
  let r2 = e3.get(t2);
  r2 || e3.set(t2, r2 = /* @__PURE__ */ new Set()), r2.add(n2);
}
function xe(e3) {
  if (e3.size) {
    for (let [t2, n2] of e3) for (let e4 of n2) he(t2, e4);
    oe++;
  }
}
function Se(e3) {
  te(e3);
}
function Ce(e3, t2) {
  ee(e3, t2);
}
function we(e3, t2) {
  if (e3) try {
    e3(t2);
  } catch {
  }
}
function Te() {
  return globalThis.performance?.now() ?? Date.now();
}
var O = /* @__PURE__ */ new Map(), k = /* @__PURE__ */ new Map(), Ee = [], De = false, Oe = false, ke = 0, Ae = 1e3, je = 8, Me = { interactive: 0, normal: 1, deferred: 2 }, Ne, Pe = /* @__PURE__ */ new Set(), Fe = false, Ie = false;
function Le(e3) {
  Ne = e3;
}
function Re(e3, t2 = Ue()) {
  t2 = ct(e3.scope, t2);
  let n2 = O.get(e3), r2 = Ne?.(t2);
  r2 && n2?.context?.cancel(), (!n2 || st(t2, n2.priority) || r2) && O.set(e3, { priority: n2 && !st(t2, n2.priority) ? n2.priority : t2, context: r2 ?? n2?.context }), Ze(t2);
}
function ze(e3, t2, n2 = Ue(), r2) {
  n2 = ct(r2, n2);
  let i2 = k.get(e3);
  (!i2 || st(n2, i2.priority)) && k.set(e3, { priority: n2, onError: t2 ?? i2?.onError, scope: r2 ?? i2?.scope }), Ze(n2);
}
function Be(e3) {
  k.delete(e3);
}
function Ve(e3, t2) {
  for (let n2 of O.keys()) (t2 ? n2.scope && t2.has(n2.scope) : n2.scope === e3) && (O.get(n2)?.context?.cancel(), O.delete(n2));
  for (let [n2, r2] of k) (t2 ? r2.scope && t2.has(r2.scope) : r2.scope === e3) && k.delete(n2);
}
function He() {
  return O.size || k.size ? /* @__PURE__ */ new Set() : void 0;
}
function Ue() {
  return Ee[Ee.length - 1] ?? `normal`;
}
function We(e3, t2) {
  Ee.push(e3);
  try {
    return t2();
  } finally {
    Ee.pop();
  }
}
function Ge(e3, t2 = Ue(), n2, r2) {
  ze(e3, n2, t2, r2);
}
function Ke() {
  Qe();
}
function qe(e3 = `deferred`) {
  let t2 = 0, n2, r2 = false, i2, a2 = /* @__PURE__ */ new Map();
  try {
    for (; et(e3); ) {
      if (++t2 > Ae) {
        let e4 = Error(`eXact reactive scheduler exceeded its flush limit; a reaction is repeatedly invalidating itself`);
        if (Xe(e4)) return;
        throw e4;
      }
      for (; tt(e3); ) {
        if (++t2 > Ae) {
          let e4 = Error(`eXact reactive scheduler exceeded its flush limit; a computation is repeatedly invalidating itself`);
          if (Xe(e4)) return;
          throw e4;
        }
        let i3 = it(e3);
        for (let [e4, t3] of i3) if (!(t3.scope && !t3.scope.active)) try {
          We(t3.priority, e4);
        } catch (e5) {
          if (t3.onError) try {
            t3.onError(e5);
          } catch (e6) {
            r2 || (n2 = e6), r2 = true;
          }
          else r2 || (n2 = e5), r2 = true;
        }
      }
      let o2 = at(e3);
      for (let [e4, t3] of o2) {
        if (!e4.active || e4.scope && (!e4.scope.active || e4.scope.paused)) {
          t3.context?.cancel();
          continue;
        }
        let o3 = e4.scope?.onProfile;
        o3 && (i2 ??= Te(), a2.set(o3, (a2.get(o3) ?? 0) + 1));
        try {
          t3.context ? t3.context.run(() => Je(t3.priority, e4)) : Je(t3.priority, e4);
        } catch (e5) {
          r2 || (n2 = e5), r2 = true;
        }
      }
    }
  } finally {
    if (e3 === `deferred` ? (De = false, Oe = false) : De = false, Qe(), et(`deferred`) || Ye(), i2 !== void 0) for (let [e4, n3] of a2) we(e4, Object.freeze({ subsystem: `reactive`, phase: `flush`, elapsedMs: Te() - i2, counts: Object.freeze({ passes: t2, reactions: n3 }) }));
  }
  if (r2) throw n2;
}
function Je(e3, t2) {
  Ee.push(e3);
  try {
    t2.run();
  } finally {
    Ee.pop();
  }
}
function Ye() {
  if (Ie || et(`deferred`) || (Fe = false, !Pe.size)) return;
  let e3 = [...Pe];
  Pe.clear(), Ie = true;
  try {
    for (let t2 of e3) t2();
  } finally {
    Ie = false, Pe.size && !Fe && (Fe = true, queueMicrotask(Ye));
  }
}
function Xe(e3) {
  let t2 = /* @__PURE__ */ new Set();
  for (let e4 of k.values()) e4.onError && t2.add(e4.onError);
  for (let [e4, n3] of O) e4.scheduled = false, e4.pendingPriority = void 0, n3.context?.cancel(), e4.scope?.onError && t2.add(e4.scope.onError);
  if (k.clear(), O.clear(), !t2.size) return false;
  let n2, r2 = false;
  for (let i2 of t2) try {
    i2(e3);
  } catch (e4) {
    r2 || (n2 = e4), r2 = true;
  }
  if (r2) throw n2;
  return true;
}
function Ze(e3) {
  if (e3 === `deferred`) {
    if (De || Oe) return;
    Oe = true, lt(() => {
      Oe = false, ke = 0, qe();
    });
    return;
  }
  De || (De = true, queueMicrotask(() => {
    De = false;
    let e4 = rt(`deferred`) && ++ke >= je;
    e4 && (ke = 0), qe(e4 ? `deferred` : `normal`);
  }));
}
function Qe() {
  let e3 = $e();
  e3 && Ze(e3);
}
function $e() {
  let e3;
  for (let [t2, n2] of O) t2.scope?.paused || (!e3 || st(n2.priority, e3)) && (e3 = n2.priority);
  for (let t2 of k.values()) t2.scope?.paused || (!e3 || st(t2.priority, e3)) && (e3 = t2.priority);
  return e3;
}
function et(e3) {
  return tt(e3) || nt(e3);
}
function tt(e3) {
  for (let t2 of k.values()) if (!t2.scope?.paused && ot(t2.priority, e3)) return true;
  return false;
}
function nt(e3) {
  for (let [t2, n2] of O) if (!t2.scope?.paused && ot(n2.priority, e3)) return true;
  return false;
}
function rt(e3) {
  for (let [t2, n2] of O) if (!t2.scope?.paused && n2.priority === e3) return true;
  for (let t2 of k.values()) if (!t2.scope?.paused && t2.priority === e3) return true;
  return false;
}
function it(e3) {
  let t2 = [];
  for (let [n2, r2] of k) r2.scope?.paused || ot(r2.priority, e3) && (k.delete(n2), t2.push([n2, r2]));
  return t2.sort((e4, t3) => Me[e4[1].priority] - Me[t3[1].priority]), t2;
}
function at(e3) {
  let t2 = [];
  for (let [n2, r2] of O) n2.scope?.paused || ot(r2.priority, e3) && (O.delete(n2), t2.push([n2, r2]));
  return t2.sort((e4, t3) => Me[e4[1].priority] - Me[t3[1].priority] || (e4[0].order ?? 1) - (t3[0].order ?? 1)), t2;
}
function ot(e3, t2) {
  return Me[e3] <= Me[t2];
}
function st(e3, t2) {
  return Me[e3] < Me[t2];
}
function ct(e3, t2) {
  let n2 = t2;
  for (let t3 = e3; t3; t3 = t3.parent) t3.workPriority && st(n2, t3.workPriority) && (n2 = t3.workPriority);
  return n2;
}
function lt(e3) {
  setTimeout(e3, 0);
}
var ut = [], dt = /* @__PURE__ */ new Set(), ft = /* @__PURE__ */ new Set(), pt = /* @__PURE__ */ new Set(), mt = /* @__PURE__ */ new Set(), ht = class {
  active = true;
  selfPaused = false;
  workPriority;
  parent;
  onError;
  onProfile;
  childrenValue;
  reactionsValue;
  cleanupsValue;
  resumeWaitersValue;
  constructor(e3, t2, n2) {
    this.parent = e3, this.onError = t2 ?? e3?.onError, this.onProfile = n2 ?? e3?.onProfile, e3?.children.add(this);
  }
  get paused() {
    return Tt(this);
  }
  get children() {
    return this.childrenValue ??= /* @__PURE__ */ new Set();
  }
  get reactions() {
    return this.reactionsValue ??= /* @__PURE__ */ new Set();
  }
  get cleanups() {
    return this.cleanupsValue ??= /* @__PURE__ */ new Set();
  }
  get resumeWaiters() {
    return this.resumeWaitersValue ??= /* @__PURE__ */ new Set();
  }
  pause() {
    this.selfPaused = true;
  }
  resume() {
    this.selfPaused && (this.selfPaused = false, Et(this), Ke());
  }
  stop() {
    xt(this);
  }
  ownedChildren() {
    return this.childrenValue ?? dt;
  }
  ownedReactions() {
    return this.reactionsValue ?? ft;
  }
  ownedCleanups() {
    return this.cleanupsValue ?? pt;
  }
  ownedResumeWaiters() {
    return this.resumeWaitersValue ?? mt;
  }
  removeChild(e3) {
    this.childrenValue?.delete(e3), this.childrenValue?.size === 0 && (this.childrenValue = void 0);
  }
  removeReaction(e3) {
    this.reactionsValue?.delete(e3), this.reactionsValue?.size === 0 && (this.reactionsValue = void 0);
  }
  removeCleanup(e3) {
    this.cleanupsValue?.delete(e3), this.cleanupsValue?.size === 0 && (this.cleanupsValue = void 0);
  }
  releaseResumeWaiters() {
    this.resumeWaitersValue = void 0;
  }
  releaseCollections() {
    this.childrenValue = void 0, this.reactionsValue = void 0, this.cleanupsValue = void 0, this.resumeWaitersValue = void 0;
  }
};
function gt(e3, t2) {
  e3.reactions.add(t2);
}
function _t(e3, t2) {
  e3.removeReaction(t2);
}
function vt(e3, t2) {
  e3.cleanups.add(t2);
}
function A(e3 = St(), t2, n2) {
  let r2 = e3;
  if (r2 && !r2.active) throw Error(`Cannot create an effect scope beneath an inactive parent scope`);
  return new ht(r2, t2, n2);
}
function yt(e3) {
  return e3.parent;
}
function bt(e3, t2) {
  let n2 = e3, r2 = t2;
  if (!n2.active) throw Error(`Cannot transfer an inactive effect scope`);
  if (r2 && !r2.active) throw Error(`Cannot transfer an effect scope beneath an inactive parent scope`);
  for (let e4 = r2; e4; e4 = e4.parent) if (e4 === n2) throw Error(`Cannot create an effect scope cycle`);
  n2.parent !== r2 && (n2.parent?.removeChild(n2), n2.parent = r2, r2?.children.add(n2), Et(n2), Ke());
}
function xt(e3) {
  if (!e3.active) return;
  let t2 = He(), n2 = [e3], r2, i2 = false;
  for (; n2.length; ) {
    let e4 = n2.pop(), a2 = e4 === void 0, o2 = a2 ? n2.pop() : e4;
    if (!a2) {
      if (!o2.active) continue;
      o2.active = false;
      for (let e6 of o2.ownedResumeWaiters()) e6();
      o2.releaseResumeWaiters();
      let e5 = o2.ownedChildren();
      if (e5.size) {
        n2.push(o2, void 0);
        let t3 = n2.length;
        for (let t4 of e5) n2.push(t4);
        for (let e6 = t3, r3 = n2.length - 1; e6 < r3; e6++, r3--) {
          let t4 = n2[e6];
          n2[e6] = n2[r3], n2[r3] = t4;
        }
        continue;
      }
    }
    for (let e5 of [...o2.ownedReactions()]) try {
      e5.stop();
    } catch (e6) {
      i2 || (r2 = e6), i2 = true;
    }
    for (let e5 of [...o2.ownedCleanups()]) try {
      e5();
    } catch (e6) {
      i2 || (r2 = e6), i2 = true;
    }
    t2 ? t2.add(o2) : Ve(o2), o2.parent?.removeChild(o2), o2.parent = void 0, o2.releaseCollections();
  }
  if (t2 && Ve(void 0, t2), Ke(), i2) throw r2;
}
function j(e3, t2) {
  if (!e3) return t2();
  if (!e3.active) throw Error(`Cannot create reactive work inside an inactive effect scope`);
  ut.push(e3);
  try {
    return t2();
  } finally {
    ut.pop();
  }
}
function St() {
  return ut[ut.length - 1];
}
function Ct(e3, t2) {
  let n2 = e3, r2 = n2.active && n2.paused ? n2.resumeWaiters : void 0, i2 = true, a2 = () => {
    r2?.delete(a2), queueMicrotask(() => {
      i2 && (i2 = false, t2());
    });
  };
  return r2 ? r2.add(a2) : a2(), () => {
    i2 = false, r2?.delete(a2);
  };
}
function wt(e3, t2) {
  let n2 = t2;
  for (let t3 = e3; t3; t3 = t3.parent) t3.workPriority && st(n2, t3.workPriority) && (n2 = t3.workPriority);
  return n2;
}
function Tt(e3) {
  for (let t2 = e3; t2; t2 = t2.parent) if (t2.selfPaused) return true;
  return false;
}
function Et(e3) {
  let t2 = [e3];
  for (; t2.length; ) {
    let e4 = t2.pop();
    if (e4.active && !e4.paused && e4.ownedResumeWaiters().size) {
      for (let t3 of e4.ownedResumeWaiters()) t3();
      e4.releaseResumeWaiters();
    }
    for (let n2 of e4.ownedChildren()) t2.push(n2);
  }
}
var Dt = /* @__PURE__ */ Symbol.for(`exact.reactive.proxy`), Ot = /* @__PURE__ */ Symbol.for(`exact.reactive.value`), kt = /* @__PURE__ */ Symbol.for(`exact.reactive.raw`), At = /* @__PURE__ */ Symbol.for(`exact.reactive.valueRef`), M = /* @__PURE__ */ Symbol.for(`exact.reactive.iterate`), N = /* @__PURE__ */ Symbol.for(`exact.reactive.arrayLengthWrite`);
function P(e3) {
  return !!e3 && typeof e3 == `object` && Ot in e3;
}
function jt(e3) {
  return !!e3 && typeof e3 == `object` && !!e3[Dt];
}
function F(e3) {
  return typeof e3 != `object` || !e3 ? e3 : P(e3) ? e3.get() : jt(e3) ? e3[kt] : e3;
}
function Mt() {
  throw TypeError(`Cannot write to readonly reactive value`);
}
function Nt(e3, t2) {
  let n2 = [e3, t2].sort();
  return Error(`Conflicting this.map() key extractors for the same collection (${n2[0]} and ${n2[1]}). A reactive collection must have one stable key contract.`);
}
var Pt = Object.freeze({}), Ft = Object.freeze({ readonly: true }), It = /* @__PURE__ */ new WeakMap(), Lt = /* @__PURE__ */ new WeakMap(), Rt = /* @__PURE__ */ new WeakMap(), zt = /* @__PURE__ */ new WeakMap(), Bt = /* @__PURE__ */ new WeakSet(), Vt = /* @__PURE__ */ new WeakMap(), Ht = /* @__PURE__ */ new Set([`copyWithin`, `fill`, `pop`, `push`, `reverse`, `shift`, `sort`, `splice`, `unshift`]);
function Ut(e3) {
  if (!e3 || typeof e3 != `object`) return false;
  let t2 = Object.getPrototypeOf(e3);
  return t2 === Object.prototype || t2 === null;
}
function Wt(e3, t2) {
  return Array.isArray(e3) && (t2 === `length` || Gt(t2));
}
function Gt(e3) {
  if (typeof e3 == `number`) return Number.isInteger(e3) && e3 >= 0;
  if (typeof e3 != `string` || e3 === ``) return false;
  let t2 = Number(e3);
  return Number.isInteger(t2) && t2 >= 0 && String(t2) === e3;
}
var Kt = /* @__PURE__ */ Symbol.for(`@exactjs/opaque-target-operation`);
function qt(e3, t2, n2) {
  return !Jt(e3, t2, n2);
}
function Jt(e3, t2, n2) {
  if (Object.is(e3, t2)) return true;
  let r2, i2, a2 = [[e3, t2]], o2 = 0;
  for (; a2.length; ) {
    if (++o2 > 1e6) return false;
    let [e4, t3] = a2.pop();
    if (Object.is(e4, t3)) continue;
    let s2 = n2(e4), c2 = n2(t3);
    if (Object.is(s2, c2)) continue;
    if (!s2 || !c2 || typeof s2 != `object` || typeof c2 != `object` || Kt in s2 || Kt in c2) return false;
    r2 ??= /* @__PURE__ */ new WeakMap(), i2 ??= /* @__PURE__ */ new WeakMap();
    let l2 = r2.get(s2), u2 = i2.get(c2);
    if (l2 || u2) {
      if (l2 !== c2 || u2 !== s2) return false;
      continue;
    }
    r2.set(s2, c2), i2.set(c2, s2);
    let d2 = Array.isArray(s2) && Array.isArray(c2), f2 = Ut(s2) && Ut(c2);
    if (!d2 && !f2 || Object.getPrototypeOf(s2) !== Object.getPrototypeOf(c2) || d2 && s2.length !== c2.length) return false;
    let p2 = Reflect.ownKeys(s2).filter((e5) => !d2 || e5 !== `length`), m2 = Reflect.ownKeys(c2).filter((e5) => !d2 || e5 !== `length`);
    if (p2.length !== m2.length) return false;
    for (let e5 of p2) {
      if (!Object.prototype.hasOwnProperty.call(c2, e5)) return false;
      let t4 = Reflect.getOwnPropertyDescriptor(s2, e5), n3 = Reflect.getOwnPropertyDescriptor(c2, e5);
      if (!t4 || !n3) return false;
      if (!(`value` in t4) || !(`value` in n3)) {
        if (t4.get !== n3.get || t4.set !== n3.set || t4.enumerable !== n3.enumerable || t4.configurable !== n3.configurable) return false;
        continue;
      }
      if (t4.enumerable !== n3.enumerable || t4.configurable !== n3.configurable || t4.writable !== n3.writable) return false;
      a2.push([t4.value, n3.value]);
    }
  }
  return true;
}
var Yt = /* @__PURE__ */ Symbol.for(`@exactjs/opaque-target-operation`);
function Xt(e3, t2) {
  return qt(e3, t2, F);
}
function Zt(e3, t2) {
  return jt(e3) || jt(t2) ? !Object.is(e3, t2) : Xt(e3, t2);
}
function Qt(e3) {
  return e3 && typeof e3 == `object` && Object.prototype.hasOwnProperty.call(e3, Yt) ? false : Array.isArray(e3) || e3 instanceof Map || e3 instanceof Set || Ut(e3);
}
var $t = /* @__PURE__ */ new WeakMap(), en = /* @__PURE__ */ new WeakMap(), tn = 1e5, nn = `eXact reactive computation cycle detected`, rn = 0, an = 0;
function on(e3) {
  let t2 = new ln(e3, St()), n2 = { [Ot]: true, [At]: t2, get: () => t2.get(), toJSON: sn, toString: cn, valueOf: sn, [Symbol.toPrimitive]: sn };
  return en.set(n2, t2), n2;
}
function sn() {
  return this.get();
}
function cn() {
  return String(this.get());
}
var ln = class {
  compute;
  scope;
  active = true;
  scheduled = false;
  pendingPriority;
  deps = [];
  target = {};
  key = `value`;
  state = `dirty`;
  initialized = false;
  current;
  observed = false;
  failed = false;
  invalidatedWhileComputing = false;
  validatedGeneration = 0;
  restorationVersion = ge();
  dependencies = [];
  computedSources;
  computedSinks;
  releaseObservationHooks;
  settleScheduled = () => this.settle();
  constructor(e3, t2) {
    this.compute = e3, this.scope = t2, $t.set(this.target, this), this.releaseObservationHooks = h(this.target, this.key, { onObserved: () => this.becomeObserved(), onUnobserved: () => this.becomeUnobserved() }), t2 && gt(t2, this);
  }
  set(e3) {
    Mt();
  }
  get() {
    if (this.state === `computing`) throw Error(nn);
    return this.active && !this.scope?.paused && (an === 0 || this.validatedGeneration !== an) && this.settle(), m(this.target, this.key), this.current;
  }
  run() {
    if (this.scheduled = false, this.pendingPriority = void 0, !this.active || this.scope && !this.scope.active) {
      this.stop();
      return;
    }
    this.settle();
  }
  schedule() {
    if (!this.active || this.scope && !this.scope.active) {
      this.stop();
      return;
    }
    this.state !== `computing` && this.initialized && this.dependencies.every((e3) => D(e3.target, e3.key) === e3.version) || (this.state === `computing` ? this.invalidatedWhileComputing = true : this.state = `dirty`, this.markSinksChecked(), this.isRetained() && this.queue());
  }
  stop() {
    this.active && (this.active = false, this.state = `stopped`, this.scheduled = false, this.pendingPriority = void 0, Be(this.settleScheduled), b(this), this.detachComputedSources(), this.releaseObservationHooks(), this.scope && _t(this.scope, this));
  }
  inspect() {
    return Object.freeze({ state: this.failed ? `failed` : this.scope?.paused ? `paused` : this.state, priority: this.pendingPriority ?? wt(this.scope, Ue()), observed: this.isRetained(), initialized: this.initialized, sources: this.dependencies.length, sinks: this.computedSinks?.size ?? 0 });
  }
  settle() {
    if (!this.active || this.scope?.paused) return;
    let e3 = an === 0;
    e3 && (an = ++rn);
    try {
      un(this);
    } finally {
      e3 && (an = 0);
    }
  }
  needsValidation() {
    return this.state !== `clean` || !this.isRetained() || ue() || this.restorationVersion !== ge();
  }
  validateAndEvaluate() {
    if (!(!this.active || this.scope?.paused)) {
      if (this.state === `computing`) throw Error(nn);
      if (this.initialized && this.state !== `dirty`) {
        if (!this.dependencies.some((e3) => D(e3.target, e3.key) !== e3.version)) {
          this.state = `clean`, Be(this.settleScheduled), this.scheduled = false, this.pendingPriority = void 0, this.validatedGeneration = an, this.restorationVersion = ge();
          return;
        }
        this.state = `dirty`;
      }
      (this.state === `dirty` || !this.initialized) && this.evaluate(), this.validatedGeneration = an, this.restorationVersion = ge();
    }
  }
  evaluate() {
    let e3 = this.dependencies, t2 = this.current, n2 = this.initialized;
    this.state = `computing`, this.failed = false, this.invalidatedWhileComputing = false, Be(this.settleScheduled), b(this), this.detachComputedSources();
    let r2;
    try {
      j(this.scope, () => S(this, () => {
        let e4 = this.compute();
        pn(e4), r2 = P(e4) ? e4.get() : e4;
      }));
    } catch (t3) {
      this.recoverFromFailure(e3, t3);
      return;
    }
    this.dependencies = dn(this), this.refreshComputedSources(), this.isRetained() || (b(this), this.detachComputedSources());
    let i2 = !n2 || Zt(t2, r2);
    this.current = n2 && !i2 ? t2 : r2, this.initialized = true, this.state = this.invalidatedWhileComputing ? `dirty` : `clean`, this.scheduled = false, this.pendingPriority = void 0, n2 && i2 && T(this.target, this.key), this.invalidatedWhileComputing && this.queue(true);
  }
  recoverFromFailure(e3, t2) {
    let n2 = dn(this);
    b(this), this.dependencies = fn(e3, n2), this.isRetained() && this.attachDependencies(), this.failed = true, this.state = `clean`, this.validatedGeneration = an, this.restorationVersion = ge(), Be(this.settleScheduled), this.scheduled = false, this.pendingPriority = void 0;
    let r2 = this.scope?.onError;
    if (!r2) throw t2;
    r2(t2);
  }
  queue(e3 = false) {
    if (!e3 && !this.isRetained()) return;
    let t2 = wt(this.scope, Ue());
    (this.pendingPriority === void 0 || t2 === `interactive` || this.pendingPriority === `deferred` && t2 === `normal`) && (this.pendingPriority = t2), this.scheduled = true, ze(this.settleScheduled, void 0, t2, this.scope);
  }
  markSinksChecked() {
    let e3 = this.computedSinks ? [...this.computedSinks] : [], t2 = /* @__PURE__ */ new Set();
    for (; e3.length; ) {
      let n2 = e3.pop();
      if (!(!t2.add(n2) || !n2.active) && (n2.state === `clean` && (n2.state = `checked`), n2.state === `computing` && (n2.invalidatedWhileComputing = true), n2.isRetained() && n2.queue(), n2.computedSinks)) for (let t3 of n2.computedSinks) e3.push(t3);
    }
  }
  becomeObserved() {
    this.observed || !this.active || (this.observed = true, this.attachDependencies(), this.state !== `clean` && this.queue());
  }
  becomeUnobserved() {
    this.observed && (this.observed = false, !this.scope && (b(this), this.detachComputedSources(), Be(this.settleScheduled), this.scheduled = false, this.pendingPriority = void 0));
  }
  attachDependencies() {
    for (let e3 of this.dependencies) g(this, e3.target, e3.key);
    this.refreshComputedSources();
  }
  refreshComputedSources() {
    if (this.detachComputedSources(), this.isRetained()) for (let e3 of this.dependencies) e3.computed && ((this.computedSources ??= /* @__PURE__ */ new Set()).add(e3.computed), (e3.computed.computedSinks ??= /* @__PURE__ */ new Set()).add(this));
  }
  detachComputedSources() {
    if (this.computedSources) {
      for (let e3 of this.computedSources) e3.computedSinks?.delete(this), e3.computedSinks?.size === 0 && (e3.computedSinks = void 0);
      this.computedSources = void 0;
    }
  }
  computedDependencies() {
    return this.dependencies;
  }
  isRetained() {
    return this.observed || !!this.scope;
  }
};
function un(e3) {
  let t2 = [{ node: e3, leave: false }], n2 = /* @__PURE__ */ new Set(), r2 = 0;
  for (; t2.length; ) {
    if (++r2 > tn) throw Error(`eXact reactive computation graph exceeded its settlement limit`);
    let e4 = t2.pop(), i2 = e4.node;
    if (e4.leave) {
      n2.delete(i2), i2.validateAndEvaluate();
      continue;
    }
    if (!i2.needsValidation()) continue;
    if (n2.has(i2)) throw Error(nn);
    n2.add(i2), t2.push({ node: i2, leave: true });
    let a2 = i2.computedDependencies();
    for (let e5 = a2.length - 1; e5 >= 0; e5--) {
      let n3 = a2[e5].computed;
      n3 && t2.push({ node: n3, leave: false });
    }
  }
}
function dn(e3) {
  return v(e3).map(({ target: e4, key: t2 }) => ({ target: e4, key: t2, version: D(e4, t2), computed: $t.get(e4) }));
}
function fn(e3, t2) {
  let n2 = [...t2];
  for (let t3 of e3) n2.some((e4) => e4.target === t3.target && e4.key === t3.key) || n2.push({ ...t3, version: D(t3.target, t3.key) });
  return n2;
}
function pn(e3) {
  if (P(e3)) {
    e3.get();
    return;
  }
  e3 && typeof e3 == `object` && zt.get(e3)?.get();
}
var mn = () => void 0, hn = /* @__PURE__ */ new WeakMap();
function gn(e3, t2, n2 = {}) {
  return vn(e3, t2, n2) ?? mn;
}
function _n(e3, t2 = {}) {
  return vn(e3, void 0, { ...t2, structural: true }) ?? mn;
}
function vn(e3, t2, n2 = {}) {
  let r2 = Sn(n2), i2 = new yn(e3, t2, n2, r2);
  r2 && gt(r2, i2);
  try {
    i2.run();
  } catch (e4) {
    throw i2.stop(), e4;
  }
  return i2.active ? n2.owned ? i2 : () => i2.stop() : void 0;
}
var yn = class {
  fn;
  scheduler;
  scope;
  fixed;
  active = true;
  scheduled = false;
  pendingPriority;
  deps = [];
  order;
  constructor(e3, t2, n2, r2, i2 = false) {
    this.fn = e3, this.scheduler = t2, this.scope = r2, this.fixed = i2, this.order = +!n2.structural, this.onSchedule = n2.onSchedule, this.onError = n2.onError, this.onRelease = n2.onRelease;
  }
  onSchedule;
  onError;
  onRelease;
  run() {
    if (this.active) {
      if (this.scope && !this.scope.active) {
        this.stop();
        return;
      }
      this.scheduled = false, this.pendingPriority = void 0;
      try {
        this.fixed ? j(this.scope, this.fn) : (j(this.scope, () => S(this, this.fn)), this.deps.length === 0 && this.stop());
      } catch (e3) {
        this.handleError(e3);
      }
    }
  }
  schedule() {
    if (!this.active) return;
    if (this.scope && !this.scope.active) {
      this.stop();
      return;
    }
    let e3 = wt(this.scope, Ue());
    if (this.scheduled) {
      this.pendingPriority !== void 0 && st(e3, this.pendingPriority) && (this.pendingPriority = e3, this.scheduler ? this.scheduler() : Re(this, e3));
      return;
    }
    this.scheduled = true, this.pendingPriority = e3;
    try {
      this.onSchedule && j(this.scope, this.onSchedule), this.scheduler ? this.scheduler() : Re(this);
    } catch (e4) {
      this.scheduled = false, this.pendingPriority = void 0, this.handleError(e4);
    }
  }
  stop() {
    this.active && (this.active = false, this.scheduled = false, this.pendingPriority = void 0, b(this), this.scope && _t(this.scope, this), this.onRelease?.());
  }
  handleError(e3) {
    let t2 = this.onError ?? this.scope?.onError;
    if (!t2) throw e3;
    t2(e3);
  }
};
function bn(e3, t2, n2 = {}) {
  let r2 = Sn(n2), i2 = new yn(t2, void 0, n2, r2, true);
  return _(i2, y(e3.target, e3.key)), r2 && gt(r2, i2), () => i2.stop();
}
function xn(e3, t2, n2, r2 = {}) {
  if (t2.length === 0) return mn;
  let i2 = Sn(r2), a2 = new yn(n2, void 0, r2, i2, true);
  for (let n3 of t2) _(a2, y(e3, n3));
  return i2 && gt(i2, a2), () => a2.stop();
}
function Sn(e3) {
  return Object.prototype.hasOwnProperty.call(e3, `scope`) ? e3.scope : St();
}
function Cn(e3) {
  if (P(e3)) return e3.get(), e3[At];
  if (e3 && typeof e3 == `object`) return zt.get(e3);
}
function wn(e3) {
  let t2 = Cn(e3), n2 = hn.get(e3);
  if (n2) return n2;
  if (!t2 && !jt(e3)) return;
  let r2 = F(e3);
  return n2 = { target: t2?.target ?? r2, key: t2?.key ?? M, get() {
    let n3 = t2 ? t2.get() : e3;
    return Tn(n3), n3;
  }, set(e4) {
    if (t2) {
      t2.set(e4);
      return;
    }
    throw TypeError(`Cannot replace a collection through its structural reference`);
  } }, hn.set(e3, n2), n2;
}
function Tn(e3) {
  m(F(e3), M);
}
function En(e3) {
  return `value` in e3 ? { ...e3, value: F(e3.value) } : e3;
}
function Dn(e3, t2) {
  return !e3 || `value` in e3 != `value` in t2 || e3.configurable !== t2.configurable || e3.enumerable !== t2.enumerable ? false : `value` in e3 && `value` in t2 ? e3.writable === t2.writable && !Xt(e3.value, t2.value) : e3.get === t2.get && e3.set === t2.set;
}
var On = new TextEncoder();
function kn(e3, t2) {
  let n2 = jn(e3);
  return Nn(`${t2.length}:${t2}${n2.length}:${n2}`);
}
function An(e3, t2) {
  let n2 = `${t2.length}:${t2}${e3.length}:`;
  for (let t3 of e3) n2 += `${t3.length}:${t3}`;
  return Nn(n2);
}
function jn(e3) {
  return Mn(e3, /* @__PURE__ */ new WeakSet(), 0);
}
function Mn(e3, t2, n2) {
  if (n2 > 100) throw TypeError(`Cannot hash JSON deeper than 100 levels`);
  if (e3 === null) return `null`;
  if (typeof e3 == `boolean`) return e3 ? `true` : `false`;
  if (typeof e3 == `string`) return JSON.stringify(e3);
  if (typeof e3 == `number`) {
    if (!Number.isFinite(e3)) throw TypeError(`Cannot hash non-finite JSON numbers`);
    return Object.is(e3, -0) ? `0` : JSON.stringify(e3);
  }
  if (!e3 || typeof e3 != `object`) throw TypeError(`Cannot hash non-JSON ${typeof e3}`);
  if (t2.has(e3)) throw TypeError(`Cannot hash cyclic JSON`);
  t2.add(e3);
  try {
    if (Array.isArray(e3)) {
      if (Object.getPrototypeOf(e3) !== Array.prototype) throw TypeError(`Cannot hash non-standard arrays`);
      let r3 = Object.keys(e3);
      if (r3.length !== e3.length || r3.some((e4, t3) => e4 !== String(t3))) throw TypeError(`Cannot hash sparse arrays or arrays with enumerable properties`);
      if (Object.getOwnPropertySymbols(e3).some((t3) => Object.prototype.propertyIsEnumerable.call(e3, t3))) throw TypeError(`Cannot hash arrays with enumerable symbols`);
      let i3 = [];
      for (let r4 = 0; r4 < e3.length; r4++) {
        let a3 = Object.getOwnPropertyDescriptor(e3, String(r4));
        if (!a3 || !(`value` in a3)) throw TypeError(`Cannot hash array accessors`);
        i3.push(Mn(a3.value, t2, n2 + 1));
      }
      return `[${i3.join(`,`)}]`;
    }
    let r2 = Object.getPrototypeOf(e3);
    if (r2 !== Object.prototype && r2 !== null) throw TypeError(`Cannot hash non-plain JSON objects`);
    if (Object.getOwnPropertySymbols(e3).some((t3) => Object.prototype.propertyIsEnumerable.call(e3, t3))) throw TypeError(`Cannot hash objects with enumerable symbols`);
    let i2 = Object.getOwnPropertyDescriptors(e3), a2 = Object.keys(i2).filter((e4) => i2[e4].enumerable).sort(), o2 = [];
    for (let e4 of a2) {
      let r3 = i2[e4];
      if (!(`value` in r3)) throw TypeError(`Cannot hash object accessors`);
      o2.push(`${JSON.stringify(e4)}:${Mn(r3.value, t2, n2 + 1)}`);
    }
    return `{${o2.join(`,`)}}`;
  } finally {
    t2.delete(e3);
  }
}
function Nn(e3) {
  let t2 = On.encode(e3), n2 = 2166136261, r2 = 2654435769, i2 = 2246822507, a2 = 3266489909;
  for (let e4 of t2) n2 = Math.imul(n2 ^ e4, 16777619), r2 = Math.imul(r2 ^ e4, 668265261), i2 = Math.imul(i2 ^ e4, 374761393), a2 = Math.imul(a2 ^ e4, 2246822519);
  return n2 = Pn(n2 ^ t2.length), r2 = Pn(r2 ^ n2), i2 = Pn(i2 ^ r2), a2 = Pn(a2 ^ i2), [n2, r2, i2, a2].map((e4) => (e4 >>> 0).toString(16).padStart(8, `0`)).join(``);
}
function Pn(e3) {
  return e3 ^= e3 >>> 16, e3 = Math.imul(e3, 2146121005), e3 ^= e3 >>> 15, e3 = Math.imul(e3, 2221713035), e3 ^ e3 >>> 16;
}
var Fn = /^[0-9a-f]{32}$/;
function In(e3, t2) {
  return Ln(e3, t2, /* @__PURE__ */ new WeakSet(), 0);
}
function Ln(e3, t2, n2, r2) {
  if (!e3 || typeof e3 != `object`) return e3;
  if (r2 > 100 || n2.has(e3)) throw TypeError(`Cannot decode cyclic or excessively deep reactive protocol data`);
  n2.add(e3);
  try {
    if (Array.isArray(e3)) return e3.map((e4) => Ln(e4, t2, n2, r2 + 1));
    if (e3.$exact === `map`) {
      let i3 = Rn(e3);
      return new Map(i3.entries.map(([e4, i4]) => [e4, Ln(i4, t2, n2, r2 + 1)]));
    }
    if (e3.$exact === `set`) {
      let i3 = zn(e3);
      return new Set(i3.values.map((e4) => Ln(e4, t2, n2, r2 + 1)));
    }
    if (e3.$exact === `keyed-collection`) {
      let i3 = Bn(e3), a2 = i3.items.map((e4) => Ln(e4, t2, n2, r2 + 1));
      return t2(a2, i3), a2;
    }
    let i2 = {};
    for (let a2 of Object.keys(e3)) Object.defineProperty(i2, a2, { configurable: true, enumerable: true, writable: true, value: Ln(e3[a2], t2, n2, r2 + 1) });
    return i2;
  } finally {
    n2.delete(e3);
  }
}
function Rn(e3) {
  if (!Hn(e3, [`$exact`, `version`, `entries`]) || e3.version !== 1 || !Array.isArray(e3.entries) || !e3.entries.every((e4) => Array.isArray(e4) && e4.length === 2 && Vn(e4[0]))) throw TypeError(`Malformed eXact Map envelope`);
  return e3;
}
function zn(e3) {
  if (!Hn(e3, [`$exact`, `version`, `values`]) || e3.version !== 1 || !Array.isArray(e3.values)) throw TypeError(`Malformed eXact Set envelope`);
  return e3;
}
function Bn(e3) {
  let t2 = /* @__PURE__ */ new Set([`$exact`, `version`, `keys`, `keyHash`, `itemHashes`, `itemsHash`, `items`]);
  if (Object.keys(e3).some((e4) => !t2.has(e4)) || e3.version !== 1 || !Array.isArray(e3.keys) || !e3.keys.every((e4) => typeof e4 == `string`) || new Set(e3.keys).size !== e3.keys.length || !Array.isArray(e3.itemHashes) || !e3.itemHashes.every((e4) => typeof e4 == `string` && Fn.test(e4)) || !Array.isArray(e3.items) || e3.keys.length !== e3.itemHashes.length || e3.keys.length !== e3.items.length || typeof e3.keyHash != `string` || !Fn.test(e3.keyHash) || typeof e3.itemsHash != `string` || !Fn.test(e3.itemsHash)) throw TypeError(`Malformed eXact keyed-collection envelope`);
  return e3;
}
function Vn(e3) {
  return e3 === null || typeof e3 == `boolean` || typeof e3 == `string` || typeof e3 == `number` && Number.isFinite(e3);
}
function Hn(e3, t2) {
  let n2 = new Set(t2);
  return Object.keys(e3).every((e4) => n2.has(e4));
}
var Un = /* @__PURE__ */ new WeakMap(), Wn = /* @__PURE__ */ new WeakMap();
function Gn(e3, t2) {
  return Qn(e3, t2);
}
function Kn(e3) {
  ar(e3);
}
function qn(e3, t2) {
  let n2 = Un.get(e3);
  if (!n2) return t2 ? Qn(e3, t2) : void 0;
  if (!n2.structureDirty && n2.dirtyKeys.size === 0) return n2;
  if (t2) {
    if (n2.structureDirty || $n(e3, n2.keys, t2)) return Qn(e3, t2);
    try {
      let t3 = new Set(n2.dirtyKeys);
      for (let t4 = 0; t4 < e3.length; t4++) {
        let r2 = n2.keys[t4];
        n2.dirtyKeys.has(r2) && (n2.itemHashes[t4] = er(r2, e3[t4]));
      }
      return n2.itemsHash = An(n2.itemHashes, `exact:keyed-items:v1`), n2.dirtyKeys.clear(), nr(n2, e3, t3), n2;
    } catch {
      ar(e3);
      return;
    }
  }
}
function Jn(e3) {
  let t2 = Un.get(e3);
  t2 && (t2.structureDirty = true);
  for (let t3 of Wn.get(e3) ?? []) cr(t3)?.dirtyKeys.add(t3.key);
}
function Yn(e3, t2, n2 = true) {
  ar(e3);
  let r2 = { keys: [...t2.keys], keyHash: t2.keyHash, itemHashes: [...t2.itemHashes], itemsHash: t2.itemsHash, structureDirty: false, dirtyKeys: /* @__PURE__ */ new Set(), owners: [] };
  Un.set(e3, r2), n2 && tr(r2, e3);
}
function Xn(e3, t2, n2) {
  let r2 = Un.get(e3);
  if (!r2) {
    Yn(e3, t2);
    return;
  }
  let i2 = /* @__PURE__ */ new Map();
  for (let e4 = 0; e4 < r2.keys.length; e4++) {
    let t3 = r2.owners[e4];
    t3 && i2.set(r2.keys[e4], t3);
  }
  let a2 = /* @__PURE__ */ new Set(), o2 = [];
  for (let r3 = 0; r3 < t2.keys.length; r3++) {
    let s2 = t2.keys[r3], c2 = i2.get(s2);
    if (c2 && !n2.has(s2)) {
      a2.add(c2), o2.push(c2);
      continue;
    }
    c2 && sr(c2), o2.push(rr(e3, s2, e3[r3]));
  }
  for (let e4 of r2.owners) !a2.has(e4) && !n2.has(e4.key) && sr(e4);
  r2.owners = o2, r2.keys = [...t2.keys], r2.keyHash = t2.keyHash, r2.itemHashes = [...t2.itemHashes], r2.itemsHash = t2.itemsHash, r2.structureDirty = false, r2.dirtyKeys.clear();
}
function Zn(e3) {
  return In(e3, (e4, t2) => Yn(e4, t2, false));
}
function Qn(e3, t2) {
  try {
    let n2 = [], r2 = [], i2 = /* @__PURE__ */ new Set();
    for (let a3 of e3) {
      let e4 = String(t2(a3));
      if (i2.has(e4)) throw Error(`Duplicate key "${e4}"`);
      i2.add(e4), n2.push(e4), r2.push(er(e4, a3));
    }
    ar(e3);
    let a2 = { keys: n2, keyHash: An(n2, `exact:keyed-keys:v1`), itemHashes: r2, itemsHash: An(r2, `exact:keyed-items:v1`), structureDirty: false, dirtyKeys: /* @__PURE__ */ new Set(), owners: [] };
    return Un.set(e3, a2), tr(a2, e3), a2;
  } catch {
    ar(e3);
    return;
  }
}
function $n(e3, t2, n2) {
  if (e3.length !== t2.length) return true;
  for (let r2 = 0; r2 < e3.length; r2++) if (String(n2(e3[r2])) !== t2[r2]) return true;
  return false;
}
function er(e3, t2) {
  return kn([e3, t2], `exact:keyed-item:v1`);
}
function tr(e3, t2) {
  or(e3);
  for (let n2 = 0; n2 < t2.length; n2++) {
    let r2 = rr(t2, e3.keys[n2], t2[n2]);
    e3.owners.push(r2);
  }
}
function nr(e3, t2, n2) {
  for (let r2 = 0; r2 < e3.keys.length; r2++) {
    if (!n2.has(e3.keys[r2])) continue;
    let i2 = e3.owners[r2];
    i2 && sr(i2);
    let a2 = rr(t2, e3.keys[r2], t2[r2]);
    e3.owners[r2] = a2;
  }
}
function rr(e3, t2, n2) {
  let r2 = [];
  ir(n2, r2, /* @__PURE__ */ new WeakSet(), 0);
  let i2 = { collection: e3, key: t2, nodes: r2 };
  for (let e4 of r2) {
    let t3 = Wn.get(e4);
    t3 || Wn.set(e4, t3 = /* @__PURE__ */ new Set()), t3.add(i2);
  }
  return i2;
}
function ir(e3, t2, n2, r2) {
  if (!(!e3 || typeof e3 != `object` || n2.has(e3) || r2 > 100)) {
    if (n2.add(e3), t2.push(e3), Array.isArray(e3)) for (let i2 of e3) ir(i2, t2, n2, r2 + 1);
    else for (let i2 of Object.keys(e3)) {
      let a2 = Object.getOwnPropertyDescriptor(e3, i2);
      a2 && `value` in a2 && ir(a2.value, t2, n2, r2 + 1);
    }
  }
}
function ar(e3) {
  let t2 = Un.get(e3);
  t2 && or(t2), Un.delete(e3);
}
function or(e3) {
  for (let t2 of e3.owners) sr(t2);
  e3.owners = [];
}
function sr(e3) {
  for (let t2 of e3.nodes) {
    let n2 = Wn.get(t2);
    n2?.delete(e3), n2?.size === 0 && Wn.delete(t2);
  }
}
function cr(e3) {
  return Un.get(e3.collection);
}
function lr(e3, t2) {
  if (Array.isArray(e3) && t2 === `length`) return ur(e3);
  let n2 = Reflect.getOwnPropertyDescriptor(e3, t2), r2 = Array.isArray(e3) ? e3 : void 0, i2 = r2 ? dr(t2) : void 0, a2 = r2?.length ?? 0, o2 = r2 ? D(r2, N) : 0;
  return (s2) => {
    let c2 = !r2 || s2.allows(r2, N, o2);
    if (!(r2 && i2 !== void 0 && i2 >= r2.length && !c2) && (n2 ? Reflect.defineProperty(e3, t2, n2) : Reflect.deleteProperty(e3, t2), r2 && i2 !== void 0 && i2 >= a2 && c2)) {
      let e4 = a2;
      for (let t3 of Object.getOwnPropertyNames(r2)) {
        let n3 = dr(t3);
        n3 !== void 0 && (e4 = Math.max(e4, n3 + 1));
      }
      r2.length > e4 && (r2.length = e4, s2.mark(r2, `length`));
    }
  };
}
function ur(e3) {
  let t2 = e3.length, n2 = D(e3, N), r2 = Object.getOwnPropertyNames(e3).flatMap((t3) => {
    let n3 = dr(t3);
    return n3 === void 0 ? [] : [{ key: t3, index: n3, descriptor: Reflect.getOwnPropertyDescriptor(e3, t3), version: D(e3, t3) }];
  });
  return (i2) => {
    let a2 = i2.allows(e3, N, n2), o2 = e3.length;
    a2 && o2 < t2 && (e3.length = t2);
    for (let t3 of r2) {
      if (!a2 && t3.index >= o2 || !i2.allows(e3, t3.key, t3.version)) continue;
      let n3 = Reflect.getOwnPropertyDescriptor(e3, t3.key);
      n3 && Object.is(n3.value, t3.descriptor.value) || (Reflect.defineProperty(e3, t3.key, t3.descriptor), i2.mark(e3, t3.key));
    }
    if (a2 && e3.length > t2) {
      let n3 = t2;
      for (let t3 of Object.getOwnPropertyNames(e3)) {
        let e4 = dr(t3);
        e4 !== void 0 && (n3 = Math.max(n3, e4 + 1));
      }
      e3.length = n3;
    }
    e3.length !== o2 && i2.mark(e3, `length`);
  };
}
function dr(e3) {
  if (typeof e3 == `symbol` || e3 === ``) return;
  let t2 = Number(e3);
  return Number.isInteger(t2) && t2 >= 0 && t2 < 4294967295 && String(t2) === String(e3) ? t2 : void 0;
}
function fr(e3, t2, n2, r2, i2, a2) {
  if (a2.readonly) throw a2.onReadonlyWrite?.(t2), TypeError(`Cannot call ${t2} on a readonly array`);
  if ((t2 === `push` || t2 === `pop`) && n2 === Array.prototype[t2]) return gr(e3, t2, n2, r2, i2, a2);
  let o2 = e3.slice(), s2;
  try {
    s2 = n2.apply(e3, r2.map((e4) => F(e4)));
  } finally {
    mr(e3, o2), se(() => {
      let n3 = Math.max(o2.length, e3.length), r3 = o2.length !== e3.length;
      for (let t3 = 0; t3 < n3; t3++) Reflect.has(o2, t3) === Reflect.has(e3, t3) && Object.is(F(o2[t3]), F(e3[t3])) || (r3 = true, T(e3, String(t3)));
      o2.length !== e3.length && T(e3, `length`), r3 && (Jn(e3), T(e3, M), pr(a2, t2));
    });
  }
  return s2 === e3 ? i2 : s2;
}
function pr(e3, t2) {
  try {
    e3.onMutation?.(void 0, t2);
  } catch {
  }
}
function mr(e3, t2) {
  if (!le()) return;
  let n2 = e3.slice(), r2 = D(e3, N), i2 = Array.from({ length: Math.max(t2.length, n2.length) }, (t3, n3) => D(e3, String(n3))), a2 = 0;
  for (; a2 < t2.length && a2 < n2.length && hr(t2, n2, a2, a2); ) a2++;
  let o2 = 0;
  for (; o2 < t2.length - a2 && o2 < n2.length - a2 && hr(t2, n2, t2.length - o2 - 1, n2.length - o2 - 1); ) o2++;
  let s2 = t2.length - o2, c2 = n2.length - o2, l2 = t2.slice(a2, s2), u2 = n2.slice(a2, c2);
  E((o3) => {
    let d2 = o3.allows(e3, N, r2), f2 = d2;
    for (let t3 = 0; t3 < u2.length; t3++) if (!o3.allows(e3, String(a2 + t3), i2[a2 + t3]) || !hr(n2, e3, a2 + t3, a2 + t3)) {
      f2 = false;
      break;
    }
    if (f2) {
      let n3 = e3.length;
      Array.prototype.splice.call(e3, a2, u2.length, ...l2.map((e4) => F(e4)));
      for (let n4 = 0; n4 < l2.length; n4++) {
        let r3 = a2 + n4, i3 = a2 + n4, o4 = Reflect.getOwnPropertyDescriptor(t2, String(r3));
        o4 ? Reflect.defineProperty(e3, String(i3), o4) : Reflect.deleteProperty(e3, String(i3));
      }
      for (let t3 = a2; t3 < Math.max(n3, e3.length); t3++) o3.mark(e3, String(t3));
      n3 !== e3.length && o3.mark(e3, `length`);
      return;
    }
    let p2 = Math.max(s2, c2);
    for (let r3 = a2; r3 < p2; r3++) !d2 && r3 >= e3.length || !o3.allows(e3, String(r3), i2[r3]) || !hr(n2, e3, r3, r3) || (Reflect.has(t2, r3) ? e3[r3] = t2[r3] : Reflect.deleteProperty(e3, r3), o3.mark(e3, String(r3)));
  });
}
function hr(e3, t2, n2, r2) {
  let i2 = Reflect.has(e3, n2);
  return i2 === Reflect.has(t2, r2) && (!i2 || Object.is(F(e3[n2]), F(t2[r2])));
}
function gr(e3, t2, n2, r2, i2, a2) {
  let o2 = e3.length, s2 = t2 === `pop` && o2 > 0 ? Reflect.getOwnPropertyDescriptor(e3, String(o2 - 1)) : void 0, c2 = le(), l2 = c2 ? D(e3, N) : 0, u2 = n2.apply(e3, r2.map((e4) => F(e4))), d2 = e3.length;
  if (d2 !== o2) {
    if (c2) {
      if (t2 === `push`) for (let t3 = o2; t3 < d2; t3++) {
        let n3 = t3;
        E((t4) => {
          t4.allows(e3, N, l2) ? (Array.prototype.splice.call(e3, n3, 1), t4.mark(e3, `length`)) : Reflect.deleteProperty(e3, n3);
        }, e3, String(n3));
      }
      else E((t3) => {
        if (t3.allows(e3, N, l2)) Array.prototype.splice.call(e3, o2 - 1, 0, void 0), t3.mark(e3, `length`);
        else if (o2 > e3.length) return;
        s2 ? Reflect.defineProperty(e3, String(o2 - 1), s2) : Reflect.deleteProperty(e3, String(o2 - 1));
      }, e3, String(o2 - 1));
    }
    se(() => {
      if (Jn(e3), t2 === `push`) for (let t3 = o2; t3 < d2; t3++) T(e3, String(t3));
      else T(e3, String(o2 - 1));
      T(e3, `length`), T(e3, M);
    }), pr(a2, t2);
  }
  return u2 === e3 ? i2 : u2;
}
function _r(e3, t2) {
  le() && E(lr(e3, t2), e3, t2);
}
function vr(e3) {
  le() && E(yr(e3));
}
function yr(e3) {
  let t2 = /* @__PURE__ */ new Map(), n2 = /* @__PURE__ */ new Map(), r2 = e3.length, i2 = D(e3, N);
  for (let r3 of Reflect.ownKeys(e3)) {
    let i3 = Reflect.getOwnPropertyDescriptor(e3, r3);
    i3 && t2.set(r3, i3), n2.set(r3, D(e3, r3));
  }
  return (a2) => {
    let o2 = a2.allows(e3, N, i2);
    for (let n3 of Reflect.ownKeys(e3)) n3 === `length` || t2.has(n3) || !a2.allows(e3, n3) || (Reflect.deleteProperty(e3, n3), a2.mark(e3, n3));
    for (let [r3, i3] of t2) {
      if (r3 === `length` || !a2.allows(e3, r3, n2.get(r3))) continue;
      let t3 = dr(r3);
      !o2 && t3 !== void 0 && t3 >= e3.length || (Reflect.defineProperty(e3, r3, i3), a2.mark(e3, r3));
    }
    if (o2) {
      let t3 = r2;
      for (let n3 of Object.getOwnPropertyNames(e3)) {
        let e4 = dr(n3);
        e4 !== void 0 && (t3 = Math.max(t3, e4 + 1));
      }
      e3.length !== t3 && (e3.length = t3, a2.mark(e3, `length`));
    }
  };
}
var br = { get(e3, t2, n2) {
  if (t2 === Dt) return true;
  if (t2 === kt) return e3;
  let { collectionMember: r2, options: i2, proxy: a2 } = this.record;
  if (Or(a2), e3 instanceof Map || e3 instanceof Set) {
    if (!r2) throw TypeError(`Compiled object/array state received a Map or Set value`);
    return r2(e3, t2, a2, i2, (t3, n3) => !t3 || typeof t3 != `object` || !Qt(F(t3)) ? t3 : wr(F(t3), i2, n3 === void 0 ? void 0 : Cr(e3, n3, i2, r2), r2));
  }
  let o2 = Reflect.get(e3, t2, n2);
  if (o2 && typeof o2 == `object` && Sr(e3, t2)) return o2;
  if (Array.isArray(e3) && Ht.has(t2) && typeof o2 == `function`) return (...r3) => fr(e3, String(t2), o2, r3, n2, i2);
  if (i2.passthroughKeys?.includes(t2)) return m(e3, t2), o2;
  if (P(o2)) {
    m(e3, t2);
    let n3 = F(o2.get());
    return Qt(n3) ? wr(n3, i2, Cr(e3, t2, i2, r2), r2) : n3;
  }
  if (o2 && typeof o2 == `object` && Qt(F(o2))) {
    let a3 = F(o2);
    return a3 === e3 ? (m(e3, t2), n2) : wr(a3, i2, Cr(e3, t2, i2, r2), r2);
  }
  return m(e3, t2), o2;
}, set(e3, t2, n2, r2) {
  let { options: i2 } = this.record;
  if (i2.readonly) return i2.onReadonlyWrite?.(t2), false;
  let a2 = Array.isArray(e3) ? e3.length : void 0, o2 = Array.isArray(e3) && t2 === `length` && typeof n2 == `number` && n2 < e3.length ? Array.from({ length: e3.length - n2 }, (e4, t3) => n2 + t3).filter((t3) => Reflect.has(e3, t3)) : [], s2 = Reflect.get(e3, t2, r2), c2 = F(n2), l2 = Object.prototype.hasOwnProperty.call(e3, t2), u2 = Xt(s2, c2), d2 = Reflect.getOwnPropertyDescriptor(e3, t2);
  if (!u2 && d2 && `value` in d2) return Array.isArray(e3) && t2 === `length` && T(e3, N), true;
  let f2 = le() ? lr(e3, t2) : void 0;
  this.record.forwardingSet = true;
  let p2;
  try {
    p2 = Reflect.set(e3, t2, c2, r2);
  } finally {
    this.record.forwardingSet = false;
  }
  if (p2 && f2 && (!l2 || !Object.is(s2, Reflect.get(e3, t2, r2))) && E(f2, Array.isArray(e3) && t2 === `length` ? void 0 : e3, t2), p2 && u2) {
    Array.isArray(e3) && t2 === `length` && T(e3, N), Jn(e3), T(e3, t2);
    for (let t3 of o2) T(e3, String(t3));
    a2 !== void 0 && Array.isArray(e3) && e3.length !== a2 && t2 !== `length` && T(e3, `length`), (!l2 || Wt(e3, t2)) && T(e3, M), Ar(i2, t2, `set`);
  }
  return p2;
}, defineProperty(e3, t2, n2) {
  let { options: r2 } = this.record;
  if (this.record.forwardingSet) return Reflect.defineProperty(e3, t2, n2);
  if (r2.readonly) return r2.onReadonlyWrite?.(t2), false;
  let i2 = Reflect.getOwnPropertyDescriptor(e3, t2);
  if (Dn(i2, n2)) return Array.isArray(e3) && t2 === `length` && `value` in n2 && T(e3, N), true;
  let a2 = le() ? lr(e3, t2) : void 0, o2 = Array.isArray(e3) ? e3.length : void 0, s2 = Array.isArray(e3) && t2 === `length` ? Object.keys(e3) : void 0;
  if (!Reflect.defineProperty(e3, t2, En(n2))) return false;
  if (Array.isArray(e3) && t2 === `length`) {
    T(e3, N);
    for (let t3 of s2 ?? []) Reflect.has(e3, t3) || T(e3, t3);
  }
  return a2 && E(a2, Array.isArray(e3) && t2 === `length` ? void 0 : e3, t2), Jn(e3), T(e3, t2), (!i2 || Wt(e3, t2)) && T(e3, M), o2 !== void 0 && e3.length !== o2 && t2 !== `length` && T(e3, `length`), Ar(r2, t2, `define`), true;
}, deleteProperty(e3, t2) {
  let { options: n2 } = this.record;
  if (n2.readonly) return n2.onReadonlyWrite?.(t2), false;
  let r2 = Object.prototype.hasOwnProperty.call(e3, t2), i2 = r2 && le() ? Reflect.getOwnPropertyDescriptor(e3, t2) : void 0, a2 = Reflect.deleteProperty(e3, t2);
  return a2 && r2 && (i2 && E(() => {
    Reflect.defineProperty(e3, t2, i2);
  }, e3, t2), Jn(e3), T(e3, t2), T(e3, M), Ar(n2, t2, `delete`)), a2;
}, ownKeys(e3) {
  return Or(this.record.proxy), m(e3, M), Reflect.ownKeys(e3);
}, has(e3, t2) {
  return m(e3, t2), Reflect.has(e3, t2);
} };
function xr(e3, t2, n2, r2) {
  let i2 = jt(e3) ? e3[kt] : e3, a2 = Tr(i2, t2, n2);
  if (a2) return n2 && Dr(a2, n2), a2;
  let o2 = { options: t2, collectionMember: r2, forwardingSet: false }, s2 = Object.create(br);
  s2.record = o2;
  let c2 = new Proxy(i2, s2);
  return o2.proxy = c2, Er(i2, t2, n2, c2), n2 && (Bt.add(i2), Dr(c2, n2)), c2;
}
function Sr(e3, t2) {
  let n2 = Reflect.getOwnPropertyDescriptor(e3, t2);
  return !!n2 && `value` in n2 && !n2.configurable && !n2.writable;
}
function Cr(e3, t2, n2, r2) {
  let i2 = kr(n2), a2 = Rt.get(e3);
  a2 || Rt.set(e3, a2 = /* @__PURE__ */ new Map());
  let o2 = a2.get(t2);
  o2 || a2.set(t2, o2 = /* @__PURE__ */ new WeakMap());
  let s2 = o2.get(i2);
  if (s2) return s2;
  let c2 = { target: e3, key: t2, get() {
    m(e3, t2);
    let i3 = Reflect.get(e3, t2);
    if (P(i3)) {
      let e4 = i3.get();
      return e4 && typeof e4 == `object` ? wr(F(e4), n2, c2, r2) : e4;
    }
    return i3 && typeof i3 == `object` ? wr(F(i3), n2, c2, r2) : i3;
  }, set(n3) {
    let r3 = Reflect.get(e3, t2), i3 = F(n3);
    Xt(r3, i3) && (_r(e3, t2), Reflect.set(e3, t2, i3), Jn(e3), T(e3, t2), Wt(e3, t2) && T(e3, M));
  } };
  return o2.set(i2, c2), c2;
}
function wr(e3, t2, n2, r2) {
  if (!n2) return xr(e3, t2, void 0, r2);
  if (n2.cachedRaw === e3 && n2.cachedProxy) return Dr(n2.cachedProxy, n2), n2.cachedProxy;
  let i2 = xr(e3, t2, n2, r2);
  return n2.cachedRaw = e3, n2.cachedProxy = i2, i2;
}
function Tr(e3, t2, n2) {
  let r2 = kr(t2);
  if (!n2) return It.get(e3)?.get(r2);
  let i2 = Lt.get(e3)?.get(r2), a2 = i2?.get(n2);
  if (a2) return a2;
  if (i2) {
    for (let [t3, r3] of i2) if (F(Reflect.get(t3.target, t3.key)) !== e3) return i2.delete(t3), i2.set(n2, r3), zt.set(r3, n2), r3;
  }
}
function Er(e3, t2, n2, r2) {
  let i2 = kr(t2);
  if (n2) {
    let t3 = Lt.get(e3);
    t3 || Lt.set(e3, t3 = /* @__PURE__ */ new WeakMap());
    let a3 = t3.get(i2);
    a3 || t3.set(i2, a3 = /* @__PURE__ */ new Map()), a3.set(n2, r2);
    return;
  }
  let a2 = It.get(e3);
  a2 || It.set(e3, a2 = /* @__PURE__ */ new WeakMap()), a2.set(i2, r2);
}
function Dr(e3, t2) {
  zt.set(e3, t2);
}
function Or(e3) {
  let t2 = zt.get(e3);
  t2 && m(t2.target, t2.key);
}
function kr(e3) {
  return `__exactCollectionCacheMode` in e3 ? e3 : !e3.readonly && !e3.onReadonlyWrite && !e3.onMutation && !e3.passthroughKeys?.length ? Pt : e3.readonly && !e3.onReadonlyWrite && !e3.onMutation && !e3.passthroughKeys?.length ? Ft : e3;
}
function Ar(e3, t2, n2) {
  try {
    e3.onMutation?.(t2, n2);
  } catch {
  }
}
function jr(e3, t2 = Pt, n2) {
  let r2 = F(e3);
  if (!Qt(r2)) return e3;
  if (r2 instanceof Map || r2 instanceof Set) throw TypeError(`Compiled object/array state received a Map or Set value`);
  return xr(r2, t2, n2);
}
var Mr = /* @__PURE__ */ new WeakMap();
function Nr(e3) {
  let t2 = e3, n2 = Mr.get(t2);
  if (n2) return n2;
  let r2 = /* @__PURE__ */ new Map(), i2 = [];
  for (let t3 of e3) r2.has(t3) || (r2.set(t3, r2.size), i2.push(t3));
  let a2 = { indexes: r2, keys: i2 };
  return Mr.set(t2, a2), a2;
}
function Pr(e3, t2) {
  return e3.layout.indexes.get(t2) ?? e3.dynamicIndexes?.get(t2);
}
function Fr(e3, t2) {
  let n2 = Pr(e3, t2);
  if (n2 !== void 0) return n2;
  let r2 = e3.dynamicIndexes ??= /* @__PURE__ */ new Map(), i2 = e3.dynamicKeys ??= [], a2 = e3.layout.keys.length + r2.size;
  return r2.set(t2, a2), i2.push(t2), e3.initialized.push(false), a2;
}
function Ir(e3, t2) {
  return t2 < e3.layout.keys.length ? e3.layout.keys[t2] : e3.dynamicKeys[t2 - e3.layout.keys.length];
}
var Lr = /* @__PURE__ */ Symbol.for(`exact.reactive.property-operand`), Rr = /* @__PURE__ */ new WeakMap(), zr = { get(e3, t2, n2) {
  if (t2 === Dt) return true;
  if (t2 === kt) return e3;
  let { record: r2 } = this, i2 = Pr(r2, t2);
  return i2 === void 0 ? Reflect.get(e3, t2, n2) : Xr(r2, t2, i2, `facade`);
}, set(e3, t2, n2) {
  let { record: r2 } = this;
  return r2.options.readonly ? (r2.options.onReadonlyWrite?.(t2), false) : qr(r2, Fr(r2, t2), n2);
}, deleteProperty(e3, t2) {
  let { record: n2 } = this, r2 = Pr(n2, t2);
  return r2 === void 0 ? Reflect.deleteProperty(e3, t2) : Qr(n2, r2);
}, has(e3, t2) {
  let { record: n2 } = this, r2 = Pr(n2, t2);
  return r2 !== void 0 && n2.initialized[r2] === true || Reflect.has(e3, t2);
} };
function Br(e3, t2, n2, r2, i2 = false) {
  let a2 = Nr(e3), o2 = {}, s2 = { layout: a2, initialized: Array(a2.keys.length).fill(false), target: o2, options: t2, wrap: n2, preserveReactiveValues: i2 };
  r2 && Jr(s2, r2);
  let c2 = Object.create(zr);
  c2.record = s2;
  let l2 = new Proxy(o2, c2);
  return Rr.set(l2, s2), l2;
}
function I(e3, t2) {
  let n2 = Kr(e3, t2, `read`);
  return Xr(n2, Ir(n2, t2), t2, `direct`);
}
function Vr(e3, t2) {
  let n2 = Kr(e3, t2, `read source`), r2 = n2.values ??= [], i2 = r2[t2];
  if (i2) return i2;
  let a2 = Zr(n2, t2), o2 = { [Ot]: true, target: a2.target, key: a2.key, get: a2.get, set: Mt };
  o2[At] = o2;
  let s2 = o2;
  return r2[t2] = s2, s2;
}
function Hr(e3, t2) {
  let n2 = Kr(e3, t2, `peek`);
  return Xr(n2, Ir(n2, t2), t2, `peek`);
}
function Ur(e3, t2, n2) {
  qr(Kr(e3, t2, `write`), t2, n2);
}
function Wr(e3, t2, n2) {
  let r2 = Kr(e3, t2, `write`), i2 = D(r2.target, t2);
  return qr(r2, t2, n2), D(r2.target, t2) !== i2;
}
function Gr(e3, t2) {
  let n2 = Kr(e3, t2, `delete`), r2 = D(n2.target, t2);
  return Qr(n2, t2), D(n2.target, t2) !== r2;
}
function Kr(e3, t2, n2) {
  let r2 = Rr.get(e3);
  if (!r2 || !Number.isSafeInteger(t2) || t2 < 0 || t2 >= r2.initialized.length) throw TypeError(`Compiled reactive ${n2} referenced an invalid indexed slot`);
  return r2;
}
function qr(e3, t2, n2) {
  let r2 = Ir(e3, t2), i2 = e3.target[r2], a2 = Yr(e3, r2, n2), o2 = !e3.options.passthroughKeys?.includes(r2) && !(Array.isArray(a2) && a2[0] === Lr) && !P(a2) && a2 && typeof a2 == `object` && Qt(a2) ? e3.wrap(a2, e3.options, Zr(e3, t2)) : a2, s2 = e3.initialized[t2] === true;
  if (s2 && !Xt(i2, o2)) return true;
  le() && E(() => {
    s2 && (e3.target[r2] = i2), s2 || (e3.initialized[t2] = false, Reflect.deleteProperty(e3.target, r2));
  }, e3.target, t2), Reflect.defineProperty(e3.target, r2, { configurable: true, enumerable: true, value: o2, writable: true }), e3.initialized[t2] = true, T(e3.target, t2);
  try {
    e3.options.onMutation?.(r2, `set`);
  } catch {
  }
  return true;
}
function Jr(e3, t2) {
  for (let n2 of Reflect.ownKeys(t2)) {
    let r2 = Fr(e3, n2), i2 = Yr(e3, n2, Reflect.get(t2, n2));
    e3.target[n2] = !e3.options.passthroughKeys?.includes(n2) && !(Array.isArray(i2) && i2[0] === Lr) && !P(i2) && i2 && typeof i2 == `object` && Qt(i2) ? e3.wrap(i2, e3.options, Zr(e3, r2)) : i2, e3.initialized[r2] = true;
  }
}
function Yr(e3, t2, n2) {
  return e3.options.passthroughKeys?.includes(t2) || e3.preserveReactiveValues && P(n2) ? n2 : F(n2);
}
function Xr(e3, t2, n2, r2) {
  let i2 = e3.target[t2];
  if (e3.options.passthroughKeys?.includes(t2)) return r2 !== `peek` && m(e3.target, n2), i2;
  let a2 = e3.preserveReactiveValues && Array.isArray(i2) && i2[0] === Lr ? i2 : void 0, o2 = F(a2 ? Reflect.get(a2[1], a2[2]) : e3.preserveReactiveValues && P(i2) ? i2.get() : i2);
  return o2 && typeof o2 == `object` && Qt(o2) ? (r2 === `direct` && m(e3.target, n2), e3.wrap(o2, e3.options, Zr(e3, n2))) : (r2 !== `peek` && m(e3.target, n2), o2);
}
function Zr(e3, t2) {
  let n2 = e3.sources ??= [], r2 = n2[t2];
  if (r2) return r2;
  let i2 = { target: e3.target, key: t2, get() {
    return Xr(e3, Ir(e3, t2), t2, `direct`);
  }, set(n3) {
    qr(e3, t2, n3);
  } };
  return n2[t2] = i2, i2;
}
function Qr(e3, t2) {
  let n2 = Ir(e3, t2);
  if (e3.initialized[t2]) {
    let r2 = e3.target[n2];
    le() && E(() => {
      Reflect.defineProperty(e3.target, n2, { configurable: true, enumerable: true, value: r2, writable: true }), e3.initialized[t2] = true;
    }, e3.target, t2), T(e3.target, t2);
  }
  return e3.initialized[t2] = false, Reflect.deleteProperty(e3.target, n2);
}
function $r(e3, t2) {
  let n2 = Rr.get(e3);
  if (!n2) return;
  let r2 = [];
  for (let e4 of t2) {
    let t3 = Pr(n2, e4);
    if (t3 === void 0) return;
    r2.push(t3);
  }
  return { target: n2.target, keys: r2 };
}
function ei(e3, t2) {
  let n2 = Rr.get(e3);
  if (n2) {
    for (let e4 of t2) if (!Number.isSafeInteger(e4) || e4 < 0 || e4 >= n2.initialized.length) return;
    return { target: n2.target, keys: t2 };
  }
}
function ti(e3, t2) {
  let n2 = Rr.get(e3);
  return !n2 || !Number.isSafeInteger(t2) || t2 < 0 || t2 >= n2.initialized.length || !n2.initialized[t2] ? { present: false } : { present: true, value: n2.target[Ir(n2, t2)] };
}
function ni(e3) {
  return Zn(e3);
}
function ri(e3, t2, n2, r2 = 0) {
  if (r2 > 100) return false;
  let i2 = F(e3), a2 = F(t2);
  if (Object.is(i2, a2)) return true;
  if (!i2 || !a2 || typeof i2 != `object` || typeof a2 != `object` || !(Array.isArray(i2) && Array.isArray(a2) ? Object.getPrototypeOf(i2) === Object.getPrototypeOf(a2) && ui(i2) && di(a2) : Ut(i2) && Ut(a2) && Object.getPrototypeOf(i2) === Object.getPrototypeOf(a2) && ui(i2) && di(a2))) return false;
  let o2 = n2.oldToNext.get(i2), s2 = n2.nextToOld.get(a2);
  if (o2 || s2) return o2 === a2 && s2 === i2;
  n2.oldToNext.set(i2, a2), n2.nextToOld.set(a2, i2);
  let c2 = e3;
  if (Array.isArray(i2) && Array.isArray(a2)) {
    let e4 = Vt.get(i2);
    if (e4) return si(c2, i2, a2, e4.key, n2, r2);
    let t3 = i2.length, o3 = Array.from({ length: t3 }, (e5, t4) => Object.prototype.hasOwnProperty.call(c2, t4) ? c2[t4] : ii), s3 = /* @__PURE__ */ new WeakMap();
    for (let e5 of o3) {
      let t4 = ci(e5);
      t4 && s3.set(t4, e5);
    }
    let l3 = /* @__PURE__ */ new WeakSet();
    for (let e5 of a2) {
      let t4 = ci(e5);
      t4 && s3.has(t4) && l3.add(t4);
    }
    return li(c2, t3, a2.map((e5, t4) => {
      let i3 = ci(e5), a3 = i3 ? s3.get(i3) : void 0;
      if (a3 !== void 0) return a3;
      let c3 = o3[t4];
      if (c3 === ii) return e5;
      let u2 = ci(c3);
      return u2 && l3.has(u2) ? e5 : c3 !== void 0 && ri(c3, e5, n2, r2 + 1) ? c3 : e5;
    })), oi(c2, i2, a2, n2, r2), true;
  }
  let l2 = a2;
  for (let e4 of Reflect.ownKeys(i2)) Object.prototype.hasOwnProperty.call(l2, e4) || Reflect.deleteProperty(c2, e4);
  for (let e4 of Reflect.ownKeys(l2)) {
    let t3 = Reflect.getOwnPropertyDescriptor(l2, e4), a3 = Reflect.getOwnPropertyDescriptor(i2, e4);
    if (!(`value` in t3)) return false;
    (!a3 || !(`value` in a3) || !ri(c2[e4], t3.value, n2, r2 + 1)) && Reflect.defineProperty(c2, e4, { ...t3, value: F(t3.value) });
  }
  return true;
}
var ii = /* @__PURE__ */ Symbol(`exact.array-hole`);
function ai() {
  return { oldToNext: /* @__PURE__ */ new WeakMap(), nextToOld: /* @__PURE__ */ new WeakMap() };
}
function oi(e3, t2, n2, r2, i2) {
  let a2 = (e4) => e4 !== `length` && !(typeof e4 == `string` && /^(0|[1-9]\d*)$/.test(e4));
  for (let r3 of Reflect.ownKeys(t2)) a2(r3) && !Object.prototype.hasOwnProperty.call(n2, r3) && Reflect.deleteProperty(e3, r3);
  for (let o2 of Reflect.ownKeys(n2)) {
    if (!a2(o2)) continue;
    let s2 = Reflect.getOwnPropertyDescriptor(n2, o2), c2 = Reflect.getOwnPropertyDescriptor(t2, o2);
    `value` in s2 && (!c2 || !(`value` in c2) || !ri(e3[o2], s2.value, r2, i2 + 1)) && Reflect.defineProperty(e3, o2, { ...s2, value: F(s2.value) });
  }
}
function si(e3, t2, n2, r2, i2, a2) {
  let o2 = qn(t2, r2), s2 = qn(n2);
  if (o2 && s2 && o2.itemsHash === s2.itemsHash) return true;
  if (o2 && s2 && o2.keyHash === s2.keyHash) {
    let r3 = /* @__PURE__ */ new Set();
    for (let t3 = 0; t3 < n2.length; t3++) {
      if (o2.itemHashes[t3] === s2.itemHashes[t3]) continue;
      let c3 = s2.keys[t3];
      r3.add(c3), ri(e3[t3], n2[t3], i2, a2 + 1) || (e3[t3] = n2[t3]);
    }
    return Xn(t2, s2, r3), true;
  }
  let c2 = /* @__PURE__ */ new Map();
  for (let n3 = 0; n3 < t2.length; n3++) {
    let i3 = String(r2(t2[n3]));
    if (c2.has(i3)) throw Error(`Duplicate key "${i3}" in the current keyed reactive array`);
    c2.set(i3, { item: e3[n3], index: n3 });
  }
  let l2 = n2.map((e4) => ({ id: String(r2(e4)), incoming: e4 })), u2 = /* @__PURE__ */ new Set();
  for (let { id: e4 } of l2) {
    if (u2.has(e4)) throw Error(`Duplicate key "${e4}" in the next keyed reactive array`);
    u2.add(e4);
  }
  let d2 = [], f2 = /* @__PURE__ */ new Set();
  for (let e4 = 0; e4 < l2.length; e4++) {
    let { id: t3, incoming: n3 } = l2[e4], r3 = c2.get(t3);
    r3 !== void 0 && o2 !== void 0 && s2 !== void 0 && o2.itemHashes[r3.index] === s2.itemHashes[e4] ? d2.push(r3.item) : r3 !== void 0 && ri(r3.item, n3, i2, a2 + 1) ? (f2.add(t3), d2.push(r3.item)) : (r3 !== void 0 && f2.add(t3), d2.push(n3));
  }
  return li(e3, t2.length, d2), s2 ? Xn(t2, s2, f2) : Gn(t2, r2), true;
}
function ci(e3) {
  let t2 = F(e3);
  return t2 && typeof t2 == `object` ? t2 : void 0;
}
function li(e3, t2, n2) {
  let r2 = F(e3);
  vr(r2);
  let i2 = /* @__PURE__ */ new Set();
  for (let e4 = 0; e4 < n2.length; e4++) {
    if (!Reflect.has(n2, e4)) {
      Reflect.has(r2, e4) && (Reflect.deleteProperty(r2, e4), i2.add(e4));
      continue;
    }
    let t3 = F(n2[e4]);
    Object.is(F(r2[e4]), t3) || (Reflect.set(r2, e4, t3), i2.add(e4));
  }
  if (n2.length < t2) for (let e4 = t2 - 1; e4 >= n2.length; e4--) Reflect.has(r2, e4) && i2.add(e4), Reflect.deleteProperty(r2, e4);
  r2.length !== n2.length && (r2.length = n2.length), T(r2, N);
  for (let e4 of i2) T(r2, String(e4));
  t2 !== n2.length && T(r2, `length`), (i2.size || t2 !== n2.length) && T(r2, M);
}
function ui(e3) {
  return Object.isExtensible(e3) ? Reflect.ownKeys(e3).every((t2) => {
    if (Array.isArray(e3) && t2 === `length`) return true;
    let n2 = Reflect.getOwnPropertyDescriptor(e3, t2);
    return !!n2 && `value` in n2 && n2.writable !== false && n2.configurable !== false;
  }) : false;
}
function di(e3) {
  return Reflect.ownKeys(e3).every((t2) => {
    if (Array.isArray(e3) && t2 === `length`) return true;
    let n2 = Reflect.getOwnPropertyDescriptor(e3, t2);
    return !!n2 && `value` in n2;
  });
}
function L(e3, t2, n2) {
  return fi(e3, t2, n2), n2;
}
function fi(e3, t2, n2) {
  let r2 = Hr(e3, t2), i2 = F(r2), a2 = F(n2);
  if (Object.is(i2, a2)) return;
  if (i2 === null || a2 === null || typeof i2 != `object` || typeof a2 != `object`) {
    Ur(e3, t2, n2);
    return;
  }
  let o2 = () => {
    ri(r2, n2, ai()) || Ur(e3, t2, n2);
  };
  ue() ? o2() : se(o2);
}
function pi(e3, t2, n2 = `an unlabelled this.map() call`, r2) {
  if (!e3 || typeof e3 != `object`) return () => void 0;
  let i2 = F(e3);
  if (!Array.isArray(i2)) return () => void 0;
  let a2 = r2 ? `compiler:${r2}` : `runtime:${Function.prototype.toString.call(t2)}`, o2 = Vt.get(i2);
  if (o2 && o2.signature !== a2) throw Nt(o2.site, n2);
  if (o2 && !r2) {
    for (let e4 of i2) if (String(o2.key(e4)) !== String(t2(e4))) throw Nt(o2.site, n2);
  }
  o2 ? o2.references++ : Vt.set(i2, { key: t2, signature: a2, site: n2, references: 1 });
  let s2 = true;
  return () => {
    if (!s2) return;
    s2 = false;
    let e4 = Vt.get(i2);
    !e4 || e4.signature !== a2 || --e4.references === 0 && (Vt.delete(i2), Kn(i2));
  };
}
var R = class extends Error {
  reason;
  constructor(e3) {
    super(e3 === void 0 ? `Component task was cancelled` : String(e3)), this.name = `AbortError`, this.reason = e3;
  }
};
function mi(e3) {
  return e3 instanceof R;
}
function hi(e3, t2) {
  return e3.aborted ? (Promise.resolve(t2).catch(() => void 0), Promise.reject(new R(e3.reason))) : new Promise((n2, r2) => {
    let i2 = () => r2(new R(e3.reason));
    e3.addEventListener(`abort`, i2, { once: true }), Promise.resolve(t2).then((t3) => {
      e3.removeEventListener(`abort`, i2), n2(t3);
    }, (t3) => {
      e3.removeEventListener(`abort`, i2), r2(t3);
    });
  });
}
var gi = /* @__PURE__ */ new WeakMap(), _i = [], vi = false;
function yi(e3, t2) {
  gi.set(e3, t2);
}
function bi(e3) {
  gi.delete(e3);
}
function xi(e3, t2, n2) {
  let r2 = gi.get(e3);
  if (!r2 || r2.settled) {
    t2();
    return;
  }
  _i.push({ frame: r2, resume: t2, enter: n2 }), !vi && (vi = true, Si());
}
function Si() {
  let e3 = _i.shift();
  if (!e3) {
    vi = false;
    return;
  }
  let t2 = e3.enter(e3.frame);
  e3.resume(), queueMicrotask(() => {
    t2(), _i.length ? queueMicrotask(Si) : vi = false;
  });
}
var Ci = /* @__PURE__ */ new WeakMap();
function wi(e3, t2) {
  let n2 = { signal: e3.controller.signal, generation: t2.generation ?? 1, activation: t2.activation ?? `invoked`, peek: C, optimistic: t2.optimistic ?? (() => {
    throw Error(`Optimistic state is not available for this task activation`);
  }), cleanup(t3) {
    if (e3.settled || !e3.producerOpen) throw Error(`Cannot register cleanup after the task producer has closed`);
    (e3.cleanups ??= []).push(t3);
  }, own(e4) {
    return n2.cleanup(async () => {
      Symbol.asyncDispose in e4 ? await e4[Symbol.asyncDispose]() : e4[Symbol.dispose]();
    }), e4;
  } };
  return Ci.set(n2, e3), n2;
}
var Ti;
function z(e3, t2, n2, r2) {
  Ti?.publish(e3, t2, n2, r2);
}
function Ei(e3) {
  return Ti?.attached(e3) ?? false;
}
var Di = /* @__PURE__ */ new WeakMap();
function Oi(e3, t2) {
  Di.set(e3, t2);
}
function ki(e3) {
  return Di.get(e3) ?? Promise.resolve();
}
async function Ai(e3) {
  let t2, n2 = false;
  for (; e3.children?.size; ) {
    let r2 = await Promise.allSettled([...e3.children]);
    for (let e4 of r2) e4.status === `fulfilled` || n2 || (t2 = e4.reason, n2 = true);
  }
  if (n2) throw t2;
}
async function ji(e3) {
  let t2;
  for (let n2 of e3.cleanups?.reverse() ?? []) try {
    await n2();
  } catch (e4) {
    t2 ??= e4;
  }
  if (t2 !== void 0) throw t2;
}
var Mi = /* @__PURE__ */ Symbol(`exact.task-frame-token`), Ni = /* @__PURE__ */ Symbol.for(`@exactjs/task-owner`), Pi = class {
  [Ni] = true;
  label;
  host;
  observeSettlement;
  registerReadiness;
  activationsDeferred = false;
  disposed = false;
  controllerValue;
  framesValue;
  settlementsValue;
  ownerCleanupsValue;
  activationRegistrationsValue;
  constructor(e3) {
    this.label = e3;
  }
  get controller() {
    return this.controllerValue || (this.controllerValue = new AbortController(), this.disposed && this.controllerValue.abort(`task-owner-disposed`)), this.controllerValue;
  }
  get signal() {
    return this.controller.signal;
  }
  get frames() {
    return this.framesValue ??= /* @__PURE__ */ new Set();
  }
  get settlements() {
    return this.settlementsValue ??= /* @__PURE__ */ new Set();
  }
  get ownerCleanups() {
    return this.ownerCleanupsValue ??= /* @__PURE__ */ new Set();
  }
  get activationRegistrations() {
    return this.activationRegistrationsValue ??= /* @__PURE__ */ new Set();
  }
  async [Symbol.asyncDispose]() {
    if (!this.disposed) {
      this.disposed = true, this.controllerValue?.abort(`task-owner-disposed`);
      for (let e3 of this.framesValue ?? []) e3.controller.abort(`task-owner-disposed`);
      for (let e3 of [...this.ownerCleanupsValue ?? []].reverse()) await e3();
      this.ownerCleanupsValue?.clear(), await Promise.allSettled([...[...this.framesValue ?? []].map(ki), ...this.settlementsValue ?? []]);
    }
  }
};
function Fi(e3) {
  return new Pi(e3);
}
var Ii = /* @__PURE__ */ new WeakMap();
function Li(e3) {
  let t2 = Ii.get(e3);
  (!t2 || t2.closed) && (t2 = Ri(e3), Ii.set(e3, t2)), t2.pending++;
  let n2 = false, r2 = (r3, i2 = false) => {
    n2 || (n2 = true, i2 && !t2.failed && (t2.failed = true, t2.failure = r3), --t2.pending === 0 && (t2.closed = true, Ii.get(e3) === t2 && Ii.delete(e3), t2.failed ? t2.reject(t2.failure) : t2.resolve()));
  };
  return { run(e4) {
    if (!n2) {
      try {
        if (t2.signal.aborted) throw new R(t2.signal.reason);
        na(t2.frame, e4);
      } catch (e5) {
        throw r2(e5, true), e5;
      }
      r2();
    }
  }, cancel: r2 };
}
function Ri(e3) {
  return Ei(e3) ? Vi(e3) : zi(e3);
}
function zi(e3) {
  let t2, n2, r2, i2 = new Promise((e4, t3) => {
    n2 = e4, r2 = t3;
  }), a2 = { [Mi]: true, id: da(), owner: e3.owner, parent: e3, get controller() {
    return t2 || (t2 = new AbortController(), Hi(e3.controller.signal, t2)), t2;
  }, kind: `reactive`, label: `reactive consequences`, activation: e3.activation, generation: e3.generation, placement: e3.placement, concurrency: e3.concurrency, priority: e3.priority, readiness: e3.readiness, startedAt: Ui(), producerOpen: true, settled: false };
  return aa(e3, i2), { frame: a2, signal: e3.controller.signal, resolve() {
    a2.producerOpen = false, Ai(a2).then(() => Bi(a2, n2), (e4) => Bi(a2, () => r2(e4)));
  }, reject(e4) {
    a2.producerOpen = false, t2?.abort(e4);
    let n3 = () => Bi(a2, () => r2(e4));
    Ai(a2).then(n3, n3);
  }, pending: 0, failed: false, closed: false };
}
function Bi(e3, t2) {
  e3.settled = true, t2();
}
function Vi(e3) {
  let t2, n2, r2 = new Promise((e4, r3) => {
    t2 = e4, n2 = r3;
  }), i2;
  return ra({ parent: e3, owner: e3.owner, activation: e3.activation, kind: `reactive`, label: `reactive consequences`, publicContext: false }, () => (i2 = Qi(), r2)).catch(() => void 0), { frame: i2, signal: i2.controller.signal, resolve: t2, reject: n2, pending: 0, failed: false, closed: false };
}
function Hi(e3, t2) {
  e3.aborted ? t2.abort(e3.reason) : e3.addEventListener(`abort`, () => t2.abort(e3.reason), { once: true });
}
function Ui() {
  return globalThis.performance?.now() ?? Date.now();
}
var Wi = 1, Gi, Ki, qi, Ji = false, Yi = /* @__PURE__ */ new WeakMap();
function Xi(e3) {
  return Fi(e3);
}
function Zi(e3, t2) {
  if (e3.disposed) throw Error(`Task owner has been disposed`);
  e3.ownerCleanups.add(t2);
}
function Qi() {
  return Gi;
}
function $i() {
  return qi?.();
}
function ea(e3, t2) {
  let n2 = qi;
  qi = e3;
  try {
    return t2();
  } finally {
    qi = n2;
  }
}
function ta(e3, t2) {
  let n2 = Ki;
  Ki = e3;
  try {
    return t2();
  } finally {
    Ki = n2;
  }
}
function na(e3, t2) {
  if (e3.settled) throw Error(`Cannot resume a settled task frame`);
  fa();
  let n2 = Gi;
  Gi = e3;
  try {
    return t2();
  } finally {
    Gi = n2;
  }
}
function ra(e3, t2) {
  let n2 = e3.detached ? void 0 : e3.parent ?? Gi;
  if (n2 && !e3.parentReserved && (!n2.producerOpen || n2.settled)) return Promise.reject(Error(`Cannot attach work after the parent task producer has closed`));
  let r2 = e3.owner ?? n2?.owner ?? Xi(`implicit task invocation`);
  if (r2.disposed) return Promise.reject(Error(`Task owner has been disposed`));
  let i2 = e3.controller ?? new AbortController();
  n2 && la(n2.controller.signal, i2);
  let a2, o2, s2 = new Promise((e4, t3) => {
    a2 = e4, o2 = t3;
  }), c2 = { [Mi]: true, id: Wi++, owner: r2, parent: n2, controller: i2, ...e3.label === void 0 ? {} : { label: e3.label }, ...e3.sourceEntityId === void 0 ? {} : { sourceEntityId: e3.sourceEntityId }, activation: e3.activation ?? `invoked`, generation: e3.generation ?? 1, placement: e3.placement ?? `current`, concurrency: e3.concurrency ?? `parallel`, priority: e3.priority ?? n2?.priority ?? `normal`, readiness: e3.readiness ?? (e3.priority === `deferred` ? `nonblocking` : n2?.readiness ?? `blocking`), kind: e3.kind ?? `task`, producerOpen: true, settled: false, startedAt: ua() };
  e3.publicContext !== false && (c2.context = wi(c2, e3)), yi(i2.signal, c2), Oi(c2, s2), r2.frames.add(c2), Ei(c2) ? (z(c2, `task.frame.enter`), z(c2, `task.start`, void 0, { kind: `start`, arguments: e3.inspectionArguments })) : ca.add(c2), n2 ? ((n2.children ??= /* @__PURE__ */ new Set()).add(s2), s2.finally(() => n2.children?.delete(s2)).catch(() => void 0)) : s2.catch(() => void 0);
  let l2, u2;
  try {
    if (i2.signal.aborted) throw new R(i2.signal.reason);
    l2 = na(c2, () => t2(c2.context));
  } catch (e4) {
    u2 = e4, l2 = Promise.reject(e4);
  } finally {
    ca.delete(c2);
  }
  let d2 = hi(i2.signal, l2).then(async (e4) => {
    c2.producerOpen = false, z(c2, `task.foreground-settle`);
    let t3, n3 = false;
    try {
      await Ai(c2);
    } catch (e5) {
      t3 = e5, n3 = true;
    }
    try {
      await ji(c2);
    } catch (e5) {
      if (!n3) throw e5;
      t3 && typeof t3 == `object` && Object.defineProperty(t3, "suppressed", { configurable: true, value: [e5] });
    }
    if (i2.signal.aborted) throw new R(i2.signal.reason);
    if (n3) throw t3;
    return e4;
  }, async (e4) => {
    let t3 = i2.signal.aborted && !(e4 instanceof R) ? new R(i2.signal.reason) : e4;
    c2.producerOpen = false, z(c2, `task.foreground-settle`), i2.abort(e4);
    let n3, r3 = false;
    try {
      await Ai(c2);
    } catch (e5) {
      n3 = e5, r3 = true;
    }
    try {
      await ji(c2);
    } catch (e5) {
      t3 && typeof t3 == `object` && Object.defineProperty(t3, "suppressed", { configurable: true, value: [e5] });
    }
    throw t3 === void 0 && r3 ? n3 : t3;
  }).then((e4) => (c2.settled = true, bi(i2.signal), r2.frames.delete(c2), a2(), z(c2, `task.frame.exit`), z(c2, `task.structural-settle`), z(c2, `task.settle`, void 0, { kind: `outcome`, status: `settled`, value: e4 }), e4), (t3) => {
    c2.settled = true, bi(i2.signal), r2.frames.delete(c2), e3.propagateFailure?.() === false ? a2() : o2(t3), z(c2, `task.frame.exit`);
    let n3 = t3 instanceof R;
    throw z(c2, n3 ? `task.cancel` : `task.fail`, t3, { kind: `outcome`, status: n3 ? `cancelled` : `failed`, value: t3 }), t3;
  });
  return u2 !== void 0 && (Yi.set(d2, { error: u2 }), d2.catch(() => void 0)), d2;
}
function ia(e3) {
  return e3 instanceof Promise ? Yi.get(e3) : void 0;
}
function aa(e3, t2) {
  if (e3.settled || !e3.producerOpen) throw Error(`Cannot attach work after the task frame producer has closed`);
  let n2 = Promise.resolve(t2).then(() => void 0);
  (e3.children ??= /* @__PURE__ */ new Set()).add(n2), n2.finally(() => e3.children?.delete(n2)).catch(() => void 0);
}
function oa(e3, t2) {
  xi(e3, t2, (e4) => {
    if (e4.settled) throw Error(`Cannot resume a settled task frame`);
    let t3 = Gi;
    return Gi = e4, () => {
      Gi = t3;
    };
  });
}
var sa = /* @__PURE__ */ new WeakMap(), ca = /* @__PURE__ */ new WeakSet();
function la(e3, t2) {
  if (e3.aborted) {
    t2.abort(e3.reason);
    return;
  }
  e3.addEventListener(`abort`, () => t2.abort(e3.reason), { once: true });
}
function ua() {
  return globalThis.performance?.now() ?? Date.now();
}
function da() {
  return Wi++;
}
function fa() {
  Ji || (Ji = true, Le((e3) => {
    let t2 = Qi();
    if (!(!t2 || !t2.producerOpen || t2.settled)) return e3 === `interactive` && ca.has(t2) ? pa(t2) : Li(t2);
  }));
}
function pa(e3) {
  let t2 = sa.get(e3);
  return t2 || (t2 = { run: (t3) => na(e3, t3), cancel() {
  } }, sa.set(e3, t2), t2);
}
var ma = [], ha = /* @__PURE__ */ new WeakMap();
function ga(e3) {
  return ma[ma.length - 1] ?? ha.get(e3);
}
function _a(e3, t2) {
  ha.set(e3, t2);
}
function va(e3) {
  ha.delete(e3);
}
function ya(e3, t2) {
  ga(t2)?.register(e3, t2);
}
function ba(e3, t2) {
  if (t2 === 0) return e3;
  if (!Array.isArray(e3)) throw TypeError(`Malformed positional eXact component value`);
  if (t2[0] === 2) return e3.map((e4) => ba(e4, t2[1]));
  let n2 = (t2.length - 1) / 2;
  if (e3.length !== n2) throw TypeError(`Malformed positional eXact component value`);
  let r2 = {};
  for (let n3 = 1, i2 = 0; n3 < t2.length; n3 += 2) r2[t2[n3]] = ba(e3[i2++], t2[n3 + 1]);
  return r2;
}
var xa = /* @__PURE__ */ Symbol.for(`@exactjs/component-contract`), Sa = /* @__PURE__ */ Symbol.for(`@exactjs/component`);
function Ca(e3) {
  let t2 = e3[xa];
  if (t2 && t2.artifact?.version !== 2) throw TypeError(`Unsupported eXact component artifact version ${t2.artifact?.version}; expected 2. Recompile with the matching eXact compiler.`);
  return t2;
}
function wa(e3) {
  let t2 = Ca(e3);
  if (!t2?.artifact) throw TypeError(`Native eXact component execution requires a compiled component artifact: ${e3.name || `<anonymous>`}`);
  return t2;
}
function Ta(e3) {
  let t2 = wa(e3);
  if (t2.artifact.target !== `client`) throw TypeError(`Client execution requires a current client component artifact`);
  return t2;
}
function Ea(e3) {
  let t2 = e3[Sa];
  if (typeof t2 == `string` && t2) return t2;
  throw Error(`Native eXact components require compiler-owned identity`);
}
var Da;
function Oa(e3, t2, n2, r2) {
  Da?.initialize(e3, t2, n2, r2);
}
function ka(e3, t2 = false) {
  let n2 = typeof t2 == `boolean` ? t2 : t2.global ?? false, r2 = typeof t2 == `boolean` ? true : t2.reactive ?? true;
  return { id: n2 ? /* @__PURE__ */ Symbol.for(`exact.context:${e3}`) : Symbol(e3), description: e3, global: n2, reactive: r2, keep: typeof t2 == `boolean` ? void 0 : t2.keep, scope: typeof t2 == `boolean` ? `component` : t2.scope ?? `component` };
}
var Aa = ka(`exact.logger`, true), ja = ka(`exact.error`, { global: true, reactive: false }), Ma = ka(`exact.suspension`, true), Na = ka(`exact.readiness`, true);
function Pa(e3) {
  for (let t2 = e3; t2; t2 = t2.parent) if (t2.contexts.has(Na.id)) return F(t2.contexts.get(Na.id));
}
function Fa(e3, t2, n2, i2) {
  r(e3, t2), Oa(t2, e3, n2?.plan ?? wa(e3.type).execution, i2);
  let a2 = Pa(e3);
  a2 && (t2.registerReadiness = (t3, n3, r2, i3) => a2.register({ owner: e3, taskGeneration: t3, settlement: n3, commit: r2, discard: i3 }));
  let o2 = ga(e3);
  return o2 && (t2.observeSettlement = (t3) => o2.register(t3, e3)), o2?.runTask && (t2.runTask = o2.runTask), o2;
}
var Ia;
function La(e3) {
  if (Ia && Ia !== e3) throw Error(`Conflicting eXact component task capability integration`);
  Ia = e3;
}
function Ra() {
  return Ia;
}
La(Object.freeze({ create(t2, n2, r2, i2, a2, o2) {
  if (r2 !== void 0 && (r2.continuations?.length ?? 0) === 0 && (r2.execution?.transitions.length ?? 0) === 0 && r2.artifact?.capabilities.includes(`tasks`) !== true && r2.artifact?.capabilities.includes(`compatibility`) !== true) return;
  let s2 = Xi(t2.id);
  return o2 && e(s2), Object.freeze({ owner: s2, observer: Fa(t2, s2, i2, a2) });
}, run(e3, t2) {
  return e3 ? ta(e3.owner, t2) : t2();
}, resume(e3, n2) {
  e3 && t(e3.owner, (e4) => {
    let t2 = o(e4);
    return t2 !== void 0 && n2.has(t2);
  });
}, retain(e3, t2) {
  let n2 = e3?.observer;
  n2?.retain?.(t2), n2?.retain && _a(t2, n2);
}, release(e3, t2) {
  e3 && e3.owner[Symbol.asyncDispose](), va(t2);
} }));
var za = /* @__PURE__ */ Symbol.for(`@exactjs/component-domain.runtime-state`), Ba = (() => {
  let e3 = globalThis;
  return e3[za] ??= { resumingDomains: /* @__PURE__ */ new WeakMap(), domainCapabilities: /* @__PURE__ */ new WeakMap(), wallClockUsedDomains: /* @__PURE__ */ new WeakSet() };
})(), { domainCapabilities: Va, resumingDomains: Ha, wallClockUsedDomains: Ua } = Ba, Wa = /* @__PURE__ */ Symbol.for(`@exactjs/page-component-domain`), Ga = globalThis, Ka = Ga[Wa] ??= Qa({ executionRoot: `page` });
function qa(e3) {
  let t2 = Qa(e3), n2 = Object.prototype.hasOwnProperty.call(e3, `logger`) ? { logger: e3.logger, componentOverride: false } : void 0, r2 = Object.freeze({ target: e3.target ? e3.target : void 0, dispatchContinuation: e3.dispatchContinuation ? e3.dispatchContinuation : void 0, resumeComponent: e3.resumeComponent ? e3.resumeComponent : void 0, inspection: e3.inspection ? e3.inspection : void 0, inspectionActivation: e3.inspectionActivation ? e3.inspectionActivation : void 0, wallClockSnapshot: e3.wallClockSnapshot === void 0 ? void 0 : e3.wallClockSnapshot, logging: n2 });
  return Va.set(t2, r2), t2;
}
function Ja(e3) {
  return Va.get(e3)?.logging;
}
function Ya(e3) {
  return Va.get(e3)?.inspection;
}
function Xa(e3) {
  return Va.get(e3)?.resumeComponent;
}
function Za(e3) {
  return Va.get(e3)?.inspectionActivation === `hydration`;
}
function Qa(e3) {
  if (!e3.executionRoot) throw Error(`Component execution root must be a non-empty string`);
  return Object.freeze({ executionRoot: e3.executionRoot });
}
function $a(e3, t2) {
  return eo(e3, t2);
}
function eo(e3, t2) {
  let n2 = Ba.activeDomain;
  Ba.activeDomain = e3;
  try {
    return t2();
  } finally {
    Ba.activeDomain = n2;
  }
}
function to(e3, t2, n2) {
  let r2 = Ba.activeDomain;
  Ba.activeDomain = e3;
  try {
    return j(t2, n2);
  } finally {
    Ba.activeDomain = r2;
  }
}
function no(e3, t2) {
  let n2 = Ha.get(e3) ?? 0;
  Ha.set(e3, n2 + 1);
  try {
    return t2();
  } finally {
    n2 === 0 ? Ha.delete(e3) : Ha.set(e3, n2);
  }
}
function ro(e3, t2) {
  return Ha.has(e3) ? Va.get(e3)?.resumeComponent?.(t2) : void 0;
}
function io() {
  return Ba.activeDomain;
}
function ao(e3, t2) {
  let n2 = AbortSignal.any;
  if (n2) return n2.call(AbortSignal, [e3, t2]);
  let r2 = new AbortController(), i2 = (n3) => {
    e3.removeEventListener(`abort`, i2), t2.removeEventListener(`abort`, i2), r2.abort(n3.currentTarget?.reason);
  };
  return e3.aborted ? r2.abort(e3.reason) : t2.aborted ? r2.abort(t2.reason) : (e3.addEventListener(`abort`, i2, { once: true }), t2.addEventListener(`abort`, i2, { once: true })), r2.signal;
}
function oo(e3, t2) {
  return !t2 || t2 === e3 ? e3 : ao(t2, e3);
}
function so(e3) {
  return !!e3 && (typeof e3 == `object` || typeof e3 == `function`) && typeof e3.then == `function`;
}
var co = { trace: 0, debug: 1, info: 2, warn: 3, error: 4 };
function lo(e3 = {}) {
  let t2 = e3.level ?? `info`;
  return { isEnabled(e4) {
    return co[e4] >= co[t2];
  }, log(e4) {
    let t3 = `${uo(e4.scope)} ${e4.message}`, n2 = fo(e4.level);
    e4.error !== void 0 && e4.data !== void 0 ? n2(t3, e4.error, e4.data) : e4.error === void 0 ? e4.data === void 0 ? n2(t3) : n2(t3, e4.data) : n2(t3, e4.error);
  } };
}
function uo(e3) {
  return e3.source === `component` && e3.component ? `[exact] [component:${e3.component.name}#${e3.component.id}]` : `[exact] [${[`framework`, e3.packageName, e3.category].filter(Boolean).join(`:`)}]`;
}
function fo(e3) {
  return e3 === `trace` ? console.trace?.bind(console) ?? console.debug.bind(console) : e3 === `debug` ? console.debug.bind(console) : e3 === `info` ? console.info.bind(console) : e3 === `warn` ? console.warn.bind(console) : console.error.bind(console);
}
var po = lo();
function mo(e3, t2, n2, r2, i2, a2 = po) {
  let o2 = { source: `framework`, packageName: t2, category: n2 };
  yo(a2, e3, o2) && bo(a2, { level: e3, message: wo(r2), data: i2 === void 0 ? void 0 : wo(i2), scope: o2 });
}
function ho(e3, t2) {
  return go(e3, t2);
}
function go(e3, t2, n2) {
  let r2 = So(e3);
  if (r2 === po && !yo(r2, t2, _o)) return;
  let i2 = n2 ?? Co(e3);
  if (i2.component && (i2.component.mounted = e3.mounted), !(r2 !== po && !yo(r2, t2, i2))) return (e4) => {
    C(() => {
      let [n3, a2, o2] = e4();
      vo(r2, i2, t2, n3, a2, o2);
    });
  };
}
var _o = Object.freeze({ source: `component` });
function vo(e3, t2, n2, r2, i2, a2) {
  let o2 = wo(r2), s2, c2;
  if (n2 === `error` && a2 !== void 0) s2 = wo(i2), c2 = wo(a2);
  else if (n2 === `error` && i2 !== void 0) {
    let e4 = wo(i2);
    To(e4) ? s2 = e4 : c2 = e4;
  } else i2 !== void 0 && (c2 = wo(i2));
  bo(e3, { level: n2, message: o2, error: s2, data: c2, scope: t2 });
}
function yo(e3, t2, n2) {
  try {
    return !e3.isEnabled || e3.isEnabled(t2, n2);
  } catch (e4) {
    return xo(e4), false;
  }
}
function bo(e3, t2) {
  try {
    e3.log(t2);
  } catch (e4) {
    xo(e4);
  }
}
function xo(e3) {
  try {
    po.log({ level: `error`, message: `logger failed while handling eXact log event`, error: e3, scope: { source: `framework`, packageName: `core`, category: `logger` } });
  } catch {
  }
}
function So(e3) {
  let t2 = Ja(e3.domain);
  if (t2 && !t2.componentOverride) return t2.logger ?? po;
  let n2 = e3.parent;
  for (; n2; ) {
    if (n2.contexts.has(Aa.id)) return F(n2.contexts.get(Aa.id));
    n2 = n2.parent;
  }
  return e3.ambientContexts?.has(Aa.id) ? F(e3.ambientContexts.get(Aa.id)) : po;
}
function Co(e3) {
  return { source: `component`, component: { id: e3.id, name: e3.type.name || `anonymous`, mounted: e3.mounted } };
}
function wo(e3) {
  return typeof e3 == `function` ? e3() : e3;
}
function To(e3) {
  return e3 instanceof Error;
}
function Eo(e3) {
  return !!e3 && typeof e3 == `object` && `id` in e3 && `error` in e3 && `source` in e3;
}
function Do(e3) {
  return e3 instanceof Error ? e3.stack ?? e3.message : String(e3);
}
function Oo(e3) {
  let t2 = [];
  return ko(e3, t2), t2;
}
function ko(e3, t2) {
  for (let n2 of e3) Array.isArray(n2) ? ko(n2, t2) : t2.push(n2);
}
function B(e3) {
  if (!Array.isArray(e3)) return [e3];
  for (let t2 of e3) if (Array.isArray(t2)) return Oo(e3);
  return e3;
}
var Ao = /* @__PURE__ */ Symbol.for(`@exactjs/opaque-target-operation`), jo = /* @__PURE__ */ Symbol.for(`@exactjs/opaque-target-operation-execution`), Mo = /* @__PURE__ */ Symbol.for(`@exactjs/opaque-target-operation-metadata`), No = Object.freeze(Object.defineProperty({}, Ao, { value: true })), Po = /* @__PURE__ */ new WeakMap(), Fo = /* @__PURE__ */ new WeakMap();
function Io(e3) {
  if (!e3) return No;
  let t2 = Po.get(e3);
  return t2 || (t2 = Object.freeze(Object.defineProperties({}, { [Ao]: { value: true }, [jo]: { value: e3 } })), Po.set(e3, t2)), t2;
}
function Lo(e3, t2) {
  let n2 = Fo.get(e3);
  n2 || Fo.set(e3, n2 = /* @__PURE__ */ new WeakMap());
  let r2 = n2.get(t2);
  if (!r2) {
    let i2 = Object.create(e3);
    r2 = Object.freeze(Object.defineProperty(i2, Mo, { value: Object.freeze({ domain: t2 }) })), n2.set(t2, r2);
  }
  return r2;
}
function V(e3) {
  let t2 = /* @__PURE__ */ Symbol.for(`@exactjs/opaque-target-operation-store/${e3}`), n2 = globalThis, r2 = n2[t2];
  if (r2 instanceof WeakMap) return r2;
  let i2 = /* @__PURE__ */ new WeakMap();
  return n2[t2] = i2, i2;
}
function Ro(e3, t2) {
  let n2 = Io(e3);
  if (t2?.key === void 0 && t2?.domain) return Object.freeze(Object.create(Lo(n2, t2.domain)));
  let r2 = Object.create(n2);
  return t2 && (t2.key !== void 0 || t2.domain !== void 0) && Object.defineProperty(r2, Mo, { value: Object.freeze({ ...t2 }) }), Object.freeze(r2);
}
function zo(e3) {
  return typeof e3 == `object` && !!e3 && e3[Ao] === true;
}
function Bo(e3) {
  return zo(e3) ? e3[Mo]?.key : void 0;
}
function Vo(e3) {
  return zo(e3) ? e3[Mo]?.domain : void 0;
}
function Ho(e3, t2) {
  if (typeof e3 != `object` || !e3) return;
  let n2 = e3[jo];
  return typeof n2 == `function` ? { value: Reflect.apply(n2, e3, [t2]) } : void 0;
}
var Uo = V(`intrinsic`);
V(`intrinsic-composition`);
var Wo = /* @__PURE__ */ Symbol.for(`@exactjs/target-operation/intrinsic`);
function Go(e3) {
  let t2 = Uo.get(this);
  if (!t2) throw TypeError(`Intrinsic operation lost its compiler-issued payload`);
  return e3[Wo](this, t2);
}
function H(e3, t2, ...n2) {
  if (typeof e3 != `string`) throw TypeError(`Compiled intrinsic receipt requires an intrinsic tag`);
  let { key: r2, __exactEnhancements: i2, ...a2 } = t2 ?? {}, o2 = F(r2), s2 = io(), c2 = o2 == null ? void 0 : String(o2), l2 = Ro(Go, { key: c2, domain: s2 });
  return Uo.set(l2, { tag: e3, props: a2, children: B(n2), key: c2, domain: s2, enhancement: i2 || void 0 }), l2;
}
function Ko(e3) {
  return typeof e3 == `object` && e3 ? Uo.get(e3) : void 0;
}
function qo(e3, t2 = {}) {
  return H(`section`, { role: `alert`, className: `exact-error-boundary` }, H(`h1`, null, `Application error`), ...Array.from(e3, (e4) => H(`article`, { key: e4.id, className: `exact-error` }, H(`h2`, null, e4.component?.name ?? t2.componentFallback ?? `Framework`), H(`p`, null, `${e4.source}${e4.phase ? `:${e4.phase}` : ``}`), H(`pre`, null, Do(e4.error)))), ...t2.actions ?? []);
}
var Jo = 1;
function Yo(e3 = []) {
  return Xo(e3);
}
function Xo(e3, t2) {
  let n2 = jr(e3);
  return { errors: n2, report(e4, r2) {
    let i2 = Eo(e4) ? e4 : Zo(e4, r2);
    return se(() => {
      n2.push(i2), t2 !== void 0 && n2.length > t2 && n2.splice(0, n2.length - t2);
    }), i2;
  }, clear(e4) {
    let t3 = typeof e4 == `string` ? e4 : e4.id, r2 = n2.findIndex((e5) => e5.id === t3);
    r2 >= 0 && n2.splice(r2, 1);
  }, clearAll() {
    n2.splice(0, n2.length);
  } };
}
function U(e3, t2, n2, r2) {
  return { id: `e${Jo++}`, error: e3, source: t2, component: n2 ? Co(n2).component : void 0, phase: r2 };
}
function Zo(e3, t2 = {}) {
  return { id: `e${Jo++}`, error: e3, source: t2.source ?? `component`, component: t2.component, phase: t2.phase };
}
function W(e3, t2, n2 = e3) {
  let r2 = e3;
  for (; r2; ) {
    if (r2.contexts.has(ja.id)) {
      let e4 = F(r2.contexts.get(ja.id));
      if (e4.boundary === n2) {
        r2 = r2.parent;
        continue;
      }
      e4.report(t2), (e4.boundary ?? r2).invalidate?.();
      return;
    }
    r2 = r2.parent;
  }
  let i2 = e3?.ambientContexts?.get(ja.id);
  if (i2) {
    let r3 = F(i2);
    if (r3.boundary !== n2) {
      r3.report(t2), e3 && ho(e3, `error`)?.(() => [`root error context handled failure`, t2.error, { source: t2.source, phase: t2.phase, component: t2.component }]);
      return;
    }
  }
  let a2 = es;
  a2.report(t2);
  let o2 = () => qo(a2.errors);
  return e3 ? (e3.errorFallback = o2, e3.invalidate?.(), ho(e3, `error`)?.(() => [`root error context handled failure`, t2.error, { source: t2.source, phase: t2.phase, component: t2.component }])) : mo(`error`, `core`, t2.source, `root error context handled failure`, { phase: t2.phase, component: t2.component }), o2;
}
function Qo(e3, t2) {
  return $o(e3, t2) !== false;
}
function $o(e3, t2) {
  let n2 = e3;
  for (; n2; ) {
    if (n2.contexts.has(Ma.id)) return F(n2.contexts.get(Ma.id)).suspend(t2) ?? true;
    n2 = n2.parent;
  }
  return false;
}
var es = Xo([], 100), ts = /* @__PURE__ */ new WeakMap();
function ns(e3, t2) {
  return e3.aborted ? Promise.reject(new R(e3.reason)) : new Promise((n2, r2) => {
    let i2 = false, a2, o2 = () => {
      i2 || (i2 = true, a2?.(), a2 = void 0, oa(e3, () => r2(new R(e3.reason))));
    };
    e3.addEventListener(`abort`, o2, { once: true });
    let s2 = (t3, a3) => {
      i2 || (i2 = true, e3.removeEventListener(`abort`, o2), oa(e3, () => {
        a3 ? r2(t3) : e3.aborted ? r2(new R(e3.reason)) : n2(t3);
      }));
    }, c2 = (t3, n3) => {
      if (i2) return;
      let r3 = ts.get(e3);
      if (r3?.scope.paused) {
        a2 = Ct(r3.scope, () => {
          a2 = void 0, s2(t3, n3);
        });
        return;
      }
      s2(t3, n3);
    };
    Promise.resolve(t2).then((e4) => c2(e4, false), (e4) => c2(e4, true));
  });
}
var rs = /* @__PURE__ */ new WeakMap();
function is(e3) {
  return rs.get(e3);
}
var as = class e2 {
  promise;
  observe;
  [Symbol.toStringTag] = `TaskInvocation`;
  constructor(e3, t2 = () => void 0) {
    this.promise = e3, this.observe = t2;
  }
  then(t2, n2) {
    return this.observe(), new e2(this.promise.then(t2, n2));
  }
  catch(t2) {
    return this.observe(), new e2(this.promise.catch(t2));
  }
  finally(t2) {
    return this.observe(), new e2(this.promise.finally(t2 ?? void 0));
  }
};
function os(e3) {
  let t2 = ho(e3, `trace`);
  if (t2) return (e4, n2, r2) => {
    let i2 = Object.freeze({ operation: e4, operationId: n2, startedAt: cs() });
    return t2(() => [`performance ${e4} started`, { operation: e4, operationId: n2, phase: `started`, elapsedMs: 0, ...r2 ? { attributes: r2 } : {} }]), i2;
  };
}
function ss(e3, t2, n2, r2) {
  t2 && ho(e3, `trace`)?.(() => [`performance ${t2.operation} ${n2}`, { operation: t2.operation, operationId: t2.operationId, phase: n2, elapsedMs: cs() - t2.startedAt, ...r2 ? { attributes: typeof r2 == `function` ? r2() : r2 } : {} }]);
}
function cs() {
  return globalThis.performance?.now() ?? Date.now();
}
var ls = 1, us = /* @__PURE__ */ new WeakMap(), ds;
function fs() {
  let e3 = Qi();
  for (let t2 = e3; t2; t2 = t2.parent) {
    let e4 = us.get(t2);
    if (e4) return e4;
  }
}
function ps(e3) {
  return i(e3) !== void 0;
}
function ms(e3, t2, n2) {
  e3 && ss(e3.owner, ds?.get(e3), t2, n2);
}
function hs(e3, t2, n2, r2, i2, a2) {
  return ys(e3, t2, n2, r2, i2, true, a2);
}
function gs(e3, t2, n2, r2, i2, a2, o2, s2) {
  return ys(e3, t2, n2, r2, i2, false, a2, o2, s2);
}
function _s(e3, t2, n2, r2, a2, o2, s2) {
  let c2 = s2 === void 0 ? os(e3) : s2;
  if (c2) return gs(e3, t2, vs(n2, e3), r2, new AbortController(), a2, o2, c2);
  let l2, u2, d2, f2, p2 = () => {
    if (l2) return l2;
    let a3 = i(e3), o3 = a3 ?? Xi(`${e3.id}:interaction`), s3 = new Promise((e4, t3) => {
      d2 = e4, f2 = t3;
    });
    return u2 = ra({ owner: o3, generation: vs(n2, e3), activation: `interaction`, label: `${t2} interaction`, concurrency: `latest`, priority: r2 === `interactive` ? `immediate` : r2, readiness: r2 === `deferred` ? `nonblocking` : `blocking`, publicContext: false, detached: true }, () => (l2 = Qi(), s3)).finally(() => a3 ? void 0 : o3[Symbol.asyncDispose]()), l2;
  }, m2;
  try {
    m2 = ea(p2, a2);
  } catch (e4) {
    throw u2 && (f2(e4), u2.catch(() => void 0)), e4;
  }
  return u2 ? (d2(m2), u2) : m2;
}
function vs(e3, t2) {
  return typeof e3 == `function` ? e3(t2) : e3;
}
function ys(e3, t2, n2, r2, a2, o2, s2, c2, l2) {
  let u2 = i(e3), d2 = u2 ?? Xi(`${e3.id}:interaction`), f2 = l2 === void 0 ? os(e3) : l2 || void 0, p2, m2 = ra({ owner: d2, controller: a2, generation: n2, activation: `interaction`, label: `${t2} interaction`, concurrency: `latest`, priority: r2 === `interactive` ? `immediate` : r2, readiness: r2 === `deferred` ? `nonblocking` : `blocking`, publicContext: false }, () => {
    if (o2 || f2) {
      let i2 = Qi(), a3 = Object.freeze({ id: ls++, owner: e3, source: t2, priority: r2, generation: n2 });
      p2 = a3, us.set(i2, a3);
      let o3 = f2?.(`interaction`, `interaction:${a3.id}`, { source: t2, priority: r2, generation: n2 });
      return o3 && (ds ??= /* @__PURE__ */ new WeakMap()).set(a3, o3), c2?.(a3), s2(a3);
    }
    return s2();
  }), h2 = ia(m2);
  if (h2) throw u2 || m2.finally(() => d2[Symbol.asyncDispose]()).catch(() => void 0), p2 && ds?.has(p2) && bs(p2, `error`), h2.error;
  let g2 = u2 ? m2 : m2.finally(() => d2[Symbol.asyncDispose]());
  return p2 && ds?.has(p2) && g2.then(() => bs(p2, `success`), () => bs(p2, `error`)), g2;
}
function bs(e3, t2) {
  ms(e3, `settled`, { outcome: t2 }), ds?.delete(e3);
}
function xs(e3, t2, n2, r2) {
  return Ss(e3, t2, n2, r2);
}
function Ss(e3, t2, n2, r2) {
  let i2 = ws(e3);
  if (!i2) return;
  let a2 = fs(), o2 = os(i2)?.(`task`, `task:${n2 ?? r2 ?? `anonymous`}:${t2.generation}`, { activation: t2.activation, generation: t2.generation, priority: t2.priority, ...a2 ? { interactionId: a2.id } : {} });
  return o2 ? { owner: i2, span: o2 } : void 0;
}
function Cs(e3, t2) {
  e3 && ss(e3.owner, e3.span, `settled`, t2);
}
function ws(e3) {
  let t2 = e3.host;
  if (!(!t2 || typeof t2 != `object` || !(`id` in t2) || typeof t2.id != `string` || !(`domain` in t2) || !(`scope` in t2) || !(`unmount` in t2) || typeof t2.unmount != `function`)) return t2;
}
var Ts = /* @__PURE__ */ new WeakMap();
function Es(e3) {
  if (typeof e3 == `object` && e3 || typeof e3 == `function`) return Ts.get(e3);
}
function Ds(e3) {
  let t2 = { status: `available`, generation: 0, version: 0, value: e3 };
  return { read: () => t2, subscribe: () => js };
}
function Os(e3) {
  if (Ms.has(e3)) return e3;
  let t2 = e3, n2 = Es(t2);
  if (n2) return n2;
  let r2 = Cn(t2);
  return r2 ? As(t2, r2) : Ds(t2);
}
function ks(e3, t2) {
  let n2 = new Ns(e3, t2);
  return Ms.add(n2), n2;
}
function As(e3, t2) {
  let n2 = 0, r2 = true, i2;
  return { read() {
    return r2 &&= (i2 = { status: `available`, generation: 0, version: n2, value: P(e3) ? F(e3) : e3 }, false), i2;
  }, subscribe(e4) {
    return Ps(bn(t2, () => {
      n2++, r2 = true, e4();
    }));
  } };
}
var js = { [Symbol.dispose]() {
} }, Ms = /* @__PURE__ */ new WeakSet(), Ns = class {
  input;
  index;
  target;
  key;
  version = 0;
  constructor(e3, t2) {
    this.input = e3, this.index = t2;
    let n2 = ei(e3, [t2]);
    if (!n2) throw TypeError(`Indexed continuation dependency referenced an invalid reactive slot`);
    this.target = n2.target, this.key = n2.keys[0];
  }
  read() {
    return { status: `available`, generation: 0, version: this.version, value: Hr(this.input, this.index) };
  }
  subscribe(e3) {
    let t2, n2 = () => {
      this.version++, e3();
    }, r2 = () => {
      t2?.(), t2 = void 0;
      let e4 = ti(this.input, this.index);
      if (e4.present && P(e4.value)) {
        let r3 = Cn(e4.value);
        r3 && (t2 = bn(r3, n2));
      }
    }, i2 = xn(this.target, [this.key], () => {
      r2(), n2();
    });
    try {
      r2();
    } catch (e4) {
      throw i2(), e4;
    }
    return Ps(() => {
      i2(), t2?.();
    });
  }
};
function Ps(e3) {
  return { [Symbol.dispose]: e3 };
}
var Fs = Object.freeze([]);
function Is(e3, t2) {
  let n2 = false, r2 = false, i2 = false, a2 = Array(e3.length).fill(-1), o2 = Array(e3.length).fill(-1), s2 = Array(e3.length), c2 = Array(e3.length), l2 = Array(e3.length), u2 = () => {
    if (r2 = false, n2) return;
    let u3 = !i2;
    for (let n3 = 0; n3 < e3.length; n3++) {
      let r3 = e3[n3].read();
      if (r3.status !== `available`) {
        i2 = false, t2.onUnavailable(r3.status, r3);
        return;
      }
      s2[n3] = r3.generation, c2[n3] = r3.version, l2[n3] = r3.value, (r3.generation !== a2[n3] || r3.version !== o2[n3]) && (u3 = true);
    }
    if (!u3) return;
    i2 = true;
    let d3 = e3.length ? Array(e3.length) : void 0;
    for (let t3 = 0; t3 < e3.length; t3++) a2[t3] = s2[t3], o2[t3] = c2[t3], d3[t3] = l2[t3];
    t2.onReady({ values: d3 ?? Fs });
  }, d2 = () => {
    n2 || r2 || (r2 = true, Ge(u2));
  }, f2 = Array(e3.length);
  for (let t3 = 0; t3 < e3.length; t3++) f2[t3] = e3[t3].subscribe(d2);
  return { evaluate: u2, [Symbol.dispose]() {
    if (!n2) {
      n2 = true;
      for (let e4 of f2) e4[Symbol.dispose]();
    }
  } };
}
function Ls(e3, t2, ...n2) {
  let r2 = i(e3);
  if (!r2) throw Error(`activateComputationForHost() requires a registered durable task host`);
  let a2 = n2.map(Os), o2, s2 = false, c2 = { task: t2, settled: false, start(e4) {
    if (o2) return;
    let n3 = true;
    o2 = Is(a2, { onReady(r3) {
      if ((e4 || s2) && n3) {
        n3 = false, c2.settled = true;
        return;
      }
      n3 = false, C(() => t2(...r3.values, Rs)), c2.settled = true;
    }, onUnavailable() {
      c2.settled = false;
    } }), o2.evaluate();
  } };
  r2.activationRegistrations.add(c2);
  let l2 = false, u2 = { [Symbol.dispose]() {
    l2 || (l2 = true, o2?.[Symbol.dispose](), r2.activationRegistrations.delete(c2), r2.ownerCleanups.delete(d2));
  } }, d2 = u2[Symbol.dispose].bind(u2);
  Zi(r2, d2);
  try {
    if (r2.activationsDeferred) {
      let e4 = a2.map((e5) => e5.read());
      e4.every((e5) => e5.status === `available`) && (C(() => t2(...e4.map((e5) => e5.value), Rs)), s2 = true, c2.settled = true);
    } else c2.start(false);
  } catch (e4) {
    throw u2[Symbol.dispose](), e4;
  }
  return u2;
}
var Rs = Object.freeze({ signal: new AbortController().signal });
function zs(e3, t2, n2) {
  let r2 = Bs(e3, t2, n2);
  return ((...e4) => Vs(r2, e4, `invoked`));
}
function Bs(e3, t2, n2) {
  let r2 = i(e3);
  if (!r2) throw Error(`A compiled client/latest task requires a registered durable task host`);
  let a2 = is(n2);
  return { owner: r2, label: t2, implementation: n2, ...a2 ? { sourceEntityId: a2 } : {}, generation: 0 };
}
function Vs(e3, t2, n2) {
  e3.active?.abort(`superseded`);
  let r2 = new AbortController();
  e3.active = r2;
  let i2 = ++e3.generation, a2 = n2 === `invoked` ? Qi() ?? $i() : void 0, o2;
  a2 && aa(a2, new Promise((e4) => o2 = e4));
  let s2, c2, l2 = new Promise((e4, t3) => {
    s2 = e4, c2 = t3;
  });
  l2.catch(() => void 0);
  let u2 = false;
  return e3.owner.settlements.add(l2), e3.owner.observeSettlement?.(l2), l2.finally(() => {
    e3.owner.settlements.delete(l2), e3.active === r2 && (e3.active = void 0);
  }).catch(() => void 0), Ge(() => {
    let l3 = xs(e3.owner, { activation: n2, generation: i2, priority: `normal` }, e3.sourceEntityId, e3.label), d2 = () => ra({ parent: a2, parentReserved: o2 !== void 0, owner: e3.owner, controller: r2, generation: i2, activation: n2, label: e3.label, sourceEntityId: e3.sourceEntityId, placement: `client`, concurrency: `latest`, priority: `normal`, readiness: `nonblocking`, inspectionArguments: t2, detached: n2 !== `invoked`, propagateFailure: () => !u2 }, (n3) => e3.implementation(...t2, n3)), f2;
    try {
      f2 = e3.owner.runTask && !a2 ? e3.owner.runTask(d2) : d2();
    } catch (e4) {
      o2?.(), Cs(l3, { outcome: `error` }), c2(e4);
      return;
    }
    o2?.(), f2.then((e4) => {
      Cs(l3, { outcome: `success` }), s2(e4);
    }, (e4) => {
      Cs(l3, { outcome: r2.signal.aborted ? `cancelled` : `error` }), c2(e4);
    });
  }, `normal`, (e4) => {
    o2?.(), c2(e4);
  }), new as(l2, () => {
    u2 = true;
  });
}
Object.freeze({ [Symbol.dispose]() {
} });
function Hs(e3, t2, n2) {
  ya(Promise.resolve(t2).catch((t3) => {
    W(e3, U(t3, `lifecycle`, e3, n2));
  }), e3);
}
function Us(e3, t2, n2, r2) {
  if (!so(t2)) return;
  let i2 = Promise.resolve(t2).catch((t3) => {
    mi(t3) || W(e3, U(t3, n2, e3, r2));
  });
  e3 && ya(i2, e3);
}
var Ws = /* @__PURE__ */ new WeakMap(), Gs = Object.freeze([]), Ks = Object.freeze([]);
function qs(e3) {
  let t2 = Ws.get(e3);
  return t2 || (t2 = {}, Ws.set(e3, t2)), t2;
}
function Js(e3, t2) {
  let n2 = qs(e3);
  return n2[t2] ??= [];
}
function Ys(e3, t2, n2) {
  Js(e3, t2).push(n2);
}
function Xs(e3, t2) {
  return Ws.get(e3)?.[t2] ?? Gs;
}
function Zs(e3) {
  return Ws.get(e3)?.render ?? Ks;
}
function Qs(e3) {
  Ws.delete(e3);
}
function $s(e3) {
  let t2 = null, n2 = ec();
  e3.invalidate = void 0, e3.beginRender();
  try {
    let n3 = e3.errorFallback ?? e3.renderFunction;
    t2 = j(e3.scope, () => $a(e3.domain, n3));
  } catch (n3) {
    if (so(n3) && Qo(e3, n3)) t2 = null;
    else {
      let r2 = W(e3, U(n3, `render`, e3));
      r2 && (e3.errorFallback = r2, t2 = j(e3.scope, () => $a(e3.domain, r2)));
    }
  } finally {
    e3.endRender();
  }
  if (e3.runtimeABI & 2) {
    let t3 = ec() - n2;
    for (let n3 of Zs(e3)) try {
      let r2 = n3({ duration: t3 });
      so(r2) && Hs(e3, Promise.resolve(r2), `render`);
    } catch (t4) {
      W(e3, U(t4, `lifecycle`, e3, `render`));
    }
  }
  return B(t2);
}
function ec() {
  return typeof globalThis.performance?.now == `function` ? globalThis.performance.now() : Date.now();
}
var tc = /* @__PURE__ */ Symbol.for(`@exactjs/compiled-client-component-attachment`), nc = /* @__PURE__ */ Symbol.for(`@exactjs/compatibility-client-component-attachment`), rc = Object.freeze([]);
function ic(e3, t2, n2) {
  return qe(`normal`), t2[tc](this, e3, $s(e3), n2);
}
function ac(e3, t2, n2 = rc) {
  e3.receiveProps(this.props, t2, n2);
}
function oc(e3, t2) {
  e3.unmount(typeof t2 == `string` ? t2 : `artifact-dispose`);
}
Object.freeze([]);
var sc = V(`component`), cc = /* @__PURE__ */ Symbol.for(`@exactjs/target-operation/component`);
function lc(e3) {
  let t2 = sc.get(this);
  if (!t2) throw TypeError(`Component operation lost its compiler-issued payload`);
  return e3[cc](this, t2);
}
function uc(e3, t2, ...n2) {
  let { key: r2, __exactEnhancements: i2, ...a2 } = t2 ?? {}, o2 = F(r2), s2 = io(), c2 = o2 == null ? void 0 : String(o2), l2 = Ro(lc, { ...c2 === void 0 ? {} : { key: c2 }, ...s2 ? { domain: s2 } : {} });
  return sc.set(l2, { contract: wa(e3), props: a2, children: B(n2), ...c2 === void 0 ? {} : { key: c2 }, ...s2 ? { domain: s2 } : {}, ...i2 ? { enhancement: i2 } : {} }), l2;
}
function dc(e3) {
  return typeof e3 == `object` && e3 ? sc.get(e3) : void 0;
}
var fc = V(`target`), pc = /* @__PURE__ */ Symbol.for(`@exactjs/target-operation/target`);
function mc(e3) {
  return typeof e3 == `object` && e3 ? fc.get(e3) : void 0;
}
var hc = V(`fragment`), gc = /* @__PURE__ */ Symbol.for(`@exactjs/target-operation/fragment`);
function _c(e3) {
  let t2 = hc.get(this);
  if (!t2) throw TypeError(`Fragment operation lost its compiler-issued payload`);
  return e3[gc](this, t2);
}
function vc(e3, ...t2) {
  let { key: n2, __exactEnhancements: r2, ...i2 } = e3 ?? {}, a2 = F(n2), o2 = io(), s2 = a2 == null ? void 0 : String(a2), c2 = Ro(_c, { key: s2, domain: o2 });
  return hc.set(c2, { props: i2, children: B(t2), key: s2, domain: o2, enhancement: r2 || void 0 }), c2;
}
function yc(e3) {
  return typeof e3 == `object` && e3 ? hc.get(e3) : void 0;
}
var bc = /* @__PURE__ */ Symbol.for(`@exactjs/target-operation/document-output`), xc = vc(null), Sc = V(`document-output`);
function Cc(e3) {
  let t2 = Ro(function(t3) {
    let n2 = t3[bc];
    return n2 ? n2.call(t3, e3) : Ho(xc, t3)?.value;
  });
  return Sc.set(t2, e3), t2;
}
function wc(e3) {
  return typeof e3 == `object` && !!e3 && Sc.has(e3);
}
Object.freeze({ styles: Cc(`styles`), headScripts: Cc(`headScripts`), hydrationData: Cc(`hydrationData`), bootstrap: Cc(`bootstrap`) });
var Tc = V(`doctype`);
vc(null);
function Ec(e3) {
  return typeof e3 == `object` && e3 ? Tc.get(e3) : void 0;
}
var Dc = V(`child-range`), Oc = /* @__PURE__ */ Symbol.for(`@exactjs/target-operation/child-range`);
function kc(e3) {
  let t2 = Dc.get(this);
  if (!t2) throw TypeError(`Child-range operation lost its compiler-issued payload`);
  return e3[Oc](this, t2);
}
function Ac(e3, t2, n2 = true, r2) {
  let i2 = io(), a2 = Ro(kc, { ...i2 ? { domain: i2 } : {} });
  return Dc.set(a2, { value: e3, mayReplaceSubtree: n2, ...t2 ? { markerId: t2 } : {}, ...i2 ? { domain: i2 } : {}, ...r2 ? { dynamicComponent: r2 } : {} }), a2;
}
function jc(e3) {
  return typeof e3 == `object` && e3 ? Dc.get(e3) : void 0;
}
var Mc = V(`suspense`), Nc = /* @__PURE__ */ Symbol.for(`@exactjs/target-operation/suspense`);
function Pc(e3) {
  return typeof e3 == `object` && e3 ? Mc.get(e3) : void 0;
}
var Fc = V(`activity`), Ic = /* @__PURE__ */ Symbol.for(`@exactjs/target-operation/activity`);
function Lc(e3) {
  return typeof e3 == `object` && e3 ? Fc.get(e3) : void 0;
}
var Rc = V(`keyed-child`), zc = /* @__PURE__ */ Symbol.for(`@exactjs/target-operation/keyed-child`);
function Bc(e3) {
  let t2 = Rc.get(this);
  if (!t2) throw TypeError(`Keyed child operation lost its compiler-issued payload`);
  return e3[zc](this, t2);
}
function Vc(e3, t2, n2) {
  let r2 = F(t2);
  if (r2 == null) throw Error(`Compiled keyed lists require a key`);
  let i2 = String(r2), a2 = Vo(e3), o2 = Ro(Bc, { key: i2, ...a2 ? { domain: a2 } : {} });
  return Rc.set(o2, { value: e3, key: i2, ...n2 ? { ownerScope: n2 } : {} }), o2;
}
function Hc(e3) {
  return typeof e3 == `object` && e3 ? Rc.get(e3) : void 0;
}
var Uc = V(`unsafe-html`), Wc = /* @__PURE__ */ Symbol.for(`@exactjs/target-operation/unsafe-html`);
function Gc(e3) {
  return typeof e3 == `object` && e3 ? Uc.get(e3) : void 0;
}
V(`portal`);
var Kc = /* @__PURE__ */ Symbol.for(`@exactjs/target-operation/portal`);
new TextEncoder(), Array.from({ length: 256 }, (e3, t2) => t2.toString(16).padStart(2, `0`));
function qc(e3) {
  if (!e3.startsWith(`~`) || !/^(?:[0-9a-f]{2})+$/i.test(e3.slice(1))) return e3;
  let t2 = e3.slice(1), n2 = new Uint8Array(t2.length / 2);
  for (let e4 = 0; e4 < n2.length; e4++) n2[e4] = Number.parseInt(t2.slice(e4 * 2, e4 * 2 + 2), 16);
  return new TextDecoder().decode(n2);
}
V(`server-boundary`);
var Jc = V(`server-slot`), Yc = /* @__PURE__ */ Symbol.for(`@exactjs/target-operation/server-boundary`), Xc = /* @__PURE__ */ Symbol.for(`@exactjs/target-operation/server-slot`);
function Zc(e3) {
  return typeof e3 == `object` && e3 ? Jc.get(e3) : void 0;
}
var Qc = /* @__PURE__ */ Symbol.for(`@exactjs/dom.supplied-placement-capability.v2`);
function $c(e3, t2) {
  if (!e3.componentReceipt?.transparentUpdateOwner && !e3.clientArtifact?.capabilities.includes(`targets`)) return;
  let n2 = globalThis[Qc];
  if (!n2) throw Error(`Supplied placement requires the compiler-selected capability`);
  n2.retain(e3, t2);
}
function el(e3) {
  globalThis[Qc]?.validate(e3);
}
function tl(e3, t2, n2, r2, i2) {
  return globalThis[Qc]?.take(e3, t2, n2, r2, i2);
}
var nl = /* @__PURE__ */ new WeakMap(), rl = /^[^\t\n\f\r ]+$/u;
function il(e3, t2) {
  let n2 = al(t2.id);
  if (n2) {
    nl.set(e3, { id: n2, generated: false });
    return;
  }
  if (t2.id) return;
  let r2 = nl.get(e3);
  r2 && (t2.id = r2.id);
}
function al(e3) {
  return typeof e3 == `string` && rl.test(e3) ? e3 : void 0;
}
function ol(e3) {
  return sl(``, e3);
}
function sl(e3, t2) {
  let n2 = F(t2);
  if (n2 === false || n2 == null) return e3;
  if (Array.isArray(n2)) {
    for (let t3 of n2) e3 = sl(e3, t3);
    return e3;
  }
  if (typeof n2 == `object`) {
    for (let t3 in n2) Object.hasOwn(n2, t3) && F(n2[t3]) && (e3 = cl(e3, t3));
    return e3;
  }
  return cl(e3, String(n2));
}
function cl(e3, t2) {
  return t2 ? e3 ? `${e3} ${t2}` : t2 : e3;
}
function ll() {
  return { failed: false, error: void 0 };
}
function ul(e3, t2) {
  e3.failed || (e3.error = t2), e3.failed = true;
}
function dl(e3, t2) {
  try {
    t2();
  } catch (t3) {
    ul(e3, t3);
  }
}
function fl(e3) {
  if (e3.failed) throw e3.error;
}
function pl(e3, t2) {
  if (!(!e3 || typeof e3 != `object` && typeof e3 != `function`)) try {
    let n2 = e3, r2 = Array.isArray(n2.suppressed) ? n2.suppressed : [];
    r2.push(t2), n2.suppressed !== r2 && Object.defineProperty(n2, "suppressed", { configurable: true, value: r2 });
  } catch {
  }
}
function ml(e3) {
  if (!e3 || typeof e3 != `object` || Array.isArray(e3)) return false;
  let t2 = e3;
  return Object.keys(t2).every((e4) => [`protocol`, `buildKey`, `fingerprint`].includes(e4)) && t2.protocol === 1 && typeof t2.buildKey == `string` && t2.buildKey.length > 0 && t2.buildKey.length <= 256 && typeof t2.fingerprint == `string` && t2.fingerprint.length > 0 && t2.fingerprint.length <= 256 && /^[A-Za-z0-9_-]+$/.test(t2.fingerprint);
}
function hl(e3, t2) {
  return e3.protocol === t2.protocol && e3.buildKey === t2.buildKey && e3.fingerprint === t2.fingerprint;
}
function gl(e3, t2) {
  try {
    e3.unmount(`construct-failed`);
  } catch (e4) {
    pl(t2, e4);
  }
}
var _l = 1;
function vl() {
  return `c${_l++}`;
}
function yl(e3, t2, n2, r2) {
  let i2 = ti(e3.props, n2[0]);
  if (!i2.present || !P(i2.value)) return false;
  let a2 = false, o2;
  return j(r2, () => gn(() => {
    let r3 = I(e3.props, n2[0]), i3 = a2 && !Object.is(o2, r3);
    o2 = r3, a2 = true, i3 && C(() => t2.apply(e3, n2[1], n2[2]));
  })), true;
}
function bl(e3, t2) {
  let n2 = `componentId` in t2 ? t2.values : t2[1] ?? [];
  if (Array.isArray(n2)) {
    for (let [r2, i2] of n2) {
      if (typeof r2 != `string`) throw Error(`eXact indexed resumption was not prepared for ${`componentId` in t2 ? t2.componentId : t2[0]}`);
      xl(e3, r2, i2);
    }
    return;
  }
  for (let [t3, r2] of Object.entries(n2)) xl(e3, t3, r2);
}
function xl(e3, t2, n2) {
  let r2 = t2.split(`.`);
  if (!r2.length || !r2.every(Sl)) throw Error(`Malformed eXact component resumption state path ${t2}`);
  let i2 = e3;
  for (let e4 of r2.slice(0, -1)) {
    let t3 = i2[e4];
    if (t3 && typeof t3 == `object` && !Array.isArray(t3)) i2 = t3;
    else {
      let t4 = {};
      i2[e4] = t4, i2 = t4;
    }
  }
  i2[r2.at(-1)] = n2;
}
function Sl(e3) {
  return e3.length > 0 && e3 !== `__proto__` && e3 !== `prototype` && e3 !== `constructor`;
}
var Cl = class {
  contextsValue;
  contextTokensValue;
  get contexts() {
    return this.contextsValue ??= /* @__PURE__ */ new Map();
  }
  get contextTokens() {
    return this.contextTokensValue ??= /* @__PURE__ */ new Map();
  }
};
function wl(e3, t2 = {}, n2, r2 = false) {
  return Br(e3, t2, jr, n2, r2);
}
function Tl(e3, t2, n2, r2 = false) {
  let i2 = { onMutation(n3, r3) {
    let i3 = t2();
    i3 && Ya(e3)?.publish({ kind: `state.change`, component: i3, path: n3 === void 0 ? `state` : `state.${String(n3)}`, attributes: Object.freeze({ operation: r3 }) });
  } };
  if (r2) {
    if (!El) throw Error(`Collection state requires the compiler-selected collection capability`);
    return El(n2, i2);
  }
  return wl(n2, i2);
}
var El;
function Dl(e3, t2, n2 = false, r2 = []) {
  let i2 = { readonly: true, passthroughKeys: [`children`, ...r2], onReadonlyWrite(e4) {
    throw TypeError(`Cannot write to readonly props.${String(e4)}`);
  } };
  if (n2) {
    if (!Ol) throw Error(`Collection props require the compiler-selected collection capability`);
    return Ol(e3, t2, i2);
  }
  return wl(t2, i2, e3, true);
}
var Ol, kl;
function Al() {
  return kl;
}
var jl = class extends Cl {
  type;
  parent;
  domain;
  id = vl();
  scope;
  state;
  props;
  ambientContexts;
  runtimeABI;
  renderStop;
  invalidate;
  errorFallback;
  inspection;
  mountedValue = false;
  activeValue = false;
  disposedValue = false;
  activityBlockers;
  renderFunctionValue = () => null;
  componentResumption;
  observedInputSlots;
  inputUpdates;
  constructor(e3, t2, n2, r2, i2, a2) {
    super(), this.type = e3, this.parent = n2, this.domain = i2, this.ambientContexts = r2, this.runtimeABI = a2.artifact.abi, this.inspection = Ya(i2), this.scope = A(void 0, (e4) => {
      W(this, U(e4, `reactive`, this, `watch`));
    }), this.state = Tl(i2, () => this, a2.artifact.state, !!(this.runtimeABI & 16)), this.props = Dl(t2, a2.artifact.props, !!(this.runtimeABI & 16), a2.artifact.opaqueProps), this.componentResumption = ro(this.domain, this.type), this.inputUpdates = `inputs` in a2.artifact ? a2.artifact.inputs : void 0, this.componentResumption && bl(this.state, this.componentResumption);
  }
  get mounted() {
    return this.mountedValue;
  }
  get renderFunction() {
    return this.renderFunctionValue;
  }
  beginRender() {
  }
  endRender() {
  }
  markMounted() {
    this.mountedValue || this.disposedValue || (this.mountedValue = true, this.inspection?.publish({ kind: `component.mount`, component: this }), this.handleMounted(), this.updateActivation());
  }
  setActivity(e3, t2, n2 = `activity`) {
    t2 ? (this.activityBlockers?.delete(e3), this.activityBlockers?.size || (this.activityBlockers = void 0)) : (this.activityBlockers ??= /* @__PURE__ */ new Set()).add(e3);
    let r2 = this.activityBlockers?.size ?? 0;
    this.inspection?.publish({ kind: `activity.change`, component: this, reason: n2, attributes: Object.freeze({ active: r2 === 0, blockers: r2 }) }), this.updateActivation(n2);
  }
  receiveProps(e3, t2, n2) {
    se(() => {
      let r2 = 0, i2 = 0, a2 = 0, o2 = this.inputUpdates?.bindings;
      for (let s2 = 0; s2 < e3.length; s2++) {
        let c2 = e3[s2];
        for (; o2 && a2 < o2.length && o2[a2][0] < s2; ) a2++;
        let l2;
        l2 = c2 === `children` && n2.length !== 0 ? Wr(this.props, s2, n2.length === 1 ? n2[0] : n2) : Object.prototype.hasOwnProperty.call(t2, c2) ? Wr(this.props, s2, t2[c2]) : Gr(this.props, s2);
        let u2 = o2?.[a2];
        l2 && u2?.[0] === s2 && (r2 |= u2[1], i2 |= u2[2], this.observeInputBinding(u2));
      }
      (r2 || i2) && this.inputUpdates.apply(this, r2, i2);
    }), this.inspection?.publish({ kind: `props.change`, component: this, path: `props` });
  }
  unmount(e3 = `unmount`) {
    if (this.disposedValue) return;
    this.inspection?.publish({ kind: `component.unmount`, component: this, reason: e3 }), this.deactivate(e3), this.disposedValue = true, this.mountedValue = false;
    let t2;
    try {
      this.renderStop?.();
    } catch (e4) {
      t2 = e4;
    }
    try {
      this.scope.stop();
    } catch (e4) {
      t2 === void 0 && (t2 = e4);
    }
    if (t2 !== void 0) throw t2;
  }
  initializeComponent(e3) {
    let t2 = this.componentResumption, n2 = t2 ? `componentId` in t2 ? t2.contexts : t2[2] ?? [] : void 0;
    try {
      if (this.inspection?.publish({ kind: `component.construct`, component: this }), !this.parent && Za(this.domain) && this.inspection?.publish({ kind: `hydration.activate`, component: this }), !this.parent && !this.ambientContexts?.has(ja.id) && this.contexts.set(ja.id, Yo()), t2 && n2 && (Array.isArray(n2) ? n2.length !== 0 : Object.keys(n2).length !== 0)) {
        let e4 = Al();
        if (!e4) throw Error(`Component context resumption requires the compiler-selected context capability`);
        e4.prepare(this, t2);
      }
      let r2 = to(this.domain, this.scope, e3);
      if (t2 && (bl(this.state, t2), this.inspection?.publish({ kind: `resumption.activate`, component: this })), typeof r2 != `function`) throw TypeError(`eXact runtime components must synchronously return their compiled render function`);
      this.renderFunctionValue = r2;
      for (let e4 of this.inputUpdates?.bindings ?? []) this.observeInputBinding(e4);
    } catch (e4) {
      throw gl(this, e4), e4;
    }
  }
  observeInputBinding(e3) {
    this.observedInputSlots?.has(e3[0]) || yl(this, this.inputUpdates, e3, this.scope) && (this.observedInputSlots ??= /* @__PURE__ */ new Set()).add(e3[0]);
  }
  handleMounted() {
  }
  updateActivation(e3 = `activity`) {
    if (this.disposedValue || !this.mountedValue || this.activityBlockers?.size) {
      this.deactivate(e3);
      return;
    }
    this.activate(e3);
  }
  activate(e3) {
    return !this.activeValue && (this.activeValue = true, this.inspection?.publish({ kind: `component.activate`, component: this, reason: e3 }), true);
  }
  deactivate(e3) {
    return this.activeValue ? (this.activeValue = false, this.inspection?.publish({ kind: `component.deactivate`, component: this, reason: e3 }), true) : false;
  }
};
function Ml(e3, t2) {
  for (let n2 = t2; n2; n2 = n2.parent) if (n2 === e3) throw Error(`Cannot create a component parent cycle`);
  e3.parent = t2;
}
var Nl = V(`render-program`), Pl = /* @__PURE__ */ Symbol.for(`@exactjs/target-operation/render-program`);
function Fl(e3) {
  let t2 = Nl.get(this);
  if (!t2) throw TypeError(`Render-program operation lost its compiler-issued payload`);
  return e3[Pl](this, t2);
}
function G(e3) {
  if (e3.version !== 2) throw TypeError(`Unsupported eXact render-program ABI; expected version 2`);
  return e3;
}
function K(e3, t2, n2, r2, i2) {
  let a2 = io(), o2 = Ro(Fl, { ...a2 ? { domain: a2 } : {} });
  return Nl.set(o2, { invocation: { program: e3, readers: t2, owner: n2, ...r2 ? { propertyWriter: r2 } : {} }, ...i2 ? { enhancement: i2 } : {}, ...a2 ? { domain: a2 } : {} }), o2;
}
function Il(e3) {
  return Ll(e3)?.invocation;
}
function Ll(e3) {
  return typeof e3 == `object` && e3 ? Nl.get(e3) : void 0;
}
function Rl(e3, t2) {
  return e3.eagerValues ? e3.eagerValues[t2] : typeof e3.readers == `function` ? e3.readers(t2) : e3.readers[t2]();
}
function zl(e3, t2, n2 = true) {
  let r2 = n2 ? io() : void 0;
  return Ac(on(r2 ? () => $a(r2, e3) : e3), t2, n2);
}
function Bl(e3) {
  return on(e3);
}
function Vl(e3) {
  let t2 = jl.prototype;
  for (let n2 of Reflect.ownKeys(e3)) {
    if (Object.hasOwn(t2, n2)) throw Error(`Component runtime surface already defines ${String(n2)}`);
    Object.defineProperty(t2, n2, e3[n2]);
  }
}
function Hl(e3) {
  Vl(e3);
}
var Ul = class extends jl {
  constructor(e3, t2, n2, r2, i2, a2) {
    super(e3, t2, n2, r2, i2, a2), this.initializeComponent(() => a2.artifact.instantiate.call(this, this.props));
  }
}, Wl = function(e3, t2, n2, r2, i2, a2) {
  return new Ul(this.instantiate, t2, e3, n2, r2, a2);
}, Gl = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i, Kl = /* @__PURE__ */ new Set([`action`, `formaction`, `href`, `src`, `xlink:href`, `xlinkhref`]), ql = `javascript:throw new Error('eXact has blocked a javascript: URL as a security precaution.')`;
function Jl(e3) {
  return Kl.has(e3.toLowerCase());
}
function Yl(e3, t2) {
  if (!Jl(e3) || t2 == null) return t2;
  let n2 = String(t2);
  return Gl.test(n2) ? ql : t2;
}
function Xl(e3, t2, n2) {
  mo(`trace`, `dom`, `patch`, t2, n2, e3.logger);
}
function q(e3) {
  if (!e3) return `none`;
  if (e3 instanceof Element) {
    let t2 = e3.id ? `#${e3.id}` : ``, n2 = typeof e3.className == `string` && e3.className ? `.${e3.className.split(/\s+/).filter(Boolean).join(`.`)}` : ``;
    return `${e3.tagName.toLowerCase()}${t2}${n2}`;
  }
  return e3.nodeName;
}
var Zl = /* @__PURE__ */ Symbol.for(`@exactjs/dom.foreign-child-capability.v1`);
function Ql() {
  let e3 = globalThis, t2 = e3[Zl];
  if (t2 !== void 0) {
    if (!t2 || typeof t2 != `object` || t2.abi !== 1) throw Error(`Incompatible eXact DOM foreign-child capability registry`);
    return t2;
  }
  let n2 = { abi: 1 };
  return e3[Zl] = n2, n2;
}
function $l() {
  return Ql().capability;
}
function eu(e3) {
  return $l()?.prepareProgramChildren?.(e3) ?? e3;
}
function J(e3, t2, n2, r2) {
  let i2 = r2?.parentNode === t2 ? r2 : null, a2 = tu(n2), o2 = a2[0], s2 = a2[a2.length - 1];
  if (o2.parentNode === t2 && s2.nextSibling === i2 && lu(a2)) {
    Xl(e3, `skip placement`, () => ({ reason: `mounted-range-already-before-cursor`, parent: q(t2), node: q(o2), before: q(i2) })), ou(e3, n2);
    return;
  }
  for (let n3 of a2) uu(e3, t2, n3, i2);
  ou(e3, n2);
}
function tu(e3) {
  let t2 = [], n2 = [{ mounted: e3, end: false }];
  for (; n2.length; ) {
    let e4 = n2.pop();
    if (e4.end) {
      e4.mounted.end && t2.push(e4.mounted.end);
      continue;
    }
    if (au(e4.mounted)) {
      n2.push({ mounted: e4.mounted.children[0], end: false });
      continue;
    }
    if (t2.push(e4.mounted.dom), e4.mounted.end && n2.push({ mounted: e4.mounted, end: true }), e4.mounted.rawNodes && t2.push(...e4.mounted.rawNodes), iu(e4.mounted)) for (let t3 = e4.mounted.children.length - 1; t3 >= 0; t3--) n2.push({ mounted: e4.mounted.children[t3], end: false });
  }
  return t2;
}
function nu(e3) {
  if (e3.end) return e3.end.nextSibling;
  let t2 = e3.children[e3.children.length - 1];
  return t2 ? ru(t2).nextSibling : e3.dom.nextSibling;
}
function ru(e3) {
  let t2 = e3;
  for (; !t2.end && iu(t2) && t2.children.length; ) t2 = t2.children[t2.children.length - 1];
  return t2.end ?? t2.dom;
}
function iu(e3) {
  return e3.textPresentation ? false : !!e3.end || e3.childRangeReceipt !== void 0 || e3.range === `item` || e3.range === `root` || e3.fragmentReceipt !== void 0 || e3.targetReceipt !== void 0 || e3.clientArtifact !== void 0 || $l()?.ownsChildDom?.(e3) === true;
}
function au(e3) {
  let t2 = e3.range === `item` && e3.children.length === 1 ? e3.children[0] : void 0;
  return !!t2 && e3.dom === t2.dom && e3.end === t2.end;
}
function ou(e3, t2) {
  let n2 = [{ mounted: t2 }];
  for (; n2.length; ) {
    let t3 = n2.pop(), r2 = t3.mounted;
    if (t3.mountCommit) {
      let t4 = r2.afterPlacement;
      t4 && r2.afterPlacementPhase === `mount` && su(e3, r2.dom) && (r2.afterPlacement = void 0, r2.afterPlacementPhase = void 0, t4());
      continue;
    }
    r2.afterPlacementPhase === `mount` && n2.push({ mounted: r2, mountCommit: true });
    for (let e4 = r2.children.length - 1; e4 >= 0; e4--) n2.push({ mounted: r2.children[e4] });
    let i2 = r2.afterPlacement, a2 = r2.afterPlacementPhase;
    !i2 || a2 === `mount` || (r2.afterPlacement = void 0, r2.afterPlacementPhase = void 0, a2 === `retention` ? (e3.placementRetentions ??= /* @__PURE__ */ new Map()).set(r2, i2) : i2());
  }
}
function su(e3, t2) {
  if (e3.container.contains(t2) || t2.isConnected) return true;
  for (let n2 of e3.portalTargets) if (n2.contains(t2)) return true;
  return false;
}
function cu(e3) {
  for (; e3.placementRetentions?.size; ) {
    let t2 = [...e3.placementRetentions.values()];
    e3.placementRetentions.clear();
    for (let e4 of t2) e4();
  }
}
function lu(e3) {
  for (let t2 = 0; t2 < e3.length - 1; t2++) if (e3[t2].nextSibling !== e3[t2 + 1]) return false;
  return true;
}
function uu(e3, t2, n2, r2) {
  let i2 = r2?.parentNode === t2 ? r2 : null;
  if (n2 === i2) {
    Xl(e3, `skip placement`, () => ({ reason: `node-is-cursor`, parent: q(t2), node: q(n2), before: q(i2) }));
    return;
  }
  if (n2.parentNode === t2 && n2.nextSibling === i2) {
    Xl(e3, `skip placement`, () => ({ reason: `already-before-cursor`, parent: q(t2), node: q(n2), before: q(i2) }));
    return;
  }
  Xl(e3, `place node`, () => ({ parent: q(t2), node: q(n2), before: q(i2), active: q(document.activeElement) })), t2.insertBefore(n2, i2);
}
var du = 1e5;
function fu(e3) {
  return { limit: Number.isSafeInteger(e3) && e3 > 0 ? e3 : du, used: 0 };
}
function pu(e3) {
  if (++e3.used > e3.limit) throw new mu(e3.limit);
}
var mu = class extends Error {
  limit;
  constructor(e3) {
    super(`eXact DOM traversal exceeds the configured maximum of ${e3} nodes`), this.limit = e3, this.name = `DomTraversalLimitError`;
  }
};
function hu(e3, t2, n2 = {}) {
  let r2 = n2.budget ?? fu(n2.maxNodes), i2 = 0, a2 = (e4) => {
    pu(r2), i2++, t2(e4);
  };
  n2.includeRoot !== false && a2(e3);
  let o2 = e3.nodeType === 9 ? e3 : e3.ownerDocument;
  if (!o2) throw Error(`Cannot traverse a DOM node without an owner document`);
  let s2 = o2.createTreeWalker(e3, 4294967295);
  for (; s2.nextNode(); ) a2(s2.currentNode);
  return i2;
}
function gu(e3, t2, n2) {
  let r2 = bu(e3.container, t2.id, e3.maxTreeNodes) ?? document.createElement(`span`);
  return r2.setAttribute(`data-exact-server-slot`, t2.id), r2 instanceof HTMLElement && (r2.style.display = `contents`), { serverSlotReceipt: t2, dom: r2, scope: n2, children: [] };
}
function _u(e3, t2, n2, r2) {
  let i2 = t2[n2];
  if (!(!(i2 instanceof Element) || i2.getAttribute(`data-exact-server-slot`) !== e3.id)) return { mounted: { serverSlotReceipt: e3, dom: i2, scope: r2, children: [] }, next: n2 + 1 };
}
function vu(e3, t2) {
  let n2 = t2.serverSlotReceipt?.id;
  if (n2 === void 0) return;
  let r2 = yu(e3, n2);
  !r2 || r2 === t2.dom || (t2.dom = r2);
}
function yu(e3, t2) {
  for (let n2 of Array.from(e3.childNodes)) if (n2 instanceof Element && n2.getAttribute(`data-exact-server-slot`) === t2) return n2;
}
function bu(e3, t2, n2) {
  let r2;
  return hu(e3, (e4) => {
    !r2 && e4 instanceof Element && e4.getAttribute(`data-exact-server-slot`) === t2 && (r2 = e4);
  }, { maxNodes: n2 }), r2;
}
var xu = 512, Su = 1024, Cu = 1e5, wu = class extends Error {
  constructor(e3) {
    super(`eXact DOM tree exceeds the configured maximum depth of ${e3}`), this.name = `DomTreeDepthError`;
  }
}, Tu = class extends Error {
  constructor(e3) {
    super(`eXact DOM update exceeds the configured maximum of ${e3} render values`), this.name = `DomTreeWorkError`;
  }
};
function Eu(e3) {
  return Number.isSafeInteger(e3) && e3 > 0 ? Math.min(e3, Su) : xu;
}
function Du(e3) {
  return Number.isSafeInteger(e3) && e3 > 0 ? e3 : Cu;
}
function Ou(e3, t2) {
  let n2 = e3.workDepth++ === 0;
  n2 && (e3.traversedNodes = 0);
  try {
    return t2();
  } finally {
    e3.workDepth--, n2 && cu(e3);
  }
}
function ku(e3) {
  if (e3.workBudget && pu(e3.workBudget), e3.interactionWork && e3.interactionWork.traversedNodes++, ++e3.traversedNodes > e3.maxTreeNodes) throw new Tu(e3.maxTreeNodes);
}
function Au(e3) {
  return e3 instanceof wu || e3 instanceof Tu;
}
function ju(e3, t2) {
  if (e3.traversalDepth++, e3.traversalDepth > e3.maxTreeDepth) throw e3.traversalDepth--, new wu(e3.maxTreeDepth);
  try {
    return t2();
  } finally {
    e3.traversalDepth--;
  }
}
var Mu = /* @__PURE__ */ Symbol.for(`@exactjs/dom.runtime-state`), Y = (() => {
  let e3 = globalThis;
  return e3[Mu] ??= { roots: /* @__PURE__ */ new WeakMap(), eventHandlers: /* @__PURE__ */ new WeakMap(), directEventHandlers: /* @__PURE__ */ new WeakMap(), elementOwners: /* @__PURE__ */ new WeakMap(), nodeOwners: /* @__PURE__ */ new WeakMap(), propBindings: /* @__PURE__ */ new WeakMap(), componentMounts: /* @__PURE__ */ new WeakMap(), inspectableRoots: /* @__PURE__ */ new Set(), rootInspectionReferences: /* @__PURE__ */ new WeakMap() };
})(), Nu = Y.roots, Pu = Y.eventHandlers, Fu = Y.directEventHandlers, Iu = Y.elementOwners, Lu = Y.nodeOwners, Ru = Y.propBindings, zu = Y.componentMounts;
function Bu(e3 = {}) {
  return Y.inspectionOwnerFactory?.(e3);
}
function Vu(e3) {
  if (Y.rootInspectionReferences.has(e3)) return;
  let t2 = new WeakRef(e3);
  Y.rootInspectionReferences.set(e3, t2), Y.inspectableRoots.add(t2);
}
function Hu(e3) {
  let t2 = Y.rootInspectionReferences.get(e3);
  t2 && (Y.inspectableRoots.delete(t2), Y.rootInspectionReferences.delete(e3));
}
function Uu(e3, t2) {
  Iu.set(e3, t2);
}
function Wu(e3) {
  Iu.delete(e3);
}
function Gu(e3, t2) {
  Lu.set(e3, t2);
}
function Ku(e3) {
  Lu.delete(e3);
}
function qu(e3) {
  let t2 = e3;
  for (; t2; ) {
    let e4 = Iu.get(t2);
    if (e4) return e4;
    t2 = t2.parentElement;
  }
}
function Ju(e3, t2) {
  if (e3.focusTransactionDepth > 0) {
    e3.focusTransactionDepth++;
    try {
      return t2();
    } finally {
      e3.focusTransactionDepth--;
    }
  }
  e3.focusTransactionDepth = 1, e3.focusSnapshot = Yu();
  try {
    let n2 = t2();
    return Xu(e3, e3.focusSnapshot), n2;
  } finally {
    e3.focusSnapshot = void 0, e3.focusTransactionDepth = 0;
  }
}
function Yu() {
  let e3 = document.activeElement;
  if (!(!(e3 instanceof HTMLElement) || e3 === document.body)) return { active: e3, inputSelection: e3 instanceof HTMLInputElement || e3 instanceof HTMLTextAreaElement ? { start: e3.selectionStart, end: e3.selectionEnd, direction: e3.selectionDirection } : void 0, documentSelection: e3.isContentEditable ? Zu(e3) : void 0 };
}
function Xu(e3, t2) {
  if (!t2) return;
  let { active: n2, inputSelection: r2, documentSelection: i2 } = t2;
  n2.isConnected && document.activeElement === document.body && (Xl(e3, `restore focus`, () => ({ active: q(n2), bodyOwnsFocus: document.activeElement === document.body })), n2.focus({ preventScroll: true })), n2.isConnected && document.activeElement === n2 && (r2 && (n2 instanceof HTMLInputElement || n2 instanceof HTMLTextAreaElement) && r2.start !== null && r2.end !== null ? n2.setSelectionRange(r2.start, r2.end, r2.direction ?? void 0) : i2 && Qu(n2, i2));
}
function Zu(e3) {
  let t2 = document.getSelection();
  if (!t2?.rangeCount) return;
  let n2 = t2.getRangeAt(0);
  if (!(!e3.contains(n2.startContainer) || !e3.contains(n2.endContainer))) return { start: $u(e3, n2.startContainer), startOffset: n2.startOffset, end: $u(e3, n2.endContainer), endOffset: n2.endOffset };
}
function Qu(e3, t2) {
  let n2 = ed(e3, t2.start), r2 = ed(e3, t2.end);
  if (!(!n2 || !r2)) try {
    let e4 = document.createRange();
    e4.setStart(n2, Math.min(t2.startOffset, td(n2))), e4.setEnd(r2, Math.min(t2.endOffset, td(r2)));
    let i2 = document.getSelection();
    i2?.removeAllRanges(), i2?.addRange(e4);
  } catch {
  }
}
function $u(e3, t2) {
  let n2 = [];
  for (let r2 = t2; r2 && r2 !== e3; r2 = r2.parentNode) {
    if (!r2.parentNode) return [];
    n2.unshift(Array.prototype.indexOf.call(r2.parentNode.childNodes, r2));
  }
  return n2;
}
function ed(e3, t2) {
  let n2 = e3;
  for (let e4 of t2) n2 = n2?.childNodes[e4];
  return n2;
}
function td(e3) {
  return e3.nodeType === Node.TEXT_NODE ? e3.textContent?.length ?? 0 : e3.childNodes.length;
}
var nd = /* @__PURE__ */ new WeakMap(), rd = new Set(`abort.blur.cancel.canplay.canplaythrough.close.cuechange.durationchange.emptied.ended.error.focus.gotpointercapture.invalid.load.loadeddata.loadedmetadata.loadstart.lostpointercapture.mouseenter.mouseleave.pause.play.playing.pointerenter.pointerleave.progress.ratechange.resize.scroll.seeked.seeking.stalled.suspend.timeupdate.toggle.volumechange.waiting`.split(`.`));
function id(e3) {
  return rd.has(e3);
}
function ad(e3, t2, n2 = e3.container) {
  let r2 = e3.delegated.get(n2);
  if (r2 || (r2 = /* @__PURE__ */ new Map(), e3.delegated.set(n2, r2)), r2.has(t2)) return;
  let i2 = (r3) => {
    pd(r3, n2, (n3) => {
      let i3 = Pu.get(n3)?.get(t2);
      if (i3) {
        let a2 = i3[0], o2 = i3[1], s2 = n3, c2 = !!(o2 & 2);
        Ju(e3, () => {
          try {
            let n4 = qu(s2);
            Us(n4, sd(e3, n4, () => c2 ? a2.call(s2) : md(a2, s2, r3), !!(o2 & 1)), `event`, t2);
          } catch (e4) {
            let n4 = qu(s2);
            W(n4, U(e4, `event`, n4, t2));
          }
        });
      }
      return !r3.cancelBubble;
    });
  };
  n2.addEventListener(t2, i2), r2.set(t2, i2);
}
function od(e3, t2, n2, r2, i2 = false) {
  return t2 ? i2 || !ps(t2) ? _s(t2, `event`, dd, `interactive`, n2, r2, cd(e3)) : hs(t2, `event`, dd(t2), `interactive`, new AbortController(), (e4) => (r2?.(e4), n2())) : n2();
}
function sd(e3, t2, n2, r2 = false) {
  let i2, a2 = t2 !== void 0 && !ps(t2);
  try {
    let o2 = We(`interactive`, () => (r2 ? ce : se)(() => t2 ? r2 || a2 ? _s(t2, `event`, dd, `interactive`, n2, (t3) => {
      i2 = t3, e3.interactionWork = { reconciliations: 0, traversedNodes: 0 };
    }, cd(e3)) : gs(t2, `event`, dd(t2), `interactive`, new AbortController(), n2, (t3) => {
      i2 = t3, e3.interactionWork = { reconciliations: 0, traversedNodes: 0 };
    }, cd(e3)) : n2()));
    return ms(i2, `handler-complete`), qe(`interactive`), ms(i2, `feedback-committed`, () => ({ reconciliations: e3.interactionWork?.reconciliations ?? 0, traversedNodes: e3.interactionWork?.traversedNodes ?? 0 })), o2;
  } finally {
    e3.interactionWork = void 0;
  }
}
function cd(e3) {
  let t2 = e3.componentLogging;
  return t2 && !t2.componentOverride && t2.logger === void 0 ? false : void 0;
}
function ld(e3) {
  return e3.startsWith(`__exactClosedInteraction:`) || e3.startsWith(`__exactDirectInteraction:`) ? e3.slice(25) : e3;
}
function ud(e3) {
  let t2 = e3.toLowerCase(), n2 = t2 === `onlostpointercapture` || t2 === `ongotpointercapture`, r2 = t2.endsWith(`capture`) && !n2, i2 = t2.slice(2, r2 ? -7 : void 0);
  return { type: i2 === `doubleclick` ? `dblclick` : i2, capture: r2 };
}
function dd(e3) {
  let t2 = (nd.get(e3) ?? 0) + 1;
  return nd.set(e3, t2), t2;
}
function fd(e3) {
  for (let [t2, n2] of e3.delegated) for (let [e4, r2] of n2) t2.removeEventListener(e4, r2);
  e3.delegated.clear(), e3.portalTargets.clear();
}
function pd(e3, t2, n2) {
  let r2 = typeof e3.composedPath == `function` ? e3.composedPath() : [], i2 = r2.indexOf(t2);
  if (i2 >= 0) {
    for (let e4 = 0; e4 <= i2; e4++) {
      let t3 = r2[e4];
      if (t3 instanceof Element && !n2(t3)) return;
    }
    return;
  }
  let a2 = hd(e3.target);
  for (; a2; ) {
    if (!n2(a2)) return;
    if (a2 === t2) break;
    a2 = a2.parentElement;
  }
}
function md(e3, t2, n2) {
  let r2 = Object.getOwnPropertyDescriptor(n2, `currentTarget`);
  Object.defineProperty(n2, "currentTarget", { configurable: true, value: t2 });
  try {
    return e3.call(t2, n2);
  } finally {
    r2 ? Object.defineProperty(n2, "currentTarget", r2) : delete n2.currentTarget;
  }
}
function hd(e3) {
  return e3 instanceof Element ? e3 : e3 instanceof Node ? e3.parentElement : null;
}
function gd(e3) {
  return e3.length > 2 && (e3[0] === `o` || e3[0] === `O`) && (e3[1] === `n` || e3[1] === `N`);
}
function _d(e3) {
  let t2 = e3[0];
  if (t2 !== `i` && t2 !== `I` && t2 !== `o` && t2 !== `O` && t2 !== `d` && t2 !== `D`) return;
  let n2 = e3.toLowerCase();
  if (n2 === `innerhtml` || n2 === `outerhtml` || n2 === `dangerouslysetinnerhtml`) throw TypeError(`Native eXact does not support ${e3}; use unsafeHtml() with explicit root opt-in.`);
}
function vd(e3) {
  if (e3 != null && e3 !== false && typeof e3 != `function`) throw TypeError(`Native eXact event handlers must be functions; inline event strings are not supported.`);
}
function yd(e3) {
  return e3.length === 6 && e3.toLowerCase() === `srcdoc`;
}
var bd;
function xd() {
  return bd;
}
function Sd(e3, t2) {
  let n2 = Ru.get(e3);
  if (!n2) return;
  let r2 = n2.get(t2);
  r2 && (r2(), n2.delete(t2));
}
function Cd(e3, t2) {
  let n2 = Ru.get(e3);
  n2?.delete(t2), n2 && n2.size === 0 && Ru.delete(e3);
}
function wd(e3, t2, n2) {
  let r2 = Ru.get(e3);
  r2 || (r2 = /* @__PURE__ */ new Map(), Ru.set(e3, r2)), r2.set(t2, n2);
}
function Td(e3) {
  return e3.replace(/[A-Z]/g, (e4) => `-${e4.toLowerCase()}`);
}
function Ed(e3, t2, n2, r2) {
  let i2, a2, o2;
  return vn(() => {
    let n3 = F(t2);
    if (n3 === false || n3 == null) {
      e3.hasAttribute(`style`) && e3.removeAttribute(`style`), i2 = void 0, a2 = void 0, o2 = void 0;
      return;
    }
    if (typeof n3 == `string`) {
      (a2 !== n3 || e3.style.cssText !== n3) && (e3.style.cssText = n3), i2 = void 0, a2 = n3, o2 = void 0;
      return;
    }
    if (!n3 || typeof n3 != `object`) {
      e3.hasAttribute(`style`) && e3.removeAttribute(`style`), i2 = void 0, a2 = void 0, o2 = void 0;
      return;
    }
    a2 = void 0;
    let r3 = i2, s2 = o2 ??= /* @__PURE__ */ new Map(), c2 = /* @__PURE__ */ new Set();
    for (let [t3, r4] of Object.entries(n3)) {
      let n4 = F(r4), i3 = Td(t3);
      if (c2.add(i3), n4 == null || n4 === false) (s2.has(i3) || e3.style.getPropertyValue(i3)) && e3.style.removeProperty(i3), s2.delete(i3);
      else {
        let t4 = String(n4);
        (s2.get(i3) !== t4 || e3.style.getPropertyValue(i3) !== t4) && e3.style.setProperty(i3, t4), s2.set(i3, t4);
      }
    }
    for (let t3 of r3 ?? []) c2.has(t3) || (e3.style.removeProperty(t3), s2.delete(t3));
    i2 = c2;
  }, void 0, { scope: n2, onRelease: r2 });
}
function Dd(e3, t2, n2, r2, i2, a2 = true) {
  let o2 = () => {
    for (let a3 of Object.keys(n2)) a3 in r2 || Ad(e3, t2, a3, void 0, n2[a3], i2);
    for (let [a3, o3] of Object.entries(r2)) Object.is(n2[a3], o3) || Ad(e3, t2, a3, o3, n2[a3], i2);
  };
  a2 ? Ju(e3, o2) : o2();
}
function Od(e3) {
  for (let t2 of Ru.get(e3)?.values() ?? []) t2();
  Ru.delete(e3), Pu.delete(e3);
  for (let t2 of Fu.get(e3)?.values() ?? []) e3.removeEventListener(t2.type, t2.listener, t2.capture);
  Fu.delete(e3);
}
function kd(e3) {
  let t2 = Fu.get(e3), n2 = t2?.get(`__exactBindInput`) ?? t2?.get(`__exactBindChange`) ?? t2?.get(`__exactBindToggle`) ?? t2?.get(`__exactBindModalToggle`) ?? t2?.get(`__exactBindModalClose`);
  if (!n2) return false;
  let r2 = new Event(n2.type, { bubbles: false, cancelable: false });
  return Object.defineProperties(r2, { target: { configurable: true, value: e3 }, currentTarget: { configurable: true, value: e3 } }), n2.listener(r2), true;
}
function Ad(e3, t2, n2, r2, i2, a2) {
  if (n2 === `children`) return;
  if (_d(n2), yd(n2) && (n2 = `srcdoc`), Sd(t2, n2), n2 === `ref`) {
    i2 && i2 !== r2 && i2.fulfill(void 0), r2 && il(r2, t2), r2?.fulfill(t2);
    return;
  }
  if (jd(n2)) {
    Pd(e3, t2, n2, n2 === `__exactBindInput` ? `input` : n2 === `__exactBindToggle` || n2 === `__exactBindModalToggle` ? `toggle` : n2 === `__exactBindModalClose` ? `close` : `change`, r2, false);
    return;
  }
  if (n2 === `__exactModalOpen`) {
    if (r2 === void 0) return;
    let e4 = xd();
    if (!e4) throw Error(`Modal binding is unavailable because this artifact did not include the modal capability`);
    let i3 = e4.bind(t2, r2, a2, () => Cd(t2, n2));
    i3 && wd(t2, n2, i3);
    return;
  }
  let o2 = n2.startsWith(`__exactClosedInteraction:`), s2 = o2 || n2.startsWith(`__exactDirectInteraction:`), c2 = ld(n2);
  if (gd(c2)) {
    vd(r2);
    let { type: i3, capture: a3 } = ud(c2);
    if (o2 || a3 || id(i3)) {
      Pd(e3, t2, n2, i3, r2, a3, s2, o2);
      return;
    }
    let l3 = Pu.get(t2);
    if (l3 || (l3 = /* @__PURE__ */ new Map(), Pu.set(t2, l3)), typeof r2 == `function`) {
      let n3 = r2, a4 = !!s2 | (o2 ? 2 : 0), c3 = l3.get(i3);
      (!c3 || c3[0] !== n3 || c3[1] !== a4) && l3.set(i3, [n3, a4]), ad(e3, i3, Fd(e3, t2));
    } else l3.delete(i3);
    return;
  }
  if (n2 === `style`) {
    i2 !== r2 && t2.removeAttribute(`style`);
    let e4 = Ed(t2, r2, a2, () => Cd(t2, n2));
    e4 && wd(t2, n2, e4);
    return;
  }
  if (Sd(t2, n2), !Nd(n2, r2)) {
    Md(e3, t2, n2, r2);
    return;
  }
  let l2 = vn(() => Ju(e3, () => Md(e3, t2, n2, r2)), void 0, { scope: a2, onRelease: () => Cd(t2, n2) });
  l2 && wd(t2, n2, l2);
}
function jd(e3) {
  return e3 === `__exactBindInput` || e3 === `__exactBindChange` || e3 === `__exactBindToggle` || e3 === `__exactBindModalToggle` || e3 === `__exactBindModalClose`;
}
function Md(e3, t2, n2, r2) {
  let i2 = F(r2);
  if (i2 === false || i2 == null) {
    Bd(t2, n2);
    return;
  }
  Rd(e3, t2, n2, Yl(n2, n2 === `srcdoc` || n2 === `srcDoc` ? Id(e3, i2) : n2 === `class` || n2 === `className` ? ol(i2) : i2));
}
function Nd(e3, t2) {
  return P(t2) ? true : e3 === `class` || e3 === `className` ? typeof t2 == `object` && !!t2 : (e3 === `srcdoc` || e3 === `srcDoc`) && P(Ld(t2)?.value);
}
function Pd(e3, t2, n2, r2, i2, a2, o2 = false, s2 = false) {
  let c2 = Fu.get(t2)?.get(n2);
  if (c2) {
    t2.removeEventListener(c2.type, c2.listener, c2.capture);
    let e4 = Fu.get(t2);
    e4?.delete(n2), e4 && !e4.size && Fu.delete(t2);
  }
  if (typeof i2 != `function`) return;
  let l2 = i2, u2 = (n3) => Ju(e3, () => {
    try {
      let i3 = qu(t2), a3 = () => s2 ? l2.call(t2) : l2.call(t2, n3);
      Us(i3, s2 ? sd(e3, i3, a3, true) : se(() => od(e3, i3, a3, void 0, o2)), `event`, r2);
    } catch (e4) {
      let n4 = qu(t2);
      W(n4, U(e4, `event`, n4, r2));
    }
  }), d2 = { type: r2, listener: u2, capture: a2 }, f2 = Fu.get(t2);
  f2 || (f2 = /* @__PURE__ */ new Map(), Fu.set(t2, f2)), f2.set(n2, d2), t2.addEventListener(r2, u2, a2);
}
function Fd(e3, t2) {
  if (e3.eventContainer) return e3.eventContainer;
  if (e3.container.contains(t2)) return e3.container;
  for (let n2 of e3.portalTargets) if (n2.contains(t2)) return n2;
  return e3.container;
}
function Id(e3, t2) {
  let n2 = Gc(t2), r2 = n2 ? void 0 : Ld(t2);
  if (!n2 && !r2) throw Error(`Native eXact iframe srcdoc requires unsafeHtml() and explicit allowUnsafeHtml root opt-in.`);
  if (!e3.allowUnsafeHtml) throw Error(`unsafeHtml() used for iframe srcdoc requires allowUnsafeHtml: true on the native eXact render or hydration root.`);
  let i2 = String(F(n2?.value ?? r2?.value) ?? ``);
  return e3.onUnsafeHtml?.({ characters: i2.length }), i2;
}
function Ld(e3) {
  return $l()?.unsafeHtmlValue?.(e3);
}
function Rd(e3, t2, n2, r2) {
  let i2 = Vd(n2);
  if (i2 === `defaultValue` && Hd(t2)) {
    e3 && Xl(e3, `skip focused defaultValue`, () => ({ element: q(t2), value: r2 }));
    return;
  }
  if (i2 in t2) try {
    let n3 = t2;
    if (i2 === `value` && t2 instanceof HTMLSelectElement && t2.multiple) {
      let e4 = new Set(Array.isArray(r2) ? r2.map(String) : r2 == null ? [] : [String(r2)]);
      for (let n4 of Array.from(t2.options)) n4.selected !== e4.has(n4.value) && (n4.selected = e4.has(n4.value));
      return;
    }
    if (i2 === `value` && t2 instanceof HTMLInputElement && r2 instanceof Date) {
      let e4 = Number.isNaN(r2.getTime()) ? null : r2;
      (t2.valueAsDate?.getTime() ?? null) !== (e4?.getTime() ?? null) && (t2.valueAsDate = e4);
      return;
    }
    if (Object.is(n3[i2], r2)) {
      zd(t2, i2, r2);
      return;
    }
    (i2 === `value` || i2 === `defaultValue`) && e3 && Xl(e3, `set form value prop`, () => ({ element: q(t2), property: i2, active: q(document.activeElement), value: r2 })), n3[i2] = r2, zd(t2, i2, r2);
    return;
  } catch {
  }
  let a2 = String(r2);
  t2.getAttribute(i2) !== a2 && t2.setAttribute(i2, a2);
}
function zd(e3, t2, n2) {
  typeof n2 == `boolean` && (n2 ? e3.hasAttribute(t2) || e3.setAttribute(t2, ``) : e3.hasAttribute(t2) && e3.removeAttribute(t2));
}
function Bd(e3, t2) {
  let n2 = Vd(t2);
  if (n2 in e3) {
    let t3 = e3[n2];
    try {
      typeof t3 == `boolean` ? t3 && (e3[n2] = false) : typeof t3 == `string` && t3 !== `` && (e3[n2] = ``);
    } catch {
    }
  }
  e3.removeAttribute(n2);
}
function Vd(e3) {
  return e3 === `className` ? `class` : e3 === `commandFor` ? `commandfor` : e3;
}
function Hd(e3) {
  return document.activeElement === e3 && (e3 instanceof HTMLInputElement || e3 instanceof HTMLTextAreaElement);
}
var Ud = /* @__PURE__ */ new WeakMap();
function Wd(e3, t2, n2 = true, r2 = `update`) {
  let i2 = Kd(e3), a2 = i2.explicit?.current ?? t2;
  i2.state.current !== a2 && (i2.state.current = a2, i2.state.generation++, i2.state.introduction = a2 ? r2 : void 0, i2.state.release = void 0), i2.state.presented = a2 !== void 0 && n2;
}
function Gd(e3) {
  let t2 = Ud.get(e3);
  t2 && (t2.state.current = void 0, t2.state.introduction = void 0, t2.state.presented = false, t2.state.release = void 0), Ud.delete(e3);
}
function Kd(e3) {
  let t2 = Ud.get(e3);
  if (t2) return t2;
  let n2 = { lifecycle: void 0, state: { current: void 0, generation: 0, introduction: void 0, presented: false, release: void 0 } };
  return Ud.set(e3, n2), n2;
}
function qd(e3, t2 = true, n2 = `update`) {
  let r2 = zu.get(e3), i2 = r2 ? Jd(r2) : void 0, a2 = r2 ? $d(r2) : void 0;
  r2 && (r2.componentRootCache = { target: i2, host: a2 }), Wd(e3, i2 ?? a2 ?? (r2 ? Xd(r2) : void 0), t2, n2);
}
function Jd(e3) {
  if (e3.targetReceipt) {
    let t2 = e3.targetBoundary?.selected;
    return t2 ? tf(t2) : $d(e3) ?? Xd(e3);
  }
  for (let t2 of e3.children) {
    if (t2.instance) continue;
    let e4 = Jd(t2);
    if (e4) return e4;
  }
}
function Yd(e3, t2) {
  if (e3.textPresentation) {
    t2.push(e3.textPresentation);
    return;
  }
  if (e3.scalar || e3.intrinsicReceipt || e3.renderProgram) {
    t2.push(e3.renderProgram?.programRoot ?? e3.dom);
    return;
  }
  e3.rawNodes && t2.push(...e3.rawNodes);
  for (let n2 of e3.children) Yd(n2, t2);
}
function Xd(e3) {
  let t2 = [];
  if (Yd(e3, t2), t2.length === 1 && t2[0] instanceof Text) return t2[0];
  if (!(!t2.length && !ef(e3))) return e3.componentRootRange ??= Object.freeze({ kind: `range`, get nodes() {
    let t3 = [];
    return Yd(e3, t3), t3;
  } });
}
function Zd(e3) {
  return e3.initialCommitComplete ? `update` : e3.mode === `hydrated` || e3.mode === `document` ? `hydration` : `initial`;
}
function Qd(e3) {
  Gd(e3);
}
function $d(e3) {
  if ((e3.intrinsicReceipt || e3.renderProgram) && (e3.renderProgram?.programRoot ?? e3.dom) instanceof Element) return e3.renderProgram?.programRoot ?? e3.dom;
  if (!e3.scalar) for (let t2 of e3.children) {
    if (t2.instance && t2.componentRootCache) {
      if (t2.componentRootCache.host) return t2.componentRootCache.host;
      continue;
    }
    let e4 = $d(t2);
    if (e4) return e4;
  }
}
function ef(e3) {
  return e3.fragmentReceipt !== void 0 || e3.children.some(ef);
}
function tf(e3) {
  return e3.fragmentReceipt ? e3.fragmentReceipt.presentation?.hosts.length ? $d(e3) : Xd(e3) : e3.renderProgram?.programRoot ?? e3.dom;
}
var nf = /* @__PURE__ */ Symbol.for(`@exactjs/dom.target-capability.v2`);
function rf() {
  return of().capability;
}
function af() {
  let e3 = rf();
  if (!e3) throw Error(`Target rendering is unavailable because this artifact did not include the DOM capability`);
  return e3;
}
function of() {
  let e3 = globalThis, t2 = e3[nf];
  if (t2 !== void 0) {
    if (t2.abi !== 2) throw Error(`Incompatible eXact target DOM capability registry`);
    return t2;
  }
  let n2 = { abi: 2 };
  return e3[nf] = n2, n2;
}
function sf(e3, t2, n2) {
  let r2 = rf();
  if (!r2) throw Error(`Target rendering is unavailable because this artifact did not include the DOM capability`);
  r2.refreshBoundary(e3, t2, n2);
}
function cf(e3, t2) {
  rf()?.refreshDependents(e3, t2);
}
function lf(e3, t2, n2, r2) {
  let i2 = rf();
  i2 ? i2.updateIntrinsic(e3, t2, n2, r2) : t2.dom instanceof Element && Dd(e3, t2.dom, n2, r2, t2.scope);
}
function uf(e3) {
  rf()?.clearIntrinsic(e3);
}
var df = ll, ff = ul, X = dl, pf = fl;
function mf(e3) {
  let t2 = df();
  for (let n2 of e3) X(t2, () => Z(n2));
  pf(t2);
}
function hf(e3, t2) {
  let n2 = df();
  X(n2, () => Z(t2)), X(n2, () => gf(e3, t2)), pf(n2);
}
function Z(e3) {
  let t2 = [e3], n2 = df();
  for (; t2.length; ) {
    let e4 = t2.pop();
    if (e4) {
      e4.suspensionRegistration?.cancel(), e4.suspensionRegistration = void 0, X(n2, () => e4.scope.stop()), t2.push(e4, void 0);
      for (let n3 = (e4.suspense?.candidate?.children.length ?? 0) - 1; n3 >= 0; n3--) t2.push(e4.suspense.candidate.children[n3]);
      for (let n3 = e4.children.length - 1; n3 >= 0; n3--) t2.push(e4.children[n3]);
      continue;
    }
    let r2 = t2.pop();
    r2.instance && (zu.delete(r2.instance), X(n2, () => {
      let e5 = r2.clientArtifact;
      e5 ? e5.dispose(r2.instance, `dom-unmount`) : r2.instance.unmount();
    }), X(n2, () => Qd(r2.instance))), r2.targetBoundary?.release && X(n2, r2.targetBoundary.release), r2.stop && X(n2, r2.stop), r2.dom instanceof Element && (X(n2, () => uf(r2)), X(n2, () => Od(r2.dom)), X(n2, () => Wu(r2.dom))), X(n2, () => Ku(r2.dom)), r2.end && X(n2, () => Ku(r2.end));
    let i2 = r2.intrinsicReceipt?.props.ref;
    i2 && typeof i2.fulfill == `function` && X(n2, () => i2.fulfill(void 0));
  }
  pf(n2);
}
function gf(e3, t2) {
  let n2 = [{ mounted: t2, parent: e3, complete: false }], r2 = df();
  for (; n2.length; ) {
    let e4 = n2.pop();
    if (!e4.complete) {
      n2.push({ ...e4, complete: true });
      let t3 = e4.mounted.portalTarget ?? e4.parent;
      for (let r3 = e4.mounted.children.length - 1; r3 >= 0; r3--) n2.push({ mounted: e4.mounted.children[r3], parent: t3, complete: false });
      continue;
    }
    e4.mounted.dom.parentNode === e4.parent && X(r2, () => e4.parent.removeChild(e4.mounted.dom));
    for (let t3 of e4.mounted.rawNodes ?? []) t3.parentNode === e4.parent && X(r2, () => e4.parent.removeChild(t3));
    e4.mounted.end?.parentNode === e4.parent && X(r2, () => e4.parent.removeChild(e4.mounted.end));
  }
  pf(r2);
}
var _f = /* @__PURE__ */ Symbol.for(`@exactjs/dom.enhancement-capability.v2`);
function vf() {
  let e3 = globalThis, t2 = e3[_f];
  if (t2 !== void 0) {
    if (!xf(t2)) throw Error(`Incompatible eXact DOM enhancement capability registry in this realm`);
    return t2;
  }
  let n2 = { abi: 2 };
  return e3[_f] = n2, n2;
}
function yf() {
  return vf().capability;
}
function bf() {
  let e3 = yf();
  if (!e3) throw Error(`eXact enhancement declarations require the compiler-selected DOM enhancement integration`);
  return e3;
}
function xf(e3) {
  return !!e3 && typeof e3 == `object` && e3.abi === 2;
}
function Sf(e3, t2) {
  e3.instance = t2, zu.set(t2, e3);
}
var Cf = `http://www.w3.org/1999/xhtml`, wf = `http://www.w3.org/2000/svg`, Tf = `http://www.w3.org/1998/Math/MathML`;
function Ef(e3, t2) {
  if (e3 === `svg`) return wf;
  if (e3 === `math`) return Tf;
  if (!t2) return;
  let n2 = t2.namespaceURI;
  if (n2 === `http://www.w3.org/2000/svg`) return t2.localName === `foreignObject` ? void 0 : wf;
  if (n2 === `http://www.w3.org/1998/Math/MathML` && !([`mi`, `mo`, `mn`, `ms`, `mtext`].includes(t2.localName) && e3 !== `mglyph` && e3 !== `malignmark`)) {
    if (t2.localName === `annotation-xml`) {
      let e4 = t2.getAttribute(`encoding`)?.toLowerCase();
      if (e4 === `text/html` || e4 === `application/xhtml+xml`) return;
    }
    return Tf;
  }
}
function Df(e3, t2) {
  let n2 = Yo();
  return { ...n2, report(r2, i2) {
    let a2 = n2.report(r2, i2);
    return e3.onErrorReport?.(a2), t2?.(n2.errors), a2;
  } };
}
function Of(e3) {
  return H(`section`, { role: `alert`, className: `exact-error-boundary` }, H(`h1`, null, `Application error`), ...e3.map((e4) => H(`article`, { key: e4.id, className: `exact-error` }, H(`h2`, null, e4.component?.name ?? `Application`), H(`p`, null, `${e4.source}${e4.phase ? `:${e4.phase}` : ``}`), H(`pre`, null, Do(e4.error)))));
}
function kf(e3, t2) {
  return e3.debugMarkers ? document.createComment(`exact-${t2}`) : document.createTextNode(``);
}
function Af(e3, t2, n2) {
  let r2 = Ef(e3, t2 instanceof Element ? t2 : void 0), i2 = r2 ? document.createElementNS(r2, e3) : document.createElement(e3);
  return r2 === `http://www.w3.org/1998/Math/MathML` && e3 === `annotation-xml` && typeof n2?.encoding == `string` && i2.setAttribute(`encoding`, n2.encoding), i2;
}
var jf = /* @__PURE__ */ Symbol(`exact.dom.component-updates`);
function Mf(e3) {
  let t2 = e3, n2 = t2.owner ?? t2.mounted.renderProgram?.bindingOwner ?? t2.mounted.renderProgram?.parentInstance;
  if (n2) return n2;
  t2.valid = false;
}
function Nf(e3, t2, n2) {
  let r2 = t2[n2];
  r2 ? r2 instanceof Set ? r2.add(e3) : r2 !== e3 && (t2[n2] = /* @__PURE__ */ new Set([r2, e3])) : t2[n2] = e3, e3.stopBindings.push({ stop: () => {
    for (let r4 of t2.publishing ?? []) r4[n2] === e3 && (r4[n2] = void 0);
    let r3 = t2[n2];
    r3 === e3 ? t2[n2] = void 0 : r3 instanceof Set && (r3.delete(e3), r3.size === 0 ? t2[n2] = void 0 : r3.size === 1 && (t2[n2] = r3.values().next().value));
  } });
}
function Pf(e3, t2) {
  let n2 = [], r2 = false;
  for (let t3 = 0; t3 < e3.length; t3++) {
    let i3 = e3[t3];
    !i3 || i3 instanceof Set || (n2[t3] = i3, r2 = true);
  }
  r2 && i2(n2);
  for (let t3 = 0; t3 < e3.length; t3++) {
    let n3 = e3[t3];
    if (n3 instanceof Set) for (let e4 of n3) {
      let n4 = [];
      n4[t3] = e4, i2(n4);
    }
  }
  function i2(n3) {
    (e3.publishing ??= []).push(n3);
    try {
      t2(n3);
    } finally {
      e3.publishing.pop(), e3.publishing.length === 0 && (e3.publishing = void 0);
    }
  }
}
function Ff(e3, t2, n2, r2 = 0, i2 = t2.length) {
  let a2 = [];
  for (let e4 = r2; e4 < i2; e4++) {
    let n3 = t2[e4];
    a2.push(n3[0]);
  }
  if (a2.length === 0) return null;
  let o2 = ei(e3[n2], a2);
  if (o2) return { d: o2.target, k: o2.keys, v: o2.keys.map((e4) => D(o2.target, e4)), o: r2 };
}
function If(e3, t2) {
  let n2 = false;
  for (let r2 = 0; r2 < e3.k.length; r2++) {
    let i2 = D(e3.d, e3.k[r2]);
    i2 !== e3.v[r2] && (e3.v[r2] = i2, n2 = true, t2(e3.o + r2));
  }
  return n2;
}
var Lf = class {
  owner;
  bindings;
  props;
  scope;
  publish;
  g = [];
  f = [];
  s = [];
  constructor(e3, t2, n2, r2, i2) {
    this.owner = e3, this.bindings = t2, this.props = n2, this.scope = r2, this.publish = i2;
  }
  stop() {
    for (let e3 of this.s.splice(0)) e3();
    for (let e3 of this.f.splice(0)) e3?.stop();
  }
};
function Rf(e3, t2, n2, r2, i2 = e3.scope) {
  let a2 = new Lf(e3, t2, n2, i2, r2);
  for (let [o2, s2, c2] of [[`props`, 0, n2], [`state`, n2, t2.length]]) {
    let n3 = Ff(e3, t2, o2, s2, c2);
    if (n3 === void 0) return;
    n3 && (a2.g.push(n3), a2.s.push(xn(n3.d, n3.k, r2, Vf(i2))));
  }
  for (let e4 = 0; e4 < t2.length; e4++) Bf(a2, e4);
  return a2;
}
function zf(e3, t2, n2 = -1) {
  let r2 = n2 >= 0;
  r2 && t2(n2);
  for (let i2 of e3.g) r2 = If(i2, (r3) => {
    r3 !== n2 && t2(r3), Bf(e3, r3);
  }) || r2;
  return r2;
}
function Bf(e3, t2) {
  let n2 = e3.bindings[t2];
  if (!n2 || t2 >= e3.props) return;
  let r2 = ti(e3.owner.props, n2[0]), i2 = r2.present && Array.isArray(r2.value) && r2.value[0] === Lr ? r2.value : void 0, a2 = r2.present && P(r2.value) ? r2.value : void 0;
  console.log(`FWD`, e3.owner.id, t2, r2.present, !!i2, !!a2);
  let o2 = i2 ?? a2, s2 = e3.f[t2];
  if (s2?.value === o2 || (s2?.stop(), e3.f[t2] = void 0, !o2)) return;
  let c2 = () => {
    console.log(`NOTIFY`, e3.owner.id, t2), a2?.get(), e3.publish(t2);
  }, l2 = i2 ? $r(i2[1], [i2[2]]) : void 0, u2 = i2 ? xn(l2?.target ?? F(i2[1]), l2?.keys ?? [i2[2]], c2, Vf(e3.scope)) : bn(Cn(a2), c2, Vf(e3.scope));
  e3.f[t2] = { value: o2, stop: u2 };
}
function Vf(e3) {
  return { scope: e3, structural: true };
}
function Hf(e3, t2, n2) {
  let r2 = Mf(e3);
  if (!r2) return;
  let i2 = r2, a2 = i2[jf];
  if (!a2) {
    let t3, o2 = Rf(r2, n2.bindings, n2.props, (e4) => Uf(n2, t3, e4));
    if (!o2) {
      e3.valid = false;
      return;
    }
    a2 = t3 = { d: o2, t: [] }, i2[jf] = a2;
  }
  Nf(e3, a2.t, t2);
}
function Uf(e3, t2, n2) {
  let r2 = 0, i2 = 0;
  zf(t2.d, (t3) => {
    r2 |= e3.bindings[t3][1], i2 |= e3.bindings[t3][2];
  }, n2), console.log(`PUBLISH`, t2.d.owner.id, r2, i2, t2.t.map((e4, t3) => e4 ? t3 : -1).join(`,`)), (r2 || i2) && Pf(t2.t, (t3) => e3.apply(t3, r2, i2));
}
var Wf = /* @__PURE__ */ Symbol(`exact.dom.component-wide-updates`);
function Gf(e3, t2, n2) {
  let r2 = e3, i2 = r2.mounted.renderProgram?.bindingOwner ?? r2.mounted.renderProgram?.parentInstance;
  if (!i2) {
    r2.valid = false;
    return;
  }
  let a2 = i2, o2 = a2[Wf];
  if (!o2) {
    let e4, t3 = Rf(i2, n2.bindings, n2.props, (t4) => Kf(n2, e4, t4));
    if (!t3) {
      r2.valid = false;
      return;
    }
    o2 = e4 = { d: t3, t: [], w: new Uint32Array(n2.words - 2) }, a2[Wf] = o2;
  }
  Nf(e3, o2.t, t2);
}
function Kf(e3, t2, n2) {
  let r2 = 0, i2 = 0, a2 = false;
  if (a2 = zf(t2.d, (n3) => {
    let a3 = e3.bindings[n3];
    r2 |= a3[1], i2 |= a3[2];
    let o2 = a3;
    for (let e4 = 0; e4 < t2.w.length; e4++) t2.w[e4] = t2.w[e4] | (o2[e4 + 3] ?? 0);
  }, n2), a2) try {
    Pf(t2.t, (n3) => e3.apply(n3, r2, i2, t2.w));
  } finally {
    t2.w.fill(0);
  }
}
var qf = /* @__PURE__ */ Symbol(`exact.dom.component-wide-state-updates`);
function Jf(e3, t2, n2) {
  let r2 = Mf(e3);
  if (!r2) return;
  let i2 = r2[jf];
  if (!i2) {
    let t3 = Ff(r2, n2.bindings, `state`);
    if (!t3) {
      e3.valid = false;
      return;
    }
    i2 = { d: t3, t: [] }, r2[jf] = i2, xn(i2.d.d, i2.d.k, () => Xf(n2, i2), { scope: r2.scope });
  }
  Nf(e3, i2.t, t2);
}
function Yf(e3, t2, n2) {
  let r2 = Mf(e3);
  if (!r2) return;
  let i2 = r2[qf];
  if (!i2) {
    let t3 = Ff(r2, n2.bindings, `state`);
    if (!t3) {
      e3.valid = false;
      return;
    }
    i2 = { d: t3, t: [], w: new Uint32Array(n2.words - 2) }, r2[qf] = i2, xn(i2.d.d, i2.d.k, () => Zf(n2, i2), { scope: r2.scope });
  }
  Nf(e3, i2.t, t2);
}
function Xf(e3, t2) {
  let n2 = 0, r2 = 0;
  If(t2.d, (t3) => {
    n2 |= e3.bindings[t3][1], r2 |= e3.bindings[t3][2];
  }), (n2 || r2) && Pf(t2.t, (t3) => e3.apply(t3, n2, r2));
}
function Zf(e3, t2) {
  let n2 = 0, r2 = 0, i2 = false;
  if (i2 = If(t2.d, (i3) => {
    let a2 = e3.bindings[i3];
    n2 |= a2[1], r2 |= a2[2];
    let o2 = a2;
    for (let e4 = 0; e4 < t2.w.length; e4++) t2.w[e4] = t2.w[e4] | (o2[e4 + 3] ?? 0);
  }), i2) try {
    Pf(t2.t, (i3) => e3.apply(i3, n2, r2, t2.w));
  } finally {
    t2.w.fill(0);
  }
}
var Qf = /* @__PURE__ */ Symbol.for(`@exactjs/dom.foreign-component-capability.v1`);
function $f() {
  let e3 = globalThis, t2 = e3[Qf];
  if (t2 !== void 0) {
    if (!t2 || typeof t2 != `object` || t2.abi !== 1) throw Error(`Incompatible eXact DOM foreign component registry`);
    return t2;
  }
  let n2 = { abi: 1 };
  return e3[Qf] = n2, n2;
}
function ep() {
  let e3 = $f().capability;
  if (!e3) throw Error(`A foreign component artifact was used without its renderer integration`);
  return e3;
}
var tp = /* @__PURE__ */ new WeakMap();
function np(e3, t2, n2, r2, i2) {
  let a2 = e3.preparedComponents?.get(t2);
  if (a2) {
    e3.preparedComponents.delete(t2);
    let r3 = a2.attachment.ownedRange;
    if (a2.attachment.owner.parent !== n2) throw Error(`Prepared component cannot attach beneath a different context owner`);
    return a2.attachment.commit(new up(e3, r3, i2), a2.project, `mount`);
  }
  return ju(e3, () => {
    ku(e3);
    let a3 = A(r2);
    try {
      return rp(e3, t2, a3, n2, i2);
    } catch (e4) {
      throw a3.stop(), e4;
    }
  });
}
function rp(e3, t2, n2, r2, i2, a2, o2 = `mount`) {
  let s2 = t2.contract.artifact;
  if (s2.target !== `client`) throw TypeError(`Component receipt selected non-client artifact ${s2.id}`);
  let c2 = { componentReceipt: t2, dom: kf(e3, `component`), end: void 0, scope: n2, children: [], clientArtifact: s2 }, l2 = new up(e3, c2, i2);
  a2?.own(c2);
  try {
    let i3 = t2.domain ?? r2?.domain ?? e3.domain ?? Ka, u2 = t2.update ? op(t2.props) : t2.props, d2 = () => j(n2, () => s2.construct(r2, cp(u2, lp(t2.children)), r2?.ambientContexts ?? e3.ambientContexts, i3, void 0, t2.contract)), f2 = o2 === `hydrate` ? no(i3, d2) : d2();
    Sf(c2, f2);
    let p2 = ap(r2);
    t2.transparentUpdateOwner && p2 && tp.set(f2, p2), a2 ? a2.capture(s2, f2, l2, () => {
      ip(c2, p2, t2), l2.finishConstruction();
    }, o2) : (s2.attach(f2, l2, `mount`), ip(c2, p2, t2), l2.finishConstruction());
  } catch (t3) {
    if (a2 || Au(t3)) throw t3;
    let o3 = W(r2, U(t3, `construct`, r2, s2.id), null)?.();
    c2.children = o3 === void 0 ? [] : $(e3, Array.isArray(o3) ? o3 : [o3], r2, n2, i2);
  }
  return c2;
}
function ip(e3, t2, n2) {
  let r2 = n2.update;
  if (!r2 || !t2) return;
  let i2 = [], a2 = { mounted: e3, owner: t2, stopBindings: i2, valid: true }, o2 = `words` in r2.contract && typeof r2.contract.words == `number`, s2 = `props` in r2.contract && typeof r2.contract.props == `number`;
  o2 ? s2 ? Gf(a2, r2.target, r2.contract) : Yf(a2, r2.target, r2.contract) : s2 ? Hf(a2, r2.target, r2.contract) : Jf(a2, r2.target, r2.contract), i2.length !== 0 && (e3.stop = () => {
    for (let e4 of i2) e4.stop();
  });
}
function ap(e3) {
  let t2 = e3, n2 = /* @__PURE__ */ new Set();
  for (; t2 && !n2.has(t2); ) {
    n2.add(t2);
    let e4 = tp.get(t2);
    if (!e4) return t2;
    t2 = e4;
  }
  return t2;
}
function op(e3) {
  let t2;
  for (let n2 of Object.keys(e3)) {
    let r2 = e3[n2], i2 = Array.isArray(r2) && r2[0] === Lr ? r2 : void 0;
    !i2 && !P(r2) || ((t2 ??= { ...e3 })[n2] = i2 ? Reflect.get(i2[1], i2[2]) : F(r2));
  }
  return t2 ?? e3;
}
function sp(e3, t2) {
  return !e3.clientArtifact || !e3.instance ? false : (e3.clientArtifact.receive(e3.instance, t2.update ? op(t2.props) : t2.props, lp(t2.children)), e3.componentReceipt = t2, true);
}
function cp(e3, t2) {
  let n2 = { ...e3 };
  return t2.length === 1 ? n2.children = t2[0] : t2.length > 1 && (n2.children = t2), n2;
}
function lp(e3) {
  return Oo(e3.map((e4) => F(e4)));
}
var up = class {
  root;
  mounted;
  parentNode;
  constructor(e3, t2, n2) {
    this.root = e3, this.mounted = t2, this.parentNode = n2;
  }
  [tc](e3, t2, n2, r2) {
    return this.assertAttachment(e3, t2, r2), $c(this.mounted, n2), this.mounted.children = $(this.root, this.mounted.componentReceipt?.fragmentTarget ? yf().projectComponent(this.mounted, n2) : n2, t2, this.mounted.scope, this.parentNode), qd(t2, true, Zd(this.root)), this.mounted.afterPlacement = () => t2.markMounted(), this.mounted.afterPlacementPhase = `mount`, this.mounted;
  }
  [nc](e3, t2, n2) {
    return this.assertAttachment(e3, t2, n2), ep().attach(this.root, this.mounted, e3, t2, this.parentNode), this.mounted;
  }
  finishConstruction() {
    return false;
  }
  assertAttachment(e3, t2, n2) {
    if (n2 !== `mount` || t2 !== this.mounted.instance || e3 !== this.mounted.clientArtifact) throw TypeError(`Client component attached through an incompatible DOM target`);
  }
};
function dp(e3, t2, n2, r2) {
  let i2 = e3.replacementParking?.mounts, a2 = t2, o2 = i2?.get(t2);
  if (!o2?.length) {
    let e4 = dc(t2);
    if (e4 && i2) for (let [t3, n3] of i2) {
      let r3 = dc(t3) ?? n3[0]?.mounted.componentReceipt;
      if (r3 && r3.contract.artifact === e4.contract.artifact && r3.key === e4.key && r3.domain === e4.domain) {
        a2 = t3, o2 = n3;
        break;
      }
    }
  }
  let s2 = o2?.shift();
  if (s2) return !o2?.length && a2 && i2?.delete(a2), e3.replacementParking?.commits.push(() => {
    bt(s2.mounted.scope, r2), s2.mounted.operation = t2;
    let e4 = dc(t2);
    e4 && (s2.mounted.instance ? (Ml(s2.mounted.instance, n2), sp(s2.mounted, e4)) : s2.mounted.componentReceipt = e4);
    let i3 = Ko(t2);
    i3 && (s2.mounted.intrinsicReceipt = i3);
    let a3 = yc(t2);
    a3 && (s2.mounted.fragmentReceipt = a3);
    let o3 = Ll(t2);
    o3 && (s2.mounted.renderProgramReceipt = o3);
  }), s2.mounted;
}
function fp(e3) {
  let t2 = /* @__PURE__ */ new Set();
  for (let n2 of e3) {
    let e4 = zo(n2) ? Bo(n2) : $l()?.key(n2);
    if (e4 !== void 0) {
      if (t2.has(e4)) throw Error(`Duplicate key "${e4}" in rendered children`);
      t2.add(e4);
    }
  }
}
function pp(e3) {
  let t2 = F(e3);
  return typeof t2 == `string` || typeof t2 == `number` ? String(t2) : void 0;
}
function mp(e3, t2) {
  e3.stop?.(), e3.scalarSource = t2;
  let n2 = e3.dom;
  if (!P(t2)) {
    e3.stop = void 0;
    let r2 = String(t2 ?? ``);
    n2.data !== r2 && (n2.data = r2);
    return;
  }
  e3.stop = vn(() => {
    let e4 = String(F(t2) ?? ``);
    n2.data !== e4 && (n2.data = e4);
  }, void 0, { scope: e3.scope, onRelease: () => e3.stop = void 0 });
}
function hp(e3) {
  let t2 = e3.target;
  if (!(t2 instanceof Node)) throw TypeError(`An eXact portal target must be a DOM Node`);
  return t2;
}
function gp(e3, t2, n2) {
  let r2 = e3.eventContainer;
  e3.eventContainer = t2;
  try {
    return n2();
  } finally {
    e3.eventContainer = r2;
  }
}
function _p(e3, t2) {
  return e3.container === t2 || e3.container.contains(t2) ? e3.container : t2;
}
var vp = /* @__PURE__ */ Symbol.for(`@exactjs/dom.text-host-capability.v2`);
function yp(e3, t2, n2, r2, i2) {
  let a2 = globalThis[vp];
  if (!a2) throw Error(`Text host rendering requires the compiler-selected capability`);
  return a2(e3, t2, n2, r2, i2);
}
function bp(e3, t2, n2) {
  if (![`title`, `textarea`, `script`, `style`].includes(t2) || n2.length < 2) return n2;
  let r2 = () => n2.map((e4) => {
    let t3 = F(e4);
    if (t3 == null || typeof t3 == `boolean`) return ``;
    if (typeof t3 != `string` && typeof t3 != `number`) throw TypeError(`Text-only elements require scalar children`);
    return String(t3);
  }).join(``);
  return [n2.some(P) ? on(r2) : r2()];
}
function xp(e3, t2, n2, r2, i2) {
  let a2 = Af(t2.tag, i2, t2.props), o2 = { intrinsicReceipt: t2, dom: a2, scope: n2, children: [] };
  if (r2 && Uu(a2, r2), t2.tag === `title` || t2.tag === `textarea`) {
    let i3 = yp(e3, t2.children, r2, n2);
    o2.children = [i3], J(e3, a2, i3);
  } else o2.children = Ch(e3, a2, [...bp(e3, t2.tag, t2.children)], r2, n2);
  return Dd(e3, a2, {}, t2.props, n2), o2;
}
function Sp(e3) {
  let t2 = [], n2 = Array(e3.length).fill(-1);
  for (let r3 = 0; r3 < e3.length; r3++) {
    let i3 = e3[r3];
    if (i3 < 0) continue;
    let a2 = 0, o2 = t2.length;
    for (; a2 < o2; ) {
      let n3 = a2 + o2 >> 1;
      e3[t2[n3]] < i3 ? a2 = n3 + 1 : o2 = n3;
    }
    a2 > 0 && (n2[r3] = t2[a2 - 1]), t2[a2] = r3;
  }
  let r2 = /* @__PURE__ */ new Set(), i2 = t2[t2.length - 1] ?? -1;
  for (; i2 >= 0; ) r2.add(i2), i2 = n2[i2];
  return r2;
}
var Cp;
function wp(e3, t2, n2, r2) {
  return Cp?.release(e3, t2, n2, r2) ?? false;
}
function Tp(e3, t2, n2) {
  return Cp?.reverse(e3, t2, n2);
}
function Ep(e3) {
  Cp?.dispose(e3);
}
function Dp(e3) {
  let t2 = [];
  for (let n2 of e3) {
    if (n2 == null || n2 === false || n2 === true) continue;
    if (zo(n2)) {
      let e5 = Bo(n2);
      t2.push({ value: n2, native: true, ...e5 === void 0 ? {} : { key: e5 } });
      continue;
    }
    let e4 = pp(n2);
    if (e4 !== void 0) {
      t2.push({ value: n2, scalar: e4 });
      continue;
    }
    throw TypeError(`Native eXact children must be compiler-issued operations, scalar values, or empty placeholders`);
  }
  return t2;
}
function Op(e3) {
  return e3.operationKey ?? e3.componentReceipt?.key ?? e3.intrinsicReceipt?.key ?? e3.fragmentReceipt?.key ?? e3.targetReceipt?.key;
}
function kp(e3, t2, n2) {
  n2 && (yf()?.invalidate?.(n2), cf(e3, n2)), t2 && qd(t2), e3.enhancementReconciliationDepth || e3.reconcileEnhancements?.();
}
function Ap(e3, t2, n2, r2, i2) {
  let a2 = e3.renderProgram, o2 = a2.compiledProps ??= [], s2 = o2[n2];
  s2 || (s2 = { element: t2, values: {} }, o2[n2] = s2);
  let c2 = s2.values, l2 = () => {
    let r3, o3 = (n3, i3) => {
      if (n3 === ``) {
        r3 ??= {};
        let e4 = F(i3);
        typeof e4 == `object` && e4 && Object.assign(r3, e4);
        return;
      }
      let o4 = F(i3);
      if (r3) {
        r3[n3] = o4;
        return;
      }
      Object.hasOwn(c2, n3) && Object.is(c2[n3], o4) || (Ad(a2.root, t2, n3, o4, c2[n3], e3.scope), c2[n3] = o4);
    };
    if (i2) {
      let e4 = a2.invocation.owner;
      for (let [t3, n3, r4] of i2) o3(t3, I(n3 === 0 ? e4.state : e4.props, r4));
    }
    if (a2.invocation.propertyWriter?.(n2, o3), r3) for (let n3 of /* @__PURE__ */ new Set([...Object.keys(c2), ...Object.keys(r3)])) {
      let i3 = F(r3[n3]);
      Object.hasOwn(c2, n3) && Object.is(c2[n3], i3) || (Ad(a2.root, t2, n3, i3, c2[n3], e3.scope), n3 in r3 ? c2[n3] = i3 : delete c2[n3]);
    }
  };
  r2 ? l2() : Ju(a2.root, l2);
}
function jp(e3) {
  let t2 = e3.renderProgram;
  if (t2.compiledProps) {
    for (let e4 of t2.compiledProps) e4 && (e4.values.ref?.fulfill(void 0), Od(e4.element));
    t2.compiledProps = void 0;
  }
}
function Mp(e3, t2, n2, r2) {
  try {
    return B(F(Rl(e3, t2)));
  } catch (e4) {
    return Pp(e4) ? (Qo(n2, e4), []) : Np(e4, n2, r2);
  }
}
function Np(e3, t2, n2 = `dynamic-component`) {
  let r2 = W(t2, U(e3, `render`, t2, n2));
  return r2 ? B(r2()) : [];
}
function Pp(e3) {
  return (typeof e3 == `object` || typeof e3 == `function`) && e3 !== null && typeof e3.then == `function`;
}
function Fp(e3, t2) {
  if (!(e3 instanceof Comment) || !t2) return;
  let n2 = `/x:${t2.startsWith(`exact:`) ? t2.slice(6) : t2}`;
  for (let t3 = e3.nextSibling; t3; t3 = t3.nextSibling) if (t3 instanceof Comment && t3.data === n2) return t3;
}
function Ip(e3, t2, n2, r2, i2 = false) {
  let a2 = Bp(e3, t2, n2);
  if (!a2) return false;
  if (i2) return (e3.renderProgram.directChildUpdates ??= [])[t2] = a2, a2(), true;
  let o2 = vn(a2, void 0, { scope: e3.scope, owned: true });
  return o2 && r2.push(o2), true;
}
function Lp(e3, t2) {
  let n2 = e3.renderProgram?.directChildUpdates?.[t2];
  return n2 ? (n2(), true) : false;
}
function Rp(e3, t2, n2, r2) {
  let i2 = t2.map((t3) => Bp(e3, t3, n2));
  if (i2.some((e4) => !e4)) return false;
  let a2 = vn(() => {
    let t3 = e3.renderProgram.parentInstance;
    t3?.beginRender();
    try {
      for (let e4 of i2) e4();
    } finally {
      t3?.endRender();
    }
  }, void 0, { scope: e3.scope, owned: true });
  return a2 && r2.push(a2), true;
}
function zp(e3, t2, n2, r2) {
  let i2 = Bp(e3, t2, n2, Kp);
  if (!i2) return false;
  let a2 = e3.renderProgram.parentInstance, o2 = vn(() => {
    a2?.beginRender();
    try {
      i2();
    } finally {
      a2?.endRender();
    }
  }, void 0, { scope: e3.scope, owned: true });
  return o2 && r2.push(o2), true;
}
function Bp(e3, t2, n2, r2 = Gp) {
  let i2 = e3.renderProgram, a2 = i2.childSlots?.[t2], o2 = i2.slotNodes[t2], s2 = Vp(i2, t2), c2 = s2 !== void 0 && Up(i2.componentSlots, t2), l2 = Hp(o2) ? o2 : void 0, u2 = o2 instanceof Node ? o2 : void 0, d2 = a2 ? a2.before : l2 ? void 0 : Fp(u2, s2), f2 = a2?.parent ?? l2?.[0] ?? u2?.parentNode, p2 = a2 ? a2.before : l2 ? null : d2;
  if (!f2 || !l2 && (!(u2 instanceof Comment) || !d2)) return;
  a2 || (a2 = { parent: f2, before: p2 ?? null, children: [] }, (i2.childSlots ??= [])[t2] = a2);
  let m2 = n2 && a2.children.length !== 0;
  return () => {
    let n3 = j(e3.scope, () => r2(i2.invocation, t2, i2.parentInstance));
    if (m2) {
      m2 = false;
      return;
    }
    C(() => {
      let t3 = c2 ? Wp(n3) : void 0;
      if (t3 ? Object.is(a2.componentValue, t3) : Jp(a2.value, n3)) return;
      let r3 = a2.parent, o3 = a2.before;
      a2.children = Q(i2.root, r3, a2.children, n3, i2.parentInstance, e3.scope, o3, e3), t3 ? (a2.componentValue = t3, a2.value = void 0) : (a2.componentValue = void 0, a2.value = n3), Yp(e3);
    });
  };
}
function Vp(e3, t2) {
  let n2 = e3.slotNodes[t2];
  if (Hp(n2)) return ``;
  if (!(!(n2 instanceof Comment) || !n2.data.startsWith(`x:`))) return n2.data.slice(2);
}
function Hp(e3) {
  return Array.isArray(e3);
}
function Up(e3, t2) {
  return typeof e3 == `number` ? t2 < 31 && !!(e3 & 1 << t2) : e3?.has(t2) === true;
}
function Wp(e3) {
  return e3.length === 1 ? dc(e3[0]) : void 0;
}
function Gp(e3, t2, n2) {
  return eu(Mp(e3, t2, n2, `compiled-child-slot`));
}
function Kp(e3, t2, n2) {
  return Mp(e3, t2, n2, `compiled-keyed-child-slot`);
}
function qp(e3, t2) {
  return typeof e3 == `number` ? t2 < 31 && !!(e3 & 1 << t2) : e3?.includes(t2) === true;
}
function Jp(e3, t2) {
  return !e3 || e3.length !== t2.length ? false : t2.every((t3, n2) => Object.is(t3, e3[n2]));
}
function Yp(e3) {
  e3.children.length = 0;
  for (let t2 of e3.renderProgram.childSlots ?? []) t2 && e3.children.push(...t2.children);
}
function Xp(e3, t2, n2) {
  let r2 = Qp(e3, t2, n2);
  return r2 ? ((e3.renderProgram.componentReceipts ??= [])[t2] = r2, r2(), true) : false;
}
function Zp(e3, t2) {
  let n2 = e3.renderProgram?.componentReceipts?.[t2];
  return n2 ? (n2(), true) : false;
}
function Qp(e3, t2, n2) {
  let r2 = e3.renderProgram, i2 = r2.childSlots?.[t2], a2 = r2.slotNodes[t2], o2 = nm(a2) ? a2 : void 0, s2 = a2 instanceof Node ? a2 : void 0, c2 = em(r2, t2, s2, o2);
  if (c2 === void 0) return;
  let l2 = i2 ? i2.before : o2 ? void 0 : Fp(s2, c2), u2 = i2?.parent ?? o2?.[0] ?? s2?.parentNode, d2 = i2 ? i2.before : o2 ? o2[2] ?? null : l2;
  if (!u2 || !o2 && (!(s2 instanceof Comment) || !l2)) return;
  i2 || (i2 = { parent: u2, before: d2 ?? null, children: [] }, (r2.childSlots ??= [])[t2] = i2);
  let f2 = n2 && i2.children.length !== 0;
  return () => {
    let n3 = j(e3.scope, () => Rl(r2.invocation, t2)), a3 = dc(n3);
    if (a3) {
      if (f2) {
        f2 = false, i2.componentValue = a3;
        return;
      }
      C(() => {
        let t3 = i2.children.length === 1 ? i2.children[0] : void 0, o3 = dp(r2.root, n3, r2.parentInstance, e3.scope);
        if (!o3 && t3?.clientArtifact && t3.instance && t3.componentReceipt && t3.componentReceipt.contract.artifact === a3.contract.artifact && t3.componentReceipt.key === a3.key && t3.componentReceipt.domain === a3.domain && !$p(t3, a3.props)) sp(t3, a3);
        else if (t3) {
          let n4 = o3 ?? np(r2.root, a3, r2.parentInstance, e3.scope, i2.parent);
          J(r2.root, i2.parent, n4, t3.dom), wp(r2.root, i2.parent, t3, `reconcile-replaced`) || hf(i2.parent, t3), i2.children[0] = n4;
        } else {
          let t4 = o3 ?? np(r2.root, a3, r2.parentInstance, e3.scope, i2.parent);
          J(r2.root, i2.parent, t4, i2.before), i2.children.push(t4);
        }
        i2.componentValue = a3, i2.value = void 0, Yp(e3);
      });
    }
  };
}
function $p(e3, t2) {
  let n2 = e3.componentReceipt?.props, r2 = e3.clientArtifact?.identityProps;
  return !!n2 && !!r2?.some((e4) => !Object.is(Reflect.get(n2, e4), Reflect.get(t2, e4)));
}
function em(e3, t2, n2, r2) {
  if (tm(e3.componentSlots, t2)) {
    if (r2) return ``;
    if (!(!(n2 instanceof Comment) || !n2.data.startsWith(`x:`))) return n2.data.slice(2);
  }
}
function tm(e3, t2) {
  return typeof e3 == `number` ? t2 < 31 && !!(e3 & 1 << t2) : e3?.has(t2) === true;
}
function nm(e3) {
  return Array.isArray(e3);
}
function rm(e3, t2, n2, r2, i2 = ``, a2 = ``) {
  let o2 = e3.renderProgram, s2 = o2.invocation.owner, c2 = F(n2 === void 0 ? Rl(o2.invocation, t2) : I(n2 === 0 ? s2.state : s2.props, r2)), l2 = c2 == null || c2 === false || c2 === true ? `` : typeof c2 == `string` || typeof c2 == `number` ? String(c2) : void 0;
  if (l2 === void 0) return false;
  let u2 = `${i2}${l2}${a2}`;
  if (o2.textRuns?.values.has(t2)) return o2.textRuns.values.set(t2, u2), true;
  let d2 = o2.slotNodes[t2];
  return d2 instanceof Text && (d2.data !== u2 && (d2.data = u2), true);
}
function im(e3, t2, n2) {
  let r2 = e3.firstChild;
  if (r2 && (!(r2 instanceof Text) || r2.nextSibling)) return false;
  n2.runs.push({ container: e3, parts: t2 });
  for (let e4 of t2) typeof e4 == `number` && n2.values.set(e4, void 0);
  return true;
}
function am(e3, t2) {
  for (let { container: t3, parts: n3 } of e3.runs) {
    let r2 = ``;
    for (let t4 of n3) {
      let n4 = typeof t4 == `string` ? t4 : e3.values.get(t4);
      if (n4 === void 0) return false;
      r2 += n4;
    }
    let i2 = t3.firstChild;
    if (i2 && (!(i2 instanceof Text) || i2.nextSibling) || (i2?.textContent ?? ``) !== r2) return false;
  }
  let n2 = t2;
  for (let { container: t3, parts: r2 } of e3.runs) {
    let i2 = t3.firstChild;
    i2 || (i2 = t3.ownerDocument.createTextNode(``), t3.appendChild(i2));
    for (let t4 = 0; t4 < r2.length; t4++) {
      let a2 = r2[t4], o2 = typeof a2 == `string` ? a2 : e3.values.get(a2);
      typeof a2 == `number` && (n2[a2] = i2), t4 < r2.length - 1 && (i2 = i2.splitText(o2.length));
    }
  }
  return true;
}
function om(e3, t2) {
  let n2 = vn(t2, void 0, { scope: e3.mounted.scope, owned: true });
  n2 && e3.stopBindings.push(n2);
}
function sm(e3, t2, n2, r2, i2) {
  let a2 = e3, o2 = a2.mounted.renderProgram, s2 = o2.slotNodes[n2];
  if (!o2.invocation.propertyWriter && !i2 || !s2) {
    a2.valid = false;
    return;
  }
  let c2 = () => Ap(a2.mounted, s2, t2, a2.initialBinding, i2);
  r2 ? c2() : om(a2, c2);
}
function cm(e3, t2, n2) {
  let r2 = e3, i2 = r2.mounted.renderProgram, a2 = i2.slotNodes[n2];
  if (!i2.invocation.propertyWriter || !a2) {
    r2.valid = false;
    return;
  }
  om(r2, () => Ap(r2.mounted, a2, t2, r2.initialBinding));
}
function lm(e3, t2, n2) {
  let r2 = e3, i2 = r2.mounted.renderProgram, a2 = i2.slotNodes[n2], o2, s2 = i2.invocation.program.wire;
  for (let e4 of s2?.[2] ?? []) if (e4[0] === 12 && e4[1] === t2 && e4[2] === n2) {
    o2 = e4[3];
    break;
  }
  if (!(a2 instanceof Element) || !i2.invocation.propertyWriter && !o2) {
    r2.valid = false;
    return;
  }
  Ap(r2.mounted, a2, t2, false, o2);
}
function um(e3) {
  let t2 = e3.renderProgram, n2 = false, r2 = true, i2 = [], a2 = () => {
    for (let e4 of i2) e4.stop();
    i2 = [], t2.directChildUpdates = void 0, t2.componentReceipts = void 0;
  }, o2 = () => {
    if (!n2) {
      if (n2 = true, a2(), t2.textRuns = void 0, t2.props) {
        for (let [e4, n3] of t2.props) n3.ref?.fulfill(void 0), Od(e4);
        t2.props.clear(), t2.props = void 0;
      }
      jp(e3), e3.stop = void 0, t2.refresh = void 0;
    }
  }, s2 = () => {
    a2();
    let n3 = { mounted: e3, initialBinding: r2, stopBindings: i2, valid: true }, o3 = t2.invocation.program.wire, s3 = t2.invocation.program.bind;
    return o3 ? dm(o3, n3) : s3 ? s3(n3) : n3.valid = false, t2.textRuns &&= (n3.valid &&= am(t2.textRuns, t2.slotNodes), void 0), r2 = false, n3.valid;
  };
  return t2.refresh = s2, e3.stop = o2, s2() ? true : (o2(), false);
}
function dm(e3, t2) {
  for (let n2 of e3[2]) if (fm(n2, t2), !t2.valid) return;
}
function fm(e3, t2) {
  switch (e3[0]) {
    case 0:
      let n2 = Array.isArray(e3[2]) ? e3[2] : void 0;
      mm(t2, e3[1], (n2 ? e3[3] : e3[2]) === true || void 0, n2);
      return;
    case 11: {
      let n3 = e3[2], r2 = n3[3] === void 0 ? void 0 : [n3[3], n3[4]];
      mm(t2, e3[1], n3[2], r2, n3[0], n3[1]);
      return;
    }
    case 1:
      gm(t2, e3[1], e3[2] === true || void 0);
      return;
    case 2:
      pm(t2, e3[1], e3[2], e3[3]);
      return;
    case 3:
      ym(t2, e3[1]);
      return;
    case 4:
      vm(t2, e3[1]);
      return;
    case 5:
      sm(t2, e3[1], e3[2], e3[3] === true || void 0);
      return;
    case 6:
      cm(t2, e3[1], e3[2]);
      return;
    case 12:
      sm(t2, e3[1], e3[2], e3[4] === true || void 0, e3[3]);
      return;
    case 7:
      Hf(t2, e3[1], e3[2]);
      return;
    case 8:
      Gf(t2, e3[1], e3[2]);
      return;
    case 9:
      Jf(t2, e3[1], e3[2]);
      return;
    case 10:
      Yf(t2, e3[1], e3[2]);
      return;
    default:
      t2.valid = false;
  }
}
function pm(e3, t2, n2, r2) {
  let i2 = e3, a2 = Mf(e3);
  if (!a2 || !Xp(i2.mounted, t2, i2.initialBinding)) {
    i2.valid = false;
    return;
  }
  if (n2.length !== 0) {
    let e4 = () => {
      Zp(i2.mounted, t2) || (i2.valid = false);
    }, o2 = Rf(a2, n2, r2, (t3) => {
      o2 && zf(o2, () => void 0, t3), Ge(e4, Ue(), void 0, i2.mounted.scope);
    }, i2.mounted.scope);
    o2 ? i2.stopBindings.push(o2) : i2.valid = false;
  }
}
function mm(e3, t2, n2, r2, i2 = ``, a2 = ``) {
  let o2 = e3, s2 = o2, c2 = () => {
    rm(o2.mounted, t2, r2?.[0], r2?.[1], i2, a2) || s2 && (s2.valid = false);
  };
  n2 ? c2() : om(o2, c2), s2 = void 0;
}
function hm(e3, t2, n2, r2, i2 = ``, a2 = ``) {
  let o2 = e3;
  rm(o2.mounted, t2, n2, r2, i2, a2) || (o2.valid = false);
}
function gm(e3, t2, n2) {
  let r2 = e3;
  Ip(r2.mounted, t2, r2.initialBinding, r2.stopBindings, n2) || (r2.valid = false);
}
function _m(e3, t2) {
  let n2 = e3;
  Lp(n2.mounted, t2) || (n2.valid = false);
}
function vm(e3, t2) {
  let n2 = e3;
  Rp(n2.mounted, t2, n2.initialBinding, n2.stopBindings) || (n2.valid = false);
}
function ym(e3, t2) {
  let n2 = e3;
  zp(n2.mounted, t2, n2.initialBinding, n2.stopBindings) || (n2.valid = false);
}
function bm(e3, t2, n2, r2, i2) {
  let a2 = e3;
  if (a2.claiming !== true || !a2.valid || !a2.root || !a2.elements) return;
  let o2 = Math.floor(n2), s2 = o2 % 16;
  o2 = Math.floor(o2 / 16);
  let c2 = a2.root;
  for (; s2-- > 0; ) {
    let e4 = o2 % 128, t3 = e4 % 64, n3 = c2.children.item(e4 < 64 ? t3 : c2.children.length - t3 - 1);
    if (!n3) {
      a2.valid = false;
      return;
    }
    c2 = n3, o2 = Math.floor(o2 / 128);
  }
  if (!xm(c2, r2, i2 ?? a2.namespace)) {
    a2.valid = false;
    return;
  }
  a2.elements[t2] = c2;
}
function xm(e3, t2, n2) {
  let r2 = n2 === `contextual` ? e3.parentElement ? Ef(t2, e3.parentElement) ?? `http://www.w3.org/1999/xhtml` : e3.namespaceURI : n2 === `svg` ? wf : n2 === `mathml` ? Tf : Cf;
  return e3.localName.toLowerCase() === t2.toLowerCase() && e3.namespaceURI === r2;
}
function Sm(e3, t2, n2) {
  if (!e3.directClaims) return;
  let r2 = e3.bind;
  if (!e3.wire && !r2) return xm(t2, e3.root[0], e3.root[1] ?? e3.namespace) ? { elements: [t2], slotNodes: [], componentSlots: 0, work: e3.work } : void 0;
  let i2 = { claiming: true, root: t2, source: n2, namespace: Pm(t2), elements: [], slotNodes: [], componentSlots: 0, work: [0, 0], parents: [], container: t2, current: null, valid: true, began: false };
  if (e3.wire ? Cm(e3.wire, i2) : r2(i2), i2.valid && i2.began && i2.parents.length === 0) return i2;
}
function Cm(e3, t2) {
  let [n2, r2] = e3;
  if (Tm(t2, n2[0], n2[1], n2[2], n2[3])) for (let e4 of r2) switch (e4[0]) {
    case 0:
      Em(t2, e4[1], e4[2], e4[3], e4[4]);
      break;
    case 1:
      Dm(t2, e4[1]);
      break;
    case 2:
      Om(t2);
      break;
    case 3:
      km(t2, e4[1], e4[2], e4[3]);
      break;
    case 4:
      jm(t2, e4[1], e4[2], e4[3] === true, e4[4]);
      break;
    case 5:
      Am(t2, e4[1], e4[2], e4[3], e4[4] === true);
      break;
    case 6:
      bm(t2, e4[1], e4[2], e4[3], e4[4]);
      break;
    case 7:
      wm(t2, e4[1], e4[2]);
      break;
    case 8: {
      let n3 = t2;
      if (n3.valid && n3.source === `ssr`) {
        let t3 = n3.textRuns ??= { runs: [], values: /* @__PURE__ */ new Map() };
        n3.valid = im(n3.container, e4[1], t3), n3.current = null;
      }
      break;
    }
    default:
      t2.valid = false;
      return;
  }
}
function wm(e3, t2, n2) {
  if (!Mm(e3) || !e3.valid) return;
  let r2 = e3.elements[n2];
  if (!r2) {
    e3.valid = false;
    return;
  }
  e3.slotNodes[t2] = r2;
}
function Tm(e3, t2, n2, r2, i2) {
  return Mm(e3) ? (e3.began = true, e3.namespace = Pm(e3.root), e3.work = [r2, i2], xm(e3.root, t2, n2) ? (e3.elements[0] = e3.root, e3.current = e3.root.firstChild, true) : (e3.valid = false, true)) : false;
}
function Em(e3, t2, n2, r2, i2) {
  if (!Mm(e3) || !e3.valid) return;
  let a2 = Nm(e3.current, n2);
  if (!(a2 instanceof Element) || !xm(a2, r2, i2 ?? e3.namespace)) {
    e3.valid = false;
    return;
  }
  e3.elements[t2] = a2, e3.current = a2.nextSibling;
}
function Dm(e3, t2) {
  if (!Mm(e3) || !e3.valid) return;
  let n2 = e3.elements[t2];
  if (!n2) {
    e3.valid = false;
    return;
  }
  e3.parents.push(e3.current, e3.container), e3.container = n2, e3.current = n2.firstChild;
}
function Om(e3) {
  if (!Mm(e3) || !e3.valid) return;
  let t2 = e3.parents.pop(), n2 = e3.parents.pop();
  if (n2 === void 0 || !t2) {
    e3.valid = false;
    return;
  }
  e3.container = t2, e3.current = n2;
}
function km(e3, t2, n2, r2) {
  if (!Mm(e3) || !e3.valid || e3.textRuns?.values.has(t2)) return;
  if (e3.source === `ssr` && r2 === true) {
    let r3 = e3.current;
    for (let t3 = 0; t3 < n2; t3++) {
      if (!r3) {
        e3.valid = false;
        return;
      }
      r3 = r3.nextSibling;
    }
    if (r3 instanceof Comment && r3.data.startsWith(`exact:`)) {
      e3.valid = false;
      return;
    }
    let i3 = r3 instanceof Text ? r3 : (r3?.ownerDocument ?? e3.root.ownerDocument).createTextNode(``);
    r3 instanceof Text || e3.container.insertBefore(i3, r3), e3.slotNodes[t2] = i3, e3.current = r3 instanceof Text ? r3.nextSibling : r3;
    return;
  }
  let i2 = Nm(e3.current, n2), a2 = r2 === true ? `` : Fm(r2), o2 = e3.source === `template` ? `` : `x:${a2}`;
  if (!(i2 instanceof Comment) || i2.data !== o2) {
    e3.valid = false;
    return;
  }
  let s2 = i2.nextSibling, c2, l2;
  if (s2 instanceof Text ? (c2 = s2, l2 = s2.nextSibling) : (c2 = i2.ownerDocument.createTextNode(``), l2 = s2), !(l2 instanceof Comment)) {
    e3.valid = false;
    return;
  }
  if (e3.source === `ssr` ? l2.data !== `/x:${a2}` : l2.data !== ``) {
    e3.valid = false;
    return;
  }
  let u2 = l2.nextSibling;
  c2.parentNode === null && l2.parentNode?.insertBefore(c2, l2), e3.slotNodes[t2] = c2, i2.remove(), l2.remove(), e3.current = u2;
}
function Am(e3, t2, n2, r2, i2 = false) {
  if (!Mm(e3) || !e3.valid) return;
  let a2 = Nm(e3.current, n2), o2 = Fm(r2);
  if (!(a2 instanceof Comment) || a2.data !== `x:${o2}`) {
    e3.valid = false;
    return;
  }
  let s2;
  for (let e4 = a2.nextSibling; e4; e4 = e4.nextSibling) if (e4 instanceof Comment && e4.data === `/x:${o2}`) {
    s2 = e4;
    break;
  }
  if (!s2) {
    e3.valid = false;
    return;
  }
  e3.slotNodes[t2] = a2, i2 && Im(e3, t2), e3.current = s2.nextSibling;
}
function jm(e3, t2, n2, r2 = false, i2) {
  if (!Mm(e3) || !e3.valid) return;
  if (i2 !== void 0) {
    let a3 = Nm(e3.current, n2), o2 = e3.elements[i2];
    if (!o2 || o2.parentNode !== e3.container) {
      e3.valid = false;
      return;
    }
    e3.slotNodes[t2] = [e3.container, a3, o2], r2 && Im(e3, t2), e3.current = o2;
    return;
  }
  let a2 = e3.current;
  for (let t3 = 0; t3 < n2; t3++) {
    if (!a2) {
      e3.valid = false;
      return;
    }
    a2 = a2.nextSibling;
  }
  e3.slotNodes[t2] = [e3.container, a2], r2 && Im(e3, t2), e3.current = null;
}
function Mm(e3) {
  return e3.claiming === true;
}
function Nm(e3, t2) {
  for (let n2 = 0; e3 && n2 < t2; n2++) e3 = e3.nextSibling;
  return e3;
}
function Pm(e3) {
  return e3.namespaceURI === `http://www.w3.org/2000/svg` ? `svg` : e3.namespaceURI === `http://www.w3.org/1998/Math/MathML` ? `mathml` : `html`;
}
function Fm(e3) {
  return e3.startsWith(`exact:`) ? e3.slice(6) : e3;
}
function Im(e3, t2) {
  if (t2 < 31 && typeof e3.componentSlots == `number`) {
    e3.componentSlots |= 1 << t2;
    return;
  }
  if (typeof e3.componentSlots == `number`) {
    let t3 = /* @__PURE__ */ new Set();
    for (let n2 = 0; n2 < 31; n2++) e3.componentSlots & 1 << n2 && t3.add(n2);
    e3.componentSlots = t3;
  }
  e3.componentSlots.add(t2);
}
function Lm(e3, t2, n2) {
  let r2 = e3[t2];
  if (!(r2 instanceof Comment) || !r2.data.startsWith(`exact:cell:`)) return { contentStart: t2, endIndex: t2 + 1 };
  for (let i2 = t2 + 1; i2 < n2; i2++) {
    let n3 = e3[i2];
    if (n3 instanceof Comment && n3.data === `/${r2.data}`) return { start: r2, contentStart: t2 + 1, endIndex: i2 };
  }
}
function Rm(e3) {
  if (e3) for (let t2 of e3) t2 && (Ku(t2), Wu(t2));
}
function zm(e3, t2) {
  if (!(!e3 || !t2)) for (let n2 of e3) n2 && (Gu(n2, t2), Uu(n2, t2));
}
var Bm = /* @__PURE__ */ new WeakMap();
function Vm(e3, t2, n2) {
  let r2 = Bm.get(t2);
  r2 || Bm.set(t2, r2 = /* @__PURE__ */ new WeakMap());
  let i2 = r2.get(e3);
  i2 || r2.set(e3, i2 = /* @__PURE__ */ new Map());
  let a2 = Um(e3, n2), o2 = i2.get(a2);
  if (o2 || i2.set(a2, o2 = { uses: 0 }), o2.uses++, o2.template) return o2.template.content.cloneNode(true);
  let s2 = Hm(e3, t2, a2);
  return o2.uses > 1 ? (o2.template = s2, s2.content.cloneNode(true)) : s2.content;
}
function Hm(e3, t2, n2) {
  let r2 = t2.createElement(`template`);
  if (n2 === `html`) r2.innerHTML = e3.template;
  else {
    let i2 = n2 === `svg` ? wf : Tf, a2 = t2.createElementNS(i2, n2 === `svg` ? `svg` : `math`);
    for (a2.innerHTML = e3.template; a2.firstChild; ) r2.content.append(a2.firstChild);
  }
  return r2;
}
function Um(e3, t2) {
  if (e3.namespace !== `contextual`) return e3.namespace;
  if (!e3.attachmentTag) throw TypeError(`Contextual eXact render program omitted its attachment tag`);
  let n2 = t2 instanceof Element ? t2 : void 0, r2 = Ef(e3.attachmentTag, n2) ?? `http://www.w3.org/1999/xhtml`;
  return r2 === `http://www.w3.org/2000/svg` ? `svg` : r2 === `http://www.w3.org/1998/Math/MathML` ? `mathml` : `html`;
}
function Wm(e3, t2, n2, r2, i2) {
  let a2 = Il(t2);
  if (!a2) return;
  let o2 = a2.owner ?? r2, s2 = Jm(a2.program), c2 = Vm(s2, e3.container.ownerDocument, i2 ?? e3.container);
  if (!c2.firstChild || c2.firstChild !== c2.lastChild) return;
  let l2 = c2.firstChild;
  if (!(l2 instanceof Element)) return;
  let u2 = Sm(s2, l2, `template`);
  if (!u2) return;
  let d2 = Ll(t2);
  if (!d2) return;
  let f2 = { renderProgramReceipt: d2, dom: l2, scope: n2, children: [], renderProgram: { invocation: a2, programRoot: l2, slotNodes: u2.slotNodes, ...u2.componentSlots ? { componentSlots: u2.componentSlots } : {}, root: e3, bindingOwner: o2, parentInstance: r2 } };
  if (o2 && zm(u2.elements, o2), Gm(s2) && !um(f2)) {
    Rm(u2.elements);
    return;
  }
  return qm(e3, u2.work, false), f2;
}
function Gm(e3) {
  return e3.wire ? e3.wire[2].length !== 0 : !!e3.bind;
}
function Km(e3, t2) {
  let n2 = Il(t2);
  if (!n2 || !e3.renderProgram || e3.renderProgram.invocation.program.id !== n2.program.id) return false;
  let r2 = Ll(t2);
  return r2 ? (e3.renderProgramReceipt = r2, e3.renderProgram.invocation = n2, e3.renderProgram.refresh?.(), true) : false;
}
function qm(e3, t2, n2) {
  let [r2, i2] = t2;
  for (let t3 = +!n2; t3 < r2; t3++) ku(e3);
  if (!n2) for (let t3 = 0; t3 < i2; t3++) ku(e3);
}
function Jm(e3) {
  if (!e3.directClaims) throw TypeError(`Browser rendering requires a compiler-specialized client program`);
  return e3;
}
var Ym;
function Xm() {
  if (!Ym) throw Error(`Activity or Suspense rendering is unavailable because this artifact did not include the structural boundary capability`);
  return Ym;
}
function Zm(e3, t2, n2, r2, i2) {
  let a2 = { fragmentReceipt: t2, dom: kf(e3, `fragment`), scope: n2, children: [] };
  return a2.children = $(e3, [...t2.children], r2, n2, i2), a2;
}
function Qm(e3, t2, n2, r2, i2) {
  return n2.fragmentReceipt = r2, n2.children = Q(e3, t2, n2.children, [...r2.children], i2, n2.scope, nu(n2), n2), n2;
}
var $m;
function eh() {
  if (!$m) throw Error(`unsafeHtml() rendering is unavailable because this artifact did not include the DOM capability`);
  return $m;
}
function th(e3, t2, n2, r2, i2, a2, o2, s2) {
  let c2 = n2.range === `item` ? n2 : void 0, l2 = c2?.children[0] ?? n2, u2 = c2?.scope, d2 = i2.ownerScope ?? u2 ?? A(o2);
  i2.ownerScope && d2 !== u2 && bt(d2, o2);
  let f2 = Q(e3, t2, [l2], [i2.value], a2, d2, void 0, s2, false);
  if (f2.length !== 1) throw Error(`A keyed compiler operation must contribute one child range`);
  let p2 = f2[0];
  return c2 ? (p2.scope !== d2 && bt(p2.scope, d2), u2 && u2 !== d2 && u2.stop(), c2.operation = r2, c2.operationKey = i2.key, c2.scope = d2, c2.dom = p2.dom, c2.end = p2.end, c2.children = [p2], c2) : { operation: r2, operationKey: i2.key, range: `item`, dom: p2.dom, ...p2.end ? { end: p2.end } : {}, scope: d2, children: [p2] };
}
function nh(e3, t2, n2, r2) {
  let i2 = t2.portalTarget ?? hp(t2.portalReceipt), a2 = hp(n2);
  if (t2.portalReceipt = n2, i2 !== a2) {
    t2.children = Q(e3, i2, t2.children, [], r2, t2.scope), t2.portalTarget = a2;
    let o2 = _p(e3, a2);
    o2 === a2 && e3.portalTargets.add(a2), t2.children = gp(e3, o2, () => $(e3, [...n2.children], r2, t2.scope, a2));
    for (let n3 of t2.children) J(e3, a2, n3, null);
    return;
  }
  t2.children = gp(e3, _p(e3, a2), () => Q(e3, a2, t2.children, [...n2.children], r2, t2.scope));
}
var rh = class {
  mounted;
  root;
  parent;
  parentInstance;
  parentScope;
  structuralOwner;
  constructor(e3, t2, n2, r2, i2, a2) {
    this.mounted = e3, this.root = t2, this.parent = n2, this.parentInstance = r2, this.parentScope = i2, this.structuralOwner = a2;
  }
  [zc](e3, t2) {
    if (this.mounted.operationKey === t2.key) return !this.root || !this.parent ? this.mounted : th(this.root, this.parent, this.mounted, e3, t2, this.parentInstance, this.parentScope, this.structuralOwner);
  }
  [Pl](e3, t2) {
    if (this.mounted.renderProgram?.invocation.program.id === t2.invocation.program.id) return !this.root || !this.parent || Km(this.mounted, e3) ? this.mounted : void 0;
  }
  [cc](e3, t2) {
    let n2 = this.mounted.componentReceipt;
    if (n2?.contract.artifact === t2.contract.artifact && n2.key === t2.key && n2.domain === t2.domain) return !this.root || !this.parent || sp(this.mounted, t2) ? this.mounted : void 0;
  }
  [Wo](e3, t2) {
    let n2 = this.mounted.intrinsicReceipt;
    if (n2?.tag !== t2.tag || n2.key !== t2.key || n2.domain !== t2.domain) return;
    if (!this.root || !this.parent) return this.mounted;
    this.mounted.intrinsicReceipt = t2;
    let r2 = this.mounted.children[0]?.textHostPresentation;
    return r2 ? r2.receive(t2.children) : this.mounted.children = Q(this.root, this.mounted.dom, this.mounted.children, [...bp(this.root, t2.tag, t2.children)], this.parentInstance, this.mounted.scope, void 0, this.mounted), lf(this.root, this.mounted, { ...n2.props }, { ...t2.props }), this.mounted;
  }
  [Oc](e3, t2) {
    let n2 = this.mounted.childRangeReceipt;
    if (!(!n2 || n2.markerId !== t2.markerId || n2.domain !== t2.domain)) return !this.root || !this.parent || fh(this.root, this.parent, this.mounted, t2, this.parentInstance), this.mounted;
  }
  [Ic](e3, t2) {
    if (this.mounted.activityReceipt?.domain === t2.domain) return !this.root || !this.parent || Xm().patchActivityReceipt(this.root, this.parent, this.mounted, t2), this.mounted;
  }
  [Nc](e3, t2) {
    if (this.mounted.suspenseReceipt?.domain === t2.domain) return !this.root || !this.parent || Xm().patchSuspenseReceipt(this.root, this.parent, this.mounted, t2, this.parentInstance), this.mounted;
  }
  [gc](e3, t2) {
    let n2 = this.mounted.fragmentReceipt;
    if (!(!n2 || n2.key !== t2.key || n2.domain !== t2.domain) && !!n2.presentation == !!t2.presentation) return !this.root || !this.parent ? this.mounted : t2.presentation ? af().patchFragmentPresentation(this.root, this.parent, this.mounted, t2, this.parentInstance) : (Qm(this.root, this.parent, this.mounted, t2, this.parentInstance), this.mounted);
  }
  [pc](e3, t2) {
    let n2 = this.mounted.targetReceipt;
    if (!(!n2 || n2.key !== t2.key || n2.domain !== t2.domain)) return !this.root || !this.parent || af().patch(this.root, this.parent, this.mounted, t2, this.parentInstance), this.mounted;
  }
  [Wc](e3, t2) {
    if (this.mounted.unsafeHtmlReceipt?.domain !== t2.domain) return;
    if (!this.root || !this.parent) return this.mounted;
    this.mounted.unsafeHtmlReceipt = t2;
    let n2 = eh();
    return n2.assertAllowed(this.root), n2.bind(this.root, this.mounted, t2.value), this.mounted;
  }
  [Kc](e3, t2) {
    if (this.mounted.portalReceipt?.domain === t2.domain) return !this.root || !this.parent || nh(this.root, this.mounted, t2, this.parentInstance), this.mounted;
  }
  [Yc](e3, t2) {
  }
  [Xc](e3, t2) {
    if (this.mounted.serverSlotReceipt?.id === t2.id) return !this.root || !this.parent || (this.mounted.serverSlotReceipt = t2), this.mounted;
  }
};
function ih(e3, t2) {
  return Ho(t2, new rh(e3))?.value !== void 0;
}
function ah(e3, t2, n2, r2, i2, a2, o2) {
  let s2 = Ho(r2, new rh(n2, e3, t2, i2, a2, o2))?.value;
  return s2 && (s2.operation = r2), s2;
}
function oh(e3, t2) {
  let n2 = { mounts: /* @__PURE__ */ new Map(), commits: [] };
  return e3.instance && sh(e3, e3.instance.domain, n2.mounts, t2), n2;
}
function sh(e3, t2, n2, r2) {
  let i2 = [];
  for (let a2 of e3.children) {
    let e4 = a2.instance?.domain ?? a2.componentReceipt?.domain, o2 = a2.operation ?? a2.componentReceipt;
    if (o2 && e4 && e4 !== t2) {
      let e5 = n2.get(o2) ?? [];
      e5.push({ mounted: a2, parent: a2.dom.parentNode ?? r2 }), n2.set(o2, e5);
      continue;
    }
    sh(a2, t2, n2, a2.portalTarget ?? r2), i2.push(a2);
  }
  e3.children = i2;
}
function Q(e3, t2, n2, r2, i2, a2, o2, s2, c2 = true) {
  return el(i2), e3.interactionWork && e3.interactionWork.reconciliations++, Xl(e3, `patch children`, () => ({ parent: q(t2), oldCount: n2.length, nextCount: r2.length, before: q(o2) })), Ou(e3, () => Ju(e3, () => ch(e3, t2, n2, Dp(r2), i2, a2, o2, s2, c2)));
}
function ch(e3, t2, n2, r2, i2, a2, o2, s2, c2) {
  if (n2.length === r2.length && r2.length > 0 && r2.every((e4, t3) => e4.scalar !== void 0 && n2[t3]?.scalar && n2[t3].dom.nodeType === 3)) {
    for (let o3 = 0; o3 < r2.length; o3++) {
      let s3 = r2[o3];
      uh(e3, t2, n2[o3], s3.value, s3.scalar, i2, a2);
    }
    return n2;
  }
  let l2 = /* @__PURE__ */ new Map(), u2 = [];
  for (let e4 = 0; e4 < n2.length; e4++) {
    let t3 = n2[e4], r3 = Op(t3);
    if (r3 === void 0) u2.push({ mounted: t3, index: e4 });
    else {
      if (l2.has(r3)) throw Error(`Duplicate key "${r3}" in mounted children`);
      l2.set(r3, { mounted: t3, index: e4 });
    }
  }
  let d2 = /* @__PURE__ */ new Set(), f2 = Array(r2.length), p2 = 0;
  for (let e4 = 0; e4 < r2.length; e4++) {
    let t3 = r2[e4];
    if (t3.key === void 0) f2[e4] = u2[p2++];
    else {
      if (d2.has(t3.key)) throw Error(`Duplicate key "${t3.key}" in rendered children`);
      d2.add(t3.key), f2[e4] = l2.get(t3.key);
    }
  }
  let m2 = new Set(f2.flatMap((e4) => e4 ? [e4.mounted] : [])), h2 = Sp(f2.map((e4) => e4?.index ?? -1)), g2 = Array(r2.length), _2 = o2 ?? null;
  for (let n3 = r2.length - 1; n3 >= 0; n3--) {
    let o3 = r2[n3], s3 = f2[n3], c3 = o3.native ? s3 ? Object.is(s3.mounted.operation, o3.value) ? s3.mounted : lh(e3, t2, s3.mounted, o3.value, i2, a2, void 0) : (() => {
      let n4 = Tp(e3, t2, o3.value);
      return n4 ? lh(e3, t2, n4, o3.value, i2, a2, void 0) : $(e3, [o3.value], i2, a2, t2)[0];
    })() : o3.scalar === void 0 ? (() => {
      throw TypeError(`Unsupported native child operation`);
    })() : uh(e3, t2, s3?.mounted, o3.value, o3.scalar, i2, a2);
    g2[n3] = c3, (!s3 || !h2.has(n3)) && J(e3, t2, c3, _2), _2 = c3.dom;
  }
  let v2 = df();
  for (let r3 of n2) m2.has(r3) || wp(e3, t2, r3, `reconcile-removed`) || (X(v2, () => Z(r3)), X(v2, () => gf(t2, r3)));
  pf(v2);
  let y2 = g2.length > 0 && g2.length === n2.length && g2.every((e4, t3) => e4 === n2[t3] && e4.scalar === true);
  return c2 && !y2 && kp(e3, i2, s2), g2;
}
function lh(e3, t2, n2, r2, i2, a2, o2) {
  if (n2.enhancement && ih(n2.enhancement.target, r2)) return bf().patch(e3, n2, r2, t2, i2, a2, (n3, r3, i3, a3) => n3 ? lh(e3, t2, n3, r3, i3, a3, o2) : xh(e3, r3, i3, a3, t2));
  let s2 = ah(e3, t2, n2, r2, i2, a2, o2);
  if (s2) return s2;
  let c2 = e3.replacementParking, l2 = oh(n2, t2);
  e3.replacementParking = l2;
  let u2;
  try {
    u2 = $(e3, [r2], i2, a2, t2)[0];
  } finally {
    e3.replacementParking = c2;
  }
  if (!u2) throw Error(`Compiler-issued child operation did not mount a range`);
  for (let e4 of l2.commits) e4();
  J(e3, t2, u2, n2.dom), wp(e3, t2, n2, `reconcile-replaced`) || (Z(n2), gf(t2, n2));
  for (let e4 of l2.mounts.values()) for (let t3 of e4) hf(t3.parent, t3.mounted);
  return u2;
}
function uh(e3, t2, n2, r2, i2, a2, o2) {
  if (n2?.scalar && n2.dom.nodeType === 3) return n2.scalarValue !== i2 && (n2.dom.data = i2), n2.scalarValue = i2, mp(n2, r2), n2;
  let s2 = xh(e3, r2, a2, o2, t2);
  return n2 ? (J(e3, t2, s2, n2.dom), wp(e3, t2, n2, `reconcile-replaced`) || (Z(n2), gf(t2, n2)), s2) : s2;
}
function dh(e3, t2, n2, r2, i2) {
  let a2 = { childRangeReceipt: t2, dom: kf(e3, `dynamic`), scope: n2, children: [] }, o2 = gh(t2, r2, (e4) => {
    mh(a2, e4);
  });
  return a2.dynamicChildren = o2, a2.children = $(e3, o2, r2, n2, i2), ph(e3, a2, t2, r2), a2;
}
function fh(e3, t2, n2, r2, i2) {
  n2.stop?.(), n2.stop = void 0, n2.childRangeReceipt = r2, n2.suspensionRegistration?.cancel(), n2.suspensionRegistration = void 0;
  let a2 = gh(r2, i2, (e4) => {
    mh(n2, e4);
  });
  return n2.dynamicChildren = a2, n2.children = Q(e3, t2, n2.children, a2, i2, n2.scope, nu(n2), n2), ph(e3, n2, r2, i2, t2), n2;
}
function ph(e3, t2, n2, r2, i2) {
  let a2 = false, o2, s2 = () => {
    let s3 = gh(n2, r2, (e4) => {
      mh(t2, e4);
    });
    if (a2) {
      o2 = s3;
      return;
    }
    a2 = true;
    try {
      let n3 = s3;
      for (; n3; ) {
        if (o2 = void 0, !_h(t2.dynamicChildren, n3)) {
          let a3 = t2.dom.parentNode ?? i2;
          if (!a3) {
            for (let e4 of t2.children) hf(document.createDocumentFragment(), e4);
            t2.dynamicChildren = n3, t2.children = $(e3, n3, r2, t2.scope), n3 = o2;
            continue;
          }
          t2.dynamicChildren = n3, t2.children = C(() => Q(e3, a3, t2.children, n3, r2, t2.scope, nu(t2), t2)), r2 && qd(r2);
        }
        n3 = o2;
      }
    } finally {
      a2 = false, o2 = void 0;
    }
  };
  t2.stop = _n(s2, { scope: t2.scope, onSchedule: s2 });
}
function mh(e3, t2) {
  let n2 = e3.suspensionRegistration;
  if (n2?.settlement === t2.settlement) {
    t2.cancel();
    return;
  }
  n2?.cancel(), e3.suspensionRegistration = t2;
}
function hh(e3, t2, n2, r2) {
  ph(e3, t2, n2, r2, t2.dom.parentNode ?? void 0);
}
function gh(e3, t2, n2) {
  let r2 = e3.dynamicComponent;
  if (r2?.inspection.status === `pending`) {
    let e4 = r2.readiness?.();
    if (e4) {
      let r3 = $o(t2, e4);
      r3 !== true && r3 !== false && n2?.(r3);
    }
    return [];
  }
  if (r2?.inspection.status === `failed`) {
    let e4 = W(t2, U(r2.inspection.error, `render`, t2, `dynamic-component`));
    return e4 ? B(e4()) : [];
  }
  try {
    return B(F(e3.value));
  } catch (e4) {
    if (vh(e4)) return Qo(t2, e4), [];
    let n3 = W(t2, U(e4, `render`, t2, `compiled-child-range`));
    return n3 ? B(n3()) : [];
  }
}
function _h(e3, t2) {
  if (!e3 || e3.length !== t2.length) return false;
  for (let n2 = 0; n2 < t2.length; n2++) if (!Object.is(e3[n2], t2[n2])) return false;
  return true;
}
function vh(e3) {
  return (typeof e3 == `object` || typeof e3 == `function`) && e3 !== null && typeof e3.then == `function`;
}
var yh = class {
  root;
  parentInstance;
  parentScope;
  parentNode;
  constructor(e3, t2, n2, r2) {
    this.root = e3, this.parentInstance = t2, this.parentScope = n2, this.parentNode = r2;
  }
  [cc](e3, t2) {
    return np(this.root, t2, this.parentInstance, this.parentScope, this.parentNode);
  }
  [Pl](e3, t2) {
    let n2 = Wm(this.root, e3, A(this.parentScope), this.parentInstance, this.parentNode);
    if (!n2) throw Error(`Compiler-closed render program could not be mounted`);
    return n2;
  }
  [Wo](e3, t2) {
    return ju(this.root, () => xp(this.root, t2, A(this.parentScope), this.parentInstance, this.parentNode));
  }
  [gc](e3, t2) {
    return Zm(this.root, t2, A(this.parentScope), this.parentInstance, this.parentNode);
  }
  [pc](e3, t2) {
    return af().mount(this.root, t2, A(this.parentScope), this.parentInstance, this.parentNode);
  }
  [Oc](e3, t2) {
    return dh(this.root, t2, A(this.parentScope), this.parentInstance, this.parentNode);
  }
  [Ic](e3, t2) {
    return Xm().mountActivityReceipt(this.root, t2, A(this.parentScope), this.parentInstance, this.parentNode);
  }
  [Nc](e3, t2) {
    return Xm().mountSuspenseReceipt(this.root, t2, A(this.parentScope), this.parentInstance, this.parentNode);
  }
  [Wc](e3, t2) {
    return eh().mount(this.root, t2, this.parentScope);
  }
  [zc](e3, t2) {
    let n2 = t2.ownerScope ?? A(this.parentScope);
    t2.ownerScope && bt(n2, this.parentScope);
    let r2 = $(this.root, [t2.value], this.parentInstance, n2, this.parentNode)[0];
    if (!r2) throw n2.stop(), Error(`A keyed compiler operation must contribute one child range`);
    return { operation: e3, operationKey: t2.key, range: `item`, dom: r2.dom, ...r2.end ? { end: r2.end } : {}, scope: n2, children: [r2] };
  }
  [Kc](e3, t2) {
    return Sh(this.root, t2, this.parentInstance, this.parentScope);
  }
  [Yc](e3, t2) {
    throw TypeError(`A server boundary cannot be mounted by the DOM target (${t2.name})`);
  }
  [Xc](e3, t2) {
    return gu(this.root, t2, A(this.parentScope));
  }
};
function bh(e3, t2) {
  return e3.operation = t2, e3;
}
function xh(e3, t2, n2, r2, i2) {
  let a2 = tl(e3, t2, n2, r2, i2) ?? dp(e3, t2, n2, r2);
  if (a2) return a2;
  let o2 = $(e3, [t2], n2, r2, i2);
  if (o2.length !== 1) throw Error(`A renderer child operation must contribute exactly one mounted range`);
  return o2[0];
}
function $(e3, t2, n2, r2, i2) {
  el(n2), fp(t2);
  let a2 = [], o2 = new yh(e3, n2, r2, i2);
  try {
    for (let s2 of t2) {
      let t3 = tl(e3, s2, n2, r2, i2) ?? dp(e3, s2, n2, r2);
      if (t3) {
        a2.push(t3);
        continue;
      }
      let c2 = wh(e3, s2, n2, r2, i2);
      if (c2) {
        a2.push(c2);
        continue;
      }
      let l2 = Ho(s2, o2);
      if (l2) {
        a2.push(bh(l2.value, s2));
        continue;
      }
      let u2 = pp(s2);
      if (u2 !== void 0) {
        ku(e3);
        let t4 = A(r2), n3 = { scalar: true, scalarValue: u2, dom: document.createTextNode(u2), scope: t4, children: [] };
        mp(n3, s2), a2.push(n3);
        continue;
      }
      if (s2 == null || s2 === false || s2 === true) {
        ku(e3);
        continue;
      }
      throw TypeError(`Native eXact children must be compiler-issued operations, scalar values, or empty placeholders`);
    }
    return a2;
  } catch (e4) {
    throw Th(a2, void 0, e4), e4;
  }
}
function Sh(e3, t2, n2, r2) {
  let i2 = A(r2), a2 = document.createComment(`exact:portal`), o2 = hp(t2), s2 = { portalReceipt: t2, dom: a2, scope: i2, children: [], portalTarget: o2 }, c2 = _p(e3, o2);
  return c2 === o2 && e3.portalTargets.add(o2), s2.children = gp(e3, c2, () => Ch(e3, o2, [...t2.children], n2, i2)), s2;
}
function Ch(e3, t2, n2, r2, i2) {
  let a2 = $(e3, n2, r2, i2, t2);
  try {
    for (let n3 of a2) n3.serverSlotReceipt && vu(t2, n3), J(e3, t2, n3, null);
    return a2;
  } catch (e4) {
    throw Th(a2, t2, e4), e4;
  }
}
function wh(e3, t2, n2, r2, i2) {
  let a2 = yf();
  if (!a2 || !a2.has(t2)) return;
  let o2 = (t3, n3, r3, i3) => {
    let a3 = xh(e3, t3, n3, r3, i3);
    return a3.operation = t3, a3;
  };
  a2.install(e3, o2);
  let s2 = a2.mountDirect?.(e3, t2, n2, r2, o2);
  if (s2) return s2;
  if (!((e3.enhancementNesting ?? 0) > 0)) {
    e3.enhancementNesting = 1;
    try {
      return a2.activate(e3, o2(t2, n2, r2, i2), n2, r2, o2);
    } finally {
      e3.enhancementNesting = 0;
    }
  }
}
function Th(e3, t2, n2) {
  for (let r2 = e3.length - 1; r2 >= 0; r2--) {
    let i2 = e3[r2], a2 = t2 ?? i2.dom.parentNode ?? document.createDocumentFragment();
    try {
      hf(a2, i2);
    } catch (e4) {
      pl(n2, e4);
    }
  }
}
function Eh(e3, t2, n2, r2) {
  let i2 = Oh(t2) ?? n2.componentDomain ?? (n2.inspection ? qa({ executionRoot: n2.inspection.executionRoot, inspection: n2.inspection, logger: n2.logger }) : void 0), a2 = Df(n2, () => Dh(c2)), o2 = [[ja.id, a2]];
  n2.logger && o2.push([Aa.id, n2.logger]);
  let s2 = new Map(o2), c2 = { container: e3, delegated: /* @__PURE__ */ new Map(), errors: a2, portalTargets: /* @__PURE__ */ new Set(), current: t2, version: r2.version, ...i2 ? { domain: i2 } : {}, debugMarkers: false, maxTreeDepth: Eu(n2.maxTreeDepth), traversalDepth: 0, maxTreeNodes: Du(n2.maxTreeNodes), traversedNodes: 0, workDepth: 0, focusTransactionDepth: 0, workBudget: n2.workBudget, allowUnsafeHtml: n2.allowUnsafeHtml ?? false, onUnsafeHtml: n2.onUnsafeHtml, onProfile: n2.onProfile, logger: n2.logger, componentLogging: i2 ? Ja(i2) : void 0, ambientContexts: s2, enhancementCatalog: n2.enhancementCatalog, ...r2.mode ? { mode: r2.mode } : {}, ...r2.markerlessHydration ? { markerlessHydration: true } : {} };
  return c2;
}
function Dh(e3) {
  let t2 = e3?.mounted;
  !t2 || e3.errors.errors.length === 0 || (t2.children = Q(e3, e3.container, t2.children, [Of(e3.errors.errors)], t2.instance, t2.scope, nu(t2), t2));
}
function Oh(e3) {
  return zo(e3) ? Vo(e3) : void 0;
}
function kh(e3, t2, n2, r2 = n2.inspection) {
  return r2 && !e3 && !t2?.domain && !n2.componentDomain ? { ...n2, componentDomain: qa({ executionRoot: r2.executionRoot, inspection: r2, logger: n2.logger }) } : n2;
}
function Ah(e3, t2) {
  e3.logger = t2.logger, e3.debugMarkers = t2.debugMarkers ?? false, e3.workBudget = t2.workBudget, e3.allowUnsafeHtml = t2.allowUnsafeHtml ?? e3.allowUnsafeHtml, e3.onUnsafeHtml = t2.onUnsafeHtml ?? e3.onUnsafeHtml, e3.onProfile = t2.onProfile ?? e3.onProfile, e3.enhancementCatalog = t2.enhancementCatalog ?? e3.enhancementCatalog;
}
function jh(e3, t2, n2, r2) {
  let i2 = new Nh(e3, t2.ownedRange, n2), a2 = t2.commit(i2, r2);
  return i2.finishConstruction(), a2;
}
function Mh(e3, t2, n2, r2, i2) {
  let a2 = new Nh(e3, t2, i2);
  return n2.attach(r2, a2, `hydrate`), a2.attached ? (a2.finishConstruction(), true) : false;
}
var Nh = class {
  root;
  mounted;
  adopt;
  attached = false;
  constructing = true;
  invalidatedDuringConstruction = false;
  constructor(e3, t2, n2) {
    this.root = e3, this.mounted = t2, this.adopt = n2;
  }
  [tc](e3, t2, n2, r2) {
    let i2 = this.assertAttachment(e3, t2, r2);
    return $c(this.mounted, n2), this.attachChildren(i2, n2);
  }
  [nc](e3, t2, n2) {
    let r2 = this.assertAttachment(e3, t2, n2);
    return this.attached = ep().hydrate(this.root, this.mounted, e3, r2), this.mounted;
  }
  finishConstruction() {
    return this.constructing = false, this.invalidatedDuringConstruction;
  }
  assertAttachment(e3, t2, n2) {
    if (n2 !== `hydrate` || t2 !== this.mounted.instance || e3 !== this.mounted.clientArtifact) throw TypeError(`Client component attached through an incompatible hydration target`);
    return t2;
  }
  attachChildren(e3, t2) {
    let n2 = yf();
    this.mounted.componentReceipt?.fragmentTarget && (t2 = n2.projectComponent(this.mounted, t2));
    let r2 = n2?.adoptComponent ? n2.adoptComponent(this.root, this.mounted, t2, this.adopt) : this.adopt(t2);
    if (!r2) throw Error(`Compiler-owned component output did not match the hydrated DOM`);
    return this.mounted.children = r2, n2?.invalidate?.(this.mounted), qd(e3, true, Zd(this.root)), e3.markMounted(), this.attached = true, this.mounted;
  }
};
function Ph(e3, t2, n2, r2 = e3.length) {
  let i2 = e3[t2];
  if (!(i2 instanceof Comment) || !i2.data.startsWith(`exact:component:`)) return;
  let a2 = -1;
  for (let n3 = t2 + 1; n3 < r2; n3++) {
    let t3 = e3[n3];
    if (t3 instanceof Comment && t3.data === `/${i2.data}`) {
      a2 = n3;
      break;
    }
  }
  if (a2 < 0) return;
  let o2 = i2.data.split(`:`);
  return { start: i2, endIndex: a2, matches: o2.length >= 4 && qc(o2[3]) === n2 };
}
function Fh(e3, t2, n2, r2, i2, a2, o2, s2) {
  let c2 = A(a2), l2 = Ph(n2, r2, t2.contract.artifact.id, o2);
  if ((e3.markerlessHydration || s2) && !l2) return Ih(e3, t2, n2, r2, i2, c2, o2);
  if (!l2) {
    c2.stop();
    return;
  }
  if (!l2.matches) {
    let o3 = n2[r2]?.parentNode;
    if (!o3) {
      c2.stop();
      return;
    }
    c2.stop();
    let s3 = np(e3, t2, i2, a2, o3);
    J(e3, o3, s3, n2[r2]);
    for (let e4 = r2; e4 <= l2.endIndex; e4++) {
      let t3 = n2[e4];
      t3?.parentNode === o3 && o3.removeChild(t3);
    }
    return { mounted: s3, next: l2.endIndex + 1 };
  }
  let u2 = e3.preparedComponents?.get(t2);
  if (u2) {
    c2.stop(), e3.preparedComponents.delete(t2);
    let a3 = u2.attachment.ownedRange;
    if (u2.attachment.owner.parent !== i2) throw Error(`Prepared component cannot adopt beneath a different context owner`);
    return a3.dom = l2.start, a3.end = n2[l2.endIndex], jh(e3, u2.attachment, (t3) => Xh(e3, t3, n2, a3.instance, a3.scope, r2 + 1, l2.endIndex), u2.project), { mounted: a3, next: l2.endIndex + 1 };
  }
  let d2 = { componentReceipt: t2, dom: l2.start, end: n2[l2.endIndex], scope: c2, children: [], clientArtifact: Lh(t2) };
  try {
    let a3 = Rh(e3, t2, i2);
    Sf(d2, a3);
    let o3 = d2.clientArtifact;
    if (!Mh(e3, d2, o3, a3, (t3) => Xh(e3, t3, n2, a3, c2, r2 + 1, l2.endIndex))) {
      Z(d2);
      return;
    }
    return { mounted: d2, next: l2.endIndex + 1 };
  } catch {
    Z(d2);
    return;
  }
}
function Ih(e3, t2, n2, r2, i2, a2, o2) {
  let s2 = { componentReceipt: t2, dom: document.createTextNode(``), end: void 0, scope: a2, children: [], clientArtifact: Lh(t2) };
  try {
    let c2 = Rh(e3, t2, i2);
    Sf(s2, c2);
    let l2 = r2, u2 = s2.clientArtifact;
    if (!Mh(e3, s2, u2, c2, (t3) => {
      let i3 = Xh(e3, t3, n2, c2, a2, r2, o2);
      if (i3) return l2 = o2, i3;
    })) return;
    let d2 = s2.children[0]?.dom, f2 = s2.children.at(-1);
    if (!d2 || !f2) {
      let e4 = n2[o2] ?? n2[r2], t3 = e4?.parentNode;
      return t3 ? (t3.insertBefore(s2.dom, e4), s2.end = document.createTextNode(``), t3.insertBefore(s2.end, e4), { mounted: s2, next: l2 }) : void 0;
    }
    let p2 = d2?.parentNode;
    if (!p2) return;
    let m2 = f2.end ?? f2.dom;
    return p2.insertBefore(s2.dom, d2), s2.end = document.createTextNode(``), p2.insertBefore(s2.end, m2.nextSibling), { mounted: s2, next: l2 };
  } catch {
    Z(s2);
    return;
  }
}
function Lh(e3) {
  let t2 = e3.contract.artifact;
  if (t2.target !== `client`) throw TypeError(`Hydration received a non-client component receipt`);
  return t2;
}
function Rh(e3, t2, n2) {
  let r2 = Lh(t2), i2 = { ...t2.props };
  t2.children.length === 1 ? i2.children = t2.children[0] : t2.children.length > 1 && (i2.children = t2.children);
  let a2 = t2.domain ?? n2?.domain ?? e3.domain ?? Ka;
  return no(a2, () => j(n2?.scope, () => r2.construct(n2, i2, n2?.ambientContexts ?? e3.ambientContexts, a2, void 0, t2.contract)));
}
function zh(e3, t2, n2, r2, i2, a2, o2) {
  let s2 = A(a2), c2 = n2[r2];
  if (!(c2 instanceof Element) || c2.tagName.toLowerCase() !== t2.tag.toLowerCase()) {
    s2.stop();
    return;
  }
  let l2 = qh(c2), u2 = t2.tag === `title` || t2.tag === `textarea`, d2 = c2.firstChild;
  if (u2 && (c2.childNodes.length > 1 || d2 && !(d2 instanceof Text))) {
    s2.stop();
    return;
  }
  let f2 = u2 ? [yp(e3, t2.children, i2, s2, d2)] : o2(e3, [...bp(e3, t2.tag, t2.children)], Jh(c2, l2), i2, s2);
  if (!f2) {
    s2.stop();
    return;
  }
  return u2 && !d2 && c2.appendChild(f2[0].dom), i2 && Uu(c2, i2), Dd(e3, c2, {}, t2.props, s2, false), { mounted: { intrinsicReceipt: t2, dom: c2, scope: s2, children: f2, ...l2 ? { childEnd: l2.start } : {} }, next: r2 + 1 };
}
function Bh(e3, t2, n2, r2, i2, a2, o2, s2, c2) {
  let l2 = A(o2), u2 = r2[i2];
  if (n2 === `fragment` && t2.children.some(Ec) && u2 instanceof Element && u2.parentNode?.nodeType === Node.DOCUMENT_NODE) {
    let n3 = c2(e3, [...t2.children], r2, a2, l2, i2, s2);
    if (!n3) {
      l2.stop();
      return;
    }
    let o3 = document.createComment(`exact:document`), d3 = document.createComment(`/exact:document`);
    return u2.parentNode.insertBefore(o3, u2), u2.parentNode.insertBefore(d3, r2[s2 - 1].nextSibling), { mounted: { fragmentReceipt: t2, dom: o3, end: d3, scope: l2, children: n3 }, next: s2 };
  }
  if (!(u2 instanceof Comment) || !u2.data.startsWith(`exact:${n2}:`)) {
    l2.stop();
    return;
  }
  let d2 = $h(r2, i2, u2.data, s2);
  if (d2 < 0) {
    l2.stop();
    return;
  }
  let f2 = c2(e3, [...t2.children], r2, a2, l2, i2 + 1, d2);
  if (!f2) {
    l2.stop();
    return;
  }
  let p2 = { ...n2 === `fragment` ? { fragmentReceipt: t2 } : { targetReceipt: t2, targetBoundary: {} }, dom: u2, end: r2[d2], scope: l2, children: f2 };
  return n2 === `target` && sf(e3, p2, a2), { mounted: p2, next: d2 + 1 };
}
function Vh(e3, t2, n2, r2, i2, a2, o2, s2) {
  let c2 = A(a2), l2 = n2[r2], u2 = l2 instanceof Comment && t2.markerId !== void 0 && l2.data.startsWith(`exact:fragment:`) && l2.data.endsWith(`:${t2.markerId}`);
  if (!(l2 instanceof Comment) || !Zh(l2.data) && !u2) {
    c2.stop();
    return;
  }
  let d2 = $h(n2, r2, l2.data, o2);
  if (d2 < 0) {
    c2.stop();
    return;
  }
  let f2 = t2.dynamicComponent ? [] : gh(t2, i2), p2 = s2(e3, f2, n2, i2, c2, r2 + 1, d2);
  if (!p2) {
    c2.stop();
    return;
  }
  let m2 = { childRangeReceipt: t2, dom: l2, end: n2[d2], scope: c2, children: p2, dynamicChildren: f2 };
  return hh(e3, m2, t2, i2), { mounted: m2, next: d2 + 1 };
}
function Hh(e3) {
  let t2 = [];
  for (let n2 = e3.firstChild; n2; n2 = n2.nextSibling) t2.push(n2);
  return t2;
}
function Uh(e3, t2, n2) {
  let r2 = e3.renderProgram, i2 = r2.invocation.program.listBindings === true || r2.invocation.program.keyedChildren !== void 0;
  i2 && t2?.beginRender();
  try {
    for (let i3 = 0; i3 < r2.slotNodes.length; i3++) {
      let a2 = Vp(r2, i3);
      if (a2 === void 0) continue;
      let o2 = Up(r2.componentSlots, i3), s2 = r2.slotNodes[i3], c2 = Hp(s2) ? s2 : void 0, l2 = s2 instanceof Node ? s2 : void 0, u2 = c2 ? void 0 : Fp(l2, a2), d2 = c2?.[0] ?? l2?.parentNode;
      if (!d2 || !c2 && (!(l2 instanceof Comment) || !u2)) return false;
      let f2 = Hh(d2), p2 = c2 ? c2[1] ? f2.indexOf(c2[1]) : f2.length : f2.indexOf(l2) + 1, m2 = c2?.[2] ?? null, h2 = m2 ? f2.indexOf(m2) : c2 ? f2.length : f2.indexOf(u2);
      if (p2 < 0 || h2 < p2) return false;
      let g2 = o2 ? dc(j(e3.scope, () => Rl(r2.invocation, i3))) : void 0, _2 = g2 ? [] : j(e3.scope, () => qp(r2.invocation.program.keyedChildren, i3) ? Kp(r2.invocation, i3, t2) : Gp(r2.invocation, i3, t2)), v2 = g2 ? Fh(r2.root, g2, f2, p2, t2, e3.scope, h2, true) : void 0, y2 = g2 ? v2 ? [v2.mounted] : void 0 : n2(_2, f2, t2, e3.scope, p2, h2, false);
      if (!y2) return false;
      (r2.childSlots ??= [])[i3] = { parent: d2, before: c2 ? m2 : u2, children: y2, ...g2 ? { componentValue: g2 } : { value: _2 } };
    }
  } finally {
    i2 && t2?.endRender();
  }
  return Yp(e3), true;
}
function Wh(e3, t2, n2, r2, i2, a2) {
  let o2 = Il(t2);
  if (!o2) return;
  let s2 = o2.owner ?? i2, c2 = Jm(o2.program);
  if (!(n2 instanceof Element)) return;
  let l2 = Sm(c2, n2, `ssr`);
  if (!l2) return;
  let u2 = Ll(t2);
  if (!u2) return;
  let d2 = { renderProgramReceipt: u2, dom: n2, scope: r2, children: [], renderProgram: { invocation: o2, programRoot: n2, slotNodes: l2.slotNodes, ...l2.textRuns ? { textRuns: l2.textRuns } : {}, ...l2.componentSlots ? { componentSlots: l2.componentSlots } : {}, root: e3, bindingOwner: s2, parentInstance: i2 } };
  if (Uh(d2, i2, a2)) {
    if (zm(l2.elements, s2), !(!Gm(c2) || um(d2))) {
      Rm(l2.elements);
      return;
    }
    return qm(e3, l2.work, true), d2;
  }
}
function Gh(e3, t2, n2, r2, i2, a2, o2, s2) {
  let c2 = Kh(e3, t2, n2, r2, o2, a2, i2, s2);
  if (c2) return c2;
  let l2 = n2[r2] ? Wh(e3, t2, n2[r2], a2, i2, s2) : void 0;
  if (l2) return { mounted: l2, next: r2 + 1 };
  a2.stop();
}
function Kh(e3, t2, n2, r2, i2, a2, o2, s2) {
  let c2 = Il(t2);
  if (!c2) return;
  let l2 = Jm(c2.program), u2 = Lm(n2, r2, i2);
  if (!u2) return;
  let d2;
  for (let e4 = u2.contentStart; e4 < u2.endIndex; e4++) {
    let t3 = n2[e4];
    if (t3 instanceof Element) {
      d2 = t3;
      break;
    }
  }
  if (!d2) return;
  let f2 = Sm(l2, d2, `ssr`);
  if (!f2) return;
  let p2 = Ll(t2);
  if (!p2) return;
  let m2 = { renderProgramReceipt: p2, dom: u2.start ?? d2, ...u2.start ? { end: n2[u2.endIndex] } : {}, ...u2.start ? { rawNodes: [d2] } : {}, scope: a2, children: [], renderProgram: { invocation: c2, programRoot: d2, slotNodes: f2.slotNodes, ...f2.textRuns ? { textRuns: f2.textRuns } : {}, ...f2.componentSlots ? { componentSlots: f2.componentSlots } : {}, root: e3, parentInstance: o2 } };
  if (Uh(m2, o2, s2)) {
    if (zm(f2.elements, o2), qm(e3, f2.work, true), !(!Gm(l2) || um(m2))) {
      Rm(f2.elements);
      return;
    }
    return { mounted: m2, next: u2.start ? u2.endIndex + 1 : u2.endIndex };
  }
}
function qh(e3) {
  let t2 = Hh(e3), n2 = t2.findIndex((e4) => e4 instanceof Comment && /^exact:framework-(head|body):start$/.test(e4.data));
  if (n2 < 0) return;
  let r2 = t2.findIndex((e4, r3) => r3 > n2 && e4 instanceof Comment && e4.data === t2[n2].data.replace(/:start$/, `:end`));
  if (!(r2 < 0)) return { start: t2[n2], end: t2[r2] };
}
function Jh(e3, t2) {
  if (!t2) return Hh(e3);
  let n2 = [], r2 = Hh(e3);
  for (let e4 = 0; e4 < r2.length; e4++) {
    let t3 = r2[e4];
    if (t3 instanceof Comment && /^exact:framework-(head|body):start$/.test(t3.data)) {
      let n3 = t3.data.replace(/:start$/, `:end`), i2 = e4 + 1;
      for (; i2 < r2.length; ) {
        let e5 = r2[i2];
        if (e5 instanceof Comment && /^exact:framework-(head|body):/.test(e5.data)) break;
        i2++;
      }
      let a2 = r2[i2];
      if (a2 instanceof Comment && a2.data === n3) {
        e4 = i2;
        continue;
      }
    }
    n2.push(t3);
  }
  return n2;
}
function Yh(e3, t2, n2, r2, i2, a2 = 0, o2 = n2.length) {
  return Qh(e3, t2, n2, r2, i2, true, a2, o2)?.mounts;
}
function Xh(e3, t2, n2, r2, i2, a2 = 0, o2 = n2.length) {
  let s2 = Yh(e3, t2, n2, r2, i2, a2, o2);
  if (s2) return s2;
  let c2 = n2[a2];
  if (!(c2 instanceof Comment) || !Zh(c2.data)) return;
  let l2 = $h(n2, a2, c2.data, o2);
  if (l2 !== o2 - 1) return;
  let u2 = Yh(e3, t2, n2, r2, i2, a2 + 1, l2);
  if (!u2) return;
  c2.remove();
  let d2 = n2[l2];
  return d2?.parentNode?.removeChild(d2), u2;
}
function Zh(e3) {
  return e3 === `x` || e3.startsWith(`exact:dynamic:`);
}
function Qh(e3, t2, n2, r2, i2, a2, o2 = 0, s2 = n2.length) {
  let c2 = [], l2 = o2;
  for (let a3 of t2) {
    if (wc(a3) || Ec(a3) || a3 == null || a3 === false || a3 === true) continue;
    let t3 = yf()?.adopt?.(e3, a3, n2, l2, r2, i2, s2);
    if (t3) {
      c2.push(t3.mounted), l2 = t3.next;
      continue;
    }
    let o3 = Hc(a3);
    if (o3) {
      let t4 = n2[l2];
      if (t4 instanceof Element && Ll(o3.value)) {
        let s3 = o3.ownerScope ?? A(i2);
        o3.ownerScope && bt(s3, i2);
        let u4 = Qh(e3, [o3.value], n2, r2, s3, true, l2, l2 + 1);
        if (!u4 || u4.mounts.length !== 1) {
          s3.stop(), mf(c2);
          return;
        }
        c2.push({ operation: a3, operationKey: o3.key, range: `item`, dom: t4, scope: s3, children: u4.mounts }), l2++;
        continue;
      }
      if (!(t4 instanceof Comment) || !t4.data.startsWith(`i:`)) {
        mf(c2);
        return;
      }
      let u3 = $h(n2, l2, t4.data, s2);
      if (u3 < 0) {
        mf(c2);
        return;
      }
      let d3 = o3.ownerScope ?? A(i2);
      o3.ownerScope && bt(d3, i2);
      let f3 = Qh(e3, [o3.value], n2, r2, d3, true, l2 + 1, u3);
      if (!f3 || f3.mounts.length !== 1) {
        d3.stop(), mf(c2);
        return;
      }
      c2.push({ operation: a3, operationKey: o3.key, range: `item`, dom: t4, end: n2[u3], scope: d3, children: f3.mounts }), l2 = u3 + 1;
      continue;
    }
    let u2 = dc(a3), d2 = Ko(a3), f2 = yc(a3), p2 = mc(a3), m2 = jc(a3), h2 = Lc(a3), g2 = Pc(a3), _2 = Gc(a3), v2 = Zc(a3), y2 = Ll(a3), b2 = pp(a3);
    if (b2 !== void 0) {
      let e4 = n2[l2];
      if (e4?.nodeType !== Node.TEXT_NODE || e4.textContent !== b2) {
        mf(c2);
        return;
      }
      let t4 = { scalar: true, scalarValue: b2, dom: e4, scope: A(i2), children: [] };
      mp(t4, a3), c2.push(t4), l2++;
      continue;
    }
    let x2 = v2 ? _u(v2, n2, l2, A(i2)) : u2 ? Fh(e3, u2, n2, l2, r2, i2, s2, false) : d2 ? zh(e3, d2, n2, l2, r2, i2, Yh) : f2 || p2 ? Bh(e3, f2 ?? p2, f2 ? `fragment` : `target`, n2, l2, r2, i2, s2, Yh) : m2 ? Vh(e3, m2, n2, l2, r2, i2, s2, Yh) : h2 ? Xm().adoptActivityReceipt(e3, h2, n2, l2, r2, i2, s2, Yh) : _2 ? eh().adopt(e3, _2, n2, l2, i2, s2) : g2 ? Xm().adoptSuspenseReceipt(e3, g2, n2, l2, r2, i2, s2, Yh) : y2 ? ju(e3, () => (ku(e3), Gh(e3, a3, n2, l2, r2, A(i2), s2, (t4, n3, r3, i3, a4, o4) => Yh(e3, [...t4], n3, r3, i3, a4, o4)))) : void 0;
    if (!x2) {
      mf(c2);
      return;
    }
    x2.mounted.operation = a3, c2.push(x2.mounted), l2 = x2.next;
  }
  if (a2 && l2 !== s2) {
    mf(c2);
    return;
  }
  return { mounts: c2, next: l2 };
}
function $h(e3, t2, n2, r2 = e3.length) {
  let i2 = `/${n2}`, a2 = 0;
  for (let o2 = t2 + 1; o2 < r2; o2++) {
    let t3 = e3[o2];
    if (t3 instanceof Comment) {
      if (t3.data === n2) a2++;
      else if (t3.data === i2) {
        if (a2 === 0) return o2;
        a2--;
      }
    }
  }
  return -1;
}
function eg(e3, t2, n2, r2 = {}) {
  if (Nu.has(n2)) return false;
  let i2 = Hh(n2), a2 = Ph(i2, 0, t2.contract.artifact.id);
  return a2?.matches ? rg(Eh(n2, e3, r2, { version: 1, mode: `hydrated` }), { componentReceipt: t2, dom: a2.start, end: i2[a2.endIndex], scope: A(), children: [], clientArtifact: Lh(t2) }, t2, i2.slice(1, a2.endIndex), r2) : false;
}
function tg(e3, t2, n2, r2 = {}) {
  if (Nu.has(n2)) return false;
  let i2 = document.createTextNode(``), a2 = document.createTextNode(``);
  n2.insertBefore(i2, n2.firstChild), n2.insertBefore(a2, n2.querySelector(`:scope > script#__exact_hydration[type="application/json"]`));
  let o2 = Eh(n2, e3, r2, { version: 1, mode: `hydrated`, markerlessHydration: true }), s2 = { componentReceipt: t2, dom: i2, end: a2, scope: A(), children: [], clientArtifact: Lh(t2) }, c2 = [];
  for (let e4 = i2.nextSibling; e4 && e4 !== a2; e4 = e4.nextSibling) c2.push(e4);
  let l2 = rg(o2, s2, t2, c2, r2);
  return l2 || (i2.remove(), a2.remove()), l2;
}
function ng(e3, t2, n2, r2 = {}) {
  let i2 = n2.documentElement;
  if (!i2 || Nu.has(i2)) return false;
  let a2 = n2.createComment(`exact:document-root`), o2 = n2.createComment(`/exact:document-root`);
  n2.insertBefore(a2, i2), n2.insertBefore(o2, i2.nextSibling);
  let s2 = rg(Eh(i2, e3, r2, { version: 1, mode: `document`, markerlessHydration: true }), { componentReceipt: t2, dom: a2, end: o2, scope: A(), children: [], clientArtifact: Lh(t2) }, t2, [i2], r2);
  return s2 || (a2.remove(), o2.remove()), s2;
}
function rg(e3, t2, n2, r2, i2) {
  try {
    return Ou(e3, () => {
      ku(e3);
      let a2 = j(t2.scope, () => Rh(e3, n2, i2.logicalParent));
      if (Sf(t2, a2), !Mh(e3, t2, t2.clientArtifact, a2, (n3) => Xh(e3, n3, r2, a2, t2.scope))) return false;
      let o2 = yf();
      return e3.mounted = o2 ? o2.activate(e3, t2, void 0, void 0, (t3, n3, r3, i3) => xh(e3, t3, n3, r3, i3)) : t2, e3.initialCommitComplete = true, Nu.set(e3.container, e3), true;
    });
  } catch (e4) {
    if (Au(e4)) throw e4;
    return false;
  } finally {
    Nu.has(e3.container) || (Z(t2), fd(e3)), e3.workBudget = void 0;
  }
}
function ig(e3) {
  return ag(e3, true);
}
function ag(e3, t2 = false) {
  let n2 = Nu.get(e3);
  if (!n2) return false;
  Nu.delete(e3), Hu(n2);
  let r2 = df();
  X(r2, () => fd(n2)), X(r2, () => Ep(n2));
  let i2 = n2.mounted;
  return n2.mounted = void 0, i2 && (X(r2, () => Z(i2)), t2 && X(r2, () => gf(e3, i2))), pf(r2), true;
}
function og(e3, t2 = true, n2) {
  let r2 = [];
  hu(e3, (n3) => {
    n3 instanceof Element && (t2 || n3 !== e3) && r2.push(n3);
  }, typeof n2 == `number` ? { maxNodes: n2 } : { budget: n2 });
  let i2 = 0, a2 = df();
  for (let e4 = r2.length - 1; e4 >= 0; e4--) try {
    ag(r2[e4], false) && i2++;
  } catch (e5) {
    ff(a2, e5);
  }
  return pf(a2), i2;
}
function sg(e3, t2, n2 = {}) {
  let r2 = dc(e3);
  if (!r2) throw TypeError(`Compiled component root requires a compiler-issued component operation`);
  let i2 = Nu.get(t2), a2 = n2.inspection ?? Bu(), o2 = kh(r2.domain, i2, n2, a2);
  if (i2?.mode === `document`) {
    if (Ah(i2, o2), i2.mounted?.componentReceipt && i2.mounted.clientArtifact === r2.contract.artifact && i2.mounted.componentReceipt.key === r2.key && i2.mounted.componentReceipt.domain === r2.domain) {
      let t3 = i2.mounted.componentReceipt;
      try {
        sp(i2.mounted, r2), qe(), i2.current = e3, i2.version++;
      } catch (e4) {
        throw i2.mounted.componentReceipt = t3, e4;
      }
      return;
    }
    throw Error(`eXact cannot safely replace a mounted Document root with a different component artifact`);
  }
  i2 || (i2 = Eh(t2, e3, o2, { version: 0, mode: `client` }), Nu.set(t2, i2), i2.domain && Ya(i2.domain) && Vu(i2)), Ah(i2, o2), i2.domain && Ya(i2.domain) && Vu(i2);
  let s2 = i2.mounted, c2 = Te();
  if (s2?.componentReceipt && s2.clientArtifact === r2.contract.artifact && s2.componentReceipt.key === r2.key && s2.componentReceipt.domain === r2.domain) {
    let e4 = s2.componentReceipt;
    try {
      Ou(i2, () => {
        sp(s2, r2), qe();
      });
    } catch (t3) {
      throw s2.componentReceipt = e4, t3;
    }
  } else {
    let n3 = i2.replacementParking, a3 = cg(s2, t2);
    i2.replacementParking = a3;
    try {
      Ou(i2, () => {
        let n4 = r2.enhancement ? xh(i2, e3, o2.logicalParent, void 0, t2) : np(i2, r2, o2.logicalParent, void 0, t2);
        J(i2, t2, n4, s2?.dom ?? null), i2.mounted = n4, Dh(i2), qe();
      });
    } finally {
      i2.replacementParking = n3;
    }
    for (let e4 of a3.commits) e4();
    s2 && hf(t2, s2);
    for (let e4 of a3.mounts.values()) for (let t3 of e4) hf(t3.parent, t3.mounted);
  }
  i2.current = e3, i2.version++, we(i2.onProfile, { subsystem: `dom`, phase: `render`, elapsedMs: Te() - c2 }), i2.initialCommitComplete = true, i2.workBudget = void 0;
}
function cg(e3, t2) {
  return e3 ? oh(e3, t2) : { mounts: /* @__PURE__ */ new Map(), commits: [] };
}
function lg(e3, t2) {
  let n2 = document.activeElement, r2 = [], i2 = false;
  return hu(e3, (e4) => {
    if (e4.nodeType === Node.COMMENT_NODE) {
      e4.data.startsWith(`exact:`) && (i2 = true);
      return;
    }
    if (e4.nodeType !== Node.ELEMENT_NODE) return;
    let t3 = e4;
    (t3.localName === `input` || t3.localName === `textarea` || t3.localName === `select` || t3.localName === `details` || t3.localName === `dialog` || t3.getAttribute(`contenteditable`) === `true`) && r2.push(t3);
  }, { budget: t2 }), { formState: r2.flatMap((r3) => {
    if (!(r3 instanceof HTMLInputElement ? r3.value !== r3.defaultValue || r3.checked !== r3.defaultChecked : r3 instanceof HTMLTextAreaElement ? r3.value !== r3.defaultValue : r3 instanceof HTMLSelectElement ? Array.from(r3.options).some((e4) => e4.selected !== e4.defaultSelected) : fg(r3) ? r3.open !== (r3.getAttribute(`data-exact-ssr-open`) === `true`) : pg(r3) ? r3.open : r3.textContent !== r3.getAttribute(`data-exact-ssr-text`)) && r3 !== n2) return [];
    let i3 = { node: r3, path: gg(e3, r3, t2), identity: dg(r3), signature: mg(r3), focused: r3 === n2 };
    return r3 instanceof HTMLInputElement || r3 instanceof HTMLTextAreaElement ? (i3.value = r3.value, r3 instanceof HTMLInputElement && (i3.checked = r3.checked), i3.selection = { start: r3.selectionStart, end: r3.selectionEnd, direction: r3.selectionDirection }) : r3 instanceof HTMLSelectElement ? i3.selected = Array.from(r3.options, (e4) => e4.selected) : fg(r3) ? i3.open = r3.open : pg(r3) ? i3.modal = r3.matches(`:modal`) : i3.value = r3.textContent ?? ``, [i3];
  }), hasMarkers: i2 };
}
function ug(e3, t2, n2) {
  if (!t2.length) return [];
  let r2 = [], i2;
  for (let a2 of t2) {
    let t3 = e3.contains(a2.node) && (!a2.identity || a2.node.getAttribute(a2.identity.attribute) === a2.identity.value) ? a2.node : void 0;
    t3 ||= (i2 ??= hg(e3, n2), (a2.identity ? i2.get(`${a2.identity.attribute}\0${a2.identity.value}`) : void 0) ?? _g(e3, a2.path, n2));
    let o2 = t3 instanceof Element && mg(t3) === a2.signature ? t3 : void 0;
    o2 instanceof Element && (r2.push(o2), o2 instanceof HTMLInputElement || o2 instanceof HTMLTextAreaElement ? (a2.value !== void 0 && (o2.value = a2.value), o2 instanceof HTMLInputElement && a2.checked !== void 0 && (o2.checked = a2.checked), a2.focused && o2.focus({ preventScroll: true }), a2.selection && a2.selection.start !== null && a2.selection.end !== null && o2.setSelectionRange(a2.selection.start, a2.selection.end, a2.selection.direction ?? void 0)) : o2 instanceof HTMLSelectElement && a2.selected ? (Array.from(o2.options).forEach((e4, t4) => {
      e4.selected = a2.selected[t4] ?? false;
    }), a2.focused && o2.focus({ preventScroll: true })) : fg(o2) && a2.open !== void 0 ? o2.open = a2.open : pg(o2) && a2.modal !== void 0 ? a2.modal && !o2.matches(`:modal`) ? (o2.open && o2.close(), o2.showModal()) : !a2.modal && o2.matches(`:modal`) && o2.close() : a2.value !== void 0 && (o2.textContent = a2.value, a2.focused && o2 instanceof HTMLElement && o2.focus({ preventScroll: true })));
  }
  return r2;
}
function dg(e3) {
  for (let t2 of [`data-exact-control-id`, `data-exact-id`, `id`, `name`]) {
    let n2 = e3.getAttribute(t2);
    if (n2) return { attribute: t2, value: n2 };
  }
}
function fg(e3) {
  return e3 instanceof Element && e3.localName === `details` && `open` in e3;
}
function pg(e3) {
  return e3 instanceof Element && e3.localName === `dialog` && `open` in e3 && typeof e3.showModal == `function`;
}
function mg(e3) {
  let t2 = e3 instanceof HTMLInputElement ? e3.type : ``;
  return `${e3.namespaceURI ?? ``}|${e3.localName}|${t2}|${e3.getAttribute(`name`) ?? ``}`;
}
function hg(e3, t2) {
  let n2 = /* @__PURE__ */ new Map();
  return hu(e3, (e4) => {
    if (e4 instanceof Element) for (let t3 of [`data-exact-control-id`, `data-exact-id`, `id`, `name`]) {
      let r2 = e4.getAttribute(t3);
      if (!r2) continue;
      let i2 = `${t3}\0${r2}`;
      n2.set(i2, n2.has(i2) ? void 0 : e4);
    }
  }, { budget: t2 }), n2;
}
function gg(e3, t2, n2) {
  let r2 = [];
  for (let i2 = t2; i2 && i2 !== e3; i2 = i2.parentNode) {
    if (pu(n2), !i2.parentNode) return [];
    r2.unshift(Array.prototype.indexOf.call(i2.parentNode.childNodes, i2));
  }
  return r2;
}
function _g(e3, t2, n2) {
  let r2 = e3;
  for (let e4 of t2) pu(n2), r2 = r2?.childNodes[e4];
  return r2;
}
function vg(e3, t2, n2 = `adoption-mismatch`, r2) {
  mo(`warn`, `hydrate`, `mismatch`, t2, void 0, e3.logger), e3.onDiagnostic?.({ code: n2, message: t2, patch: r2 });
}
var yg = new TextEncoder();
function bg(e3) {
  if (e3.length > 64) return yg.encode(e3).byteLength;
  let t2 = 0;
  for (let n2 = 0; n2 < e3.length; n2++) {
    let r2 = e3.charCodeAt(n2);
    if (r2 <= 127) t2++;
    else if (r2 <= 2047) t2 += 2;
    else if (r2 >= 55296 && r2 <= 56319 && n2 + 1 < e3.length) {
      let r3 = e3.charCodeAt(n2 + 1);
      r3 >= 56320 && r3 <= 57343 ? (t2 += 4, n2++) : t2 += 3;
    } else t2 += 3;
  }
  return t2;
}
function xg(e3, t2) {
  return typeof e3 == `number` && Number.isSafeInteger(e3) && e3 > 0 ? e3 : t2;
}
function Sg(e3, t2) {
  return Object.keys(e3).every((e4) => t2.includes(e4));
}
function Cg(e3, t2 = {}) {
  let n2 = xg(t2.maxDepth, 100), r2 = xg(t2.maxNodes, 1e5), i2 = xg(t2.maxBytes, 16777216);
  try {
    let t3 = /* @__PURE__ */ new Set(), a2 = [{ value: e3, depth: 0 }], o2 = 0, s2 = 0;
    for (; a2.length; ) {
      let { value: e4, depth: c2 } = a2.pop();
      if (++o2 > r2 || c2 > n2 || e4 === void 0) return false;
      if (e4 === null || typeof e4 == `boolean`) continue;
      if (typeof e4 == `number`) {
        if (!Number.isFinite(e4)) return false;
        continue;
      }
      if (typeof e4 == `string`) {
        if (s2 += bg(e4), s2 > i2) return false;
        continue;
      }
      if (typeof e4 != `object` || t3.has(e4)) return false;
      if (t3.add(e4), e4 instanceof Map) {
        for (let [t4, n3] of e4) {
          if (!Vn(t4) || o2 + a2.length + 1 > r2 || (typeof t4 == `string` && (s2 += bg(t4)), s2 > i2)) return false;
          a2.push({ value: n3, depth: c2 + 1 });
        }
        continue;
      }
      if (e4 instanceof Set) {
        for (let t4 of e4) {
          if (o2 + a2.length + 1 > r2) return false;
          a2.push({ value: t4, depth: c2 + 1 });
        }
        continue;
      }
      if (!Array.isArray(e4) && Object.getPrototypeOf(e4) !== Object.prototype) return false;
      let l2 = Object.keys(e4);
      if (o2 + a2.length + l2.length > r2) return false;
      for (let t4 of l2) {
        let n3 = Object.getOwnPropertyDescriptor(e4, t4);
        if (!n3 || !(`value` in n3) || (s2 += bg(t4), s2 > i2)) return false;
        a2.push({ value: n3.value, depth: c2 + 1 });
      }
    }
    return true;
  } catch {
    return false;
  }
}
var wg = Object.freeze([]);
Object.freeze({});
function Tg(e3) {
  if (e3 !== void 0) {
    if (!Array.isArray(e3)) throw TypeError(`Malformed eXact component resumptions`);
    if (!e3.length) return wg;
    for (let t2 = 0; t2 < e3.length; t2++) {
      let n2 = e3[t2];
      if (!Og(n2)) throw TypeError(`Malformed eXact component resumption ${t2}`);
    }
    return e3;
  }
}
function Eg(e3) {
  return !!e3 && typeof e3 == `object` && !Array.isArray(e3);
}
function Dg(e3) {
  return e3.length > 0 && e3.split(`.`).every((e4) => e4.length > 0 && e4 !== `__proto__` && e4 !== `prototype` && e4 !== `constructor`);
}
function Og(e3) {
  return !Array.isArray(e3) || e3.length < 1 || e3.length > 4 || typeof e3[0] != `string` || e3[0].length === 0 ? false : kg(e3[1]) && kg(e3[2]) && (e3[3] === void 0 || Ag(e3[3]));
}
function kg(e3) {
  if (e3 === void 0) return true;
  if (!Array.isArray(e3)) return false;
  let t2 = [];
  for (let n2 of e3) {
    let e4 = Array.isArray(n2) ? n2[0] : void 0;
    if (!Array.isArray(n2) || n2.length !== 2 || !(typeof e4 == `number` && Number.isSafeInteger(e4) && e4 >= 0 || typeof e4 == `string` && !e4.startsWith(`@`) && Dg(e4)) || t2.includes(e4)) return false;
    t2.push(e4);
  }
  return true;
}
function Ag(e3) {
  return Array.isArray(e3) && e3.every((e4) => typeof e4 == `string`);
}
function jg(e3, t2, n2) {
  if (!Cg(e3, t2)) throw n2();
  let r2;
  try {
    r2 = ni(e3);
  } catch {
    throw n2();
  }
  if (!Cg(r2, t2)) throw n2();
  return r2;
}
var Mg = [`pluginRegistryFingerprint`, `state`, `m`, `resumptions`, `publicContexts`, `wallClockSnapshot`, `h`, `executionRoot`, `binding`, `buildKey`, `componentAuthorization`], Ng = /* @__PURE__ */ new WeakMap(), Pg = /* @__PURE__ */ new WeakMap();
function Fg(e3, t2) {
  let n2 = Ig(e3, t2.configLimits, t2.maxTreeNodes);
  if (n2.pluginRegistryFingerprint && t2.clientPluginRegistryFingerprint && n2.pluginRegistryFingerprint !== t2.clientPluginRegistryFingerprint) throw Error(`Client and server eXact plugin registry fingerprints do not match`);
  if (n2.buildKey && t2.buildKey && n2.buildKey !== t2.buildKey) throw Error(`Client and server eXact build identities do not match`);
  if (n2.componentAuthorization && t2.componentAuthorization && !hl(n2.componentAuthorization, t2.componentAuthorization)) throw Error(`Client and server component authorization fingerprints do not match`);
  let r2 = t2.componentAuthorization ?? n2.componentAuthorization, i2 = t2.buildKey ?? n2.buildKey;
  if (r2 && i2 && r2.buildKey !== i2) throw Error(`Component authorization identity does not match the hydration build key`);
  return { ...t2, state: t2.state === void 0 ? n2.state : t2.state, markerlessRoot: t2.markerlessRoot ?? n2.markerlessRoot, allowMarkerless: t2.allowMarkerless ?? n2.markerlessRoot, resumptions: t2.resumptions ?? n2.resumptions, publicContexts: t2.publicContexts ?? n2.publicContexts, wallClockSnapshot: t2.wallClockSnapshot ?? n2.wallClockSnapshot, hydrationTable: t2.hydrationTable ?? n2.hydrationTable, executionRoot: t2.executionRoot ?? n2.executionRoot, binding: t2.binding ?? n2.binding, buildKey: i2, componentAuthorization: r2, headers: r2 ? { ...t2.headers, "X-Exact-Component-Authorization": r2.fingerprint } : t2.headers };
}
function Ig(e3, t2 = {}, n2) {
  let r2 = Ng.get(e3);
  if (r2 && r2.id === `__exact_hydration` && Lg(r2, e3)) return zg(r2, t2);
  let i2 = e3.getRootNode(), a2 = i2.nodeType === 9 ? i2 : i2.ownerDocument, o2 = a2?.getElementById(`__exact_hydration`), s2 = [];
  o2 instanceof HTMLScriptElement && (i2 === a2 || i2.contains(o2)) ? s2 = [o2] : hu(i2, (e4) => {
    e4 instanceof HTMLScriptElement && e4.id === `__exact_hydration` && s2.push(e4);
  }, { budget: fu(n2) });
  for (let n3 = e3; n3; n3 = n3.parentElement) {
    let r3 = s2.find((e4) => n3.contains(e4));
    if (r3) return Ng.set(e3, r3), zg(r3, t2);
  }
  return s2[0] ? (Ng.set(e3, s2[0]), zg(s2[0], t2)) : {};
}
function Lg(e3, t2) {
  if (e3.getRootNode() !== t2.getRootNode()) return false;
  for (let n2 = t2; n2; n2 = n2.parentElement) if (n2.contains(e3)) return true;
  return false;
}
function Rg(e3, t2, n2, r2) {
  let i2 = typeof e3 == `function` ? e3 : void 0, a2 = Ig(i2 ? t2 : e3, i2 ? n2 : t2, i2 ? r2 : n2), o2 = a2.state;
  if (i2 && Array.isArray(o2)) {
    let e4 = Ta(i2).artifact;
    if (o2.length !== 2 || o2[0] !== e4.id || !e4.serialization) throw TypeError(`Missing or malformed eXact published root props`);
    o2 = ba(o2[1], e4.serialization), a2.state = o2;
  }
  if (!Eg(o2)) throw TypeError(`Missing or malformed eXact published root props`);
  return o2;
}
function zg(e3, t2) {
  try {
    let n2 = e3.textContent ?? `{}`, r2 = Pg.get(e3);
    if (r2?.source === n2 && r2.maxBytes === t2.maxBytes && r2.maxDepth === t2.maxDepth && r2.maxNodes === t2.maxNodes) return r2.config;
    let i2 = xg(t2.maxBytes, 16777216);
    if (n2.length > i2 || bg(n2) > i2) return {};
    let a2 = jg(JSON.parse(n2), { maxDepth: t2.maxDepth, maxNodes: t2.maxNodes, maxBytes: i2 }, () => TypeError(`Malformed eXact hydration config`));
    if (!a2 || typeof a2 != `object`) return {};
    let o2, s2, c2 = false, l2 = false, u2, d2, f2, p2, m2, h2, g2, _2;
    if (Array.isArray(a2)) {
      let e4 = a2[1];
      if (a2[0] !== 1 || typeof e4 != `number` || !Number.isSafeInteger(e4) || e4 < 0 || e4 & -16384 || e4 & 38) return {};
      let t3 = 2;
      if (e4 & 1 && (o2 = a2[t3++]), e4 & 8 && (c2 = true, s2 = a2[t3++]), l2 = !!(e4 & 16), e4 & 64 && (u2 = a2[t3++]), e4 & 128 && (d2 = a2[t3++]), e4 & 256 && (f2 = a2[t3++]), e4 & 512 && (p2 = a2[t3++]), e4 & 1024 && (m2 = a2[t3++]), e4 & 2048 && (h2 = a2[t3++]), e4 & 4096 && (g2 = a2[t3++]), e4 & 8192 && (_2 = a2[t3++]), t3 !== a2.length) return {};
    } else {
      let e4 = a2;
      if (!Sg(e4, Mg)) return {};
      o2 = e4.pluginRegistryFingerprint, c2 = `state` in e4, s2 = e4.state, l2 = e4.m === 1, u2 = e4.resumptions, d2 = e4.publicContexts, f2 = e4.wallClockSnapshot, p2 = e4.h, m2 = e4.executionRoot, h2 = e4.binding, g2 = e4.buildKey, _2 = e4.componentAuthorization;
    }
    let v2 = ml(_2) ? _2 : void 0, y2 = typeof g2 == `string` ? g2 : void 0;
    if (v2 && y2 && v2.buildKey !== y2) return {};
    let b2;
    try {
      b2 = Tg(u2);
    } catch {
      b2 = void 0;
    }
    let x2 = Bg(p2), ee2 = { ...typeof o2 == `string` ? { pluginRegistryFingerprint: o2 } : {}, ...c2 ? { state: s2 } : {}, ...l2 ? { markerlessRoot: true } : {}, ...b2 ? { resumptions: b2 } : {}, ...Eg(d2) ? { publicContexts: d2 } : {}, ...typeof f2 == `number` && Number.isFinite(f2) ? { wallClockSnapshot: f2 } : {}, ...x2 ? { hydrationTable: x2 } : {}, ...typeof m2 == `string` ? { executionRoot: m2 } : {}, ...typeof h2 == `string` ? { binding: h2 } : {}, ...y2 ? { buildKey: y2 } : {}, ...v2 ? { componentAuthorization: v2 } : {} };
    return Pg.set(e3, { source: n2, maxBytes: t2.maxBytes, maxDepth: t2.maxDepth, maxNodes: t2.maxNodes, config: ee2 }), ee2;
  } catch {
    return {};
  }
}
function Bg(e3) {
  if (!(!Array.isArray(e3) || e3.length !== 2 || e3[0] !== 1 || !Array.isArray(e3[1]))) return [1, e3[1].map((e4) => {
    if (!Array.isArray(e4) || e4.length !== 3 || typeof e4[0] != `string` || !Array.isArray(e4[1]) || !e4[1].every((e5) => typeof e5 == `string`) || new Set(e4[1]).size !== e4[1].length || !Array.isArray(e4[2])) return;
    let t2 = e4[2].map((t3) => Array.isArray(t3) && t3.length === e4[1].length + 1 && typeof t3[0] == `string` ? t3 : void 0);
    return [e4[0], e4[1], t2];
  })];
}
function Vg(e3) {
  let t2 = globalThis.document;
  if ((e3.nodeType === 9 ? e3 : e3.ownerDocument) !== t2) throw Error(`eXact hydration requires a container owned by the current document.`);
  let n2 = t2.defaultView?.Element;
  if (e3.nodeType !== 9 && n2 && !(e3 instanceof n2)) throw Error(`eXact hydration requires a container created in the current window realm.`);
}
function Hg(e3) {
  let t2 = 0, n2, r2 = ((r3) => {
    let i2 = Ta(r3);
    if (!i2.resumption) return;
    let a2 = Ea(r3), o2 = n2 ?? e3();
    if (!o2?.length) throw Error(`eXact SSR resumption payload is unavailable`);
    let s2 = o2[t2];
    if (!s2) throw Error(`eXact SSR resumption is missing component ${a2}`);
    let c2 = !(`componentId` in s2), l2 = c2 ? s2[0] : s2.componentId;
    if (l2 !== a2) throw Error(`eXact SSR resumption expected component ${l2} before ${a2}`);
    let u2 = c2 ? s2[1] ?? [] : s2.values, d2 = c2 ? s2[2] ?? [] : s2.contexts, f2 = c2 ? s2[3] ?? [] : s2.settledContinuations, p2 = Array.isArray(u2) && Array.isArray(d2);
    p2 && (Ug(u2, i2.resumption.statePaths, a2, `state path`), Ug(d2, i2.resumption.contexts, a2, `context`)), p2 || (Wg(u2, i2.resumption.statePaths, a2, `state path`), Wg(d2, i2.resumption.contexts, a2, `context`));
    for (let e4 of f2) if (!i2.continuations?.some((t3) => t3.id === e4) && !i2.resumption.continuations?.includes(e4)) throw Error(`eXact SSR resumption contains undeclared continuation ${a2}:${e4}`);
    return t2++, s2;
  });
  return r2.withRecords = (e4, r3) => {
    let i2 = n2, a2 = t2;
    n2 = e4, t2 = 0;
    try {
      return r3();
    } finally {
      n2 = i2, t2 = a2;
    }
  }, r2.checkpoint = () => t2, r2.rollback = (e4) => {
    if (!Number.isSafeInteger(e4) || e4 < 0 || e4 > t2) throw Error(`Malformed eXact component resumption checkpoint`);
    t2 = e4;
  }, r2;
}
function Ug(e3, t2, n2, r2) {
  for (let i2 = 0; i2 < e3.length; i2++) {
    let a2 = e3[i2][0], o2 = typeof a2 == `number` ? t2[a2] : a2;
    if (o2 === void 0) throw Error(`eXact SSR resumption index is outside component ${n2}`);
    if (typeof a2 == `string` && !t2.includes(a2)) throw Error(`eXact SSR resumption contains undeclared ${r2} ${n2}:${a2}`);
    for (let t3 = 0; t3 < i2; t3++) if (e3[t3][0] === o2) throw Error(`Duplicate eXact resumption field ${n2}:${o2}`);
    e3[i2][0] = o2;
  }
}
function Wg(e3, t2, n2, r2) {
  let i2 = Object.keys(e3);
  for (let e4 of i2) if (!t2.includes(e4)) throw Error(`eXact SSR resumption contains undeclared ${r2} ${n2}:${e4}`);
}
function Gg(e3) {
  return Jg(e3)?.checkpoint() ?? 0;
}
function Kg(e3, t2) {
  let n2 = Jg(e3);
  if (!n2) return t2();
  let r2 = n2.checkpoint();
  try {
    return no(e3, t2);
  } catch (e4) {
    throw n2.rollback(r2), e4;
  }
}
function qg(e3, t2) {
  Jg(e3)?.rollback(t2);
}
function Jg(e3) {
  return Xa(e3);
}
var Yg = /* @__PURE__ */ new WeakMap();
function Xg(e3, t2) {
  let n2 = [...t2.resumptions ?? []], r2 = false, i2 = qa({ executionRoot: t2.executionRoot ?? `page`, logger: t2.logger, dispatchContinuation: () => Promise.reject(Error(`This root was hydrated without server-operation capabilities; use @exactjs/hydrate for compiler-generated server work.`)), resumeComponent: Hg(() => n2), inspection: t2.inspection ?? Bu({ buildKey: t2.buildKey, executionRoot: t2.executionRoot, binding: t2.binding }), inspectionActivation: `hydration`, ...t2.wallClockSnapshot === void 0 ? {} : { wallClockSnapshot: t2.wallClockSnapshot } });
  t2.componentDomain = i2;
  let a2 = { domain: i2, get pendingRequests() {
    return 0;
  }, retire() {
  }, whenSettled() {
    return Promise.resolve();
  }, dispose() {
    r2 || (r2 = true, Yg.delete(e3), e3.removeAttribute(`data-exact-hydrated`), og(e3, false), ig(e3));
  } };
  if (Yg.has(e3)) throw Error(`An eXact hydration root is already registered here`);
  return Yg.set(e3, a2), a2;
}
function Zg(e3, t2) {
  let n2 = t2.nodeType === 9 ? t2 : t2.ownerDocument, r2 = n2.defaultView, i2 = r2?.requestAnimationFrame?.bind(r2) ?? globalThis.requestAnimationFrame?.bind(globalThis), a2 = r2?.cancelAnimationFrame?.bind(r2) ?? globalThis.cancelAnimationFrame?.bind(globalThis), o2 = r2?.scheduler ?? globalThis.scheduler, s2 = `pending`, c2, l2, u2, d2, f2 = new Promise((e4, t3) => {
    u2 = e4, d2 = t3;
  }), p2 = [`pointerdown`, `keydown`, `input`, `change`, `submit`], m2 = () => {
    c2 !== void 0 && (r2 ? r2.clearTimeout(c2) : clearTimeout(c2), c2 = void 0), l2 !== void 0 && (a2?.(l2), l2 = void 0), n2.removeEventListener(`DOMContentLoaded`, v2);
    for (let e4 of p2) t2.removeEventListener(e4, _2, true);
  }, h2 = () => {
    if (s2 === `pending`) {
      s2 = `activating`, m2();
      try {
        let t3 = e3();
        s2 = `resolved`, u2(t3);
      } catch (e4) {
        s2 = `rejected`, d2(e4);
      }
    }
  }, g2 = (e4) => {
    s2 === `pending` && (s2 = `rejected`, m2(), d2(e4));
  }, _2 = () => void h2();
  for (let e4 of p2) t2.addEventListener(e4, _2, { capture: true, once: true });
  function v2() {
    if (s2 === `pending`) try {
      if (n2.visibilityState === `visible` && i2) {
        l2 = i2(() => {
          l2 = void 0, y2();
        });
        return;
      }
      y2();
    } catch (e4) {
      g2(e4);
    }
  }
  function y2() {
    if (s2 === `pending`) try {
      if (o2) {
        o2.postTask(h2, { priority: `user-visible` }).catch(g2);
        return;
      }
      c2 = r2 ? r2.setTimeout(h2, 0) : setTimeout(h2, 0);
    } catch (e4) {
      g2(e4);
    }
  }
  return n2.readyState === `loading` ? n2.addEventListener(`DOMContentLoaded`, v2, { once: true }) : v2(), f2;
}
function Qg(e3, t2, n2 = {}) {
  Vg(t2);
  let r2 = t2.nodeType === Node.DOCUMENT_NODE ? t2 : void 0, i2 = r2?.documentElement ?? t2, a2 = dc(e3);
  if (!a2) throw TypeError(`Compiled hydration root requires a compiler-issued component operation`);
  let o2 = Yg.get(i2);
  if (o2) return sg(e3, i2, e_(n2)), n2.onHydration?.({ kind: `root`, outcome: `updated`, markers: `none` }), o2;
  let s2 = n2.onProfile ? performance.now() : void 0, c2 = Fg(i2, n2), l2 = Xg(i2, c2), u2 = fu(c2.maxTreeNodes), d2 = lg(i2, u2), f2 = Gg(l2.domain);
  try {
    let t3 = r2 ? ng(e3, a2, r2, e_(c2, u2)) : c2.markerlessRoot ? tg(e3, a2, i2, e_(c2, u2)) : d2.hasMarkers ? eg(e3, a2, i2, e_(c2, u2)) : c2.allowMarkerless ? tg(e3, a2, i2, e_(c2, u2)) : false, n3 = `adopted`;
    if (!t3) {
      if (qg(l2.domain, f2), vg(c2, d2.hasMarkers ? `server markup did not match the client component` : `missing exact hydration markers`, d2.hasMarkers ? `adoption-mismatch` : `missing-markers`), r2) throw Error(`eXact cannot safely replace a mismatched Document root; reload the document or correct the authored root.`);
      i2.replaceChildren(), Kg(l2.domain, () => sg(e3, i2, e_(c2, u2))), n3 = `mounted`;
    }
    for (let e4 of ug(i2, d2.formState, u2)) kd(e4);
    return i2.setAttribute(`data-exact-hydrated`, `true`), c2.onHydration?.({ kind: `root`, outcome: n3, markers: r2 ? `document` : c2.markerlessRoot ? `markerless` : d2.hasMarkers ? `exact` : c2.allowMarkerless ? `markerless` : `none` }), l2;
  } catch (e4) {
    throw l2.dispose(), e4;
  } finally {
    s2 !== void 0 && we(n2.onProfile, { subsystem: `hydrate`, phase: `hydrate`, elapsedMs: performance.now() - s2 });
  }
}
function $g(e3, t2, n2 = {}) {
  try {
    Vg(t2);
  } catch (e4) {
    return Promise.reject(e4);
  }
  return Zg(() => Qg(typeof e3 == `function` ? e3() : e3, t2, n2), t2);
}
function e_(e3, t2) {
  return { logger: e3.logger, onErrorReport: e3.onErrorReport, maxTreeDepth: e3.maxTreeDepth, maxTreeNodes: e3.maxTreeNodes, allowUnsafeHtml: e3.allowUnsafeHtml, onUnsafeHtml: e3.onUnsafeHtml, onProfile: e3.onProfile, enhancementCatalog: e3.enhancementCatalog, componentDomain: e3.componentDomain, ...t2 ? { workBudget: t2 } : {} };
}
function t_(e3, t2, n2) {
  Ys(e3, t2, n2);
}
function n_(e3) {
  let t2 = /* @__PURE__ */ new Map(), n2 = /* @__PURE__ */ new Map(), r2 = /* @__PURE__ */ new Set(), i2 = /* @__PURE__ */ new Set(), a2 = /* @__PURE__ */ new WeakMap(), o2 = 0, s2 = 0, c2 = (e4) => {
    let t3 = l2();
    return t3 === void 0 ? e4 : `${t3}${r_(e4)}`;
  }, l2 = () => {
    for (let e4 = St(); e4; e4 = yt(e4)) {
      let t3 = a2.get(e4);
      if (t3 !== void 0) return t3;
    }
  }, u2 = (e4) => {
    for (let [a3, o3] of n2) a3.startsWith(e4) && (o3.stop(), n2.delete(a3), t2.delete(a3), i2.delete(a3), r2.delete(a3));
  };
  return { beginRender() {
    o2 = 0, r2.clear();
  }, endRender() {
    for (let [e4, a3] of n2) r2.has(e4) || i2.has(e4) || (a3.stop(), n2.delete(e4), t2.delete(e4));
  }, dispose() {
    for (let e4 of n2.values()) e4.stop();
    n2.clear(), t2.clear(), i2.clear();
  }, map(l3, d2, f2, p2, m2, h2, g2 = false) {
    let _2 = C(() => wn(l3)), v2 = P(l3) && _2 ? C(() => _2.get()) : l3, y2 = p2 ?? `map:${o2++}`, b2 = c2(y2);
    r2.add(b2), g2 && i2.add(b2);
    let x2 = F(m2 ?? v2), ee2 = h2 ?? Function.prototype.toString.call(d2), te2 = n2.get(b2);
    if (!te2 || te2.collection !== x2 || te2.identity !== ee2) {
      te2?.stop();
      let e4 = pi(m2 ?? v2, d2, p2 ?? `an unlabelled this.map() call`, h2);
      n2.set(b2, { collection: x2, identity: ee2, stop: e4 });
    }
    let ne2 = t2.get(b2), S2 = (p2 !== void 0 || ne2?.render === f2 ? ne2?.cache : void 0) ?? /* @__PURE__ */ new Map();
    (!ne2 || ne2.render !== f2) && t2.set(b2, { render: f2, cache: S2 });
    let re2 = () => {
      let t3 = _2 ? _2.get() : P(l3) ? l3.get() : l3, n3 = /* @__PURE__ */ new Set(), r3 = [];
      for (let i3 of t3) {
        let t4 = String(d2(i3));
        if (n3.has(t4)) throw Error(`Duplicate key "${t4}" in ${p2 ?? `an unlabelled this.map() call`}`);
        n3.add(t4);
        let o3 = S2.get(t4);
        if (!o3 || !Object.is(F(o3.item), F(i3))) {
          let n4 = A(e3), r4 = `${b2}${r_(t4)}${s2++}:`;
          a2.set(n4, r4), vt(n4, () => u2(r4));
          let c3;
          try {
            c3 = j(n4, () => f2(i3));
          } catch (e4) {
            throw n4.stop(), e4;
          }
          o3 = { item: i3, operation: c3, keyed: Vc(c3, t4, n4), scope: n4 }, S2.set(t4, o3), vt(n4, () => {
            S2.get(t4)?.scope === n4 && S2.delete(t4);
          });
        }
        r3.push(o3.keyed);
      }
      for (let e4 of S2.keys()) n3.has(e4) || S2.delete(e4);
      return r3;
    };
    return g2 ? re2() : zl(re2, p2);
  } };
}
function r_(e3) {
  return `${e3.length}:${e3}/`;
}
var i_;
function a_(e3) {
  if (i_ && i_ !== e3) throw Error(`Conflicting eXact component list capability integration`);
  i_ = e3;
}
function o_() {
  if (!i_) throw Error(`Component lists require the compiler-selected @exactjs/core/runtime/lists capability`);
  return i_;
}
function s_() {
  return i_;
}
var c_ = /* @__PURE__ */ new WeakMap();
function l_(e3) {
  let t2 = c_.get(e3);
  return t2 || (t2 = n_(e3.scope), c_.set(e3, t2)), t2;
}
a_(Object.freeze({ map(e3, t2, n2, r2, i2, a2, o2) {
  return l_(e3).map(t2, n2, r2, i2, a2, o2);
}, mapDirect(e3, t2, n2, r2, i2, a2, o2) {
  return l_(e3).map(t2, n2, r2, i2, a2, o2, true);
}, begin(e3) {
  c_.get(e3)?.beginRender();
}, end(e3) {
  c_.get(e3)?.endRender();
}, dispose(e3) {
  let t2 = c_.get(e3);
  t2 && (c_.delete(e3), t2.dispose());
} }));
function u_(e3, t2, n2, r2, i2, a2) {
  return o_().map(this, e3, t2, n2, r2, i2, a2);
}
Hl({ map: { configurable: true, writable: true, value: u_ } });
function d_(e3, t2, n2, r2, i2, a2, o2) {
  return o_().mapDirect(e3, t2, n2, r2, i2, a2, o2);
}
var f_ = class extends jl {
  taskCapability;
  taskState;
  taskReleased = false;
  constructor(e3, t2, n2, r2, i2, a2, o2, s2 = o2.artifact.instantiate) {
    super(e3, t2, n2, r2, i2, o2);
    let c2 = this.runtimeABI & 8 ? Ra() : void 0;
    if (this.runtimeABI & 8 && !c2) {
      let e4 = Error(`Task component construction requires the compiler-selected task capability`);
      throw gl(this, e4), e4;
    }
    this.taskCapability = c2;
    try {
      this.taskState = c2?.create(this, e3, o2, a2, t2, !!this.componentResumption), this.initializeComponent(() => c2 ? c2.run(this.taskState, () => s2.call(this, this.props)) : s2.call(this, this.props)), c2 && this.componentResumption && c2.resume(this.taskState, new Set(`componentId` in this.componentResumption ? this.componentResumption.settledContinuations : this.componentResumption[3] ?? [])), c2?.retain(this.taskState, this);
    } catch (e4) {
      throw gl(this, e4), e4;
    }
  }
  unmount(e3 = `unmount`) {
    let t2;
    try {
      super.unmount(e3);
    } catch (e4) {
      t2 = e4;
    }
    if (!this.taskReleased) {
      this.taskReleased = true;
      try {
        this.taskCapability?.release(this.taskState, this);
      } catch (e4) {
        t2 === void 0 && (t2 = e4);
      }
    }
    if (t2 !== void 0) throw t2;
  }
}, p_ = class extends f_ {
  mountController;
  activationController;
  durableReleased = false;
  constructor(e3, t2, n2, r2, i2, a2, o2, s2) {
    super(e3, n2, r2, i2, a2, o2, s2, t2);
  }
  beginRender() {
    this.runtimeABI & 4 && s_()?.begin(this);
  }
  endRender() {
    this.runtimeABI & 4 && s_()?.end(this);
  }
  unmount(e3 = `unmount`) {
    let t2;
    try {
      super.unmount(e3);
    } catch (e4) {
      t2 = e4;
    }
    if (!this.durableReleased) {
      this.durableReleased = true;
      let n2 = (e4) => {
        try {
          e4();
        } catch (e5) {
          t2 === void 0 && (t2 = e5);
        }
      };
      this.runtimeABI & 4 && n2(() => s_()?.dispose(this)), this.mountController && n2(() => this.mountController.abort(e3));
      let r2 = this.runtimeABI & 2 ? Xs(this, `unmount`) : [];
      for (let t3 of r2) try {
        let n3 = t3({ signal: AbortSignal.abort(e3), reason: e3 });
        so(n3) && Hs(this, Promise.resolve(n3), `unmount`);
      } catch (e4) {
        n2(() => W(this, U(e4, `lifecycle`, this, `unmount`)));
      }
      this.runtimeABI & 2 && Qs(this);
    }
    if (t2 !== void 0) throw t2;
  }
  handleMounted() {
    let e3 = this.runtimeABI & 2 ? Xs(this, `mount`) : [];
    this.mountController = e3.length ? new AbortController() : void 0;
    for (let t2 of e3) {
      if (!this.mounted) break;
      try {
        let e4 = t2({ signal: this.mountController.signal });
        so(e4) && Hs(this, Promise.resolve(e4), `mount`);
      } catch (e4) {
        W(this, U(e4, `lifecycle`, this, `mount`));
      }
    }
  }
  activate(e3) {
    if (!super.activate(e3)) return false;
    let t2 = this.runtimeABI & 2 ? Xs(this, `activate`) : [];
    this.activationController = t2.length ? new AbortController() : void 0;
    for (let e4 of t2) try {
      let t3 = e4({ signal: this.activationController.signal });
      so(t3) && Hs(this, Promise.resolve(t3), `activate`);
    } catch (e5) {
      W(this, U(e5, `lifecycle`, this, `activate`));
    }
    return true;
  }
  deactivate(e3) {
    if (!super.deactivate(e3)) return false;
    this.activationController?.abort(e3), this.activationController = void 0;
    let t2 = this.runtimeABI & 2 ? Xs(this, `deactivate`) : [];
    for (let n2 of t2) try {
      let t3 = n2({ signal: AbortSignal.abort(e3), reason: e3 });
      so(t3) && Hs(this, Promise.resolve(t3), `deactivate`);
    } catch (e4) {
      W(this, U(e4, `lifecycle`, this, `deactivate`));
    }
    return true;
  }
}, m_ = function(e3, t2, n2, r2, i2, a2) {
  return new p_(this.instantiate, a2.artifact.instantiate, t2, e3, n2, r2, i2, a2);
}, h_ = /* @__PURE__ */ Symbol.for(`@exactjs/component-contract`), g_ = { bindings: [[0, 25, 0], [1, 8, 0], [2, 12, 0], [3, 32, 0], [5, 2, 0]], props: 5, apply: (e3, t2, n2) => {
  let r2 = e3[2];
  r2 && (t2 & 4 && _m(r2, 5), t2 & 8 && _m(r2, 6), t2 & 16 && _m(r2, 7), t2 & 32 && lm(r2, 0, 0));
  let i2 = e3[1];
  i2 && t2 & 2 && lm(i2, 0, 0);
  let a2 = e3[0];
  a2 && t2 & 1 && hm(a2, 0, 1, 0);
} }, __ = { bindings: [[0, 3, 0]], props: 1, apply: (e3, t2, n2) => {
  let r2 = e3[0];
  r2 && (t2 & 1 && hm(r2, 1, 1, 0), t2 & 2 && lm(r2, 0, 0));
} };
Object.assign(E_, { [/* @__PURE__ */ Symbol.for(`@exactjs/component`)]: `xp_5xgm5Jp-BAVGSHYKaUb-`, [h_]: { artifact: { version: 2, target: `client`, id: `xp_5xgm5Jp-BAVGSHYKaUb-`, instantiate: E_, construct: Wl, abi: 1, capabilities: [], state: [], props: [`severity`], attach: ic, receive: ac, dispose: oc, updates: __ } } });
var v_ = G({ version: 2, id: `x0zD5X2abUEe2H7Wc2itVjW`, namespace: `html`, template: `<p class="empty">Loading incidents\u2026</p>`, root: [`p`], work: [1, 0], directClaims: true }), y_ = G({ version: 2, id: `x46hB2XUY5_EpPBx0BBAMp_`, namespace: `html`, template: `<p class="empty">No incidents match this workspace.</p>`, root: [`p`], work: [1, 0], directClaims: true }), b_ = G({ version: 2, id: `xw8aN1VhGL_JEF3Rl41fWuM`, namespace: `html`, template: `<p role="alert"><!---->\uE000exact:0\uE001<!----></p>`, wire: [[`p`, `html`, 1, 1], [[3, 0, 0, true]], [[0, 0, [1, 0], true], [7, 0, g_]]], directClaims: true }), x_ = G({ version: 2, id: `xTXYJaGtLJXrAC1QEguZSBY`, namespace: `html`, template: `<button type="button" data-testid="incident-row"><strong><!---->\uE000exact:3\uE001<!----></strong><small><!---->\uE000exact:4\uE001<!----> \xB7 <!---->\uE000exact:5\uE001<!----></small></button>`, wire: [[`button`, `html`, 3, 6], [[6, 1, 1041, `strong`], [4, 2, 0, true, 1], [0, 1, 0, `strong`], [1, 1], [3, 3, 0, true], [2], [0, 2, 0, `small`], [1, 2], [8, [4, ` \xB7 `, 5]], [3, 4, 0, true], [3, 5, 1, true], [2], [7, 0, 0]], [[2, 2, [], 0], [0, 3], [0, 4], [0, 5], [5, 0, 0, true], [7, 1, g_]]], directClaims: true, targetSlots: [2] }), S_ = G({ version: 2, id: `xTMh6_0H_XirlTRIIScMVHJ`, namespace: `html`, template: `<section class="queue-panel" aria-labelledby="queue-title"><div class="section-heading"><div><span class="eyebrow">Active response</span><h2 id="queue-title">Incident queue</h2></div><button type="button" class="quiet">Refresh</button></div><div class="filters"><label>Severity <select><option value="all">All</option><option value="critical">Critical</option><option value="high">High</option><option value="medium">Medium</option></select></label><label>Status <select><option value="all">All</option><option value="open">Open</option><option value="investigating">Investigating</option><option value="closed">Closed</option></select></label></div><!--x:0--><!--/x:0--><!--x:1--><!--/x:1--><!--x:2--><!--/x:2--><div class="incident-list"></div></section>`, wire: [[`section`, `html`, 20, 9], [[5, 5, 2, `0`], [5, 6, 0, `1`], [5, 7, 0, `2`], [0, 19, 0, `div`], [1, 19], [4, 8, 0], [2], [6, 5, 2050, `button`], [7, 0, 5], [6, 8, 19, `select`], [7, 1, 8], [6, 14, 2067, `select`], [7, 3, 14]], [[1, 5, true], [1, 6, true], [1, 7, true], [3, 8], [12, 0, 0, [[`__exactDirectInteraction:onClick`, 1, 3]], true], [6, 1, 1], [6, 2, 3], [7, 2, g_]]], directClaims: true, keyedChildren: 256, targetSlots: [5, 6, 7, 8] }), C_ = G({ version: 2, id: `xvl_yj1OcUKmFPTiMXPL_-V`, namespace: `html`, template: `<span><!---->\uE000exact:1\uE001<!----></span>`, wire: [[`span`, `html`, 1, 2], [[3, 1, 0, true], [7, 0, 0]], [[0, 1, [1, 0], true], [5, 0, 0, true], [7, 0, __]]], directClaims: true }), w_ = function(e3) {
  return L(this.state, 0, `all`), L(this.state, 1, `all`), () => K(S_, (t2) => {
    if (t2 === 5) return I(e3, 2) ? K(v_, [], this) : null;
    if (t2 === 6) return !I(e3, 2) && I(e3, 1).length === 0 && !I(e3, 0) ? K(y_, [], this) : null;
    if (t2 === 7) return I(e3, 0) ? K(b_, [], this) : null;
    if (t2 === 8) {
      let t3 = I(e3, 1).filter((e4) => (I(this.state, 0) === `all` || e4.severity === I(this.state, 0)) && (I(this.state, 1) === `all` || e4.status === I(this.state, 1)));
      return d_(this, t3, (e4) => e4.id, (t4) => K(x_, (e4) => e4 === 2 ? uc(E_, { severity: [Lr, t4, `severity`] }) : e4 === 3 ? t4.title : e4 === 4 ? t4.ownerId ? `Assigned` : `Unassigned` : e4 === 5 ? t4.status : void 0, this, (n2, r2) => {
        n2 === 0 && (r2(`className`, [`incident`, { active: t4.id === I(e3, 5) }]), r2(`__exactClosedInteraction:onClick`, () => I(e3, 4)(t4.id)));
      }), `xvauc75zJhLSnWpVYQsquY1`, void 0, `member:id`);
    }
  }, this, (e4, t2) => {
    e4 === 1 && (t2(`value`, I(this.state, 0) ?? ``), t2(`__exactBindChange`, (e5) => L(this.state, 0, e5.currentTarget.value))), e4 === 2 && (t2(`value`, I(this.state, 1) ?? ``), t2(`__exactBindChange`, (e5) => L(this.state, 1, e5.currentTarget.value)));
  });
}, T_ = Object.assign(w_, { [/* @__PURE__ */ Symbol.for(`@exactjs/component`)]: `xpIJOILUNwd859VP0fMOQEe`, [h_]: { artifact: { version: 2, target: `client`, id: `xpIJOILUNwd859VP0fMOQEe`, instantiate: w_, construct: m_, abi: 5, capabilities: [`interactions`], state: [`severity`, `status`], props: [`error`, `incidents`, `loading`, `onRefresh`, `onSelectedIdChanged`, `selectedId`], serialization: [1, `incidents`, [2, [1, `id`, 0, `title`, 0, `severity`, 0, `status`, 0, `ownerId`, 0, `version`, 0, `updatedAt`, 0, `comments`, [2, [1, `id`, 0, `authorId`, 0, `body`, 0, `createdAt`, 0]]]], `selectedId`, 0, `onSelectedIdChanged`, 0, `loading`, 0, `error`, 0, `onRefresh`, 0], attach: ic, receive: ac, dispose: oc, updates: g_ } } });
function E_(e3) {
  return () => K(C_, [], this, (t2, n2) => {
    t2 === 0 && n2(`className`, [`severity`, { critical: I(e3, 0) === `critical` }, { high: I(e3, 0) === `high` }, { medium: I(e3, 0) === `medium` }, { low: I(e3, 0) === `low` }]);
  });
}
var D_ = `http://127.0.0.1:4310`;
async function O_(e3) {
  let [t2, n2] = await Promise.all([fetch(`${D_}/api/session`, { signal: e3 }), fetch(`${D_}/api/incidents`, { signal: e3 })]);
  if (!t2.ok || !n2.ok) throw Error(`Service unavailable`);
  let r2 = await t2.json(), i2 = await n2.json();
  return { ...r2, ...i2 };
}
async function k_(e3, t2, n2, r2) {
  let i2 = await fetch(`${D_}/api/incidents/${e3}/claim`, { method: `POST`, headers: { "content-type": `application/json` }, body: JSON.stringify({ actorId: t2, expectedVersion: n2 }), signal: r2 }), a2 = await i2.json();
  if (!i2.ok && i2.status !== 409) throw Error(a2.error?.message ?? `Unable to claim incident`);
  return { status: i2.status, ...a2 };
}
async function A_(e3, t2, n2, r2, i2) {
  let a2 = await fetch(`${D_}/api/incidents/${e3}/comments`, { method: `POST`, headers: { "content-type": `application/json` }, body: JSON.stringify({ actorId: t2, body: n2, clientMutationId: r2 }), signal: i2 });
  if (!a2.ok) throw Error(`Comment was not accepted`);
  return await a2.json();
}
async function j_(e3, t2) {
  let n2 = await fetch(`${D_}/api/incidents/${e3}/analysis`, { method: `POST`, headers: { "content-type": `application/json` }, body: `{}`, signal: t2 });
  if (!n2.ok) throw Error(`Analysis was not accepted`);
  return await n2.json();
}
var M_ = /* @__PURE__ */ new Set(), N_, P_ = `Connecting`;
function F_(e3, t2) {
  M_.add(e3), e3.onConnection?.(P_), I_();
  let n2 = true, r2 = () => {
    n2 && (n2 = false, M_.delete(e3), !M_.size && (N_?.close(), N_ = void 0, P_ = `Connecting`));
  };
  return t2.aborted ? r2() : t2.addEventListener(`abort`, r2, { once: true }), r2;
}
function I_() {
  N_ || (N_ = new EventSource(`${D_}/api/events`), N_.onopen = () => L_(`Live service`), N_.onerror = () => L_(`Reconnecting`), N_.addEventListener(`incident`, (e3) => {
    let t2 = JSON.parse(e3.data);
    for (let e4 of M_) e4.onIncident?.(t2);
  }), N_.addEventListener(`job`, (e3) => {
    let t2 = JSON.parse(e3.data);
    for (let e4 of M_) e4.onJob?.(t2);
  }));
}
function L_(e3) {
  P_ = e3;
  for (let t2 of M_) t2.onConnection?.(e3);
}
var R_ = /* @__PURE__ */ Symbol.for(`@exactjs/component-contract`), z_ = { bindings: [[0, 24, 0], [0, 4, 0], [1, 1, 0], [3, 2, 0]], props: 1, apply: (e3, t2, n2) => {
  let r2 = e3[4];
  r2 && t2 & 16 && _m(r2, 0);
  let i2 = e3[3];
  i2 && t2 & 8 && _m(i2, 0);
  let a2 = e3[2];
  a2 && t2 & 4 && lm(a2, 0, 2);
  let o2 = e3[1];
  o2 && t2 & 2 && hm(o2, 0, 0, 3);
  let s2 = e3[0];
  s2 && t2 & 1 && hm(s2, 0, 0, 1);
} }, B_ = G({ version: 2, id: `xGn9yDMZByLcAkQszHhw73F`, namespace: `html`, template: `<div class="detail-heading"><div><h2><!---->\uE000exact:1\uE001<!----></h2></div><span class="version"><!---->\uE000exact:2\uE001<!----></span></div>`, wire: [[`div`, `html`, 4, 3], [[0, 1, 0, `div`], [1, 1], [6, 2, 131074, `h2`], [4, 0, 0, true, 2], [0, 2, 0, `h2`], [1, 2], [3, 1, 0, true], [2], [2], [0, 3, 0, `span`], [1, 3], [3, 2, 0, true], [2]], [[2, 0, [[0]], 1], [0, 1], [11, 2, [`Version `, ``]]]], directClaims: true, targetSlots: [0] }), V_ = G({ version: 2, id: `xGoOzEstYGnlEqUeszguUUG`, namespace: `html`, template: `<div class="facts"><div><span>Owner</span><strong><!---->\uE000exact:0\uE001<!----></strong></div><div><span>Status</span><strong><!---->\uE000exact:1\uE001<!----></strong></div></div>`, wire: [[`div`, `html`, 7, 2], [[0, 1, 0, `div`], [1, 1], [0, 3, 1, `strong`], [1, 3], [3, 0, 0, true], [2], [2], [0, 4, 0, `div`], [1, 4], [0, 6, 1, `strong`], [1, 6], [3, 1, 0, true], [2], [2]], [[0, 0], [0, 1]]], directClaims: true }), H_ = G({ version: 2, id: `xR_nsA8G9g5QkLTvDkssOag`, namespace: `html`, template: `<p class="alert" role="alert"><!---->\uE000exact:0\uE001<!----></p>`, wire: [[`p`, `html`, 1, 1], [[3, 0, 0, true]], [[0, 0, [0, 1], true], [9, 0, z_]]], directClaims: true }), U_ = G({ version: 2, id: `xII-QrjF90NFixbndGlKNmL`, namespace: `html`, template: `<p class="alert" role="alert"><!---->\uE000exact:0\uE001<!----></p>`, wire: [[`p`, `html`, 1, 1], [[3, 0, 0, true]], [[0, 0, [0, 3], true], [9, 1, z_]]], directClaims: true }), W_ = G({ version: 2, id: `x0fg8wh83aPSirY8CRuZhqv`, namespace: `html`, template: `<button type="button" class="primary">Claim incident</button>`, wire: [[`button`, `html`, 1, 1], [[7, 0, 0]], [[5, 0, 0]]], directClaims: true }), G_ = G({ version: 2, id: `xSyX9yz6saYjNvlddpw2QRx`, namespace: `html`, template: `<strong><!---->\uE000exact:0\uE001<!----></strong>`, wire: [[`strong`, `html`, 1, 1], [[3, 0, 0, true]], [[0, 0]]], directClaims: true }), K_ = G({ version: 2, id: `xGe3aQxoCh1SOPPjW3lbm4t`, namespace: `html`, template: `<section class="analysis-card"><div><h3>Server analysis</h3><p role="status"><!---->\uE000exact:0\uE001<!----></p></div><button type="button" class="quiet">Start analysis</button></section>`, wire: [[`section`, `html`, 5, 4], [[0, 1, 0, `div`], [1, 1], [0, 3, 1, `p`], [1, 3], [3, 0, 0, true], [2], [4, 1, 0], [2], [6, 4, 17, `button`], [7, 2, 4]], [[0, 0], [1, 1], [12, 0, 2, [[`disabled`, 0, 0]], true], [9, 2, z_]]], directClaims: true, targetSlots: [1] }), q_ = G({ version: 2, id: `xaj_rhxatb7hP9vTVlAUhLx`, namespace: `html`, template: `<p class="empty">No comments yet.</p>`, root: [`p`], work: [1, 0], directClaims: true }), J_ = G({ version: 2, id: `xCddtsRpoqg03a8u6gE8m22`, namespace: `html`, template: `<article><strong><!---->\uE000exact:0\uE001<!----></strong><p><!---->\uE000exact:1\uE001<!----></p></article>`, wire: [[`article`, `html`, 3, 2], [[0, 1, 0, `strong`], [1, 1], [3, 0, 0, true], [2], [0, 2, 0, `p`], [1, 2], [3, 1, 0, true], [2]], [[0, 0], [0, 1]]], directClaims: true }), Y_ = G({ version: 2, id: `x7uTT_EjJQbMgnGpY7p6zhF`, namespace: `html`, template: `<section class="comments"><h3>Response log</h3><!--x:0--><!--/x:0--><!--x:1--><!--/x:1--><form><label>New comment <textarea maxLength="2000" required></textarea></label><button type="submit" class="primary">Add comment</button></form></section>`, wire: [[`section`, `html`, 6, 5], [[5, 0, 1, `0`], [5, 1, 0, `1`], [6, 2, 1025, `form`], [7, 2, 2], [6, 4, 1027, `textarea`], [7, 3, 4]], [[1, 0, true], [3, 1], [5, 0, 2], [6, 1, 3], [7, 3, z_]]], directClaims: true, keyedChildren: 2, targetSlots: [0, 1] }), X_ = G({ version: 2, id: `xw06nSmfiYtmyJ3t1pU0CDz`, namespace: `html`, template: `<p class="empty">Select an incident to inspect its response history.</p>`, root: [`p`], work: [1, 0], directClaims: true }), Z_ = G({ version: 2, id: `xNYAbAdcBmuwUKhO1B3gvS5`, namespace: `html`, template: `<section class="detail-panel" aria-label="Incident detail"></section>`, wire: [[`section`, `html`, 1, 1], [[4, 0, 0]], [[1, 0, true], [7, 4, z_]]], directClaims: true, targetSlots: [0] }), Q_ = function(e3) {
  let t2 = this.state;
  L(this.state, 2, ``), L(this.state, 1, ``), L(this.state, 4, null), L(this.state, 0, false), L(this.state, 3, ``), L(this.state, 5, C(() => I(e3, 0)?.id ?? ``)), L(this.state, 6, C(() => I(e3, 0)?.version ?? 0));
  async function n2() {
    if (!I(e3, 0) || !I(e3, 2)) return;
    I(t2, 5) !== I(e3, 0).id && (L(t2, 5, I(e3, 0).id), L(t2, 6, I(e3, 0).version));
    let n3 = ev(I(e3, 0));
    I(e3, 1)({ ...I(e3, 0), ownerId: I(e3, 2), status: `investigating` }, `optimistic`), L(t2, 1, ``), L(t2, 3, ``);
    try {
      let r3 = await k_(n3.id, I(e3, 2), I(t2, 6), void 0);
      r3.status === 409 && r3.error?.current ? (I(e3, 1)(r3.error.current, `authoritative`), L(t2, 6, r3.error.current.version), L(t2, 1, `This incident changed while you were viewing it. The latest owner is shown.`)) : r3.incident ? (I(e3, 1)(r3.incident, `authoritative`), L(t2, 6, r3.incident.version)) : I(e3, 1)(n3, `optimistic`);
    } catch (r3) {
      I(e3, 1)(n3, `optimistic`), L(t2, 3, r3 instanceof Error ? r3.message : `Unable to claim incident`);
    }
  }
  async function r2() {
    if (!I(e3, 0)) return;
    let n3 = I(t2, 2).trim();
    if (!n3 || [...n3].length > 2e3) {
      L(t2, 3, `Comment must contain 1 to 2,000 characters.`);
      return;
    }
    let r3 = ev(I(e3, 0)), i3 = { id: `pending-${crypto.randomUUID()}`, authorId: I(e3, 2), body: n3, createdAt: (/* @__PURE__ */ new Date()).toISOString() };
    I(e3, 1)({ ...r3, comments: [...r3.comments, i3] }, `optimistic`), L(t2, 2, ``), L(t2, 3, ``);
    try {
      let i4 = await A_(r3.id, I(e3, 2), n3, crypto.randomUUID(), void 0);
      I(e3, 1)(i4.incident, `authoritative`), L(t2, 6, i4.incident.version);
    } catch (i4) {
      I(e3, 1)(r3, `optimistic`), L(t2, 2, n3), L(t2, 3, i4 instanceof Error ? i4.message : `Unable to add comment`);
    }
  }
  async function i2() {
    if (I(e3, 0)) {
      L(t2, 0, true), L(t2, 3, ``);
      try {
        let n3 = await j_(I(e3, 0).id);
        L(t2, 4, n3.job);
      } catch (e4) {
        L(t2, 3, e4 instanceof Error ? e4.message : `Unable to start analysis`);
      } finally {
        L(t2, 0, false);
      }
    }
  }
  return t_(this, `mount`, ({ signal: e4 }) => {
    F_({ onJob: (e5) => e5.id === t2.job?.id && L(this.state, 4, e5) }, e4);
  }), () => K(Z_, [() => I(e3, 0) ? [K(B_, (t3) => t3 === 0 ? uc(E_, { severity: [Lr, I(e3, 0), `severity`] }) : t3 === 1 ? I(e3, 0).title : I(e3, 0).version, this), K(V_, (t3) => {
    if (t3 === 0) return I(e3, 3).find((t4) => t4.id === I(e3, 0)?.ownerId)?.name ?? `Unassigned`;
    if (t3 === 1) return I(e3, 0).status;
  }, this), zl(() => I(this.state, 1) ? K(H_, [], this) : null, `xFpzqHiTxJF1XQ5lMx6ma0m`), zl(() => I(this.state, 3) ? K(U_, [], this) : null, `xot5kEg25UbhIjs5KLC5E8g`), K(W_, [], this, (e4, t3) => {
    e4 === 0 && t3(`__exactClosedInteraction:onClick`, n2);
  }), K(K_, (e4) => e4 === 0 ? I(this.state, 4) ? `Analysis ${this.state.job.status}` : `Analysis has not started` : e4 === 1 ? this.state.job?.result ? K(G_, [() => this.state.job.result.finding], this) : null : void 0, this, (e4, t3) => {
    e4 === 0 && t3(`__exactClosedInteraction:onClick`, i2);
  }), K(Y_, (t3) => t3 === 0 ? I(e3, 0).comments.length === 0 ? K(q_, [], this) : null : t3 === 1 ? d_(this, I(e3, 0).comments, (e4) => e4.id, (t4) => K(J_, (n3) => n3 === 0 ? I(e3, 3).find((e4) => e4.id === t4.authorId)?.name : t4.body, this), `xs8Ym6GO7mehdGpImMStbbd`, void 0, `member:id`) : void 0, this, (e4, t3) => {
    e4 === 0 && t3(`__exactDirectInteraction:onSubmit`, (e5) => (e5.preventDefault(), r2())), e4 === 1 && (t3(`value`, I(this.state, 2) ?? ``), t3(`__exactBindInput`, (e5) => L(this.state, 2, e5.currentTarget.value)));
  })] : K(X_, [], this)], this);
}, $_ = Object.assign(Q_, { [/* @__PURE__ */ Symbol.for(`@exactjs/component`)]: `xIK8_9cLJrLkOKRWpREglkO`, [R_]: { artifact: { version: 2, target: `client`, id: `xIK8_9cLJrLkOKRWpREglkO`, instantiate: Q_, construct: m_, abi: 7, capabilities: [`interactions`], state: [`busy`, `conflict`, `draft`, `error`, `job`, `viewedIncidentId`, `viewedVersion`], props: [`incident`, `onIncident`, `sessionUserId`, `users`], serialization: [1, `incident`, [1, `id`, 0, `title`, 0, `severity`, 0, `status`, 0, `ownerId`, 0, `version`, 0, `updatedAt`, 0, `comments`, [2, [1, `id`, 0, `authorId`, 0, `body`, 0, `createdAt`, 0]]], `users`, [2, [1, `id`, 0, `name`, 0]], `sessionUserId`, 0, `onIncident`, 0], attach: ic, receive: ac, dispose: oc, updates: z_ } } });
function ev(e3) {
  return { ...e3, comments: e3.comments.map((e4) => ({ ...e4 })) };
}
var tv = /* @__PURE__ */ Symbol.for(`@exactjs/component-contract`), nv = { bindings: [[0, 1, 0]], apply: (e3, t2, n2) => {
  let r2 = e3[0];
  r2 && t2 & 1 && hm(r2, 0, 0, 0);
} }, rv = { bindings: [[0, 15, 0]], apply: (e3, t2, n2) => {
  let r2 = e3.props;
  if (t2 & 1) {
    let t3 = I(r2, 0)?.incidents;
    L(e3.state, 2, t3 ?? []);
  }
  if (t2 & 2) {
    let t3 = I(r2, 0)?.users;
    L(e3.state, 6, t3 ?? []);
  }
  if (t2 & 4) {
    let t3 = I(r2, 0)?.sessionUserId;
    L(e3.state, 5, t3 ?? ``);
  }
  if (t2 & 8) {
    let t3 = I(r2, 0);
    L(e3.state, 3, !t3);
  }
} }, iv = G({ version: 2, id: `xQR7oz3Y2cAWzwxg19gqJCZ`, namespace: `html`, template: `<div class="app-shell"><header class="masthead"><div><span class="eyebrow">Operations workspace</span><h1>Signal Desk</h1></div><span class="connection" role="status"><!---->\uE000exact:0\uE001<!----></span></header><main><!--x:1--><!--/x:1--></main></div>`, wire: [[`div`, `html`, 7, 3], [[0, 1, 0, `header`], [1, 1], [0, 5, 1, `span`], [1, 5], [3, 0, 0, true], [2], [2], [0, 6, 0, `main`], [1, 6], [5, 1, 0, `1`, true], [4, 2, 0, true], [2]], [[0, 0, [0, 0], true], [2, 1, [[1], [2], [3], [4]], 0], [1, 2], [9, 0, nv]]], directClaims: true, targetSlots: [1, 2] }), av = function(e3) {
  let t2 = this.state;
  rv.apply(this, 1, 0), rv.apply(this, 2, 0), rv.apply(this, 4, 0), Ls(this, (t3, { signal: n3 }) => {
    L(this.state, 4, lv(t3) || I(e3, 0)?.incidents[0]?.id || ``);
  }, ks(e3, 1)), L(this.state, 1, ``), rv.apply(this, 8, 0), L(this.state, 0, `Connecting`);
  let n2 = (e4, t3 = `authoritative`) => {
    let n3 = I(this.state, 2).find((t4) => t4.id === e4.id);
    !n3 || t3 === `authoritative` && (n3.version > e4.version || sv(n3, e4)) || se(() => {
      n3.ownerId = e4.ownerId, n3.status = e4.status, n3.version = e4.version, cv(n3.comments, e4.comments) || (n3.comments = e4.comments);
    });
  }, r2 = zs(this, `loadQueue`, async (e4) => {
    L(t2, 3, true), L(t2, 1, ``);
    try {
      let n3 = await ns(e4.signal, O_(oo(e4.signal, e4.signal)));
      L(t2, 5, n3.sessionUserId), L(t2, 6, n3.users), L(t2, 2, n3.incidents), C(() => I(t2, 4)) || L(t2, 4, n3.incidents[0]?.id ?? ``);
    } catch (e5) {
      L(t2, 1, e5 instanceof Error ? e5.message : `Unable to load incidents`);
    } finally {
      L(t2, 3, false);
    }
  }), i2 = (e4) => {
    L(this.state, 4, e4), history.pushState({}, ``, `/incidents/${e4}`);
  }, a2 = () => void r2();
  return I(e3, 0) || r2(), t_(this, `mount`, ({ signal: e4 }) => {
    F_({ onConnection: (e5) => L(this.state, 0, e5), onIncident: (e5) => n2(e5, `authoritative`) }, e4), window.addEventListener(`popstate`, () => {
      L(this.state, 4, lv());
    }, { signal: e4 });
  }), () => K(iv, (e4) => e4 === 1 ? uc(T_, { incidents: Vr(this.state, 2), selectedId: Vr(this.state, 4), onSelectedIdChanged: i2, loading: Vr(this.state, 3), error: Vr(this.state, 1), onRefresh: a2 }) : e4 === 2 ? uc($_, { incident: Bl(() => I(this.state, 2).find((e5) => e5.id === I(this.state, 4))), users: Vr(this.state, 6), sessionUserId: Vr(this.state, 5), onIncident: n2 }) : void 0, this);
}, ov = Object.assign(av, { [/* @__PURE__ */ Symbol.for(`@exactjs/component`)]: `xuAKzNckgPuCTsehVDjqI5P`, [tv]: { artifact: { version: 2, target: `client`, id: `xuAKzNckgPuCTsehVDjqI5P`, instantiate: av, construct: m_, abi: 11, capabilities: [`tasks`, `continuations`, `resumption`, `interactions`], state: [`connection`, `error`, `incidents`, `loading`, `selectedId`, `sessionUserId`, `users`], props: [`initialData`, `path`], serialization: [1, `initialData`, [1, `incidents`, [2, [1, `id`, 0, `title`, 0, `severity`, 0, `status`, 0, `ownerId`, 0, `version`, 0, `updatedAt`, 0, `comments`, [2, [1, `id`, 0, `authorId`, 0, `body`, 0, `createdAt`, 0]]]], `users`, [2, [1, `id`, 0, `name`, 0]], `sessionUserId`, 0], `path`, 0], attach: ic, receive: ac, dispose: oc, updates: nv, inputs: rv }, resumption: { componentId: `xuAKzNckgPuCTsehVDjqI5P`, statePaths: [`connection`, `error`, `incidents`, `loading`, `selectedId`, `sessionUserId`, `users`], stateInputs: [], valueCaptures: [`state`], contexts: [], boundaries: [`xMu3fuNmRjc6dWpuERPXhmv`, `xOHhVB9dGpmnZm5koclWhiP`], continuations: [`xs4mKJpgQea0Nym7aei2uXA`] } } });
function sv(e3, t2) {
  return e3.version === t2.version && e3.ownerId === t2.ownerId && e3.status === t2.status && cv(e3.comments, t2.comments);
}
function cv(e3, t2) {
  return e3.length === t2.length && e3.every((e4, n2) => {
    let r2 = t2[n2];
    return r2?.id === e4.id && r2.authorId === e4.authorId && r2.body === e4.body && r2.createdAt === e4.createdAt;
  });
}
function lv(e3 = typeof window > `u` ? `/` : window.location.pathname) {
  return e3.match(/^\/incidents\/([^/]+)$/)?.[1] ?? ``;
}
var uv = void 0, dv = document.getElementById(`app`);
if (!dv) throw Error(`Missing incident application root`);
dv.childNodes.length > 0 ? $g(() => uc(ov, { ...Rg(ov, dv) }), dv, uv) : sg(uc(ov, {}), dv, uv);
