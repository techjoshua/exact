from pathlib import Path
p=Path('.tmp/fcp-bun-investigation-2026-09-20')
s=(p/'paint-probe-windows-client.mjs').read_text()
old="['exact','react'].map((id,i)=>({id:id+'-controlled',directory:id,artifact:'dist',url:'http://127.0.0.1:'+(4401+i)}))"
new="['exact','react','sveltekit','nuxt','tanstack-start'].map((id,i)=>({id:id+'-controlled',directory:id,artifact:['dist','dist','build/client','.output/public','.output/public'][i],url:'http://127.0.0.1:'+(4401+i)}))"
s=s.replace(old,new).replace('round<21','round<11')
s=s.replace("'/paint-probe-windows.json'", "'/paint-confirm-'+process.argv[2]+'.json'")
s=s.replace('samples},null,2)',"browserVersion:browser.version(),executable:chromium.executablePath(),platform:process.platform,node:process.version,samples},null,2)")
(p/'paint-confirm-client.mjs').write_text(s)
(p/'paint-confirm-owner.mjs').write_text('''import {spawn,execFileSync} from 'node:child_process';
import {startClientBenchmarkHarness} from '../../framework-comparison/src/client-benchmark-harness.mjs';
import {writeFile} from 'node:fs/promises';
const participants='''+new+''';
const harness=await startClientBenchmarkHarness(participants);
try {
 for(const [index,platform] of ['linux','windows','windows','linux'].entries()) {
  const path=import.meta.dirname+'/paint-confirm-client.mjs';
  const script=platform==='windows'?execFileSync('wslpath',['-w',path],{encoding:'utf8'}).trim():path;
  console.log('POPULATION',index,platform);
  const child=spawn(platform==='windows'?'/mnt/c/Program Files/nodejs/node.exe':process.execPath,[script,index+'-'+platform],{stdio:'inherit'});
  const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('exit',resolve);});
  if(code!==0)throw Error(platform+' browser probe exited '+code);
 }
 await writeFile(import.meta.dirname+'/paint-confirm-evidence.json',JSON.stringify(harness.evidence(),null,2));
}finally{await harness.close();}
''')
