import { createPreparedRenderProgram as __exactPreparedRenderProgram, prepareCompiledRenderProgram as __exactPrepareRenderProgram, createExpression as __exactExpression } from "@exactjs/core/runtime/render-operations";
import { readIndexedReactiveSlot as __exactReadState, writeIndexedReactiveValue as __exactWriteState } from "@exactjs/core/runtime/reactivity";
import { mapExactCompiledKeyedChildren as __exactMapKeyedChildren } from "@exactjs/core/runtime/lists";
import { applyCompiledProgramChild as __exactApplyProgramChild } from "@exactjs/dom/runtime/render-program";
import { createCompiledComponentReceipt as __exactComponentReceipt } from "@exactjs/core/runtime/component-operations";
import type { Component } from '@exactjs/core';
import { attachExactCompiledClientComponent as __exactAttachClientComponent_1, receiveExactClientComponentProps as __exactReceiveClientProps_1, disposeExactClientComponent as __exactDisposeClientComponent_1 } from "@exactjs/core/runtime/component-operations";
import { constructRenderComponentInstance as __exactConstructRenderComponent_1 } from "@exactjs/core/runtime/component-construction/render";
import { constructDurableComponentInstance as __exactConstructDurableComponent_1 } from "@exactjs/core/runtime/component-construction/durable";
const __exactComponentContract_1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
const __exact_component_updates_1 = { bindings: [[0, 1, 0]] as const, props: 1, apply: (__exactTargets: object[], __exactDirtyLow: number, __exactDirtyHigh: number) => {
        const __exactTarget0 = __exactTargets[0];
        if (__exactTarget0) {
            if ((__exactDirtyLow & 1) !== 0)
                __exactApplyProgramChild(__exactTarget0, 0);
        }
    } };
const __exact_render_program_1 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 2, id: "xc2eLG5KWOOUoRhXs57vWh5", namespace: "html", ssrRootStatic: ["", [], []], template: "<h2><!---->\uE000exact:0\uE001<!----></h2>", wire: [["h2", "html", 1, 1], [[3, 0, 0, true]], [[0, 0]]], directClaims: true, ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
        const __exactValue_0 = __exactSsr.prepareText(__exactInvocation, 0);
        if (__exactValue_0 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 1, 9, 9);
        let __exactCharacters = 9;
        __exactCharacters = __exactSsr.text(__exactContext, __exactOutput, __exactValue_0, "0", __exactCharacters, true, "<h2>", "</h2>");
        const __exactDrain = __exactOutput.sink.ready();
        if (__exactDrain)
            return __exactDrain.then(() => __exactOutput);
        return __exactOutput;
    } });
const __exact_render_program_2 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 2, id: "xriC3APGAXNDloth_HhlZOj", namespace: "html", ssrRootStatic: ["", [], []], template: "<p><!---->\uE000exact:0\uE001<!----></p>", wire: [["p", "html", 1, 1], [[3, 0, 0, true]], [[0, 0]]], directClaims: true, ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
        const __exactValue_0 = __exactSsr.prepareText(__exactInvocation, 0);
        if (__exactValue_0 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 1, 7, 7);
        let __exactCharacters = 7;
        __exactCharacters = __exactSsr.text(__exactContext, __exactOutput, __exactValue_0, "0", __exactCharacters, true, "<p>", "</p>");
        const __exactDrain = __exactOutput.sink.ready();
        if (__exactDrain)
            return __exactDrain.then(() => __exactOutput);
        return __exactOutput;
    } });
const __exact_render_program_3 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 2, id: "xbmWCCRhTetUChz9kJGye05", namespace: "html", ssrRootStatic: ["", [], []], template: "<div></div>", wire: [["div", "html", 1, 1], [[4, 0, 0]], [[3, 0]]], directClaims: true, keyedChildren: 1, ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame?: unknown[]): (typeof __exactOutput | undefined) | Promise<typeof __exactOutput | undefined> {
        let __exactValue_0: unknown, __exactCharacters: number, __exactStage = 0, __exactSettled: unknown, __exactPending;
        if (__exactFrame) {
            __exactValue_0 = __exactFrame[6] as unknown;
            __exactCharacters = __exactFrame[7] as number;
            __exactStage = __exactFrame[4] as number;
            __exactSettled = __exactFrame[5];
        }
        else {
            __exactValue_0 = __exactSsr.prepareChild(__exactInvocation, 0);
            if (__exactValue_0 === __exactSsr.unprepared)
                return;
            __exactSsr.begin(__exactContext, 1, 1, 11, 11);
            __exactCharacters = 11;
        }
        switch (__exactStage) {
            case 0: __exactSettled = __exactSsr.static(__exactOutput, "<div>");
            case 1:
                const __exactDrain_0 = __exactOutput.sink.ready();
                if (__exactDrain_0) {
                    __exactPending = __exactDrain_0;
                    __exactStage = 2;
                    break;
                }
            case 2:
                __exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_0);
                if (__exactSettled instanceof __exactSsr.promise) {
                    __exactPending = __exactSettled;
                    __exactStage = 3;
                    break;
                }
            case 3:
                const __exactDrain_1 = __exactOutput.sink.ready();
                if (__exactDrain_1) {
                    __exactPending = __exactDrain_1;
                    __exactStage = 4;
                    break;
                }
            case 4: __exactSettled = __exactSsr.static(__exactOutput, "</div>");
            case 5:
                const __exactDrain_2 = __exactOutput.sink.ready();
                if (__exactDrain_2) {
                    __exactPending = __exactDrain_2;
                    __exactStage = 6;
                    break;
                }
            case 6: return __exactOutput;
        }
        {
            const __exactSaved: unknown[] = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactCharacters];
            return (__exactPending!).then(__exactResult => {
                __exactSaved[5] = __exactResult;
                return __exactRun(__exactSaved[0] as typeof __exactSsr, __exactSaved[1] as typeof __exactContext, __exactSaved[2] as typeof __exactInvocation, __exactSaved[3] as typeof __exactOutput, __exactSaved);
            });
        }
    }, targetSlots: [0] });
const __exact_render_program_4 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 2, id: "xqzKZo_qlPQKNuTHhdEqxlQ", namespace: "html", ssrRootStatic: ["", [], []], template: "<p>empty</p>", root: ["p"], work: [1, 0], directClaims: true, ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
        __exactSsr.begin(__exactContext, 1, 0, 12, 12);
        let __exactCharacters = 12;
        __exactSsr.static(__exactOutput, "<p>empty</p>");
        const __exactDrain = __exactOutput.sink.ready();
        if (__exactDrain)
            return __exactDrain.then(() => __exactOutput);
        return __exactOutput;
    } });
const __exact_render_program_5 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 2, id: "x_hyl5TibrpVwhWdvRQiVx7", namespace: "html", ssrRootStatic: ["", [], []], template: "<section></section>", wire: [["section", "html", 1, 1], [[4, 0, 0]], [[1, 0, true], [7, 0, __exact_component_updates_1]]], directClaims: true, ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame?: unknown[]): (typeof __exactOutput | undefined) | Promise<typeof __exactOutput | undefined> {
        let __exactValue_0: unknown, __exactCharacters: number, __exactStage = 0, __exactSettled: unknown, __exactPending;
        if (__exactFrame) {
            __exactValue_0 = __exactFrame[6] as unknown;
            __exactCharacters = __exactFrame[7] as number;
            __exactStage = __exactFrame[4] as number;
            __exactSettled = __exactFrame[5];
        }
        else {
            __exactValue_0 = __exactSsr.prepareChild(__exactInvocation, 0);
            if (__exactValue_0 === __exactSsr.unprepared)
                return;
            __exactSsr.begin(__exactContext, 1, 1, 19, 19);
            __exactCharacters = 19;
        }
        switch (__exactStage) {
            case 0: __exactSettled = __exactSsr.static(__exactOutput, "<section>");
            case 1:
                const __exactDrain_0 = __exactOutput.sink.ready();
                if (__exactDrain_0) {
                    __exactPending = __exactDrain_0;
                    __exactStage = 2;
                    break;
                }
            case 2:
                __exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_0);
                if (__exactSettled instanceof __exactSsr.promise) {
                    __exactPending = __exactSettled;
                    __exactStage = 3;
                    break;
                }
            case 3:
                const __exactDrain_1 = __exactOutput.sink.ready();
                if (__exactDrain_1) {
                    __exactPending = __exactDrain_1;
                    __exactStage = 4;
                    break;
                }
            case 4: __exactSettled = __exactSsr.static(__exactOutput, "</section>");
            case 5:
                const __exactDrain_2 = __exactOutput.sink.ready();
                if (__exactDrain_2) {
                    __exactPending = __exactDrain_2;
                    __exactStage = 6;
                    break;
                }
            case 6: return __exactOutput;
        }
        {
            const __exactSaved: unknown[] = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactCharacters];
            return (__exactPending!).then(__exactResult => {
                __exactSaved[5] = __exactResult;
                return __exactRun(__exactSaved[0] as typeof __exactSsr, __exactSaved[1] as typeof __exactContext, __exactSaved[2] as typeof __exactInvocation, __exactSaved[3] as typeof __exactOutput, __exactSaved);
            });
        }
    }, targetSlots: [0] });
type Entry = {
    id: string;
    comments: {
        id: string;
        body: string;
    }[];
};
let owner: Component<{
    entries: Entry[];
}> | undefined;
const __exactImplementation_OptionalDetail_1 = function OptionalDetail(this: object, props: {
    entry?: Entry;
}) {
    return () => (__exactPreparedRenderProgram(__exact_render_program_5, [() => __exactReadState(props, 0) as Entry | undefined ? ([__exactPreparedRenderProgram(__exact_render_program_1, [() => (__exactReadState(props, 0) as Entry).id], this), __exactPreparedRenderProgram(__exact_render_program_3, [() => __exactMapKeyedChildren(this, (__exactReadState(props, 0) as Entry).comments, comment => comment.id, (comment) => (__exactPreparedRenderProgram(__exact_render_program_2, [() => comment.body], this)), "xALrSNOuRo_eFtNmG54oFG6", undefined, "member:id")], this)]) : (__exactPreparedRenderProgram(__exact_render_program_4, [], this))], this));
};
const OptionalDetail = /* @__PURE__ */ (() => Object.assign(__exactImplementation_OptionalDetail_1, {
    [Symbol.for("@exactjs/component")]: "xOCR1q6leTkfM1JZZufQ5_1",
    [__exactComponentContract_1]: {
        version: 2,
        placement: "isomorphic",
        role: "client",
        implementations: [
            { id: "xEL3l8lc-H1_di3SIN1uDf7", name: "OptionalDetail", role: "root", implementation: __exactImplementation_OptionalDetail_1 }
        ],
        continuations: [],
        executors: [],
        boundaries: [],
        artifact: {
            version: 2,
            target: "client",
            id: "xOCR1q6leTkfM1JZZufQ5_1",
            instantiate: __exactImplementation_OptionalDetail_1,
            construct: __exactConstructDurableComponent_1,
            abi: 5,
            capabilities: [],
            state: [],
            props: [
                "entry"
            ],
            serialization: [
                1,
                "entry",
                [
                    1,
                    "id",
                    0,
                    "comments",
                    [
                        2,
                        [
                            1,
                            "id",
                            0,
                            "body",
                            0
                        ]
                    ]
                ]
            ],
            attach: __exactAttachClientComponent_1,
            receive: __exactReceiveClientProps_1,
            dispose: __exactDisposeClientComponent_1,
            updates: __exact_component_updates_1,
            tasks: [],
            reactive: [
                {
                    name: "props",
                    provenance: "props",
                    allocation: "live-slot",
                    dependencies: []
                }
            ],
            render: "returned-function"
        },
        execution: {
            version: 1,
            ports: [],
            transitions: [],
            reactive: [
                {
                    name: "props",
                    provenance: "props",
                    allocation: "live-slot",
                    dependencies: []
                }
            ]
        }
    }
}) as typeof __exactImplementation_OptionalDetail_1)();
const __exactImplementation_OptionalDetailOwner_1 = function OptionalDetailOwner(this: Component<{
    entries: Entry[];
}>) {
    owner = this;
    __exactWriteState(this.state, 0, [{ id: 'selected', comments: [{ id: 'comment', body: 'ready' }] }]);
    ;
    return () => __exactComponentReceipt(OptionalDetail, { entry: __exactExpression(() => {
            const __exact_selected_1 = (__exactReadState(this.state, 0) as Entry[]).find((entry) => entry.id === 'selected');
            return __exact_selected_1;
        }) });
};
export const OptionalDetailOwner = /* @__PURE__ */ (() => Object.assign(__exactImplementation_OptionalDetailOwner_1, {
    [Symbol.for("@exactjs/component")]: "xMbAfy2IK0UbxPdjpql__DY",
    [__exactComponentContract_1]: {
        version: 2,
        placement: "isomorphic",
        role: "client",
        implementations: [
            { id: "xONKcaHgXjJeA57fDmga4_h", name: "OptionalDetailOwner", role: "root", implementation: __exactImplementation_OptionalDetailOwner_1 }
        ],
        continuations: [],
        executors: [],
        boundaries: [],
        artifact: {
            version: 2,
            target: "client",
            id: "xMbAfy2IK0UbxPdjpql__DY",
            instantiate: __exactImplementation_OptionalDetailOwner_1,
            construct: __exactConstructRenderComponent_1,
            abi: 1,
            capabilities: [
                "resumption"
            ],
            state: [
                "entries"
            ],
            props: [],
            attach: __exactAttachClientComponent_1,
            receive: __exactReceiveClientProps_1,
            dispose: __exactDisposeClientComponent_1,
            tasks: [],
            reactive: [
                {
                    name: "selected",
                    provenance: "derived",
                    allocation: "inline",
                    dependencies: []
                },
                {
                    name: "this",
                    provenance: "state",
                    allocation: "live-slot",
                    dependencies: []
                }
            ],
            render: "returned-function"
        },
        execution: {
            version: 1,
            ports: [],
            transitions: [],
            reactive: [
                {
                    name: "selected",
                    provenance: "derived",
                    allocation: "inline",
                    dependencies: []
                },
                {
                    name: "this",
                    provenance: "state",
                    allocation: "live-slot",
                    dependencies: []
                }
            ]
        },
        resumption: {
            componentId: "xMbAfy2IK0UbxPdjpql__DY",
            statePaths: [
                "entries"
            ],
            stateInputs: [],
            valueCaptures: [],
            contexts: [],
            boundaries: []
        }
    }
}) as typeof __exactImplementation_OptionalDetailOwner_1)();
/** Returns the inspectable owner of the optional-detail fixture. */
export function optionalDetailOwnerInstance() {
    if (!owner)
        throw new Error('Optional detail owner is not mounted');
    return owner;
}
