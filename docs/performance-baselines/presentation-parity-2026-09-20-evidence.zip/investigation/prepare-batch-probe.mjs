import {readFile,writeFile} from 'node:fs/promises';import {resolve} from 'node:path';import {pathToFileURL} from 'node:url';
let worker=await readFile('framework-comparison/src/ssr-benchmark-worker.mjs','utf8');
worker=worker.replaceAll(/from '(\.[^']+)'/g,(_,p)=>`from '${pathToFileURL(resolve('framework-comparison/src',p)).href}'`).replace("resolve(import.meta.dirname, '..')",JSON.stringify(resolve('framework-comparison')));
worker=worker.replace("? createBunRequestHandler : undefined", "? handler => createBunRequestHandler(handler, {maxBatchSize: Number(process.env.CONTROL_BATCH_SIZE || 32)}) : undefined");
await writeFile(import.meta.dirname+'/bun-batch-worker.mjs',worker);
