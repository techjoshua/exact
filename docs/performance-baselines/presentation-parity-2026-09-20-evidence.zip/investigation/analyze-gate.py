import json,collections,datetime,statistics
p='.tmp/fcp-bun-investigation-2026-09-20/bun-observed.json'
d=json.load(open(p))
for b in d['blocks']:
 if b['id']!='exact':continue
 trace=b['telemetry'][-1]['value']['admissionTrace']
 print('POP',b['population'])
 for i,s in enumerate(b['results'][0]['stages']):
  start=datetime.datetime.fromisoformat(s['startedAt'].replace('Z','+00:00')).timestamp()*1000
  ts=[x for x in trace if start<x['epochMs']<start+s['durationMs']]
  print(s['name'],'rps',round(sum(r['stages'][i]['validRps'] for r in b['results'])), 'phase',dict(collections.Counter((x['phase'],x['enabled']) for x in ts)))
  for enabled in [False,True]:
   xs=[x for x in ts if x['enabled']==enabled and x['phase'] not in ['settle']]
   if xs:print('enabled',enabled,'rate',round(statistics.mean((x['arrivals']-x['windowArrivals']+x['windowPending']-x['pending'])*1000/(x['at']-x['started']) for x in xs)), 'lag',round(statistics.mean(x['lag'] for x in xs),2))
