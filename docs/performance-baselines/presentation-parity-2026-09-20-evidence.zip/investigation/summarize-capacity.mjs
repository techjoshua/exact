import {readFile} from 'node:fs/promises';
import {summarizeSsrCapacityCapture} from '../../framework-comparison/src/ssr-capacity-report.mjs';
for(const path of process.argv.slice(2)){
 const report=JSON.parse(await readFile(path));
 if(!report.complete){console.log(path,'INCOMPLETE');continue;}
 const rows=summarizeSsrCapacityCapture(report);
 console.log(path);
 for(const c of [16,32,64,128]){
  const exact=rows.find(r=>r.name==='eXact'&&r.concurrency===c),react=rows.find(r=>r.name==='React'&&r.concurrency===c);
  console.log(c,JSON.stringify({exactRps:exact.rps,reactRps:react.rps,ratio:exact.rps/react.rps,exactP99:[exact.p99Min,exact.p99Max],reactP99:[react.p99Min,react.p99Max],errors:exact.requestErrors+react.requestErrors}));
 }
}
