#!/usr/bin/env bash
set -euo pipefail
while kill -0 90431 2>/dev/null; do sleep 2; done
source .tmp/wsl-benchmark-env.sh
CONTROL_BATCH_SIZE=32 NODE_ENV=production COMPARISON_SSR_RENDER_MODE=string CONTROL_EXACT_ENTRY=framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js CONTROL_WORKER_PATH=.tmp/fcp-bun-investigation-2026-09-20/bun-batch-worker.mjs node .tmp/node-string-investigation/transport-capacity.mjs .tmp/fcp-bun-investigation-2026-09-20/bun-plan.json .tmp/fcp-bun-investigation-2026-09-20/bun-batch32.json bun > .tmp/fcp-bun-investigation-2026-09-20/bun-batch32.log 2>&1
