from pathlib import Path
import os,subprocess,json
root=Path.cwd();out=root/'.tmp/fcp-bun-investigation-2026-09-20'
compiler=['jsx_component_updates.go','jsx_render_program_updates.go']
stage=root/'.tmp/native-typescript-go/tsc'
changes={stage/'internal/exactcompiler'/p:subprocess.check_output(['git','show','HEAD:native/typescript-go/overlay/internal/exactcompiler/'+p]) for p in compiler}
original={p:p.read_bytes() for p in changes}
try:
 for p,b in changes.items():p.write_bytes(b)
 with (out/'baseline-compiler-build.log').open('w') as log:
  subprocess.run(['go','build','-buildvcs=false','-trimpath','-o',str(out/'baseline-exactc'),'./cmd/exactc'],cwd=stage,stdout=log,stderr=subprocess.STDOUT,check=True)
finally:
 for p,b in original.items():p.write_bytes(b)
paths=subprocess.check_output(['git','diff','--name-only','--','packages/dom/src/renderer'],text=True).splitlines()
original={root/p:(root/p).read_bytes() for p in paths}
try:
 for p in paths:(root/p).write_bytes(subprocess.check_output(['git','show','HEAD:'+p]))
 env={**os.environ,'EXACT_COMPILER_EXECUTABLE':str(out/'baseline-exactc')}
 with (out/'baseline-compiler-dom-hydration.log').open('w') as log:
  result=subprocess.run(['node','node_modules/vitest/vitest.mjs','run','--config','vitest.packages.config.ts','--project','@exactjs/hydrate','packages/hydrate/src/bootstrap.test.ts'],env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/'baseline-verification.json').write_text(json.dumps({'compiler':'HEAD versions of both modified compiler implementation files','runtimeFiles':paths,'exitCode':result.returncode},indent=2))
finally:
 for p,b in original.items():p.write_bytes(b)
