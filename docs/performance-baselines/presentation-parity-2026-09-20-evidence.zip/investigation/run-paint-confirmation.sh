#!/usr/bin/env bash
set -euo pipefail
while [ ! -f .tmp/fcp-bun-investigation-2026-09-20/bun-batch32.json ] || ! python3 -c 'import json,sys;sys.exit(not json.load(open(".tmp/fcp-bun-investigation-2026-09-20/bun-batch32.json"))["complete"])'; do sleep 5; done
source .tmp/wsl-benchmark-env.sh
node .tmp/fcp-bun-investigation-2026-09-20/paint-confirm-owner.mjs > .tmp/fcp-bun-investigation-2026-09-20/paint-confirm.log 2>&1
