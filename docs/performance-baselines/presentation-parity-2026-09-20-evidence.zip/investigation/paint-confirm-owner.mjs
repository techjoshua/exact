import {spawn,execFileSync} from 'node:child_process';
import {startClientBenchmarkHarness} from '../../framework-comparison/src/client-benchmark-harness.mjs';
import {writeFile} from 'node:fs/promises';
const participants=['exact','react','sveltekit','nuxt','tanstack-start'].map((id,i)=>({id:id+'-controlled',directory:id,artifact:['dist','dist','build/client','.output/public','.output/public'][i],url:'http://127.0.0.1:'+(4401+i)}));
const harness=await startClientBenchmarkHarness(participants);
try {
 for(const p of participants)await writeFile(import.meta.dirname+'/page-'+p.directory+'.html',await (await fetch(p.url+'/incidents/inc-100')).text());
 for(const [index,platform] of ['linux','windows','windows','linux'].entries()) {
  const path=import.meta.dirname+'/paint-confirm-client.mjs';
  const script=platform==='windows'?execFileSync('wslpath',['-w',path],{encoding:'utf8'}).trim():path;
  console.log('POPULATION',index,platform);
  const child=spawn(platform==='windows'?'/mnt/c/Program Files/nodejs/node.exe':process.execPath,[script,index+'-'+platform],{stdio:'inherit'});
  const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('exit',resolve);});
  if(code!==0)throw Error(platform+' browser probe exited '+code);
 }
 await writeFile(import.meta.dirname+'/paint-confirm-evidence.json',JSON.stringify(harness.evidence(),null,2));
}finally{await harness.close();}
