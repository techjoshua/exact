import {chromium} from 'playwright';
import {startClientBenchmarkHarness} from '../../framework-comparison/src/client-benchmark-harness.mjs';
const harness=await startClientBenchmarkHarness([{id:'exact-controlled',directory:'exact',artifact:'dist',url:'http://127.0.0.1:4401'}]);let browser;
try {
 browser=await chromium.launch(); const page=await browser.newPage();page.on('console',msg=>console.log(msg.type(),msg.text()));page.on('pageerror',e=>console.log('PAGEERROR',e));
 await page.goto('http://127.0.0.1:4401/incidents/inc-100');await page.locator('.connection').filter({hasText:'Live service'}).waitFor();
 if(process.argv.includes('select')){await page.getByRole('button',{name:/Delayed fulfillment events/}).click();await page.getByRole('heading',{name:'Delayed fulfillment events'}).waitFor();}
 await fetch('http://127.0.0.1:4310/__benchmark/reset',{method:'POST',headers:{'content-type':'application/json','x-benchmark-control':'fixture-reset'},body:'{"empty":true}'});
 await page.getByRole('button',{name:'Refresh',exact:true}).click();await page.waitForTimeout(500); console.log(await page.locator('body').innerText());
}finally{try{await browser?.close();}finally{await harness.close();}}
