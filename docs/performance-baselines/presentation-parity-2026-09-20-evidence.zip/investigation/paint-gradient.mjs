import {writeFile} from 'node:fs/promises';
import {chromium} from 'playwright';
import {startClientBenchmarkHarness} from '../../framework-comparison/src/client-benchmark-harness.mjs';
import {waitForFirstContentfulPaint} from '../../framework-comparison/src/paint-timing.mjs';
const participants=['exact','react','sveltekit'].map((id,i)=>({id:id+'-controlled',directory:id,artifact:i===2?'build/client':'dist',url:'http://127.0.0.1:'+(4401+i)}));
const harness=await startClientBenchmarkHarness(participants);let browser;const samples=[];
const stripScripts=html=>html.replace(/<script\b([^>]*)>[\s\S]*?<\/script>/gi,(tag,attributes)=>/\btype\s*=\s*["'](?:application\/(?:ld\+)?json|application\/x-exact[^"']*)["']/i.test(attributes)?tag:'');
try {
 const pages=new Map();for(const p of participants)pages.set(p.id,await(await fetch(p.url+'/incidents/inc-100')).text());
 browser=await chromium.launch();
 for(let round=0;round<21;round++)for(const p of round%2?[...participants].reverse():participants)for(const variant of round%2?['no-js-no-gradient','no-gradient','no-js','original']:['original','no-js','no-gradient','no-js-no-gradient']){
  await fetch('http://127.0.0.1:4310/__benchmark/reset',{method:'POST',headers:{'content-type':'application/json','x-benchmark-control':'fixture-reset'},body:'{}'});
  const context=await browser.newContext();
  try{
   const page=await context.newPage(),cdp=await context.newCDPSession(page);
   let html=pages.get(p.id);if(variant.includes('no-js'))html=stripScripts(html);
   if(variant.includes('no-gradient'))html=html.replace('</head>','<style>.app-shell{background:#e8ede9!important}</style></head>');
   await page.route(p.url+'/incidents/inc-100',route=>route.fulfill({status:200,contentType:'text/html; charset=utf-8',body:html}));
   await cdp.send('Network.enable');await cdp.send('Network.setCacheDisabled',{cacheDisabled:true});await cdp.send('Performance.enable');
   await page.goto(p.url+'/incidents/inc-100',{waitUntil:'domcontentloaded'});
   await page.getByRole('heading',{name:'Checkout authorization failures',exact:true}).waitFor();
   const fcp=await page.evaluate(waitForFirstContentfulPaint);
   const navigation=await page.evaluate(()=>performance.getEntriesByType('navigation')[0].toJSON());
   const {metrics}=await cdp.send('Performance.getMetrics');
   samples.push({round,participant:p.id,variant,fcp,navigation,metrics});
   console.log('sample',round,p.id,variant,fcp);
  }finally{await context.close();}
 }
 await writeFile(import.meta.dirname+'/paint-gradient.json',JSON.stringify({note:'Diagnostic document/script/font substitutions, not production performance claims',browserVersion:browser.version(),platform:process.platform,evidence:harness.evidence(),samples},null,2));
 for(const p of participants)for(const variant of ['original','no-js','no-gradient','no-js-no-gradient']){const xs=samples.filter(s=>s.round>0&&s.participant===p.id&&s.variant===variant).map(s=>s.fcp).sort((a,b)=>a-b);console.log(p.id,variant,{mean:xs.reduce((a,b)=>a+b,0)/xs.length,p50:xs[Math.ceil(xs.length/2)-1]});}
}finally{try{await browser?.close();}finally{await harness.close();}}
