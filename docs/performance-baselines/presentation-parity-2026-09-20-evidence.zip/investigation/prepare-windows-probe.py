from pathlib import Path
root=Path('.tmp/fcp-bun-investigation-2026-09-20')
s=(root/'paint-probe.mjs').read_text()
s=s.replace("import {startClientBenchmarkHarness} from '../../framework-comparison/src/client-benchmark-harness.mjs';",'')
s=s.replace('const harness=await startClientBenchmarkHarness(participants);let browser;const samples=[];','let browser;const samples=[];')
s=s.replace("'/paint-probe.json'","'/paint-probe-windows.json'")
s=s.replace('evidence:harness.evidence(),','')
s=s.replace('}finally{try{await browser?.close();}finally{await harness.close();}}','}finally{await browser?.close();}')
(root/'paint-probe-windows-client.mjs').write_text(s)
(root/'paint-probe-windows-owner.mjs').write_text('''import {spawn,execFileSync} from 'node:child_process';
import {startClientBenchmarkHarness} from '../../framework-comparison/src/client-benchmark-harness.mjs';
import {writeFile} from 'node:fs/promises';
const participants=['exact','react'].map((id,i)=>({id:id+'-controlled',directory:id,artifact:'dist',url:'http://127.0.0.1:'+(4401+i)}));
const harness=await startClientBenchmarkHarness(participants);
try {
 const script=execFileSync('wslpath',['-w',import.meta.dirname+'/paint-probe-windows-client.mjs'],{encoding:'utf8'}).trim();
 const child=spawn('/mnt/c/Program Files/nodejs/node.exe',[script],{stdio:'inherit'});
 const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('exit',resolve);});
 if(code!==0)throw Error('Windows browser probe exited '+code);
 await writeFile(import.meta.dirname+'/paint-probe-windows-evidence.json',JSON.stringify(harness.evidence(),null,2));
}finally{await harness.close();}
''')
