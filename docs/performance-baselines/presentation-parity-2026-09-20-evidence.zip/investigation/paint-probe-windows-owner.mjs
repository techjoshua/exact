import {spawn,execFileSync} from 'node:child_process';
import {startClientBenchmarkHarness} from '../../framework-comparison/src/client-benchmark-harness.mjs';
import {writeFile} from 'node:fs/promises';
const participants=['exact','react'].map((id,i)=>({id:id+'-controlled',directory:id,artifact:'dist',url:'http://127.0.0.1:'+(4401+i)}));
const harness=await startClientBenchmarkHarness(participants);
try {
 const script=execFileSync('wslpath',['-w',import.meta.dirname+'/paint-probe-windows-client.mjs'],{encoding:'utf8'}).trim();
 const child=spawn('/mnt/c/Program Files/nodejs/node.exe',[script],{stdio:'inherit'});
 const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('exit',resolve);});
 if(code!==0)throw Error('Windows browser probe exited '+code);
 await writeFile(import.meta.dirname+'/paint-probe-windows-evidence.json',JSON.stringify(harness.evidence(),null,2));
}finally{await harness.close();}
