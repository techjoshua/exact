import {readFileSync,writeFileSync} from 'node:fs';
import {createCompilerSession, transformSource} from '@exactjs/compiler';
const session=createCompilerSession();
try {const filename=process.cwd()+'/'+(process.argv[2] ?? 'packages/dom/src/test-support/components/optional-detail.fixtures.tsx');const result=transformSource(readFileSync(filename,'utf8'),{filename,session,compileTestModules:true});writeFileSync(process.argv[3] ?? '.tmp/fcp-bun-investigation-2026-09-20/optional-detail.compiled.ts',result.code);} finally {session.dispose();}
