from pathlib import Path
root=Path('framework-comparison');p=root/'presentation';p.mkdir(exist_ok=True)
(p/'incident-workspace.css').write_text((root/'participants/exact/src/styles.css').read_text())
replacements={
 'participants/exact/src/main.tsx':("import './styles.css';","import '../../../presentation/incident-workspace.css';"),
 'participants/react/src/main.tsx':("import './styles.css';","import '../../../presentation/incident-workspace.css';"),
 'participants/sveltekit/src/routes/+layout.svelte':("import './styles.css';","import '../../../../presentation/incident-workspace.css';"),
 'participants/tanstack-start/src/routes/__root.tsx':("import '../styles.css';","import '../../../../presentation/incident-workspace.css';"),
 'participants/exact-native/src/client.ts':("import '../../exact/src/styles.css';","import '../../../presentation/incident-workspace.css';"),
 'participants/react-native/app/root.tsx':("import sharedStyles from '../../react/src/styles.css?url';","import sharedStyles from '../../../presentation/incident-workspace.css?url';"),
 'participants/nuxt/nuxt.config.ts':("css: ['~/styles.css'],","css: [fileURLToPath(new URL('../../presentation/incident-workspace.css', import.meta.url))],"),
}
for f,(old,new) in replacements.items():
 path=root/f;s=path.read_text();assert old in s,f;path.write_text(s.replace(old,new))
p=root/'participants/nuxt/nuxt.config.ts';p.write_text("import { fileURLToPath } from 'node:url';\n\n"+p.read_text())
for f in ['exact/src/styles.css','react/src/styles.css','sveltekit/src/routes/styles.css','nuxt/app/styles.css','tanstack-start/src/styles.css']:(root/'participants'/f).unlink()
p=root/'participants/sveltekit/src/app.html';s=p.read_text().replace('<head>','<head>\n\t\t<meta charset="UTF-8" />\n\t\t<meta name="viewport" content="width=device-width, initial-scale=1.0" />');p.write_text(s)
for f in ['participants/sveltekit/src/routes/+layout.svelte','participants/nuxt/nuxt.config.ts','participants/tanstack-start/src/routes/__root.tsx','participants/exact/index.html','participants/react/index.html']:
 p=root/f;s=p.read_text();import re;s=re.sub(r'Signal Desk · (?:SvelteKit|Nuxt|TanStack Start|eXact|React)', 'Incident Operations',s);p.write_text(s)
