import { createPreparedRenderProgram as __exactPreparedRenderProgram, prepareCompiledRenderProgram as __exactPrepareRenderProgram, createCompiledChildRangeReceipt as __exactDynamic } from "@exactjs/core/runtime/render-operations";
import { compiledReactivePropertyOperand as __exactPropertyOperand, readIndexedReactiveSlot as __exactReadState, writeIndexedReactiveValue as __exactWriteState } from "@exactjs/core/runtime/reactivity";
import "@exactjs/core/runtime/tasks";
import { mapExactCompiledKeyedChildren as __exactMapKeyedChildren } from "@exactjs/core/runtime/lists";
import { applyCompiledProgramText as __exactApplyProgramText, applyCompiledProgramChild as __exactApplyProgramChild, applyCompiledProgramProperties as __exactApplyProgramProperties } from "@exactjs/dom/runtime/render-program";
import { registerComponentLifecycleHandler as __exactRegisterLifecycle } from "@exactjs/core/framework/component-lifecycle";
import { createCompiledComponentReceipt as __exactComponentReceipt } from "@exactjs/core/runtime/component-operations";
import { peek, type Component } from '@exactjs/core';
import { SeverityBadge } from './IncidentQueue.jsx';
import { subscribeLiveService } from './live-service.js';
import { claimIncident, requestAnalysis, submitComment } from './service-client.js';
import type { AnalysisJob, Incident, User } from './types.js';
import { attachExactCompiledClientComponent as __exactAttachClientComponent_1, receiveExactClientComponentProps as __exactReceiveClientProps_1, disposeExactClientComponent as __exactDisposeClientComponent_1 } from "@exactjs/core/runtime/component-operations";
import { constructDurableComponentInstance as __exactConstructDurableComponent_1 } from "@exactjs/core/runtime/component-construction/durable";
const __exactComponentContract_1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
const __exact_component_updates_1 = { bindings: [[0, 24, 0], [0, 4, 0], [1, 1, 0], [3, 2, 0]] as const, props: 1, apply: (__exactTargets: object[], __exactDirtyLow: number, __exactDirtyHigh: number) => {
        const __exactTarget0 = __exactTargets[0];
        if (__exactTarget0) {
            if ((__exactDirtyLow & 1) !== 0)
                __exactApplyProgramText(__exactTarget0, 0, 0, 1);
        }
        const __exactTarget1 = __exactTargets[1];
        if (__exactTarget1) {
            if ((__exactDirtyLow & 2) !== 0)
                __exactApplyProgramText(__exactTarget1, 0, 0, 3);
        }
        const __exactTarget2 = __exactTargets[2];
        if (__exactTarget2) {
            if ((__exactDirtyLow & 4) !== 0)
                __exactApplyProgramProperties(__exactTarget2, 0, 2);
        }
        const __exactTarget3 = __exactTargets[3];
        if (__exactTarget3) {
            if ((__exactDirtyLow & 8) !== 0)
                __exactApplyProgramChild(__exactTarget3, 0);
        }
        const __exactTarget4 = __exactTargets[4];
        if (__exactTarget4) {
            if ((__exactDirtyLow & 16) !== 0)
                __exactApplyProgramChild(__exactTarget4, 0);
        }
    } };
const __exact_render_program_1 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 2, id: "xGn9yDMZByLcAkQszHhw73F", namespace: "html", ssrRootStatic: [" class=\"detail-heading\"", ["className"], []], template: "<div class=\"detail-heading\"><div><h2><!---->\uE000exact:1\uE001<!----></h2></div><span class=\"version\"><!---->\uE000exact:2\uE001<!----></span></div>", wire: [["div", "html", 4, 3], [[0, 1, 0, "div"], [1, 1], [6, 2, 131074, "h2"], [4, 0, 0, true, 2], [0, 2, 0, "h2"], [1, 2], [3, 1, 0, true], [2], [2], [0, 3, 0, "span"], [1, 3], [3, 2, 0, true], [2]], [[2, 0, [[0]], 1], [0, 1], [11, 2, ["Version ", ""]]]], directClaims: true, ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame?: unknown[]): (typeof __exactOutput | undefined) | Promise<typeof __exactOutput | undefined> {
        let __exactValue_0: unknown, __exactValue_1: unknown, __exactValue_2: unknown, __exactCharacters: number, __exactStage = 0, __exactSettled: unknown, __exactPending;
        if (__exactFrame) {
            __exactValue_0 = __exactFrame[6] as unknown;
            __exactValue_1 = __exactFrame[7] as unknown;
            __exactValue_2 = __exactFrame[8] as unknown;
            __exactCharacters = __exactFrame[9] as number;
            __exactStage = __exactFrame[4] as number;
            __exactSettled = __exactFrame[5];
        }
        else {
            __exactValue_0 = __exactSsr.prepareComponent(__exactInvocation, 0);
            if (__exactValue_0 === __exactSsr.unprepared)
                return;
            __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
            if (__exactValue_1 === __exactSsr.unprepared)
                return;
            __exactValue_2 = __exactSsr.prepareText(__exactInvocation, 2);
            if (__exactValue_2 === __exactSsr.unprepared)
                return;
            if (__exactOutput.prepareReferences)
                __exactOutput.preparation = __exactOutput.prepareReferences([__exactValue_0]);
            __exactSsr.begin(__exactContext, 4, 3, 91, 91);
            __exactCharacters = 91;
        }
        switch (__exactStage) {
            case 0: __exactSettled = __exactSsr.static(__exactOutput, "<div class=\"detail-heading\"><div>");
            case 1:
                const __exactDrain_0 = __exactOutput.sink.ready();
                if (__exactDrain_0) {
                    __exactPending = __exactDrain_0;
                    __exactStage = 2;
                    break;
                }
            case 2:
                __exactSettled = __exactSsr.component(__exactContext, __exactOutput, __exactValue_0, "0", __exactCharacters, true);
                if (__exactSettled instanceof __exactSsr.promise) {
                    __exactPending = __exactSettled;
                    __exactStage = 3;
                    break;
                }
            case 3:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_1 = __exactOutput.sink.ready();
                if (__exactDrain_1) {
                    __exactPending = __exactDrain_1;
                    __exactStage = 4;
                    break;
                }
            case 4: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "1", __exactCharacters, true, "<h2>", "</h2></div><span class=\"version\">");
            case 5:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_2 = __exactOutput.sink.ready();
                if (__exactDrain_2) {
                    __exactPending = __exactDrain_2;
                    __exactStage = 6;
                    break;
                }
            case 6: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_2, "2", __exactCharacters, true, "Version ", "</span></div>");
            case 7:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_3 = __exactOutput.sink.ready();
                if (__exactDrain_3) {
                    __exactPending = __exactDrain_3;
                    __exactStage = 8;
                    break;
                }
            case 8: return __exactOutput;
        }
        {
            const __exactSaved: unknown[] = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactValue_2, __exactCharacters];
            return (__exactPending!).then(__exactResult => {
                __exactSaved[5] = __exactResult;
                return __exactRun(__exactSaved[0] as typeof __exactSsr, __exactSaved[1] as typeof __exactContext, __exactSaved[2] as typeof __exactInvocation, __exactSaved[3] as typeof __exactOutput, __exactSaved);
            });
        }
    }, targetSlots: [0] });
const __exact_render_program_2 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 2, id: "xGoOzEstYGnlEqUeszguUUG", namespace: "html", ssrRootStatic: [" class=\"facts\"", ["className"], []], template: "<div class=\"facts\"><div><span>Owner</span><strong><!---->\uE000exact:0\uE001<!----></strong></div><div><span>Status</span><strong><!---->\uE000exact:1\uE001<!----></strong></div></div>", wire: [["div", "html", 7, 2], [[0, 1, 0, "div"], [1, 1], [0, 3, 1, "strong"], [1, 3], [3, 0, 0, true], [2], [2], [0, 4, 0, "div"], [1, 4], [0, 6, 1, "strong"], [1, 6], [3, 1, 0, true], [2], [2]], [[0, 0], [0, 1]]], directClaims: true, ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame?: unknown[]): (typeof __exactOutput | undefined) | Promise<typeof __exactOutput | undefined> {
        let __exactValue_0: unknown, __exactValue_1: unknown, __exactCharacters: number, __exactStage = 0, __exactSettled: unknown, __exactPending;
        if (__exactFrame) {
            __exactValue_0 = __exactFrame[6] as unknown;
            __exactValue_1 = __exactFrame[7] as unknown;
            __exactCharacters = __exactFrame[8] as number;
            __exactStage = __exactFrame[4] as number;
            __exactSettled = __exactFrame[5];
        }
        else {
            __exactValue_0 = __exactSsr.prepareText(__exactInvocation, 0);
            if (__exactValue_0 === __exactSsr.unprepared)
                return;
            __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
            if (__exactValue_1 === __exactSsr.unprepared)
                return;
            __exactSsr.begin(__exactContext, 7, 2, 118, 118);
            __exactCharacters = 118;
        }
        switch (__exactStage) {
            case 0: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_0, "0", __exactCharacters, true, "<div class=\"facts\"><div><span>Owner</span><strong>", "</strong></div><div><span>Status</span><strong>");
            case 1:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_0 = __exactOutput.sink.ready();
                if (__exactDrain_0) {
                    __exactPending = __exactDrain_0;
                    __exactStage = 2;
                    break;
                }
            case 2: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "1", __exactCharacters, true, "", "</strong></div></div>");
            case 3:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_1 = __exactOutput.sink.ready();
                if (__exactDrain_1) {
                    __exactPending = __exactDrain_1;
                    __exactStage = 4;
                    break;
                }
            case 4: return __exactOutput;
        }
        {
            const __exactSaved: unknown[] = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactCharacters];
            return (__exactPending!).then(__exactResult => {
                __exactSaved[5] = __exactResult;
                return __exactRun(__exactSaved[0] as typeof __exactSsr, __exactSaved[1] as typeof __exactContext, __exactSaved[2] as typeof __exactInvocation, __exactSaved[3] as typeof __exactOutput, __exactSaved);
            });
        }
    } });
const __exact_render_program_3 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 2, id: "xR_nsA8G9g5QkLTvDkssOag", namespace: "html", ssrRootStatic: [" class=\"alert\" role=\"alert\"", ["className", "role"], []], template: "<p class=\"alert\" role=\"alert\"><!---->\uE000exact:0\uE001<!----></p>", wire: [["p", "html", 1, 1], [[3, 0, 0, true]], [[0, 0, [0, 1], true], [9, 0, __exact_component_updates_1]]], directClaims: true, ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
        const __exactValue_0 = __exactSsr.prepareText(__exactInvocation, 0);
        if (__exactValue_0 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 1, 34, 34);
        let __exactCharacters = 34;
        __exactCharacters = __exactSsr.text(__exactContext, __exactOutput, __exactValue_0, "0", __exactCharacters, true, "<p class=\"alert\" role=\"alert\">", "</p>");
        const __exactDrain = __exactOutput.sink.ready();
        if (__exactDrain)
            return __exactDrain.then(() => __exactOutput);
        return __exactOutput;
    } });
const __exact_render_program_4 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 2, id: "xII-QrjF90NFixbndGlKNmL", namespace: "html", ssrRootStatic: [" class=\"alert\" role=\"alert\"", ["className", "role"], []], template: "<p class=\"alert\" role=\"alert\"><!---->\uE000exact:0\uE001<!----></p>", wire: [["p", "html", 1, 1], [[3, 0, 0, true]], [[0, 0, [0, 3], true], [9, 1, __exact_component_updates_1]]], directClaims: true, ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
        const __exactValue_0 = __exactSsr.prepareText(__exactInvocation, 0);
        if (__exactValue_0 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 1, 34, 34);
        let __exactCharacters = 34;
        __exactCharacters = __exactSsr.text(__exactContext, __exactOutput, __exactValue_0, "0", __exactCharacters, true, "<p class=\"alert\" role=\"alert\">", "</p>");
        const __exactDrain = __exactOutput.sink.ready();
        if (__exactDrain)
            return __exactDrain.then(() => __exactOutput);
        return __exactOutput;
    } });
const __exact_render_program_5 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 2, id: "x0fg8wh83aPSirY8CRuZhqv", namespace: "html", ssrRootStatic: [" type=\"button\" class=\"primary\"", ["type", "className"], []], template: "<button type=\"button\" class=\"primary\">Claim incident</button>", wire: [["button", "html", 1, 1], [[7, 0, 0]], [[5, 0, 0]]], directClaims: true, ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame?: unknown[]): (typeof __exactOutput | undefined) | Promise<typeof __exactOutput | undefined> {
        let __exactValue_0: unknown, __exactCharacters: number, __exactStage = 0, __exactSettled: unknown, __exactPending;
        if (__exactFrame) {
            __exactValue_0 = __exactFrame[6] as unknown;
            __exactCharacters = __exactFrame[7] as number;
            __exactStage = __exactFrame[4] as number;
            __exactSettled = __exactFrame[5];
        }
        else {
            __exactValue_0 = __exactSsr.prepareAttribute(__exactInvocation, 0);
            if (__exactValue_0 === __exactSsr.unprepared)
                return;
            __exactSsr.begin(__exactContext, 1, 1, 61, 61);
            __exactCharacters = 61;
        }
        switch (__exactStage) {
            case 0: __exactSettled = __exactSsr.static(__exactOutput, "<button type=\"button\" class=\"primary\"");
            case 1:
                const __exactDrain_0 = __exactOutput.sink.ready();
                if (__exactDrain_0) {
                    __exactPending = __exactDrain_0;
                    __exactStage = 2;
                    break;
                }
            case 2: __exactSettled = __exactSsr.compiledAttribute(__exactContext, __exactOutput, __exactValue_0, 0, "__exactClosedInteraction:onClick", "__exactClosedInteraction:onClick", "button", __exactCharacters);
            case 3:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_1 = __exactOutput.sink.ready();
                if (__exactDrain_1) {
                    __exactPending = __exactDrain_1;
                    __exactStage = 4;
                    break;
                }
            case 4: __exactSettled = __exactSsr.static(__exactOutput, ">Claim incident</button>");
            case 5:
                const __exactDrain_2 = __exactOutput.sink.ready();
                if (__exactDrain_2) {
                    __exactPending = __exactDrain_2;
                    __exactStage = 6;
                    break;
                }
            case 6: return __exactOutput;
        }
        {
            const __exactSaved: unknown[] = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactCharacters];
            return (__exactPending!).then(__exactResult => {
                __exactSaved[5] = __exactResult;
                return __exactRun(__exactSaved[0] as typeof __exactSsr, __exactSaved[1] as typeof __exactContext, __exactSaved[2] as typeof __exactInvocation, __exactSaved[3] as typeof __exactOutput, __exactSaved);
            });
        }
    } });
const __exact_render_program_6 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 2, id: "xSyX9yz6saYjNvlddpw2QRx", namespace: "html", ssrRootStatic: ["", [], []], template: "<strong><!---->\uE000exact:0\uE001<!----></strong>", wire: [["strong", "html", 1, 1], [[3, 0, 0, true]], [[0, 0]]], directClaims: true, ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
        const __exactValue_0 = __exactSsr.prepareText(__exactInvocation, 0);
        if (__exactValue_0 === __exactSsr.unprepared)
            return;
        __exactSsr.begin(__exactContext, 1, 1, 17, 17);
        let __exactCharacters = 17;
        __exactCharacters = __exactSsr.text(__exactContext, __exactOutput, __exactValue_0, "0", __exactCharacters, true, "<strong>", "</strong>");
        const __exactDrain = __exactOutput.sink.ready();
        if (__exactDrain)
            return __exactDrain.then(() => __exactOutput);
        return __exactOutput;
    } });
const __exact_render_program_7 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 2, id: "xGe3aQxoCh1SOPPjW3lbm4t", namespace: "html", ssrRootStatic: [" class=\"analysis-card\"", ["className"], []], template: "<section class=\"analysis-card\"><div><h3>Server analysis</h3><p role=\"status\"><!---->\uE000exact:0\uE001<!----></p></div><button type=\"button\" class=\"quiet\">Start analysis</button></section>", wire: [["section", "html", 5, 4], [[0, 1, 0, "div"], [1, 1], [0, 3, 1, "p"], [1, 3], [3, 0, 0, true], [2], [4, 1, 0], [2], [6, 4, 17, "button"], [7, 2, 4]], [[0, 0], [1, 1], [12, 0, 2, [["disabled", 0, 0]], true], [9, 2, __exact_component_updates_1]]], directClaims: true, ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame?: unknown[]): (typeof __exactOutput | undefined) | Promise<typeof __exactOutput | undefined> {
        let __exactValue_0: unknown, __exactValue_1: unknown, __exactValue_2: unknown, __exactValue_3: unknown, __exactCharacters: number, __exactStage = 0, __exactSettled: unknown, __exactPending;
        if (__exactFrame) {
            __exactValue_0 = __exactFrame[6] as unknown;
            __exactValue_1 = __exactFrame[7] as unknown;
            __exactValue_2 = __exactFrame[8] as unknown;
            __exactValue_3 = __exactFrame[9] as unknown;
            __exactCharacters = __exactFrame[10] as number;
            __exactStage = __exactFrame[4] as number;
            __exactSettled = __exactFrame[5];
        }
        else {
            __exactValue_0 = __exactSsr.prepareText(__exactInvocation, 0);
            if (__exactValue_0 === __exactSsr.unprepared)
                return;
            __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
            if (__exactValue_1 === __exactSsr.unprepared)
                return;
            __exactValue_2 = __exactSsr.prepareAttribute(__exactInvocation, 2);
            if (__exactValue_2 === __exactSsr.unprepared)
                return;
            __exactValue_3 = __exactSsr.prepareAttribute(__exactInvocation, 3);
            if (__exactValue_3 === __exactSsr.unprepared)
                return;
            __exactSsr.begin(__exactContext, 5, 4, 156, 156);
            __exactCharacters = 156;
        }
        switch (__exactStage) {
            case 0: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_0, "0", __exactCharacters, true, "<section class=\"analysis-card\"><div><h3>Server analysis</h3><p role=\"status\">", "</p>");
            case 1:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_0 = __exactOutput.sink.ready();
                if (__exactDrain_0) {
                    __exactPending = __exactDrain_0;
                    __exactStage = 2;
                    break;
                }
            case 2:
                __exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_1);
                if (__exactSettled instanceof __exactSsr.promise) {
                    __exactPending = __exactSettled;
                    __exactStage = 3;
                    break;
                }
            case 3:
                const __exactDrain_1 = __exactOutput.sink.ready();
                if (__exactDrain_1) {
                    __exactPending = __exactDrain_1;
                    __exactStage = 4;
                    break;
                }
            case 4: __exactSettled = __exactSsr.static(__exactOutput, "</div><button type=\"button\" class=\"quiet\"");
            case 5:
                const __exactDrain_2 = __exactOutput.sink.ready();
                if (__exactDrain_2) {
                    __exactPending = __exactDrain_2;
                    __exactStage = 6;
                    break;
                }
            case 6: __exactSettled = __exactSsr.compiledAttribute(__exactContext, __exactOutput, __exactValue_2, 0, "disabled", "disabled", "button", __exactCharacters);
            case 7:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_3 = __exactOutput.sink.ready();
                if (__exactDrain_3) {
                    __exactPending = __exactDrain_3;
                    __exactStage = 8;
                    break;
                }
            case 8: __exactSettled = __exactSsr.compiledAttribute(__exactContext, __exactOutput, __exactValue_3, 0, "__exactClosedInteraction:onClick", "__exactClosedInteraction:onClick", "button", __exactCharacters);
            case 9:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_4 = __exactOutput.sink.ready();
                if (__exactDrain_4) {
                    __exactPending = __exactDrain_4;
                    __exactStage = 10;
                    break;
                }
            case 10: __exactSettled = __exactSsr.static(__exactOutput, ">Start analysis</button></section>");
            case 11:
                const __exactDrain_5 = __exactOutput.sink.ready();
                if (__exactDrain_5) {
                    __exactPending = __exactDrain_5;
                    __exactStage = 12;
                    break;
                }
            case 12: return __exactOutput;
        }
        {
            const __exactSaved: unknown[] = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactValue_2, __exactValue_3, __exactCharacters];
            return (__exactPending!).then(__exactResult => {
                __exactSaved[5] = __exactResult;
                return __exactRun(__exactSaved[0] as typeof __exactSsr, __exactSaved[1] as typeof __exactContext, __exactSaved[2] as typeof __exactInvocation, __exactSaved[3] as typeof __exactOutput, __exactSaved);
            });
        }
    }, targetSlots: [1] });
const __exact_render_program_8 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 2, id: "xaj_rhxatb7hP9vTVlAUhLx", namespace: "html", ssrRootStatic: [" class=\"empty\"", ["className"], []], template: "<p class=\"empty\">No comments yet.</p>", root: ["p"], work: [1, 0], directClaims: true, ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
        __exactSsr.begin(__exactContext, 1, 0, 37, 37);
        let __exactCharacters = 37;
        __exactSsr.static(__exactOutput, "<p class=\"empty\">No comments yet.</p>");
        const __exactDrain = __exactOutput.sink.ready();
        if (__exactDrain)
            return __exactDrain.then(() => __exactOutput);
        return __exactOutput;
    } });
const __exact_render_program_9 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 2, id: "xCddtsRpoqg03a8u6gE8m22", namespace: "html", ssrRootStatic: ["", [], []], template: "<article><strong><!---->\uE000exact:0\uE001<!----></strong><p><!---->\uE000exact:1\uE001<!----></p></article>", wire: [["article", "html", 3, 2], [[0, 1, 0, "strong"], [1, 1], [3, 0, 0, true], [2], [0, 2, 0, "p"], [1, 2], [3, 1, 0, true], [2]], [[0, 0], [0, 1]]], directClaims: true, ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame?: unknown[]): (typeof __exactOutput | undefined) | Promise<typeof __exactOutput | undefined> {
        let __exactValue_0: unknown, __exactValue_1: unknown, __exactCharacters: number, __exactStage = 0, __exactSettled: unknown, __exactPending;
        if (__exactFrame) {
            __exactValue_0 = __exactFrame[6] as unknown;
            __exactValue_1 = __exactFrame[7] as unknown;
            __exactCharacters = __exactFrame[8] as number;
            __exactStage = __exactFrame[4] as number;
            __exactSettled = __exactFrame[5];
        }
        else {
            __exactValue_0 = __exactSsr.prepareText(__exactInvocation, 0);
            if (__exactValue_0 === __exactSsr.unprepared)
                return;
            __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
            if (__exactValue_1 === __exactSsr.unprepared)
                return;
            __exactSsr.begin(__exactContext, 3, 2, 43, 43);
            __exactCharacters = 43;
        }
        switch (__exactStage) {
            case 0: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_0, "0", __exactCharacters, true, "<article><strong>", "</strong><p>");
            case 1:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_0 = __exactOutput.sink.ready();
                if (__exactDrain_0) {
                    __exactPending = __exactDrain_0;
                    __exactStage = 2;
                    break;
                }
            case 2: __exactSettled = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "1", __exactCharacters, true, "", "</p></article>");
            case 3:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_1 = __exactOutput.sink.ready();
                if (__exactDrain_1) {
                    __exactPending = __exactDrain_1;
                    __exactStage = 4;
                    break;
                }
            case 4: return __exactOutput;
        }
        {
            const __exactSaved: unknown[] = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactCharacters];
            return (__exactPending!).then(__exactResult => {
                __exactSaved[5] = __exactResult;
                return __exactRun(__exactSaved[0] as typeof __exactSsr, __exactSaved[1] as typeof __exactContext, __exactSaved[2] as typeof __exactInvocation, __exactSaved[3] as typeof __exactOutput, __exactSaved);
            });
        }
    } });
const __exact_render_program_10 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 2, id: "x7uTT_EjJQbMgnGpY7p6zhF", namespace: "html", ssrRootStatic: [" class=\"comments\"", ["className"], []], template: "<section class=\"comments\"><h3>Response log</h3><!--x:0--><!--/x:0--><!--x:1--><!--/x:1--><form><label>New comment <textarea maxLength=\"2000\" required></textarea></label><button type=\"submit\" class=\"primary\">Add comment</button></form></section>", wire: [["section", "html", 6, 5], [[5, 0, 1, "0"], [5, 1, 0, "1"], [6, 2, 1025, "form"], [7, 2, 2], [6, 4, 1027, "textarea"], [7, 3, 4]], [[1, 0, true], [3, 1], [5, 0, 2], [6, 1, 3], [7, 3, __exact_component_updates_1]]], directClaims: true, keyedChildren: 2, ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame?: unknown[]): (typeof __exactOutput | undefined) | Promise<typeof __exactOutput | undefined> {
        let __exactValue_0: unknown, __exactValue_1: unknown, __exactValue_2: unknown, __exactValue_3: unknown, __exactValue_4: unknown, __exactCharacters: number, __exactStage = 0, __exactSettled: unknown, __exactPending;
        if (__exactFrame) {
            __exactValue_0 = __exactFrame[6] as unknown;
            __exactValue_1 = __exactFrame[7] as unknown;
            __exactValue_2 = __exactFrame[8] as unknown;
            __exactValue_3 = __exactFrame[9] as unknown;
            __exactValue_4 = __exactFrame[10] as unknown;
            __exactCharacters = __exactFrame[11] as number;
            __exactStage = __exactFrame[4] as number;
            __exactSettled = __exactFrame[5];
        }
        else {
            __exactValue_0 = __exactSsr.prepareChild(__exactInvocation, 0);
            if (__exactValue_0 === __exactSsr.unprepared)
                return;
            __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
            if (__exactValue_1 === __exactSsr.unprepared)
                return;
            __exactValue_2 = __exactSsr.prepareAttribute(__exactInvocation, 2);
            if (__exactValue_2 === __exactSsr.unprepared)
                return;
            __exactValue_3 = __exactSsr.prepareAttribute(__exactInvocation, 3);
            if (__exactValue_3 === __exactSsr.unprepared)
                return;
            __exactValue_4 = __exactSsr.prepareAttribute(__exactInvocation, 4);
            if (__exactValue_4 === __exactSsr.unprepared)
                return;
            __exactSsr.begin(__exactContext, 6, 5, 202, 202);
            __exactCharacters = 202;
        }
        switch (__exactStage) {
            case 0: __exactSettled = __exactSsr.static(__exactOutput, "<section class=\"comments\"><h3>Response log</h3>");
            case 1:
                const __exactDrain_0 = __exactOutput.sink.ready();
                if (__exactDrain_0) {
                    __exactPending = __exactDrain_0;
                    __exactStage = 2;
                    break;
                }
            case 2:
                __exactSettled = __exactSsr.child(__exactContext, __exactOutput, __exactValue_0, "0", __exactCharacters);
                if (__exactSettled instanceof __exactSsr.promise) {
                    __exactPending = __exactSettled;
                    __exactStage = 3;
                    break;
                }
            case 3:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_1 = __exactOutput.sink.ready();
                if (__exactDrain_1) {
                    __exactPending = __exactDrain_1;
                    __exactStage = 4;
                    break;
                }
            case 4:
                __exactSettled = __exactSsr.child(__exactContext, __exactOutput, __exactValue_1, "1", __exactCharacters);
                if (__exactSettled instanceof __exactSsr.promise) {
                    __exactPending = __exactSettled;
                    __exactStage = 5;
                    break;
                }
            case 5:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_2 = __exactOutput.sink.ready();
                if (__exactDrain_2) {
                    __exactPending = __exactDrain_2;
                    __exactStage = 6;
                    break;
                }
            case 6: __exactSettled = __exactSsr.static(__exactOutput, "<form");
            case 7:
                const __exactDrain_3 = __exactOutput.sink.ready();
                if (__exactDrain_3) {
                    __exactPending = __exactDrain_3;
                    __exactStage = 8;
                    break;
                }
            case 8: __exactSettled = __exactSsr.compiledAttribute(__exactContext, __exactOutput, __exactValue_2, 0, "__exactDirectInteraction:onSubmit", "__exactDirectInteraction:onSubmit", "form", __exactCharacters);
            case 9:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_4 = __exactOutput.sink.ready();
                if (__exactDrain_4) {
                    __exactPending = __exactDrain_4;
                    __exactStage = 10;
                    break;
                }
            case 10: __exactSettled = __exactSsr.static(__exactOutput, "><label>New comment <textarea");
            case 11:
                const __exactDrain_5 = __exactOutput.sink.ready();
                if (__exactDrain_5) {
                    __exactPending = __exactDrain_5;
                    __exactStage = 12;
                    break;
                }
            case 12: __exactSettled = __exactSsr.compiledAttribute(__exactContext, __exactOutput, __exactValue_3, 0, "value", "value", "textarea", __exactCharacters);
            case 13:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_6 = __exactOutput.sink.ready();
                if (__exactDrain_6) {
                    __exactPending = __exactDrain_6;
                    __exactStage = 14;
                    break;
                }
            case 14: __exactSettled = __exactSsr.compiledAttribute(__exactContext, __exactOutput, __exactValue_4, 0, "__exactBindInput", "__exactBindInput", "textarea", __exactCharacters);
            case 15:
                __exactCharacters = __exactSettled as number;
                const __exactDrain_7 = __exactOutput.sink.ready();
                if (__exactDrain_7) {
                    __exactPending = __exactDrain_7;
                    __exactStage = 16;
                    break;
                }
            case 16: __exactSettled = __exactSsr.static(__exactOutput, " maxLength=\"2000\" required></textarea></label><button type=\"submit\" class=\"primary\">Add comment</button></form></section>");
            case 17:
                const __exactDrain_8 = __exactOutput.sink.ready();
                if (__exactDrain_8) {
                    __exactPending = __exactDrain_8;
                    __exactStage = 18;
                    break;
                }
            case 18: return __exactOutput;
        }
        {
            const __exactSaved: unknown[] = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactValue_1, __exactValue_2, __exactValue_3, __exactValue_4, __exactCharacters];
            return (__exactPending!).then(__exactResult => {
                __exactSaved[5] = __exactResult;
                return __exactRun(__exactSaved[0] as typeof __exactSsr, __exactSaved[1] as typeof __exactContext, __exactSaved[2] as typeof __exactInvocation, __exactSaved[3] as typeof __exactOutput, __exactSaved);
            });
        }
    }, targetSlots: [0, 1] });
const __exact_render_program_11 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 2, id: "xw06nSmfiYtmyJ3t1pU0CDz", namespace: "html", ssrRootStatic: [" class=\"empty\"", ["className"], []], template: "<p class=\"empty\">Select an incident to inspect its response history.</p>", root: ["p"], work: [1, 0], directClaims: true, ssr: (__exactSsr, __exactContext, __exactInvocation, __exactOutput) => {
        __exactSsr.begin(__exactContext, 1, 0, 72, 72);
        let __exactCharacters = 72;
        __exactSsr.static(__exactOutput, "<p class=\"empty\">Select an incident to inspect its response history.</p>");
        const __exactDrain = __exactOutput.sink.ready();
        if (__exactDrain)
            return __exactDrain.then(() => __exactOutput);
        return __exactOutput;
    } });
const __exact_render_program_12 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 2, id: "xNYAbAdcBmuwUKhO1B3gvS5", namespace: "html", ssrRootStatic: [" class=\"detail-panel\" aria-label=\"Incident detail\"", ["className", "aria-label"], []], template: "<section class=\"detail-panel\" aria-label=\"Incident detail\"></section>", wire: [["section", "html", 1, 1], [[4, 0, 0]], [[1, 0, true], [7, 4, __exact_component_updates_1]]], directClaims: true, ssr: function __exactRun(__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactFrame?: unknown[]): (typeof __exactOutput | undefined) | Promise<typeof __exactOutput | undefined> {
        let __exactValue_0: unknown, __exactCharacters: number, __exactStage = 0, __exactSettled: unknown, __exactPending;
        if (__exactFrame) {
            __exactValue_0 = __exactFrame[6] as unknown;
            __exactCharacters = __exactFrame[7] as number;
            __exactStage = __exactFrame[4] as number;
            __exactSettled = __exactFrame[5];
        }
        else {
            __exactValue_0 = __exactSsr.prepareChild(__exactInvocation, 0);
            if (__exactValue_0 === __exactSsr.unprepared)
                return;
            __exactSsr.begin(__exactContext, 1, 1, 69, 69);
            __exactCharacters = 69;
        }
        switch (__exactStage) {
            case 0: __exactSettled = __exactSsr.static(__exactOutput, "<section class=\"detail-panel\" aria-label=\"Incident detail\">");
            case 1:
                const __exactDrain_0 = __exactOutput.sink.ready();
                if (__exactDrain_0) {
                    __exactPending = __exactDrain_0;
                    __exactStage = 2;
                    break;
                }
            case 2:
                __exactSettled = __exactSsr.keyedChild(__exactOutput, __exactValue_0);
                if (__exactSettled instanceof __exactSsr.promise) {
                    __exactPending = __exactSettled;
                    __exactStage = 3;
                    break;
                }
            case 3:
                const __exactDrain_1 = __exactOutput.sink.ready();
                if (__exactDrain_1) {
                    __exactPending = __exactDrain_1;
                    __exactStage = 4;
                    break;
                }
            case 4: __exactSettled = __exactSsr.static(__exactOutput, "</section>");
            case 5:
                const __exactDrain_2 = __exactOutput.sink.ready();
                if (__exactDrain_2) {
                    __exactPending = __exactDrain_2;
                    __exactStage = 6;
                    break;
                }
            case 6: return __exactOutput;
        }
        {
            const __exactSaved: unknown[] = [__exactSsr, __exactContext, __exactInvocation, __exactOutput, __exactStage, void 0, __exactValue_0, __exactCharacters];
            return (__exactPending!).then(__exactResult => {
                __exactSaved[5] = __exactResult;
                return __exactRun(__exactSaved[0] as typeof __exactSsr, __exactSaved[1] as typeof __exactContext, __exactSaved[2] as typeof __exactInvocation, __exactSaved[3] as typeof __exactOutput, __exactSaved);
            });
        }
    }, targetSlots: [0] });
type DetailState = {
    draft: string;
    conflict: string;
    job: AnalysisJob | null;
    busy: boolean;
    error: string;
    viewedIncidentId: string;
    viewedVersion: number;
};
type DetailProps = {
    incident?: Incident;
    users: User[];
    sessionUserId: string;
    onIncident(incident: Incident, mode?: 'optimistic' | 'authoritative'): void;
};
const __exactImplementation_IncidentDetail_1 = function IncidentDetail(this: Component<DetailState>, props: DetailProps) {
    const state = this.state;
    __exactWriteState(this.state, 2, '');
    __exactWriteState(this.state, 1, '');
    __exactWriteState(this.state, 4, null);
    __exactWriteState(this.state, 0, false);
    __exactWriteState(this.state, 3, '');
    __exactWriteState(this.state, 5, peek(() => (__exactReadState(props, 0) as Incident | undefined)?.id ?? ''));
    __exactWriteState(this.state, 6, peek(() => (__exactReadState(props, 0) as Incident | undefined)?.version ?? 0));
    async function claim() {
        if (!(__exactReadState(props, 0) as Incident | undefined) || !(__exactReadState(props, 2) as string))
            return;
        // A selection change starts a new view fence; live updates to the same selection deliberately do not.
        if (__exactReadState(state, 5) as string !== (__exactReadState(props, 0) as Incident).id) {
            __exactWriteState(state, 5, (__exactReadState(props, 0) as Incident).id);
            __exactWriteState(state, 6, (__exactReadState(props, 0) as Incident).version);
        }
        const original = copyIncident(__exactReadState(props, 0) as Incident);
        (__exactReadState(props, 1) as (incident: Incident, mode?: 'optimistic' | 'authoritative') => void)({ ...__exactReadState(props, 0) as Incident, ownerId: __exactReadState(props, 2) as string, status: 'investigating' }, 'optimistic');
        __exactWriteState(state, 1, '');
        __exactWriteState(state, 3, '');
        try {
            const payload = await claimIncident(original.id, __exactReadState(props, 2) as string, __exactReadState(state, 6) as number, undefined);
            if (payload.status === 409 && payload.error?.current) {
                (__exactReadState(props, 1) as (incident: Incident, mode?: 'optimistic' | 'authoritative') => void)(payload.error.current, 'authoritative');
                __exactWriteState(state, 6, payload.error.current.version);
                __exactWriteState(state, 1, 'This incident changed while you were viewing it. The latest owner is shown.');
            }
            else if (payload.incident) {
                (__exactReadState(props, 1) as (incident: Incident, mode?: 'optimistic' | 'authoritative') => void)(payload.incident, 'authoritative');
                __exactWriteState(state, 6, payload.incident.version);
            }
            else
                (__exactReadState(props, 1) as (incident: Incident, mode?: 'optimistic' | 'authoritative') => void)(original, 'optimistic');
        }
        catch (caught) {
            (__exactReadState(props, 1) as (incident: Incident, mode?: 'optimistic' | 'authoritative') => void)(original, 'optimistic');
            __exactWriteState(state, 3, caught instanceof Error ? caught.message : 'Unable to claim incident');
        }
    }
    async function addComment() {
        if (!(__exactReadState(props, 0) as Incident | undefined))
            return;
        const body = (__exactReadState(state, 2) as string).trim();
        if (!body || [...body].length > 2_000) {
            __exactWriteState(state, 3, 'Comment must contain 1 to 2,000 characters.');
            return;
        }
        const original = copyIncident(__exactReadState(props, 0) as Incident);
        const temporary = {
            id: `pending-${crypto.randomUUID()}`,
            authorId: __exactReadState(props, 2) as string,
            body,
            createdAt: new Date().toISOString()
        };
        (__exactReadState(props, 1) as (incident: Incident, mode?: 'optimistic' | 'authoritative') => void)({ ...original, comments: [...original.comments, temporary] }, 'optimistic');
        __exactWriteState(state, 2, '');
        __exactWriteState(state, 3, '');
        try {
            const payload = await submitComment(original.id, __exactReadState(props, 2) as string, body, crypto.randomUUID(), undefined);
            (__exactReadState(props, 1) as (incident: Incident, mode?: 'optimistic' | 'authoritative') => void)(payload.incident, 'authoritative');
            __exactWriteState(state, 6, payload.incident.version);
        }
        catch (caught) {
            (__exactReadState(props, 1) as (incident: Incident, mode?: 'optimistic' | 'authoritative') => void)(original, 'optimistic');
            __exactWriteState(state, 2, body);
            __exactWriteState(state, 3, caught instanceof Error ? caught.message : 'Unable to add comment');
        }
    }
    async function startAnalysis() {
        if (!(__exactReadState(props, 0) as Incident | undefined))
            return;
        __exactWriteState(state, 0, true);
        __exactWriteState(state, 3, '');
        try {
            const payload = await requestAnalysis((__exactReadState(props, 0) as Incident).id);
            __exactWriteState(state, 4, payload.job);
        }
        catch (caught) {
            __exactWriteState(state, 3, caught instanceof Error ? caught.message : 'Unable to start analysis');
        }
        finally {
            __exactWriteState(state, 0, false);
        }
    }
    __exactRegisterLifecycle(this, "mount", ({ signal }) => {
        subscribeLiveService({ onJob: (job) => job.id === state.job?.id && (__exactWriteState(this.state, 4, job)) }, signal);
    });
    ;
    return () => (__exactPreparedRenderProgram(__exact_render_program_12, [() => __exactReadState(props, 0) as Incident | undefined ? ([__exactPreparedRenderProgram(__exact_render_program_1, __exactSlot => __exactSlot === 0 ? __exactComponentReceipt(SeverityBadge, { severity: [__exactPropertyOperand, __exactReadState(props, 0) as Incident, "severity"] }) : __exactSlot === 1 ? (__exactReadState(props, 0) as Incident).title : (__exactReadState(props, 0) as Incident).version, this), __exactPreparedRenderProgram(__exact_render_program_2, __exactSlot => {
                if (__exactSlot === 0) {
                    const __exact_ownerName_1 = (__exactReadState(props, 3) as User[]).find((user) => user.id === (__exactReadState(props, 0) as Incident | undefined)?.ownerId)?.name ?? 'Unassigned';
                    return __exact_ownerName_1;
                }
                if (__exactSlot === 1) {
                    return (__exactReadState(props, 0) as Incident).status;
                }
            }, this), __exactDynamic(() => __exactReadState(this.state, 1) as string ? (__exactPreparedRenderProgram(__exact_render_program_3, [], this)) : null, "xFpzqHiTxJF1XQ5lMx6ma0m"), __exactDynamic(() => __exactReadState(this.state, 3) as string ? (__exactPreparedRenderProgram(__exact_render_program_4, [], this)) : null, "xot5kEg25UbhIjs5KLC5E8g"), __exactPreparedRenderProgram(__exact_render_program_5, [() => claim], this, (__exactGroup, __exactApply) => {
                if (__exactGroup === 0) {
                    __exactApply("__exactClosedInteraction:onClick", claim);
                }
            }), __exactPreparedRenderProgram(__exact_render_program_7, __exactSlot => __exactSlot === 0 ? __exactReadState(this.state, 4) as AnalysisJob | null ? `Analysis ${this.state.job.status}` : 'Analysis has not started' : __exactSlot === 1 ? this.state.job?.result ? __exactPreparedRenderProgram(__exact_render_program_6, [() => this.state.job.result.finding], this) : null : __exactSlot === 3 ? startAnalysis : undefined, this, (__exactGroup, __exactApply) => {
                if (__exactGroup === 0) {
                    __exactApply("__exactClosedInteraction:onClick", startAnalysis);
                }
            }), __exactPreparedRenderProgram(__exact_render_program_10, __exactSlot => __exactSlot === 0 ? (__exactReadState(props, 0) as Incident).comments.length === 0 ? (__exactPreparedRenderProgram(__exact_render_program_8, [], this)) : null : __exactSlot === 1 ? __exactMapKeyedChildren(this, (__exactReadState(props, 0) as Incident).comments, comment => comment.id, (comment) => (__exactPreparedRenderProgram(__exact_render_program_9, __exactSlot => __exactSlot === 0 ? (__exactReadState(props, 3) as User[]).find((user) => user.id === comment.authorId)?.name : comment.body, this)), "xs8Ym6GO7mehdGpImMStbbd", undefined, "member:id") : __exactSlot === 2 ? (event: import("@exactjs/jsx/jsx-runtime").JSX.TargetedEvent<HTMLFormElement, SubmitEvent>) => {
                event.preventDefault();
                return addComment();
            } : __exactSlot === 3 ? __exactReadState(this.state, 2) as string ?? "" : (event: Event & {
                readonly currentTarget: HTMLTextAreaElement;
            }) => __exactWriteState(this.state, 2, event.currentTarget.value as any), this, (__exactGroup, __exactApply) => {
                if (__exactGroup === 0) {
                    __exactApply("__exactDirectInteraction:onSubmit", (event: import("@exactjs/jsx/jsx-runtime").JSX.TargetedEvent<HTMLFormElement, SubmitEvent>) => {
                        event.preventDefault();
                        return addComment();
                    });
                }
                if (__exactGroup === 1) {
                    __exactApply("value", __exactReadState(this.state, 2) as string ?? "");
                    __exactApply("__exactBindInput", (event: Event & {
                        readonly currentTarget: HTMLTextAreaElement;
                    }) => __exactWriteState(this.state, 2, event.currentTarget.value as any));
                }
            })]) : (__exactPreparedRenderProgram(__exact_render_program_11, [], this))], this));
};
export const IncidentDetail = /* @__PURE__ */ (() => Object.assign(__exactImplementation_IncidentDetail_1, {
    [Symbol.for("@exactjs/component")]: "xIK8_9cLJrLkOKRWpREglkO",
    [__exactComponentContract_1]: {
        version: 2,
        placement: "isomorphic",
        role: "client",
        implementations: [
            { id: "x8tJxze4GHrCU9HUOJY7Ggl", name: "IncidentDetail", role: "root", implementation: __exactImplementation_IncidentDetail_1 }
        ],
        continuations: [],
        executors: [],
        boundaries: [
            {
                id: "xUIC2e9TWx_YlcAiNkeKGCG",
                componentId: "xIK8_9cLJrLkOKRWpREglkO",
                ownerComponentId: "xIK8_9cLJrLkOKRWpREglkO",
                kind: "client-island"
            },
            {
                id: "xeSMvWtrDoZRzuzWBl4oEFT",
                componentId: "xIK8_9cLJrLkOKRWpREglkO",
                ownerComponentId: "xIK8_9cLJrLkOKRWpREglkO",
                kind: "client-island"
            },
            {
                id: "x2OhUPQovUzSbolXPx8HovZ",
                componentId: "xIK8_9cLJrLkOKRWpREglkO",
                ownerComponentId: "xIK8_9cLJrLkOKRWpREglkO",
                kind: "client-island"
            }
        ],
        artifact: {
            version: 2,
            target: "client",
            id: "xIK8_9cLJrLkOKRWpREglkO",
            instantiate: __exactImplementation_IncidentDetail_1,
            construct: __exactConstructDurableComponent_1,
            abi: 7,
            capabilities: [
                "interactions"
            ],
            state: [
                "busy",
                "conflict",
                "draft",
                "error",
                "job",
                "viewedIncidentId",
                "viewedVersion"
            ],
            props: [
                "incident",
                "onIncident",
                "sessionUserId",
                "users"
            ],
            serialization: [
                1,
                "incident",
                [
                    1,
                    "id",
                    0,
                    "title",
                    0,
                    "severity",
                    0,
                    "status",
                    0,
                    "ownerId",
                    0,
                    "version",
                    0,
                    "updatedAt",
                    0,
                    "comments",
                    [
                        2,
                        [
                            1,
                            "id",
                            0,
                            "authorId",
                            0,
                            "body",
                            0,
                            "createdAt",
                            0
                        ]
                    ]
                ],
                "users",
                [
                    2,
                    [
                        1,
                        "id",
                        0,
                        "name",
                        0
                    ]
                ],
                "sessionUserId",
                0,
                "onIncident",
                0
            ],
            attach: __exactAttachClientComponent_1,
            receive: __exactReceiveClientProps_1,
            dispose: __exactDisposeClientComponent_1,
            updates: __exact_component_updates_1,
            tasks: [],
            reactive: [
                {
                    name: "ownerName",
                    provenance: "derived",
                    allocation: "inline",
                    dependencies: [
                        "props"
                    ]
                },
                {
                    name: "props",
                    provenance: "props",
                    allocation: "live-slot",
                    dependencies: []
                },
                {
                    name: "state",
                    provenance: "state",
                    allocation: "live-slot",
                    dependencies: []
                },
                {
                    name: "this",
                    provenance: "state",
                    allocation: "live-slot",
                    dependencies: []
                }
            ],
            render: "returned-function"
        },
        execution: {
            version: 1,
            ports: [],
            transitions: [],
            reactive: [
                {
                    name: "ownerName",
                    provenance: "derived",
                    allocation: "inline",
                    dependencies: [
                        "props"
                    ]
                },
                {
                    name: "props",
                    provenance: "props",
                    allocation: "live-slot",
                    dependencies: []
                },
                {
                    name: "state",
                    provenance: "state",
                    allocation: "live-slot",
                    dependencies: []
                },
                {
                    name: "this",
                    provenance: "state",
                    allocation: "live-slot",
                    dependencies: []
                }
            ]
        }
    }
}) as typeof __exactImplementation_IncidentDetail_1)();
function copyIncident(incident: Incident): Incident {
    return { ...incident, comments: incident.comments.map((comment) => ({ ...comment })) };
}
