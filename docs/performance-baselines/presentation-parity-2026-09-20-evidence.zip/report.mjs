import {readFile,writeFile} from 'node:fs/promises';
import {summarizeSsrCapacityCapture} from '../../framework-comparison/src/ssr-capacity-report.mjs';
const root=import.meta.dirname, prefix=root.split('/').at(-1);
const reference=process.env.COMPARISON_REFERENCE ?? 'wsl-workspace-2026-09-19';
const baselineLabel=reference==='wsl-framework-2026-09-18'?'Published 0.5.1 installation on WSL':'Workspace before hot-spot fixes';
const json=async p=>JSON.parse(await readFile(p,'utf8'));
const source=await json(root+'/source-state.json'), report=await json(root+'/report-data.json'), raw=await json(root+'/ssr.json');
const f=(n,p=2)=>Number(n).toLocaleString('en-US',{minimumFractionDigits:p,maximumFractionDigits:p});
const title='Framework comparison with verified presentation parity';
const lines=[`# ${title}, September 20, 2026`,'',
'This full capture measures the repository implementation through workspace-resolved compiler, runtime, and adapter packages. Source revision: `'+source.commit+'` plus the recorded worktree patch. Package release target: 0.6.0; component and render-program ABI: 2.','',
'The [September 18 WSL capture](wsl-framework-2026-09-18.md) loaded published 0.5.1 packages instead of the branch. Its numbers remain evidence for that installed setup, but its branch attribution is withdrawn. The dependency ranges and release-manifest inventory are corrected. Build and measurement guards now reject shadowing registry copies, and SSR environment records retain actual resolved paths and versions.','',
`Environment: ${raw.environment.platform} ${raw.environment.platformRelease}; ${raw.environment.cpu.model}; ${raw.environment.cpu.logicalCount} logical CPUs; ${f(raw.environment.totalMemoryBytes/1024**3,1)} GiB RAM; Node ${raw.environment.runtimes.node}; Bun ${raw.environment.runtimes.bun}.`,'',
'All five controlled participants are included in browser and string SSR measurements. Streaming covers eXact, React, and TanStack Start. The separate native track covers eXact and React. Browser timing uses 30 samples; startup uses ten samples at each of 1x/4x/6x CPU throttling; heap uses five samples. SSR diagnostics use 500 sequential requests, 500 16-request waves, and one 1,000 ms c32 diagnostic window. Native measurements retain seven samples. Sustained comparisons use all twelve original Windows plans with two independent drivers and reversed framework order.','',
'The participants now import one shared stylesheet. Desktop and mobile presentation gates compare server HTML and settled interactions before timing. Earlier five-framework paint comparisons included different visual workloads and must not be interpreted as isolated framework overhead. See the [presentation and paint investigation](presentation-parity-investigation-2026-09-20.md) for same-asset Windows/WSL controls, compiler corrections, and Bun concurrency experiments.','',
'## Sustained throughput and eXact/React ratios','',
'At total concurrency 32, RPS counts valid completed responses and divides by the union of simultaneous driver spans, summed over both populations and including drain. A ratio above 1 favors eXact. The ratio change treats React as the environment control, as requested; it is not a direct percentage change in eXact RPS.','',
`Reference: [${baselineLabel}](${reference}.md).`,'',
'| Runtime/API | Loading | eXact RPS | React RPS | eXact/React | Reference ratio | Ratio change |',
'| --- | --- | ---: | ---: | ---: | ---: | ---: |'];
const ratios=[];let errors=0,invalid=0;const captures=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const lane of ['multi','normal','arrivals']){
 const name=runtime+(mode==='stream'?'-stream':'')+'-'+lane,c=await json(root+'/'+name+'.json');captures.push(c);
 for(const b of c.blocks)for(const r of b.results)for(const s of r.stages){errors+=s.errors??0;invalid+=s.invalid??s.invalidResponses??0;}
 if(lane==='arrivals')continue;
 const before=await json(`docs/performance-baselines/${reference}-${name}.json`);
 const rates=d=>{const s=summarizeSsrCapacityCapture(d).filter(r=>r.concurrency===32);const exact=s.find(r=>r.name==='eXact').rps,react=s.find(r=>r.name==='React').rps;return{exact,react,ratio:exact/react};};
 const a=rates(before),b=rates(c),change=(b.ratio/a.ratio-1)*100;
 ratios.push({runtime,mode,lane,before:a,after:b,ratioChangePercent:change});
 lines.push('| '+[runtime+'/'+mode,lane==='multi'?'preloaded':'normal',f(b.exact,0),f(b.react,0),f(b.ratio,3)+'×',f(a.ratio,3)+'×',(change>=0?'+':'')+f(change,1)+'%'].join(' | ')+' |');
}
lines.push('','## Browser experience','','Each cell is mean / p50 / p95 / p99. Latency and memory: lower is better.','',
'| Metric | Unit | '+report.browserCharts[0].series.map(s=>s.name).join(' | ')+' |','| --- | --- | '+report.browserCharts[0].series.map(()=> '---:').join(' | ')+' |');
for(const c of report.browserCharts)lines.push('| '+[c.title,c.unit,...c.series.map(s=>['mean','p50','p95','p99'].map(k=>f(s.stats[k],3)).join(' / '))].join(' | ')+' |');
lines.push('','## SSR completion tails','','Completion of a 16-request wave, including data loading. Cells are mean / p95 / p99 milliseconds.','',
'| Runtime/API | '+report.server.burst.series.map(s=>s.name).join(' | ')+' |','| --- | '+report.server.burst.series.map(()=> '---:').join(' | ')+' |');
const stream=await json('apps/docs/src/data/ssr-stream-report.json');
for(const [mode,owner] of [['string',report.server],['stream',stream.server]])for(const runtime of ['node','bun']){const chart=(runtime==='node'?owner:owner.bun).burst;lines.push('| '+runtime+'/'+mode+' | '+report.server.burst.series.map(s=>{const r=chart.series.find(r=>r.name===s.name);return r?['mean','p95','p99'].map(k=>f(r.stats[k])).join(' / '):'unavailable';}).join(' | ')+' |');}
lines.push('','## Scheduled offered load','','Errors, drain time, and missed arrivals remain part of the reported results.','',
'| Runtime/API | Framework | Offered RPS | Valid RPS, populations | Request errors | Missed arrivals |','| --- | --- | ---: | ---: | ---: | ---: |');
for(const c of captures.filter(c=>c.plan.stages.some(s=>s.mode==='arrival')))for(const id of ['exact','react'])for(const rate of [8000,10000]){let e=0,m=0;const rates=[];for(const b of c.blocks.filter(b=>b.id===id).sort((a,b)=>a.population-b.population)){const ss=b.results.map(r=>r.stages.find(s=>s.name==='total-arrivals-'+rate));rates.push(f(ss.reduce((a,s)=>a+s.validRps,0),0));for(const s of ss){e+=s.errors;m+=s.missedCapacity+s.missedLag+s.missedDeadline;}}lines.push('| '+[c.runtimeId+'/'+c.renderMode,id,f(rate,0),rates.join(' / '),e,m].join(' | ')+' |');}
lines.push('',`Total request errors across capacity stages, including warmup: ${errors}. Invalid responses: ${invalid}.`,'',
'## Correctness and evidence','',
'Both runtimes passed 39 string and 25 streaming browser contracts before timing. The native track passed all 12 contracts. Native timing, startup CPU profiles, allocation captures, heap composition, raw response samples, and per-driver results remain separate evidence.','',
`The [structured capture](${prefix}.json) links all raw captures and records hashes, source state, exact runners, execution journal, and prior chart values. The [evidence archive](${prefix}-evidence.zip) retains the source patch, added implementation files, logs, load plans, and documentation verification. Native samples are in [the native capture](${prefix}-native.json).`,'');
await writeFile(`docs/performance-baselines/${prefix}.md`,lines.join('\n'));
await writeFile(root+'/ratio-comparison.json',JSON.stringify(ratios,null,2)+'\n');
console.log(JSON.stringify({reference,ratios,errors,invalid},null,2));
