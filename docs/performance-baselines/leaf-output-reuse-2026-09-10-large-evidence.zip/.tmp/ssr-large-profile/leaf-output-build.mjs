import fs from 'node:fs';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';let code=fs.readFileSync(root+'direct-execution-integrated/server-entry.js','utf8');
assert.equal(createHash('sha256').update(code).digest('hex'),'2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18');
code='const auditLeafPrograms=new WeakSet();\n'+code;
const old='function prepareCompiledRenderProgram(program) {';
assert.equal(code.split(old).length,2);
code=code.replace(old,old+`
 if(program.ssr){
 const source=program.ssr.toString();
 const allowed=new Set(['begin','prepareText','prepareAttribute','unprepared','promise','static','text','compiledAttribute','attribute','attributes','rootOpening']);
 const operations=[...source.matchAll(/__exactSsr\\.([A-Za-z]+)/g)].map(m=>m[1]);
 if(operations.length && operations.every(name=>allowed.has(name)) && !/__exactOutput\\.(?!sink\\b)/.test(source)) auditLeafPrograms.add(program);
 }
`);
const start=code.indexOf('\tconst output = {',code.indexOf('function renderProgramWriter('));const end=code.indexOf('\n\t};',start)+4;assert.ok(start>0&&end>start);
const original=code.slice(start,end);
code=code.slice(0,start)+original.replace('const output = {','const output = context.writerSink && auditLeafPrograms.has(invocation?.program) ? auditReadLeafOutput(context) : {')+code.slice(end);
code+=`
function auditReadLeafOutput(context){
 const previous=context.auditLeafOutput;
 if(previous && previous.sink===context.writerSink)return previous;
 return context.auditLeafOutput=Object.freeze({context,sink:context.writerSink});
}
`;
fs.mkdirSync(root+'leaf-output',{recursive:true});fs.writeFileSync(root+'leaf-output/server-entry.js',code);
const hash=createHash('sha256').update(code).digest('hex');console.log(hash);
fs.writeFileSync(root+'leaf-output-pressure.mjs',fs.readFileSync(root+'stateful-scope-pressure.mjs','utf8').replaceAll('stateful-scope','leaf-output'));
let t=fs.readFileSync(root+'array-invocation-timing.mjs','utf8').replaceAll('array-invocation','leaf-output').replaceAll('ad21ca825cda39d205ad89b617ddc5f5fc6e548d2be14aeac2da4e80dd178b98',hash);
// First screen is the two unresolved small-document string paths.
t=t.replace("[['node','assets'],['node','large'],['bun','assets'],['bun','large']]","[['node','assets'],['bun','assets']]").replace('rows.length,16','rows.length,8');
fs.writeFileSync(root+'leaf-output-timing.mjs',t);
