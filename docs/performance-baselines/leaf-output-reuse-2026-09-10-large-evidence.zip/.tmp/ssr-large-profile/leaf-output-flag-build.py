from pathlib import Path
import hashlib
r=Path('.tmp/ssr-large-profile');code=(r/'leaf-output/server-entry.js').read_text(encoding='utf-8')
code=code.replace('const auditLeafPrograms=new WeakSet();','')
code=code.replace('auditLeafPrograms.add(program);','program.auditLeafOutput = true;')
code=code.replace('auditLeafPrograms.has(invocation?.program)','invocation?.program.auditLeafOutput === true')
(r/'leaf-output-flag').mkdir(exist_ok=True);(r/'leaf-output-flag/server-entry.js').write_text(code,encoding='utf-8')
h=hashlib.sha256((r/'leaf-output-flag/server-entry.js').read_bytes()).hexdigest();print(h)
t=(r/'leaf-output-timing.mjs').read_text().replace('leaf-output','leaf-output-flag').replace('48231f87535442428554a955b8afa83bbcac7866fae064385b3d7647a9cba7a7',h)
(r/'leaf-output-flag-timing.mjs').write_text(t,encoding='utf-8')
p=(r/'leaf-output-pressure.mjs').read_text().replace('leaf-output','leaf-output-flag');(r/'leaf-output-flag-pressure.mjs').write_text(p,encoding='utf-8')
