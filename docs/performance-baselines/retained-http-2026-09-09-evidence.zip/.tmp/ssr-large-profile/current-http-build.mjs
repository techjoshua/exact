import {readFileSync,writeFileSync} from 'node:fs';
let source=readFileSync('.tmp/ssr-large-profile/http.mjs','utf8');
source=source.replace("population?['react','candidate','baseline']:['baseline','candidate','react']","population?['react','candidate']:['candidate','react']");
writeFileSync('.tmp/ssr-large-profile/current-http.mjs',source);
