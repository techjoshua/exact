import fs from 'node:fs/promises';
import { spawn } from 'node:child_process';
import assert from 'node:assert/strict';
const root = '.tmp/ssr-large-profile/';
const orders = [['baseline','initial','gated'],['baseline','gated','initial'],['initial','baseline','gated'],['initial','gated','baseline'],['gated','baseline','initial'],['gated','initial','baseline']];
const entries = { baseline: 'conditional-emission', initial: 'dynamic-shell-fusion', gated: 'react' };
const rows = [];
for (const runtime of ['node','bun']) for (const mode of ['encoded','stream']) for (const [round, order] of orders.entries()) for (const variant of order) {
  if(rows.some(r=>r.runtimeName===runtime&&r.mode===mode&&r.round===round&&r.variant===variant)) continue;
  const result = await new Promise((resolve, reject) => {
    const entry=variant==='gated'?'framework-comparison/participants/react/'+(runtime==='bun'?'dist-bun-server/bun-server-entry.js':'dist-server/server-entry.js'):root+entries[variant]+'/'+(runtime==='bun'?'bun-server-entry.js':'server-entry.js');
    const child = spawn(runtime==='bun'?'C:/Program Files/Bun/bun.exe':process.execPath, [root+(runtime==='bun'?'direct-document-host-bun-worker.mjs':'flat-invocation-large-worker.mjs'), entry, mode, 'small', '20000'], { windowsHide: true, env: { ...process.env, NODE_ENV: 'production' } });
    let stdout = '', stderr = '';
    child.stdout.on('data', data => stdout += data);
    child.stderr.on('data', data => stderr += data);
    child.on('error', reject);
    child.on('exit', code => resolve({ code, stdout, stderr }));
  });
  assert.equal(result.code, 0, result.stderr);
  const row = { round, variant, runtimeName:runtime, ...JSON.parse(result.stdout.trim()) };
  rows.push(row);
  await fs.writeFile(root+'dynamic-shell-fusion/screen.json', JSON.stringify(rows, null, 2));
  console.log(runtime,mode,round,variant,row.usPerRender.toFixed(2),row.cpuMicrosPerRender.toFixed(2));
}
for(const runtime of ['node','bun']) for(const mode of ['encoded','stream']) assert.equal(new Set(rows.filter(r=>r.runtimeName===runtime&&r.mode===mode&&r.variant!=='gated').map(r=>r.hash)).size,1);
