import fs from 'node:fs/promises';
const base = '.tmp/ssr-large-profile/';
let script = await fs.readFile(base + 'dynamic-shell-fusion-trace.mjs', 'utf8');
script = script.replace("const root='.tmp/ssr-large-profile/dynamic-shell-fusion-trace/'", "const root='.tmp/ssr-large-profile/root-program-audit/'")
  .replace("const originalPath='.tmp/ssr-large-profile/dynamic-shell-fusion/server-entry.js'", "const originalPath='.tmp/ssr-large-profile/conditional-emission/server-entry.js'");
script = script.replace("if(name.startsWith('executeDirectSsrComponent:'))", "if(name.startsWith('createPreparedServerRenderProgram:'))events[events.length-1].args={program:args[0]?.id,slots:args[1]?.length,host:args[0]?.ssrHost};if(name.startsWith('executeDirectSsrComponent:'))");
await fs.writeFile(base + 'root-program-audit-run.mjs', script);
