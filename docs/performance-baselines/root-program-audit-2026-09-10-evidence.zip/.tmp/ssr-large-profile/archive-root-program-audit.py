from pathlib import Path
import hashlib, json, zipfile
from statistics import mean
root = Path.cwd()
base = root / '.tmp/ssr-large-profile'
rows = json.loads((base / 'dynamic-shell-fusion/http.json').read_text())
assert len(rows) == 18
stages = [d['stages'][0] for r in rows for d in r['results']]
assert all(s['errors'] == 0 and s['valid'] == s['completed'] == s['started'] for s in stages)
assert sum(s['valid'] for s in stages) == 277742
for r in rows:
    assert hashlib.sha256(Path(r['entry']).read_bytes()).hexdigest() == r['artifactSha256']
for mode in ['string', 'stream', 'stream-pressure']:
    trace = json.loads((base / 'root-program-audit' / (mode + '.trace.json')).read_text())
    invocations = [e for e in trace['traceEvents'] if e['name'].startswith('createPreparedServerRenderProgram:') and e['ph'] == 'B']
    assert len(invocations) == 22
report = root / 'docs/performance-baselines/root-program-audit-2026-09-10.md'
files = {report, Path(__file__).resolve()}
for prefix in ['root-program-audit', 'dynamic-shell-fusion']:
    for f in base.glob(prefix + '*'):
        if f.is_file(): files.add(f)
        elif f.is_dir(): files.update(x for x in f.rglob('*') if x.is_file())
for f in ['root-execution-cache.ts', 'server-component-reference.ts', 'direct-component.ts', 'direct-component-content.ts', 'program-writer-output.ts', 'render-program.ts']:
    files.add(root / 'packages/ssr/src/render' / f)
files.add(root / 'packages/core/src/render-program.ts')
for sub in ['dist-server/server-entry.js', 'dist-bun-server/bun-server-entry.js']:
    current = root / 'framework-comparison/participants/exact' / sub
    retained = base / 'conditional-emission' / Path(sub).name
    assert current.read_bytes() == retained.read_bytes()
    files.update([current, retained, root / 'framework-comparison/participants/react' / sub])
archive = report.with_name('root-program-audit-2026-09-10-evidence.zip')
assert not archive.exists()
manifest = {f.relative_to(root).as_posix(): hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(files)}
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for f in sorted(files): z.write(f, f.relative_to(root).as_posix())
    z.writestr('SHA256.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, digest in manifest.items(): assert hashlib.sha256(z.read(name)).hexdigest() == digest
print(json.dumps({'verifiedFiles': len(files), 'valid': sum(s['valid'] for s in stages), 'rps': {v: mean(r['rps'] for r in rows if r['variant'] == v) for v in ['baseline', 'compiled', 'react']}}, indent=2))
