from pathlib import Path
import json
rows=[]
for p in sorted(Path('.tmp/ssr-checkpoint').glob('*-string-*.json')):
 d=json.loads(p.read_text())
 for b in d['blocks']:
  ss=[r['stages'][-1] for r in b['results']]
  row=dict(capture=p.stem,complete=d['complete'],population=b['population']+1,framework=b['id'],rps=sum(s['validRps'] for s in ss),p95=max(s['distributions']['responseMs']['p95'] for s in ss),p99=max(s['distributions']['responseMs']['p99'] for s in ss),errors=sum(s['errors'] for s in ss),invalid=sum(s['invalid'] for s in ss),stats=b['telemetry'][-1]['value'].get('resumeStats'))
  rows.append(row)
  print(row['capture'],row['population'],row['framework'],round(row['rps']),round(row['p95'],2),round(row['p99'],2),row['errors'],row['invalid'])
Path('.tmp/ssr-checkpoint/summary.json').write_text(json.dumps(rows,indent=2))
