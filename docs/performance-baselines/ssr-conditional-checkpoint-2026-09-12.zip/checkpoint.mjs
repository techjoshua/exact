/** Resumes ready values synchronously; consults host policy only after a pending value settles. */
export function resumeAfter(value, resume, checkpoint) {
  if (!(value instanceof Promise)) return resume(value);
  return value.then(result => {
    const scheduled = checkpoint();
    return scheduled ? scheduled.then(() => resume(result)) : resume(result);
  });
}
