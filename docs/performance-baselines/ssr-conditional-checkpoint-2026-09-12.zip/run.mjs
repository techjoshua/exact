import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync} from 'node:fs';
const rows=[];
for(const mode of ['string'])for(const policy of ['current','both','current']){
 const name=`${rows.length}-${mode}-${policy}`;
 console.log('START '+name);const row={mode,policy,startedAt:new Date().toISOString()};rows.push(row);
 const fd=openSync(`.tmp/ssr-checkpoint/${name}.log`,'w');
 try{await new Promise((yes,no)=>{const c=spawn(process.execPath,['.tmp/ssr-checkpoint/capacity.mjs','.tmp/ssr-checkpoint/plan.json',`.tmp/ssr-checkpoint/${name}.json`,'node'],{windowsHide:true,env:{...process.env,NODE_ENV:'production',COMPARISON_SSR_RENDER_MODE:mode,RESUME_POLICY:policy},stdio:['ignore',fd,fd]});row.pid=c.pid;c.once('error',no);c.once('exit',code=>{row.code=code;code===0?yes():no(Error(policy+' failed'));});});}
 finally{closeSync(fd);row.endedAt=new Date().toISOString();writeFileSync('.tmp/ssr-checkpoint/confirmation-execution.json',JSON.stringify(rows,null,2));}console.log('DONE '+name);
}
