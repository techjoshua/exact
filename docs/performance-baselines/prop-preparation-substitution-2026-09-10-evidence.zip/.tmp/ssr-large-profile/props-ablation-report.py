import hashlib
import json
import zipfile
from pathlib import Path
from statistics import mean

base=Path('.tmp/ssr-large-profile');folder=base/'props-ablation'
data=json.loads((folder/'capture.json').read_text());assert data['complete']
rows=[]
for population in (0,1):
    blocks=[b for b in data['blocks'] if b['population']==population]
    assert len(blocks)==3 and [b['phase'] for b in blocks]==['none','props','none']
    controls=[blocks[0],blocks[2]];b=blocks[1]
    assert b['after']['ablation']['counts']['props']==0
    def render(x):
        s=x['after']['telemetry']['statistics']['renderMs'];return s['sum']/s['count']*1000
    def loop(x):return mean(x[k]['meanMs'] for k in ('loopBefore','loopAfter'))*1000
    normal=mean(c['rps'] for c in controls)
    rows.append(dict(population=population+1,normalRps=normal,stubRps=b['rps'],gainPct=(b['rps']/normal-1)*100,
                     normalHttpUs=mean(render(c) for c in controls),stubHttpUs=render(b),normalLoopUs=mean(loop(c) for c in controls),stubLoopUs=loop(b)))
valid=sum(b['valid'] for b in data['blocks']);errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages']);assert errors==0
(folder/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid,errors=errors),indent=2))
report=Path('docs/performance-baselines/prop-preparation-substitution-2026-09-10.md')
lines=['# Prop preparation substitution, 2026-09-10','','## Scope','',
'The next component-preparation boundary is prepareComponentProps. Its normal',
'implementation scans inputs for task-backed values; this fixed fixture always',
'returns its original props. The diagnostic asserts that identity on every normal',
'call, then substitutes the identity result in treatment blocks. It does not',
'cache props or reuse component instances. State creation, compiled rendering,',
'hydration and cleanup remain active. Four preparation calls occur per render.', '',
'Hypothesis before measurement: approximately 1 to 5 percent HTTP headroom.',
'The compiled scalar-prop proof already skips some preparations, so this measures',
'only the remaining calls. No proposal to skip real task dependencies follows',
'from this fixed-input experiment.', '',
'Two fresh Node string workers each run normal/substitution/normal, ten seconds',
'HTTP warmup and five seconds per block. Two fresh drivers per block each hold',
'16 requests in flight. Controls average adjacent normal blocks in the same',
'worker. Isolated loops before/after each block warm and measure 10,000 renders.',
'Instrumentation and workstation workload affect timings, so do not compare',
'these controls with unrelated workers or claim exclusive CPU cost.', '',
'## Results','',
'| Worker | Normal RPS | Identity RPS | Change | Normal HTTP us | Identity HTTP us |',
'| --- | ---: | ---: | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['population']} | {r['normalRps']:,.0f} | {r['stubRps']:,.0f} | {r['gainPct']:+.2f}% | {r['normalHttpUs']:.2f} | {r['stubHttpUs']:.2f} |")
lines+=['',f'All {valid:,} measured responses match the complete 4,672-byte document,',
'zero errors. Four ordinary/escaped full-document parity cases pass. Counters',
'confirm bypassed scans. Artifact and adapter hashes are checked and owned',
'worker/load processes close. Raw isolated durations remain in summary.json.', '',
'## Decision','',
'This is only the prop-dependency scan, not all component preparation. Use its',
'measured size to prioritize the next boundary. Any real optimization must retain',
'pending, failed and cancelled task-input behavior and correctly handle authored',
'props. The broader tree cost still includes compiler issuance, frame allocation,',
'program operation construction and execution. No production change is accepted',
'from this diagnostic; the Node/Bun string/stream objective remains open.', '',
'The adjacent archive includes raw blocks, summaries, source/check/runner scripts,',
'frozen current and diagnostic artifacts, fixture and verified SHA-256 inventory.',
'Workspace dependencies are not included as a standalone distribution.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[report,Path('.tmp/positional-leaves/data.json')]+[base/n for n in ('props-ablation-build.mjs','props-ablation-check.mjs','props-ablation-run.mjs','props-ablation-report.py','tree-ablation-run.mjs','tree-ablation-check.mjs','hydration-ablation/worker.mjs','component-forwarding-integrated/server-entry.js')]
files=sorted(set(f for f in files if f.is_file()));archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={f.as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in files:z.write(f,f.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps(rows,indent=2));print(valid,'valid;',len(files),'verified files')
