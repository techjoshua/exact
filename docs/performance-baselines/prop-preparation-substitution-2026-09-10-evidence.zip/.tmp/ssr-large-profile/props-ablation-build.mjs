import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'props-ablation',{recursive:true});
const source=(await fs.readFile(root+'component-forwarding-integrated/server-entry.js','utf8')).replaceAll('\r\n','\n');
const ast=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const edits=[];let replaced=0;
function visit(n){
 if(ts.isFunctionDeclaration(n)&&n.name?.text==='prepareComponentProps'){
  edits.push({start:n.name.getStart(ast),end:n.name.end,text:'auditOriginalPrepareProps'});
  edits.push({start:n.end,end:n.end,text:`
function prepareComponentProps(props,deferredTaskProps,signal){
 if(auditStage==='props')return props;
 ++auditCounts.props;const result=auditOriginalPrepareProps(props,deferredTaskProps,signal);
 if(result!==props)throw Error('Diagnostic requires identity prop preparation');return result;
}
`});replaced++;
 }
 ts.forEachChild(n,visit);
}
visit(ast);if(replaced!==1)throw Error('Missing preparation boundary');
let output=source;for(const e of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,e.start)+e.text+output.slice(e.end);
output=`let auditStage='none',auditCounts={props:0};\n`+output+`
export function auditClearCounts(){auditCounts={props:0};}
export function auditReset(){auditStage='none';auditClearCounts();}
export function auditSelect(stage){if(!['none','props'].includes(stage))throw Error('Invalid stage');auditStage=stage;}
export function auditRead(){return {stage:auditStage,counts:{...auditCounts},ready:true};}
`;
await fs.writeFile(root+'props-ablation/server-entry.js',output);
await fs.copyFile(root+'hydration-ablation/worker.mjs',root+'props-ablation/worker.mjs');
let runner=(await fs.readFile(root+'tree-ablation-run.mjs','utf8')).replaceAll('tree-ablation/','props-ablation/').replaceAll('within-worker-tree-substitution','within-worker-props-substitution').replaceAll("'none','tree','none'","'none','props','none'");
await fs.writeFile(root+'props-ablation-run.mjs',runner);
let check=(await fs.readFile(root+'tree-ablation-check.mjs','utf8')).replaceAll('tree-ablation/','props-ablation/').replace("['none','tree']","['none','props']").replace("assert.equal(snapshot.counts.tree,stage==='tree'?0:1);","assert.equal(snapshot.counts.props===0,stage==='props');");
await fs.writeFile(root+'props-ablation-check.mjs',check);
console.log({replaced});
