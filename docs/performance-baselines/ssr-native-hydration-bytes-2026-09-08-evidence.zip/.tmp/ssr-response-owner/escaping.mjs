import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const payload=JSON.parse(await readFile('.tmp/ssr-paired-profile/payload.json','utf8'));
const escape=c=>c==='<'?'\\u003C':c==='\u2028'?'\\u2028':'\\u2029';
const unsafe=/[<\u2028\u2029]/;
const operations={
 before:p=>JSON.stringify(p).replace(/</g,'\\u003C').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029'),
 combined:p=>JSON.stringify(p).replace(/[<\u2028\u2029]/g,escape),
 guarded:p=>{const json=JSON.stringify(p);return unsafe.test(json)?json.replace(/</g,'\\u003C').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029'):json;}
};
const cases={document:payload,unsafe:[payload,'</script>\u2028\u2029\ud800'],dense:'<\u2028\u2029'.repeat(100)};
const samples=[];let consumed=0;
for(const [kind,value] of Object.entries(cases)){
 for(const op of Object.values(operations))assert.equal(op(value),operations.before(value));
 for(let round=0;round<10;round++)for(const name of round%2?Object.keys(operations).reverse():Object.keys(operations)){
  const start=performance.now();for(let i=0;i<20000;i++)consumed+=operations[name](value).length;
  samples.push({kind,round,name,us:(performance.now()-start)/20});
 }
}
const means=Object.fromEntries(Object.keys(cases).map(kind=>[kind,Object.fromEntries(Object.keys(operations).map(name=>[name,samples.filter(s=>s.name===name&&s.kind===kind).reduce((sum,s)=>sum+s.us,0)/10]))]));
console.log(means);await writeFile('.tmp/ssr-response-owner/escaping.json',JSON.stringify({means,samples,consumed},null,2));
