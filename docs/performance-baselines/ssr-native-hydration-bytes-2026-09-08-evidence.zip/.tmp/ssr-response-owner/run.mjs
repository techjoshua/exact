import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {installDevelopmentProcessLifecycle} from '../../scripts/development-process-lifecycle.mjs';
import {startSsrLoadProcess} from '../../framework-comparison/src/ssr-load-process-owner.mjs';
import {startSsrWorker,stopSsrWorker} from '../../framework-comparison/src/ssr-worker-controller.mjs';
import {availableSsrRuntimes} from '../../framework-comparison/src/ssr-run-environment.mjs';
const runtime=availableSsrRuntimes('node')[0];
const workers={},identities={},artifacts={};let service,drivers=[];
const report={complete:false,kind:'same-worker-alternating-diagnostic',createdAt:new Date().toISOString(),blocks:[],artifacts};
async function closeDrivers(){const owned=drivers;drivers=[];for(const r of await Promise.allSettled(owned.map(d=>d.close())))if(r.status==='rejected')throw r.reason;}
async function close(){await closeDrivers();for(const [id,worker] of Object.entries(workers)){delete workers[id];await stopSsrWorker(worker);}if(service){const s=service;service=undefined;await s.close();}}
const lifecycle=installDevelopmentProcessLifecycle({label:'Alternating SSR diagnostic',close});
const names=['control','candidate','react'];
try{
 for(const [name,path] of Object.entries({exact:'framework-comparison/participants/exact/dist-server/server-entry.js',react:'framework-comparison/participants/react/dist-server/server-entry.js',worker:'.tmp/ssr-response-owner/worker.mjs',adapter:'framework-adapters/node-adapter/dist/handler.js',body:'packages/server/dist/response-body.js',candidate:'.tmp/ssr-response-owner/merged.mjs'}))artifacts[name]={path,sha256:createHash('sha256').update(await readFile(path)).digest('hex')};
 service=await startSsrLoadProcess('service');
 for(const id of ['exact','react'])workers[id]=await startSsrWorker({runtime,participantId:id,transport:'node-http',workerPath:resolve(artifacts.worker.path),workingDirectory:resolve('framework-comparison'),serviceUrl:service.url,environment:{COMPARISON_SSR_BOUNDED_TELEMETRY:'1'}});
 for(const name of names){const worker=workers[name==='react'?'react':'exact'];const response=await fetch(worker.url+'?__benchmarkPreloaded=true'+(name==='candidate'?'&__candidate=true':''));assert.equal(response.status,200);const body=Buffer.from(await response.arrayBuffer());identities[name]={bytes:body.length,hash:createHash('sha256').update(body).digest('hex')};}
 assert.deepEqual(identities.control,identities.candidate);
 for(let round=-1;round<9;round++){
  const order=names.map((_,i)=>names[(i+Math.max(0,round))%3]);if(round%2)order.reverse();
  for(const name of order){
   const worker=workers[name==='react'?'react':'exact'];
   for(let i=0;i<2;i++)drivers.push(await startSsrLoadProcess('driver'));
   for(const driver of drivers)driver.run({url:worker.url+'?__benchmarkPreloaded=true'+(name==='candidate'?'&__candidate=true':''),contains:'Delayed fulfillment events',expectedIdentity:identities[name],maxInFlight:256,maxLagMs:50,timeoutMs:10000,stages:[{name:round<0?'warmup':'capacity',mode:'concurrency',concurrency:16,durationMs:3000,discard:round<0}]});
   const results=await Promise.race([Promise.all(drivers.map(d=>d.result)),service.result]);
   const stages=results.map(r=>r.stages[0]);for(const s of stages){assert.equal(s.errors,0);assert.equal(s.started,s.completed);assert.equal(s.completed,s.valid);}
   const start=Math.min(...stages.map(s=>Date.parse(s.startedAt))),end=Math.max(...stages.map(s=>Date.parse(s.startedAt)+s.elapsedMs));
   const rps=stages.reduce((sum,s)=>sum+s.valid,0)/((end-start)/1000);
   report.blocks.push({round,name,rps,workerPid:worker.child.pid,results});console.log(round,name,Math.round(rps));
   await closeDrivers();await writeFile('.tmp/ssr-response-owner/alternating.json',JSON.stringify(report));
  }
 }
 for(const a of Object.values(artifacts))assert.equal(createHash('sha256').update(await readFile(a.path)).digest('hex'),a.sha256);
 report.complete=true;await writeFile('.tmp/ssr-response-owner/alternating.json',JSON.stringify(report));
}finally{await close();lifecycle.dispose();}
