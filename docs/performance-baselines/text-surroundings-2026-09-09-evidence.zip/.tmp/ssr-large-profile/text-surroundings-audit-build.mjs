import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
for(const variant of ['scheduled-contract-current','text-surroundings-current']){
 let source=readFileSync(dir+variant+'.mjs','utf8');
 const replace=(before,after)=>{if(source.split(before).length!==2)throw Error('Unexpected instrumentation site: '+before);source=source.replace(before,after);};
 replace('static(output, value) {','static(output, value) {\n textWriteAudit.static++;');
 replace('text(opaqueContext, output, value, id, characters, markerless, prefix = "", suffix = "") {','text(opaqueContext, output, value, id, characters, markerless, prefix = "", suffix = "") {\n textWriteAudit.text++;');
 replace('function appendProgramText(output, html) {','function appendProgramText(output, html) {\n textWriteAudit.appends++;');
 source+='\nconst textWriteAudit={static:0,text:0,appends:0};\nexport function readTextWriteAudit(){return {...textWriteAudit};}\n';
 writeFileSync(dir+variant+'-write-audit.mjs',source);
}
writeFileSync(dir+'text-surroundings-audit-worker.mjs',readFileSync(dir+'scheduled-preparation-audit-worker.mjs','utf8').replaceAll('-preparation-audit','-write-audit').replaceAll('readPreparationAudit','readTextWriteAudit'));
