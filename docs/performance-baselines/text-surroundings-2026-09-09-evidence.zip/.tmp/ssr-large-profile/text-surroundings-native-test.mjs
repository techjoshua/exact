import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const run=spawnSync('go',['test','-json','./internal/exactcompiler','./cmd/exactc'],{cwd:'.tmp/native-typescript-go/tsc',encoding:'utf8',windowsHide:true,maxBuffer:32*1024*1024});
writeFileSync('.tmp/ssr-large-profile/text-surroundings-native-test.jsonl',run.stdout);
writeFileSync('.tmp/ssr-large-profile/text-surroundings-native-test.stderr.log',run.stderr);
for(const line of run.stdout.trim().split('\n')){
 const entry=JSON.parse(line);
 if(entry.Action==='fail'||entry.Output?.match(/\w_test.go:\d+:/))console.log(JSON.stringify(entry));
}
process.exitCode=run.status??1;
