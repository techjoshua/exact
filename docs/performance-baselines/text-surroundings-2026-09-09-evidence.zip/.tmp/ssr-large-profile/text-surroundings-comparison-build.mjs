import {readFileSync,writeFileSync,existsSync,copyFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {resolve} from 'node:path';
const dir='.tmp/ssr-large-profile/';
const partial=dir+'text-surroundings-comparison-results.json';
if(existsSync(partial)&&!existsSync(dir+'text-surroundings-comparison-initial-results.json'))copyFileSync(partial,dir+'text-surroundings-comparison-initial-results.json');
const resolution={};
for(const [label,entry] of Object.entries({participant:'framework-comparison/participants/react/dist-server/server-entry.js',scratch:dir+'text-surroundings-react.mjs'})){
 const require=createRequire(resolve(entry));
 resolution[label]={version:require('react-dom/package.json').version,entry:require.resolve('react-dom/server')};
}
writeFileSync(dir+'text-surroundings-react-resolution.json',JSON.stringify(resolution,null,2));
console.log(resolution);
writeFileSync(dir+'text-surroundings-react.mjs',readFileSync('framework-comparison/participants/react/dist-server/server-entry.js'));
writeFileSync(dir+'text-surroundings-comparison-run.mjs',readFileSync(dir+'current-comparison-run.mjs','utf8')
 .replaceAll('current-comparison','text-surroundings-comparison')
 .replaceAll('marker-hex-current','text-surroundings-current')
 .replace("const rows=[];",`worker=worker.replace("import {resolve} from 'node:path';", "import {resolve} from 'node:path';\\nimport {createRequire} from 'node:module';");
 worker=worker.replace('const mod=await import', "const packageRequire=createRequire(resolve(entry));\\nconst reactResolution=entry.includes('participants/react/')?{version:packageRequire('react-dom/package.json').version,entry:packageRequire.resolve('react-dom/server')}:undefined;\\nconst mod=await import");
 worker=worker.replace('JSON.stringify({entry,','JSON.stringify({reactResolution,entry,');
 writeFileSync(dir+'text-surroundings-comparison-worker.mjs',worker);
 const rows=[];`));
