import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const dir='.tmp/ssr-large-profile/';
const artifact=readFileSync('framework-comparison/participants/exact/dist-server/server-entry.js');
writeFileSync(dir+'text-surroundings-current.mjs',artifact);
writeFileSync(dir+'text-surroundings-run.mjs',readFileSync(dir+'map-fragment-run.mjs','utf8').replaceAll('map-fragment','text-surroundings-current').replaceAll('marker-hex-current','scheduled-contract-current'));
writeFileSync(dir+'text-surroundings-browser.mjs',readFileSync(dir+'browser.mjs','utf8').replace('ssr-large-profile/browser-','ssr-large-profile/text-surroundings-browser-'));
console.log(createHash('sha256').update(artifact).digest('hex'));
