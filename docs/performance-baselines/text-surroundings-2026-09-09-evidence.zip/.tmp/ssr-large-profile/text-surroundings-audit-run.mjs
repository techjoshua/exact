import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const rows=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const scenario of ['small','large'])for(const variant of ['scheduled-contract-current','text-surroundings-current']){
 const r=spawnSync(runtime,['.tmp/ssr-large-profile/text-surroundings-audit-worker.mjs',variant,mode,scenario],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(r.status!==0)throw Error(r.stderr||r.stdout);
 const row={runtime,...JSON.parse(r.stdout)};
 const peer=rows.find(v=>v.runtime===runtime&&v.mode===mode&&v.scenario===scenario);
 if(peer){assert.equal(row.hash,peer.hash);assert.equal(row.text,peer.text);assert.ok(row.static<peer.static);assert.equal(peer.appends-row.appends,peer.static-row.static);}
 rows.push(row);console.log(JSON.stringify(row));
}
writeFileSync('.tmp/ssr-large-profile/text-surroundings-audit-results.json',JSON.stringify(rows,null,2));
