from pathlib import Path
import hashlib
import json
import statistics
import zipfile

root=Path.cwd()
work=root/'.tmp/ssr-large-profile'
stem=root/'docs/performance-baselines/text-surroundings-2026-09-09'
paired=json.loads((work/'text-surroundings-current-results.json').read_text(encoding='utf-8'))
comparison=json.loads((work/'text-surroundings-comparison-results.json').read_text(encoding='utf-8'))
audit=json.loads((work/'text-surroundings-audit-results.json').read_text(encoding='utf-8'))
aborted=json.loads((work/'text-surroundings-comparison-initial-results.json').read_text(encoding='utf-8'))
assert len(paired)==32 and len(comparison)==48 and len(audit)==16 and len(aborted)==1
table=['| Runtime | Output | Document | Pair 1 time change | Pair 2 time change |','| --- | --- | --- | ---: | ---: |']
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['small','large']:
   changes=[]
   for pair in range(2):
    rows=[r for r in paired if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['round']==pair]
    assert len(rows)==2 and rows[0]['hash']==rows[1]['hash']
    old=next(r for r in rows if r['variant']=='scheduled-contract-current')
    new=next(r for r in rows if r['variant']=='text-surroundings-current')
    changes.append((new['usPerRender']/old['usPerRender']-1)*100)
   table.append(f'| {runtime} | {mode} | {scenario} | {changes[0]:+.2f}% | {changes[1]:+.2f}% |')
react_table=['| Runtime | Output | Document | eXact median us | React median us | eXact time difference |','| --- | --- | --- | ---: | ---: | ---: |']
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['empty','assets','large']:
   values={}
   for variant in ['exact','react']:
    rows=[r for r in comparison if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['variant']==variant]
    assert len(rows)==2 and rows[0]['hash']==rows[1]['hash']
    values[variant]=statistics.median(r['usPerRender'] for r in rows)
   exact,react=values['exact'],values['react']
   react_table.append(f'| {runtime} | {mode} | {scenario} | {exact:.2f} | {react:.2f} | {(exact/react-1)*100:+.1f}% |')
for variant,entry in [('text-surroundings-current','framework-comparison/participants/exact/dist-server/server-entry.js'),('text-surroundings-react','framework-comparison/participants/react/dist-server/server-entry.js')]:
 assert (work/(variant+'.mjs')).read_bytes()==(root/entry).read_bytes()
resolutions={runtime:next(r['reactResolution'] for r in comparison if r['runtimeId']==runtime and r['variant']=='react') for runtime in ['node','bun']}
validation={'core':{'files':50,'tests':258},'ssr':{'files':45,'tests':286},'browser':{'cells':4,'testsPerCell':14,'total':56},
 'passed':['native compiler and exactc Go tests','native compiler build and stamp','core/SSR builds and compiler lowering','comparison exact client/Node/Bun builds','comparison React client/server build','test typecheck','changed-file ESLint','source architecture','platform boundaries','compiled ABI fixtures','release ABI epoch 1','package contents'],
 'note':'Command completion summary; browser logs are included. Initial native failure JSONL is also retained, not presented as the final passing run.'}
evidence={'paired':paired,'comparison':comparison,'writeAudit':audit,'abortedComparisonSetup':aborted,'reactResolution':resolutions,'validation':validation}
old_size=(work/'scheduled-contract-current.mjs').stat().st_size
new_size=(work/'text-surroundings-current.mjs').stat().st_size
text=f'''# Compiler-folded text surroundings

Date: 2026-09-09. Retained compiler optimization and refreshed renderer comparison.

The compiler now folds adjacent serialized static markup into the existing prefix/suffix arguments
of a scalar SSR write. It avoids separate static-write and append calls while preserving the root
opening's ownership of its segments. Dynamic values still use the same escaping and marker logic;
static content is charged once by the program and dynamic lengths retain their existing checks.
The client topology and public authoring model are unchanged.

This uses the existing writer signature and runtime operations. No emitted helper was removed and
no ABI epoch change is required. Frozen ABI behavior passes without regenerating fixtures. The
uncompressed comparison server artifact is {old_size-new_size} bytes smaller; the client artifact
remains index-CdIXDKwS.js.

## Hypothesis and observed work

Combining surrounding static output with the scalar write should reduce operation dispatch and
array append bookkeeping in both string and streaming rendering. No numerical gain was
preregistered and no minimum improvement threshold was used.

Untimed instrumentation records the following per complete document, identically on Node and Bun
and in both output modes. The dynamic text-write count is unchanged.

| Document | Static calls before/after | Text calls | Append calls before/after |
| --- | ---: | ---: | ---: |
| Small | 37 / 14 | 19 | 95 / 72 |
| Large | 502 / 14 | 391 | 1118 / 630 |

These are observed calls, not byte-copy, allocation-byte, or CPU-profile estimates. All instrumented
and timed before/after complete-document hashes match. The existing renderer still collects program
segments and subtree strings; this change does not integrate the experimental direct sink traversal.

## Before/after experiment

There are 32 fresh production-mode populations: Node/Bun, string/consumed stream, small/large,
two reversed-order pairs, and previous/current builds. Each performs 5,000 warmups and 12,000
measured renders. The fixtures contain 3 or 96 incidents and two scripts plus two stylesheet links.
The control is scheduled-contract-current, retaining the preceding scheduling optimization.

Positive values mean longer rendering time. These descriptive local pairs do not establish
confidence intervals or HTTP throughput. Large Node string renders improve consistently by about
5%; smaller workloads and some Bun cells remain mixed.

'''+ '\n'.join(table)+'''

## Fresh React comparison

The fresh comparison has 48 successful populations: Node/Bun, string/consumed stream, three
scenarios, two reversed-order rounds, and eXact/React. Each again performs 5,000 warmups and 12,000
measured renders. Empty and assets use three incidents; large uses 96 incidents with the same four
assets. Every response is checked for complete document framing, required asset URLs, and stable
full hashes within each framework. The two frameworks own their complete application documents,
including initial client data.

The same Node-target participant entry files run on both runtimes. React's external dependency
resolution is preserved at its original package location: React DOM 19.2.0 selects server.node.js
on Node and server.bun.js on Bun. Both streaming entries use their framework's Web Stream API and
the worker consumes the result with Response.text(). These are renderer timings, not timings of
the runtime-specific HTTP adapters, network throughput, first-byte latency, or browser performance.

The table uses the median of the two process means, in microseconds per complete render. Percentage
differences are rendering-time differences, not requests-per-second differences.

'''+ '\n'.join(react_table)+'''

eXact wins every tested Node streaming pair and both smaller Bun streaming scenarios. React wins
the string-rendering pairs and large Bun streaming pairs. Overall React parity remains unmet.

The first attempted comparison copied React's externally linked bundle into the scratch directory.
That changed package resolution from the participant's React DOM 19.2.0 to the workspace root's
18.3.1 and failed before React rendered. The single eXact population from that incomplete pair is
preserved separately and excluded from the comparison. The corrected run executes React from its
original directory and records dependency resolution in every React row. The archived scratch
copy of the React artifact is evidence only; it is not a runnable replacement location for that
externally linked bundle. No completed paired population was discarded.

## Validation

Native compiler and exactc tests pass, and the compiler binary was rebuilt with an updated build
stamp. Four preexisting compiler assertions initially depended on the spelling of trailing
arguments or a separate static call. They were adjusted to retain their actual checks: markerless
scalar writes and eager issue of independent task siblings. The initial failing JSONL is archived;
the later native test/build passed. A new compiler test verifies folded markup around text and
attribute boundaries.

All 258 core tests and 286 SSR tests pass. A new SSR regression checks exact markup and escaping
across text/attribute boundaries and exercises the exact output limit plus one byte below it.
All 56 browser checks pass across eXact/React, Node/Bun, and string/stream, covering hydration and
interactive behavior. These browser checks are correctness tests, not new browser timing results.

Core/SSR builds and compiler lowering, comparison application builds, test typechecking, changed
TypeScript file linting, source architecture, platform boundaries, frozen compiled ABI behavior,
release epoch checks, and package contents pass. Completed-command summaries and the browser logs
are retained; the summary is not a claim that every terminal transcript is included.

The compiler runtime comments and engineering SSR documentation describe serialized surroundings.
No public API, application setup, or documentation-app usage rule changes.

## Remaining work

The shared direct-writer implementation, compiler task-dependent expression deferral, and early
head flushing remain unfinished. This optimization can also reduce writes in that eventual
traversal, but it does not prove its performance or lifecycle behavior. The fresh comparison leaves
string rendering and large Bun streaming as unresolved performance gaps. No full HTTP benchmark
or browser timing baseline was replaced with these focused renderer results.
'''
stem.with_suffix('.md').write_text(text,encoding='utf-8')
stem.with_suffix('.json').write_text(json.dumps(evidence,indent=2)+'\n',encoding='utf-8')
files=[stem.with_suffix('.md'),stem.with_suffix('.json')]
files+=sorted(p for p in work.glob('text-surroundings*') if p.is_file() and p.suffix in ['.mjs','.json','.jsonl','.log','.py'])
for path in ['native/typescript-go/overlay/internal/exactcompiler/jsx_render_program_ssr_lowering.go','native/typescript-go/overlay/internal/exactcompiler/jsx_render_program_ssr_lowering_test.go','native/typescript-go/overlay/internal/exactcompiler/jsx_render_program_text_runs_test.go','native/typescript-go/overlay/internal/exactcompiler/session_test.go','packages/core/src/render-program.ts','packages/ssr/src/component-rendering.test.ts','packages/ssr/src/component-rendering.fixtures.test.tsx','docs/ssr-hydration.md','framework-comparison/participants/react/src/Document.tsx','framework-comparison/participants/react/src/server-entry.tsx','framework-comparison/participants/react/dist-server/server-entry.js','framework-comparison/package.json','.tmp/ssr-large-profile/scheduled-contract-current.mjs','.tmp/ssr-large-profile/scheduled-contract-current-write-audit.mjs','.tmp/ssr-large-profile/direct-map-worker.mjs','.tmp/ssr-large-profile/map-fragment-run.mjs','.tmp/ssr-large-profile/current-comparison-run.mjs','.tmp/ssr-large-profile/long-worker.mjs','.tmp/ssr-large-profile/scheduled-preparation-audit-worker.mjs','.tmp/ssr-large-profile/browser.mjs','.tmp/positional-leaves/data.json']:
 files.append(root/path)
files=list(dict.fromkeys(files))
manifest={str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=Path(str(stem)+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p.relative_to(root)).replace('\\','/'))
 z.writestr('SHA256.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,expected in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==expected
print(f'Verified {len(files)} archived files; 80 successful timed populations, 16 instrumented documents, 1 incomplete setup population.')
print('\n'.join(react_table))
