import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {setPriority} from 'node:os';
setPriority(0,10);
const base='.tmp/ssr-large-profile/';
const modules=await Promise.all(['current','candidate'].map(name=>import(pathToFileURL(resolve(base+'structural-detail-limits/'+name+'.js')))));
const fixture=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));
const rows=[];
for(const comments of [0,1,12]){
 const data=structuredClone(fixture);
 const incident=data.incidents.find(item=>item.id==='inc-101');assert.ok(incident);
 const original=incident.comments[0]??{authorId:data.users[0].id,body:'test'};
 incident.comments=Array.from({length:comments},(_,i)=>({...original,id:'late-'+i,body:'Comment '+i}));
 const results=[],eventLists=[];
 for(const mod of modules){
  const events=[];
  const html=await mod.auditLimited(data,'',{
   onDirectComponentCreated(snapshot){
    events.push(snapshot.componentId);
    if(snapshot.componentId==='xO5-F_osoXnUvNHR-Y85XDd'){
     snapshot.state.conflict='Late conflict';snapshot.state.error='Late error';
     snapshot.state.job={status:'complete',result:{finding:'Late finding'}};
    }
   }
  });
  results.push(html);eventLists.push(events);
 }
 assert.equal(results[0],results[1]);assert.deepEqual(eventLists[0],eventLists[1]);
 const markup=results[1].split('<script type="application/json"')[0];
 assert.equal(eventLists[1].filter(id=>id==='xO5-F_osoXnUvNHR-Y85XDd').length,1);
 assert.equal(markup.includes('Late conflict')||markup.includes('Late error'),false);
 assert.ok(markup.includes('Analysis has not started'));
 assert.equal(markup.includes('Late finding'),false);
 rows.push({comments,bytes:Buffer.byteLength(results[1]),componentEvents:eventLists[1].length});
}
const runtime=process.versions.bun?'bun':'node';
await fs.writeFile(base+'structural-detail/'+runtime+'-schedule.json',JSON.stringify(rows,null,2));
console.log(JSON.stringify({runtime,scheduleChecks:rows}));
