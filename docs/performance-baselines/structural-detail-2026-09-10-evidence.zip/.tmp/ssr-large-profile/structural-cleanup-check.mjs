import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {setPriority} from 'node:os';
setPriority(0,10);
const base='.tmp/ssr-large-profile/',out=base+'structural-cleanup/';
await fs.mkdir(out,{recursive:true});
const source=await fs.readFile(base+'structural-assets/server-entry.js','utf8');
const probe=`
export async function auditScopeProbe(mode) {
 const events=[];
 const context=createSsrContext({});
 const sink={write(value){events.push(value==='</body>'?'body-close':value==='</html>'?'html-close':'write');},ready(){},flush(){events.push('head-flush');}};
 context.writerSink=sink;
 const host=enterHostTag(context,'html');
 let resolveChild,rejectChild;
 const pending=new Promise((resolve,reject)=>{resolveChild=resolve;rejectChild=reject;});
 const primary=new Error('child failed'),cleanup=new Error('cleanup failed');
 const output={context,sink,render(){throw new Error('Unexpected child traversal');},prepareReferences(){events.push('prepare');return {[Symbol.asyncDispose](){events.push('dispose');if(mode==='both-fail'||mode==='cleanup-fail')throw cleanup;}};}};
 const operations={begin(){},static(out,value){out.sink.write(value);},reference(){return {};},component(){events.push('child-start');return mode==='ready'||mode==='cleanup-fail'?undefined:pending;}};
 const ranges=[createPreparedServerChildRange(createServerList([])),createPreparedServerChildRange(createServerList([])),{}];
 let work,error,result;
 try {
  work=auditDynamicShell.ssr(operations,context,{eagerValues:ranges},output);
  if(work instanceof Promise){
   events.push('pending-observed');
   if(mode!=='ready'&&mode!=='cleanup-fail'&&events.includes('dispose'))throw new Error('Disposed before child settled');
   if(mode==='child-fail'||mode==='both-fail')rejectChild(primary);else resolveChild();
  }
  result=await work;
 } catch(failure){error=failure;}
 finally{leaveHost(context,host.tag);}
 return {mode,events,primaryPreserved:error===primary,cleanupSurfaced:error===cleanup,completed:result===output,error:error?.message,depth:context.traversalDepth,hostDepth:context.hostStack.length};
}
`;
await fs.writeFile(out+'probe.js',source+probe);
const module=await import(pathToFileURL(resolve(out+'probe.js')));
const rows=[];
for(const mode of ['ready','pending','child-fail','cleanup-fail','both-fail']){
 const row=await module.auditScopeProbe(mode);rows.push(row);
 assert.equal(row.events.filter(event=>event==='dispose').length,1);
 assert.equal(row.hostDepth,0);
 assert.equal(row.depth,0);
 if(mode==='ready'||mode==='pending'){
  assert.equal(row.completed,true);assert.ok(row.events.indexOf('dispose')<row.events.indexOf('body-close'));
 }else{
  assert.equal(row.events.includes('body-close'),false);
  assert.equal(mode==='cleanup-fail'?row.cleanupSurfaced:row.primaryPreserved,true);
 }
}
const runtime=process.versions.bun?'bun':'node';
await fs.writeFile(out+runtime+'.json',JSON.stringify(rows,null,2));
console.log(JSON.stringify({runtime,passed:rows.length,results:rows.map(({mode,completed,error})=>({mode,completed,error}))}));
