import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const base='.tmp/ssr-large-profile/',out=base+'structural-detail/';
await fs.mkdir(out,{recursive:true});
for(const file of ['server-entry.js','bun-server-entry.js']){
 let source=await fs.readFile(base+'structural-assets/'+file,'utf8');
 const start=source.indexOf('var auditComments = '),end=source.indexOf('function auditCommentsInvoke',start);
 assert.ok(start>0&&end>start);
 let writer=source.slice(start,end);
 const call='__exactSsr.child(__exactContext, __exactOutput, __exactValue_2, "1", __exactCharacters)';
 assert.equal(writer.split(call).length,2);
 writer=writer.replace(call,'auditCommentList(__exactContext, __exactOutput, __exactValue_2, "1", __exactCharacters)');
 source=source.slice(0,start)+writer+source.slice(end);
 const branch=': output.render([value]);';assert.equal(source.split(branch).length,2);
 source=source.replace(branch,': position===2 || position===3 ? auditDetailRange(output,value) : output.render([value]);');
 source+=`
function auditDetailRange(output,value){
 return auditAssetScope(output.context,()=>{
  const range=readPreparedServerChildRange(value);
  if(!range)throw new Error('Expected detail range');
  const children=normalizeRenderResult(unwrap(range.value));
  if(children.length>1)throw new Error('Expected one conditional detail program');
  return markerPair(output.context,'',()=>children.length?auditAssetScope(output.context,()=>{
   if(children[0]===null)return '';
   const program=readPreparedServerRenderProgram(children[0]);
   if(!program)throw new Error('Expected conditional detail program');
   return renderPreparedSsrProgram(output.context,program,output.target??output.render,output.prepareReferences);
  }):'');
 });
}
function auditCommentList(context,output,children,id,characters){
 if(!Array.isArray(children))throw new Error('Expected eager comment array');
 const opening=context.markers?'<!--x:'+id+'-->':'',closing=context.markers?'<!--/x:'+id+'-->':'';
 const next=characters+opening.length+closing.length;
 if(next>context.maxOutputBytes)throw new SsrOutputLimitError(context.maxOutputBytes);
 return mapRenderValue(writeProgramBoundary(context,output.sink,opening,closing,()=>auditCommentItems(output,children,0)),()=>next);
}
function auditCommentItems(output,children,index){
 while(index<children.length){
  const child=children[index++];
  const value=auditAssetScope(output.context,()=>{
   const program=readPreparedServerRenderProgram(child);
   if(!program||program.program.ssrHost!=='article')throw new Error('Expected keyed comment article');
   return renderPreparedSsrProgram(output.context,program,output.target??output.render,output.prepareReferences);
  });
  if(value instanceof Promise)return awaitSsrProgramSink(output.sink,value).then(html=>{if(html)output.sink.write(html);return mapRenderValue(output.sink.ready(),()=>auditCommentItems(output,children,index));});
  if(value)output.sink.write(value);
  const pending=output.sink.ready();if(pending)return pending.then(()=>auditCommentItems(output,children,index));
 }
 return '';
}
`;
 await fs.writeFile(out+file,source);
}
for(const kind of ['check','limits','trace']){
 const source=await fs.readFile(base+'structural-assets-'+kind+'.mjs','utf8');
 await fs.writeFile(base+'structural-detail-'+kind+'.mjs',source.replaceAll('structural-assets','structural-detail'));
}
console.log('Created detail range and eager-list prototype');
