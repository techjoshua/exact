
import {readFile,writeFile} from 'node:fs/promises';import {resolve} from 'node:path';import {createHash} from 'node:crypto';import assert from 'node:assert/strict';
import {installDevelopmentProcessLifecycle} from '../../scripts/development-process-lifecycle.mjs';import {startSsrLoadProcess} from '../../framework-comparison/src/ssr-load-process-owner.mjs';import {startSsrWorker,stopSsrWorker,controlSsrWorker} from '../../framework-comparison/src/ssr-worker-controller.mjs';import {availableSsrRuntimes,ssrEnvironmentMetadata} from '../../framework-comparison/src/ssr-run-environment.mjs';
const root='.tmp/ssr-count-audit/';const runtime=availableSsrRuntimes('node')[0],workers={},identities={};let service,drivers=[];const report={complete:false,kind:'balanced-current-build-count-audit',createdAt:new Date().toISOString(),environment:ssrEnvironmentMetadata([runtime]),artifacts:{},blocks:[]};
async function closeDrivers(){const owned=drivers;drivers=[];for(const r of await Promise.allSettled(owned.map(d=>d.close())))if(r.status==='rejected')throw r.reason;}
async function close(){await closeDrivers();for(const [id,w]of Object.entries(workers)){delete workers[id];await stopSsrWorker(w);}if(service){const s=service;service=undefined;await s.close();}}
const lifecycle=installDevelopmentProcessLifecycle({label:'SSR count audit',close});
try{
 for(const [name,path]of Object.entries({exact:'framework-comparison/participants/exact/dist-server/server-entry.js',react:'framework-comparison/participants/react/dist-server/server-entry.js',worker:'framework-comparison/src/ssr-benchmark-worker.mjs',driver:'framework-comparison/src/ssr-load-driver.mjs',adapter:'framework-adapters/node-adapter/dist/handler.js',body:'packages/server/dist/response-body.js'}))report.artifacts[name]={path,sha256:createHash('sha256').update(await readFile(path)).digest('hex')};
 service=await startSsrLoadProcess('service');
 for(const id of ['exact','react']){
  workers[id]=await startSsrWorker({runtime,participantId:id,transport:'node-http',workerPath:resolve(report.artifacts.worker.path),workingDirectory:resolve('framework-comparison'),serviceUrl:service.url,environment:{COMPARISON_SSR_BOUNDED_TELEMETRY:'1'}});
  const response=await fetch(workers[id].url+'?__benchmarkPreloaded=true');assert.equal(response.status,200);const bytes=Buffer.from(await response.arrayBuffer());identities[id]={bytes:bytes.length,hash:createHash('sha256').update(bytes).digest('hex')};
 }
 for(let round=-1;round<6;round++)for(const id of round%2?['react','exact']:['exact','react']){
  const worker=workers[id];for(let i=0;i<2;i++)drivers.push(await startSsrLoadProcess('driver'));
  const before=await controlSsrWorker(worker,'telemetry');const wallStarted=performance.now();
  for(const driver of drivers)driver.run({url:worker.url+'?__benchmarkPreloaded=true',contains:'Delayed fulfillment events',expectedIdentity:identities[id],maxInFlight:256,maxLagMs:50,timeoutMs:10000,stages:[{name:round<0?'warmup':'capacity',mode:'concurrency',concurrency:16,durationMs:5000,discard:round<0}]});
  const results=await Promise.race([Promise.all(drivers.map(d=>d.result)),service.result]);const parentElapsedMs=performance.now()-wallStarted;const after=await controlSsrWorker(worker,'telemetry');
  const stages=results.flatMap(r=>r.stages);for(const s of stages){assert.equal(s.errors,0);assert.equal(s.started,s.completed);assert.equal(s.completed,s.valid);for(const key of ['offered','started','completed','valid','errors'])assert.equal(s.intervals.reduce((n,i)=>n+i[key],0),s[key]);}
  const valid=stages.reduce((n,s)=>n+s.valid,0),expectedServerCount=valid+2;
  const counts=Object.fromEntries(['renderedBytes','responseBytes','totalMs'].map(key=>[key,after.statistics[key].count-before.statistics[key].count]));for(const n of Object.values(counts))assert.equal(n,expectedServerCount);
  assert.equal(after.statistics.responseBytes.sum-before.statistics.responseBytes.sum,expectedServerCount*identities[id].bytes);
  const start=Math.min(...stages.map(s=>Date.parse(s.startedAt))),end=Math.max(...stages.map(s=>Date.parse(s.startedAt)+s.elapsedMs)),elapsedMs=end-start,rps=valid*1000/elapsedMs;
  assert.ok(parentElapsedMs+2>=elapsedMs);report.blocks.push({round,id,rps,valid,elapsedMs,parentElapsedMs,parentRps:valid*1000/parentElapsedMs,counts,preflightRequests:2,before,after,results});console.log(round,id,JSON.stringify({rps:Math.round(rps),valid,counts,parentElapsedMs,elapsedMs}));
  await closeDrivers();await writeFile(root+'capture.json',JSON.stringify(report));
 }
 for(const a of Object.values(report.artifacts))assert.equal(createHash('sha256').update(await readFile(a.path)).digest('hex'),a.sha256);
 report.complete=true;await writeFile(root+'capture.json',JSON.stringify(report));
}finally{await close();lifecycle.dispose();}
