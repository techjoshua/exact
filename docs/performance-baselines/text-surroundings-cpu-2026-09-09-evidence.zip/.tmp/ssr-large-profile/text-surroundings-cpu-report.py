import hashlib, json, pathlib, zipfile

root = pathlib.Path('.')
directory = root / '.tmp/ssr-large-profile/text-surroundings-cpu'
summary = json.loads((directory / 'summary.json').read_text(encoding='utf-8'))
rows = json.loads((directory / 'results.json').read_text(encoding='utf-8'))
assert len(summary) == len(rows) == 6
previous = json.loads((root / '.tmp/ssr-large-profile/text-surroundings-comparison-results.json').read_text(encoding='utf-8'))
for row in rows:
    variant = 'react' if row['variant'] == 'react' else 'exact'
    matches = [p for p in previous if p['variant'] == variant and p['runtimeId'] == 'node' and p['mode'] == 'string' and p['scenario'] == row['scenario']]
    assert matches and all(p['hash'] == row['hash'] for p in matches)

report = '''# Current string renderer CPU profiles

Date: 2026-09-09. Diagnostic investigation; production unchanged.

The preceding turn reported status without new implementation evidence. This follow-up verified
the current participant SHA-256 against the retained text-surroundings artifact and collected six
fresh Node CPU profiles: eXact and React, each with three incidents without assets, three incidents
with four assets, and 96 incidents with four assets. Each production process performs 5,000 warmups
and 50,000 measured full-document string renders. React executes from its participant directory,
resolving React DOM 19.2.0. All six final document hashes match the corresponding earlier comparison.

These CPU profiles include startup, warmup, and measurement. Percentages are sampled self time,
not allocation bytes or inclusive bucket totals. Timings under the profiler are diagnostic and do
not replace the unprofiled paired comparison. One process per cell does not establish variance.

| Framework | Scenario | GC self time | Prominent serialization work |
| --- | --- | ---: | --- |
'''
for item in summary:
    name = item['profile']
    framework = 'React' if name.startswith('react-') else 'eXact'
    scenario = name.removesuffix('.cpuprofile').split('-')[-1]
    top = {x['function']: x for x in item['top']}
    gc = top.get('(garbage collector)')
    gc_text = f"{gc['percent']:.1f}%" if gc else 'Outside top 18'
    selected = ['validatePositionalValue', 'serializeJson'] if framework == 'eXact' else ['escapeTextForBrowser']
    facts = ', '.join(f"{key}: {top[key]['percent']:.1f}%" for key in selected if key in top)
    report += f'| {framework} | {scenario} | {gc_text} | {facts} |\n'
report += '''
## Consequences for the next experiment

The profile supports continued attention to allocation and hydration work, but does not prove
which allocation site causes GC. The string-result code creates request-local accessor closures,
hidden chunk properties, and a second hydratable wrapper. Source inspection confirms that these
are real costs; replacing them requires preserving lazy materialization and result semantics.
The earlier single-result experiment already tested a writable single-chunk property and produced
mixed Bun results. Repeating it unchanged is not warranted.

A distinct candidate is shared accessor implementations with request-owned result storage,
preserving lazy getters and chunk ownership. Hypothesis: eliminating per-result getter closures
could save roughly 1-3% of small-document string time; this is a forecast, not a measurement.
Before implementation, verify enumerable own-property behavior, mutation semantics, and retention
of the underlying chunk arrays. A prototype must compare Node and Bun, string and consumed stream,
and retain full-document hashes. Do not remove serialization checks to manufacture that gain.

The asset shell delta alone does not prove asset traversal is the dominant gap. Both applications
parse their build-generated tag inputs and render their own shell. The current profiles provide
attribution clues, not a causal subtraction of asset costs across separate processes.

No production edit or new browser result is claimed. The shared direct-to-sink traversal and
early independent shell publication remain incomplete, and React parity remains unmet.

Raw CPU profiles, measurements, summary, scripts, and a SHA-256 manifest are in the adjacent
evidence ZIP. The existing text-surroundings report remains the unprofiled performance reference.
'''
destination = root / 'docs/performance-baselines/text-surroundings-cpu-2026-09-09'
destination.with_suffix('.md').write_text(report, encoding='utf-8')
files = list(directory.glob('*')) + [root / '.tmp/ssr-large-profile' / name for name in ['text-surroundings-cpu-run.mjs', 'text-surroundings-cpu-summary.py', 'text-surroundings-cpu-report.py', 'text-surroundings-comparison-worker.mjs']]
files += [root / '.tmp/positional-leaves/data.json']
manifest = {str(path).replace('\\', '/'): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
archive = pathlib.Path(str(destination) + '-evidence.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as output:
    for path in files:
        output.write(path, str(path).replace('\\', '/'))
    output.writestr('sha256.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as output:
    for name, expected in manifest.items():
        assert hashlib.sha256(output.read(name)).hexdigest() == expected
print(f'Validated {len(rows)} document hashes and {len(files)} archived evidence files.')
