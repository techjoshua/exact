import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
const browser=readFileSync(dir+'direct-list-browser.mjs','utf8').replaceAll('direct-list-browser-','scalar-proof-browser-');
writeFileSync(dir+'scalar-proof-browser.mjs',browser);
const commands=[
 ['typecheck',['npm.cmd','run','typecheck:tests']],
 ['final-app',[process.execPath,dir+'source-sink-build.mjs',dir+'scalar-proof-shared']],
 ['tests-final',['npm.cmd','exec','--','vitest','run','--config','vitest.packages.config.ts','packages/ssr','packages/compiler/src/transform/ssr-continuation-types.test.ts','--testTimeout=30000']],
 ['canonical-build',['npm.cmd','run','build:exact','-w','@exactjs/framework-comparison-suite']],
 ['browser',[process.execPath,dir+'scalar-proof-browser.mjs']],
 ['platform',['npm.cmd','run','check:platform-boundaries']],
 ['contents',['npm.cmd','exec','--call','"node scripts/check-package-contents.mjs"']]
];
for(const [name,[cmd,...args]] of commands){
 const r=spawnSync(cmd,args,{windowsHide:true,shell:cmd.endsWith('.cmd'),encoding:'utf8',env:{...process.env,NODE_ENV:'production'},maxBuffer:32*1024*1024});
 writeFileSync(dir+'scalar-proof-shared-'+name+'.log',(r.stdout??'')+'\n'+(r.stderr??'')+'\n'+(r.error?.stack??''));
 console.log(name,r.status);
 if(r.status!==0)process.exit(r.status??1);
}


