import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const dir='.tmp/ssr-large-profile/',rows=[];
for(const runtime of ['node','bun'])for(const mode of ['string','stream'])for(const scenario of ['small','large']){
 const pair=[];
 for(const variant of ['direct-writer-current-node','direct-writer-siblings']){
  const run=spawnSync(runtime,[dir+'direct-map-worker.mjs',dir+variant+'.mjs',mode,scenario,'1'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
  if(run.status!==0)throw Error(run.stderr||run.stdout);
  const row={runtime,variant,...JSON.parse(run.stdout)};rows.push(row);pair.push(row);
 }
 assert.equal(pair[0].hash,pair[1].hash);
}
writeFileSync(dir+'direct-writer-siblings-smoke.json',JSON.stringify(rows,null,2));
console.log('16 complete-document observations, eight matching pairs; diagnostic timings ignored.');
