import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
const dir='.tmp/ssr-large-profile/';
const entry=dir+'direct-writer-siblings-audit-entry.mjs';
writeFileSync(entry,readFileSync(dir+'direct-writer-siblings.mjs','utf8')+'\nexport {renderDirectWriter,createSsrContext};\n');
const {renderDirectWriter,createSsrContext}=await import(pathToFileURL(resolve(entry)));
const rows=[];
for(const pending of [false,true])for(const fail of [false,true]){
 const context=createSsrContext({markers:false});
 const trace=[];let dispose=0,release;
 const gate=new Promise(resolve=>release=resolve);
 const first={name:'first'},second={name:'second'};
 const failure=new Error('second failed');
 const invocation={program:{ssrHost:'html',ssr(ops,ctx,unused,output){
  output.preparation=output.prepareReferences([first,second]);
  ops.static(output,'<html>');
  const one=ops.component(ctx,output,first,'1',0,true);
  const next=()=>{
   const two=ops.component(ctx,output,second,'2',0,true);
   const finish=()=>{ops.static(output,'</html>');return output;};
   return two instanceof Promise?two.then(finish):finish();
  };
  return one instanceof Promise?one.then(next):next();
 }}};
 const rendering=Promise.resolve().then(()=>renderDirectWriter(context,invocation,reference=>{
  trace.push('render:'+reference.name);
  if(reference===first)return pending?gate.then(()=> 'one'):'one';
  if(fail)throw failure;
  return 'two';
 },references=>{
  for(const reference of references)trace.push('prepare:'+reference.name);
  return {async [Symbol.asyncDispose](){dispose++;trace.push('dispose');}};
 }));
 await Promise.resolve();
 if(pending){assert.deepEqual(trace,['prepare:first','prepare:second','render:first']);assert.equal(dispose,0);release();}
 if(fail)await assert.rejects(rendering,error=>error===failure);
 else assert.equal(await rendering,'<!doctype html><html>onetwo</html>');
 assert.equal(dispose,1);assert.deepEqual(context.hostStack,[]);
 assert.deepEqual(trace,['prepare:first','prepare:second','render:first','render:second','dispose']);
 rows.push({pending,fail,trace,dispose,hostDepth:context.hostStack.length});
}
writeFileSync(dir+'direct-writer-siblings-audit-'+(process.versions.bun?'bun':'node')+'.json',JSON.stringify(rows,null,2));
console.log(JSON.stringify(rows));
