import pathlib,json,hashlib,zipfile
d=pathlib.Path('.tmp/ssr-large-profile')
for runtime in ['node','bun']:
 rows=json.loads((d/f'direct-writer-siblings-audit-{runtime}.json').read_text(encoding='utf-8'))
 assert len(rows)==4 and all(r['dispose']==1 and r['hostDepth']==0 for r in rows)
rows=json.loads((d/'direct-writer-siblings-smoke.json').read_text(encoding='utf-8'))
assert len(rows)==16
for i in range(0,len(rows),2):assert rows[i]['hash']==rows[i+1]['hash']
files=[d/n for n in ['direct-writer-current-node.mjs','direct-writer-siblings.mjs','direct-writer-siblings-build.mjs','direct-writer-siblings-build.json','direct-writer-siblings-audit.mjs','direct-writer-siblings-audit-node.json','direct-writer-siblings-audit-bun.json','direct-writer-siblings-smoke.mjs','direct-writer-siblings-smoke.json','direct-map-worker.mjs','direct-writer-siblings-report.py']]
files += [pathlib.Path('.tmp/positional-leaves/data.json'),pathlib.Path('docs/performance-baselines/direct-writer-siblings-2026-09-09.md')]
manifest={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=pathlib.Path('docs/performance-baselines/direct-writer-siblings-2026-09-09-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p).replace('\\','/'))
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified eight scope checks, eight document pairs, and archive hashes.')
