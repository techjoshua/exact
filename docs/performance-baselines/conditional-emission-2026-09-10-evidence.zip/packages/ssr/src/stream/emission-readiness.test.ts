import { expect, it } from 'vitest';
import { createProgressiveHtmlStream } from './creation.js';
import { produceProgressiveHtml } from './production.js';

it('completes a ready writer directly and retains actual writer pressure', async () => {
	const written: string[] = [];
	let release!: () => void;
	const pressure = new Promise<void>((resolve) => {
		release = resolve;
	});
	let blocked: void | Promise<void>;
	const rendering = produceProgressiveHtml(
		async (_options, emit) => {
			expect(emit({ event: 'head', version: 1, html: '<head></head>' })).toBeUndefined();
			blocked = emit({ event: 'shell', version: 1, html: '<main>Ready</main>' });
			expect(blocked).toBeInstanceOf(Promise);
			await blocked;
		},
		{},
		(chunk) => {
			written.push(chunk);
			if (written.length === 2) return pressure;
		},
		new AbortController().signal
	);
	try {
		expect(written).toEqual(['<head></head>', '<div id="exact-root"><main>Ready</main></div>']);
	} finally {
		release();
	}
	await rendering;
});

it('uses available reader demand directly and waits for the next reader', async () => {
	const head = '<!doctype html><html><head></head>';
	let headPending: boolean | undefined;
	let bodyPending: boolean | undefined;
	const stream = createProgressiveHtmlStream(async (_options, emit) => {
		await emit({ event: 'start', version: 1 });
		headPending = emit({ event: 'head', version: 1, html: head }) instanceof Promise;
		const body = emit({ event: 'shell', version: 1, html: head + '<body>Ready</body></html>' });
		bodyPending = body instanceof Promise;
		await body;
		await emit({ event: 'complete', version: 1 });
	}, {});
	const reader = stream.getReader();
	try {
		const first = await reader.read();
		expect(new TextDecoder().decode(first.value)).toBe(head);
		expect(headPending).toBe(false);
		expect(bodyPending).toBe(true);
		let tail = '';
		for (;;) {
			const chunk = await reader.read();
			if (chunk.done) break;
			tail += new TextDecoder().decode(chunk.value);
		}
		expect(tail).toBe('<body>Ready</body></html>');
	} finally {
		await reader.cancel();
		reader.releaseLock();
	}
});
