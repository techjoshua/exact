import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';
let code=fs.readFileSync(root+'completed-html-result-integrated/server-entry.js','utf8');
assert.equal(createHash('sha256').update(code).digest('hex'),'9093d5a3f3fdc1df26aa016be083964eace4f50ddb87766312e813331dd235b3');
function replace(from,to){assert.equal(code.split(from).length,2);code=code.replace(from,to);}
replace('function operationResult(html) {\n\treturn {\n\t\thtml,\n\t\ttext: false\n\t};\n}', 'const emptyChildResult=Object.freeze({html:"",text:false});\nfunction operationResult(html) {\n return html === "" ? emptyChildResult : {html,text:false};\n}');
replace('if (value === null || value === void 0 || value === false || value === true) return {\n\t\thtml: "",\n\t\ttext: false\n\t};','if (value === null || value === void 0 || value === false || value === true) return emptyChildResult;');
fs.mkdirSync(root+'empty-child-result',{recursive:true});
fs.writeFileSync(root+'empty-child-result/server-entry.js',code);
