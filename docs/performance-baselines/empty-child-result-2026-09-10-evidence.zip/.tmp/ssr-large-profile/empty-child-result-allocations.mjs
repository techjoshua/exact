import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root='.tmp/ssr-large-profile/';
const rows=[];
for(const scenario of ['small','large'])for(let round=0;round<2;round++)for(const variant of round?['candidate','current']:['current','candidate']) {
 const entry=root+(variant==='current'?'completed-html-result-integrated':'empty-child-result')+'/server-entry.js';
 const profile=root+`empty-child-result-${variant}-${scenario}-${round}.heapprofile`;
 const run=spawnSync('node',[root+'direct-child-boundary-allocation-worker.mjs',entry,scenario,profile],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 assert.equal(run.status,0,run.stderr+run.stdout);
 const row={variant,round,...JSON.parse(run.stdout)};
 const peer=rows.find(r=>r.scenario===scenario);if(peer)assert.equal(row.hash,peer.hash);
 let bytes=0;const sites=new Map();
 function visit(node){bytes+=node.selfSize;const key=node.callFrame.functionName;sites.set(key,(sites.get(key)??0)+node.selfSize);for(const child of node.children??[])visit(child);}
 visit(JSON.parse(fs.readFileSync(profile)).head);
 row.estimatedBytesPerRender=bytes/row.iterations;
 row.sites=[...sites.entries()].sort((a,b)=>b[1]-a[1]).map(([name,bytes])=>({name,bytesPerRender:bytes/row.iterations}));
 rows.push(row);fs.writeFileSync(root+'empty-child-result-allocations.json',JSON.stringify(rows,null,2));
 console.log(variant,scenario,round,row.estimatedBytesPerRender.toFixed(1));
}
