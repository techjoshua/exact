import {PublicationByteSink} from './publication-byte-sink.mjs';
import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import * as runtime from './direct-publication/entry.mjs';
import * as fixture from './direct-publication/fixture.mjs';
const rows=[];
for(const abort of [false,true]){
 fixture.reset();const events=[];let pending='',closed=false;
 const sink=new PublicationByteSink((bytes,reason)=>events.push({reason,text:new TextDecoder().decode(bytes)}),{threshold:8192,maxBytes:1024});
 const controller=new AbortController(),options={markers:false,signal:controller.signal};
 const context=runtime.createSsrContext(options);context.experimentalSink=sink;
 const target=new runtime.SsrOperationTarget(context,undefined,options,false,runtime.renderChildren);
 const refs=[1,2].map(index=>runtime.createPreparedServerComponentReference(fixture.ScheduledChild,{index}));
 const head={program:{ssrHost:'head',ssr(ops,ctx,invocation,out){ops.static(out,'<head><link rel="stylesheet" href="/app.css"></head>');return out;}}};
 const parent=runtime.createPreparedServerRenderProgram(runtime.prepareCompiledRenderProgram({version:1,id:'publication-root',namespace:'html',ssrHost:'html',ssr(ops,ctx,invocation,out){
  out.preparation=out.prepareReferences(refs);
  ops.static(out,'<html>');
  runtime.renderDirectWriter(ctx,head,()=>{throw Error('static head has no children');});
  ops.static(out,'<body>');
  const first=ops.component(ctx,out,refs[0],'1',0,true);
  const second=()=>{
   const value=ops.component(ctx,out,refs[1],'2',0,true);
   const finish=()=>{ops.static(out,'</body></html>');return out;};
   return value instanceof Promise?value.then(finish):finish();
  };
  return first instanceof Promise?first.then(second):second();
 }}),[]);
 const rendering=Promise.resolve(target.renderPreparedServerProgram(parent));
 let timer;
 try{
  for(let i=0;i<15;i++)await Promise.resolve();
  assert.equal(fixture.starts,2);
  assert.deepEqual(events,[{reason:'head',text:'<!doctype html><html><head><link rel="stylesheet" href="/app.css"></head>'},{reason:'await',text:'<body>'}]);
  const early=events.map(e=>({...e}));
  if(abort){
   controller.abort();
   await assert.rejects(Promise.race([rendering,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('abort hung')),2000);})]),error=>error.name==='AbortError');
   sink.destroy();
   assert.deepEqual(events,early);
  }else{
   fixture.settle();await rendering;sink.finish();
   assert.equal(events.map(e=>e.text).join(''),'<!doctype html><html><head><link rel="stylesheet" href="/app.css"></head><body><strong>Ready 1</strong><strong>Ready 2</strong></body></html>');
  }
  assert.deepEqual([...fixture.disposedIndices].sort(),[1,2]);assert.deepEqual(context.hostStack,[]);
  rows.push({abort,early,events,disposedIndices:fixture.disposedIndices});
 }finally{clearTimeout(timer);fixture.settle();sink.destroy();}
}
writeFileSync('.tmp/ssr-large-profile/direct-publication/bytes-'+(process.versions.bun?'bun':'node')+'.json',JSON.stringify(rows,null,2));
console.log(JSON.stringify(rows));
