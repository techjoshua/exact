import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {PublicationByteSink} from './publication-byte-sink.mjs';
const text='<html><head>caf\u00e9\ud83d\ude80</head><body>\u65e5\u672c\u8a9e\ud800x\udc00</body></html>';
const expected=Buffer.from(text),rows=[];
for(const threshold of [1,2,3,4,8,2048,8192])for(let split=0;split<=text.length;split++){
 const chunks=[];const sink=new PublicationByteSink(bytes=>chunks.push(bytes),{threshold,maxBytes:expected.length});
 sink.write(text.slice(0,split));sink.flush('head');sink.write(text.slice(split));
 assert.equal(sink.finish(),expected.length);assert.deepEqual(Buffer.concat(chunks),expected);
 assert.equal(sink.pendingCharacters,0);assert.throws(()=>sink.write('late'),/closed/);
 rows.push({threshold,split,bytes:expected.length});
}
for(const threshold of [1,8192]){
 const sink=new PublicationByteSink(()=>{}, {threshold,maxBytes:3});
 sink.write('\ud83d');assert.throws(()=>sink.write('\ude80'),/limit/i);
 assert.equal(sink.pendingCharacters,0);assert.throws(()=>sink.flush(),/closed/);
}
const tail=new PublicationByteSink(()=>assert.fail('over-budget tail published'),{maxBytes:2});
tail.write('\ud800');assert.throws(()=>tail.finish(),/limit/i);assert.equal(tail.pendingCharacters,0);
const failure=new Error('transport failed');
const throwing=new PublicationByteSink(()=>{throw failure;},{threshold:1});
assert.throws(()=>throwing.write('data'),error=>error===failure);assert.equal(throwing.pendingCharacters,0);
const destroyed=new PublicationByteSink(()=>assert.fail('destroyed sink published'));
destroyed.write('pending');destroyed.destroy();destroyed.destroy();assert.equal(destroyed.pendingCharacters,0);
writeFileSync('.tmp/ssr-large-profile/publication-byte-sink-'+(process.versions.bun?'bun':'node')+'.json',JSON.stringify({splits:rows.length,rows,limitAndDisposalChecks:'passed'},null,2));
console.log(rows.length+' Unicode/threshold split cases plus limit and disposal checks passed');
