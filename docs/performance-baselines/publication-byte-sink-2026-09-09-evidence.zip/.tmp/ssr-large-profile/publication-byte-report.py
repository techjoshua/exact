import pathlib,json,hashlib,zipfile
d=pathlib.Path('.tmp/ssr-large-profile')
for runtime in ['node','bun']:
 r=json.loads((d/f'publication-byte-sink-{runtime}.json').read_text(encoding='utf-8'));assert r['splits']==364
 r=json.loads((d/f'direct-publication/bytes-{runtime}.json').read_text(encoding='utf-8'));assert len(r)==2
files=[d/n for n in ['publication-byte-sink.mjs','publication-byte-sink-audit.mjs','publication-byte-sink-node.json','publication-byte-sink-bun.json','publication-byte-integration-build.mjs','publication-byte-integration-audit.mjs','publication-byte-report.py','direct-publication/entry.mjs','direct-publication/fixture.mjs','direct-publication/bytes-node.json','direct-publication/bytes-bun.json']]
files += [pathlib.Path(n) for n in ['packages/ssr/src/render/output-buffer.ts','packages/ssr/src/render/utf8.ts','packages/ssr/src/render/utf8-encoding.ts','docs/performance-baselines/publication-byte-sink-2026-09-09.md']]
manifest={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=pathlib.Path('docs/performance-baselines/publication-byte-sink-2026-09-09-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p).replace('\\','/'))
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified 728 split cases, four integration cases, and archive hashes.')
