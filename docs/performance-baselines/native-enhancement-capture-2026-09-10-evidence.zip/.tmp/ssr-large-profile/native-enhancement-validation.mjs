import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/',rows=[];
for(const [runtime,script] of [
 ['node','native-sink-application-link.mjs'],
 ['node','native-sink-fixture-build.mjs'],
 ['node','native-enhancement-build.mjs'],
 ['node','native-enhancement-audit.mjs'],['bun','native-enhancement-audit.mjs'],
 ['node','native-enhancement-budget.mjs'],['bun','native-enhancement-budget.mjs'],
 ['node','native-sink-adoption.mjs'],
]){
 const result=spawnSync(runtime,[d+script],{encoding:'utf8',windowsHide:true,maxBuffer:16*1024*1024});
 rows.push({runtime,script,status:result.status,stdout:result.stdout,stderr:result.stderr});
 fs.writeFileSync(d+'native-enhancement-validation.json',JSON.stringify(rows,null,2));
 console.log(runtime,script,result.status);
 assert.equal(result.status,0,result.stderr+result.stdout);
}
assert.equal(fs.readFileSync(d+'native-sink-application.mjs','utf8'),fs.readFileSync(d+'native-enhancement-application.mjs','utf8'));
console.log('Retained candidate exactly matches the measured artifact.');
