import fs from 'node:fs';
import assert from 'node:assert/strict';
import {PublicationStringSink} from './application-string-deferred-sink.mjs';
const d='.tmp/ssr-large-profile/enhancement-native/';
const rows=[];
for(const markers of [false,true])for(const name of ['Direct','Fragment','Nested','Routed','Forwarded','ForwardedNested','Pending','failure','abort']){
  let control;
  for(const variant of ['control','candidate']){
    const runtime=await import(`./enhancement-native/${variant}-entry.mjs`);
    const page=await import(`./enhancement-native/${variant}-page.mjs`);
    const enhancement=await import(`./enhancement-native/${variant}-implementation.mjs`);
    page.reset();enhancement.reset();
    const controller=new AbortController();
    const options={markers,signal:controller.signal,enhancementCatalog:new Map([[page.enhancementIdentity,enhancement.Panel],[page.fieldIdentity,enhancement.Field]])};
    const capture=runtime.createSsrResumptionCapture(options),context=runtime.createSsrContext(capture.options);
    const sink=new PublicationStringSink();if(variant==='candidate')context.experimentalSink=sink;
    const root=runtime.createPreparedServerComponentReference(page[['failure','abort'].includes(name)?'Pending':name],{fail:name==='failure'});
    const target=new runtime.SsrOperationTarget(context,undefined,capture.options,false,runtime.renderChildren);
    let html,error;
    const pending=Promise.resolve().then(()=>target.renderCompilerClosedRootComponent(root));
    // Observe rejection immediately while controlling the real scheduled child gate.
    const observed=pending.then(value=>{html=value;},reason=>{error={name:reason.name,message:reason.message};});
    try{
      if(['Pending','failure','abort'].includes(name)){
        for(let i=0;i<300&&page.setups===0;i++)await Promise.resolve();
        assert.equal(page.setups,1,'scheduled target must start');
        if(variant==='candidate')assert.equal(sink.value,'','enhanced markup must remain unpublished until its target completes');
        if(name==='abort')controller.abort();else page.settle();
      }else page.settle();
      await observed;
      if(!error&&variant==='candidate'){if(html)sink.write(html);sink.finish();html=sink.value;}
      const result={name,markers,html,error,setups:page.setups,disposals:page.disposals,enhancers:enhancement.starts,enhancerDisposals:enhancement.disposals,records:capture.serializedRecords()};
      assert.deepEqual(context.hostStack,[]);
      assert.equal(context.enhancementOperationRoutes?.length??0,0);
      assert.equal(context.targetReceiptLayers?.length??0,0);
      if(variant==='candidate')assert.equal(context.experimentalSink,sink,'capture restores caller sink');
      assert.equal(result.disposals,result.setups);assert.equal(result.enhancerDisposals,result.enhancers);
      if(variant==='control')control=result;else assert.deepEqual(result,control);
      rows.push({variant,...result});console.log(variant,markers,name,error?.name??html);
    }finally{controller.abort();page.settle();sink.destroy();}
  }
}
fs.writeFileSync(d+`audit-${process.versions.bun?'bun':'node'}.json`,JSON.stringify(rows,null,2));
