import assert from 'node:assert/strict';

/** Isolates markup that enhancements may rearrange before publishing it to the caller. */
export function installEnhancementCapture(runtime) {
  const guard=" if(context.enhancementOperationRoutes?.length)throw Error('Prototype needs explicit enhancement capture');";
  assert.equal(runtime.split(guard).length,2);
  runtime=runtime.replace(guard,'');
  const signature='function renderOperationEnhancements(context, enhancement, renderPlain, parent, options, renderChildren, plainOperation) {';
  assert.equal(runtime.split(signature).length,2);
  return runtime.replace(signature,signature+`
 if(enhancement&&context.experimentalSink){
  const sink=context.experimentalSink;context.experimentalSink=undefined;
  return withRenderCleanup(()=>renderOperationEnhancements(context,enhancement,renderPlain,parent,options,renderChildren,plainOperation),()=>{context.experimentalSink=sink;});
 }
`);
}
