import type {Child,Component,AnyAuthoredComponentFunction} from '@exactjs/core';
declare const _target:AnyAuthoredComponentFunction;
export let starts=0,disposals=0;
export function reset(){starts=0;disposals=0;}
export function Panel(this:Component<{}>,props:{panel?:true;children?:Child|Child[]}){
 starts++;this.onUnmount(()=>{disposals++;});return ()=><aside data-enhanced>{props.children}</aside>;
}
export function Field(this:Component<{}>,props:{field?:true;children?:Child|Child[]}){
 starts++;this.onUnmount(()=>{disposals++;});return ()=><label><span>Account</span><_target className="control" aria-describedby="description">{props.children}</_target><small id="description">Help</small></label>;
}