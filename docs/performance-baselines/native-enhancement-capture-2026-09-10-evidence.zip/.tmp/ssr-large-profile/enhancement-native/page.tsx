import {TaskContext,type Component} from '@exactjs/core';
import * as wrap from './enhancements.js' with {type:'exact-enhancement'};
export let setups=0,disposals=0;
let release:()=>void;let gate:Promise<void>;
export function reset(){setups=0;disposals=0;gate=new Promise<void>(resolve=>release=resolve);}
export function settle(){release();}
function Target(this:Component<{}>){setups++;this.onUnmount(()=>{disposals++;});return ()=><main wrap:panel wrap:root>Target</main>;}
function Boundary(){return ()=><><header>Prefix</header><Target/></>;}
export function Routed(){return ()=><Boundary wrap:panel/>;}
export function Direct(){return ()=><button wrap:panel>Save</button>;}
export function Fragment(){return ()=><_ wrap:panel>Before<strong>After</strong></_>;}
export function Nested(){return ()=><section wrap:panel>Outer<button wrap:panel>Inner</button>Tail</section>;}
export function Forwarded(){return ()=><button wrap:field className="original" aria-describedby="original-help">Save</button>;}
export function ForwardedNested(){return ()=><section wrap:panel>Before<button wrap:field>Save</button>After</section>;}
function Scheduled(this:Component<{value:string}>,props:{fail?:boolean}){
 setups++;this.state.value='Waiting';this.onUnmount(()=>{disposals++;});
 const load=async(_task:TaskContext=TaskContext.server().blocking())=>{await gate;if(props.fail)throw Error('scheduled failure');this.state.value='Ready';};load();
 return ()=><button>{this.state.value}</button>;
}
export function Pending(props:{fail?:boolean}){return ()=><article wrap:panel>Before<Scheduled fail={props.fail}/>After</article>;}
