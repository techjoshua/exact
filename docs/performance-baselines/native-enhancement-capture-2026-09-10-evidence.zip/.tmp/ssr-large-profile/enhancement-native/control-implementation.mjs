import { createPreparedServerRenderProgram as __exactPreparedServerRenderProgram, prepareCompiledRenderProgram as __exactPrepareRenderProgram, createCompiledChildRangeReceipt as __exactDynamic } from "@exactjs/core/framework/server-render-structure";
import { registerDirectSsrLifecycleHandler as __exactRegisterDirectSsrLifecycle } from "@exactjs/ssr/runtime/direct-lifecycle";
import { createCompiledTargetReceipt as __exactTarget } from "@exactjs/core/runtime/component-operations";
import { issueExactServerComponent as __exactIssueServerComponent_1, writeExactServerComponent as __exactWriteServerComponent_1, disposeExactServerComponent as __exactDisposeServerComponent_1 } from "@exactjs/core/runtime/component-operations";
import { rejectDirectServerComponentConstruction as __exactRejectDirectServerConstruction_1 } from "@exactjs/core/runtime/component-construction/direct-server";
import { directSsrLifecycle as __exactDirectSsrLifecycle_1 } from "@exactjs/ssr/runtime/direct-lifecycle";
const __exactComponentContract_1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
const __exact_render_program_1 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xfzaAnTVhEUmbQexv6sF-BL", namespace: "html", ssrRootStatic: ["", [], [[0, "data-enhanced", "data-enhanced"]], (__exactRootValue) => ({ "data-enhanced": __exactRootValue })], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
  const __exactValue_0 = __exactInvocation.eagerValues[0];
  const __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
  if (__exactValue_1 === __exactSsr.unprepared)
    return;
  __exactSsr.begin(__exactContext, 1, 2, 15, 15);
  const __exactOutput = __exactSsr.output();
  let __exactCharacters = 15;
  __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "aside", "<aside", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
  __exactSsr.keyedChild(__exactOutput, __exactValue_1);
  __exactSsr.static(__exactOutput, "</aside>");
  return __exactOutput;
}, ssrHost: "aside" });
const __exact_render_program_2 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xeA_zvspTvREZ9_vjFNX1sF", namespace: "html", ssrRootStatic: ["", [], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
  const __exactValue_0 = __exactInvocation.eagerValues[0];
  const __exactValue_1 = __exactSsr.prepareChild(__exactInvocation, 1);
  if (__exactValue_1 === __exactSsr.unprepared)
    return;
  __exactSsr.begin(__exactContext, 3, 2, 71, 71);
  const __exactOutput = __exactSsr.output();
  let __exactCharacters = 71;
  __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "label", "<label", "><span>Account</span>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
  __exactCharacters = __exactSsr.child(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters);
  __exactSsr.static(__exactOutput, '<small id="description">Help</small></label>');
  return __exactOutput;
}, ssrHost: "label" });
let starts = 0, disposals = 0;
function reset() {
  starts = 0;
  disposals = 0;
}
const __exactImplementation_Panel_1 = function Panel(props) {
  starts++;
  __exactRegisterDirectSsrLifecycle(this, "unmount", () => {
    disposals++;
  });
  return __exactPreparedServerRenderProgram(__exact_render_program_1, [true, props.children]);
};
const Panel2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Panel_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "xcbR5E7U4toPV4OFZArKrK9",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "executor",
    implementations: [
      { id: "xodc8ni7-5wI9ghCEgdEU2C", name: "Panel", role: "root", implementation: __exactImplementation_Panel_1 }
    ],
    continuations: [],
    executors: [],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "xcbR5E7U4toPV4OFZArKrK9",
      instantiate: __exactImplementation_Panel_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 3,
      capabilities: [],
      state: [],
      props: [
        "children"
      ],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "synchronous",
        lane: "direct",
        render: __exactImplementation_Panel_1,
        mode: "direct",
        lifecycle: __exactDirectSsrLifecycle_1
      },
      tasks: [],
      reactive: [
        {
          name: "props",
          provenance: "props",
          allocation: "live-slot",
          dependencies: []
        },
        {
          name: "this",
          provenance: "state",
          allocation: "live-slot",
          dependencies: []
        }
      ],
      render: "returned-function"
    }
  }
}))();
const __exactImplementation_Field_1 = function Field(props) {
  starts++;
  __exactRegisterDirectSsrLifecycle(this, "unmount", () => {
    disposals++;
  });
  return __exactPreparedServerRenderProgram(__exact_render_program_2, [{}, __exactTarget({ className: "control", "aria-describedby": "description" }, __exactDynamic(() => props.children, "xkJ47wW-mQI-3ZBzbZ6P45M"))]);
};
const Field2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Field_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "xj7jbt5hHe0ILT_gPz3pddf",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "executor",
    implementations: [
      { id: "xW-nZ9IUtfl2Z3GaIKeGOTJ", name: "Field", role: "root", implementation: __exactImplementation_Field_1 }
    ],
    continuations: [],
    executors: [],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "xj7jbt5hHe0ILT_gPz3pddf",
      instantiate: __exactImplementation_Field_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 3,
      capabilities: [
        "targets"
      ],
      state: [],
      props: [
        "children"
      ],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "synchronous",
        lane: "direct",
        render: __exactImplementation_Field_1,
        mode: "direct",
        lifecycle: __exactDirectSsrLifecycle_1
      },
      tasks: [],
      reactive: [
        {
          name: "props",
          provenance: "props",
          allocation: "live-slot",
          dependencies: []
        },
        {
          name: "this",
          provenance: "state",
          allocation: "live-slot",
          dependencies: []
        }
      ],
      render: "returned-function"
    }
  }
}))();
export {
  Field2 as Field,
  Panel2 as Panel,
  disposals,
  reset,
  starts
};
