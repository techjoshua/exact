import {issueServerComponentReceipt as __exactIssueServerComponent} from './control-entry.mjs';
import { createPreparedServerComponentReference as __exactComponentReceipt, createPreparedServerRenderProgram as __exactPreparedServerRenderProgram, prepareCompiledRenderProgram as __exactPrepareRenderProgram, createCompiledChildRangeReceipt as __exactDynamic } from "@exactjs/core/framework/server-render-structure";
import { createEnhancementNode as __exactEnhancements } from "@exactjs/core/runtime/enhancements";
import { registerDirectSsrLifecycleHandler as __exactRegisterDirectSsrLifecycle } from "@exactjs/ssr/runtime/direct-lifecycle";
import { createCompiledIntrinsicReceipt as __exactIntrinsicReceipt, createCompiledFragmentReceipt as __exactFragment } from "@exactjs/core/runtime/component-operations";
import { awaitServerComponentTask as __exactServerTaskAwait, activateServerComponentTaskForHost as __exactActivateServerTask } from "@exactjs/core/framework/server-component-execution";
import "@exactjs/ssr/runtime/resumption-boundaries";
import { issueExactServerComponent as __exactIssueServerComponent_1, writeExactServerComponent as __exactWriteServerComponent_1, disposeExactServerComponent as __exactDisposeServerComponent_1 } from "@exactjs/core/runtime/component-operations";
import { rejectDirectServerComponentConstruction as __exactRejectDirectServerConstruction_1 } from "@exactjs/core/runtime/component-construction/direct-server";
import { directSsrLifecycle as __exactDirectSsrLifecycle_1 } from "@exactjs/ssr/runtime/direct-lifecycle";
const __exactComponentContract_1 = /* @__PURE__ */ Symbol.for("@exactjs/component-contract");
const __exact_server_task_slice_1 = [[-1], [[1, ["value"]]], "blocking", "load"];
const __exact_render_program_1 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xgahZBQ1nYSLBv3Ab709Ig0", namespace: "html", ssrRootStatic: ["", [], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
  const __exactValue_0 = __exactInvocation.eagerValues[0];
  __exactSsr.begin(__exactContext, 1, 1, 23, 23);
  const __exactOutput = __exactSsr.output();
  let __exactCharacters = 23;
  __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "header", "<header", ">Prefix</header>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
  return __exactOutput;
}, ssrHost: "header" });
const __exact_render_program_2 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "x_VRON0F9jVgP5jM9xynSf1", namespace: "html", ssrRootStatic: ["", [], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
  const __exactValue_0 = __exactInvocation.eagerValues[0];
  __exactSsr.begin(__exactContext, 1, 1, 22, 22);
  const __exactOutput = __exactSsr.output();
  let __exactCharacters = 22;
  __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "strong", "<strong", ">After</strong>", __exactCharacters, __exactInvocation.program.ssrRootStatic);
  return __exactOutput;
}, ssrHost: "strong" });
const __exact_render_program_3 = /* @__PURE__ */ __exactPrepareRenderProgram({ version: 1, id: "xNy2R87cq0ExsohUkW6ztMM", namespace: "html", ssrRootStatic: ["", [], []], ssr: (__exactSsr, __exactContext, __exactInvocation) => {
  const __exactValue_0 = __exactInvocation.eagerValues[0];
  const __exactValue_1 = __exactSsr.prepareText(__exactInvocation, 1);
  if (__exactValue_1 === __exactSsr.unprepared)
    return;
  __exactSsr.begin(__exactContext, 1, 2, 17, 17);
  const __exactOutput = __exactSsr.output();
  let __exactCharacters = 17;
  __exactCharacters = __exactSsr.rootOpening(__exactContext, __exactOutput, __exactValue_0, "button", "<button", ">", __exactCharacters, __exactInvocation.program.ssrRootStatic);
  __exactCharacters = __exactSsr.text(__exactContext, __exactOutput, __exactValue_1, "0", __exactCharacters, true, "", "</button>");
  return __exactOutput;
}, ssrHost: "button" });
;
let setups = 0, disposals = 0;
let release;
let gate;
function reset() {
  setups = 0;
  disposals = 0;
  gate = new Promise((resolve) => release = resolve);
}
function settle() {
  release();
}
const __exactImplementation_Target_1 = function Target() {
  setups++;
  __exactRegisterDirectSsrLifecycle(this, "unmount", () => {
    disposals++;
  });
  return __exactIntrinsicReceipt("main", { "data-exact-id": "xtaWzeTo4ADgkpLDJn7jREn", __exactEnhancements: __exactEnhancements([{ identity: "./enhancements.js#panel", props: { panel: true }, root: true }]) }, "Target");
};
const Target2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Target_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "x5xFAPvPJcv3iRxdLAlRptN",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "executor",
    implementations: [
      { id: "xq804NISSbOL7vzYHq50Z1g", name: "Target", role: "root", implementation: __exactImplementation_Target_1 }
    ],
    continuations: [],
    executors: [],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "x5xFAPvPJcv3iRxdLAlRptN",
      instantiate: __exactImplementation_Target_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 3,
      capabilities: [],
      state: [],
      props: [],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "synchronous",
        lane: "direct",
        render: __exactImplementation_Target_1,
        mode: "direct",
        lifecycle: __exactDirectSsrLifecycle_1
      },
      tasks: [],
      reactive: [
        {
          name: "this",
          provenance: "state",
          allocation: "live-slot",
          dependencies: []
        }
      ],
      render: "returned-function"
    }
  }
}))();
const __exactImplementation_Boundary_1 = function Boundary() {
  return __exactFragment({}, __exactPreparedServerRenderProgram(__exact_render_program_1, [{}]), __exactDynamic(() => __exactComponentReceipt(Target2, {}), "xibBmp5fGkunLJmgGaN9NbX"));
};
const Boundary2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Boundary_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "xIHep-C4tjJ6sn_VsYhpJYv",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "executor",
    implementations: [
      { id: "xHYlaBSeTionpZoSWF3VMYz", name: "Boundary", role: "root", implementation: __exactImplementation_Boundary_1 }
    ],
    continuations: [],
    executors: [],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "xIHep-C4tjJ6sn_VsYhpJYv",
      instantiate: __exactImplementation_Boundary_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 1,
      capabilities: [],
      state: [],
      props: [],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "synchronous",
        lane: "direct",
        render: __exactImplementation_Boundary_1,
        mode: "stateless"
      },
      tasks: [],
      reactive: [],
      render: "returned-function"
    }
  }
}))();
const __exactImplementation_Routed_1 = function Routed() {
  return __exactComponentReceipt(Boundary2, { __exactEnhancements: __exactEnhancements([{ identity: "./enhancements.js#panel", props: { panel: true } }]) });
};
const Routed2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Routed_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "xFaYjmAaC1ll6S6nYM4Bb0f",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "executor",
    implementations: [
      { id: "xSImhzAukOzpNO3-NoiZS2T", name: "Routed", role: "root", implementation: __exactImplementation_Routed_1 }
    ],
    continuations: [],
    executors: [],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "xFaYjmAaC1ll6S6nYM4Bb0f",
      instantiate: __exactImplementation_Routed_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 1,
      capabilities: [],
      state: [],
      props: [],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "synchronous",
        lane: "direct",
        render: __exactImplementation_Routed_1,
        mode: "stateless"
      },
      tasks: [],
      reactive: [],
      render: "returned-function"
    }
  }
}))();
const __exactImplementation_Direct_1 = function Direct() {
  return __exactIntrinsicReceipt("button", { "data-exact-id": "xr1w6qYRNzIpk8zVCJwkmSm", __exactEnhancements: __exactEnhancements([{ identity: "./enhancements.js#panel", props: { panel: true } }]) }, "Save");
};
const Direct2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Direct_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "xNoBP01U6klfEQNBckypeDe",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "executor",
    implementations: [
      { id: "x_pr7KTnO9-XSGA2Nwru0-g", name: "Direct", role: "root", implementation: __exactImplementation_Direct_1 }
    ],
    continuations: [],
    executors: [],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "xNoBP01U6klfEQNBckypeDe",
      instantiate: __exactImplementation_Direct_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 1,
      capabilities: [],
      state: [],
      props: [],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "synchronous",
        lane: "direct",
        render: __exactImplementation_Direct_1,
        mode: "stateless"
      },
      tasks: [],
      reactive: [],
      render: "returned-function"
    }
  }
}))();
const __exactImplementation_Fragment_1 = function Fragment() {
  return __exactFragment({ __exactEnhancements: __exactEnhancements([{ identity: "./enhancements.js#panel", props: { panel: true } }]) }, "Before", __exactPreparedServerRenderProgram(__exact_render_program_2, [{}]));
};
const Fragment2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Fragment_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "xNGsKbq3b0XGHaRGvA69so1",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "executor",
    implementations: [
      { id: "xZuZwGaSrT3qKP_mFuSpFA6", name: "Fragment", role: "root", implementation: __exactImplementation_Fragment_1 }
    ],
    continuations: [],
    executors: [],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "xNGsKbq3b0XGHaRGvA69so1",
      instantiate: __exactImplementation_Fragment_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 1,
      capabilities: [
        "dynamic-components"
      ],
      state: [],
      props: [],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "synchronous",
        lane: "direct",
        render: __exactImplementation_Fragment_1,
        mode: "direct"
      },
      tasks: [],
      reactive: [],
      render: "returned-function"
    }
  }
}))();
const __exactImplementation_Nested_1 = function Nested() {
  return __exactIntrinsicReceipt("section", { "data-exact-id": "x80M0UZQcclwH4UGwWWbIyB", __exactEnhancements: __exactEnhancements([{ identity: "./enhancements.js#panel", props: { panel: true } }]) }, "Outer", __exactIntrinsicReceipt("button", { "data-exact-id": "x14sRXHF_a_yRvbkDgrsVKo", __exactEnhancements: __exactEnhancements([{ identity: "./enhancements.js#panel", props: { panel: true } }]) }, "Inner"), "Tail");
};
const Nested2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Nested_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "xjTTT7kKv2_qq_MlyFNvmAX",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "executor",
    implementations: [
      { id: "xEyhNpht27kOOjE2hWAvLkI", name: "Nested", role: "root", implementation: __exactImplementation_Nested_1 }
    ],
    continuations: [],
    executors: [],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "xjTTT7kKv2_qq_MlyFNvmAX",
      instantiate: __exactImplementation_Nested_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 1,
      capabilities: [],
      state: [],
      props: [],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "synchronous",
        lane: "direct",
        render: __exactImplementation_Nested_1,
        mode: "stateless"
      },
      tasks: [],
      reactive: [],
      render: "returned-function"
    }
  }
}))();
const __exactImplementation_Forwarded_1 = function Forwarded() {
  return __exactIntrinsicReceipt("button", { "data-exact-id": "xRbOIYClg5huQOCpZuppupx", className: "original", "aria-describedby": "original-help", __exactEnhancements: __exactEnhancements([{ identity: "./enhancements.js#field", props: { field: true } }]) }, "Save");
};
const Forwarded2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Forwarded_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "xyOd6zOIiGH00JHgyC9k44o",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "executor",
    implementations: [
      { id: "xdhRqwqlUJzXUhl5dZnUScW", name: "Forwarded", role: "root", implementation: __exactImplementation_Forwarded_1 }
    ],
    continuations: [],
    executors: [],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "xyOd6zOIiGH00JHgyC9k44o",
      instantiate: __exactImplementation_Forwarded_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 1,
      capabilities: [],
      state: [],
      props: [],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "synchronous",
        lane: "direct",
        render: __exactImplementation_Forwarded_1,
        mode: "stateless"
      },
      tasks: [],
      reactive: [],
      render: "returned-function"
    }
  }
}))();
const __exactImplementation_ForwardedNested_1 = function ForwardedNested() {
  return __exactIntrinsicReceipt("section", { "data-exact-id": "xitELjhVQRuPWEFc1bWxlRl", __exactEnhancements: __exactEnhancements([{ identity: "./enhancements.js#panel", props: { panel: true } }]) }, "Before", __exactIntrinsicReceipt("button", { "data-exact-id": "xic_gn86dofOF1GLBj7ZXE6", __exactEnhancements: __exactEnhancements([{ identity: "./enhancements.js#field", props: { field: true } }]) }, "Save"), "After");
};
const ForwardedNested2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_ForwardedNested_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "x4i_-nPkkdNeh73t-WVuRrv",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "executor",
    implementations: [
      { id: "xOOP29RWOi1A6nf4L63slPA", name: "ForwardedNested", role: "root", implementation: __exactImplementation_ForwardedNested_1 }
    ],
    continuations: [],
    executors: [],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "x4i_-nPkkdNeh73t-WVuRrv",
      instantiate: __exactImplementation_ForwardedNested_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 1,
      capabilities: [],
      state: [],
      props: [],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "synchronous",
        lane: "direct",
        render: __exactImplementation_ForwardedNested_1,
        mode: "stateless"
      },
      tasks: [],
      reactive: [],
      render: "returned-function"
    }
  }
}))();
const __exactImplementation_Scheduled_1 = function Scheduled(props) {
  setups++;
  this.state.value = "Waiting";
  __exactRegisterDirectSsrLifecycle(this, "unmount", () => {
    disposals++;
  });
  __exactActivateServerTask(this, __exact_server_task_slice_1, "x5NDAL-gGLckazuSl84egpK", async (__exactDependency, _task) => {
    await __exactServerTaskAwait(_task.signal, gate);
    if (__exactDependency)
      throw Error("scheduled failure");
    this.state.value = "Ready";
  }, props.fail);
  return () => __exactPreparedServerRenderProgram(__exact_render_program_3, [{}, this.state.value]);
};
const Scheduled2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Scheduled_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "xpwlncifxBEmVOemit5Ome_",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "executor",
    implementations: [
      { id: "xttK_TB9ledJCNNbOdb_SS_", name: "Scheduled", role: "root", implementation: __exactImplementation_Scheduled_1 }
    ],
    continuations: [
      {
        kind: "task",
        id: "x5NDAL-gGLckazuSl84egpK",
        componentId: "xpwlncifxBEmVOemit5Ome_",
        readiness: "blocking",
        concurrency: "latest",
        dependencies: [
          {
            index: 0,
            source: "props",
            path: "props"
          }
        ],
        stateReads: [],
        stateWrites: [
          {
            path: "value",
            kind: "write",
            confidence: "exact"
          }
        ],
        publicContexts: [],
        serverContexts: [],
        contextWrites: [],
        serverContextWrites: [],
        boundaries: []
      }
    ],
    executors: [
      {
        id: "x5NDAL-gGLckazuSl84egpK",
        componentId: "xpwlncifxBEmVOemit5Ome_",
        execute: async (__exactActivation_1, __exactExecution_1) => {
          const __exactComponent_1 = { state: __exactActivation_1.state };
          const __exactContextWrites_1 = {};
          await (async (__exactDependency, _task) => {
            await __exactServerTaskAwait(_task.signal, gate);
            if (__exactDependency)
              throw Error("scheduled failure");
            __exactComponent_1.state.value = "Ready";
          })(__exactActivation_1.dependencies[0], __exactExecution_1.task);
          return { state: __exactComponent_1.state, contexts: __exactContextWrites_1 };
        }
      }
    ],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "xpwlncifxBEmVOemit5Ome_",
      instantiate: __exactImplementation_Scheduled_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 11,
      capabilities: [
        "tasks",
        "continuations",
        "resumption"
      ],
      state: [
        "value"
      ],
      props: [
        "fail"
      ],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "scheduled",
        lane: "direct",
        deferredTaskProps: [
          "props"
        ],
        render: __exactImplementation_Scheduled_1,
        lifecycle: __exactDirectSsrLifecycle_1,
        publication: {
          kind: "resumption",
          name: "Scheduled"
        }
      },
      tasks: [
        "x5NDAL-gGLckazuSl84egpK"
      ],
      reactive: [
        {
          name: "load",
          provenance: "unknown",
          allocation: "constant",
          dependencies: []
        },
        {
          name: "props",
          provenance: "props",
          allocation: "live-slot",
          dependencies: []
        },
        {
          name: "this",
          provenance: "state",
          allocation: "live-slot",
          dependencies: []
        }
      ],
      render: "returned-function"
    },
    resumption: {
      componentId: "xpwlncifxBEmVOemit5Ome_",
      statePaths: [
        "value"
      ],
      stateInputs: [],
      valueCaptures: [],
      contexts: [],
      boundaries: [],
      stateDefaults: [
        [
          "value",
          "Waiting"
        ]
      ]
    }
  }
}))();
const __exactImplementation_Pending_1 = function Pending(props) {
  return __exactIntrinsicReceipt("article", { "data-exact-id": "xt1l2zkJ1JqEA7JLHBeXIiz", __exactEnhancements: __exactEnhancements([{ identity: "./enhancements.js#panel", props: { panel: true } }]) }, "Before", __exactDynamic(() => __exactIssueServerComponent(__exactComponentReceipt(Scheduled2, { fail: props.fail })), "xLq10vFBL2VeRw0xInBrBMb"), "After");
};
const Pending2 = /* @__PURE__ */ (() => Object.assign(__exactImplementation_Pending_1, {
  [/* @__PURE__ */ Symbol.for("@exactjs/component")]: "x9h_ClkoXpvHlKLzUB1TguR",
  [__exactComponentContract_1]: {
    version: 1,
    placement: "isomorphic",
    role: "executor",
    implementations: [
      { id: "x7MybR9GRwp0f-wRvOscTjX", name: "Pending", role: "root", implementation: __exactImplementation_Pending_1 }
    ],
    continuations: [],
    executors: [],
    boundaries: [],
    artifact: {
      version: 1,
      target: "server",
      id: "x9h_ClkoXpvHlKLzUB1TguR",
      instantiate: __exactImplementation_Pending_1,
      construct: __exactRejectDirectServerConstruction_1,
      abi: 1,
      capabilities: [],
      state: [],
      props: [
        "fail"
      ],
      issue: __exactIssueServerComponent_1,
      write: __exactWriteServerComponent_1,
      dispose: __exactDisposeServerComponent_1,
      execution: {
        version: 1,
        classification: "synchronous",
        lane: "direct",
        render: __exactImplementation_Pending_1,
        mode: "stateless"
      },
      tasks: [],
      reactive: [
        {
          name: "props",
          provenance: "props",
          allocation: "live-slot",
          dependencies: []
        }
      ],
      render: "returned-function"
    }
  }
}))();
export {
  Direct2 as Direct,
  Forwarded2 as Forwarded,
  ForwardedNested2 as ForwardedNested,
  Fragment2 as Fragment,
  Nested2 as Nested,
  Pending2 as Pending,
  Routed2 as Routed,
  disposals,
  reset,
  settle,
  setups
};

export const enhancementIdentity="./enhancements.js#panel";

export const fieldIdentity="./enhancements.js#field";
