import fs from 'node:fs';
import {resolve} from 'node:path';
import {spawnSync} from 'node:child_process';
import {transform} from 'esbuild';
import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/',dir=d+'enhancement-native/';fs.mkdirSync(dir,{recursive:true});
fs.writeFileSync(dir+'package.json',JSON.stringify({name:'@exactjs/native-sink-enhancement-audit',type:'module',private:true}));
fs.writeFileSync(dir+'tsconfig.json',JSON.stringify({compilerOptions:{target:'ES2022',module:'NodeNext',moduleResolution:'NodeNext',jsx:'preserve',jsxImportSource:'@exactjs/jsx',strict:true},include:['*.tsx','*.ts']}));
const source=`import {TaskContext,type Component} from '@exactjs/core';
import * as wrap from './enhancements.js' with {type:'exact-enhancement'};
export let setups=0,disposals=0;
let release:()=>void;let gate:Promise<void>;
export function reset(){setups=0;disposals=0;gate=new Promise<void>(resolve=>release=resolve);}
export function settle(){release();}
function Target(this:Component<{}>){setups++;this.onUnmount(()=>{disposals++;});return ()=><main wrap:panel wrap:root>Target</main>;}
function Boundary(){return ()=><><header>Prefix</header><Target/></>;}
export function Routed(){return ()=><Boundary wrap:panel/>;}
export function Direct(){return ()=><button wrap:panel>Save</button>;}
export function Fragment(){return ()=><_ wrap:panel>Before<strong>After</strong></_>;}
export function Nested(){return ()=><section wrap:panel>Outer<button wrap:panel>Inner</button>Tail</section>;}
export function Forwarded(){return ()=><button wrap:field className="original" aria-describedby="original-help">Save</button>;}
export function ForwardedNested(){return ()=><section wrap:panel>Before<button wrap:field>Save</button>After</section>;}
function Scheduled(this:Component<{value:string}>,props:{fail?:boolean}){
 setups++;this.state.value='Waiting';this.onUnmount(()=>{disposals++;});
 const load=async(_task:TaskContext=TaskContext.server().blocking())=>{await gate;if(props.fail)throw Error('scheduled failure');this.state.value='Ready';};load();
 return ()=><button>{this.state.value}</button>;
}
export function Pending(props:{fail?:boolean}){return ()=><article wrap:panel>Before<Scheduled fail={props.fail}/>After</article>;}
`;
const implementation=`import type {Child,Component,AnyAuthoredComponentFunction} from '@exactjs/core';
declare const _target:AnyAuthoredComponentFunction;
export let starts=0,disposals=0;
export function reset(){starts=0;disposals=0;}
export function Panel(this:Component<{}>,props:{panel?:true;children?:Child|Child[]}){
 starts++;this.onUnmount(()=>{disposals++;});return ()=><aside data-enhanced>{props.children}</aside>;
}
export function Field(this:Component<{}>,props:{field?:true;children?:Child|Child[]}){
 starts++;this.onUnmount(()=>{disposals++;});return ()=><label><span>Account</span><_target className="control" aria-describedby="description">{props.children}</_target><small id="description">Help</small></label>;
}`;
fs.writeFileSync(dir+'page.tsx',source);fs.writeFileSync(dir+'implementation.tsx',implementation);
fs.writeFileSync(dir+'enhancements.ts',`export {Panel as panel,Field as field} from './implementation.js' with {type:'exact-enhancement'};`);
const compiled=[];
for(const variant of ['control','candidate']){
  const exe=variant==='control'?'.tmp/native-compiler/exactc.exe':'.tmp/native-sink-compiler/exactc.exe';
  for(const [name,input] of [['page',source],['implementation',implementation]]){
    const request={kind:'compile',id:resolve(dir+name+'.tsx'),root:resolve(dir),configFile:resolve(dir+'tsconfig.json'),target:'server',source:input};
    const result=spawnSync(exe,[],{input:JSON.stringify(request)+'\n',encoding:'utf8',windowsHide:true,maxBuffer:32*1024*1024});
    if(result.status!==0)throw Error(result.stderr+result.stdout);
    const response=JSON.parse(result.stdout);compiled.push({variant,name,request,response});
    if(response.error||response.diagnostics.some(d=>d.severity==='error'))throw Error(JSON.stringify(response.diagnostics));
    let code=(await transform(response.code,{loader:'ts',format:'esm',target:'esnext'})).code;
    if(code.includes('issueServerComponentReceipt as __exactIssueServerComponent, ')){
      code=code.replace('issueServerComponentReceipt as __exactIssueServerComponent, ','');
      code=`import {issueServerComponentReceipt as __exactIssueServerComponent} from './${variant}-entry.mjs';\n`+code;
    }
    if(name==='page'){
      const identities=[...new Set([...code.matchAll(/identity: "([^"]+#panel)"/g)].map(m=>m[1]))];
      assert.equal(identities.length,1);code+='\nexport const enhancementIdentity='+JSON.stringify(identities[0])+';\n';
      const fields=[...new Set([...code.matchAll(/identity: "([^"]+#field)"/g)].map(m=>m[1]))];
      assert.equal(fields.length,1);code+='\nexport const fieldIdentity='+JSON.stringify(fields[0])+';\n';
    }
    fs.writeFileSync(dir+variant+'-'+name+'.mjs',code);
  }
}
fs.writeFileSync(dir+'compile.json',JSON.stringify(compiled,null,2));
fs.copyFileSync(d+'publication-markers-control-entry.mjs',dir+'control-entry.mjs');
const runtime=fs.readFileSync(d+'native-sink-entry.mjs','utf8');
assert.ok(runtime.includes('if(enhancement&&context.experimentalSink)'));
fs.writeFileSync(dir+'candidate-entry.mjs',runtime);
console.log('Compiled native and control enhancement fixtures; installed scoped enhancement capture.');
