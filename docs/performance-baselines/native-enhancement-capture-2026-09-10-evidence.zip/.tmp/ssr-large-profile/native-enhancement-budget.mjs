import fs from 'node:fs';
import assert from 'node:assert/strict';
import {PublicationStringSink} from './application-string-deferred-sink.mjs';
const rows=[];
for(const markers of [false,true])for(const name of ['Direct','Nested','Routed','Forwarded','ForwardedNested']){
  const baseline=JSON.parse(fs.readFileSync(`.tmp/ssr-large-profile/enhancement-native/audit-${process.versions.bun?'bun':'node'}.json`,'utf8')).find(row=>row.name===name&&row.markers===markers&&row.variant==='control');
  const bytes=Buffer.byteLength(baseline.html);
  for(const maxOutputBytes of [1,bytes-1,bytes,bytes+1]){
    let expected;
    for(const variant of ['control','candidate']){
      const runtime=await import(`./enhancement-native/${variant}-entry.mjs`);
      const page=await import(`./enhancement-native/${variant}-page.mjs`);
      const enhancement=await import(`./enhancement-native/${variant}-implementation.mjs`);
      page.reset();enhancement.reset();page.settle();
      const options={markers,maxOutputBytes,enhancementCatalog:new Map([[page.enhancementIdentity,enhancement.Panel],[page.fieldIdentity,enhancement.Field]])};
      const capture=runtime.createSsrResumptionCapture(options),context=runtime.createSsrContext(capture.options);
      const sink=new PublicationStringSink({maxBytes:maxOutputBytes});
      if(variant==='candidate')context.experimentalSink=sink;
      const root=runtime.createPreparedServerComponentReference(page[name],{});
      const target=new runtime.SsrOperationTarget(context,undefined,capture.options,false,runtime.renderChildren);
      let result;
      try{
        let html=await target.renderCompilerClosedRootComponent(root);
        if(variant==='candidate'){if(html)sink.write(html);sink.finish();html=sink.value;}
        result={html};
      }catch(error){result={error:error.name,message:error.message};}
      finally{sink.destroy();}
      assert.deepEqual(context.hostStack,[]);
      assert.equal(context.enhancementOperationRoutes?.length??0,0);
      assert.equal(context.targetReceiptLayers?.length??0,0);
      if(variant==='candidate')assert.equal(context.experimentalSink,sink);
      assert.equal(page.setups,page.disposals);assert.equal(enhancement.starts,enhancement.disposals);
      if(variant==='control')expected=result;else assert.deepEqual(result,expected,JSON.stringify({name,markers,maxOutputBytes}));
      rows.push({variant,name,markers,maxOutputBytes,...result});
    }
  }
}
fs.writeFileSync(`.tmp/ssr-large-profile/enhancement-native/budget-${process.versions.bun?'bun':'node'}.json`,JSON.stringify(rows,null,2));
console.log(rows.length,'enhancement byte-boundary results matched, with ownership restored');
