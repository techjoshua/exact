from pathlib import Path
import hashlib,json,statistics,zipfile

root=Path.cwd()
d=root/'.tmp/ssr-large-profile'
report=root/'docs/performance-baselines/native-enhancement-capture-2026-09-10.md'
archive=report.with_name(report.stem+'-evidence.zip')
datasets=[json.loads((d/name).read_text()) for name in ['native-enhancement-results.json','native-enhancement-repeat-results.json']]
assert [len(rows) for rows in datasets]==[32,16]
for rows in datasets:
    for row in rows:
        assert hashlib.sha256((root/row['entry']).read_bytes()).hexdigest()==row['artifactSha256']
for runtime in ['node','bun']:
    audit=json.loads((d/f'enhancement-native/audit-{runtime}.json').read_text())
    budgets=json.loads((d/f'enhancement-native/budget-{runtime}.json').read_text())
    assert len(audit)==36 and len(budgets)==80
checks=json.loads((d/'native-enhancement-validation.json').read_text())
assert len(checks)==8 and all(row['status']==0 for row in checks)
assert (d/'native-sink-application.mjs').read_bytes()==(d/'native-enhancement-application.mjs').read_bytes()

lines=['# Native sink enhancement capture','',
'Date: 2026-09-10. Experimental runtime integration; production compiler selection remains unchanged.','',
'The native sink prototype previously rejected rendering when enhancement routes were active.',
'Enhancements may rearrange their target HTML, so publishing the target directly to the outer sink',
'before the enhancement finishes is incorrect. The candidate temporarily clears the shared writer',
'sink within an enhanced operation. The same native renderer then collects scoped strings using',
'its existing local sink. Cleanup restores the caller sink on success, rejection, or cancellation.',
'Nested captures retain the outer scope. This does not introduce another rendering engine.','',
'The capture change is installed by both native prototype builders. The retained comparison-app',
'artifact is byte-identical to the measured candidate. It is still a runtime prototype transformation,',
'not a production ABI migration. The compiler emits the native writers used by the fixtures.','',
'## Measurements','',
'Hypothesis before measurement: ordinary rendering should change by less than roughly 1%.',
'Fresh production-mode Node 26.8.1 and Bun 1.4.2 processes perform 5,000 warmups and 12,000',
'measured renders per sample. Each cell averages two reversed-order samples. All four assets,',
'the application-owned document shell, and hydration/bootstrap output are included. Streams are',
'fully consumed through Response.text(). These are renderer microseconds, not HTTP requests/s.',
'No builds or tests ran concurrently with the timed processes. Output hashes match.','',
'| Runtime | Document | Mode | Before | Capture | Change |',
'| --- | --- | --- | ---: | ---: | ---: |']
def table(rows):
    result=[]
    for runtime in ['node','bun']:
        for scenario in ['assets','large']:
            for mode in ['string','stream']:
                values=[[r['usPerRender'] for r in rows if r['runtimeId']==runtime and r['scenario']==scenario and r['mode']==mode and r['variant']==variant] for variant in ['before','capture']]
                if not values[0]: continue
                assert all(len(v)==2 for v in values)
                before,after=map(statistics.mean,values)
                result.append(f'| {runtime} | {scenario} | {mode} | {before:.2f} | {after:.2f} | {(after/before-1)*100:+.1f}% |')
    return result
lines+=table(datasets[0])
lines+=['','The first large Bun stream samples changed direction: 259.87 to 276.70 microseconds,',
'then 262.62 to 261.35. Small Bun string samples also varied substantially. This prompted a',
'separate repeat of the large-document pairs, without changing the artifacts:','',
'| Runtime | Document | Mode | Before | Capture | Change |',
'| --- | --- | --- | ---: | ---: | ---: |']
lines+=table(datasets[1])
lines+=['','These samples do not establish the proposed 1% bound. Bun string direction changes between',
'runs, and the large initial streaming regression does not repeat. There is no consistent overall',
'performance improvement to claim. Capture is retained because it removes a concrete correctness',
'blocker for native sink integration without a repeatable large regression.','',
'React was not rerun in this capture-overhead experiment. The last paired comparison remains',
'[the native lazy-frame comparison](native-lazy-frame-2026-09-09.md): Node large string',
'158.66 versus React 131.27 microseconds, and Bun 202.57 versus React 188.92. Those figures',
'belong to that earlier paired run and must not be combined with this run as a new React gap.','',
'## Correctness evidence','',
'On each runtime, 18 enhancement scenarios compare candidate and production results with and',
'without markers: direct intrinsic, transparent fragment, nested wrapping, routed root prefix,',
'target forwarding, nested target forwarding, pending server task, rejected task, and abort.',
'HTML and hydration records match. Setup/disposal counts balance, the caller sink is restored,',
'and host, enhancement-route, and target-receipt stacks are empty. Pending enhanced markup',
'remains unpublished until its target completes. Target forwarding preserves merged classes',
'and accessibility attributes.','',
'An additional 40 byte-limit scenarios per runtime compare production and candidate at one byte,',
'one below the result size, exactly the result size, and one above it. Their 80 recorded results',
'per runtime match, and cleanup checks pass even when rendering rejects.','',
'The existing native scheduled-document fixture was rebuilt with capture support. Both runtimes',
'still match production HTML and hydration with and without markers. Twelve pressure/cancellation',
'cases pass. Two real Chromium adoption cases retain element/text/script identity, avoid restarting',
'server tasks, and dispose owned components. These browser cases cover the existing scheduled',
'document, not client adoption of the newly added enhancement fixtures.','',
'## Remaining integration work','',
'Production still uses the prior writer ABI. The native sink contract must be migrated through',
'core, SSR runtime, compiler selection, callers, and tests before these experimental capabilities',
'can be described as production behavior. The full comparison-app stream still collects its',
'document; progressive head publication is validated by the scheduled-document fixture only.',
'String performance still trails React in the last paired results.','',
'The [evidence archive](native-enhancement-capture-2026-09-10-evidence.zip) preserves all timed',
'samples, exact artifacts, compiler requests/responses, fixture sources, validation results,',
'prototype transformations, and a SHA-256 manifest. Public documentation is unchanged because',
'no published behavior or API changed.','']
report.write_text('\n'.join(lines),encoding='utf8')
names=['native-enhancement-capture.mjs','native-enhancement-build.mjs','native-enhancement-audit.mjs',
'native-enhancement-budget.mjs','native-enhancement-run.mjs','native-enhancement-report.py',
'native-enhancement-validation.mjs','native-enhancement-validation.json','native-enhancement-results.json',
'native-enhancement-repeat-results.json','native-enhancement-before.mjs','native-enhancement-application.mjs',
'native-sink-application-link.mjs','native-sink-fixture-build.mjs','native-sink-entry.mjs',
'native-sink-compile.json','native-sink-fixture.mjs','native-sink-validation.json',
'native-sink-node.json','native-sink-bun.json','native-sink-pressure-node.json','native-sink-pressure-bun.json',
'native-sink-audit.mjs','native-sink-pressure-audit.mjs','native-sink-adoption.mjs',
'native-sink-adoption-results.json','publication-adoption-client.js','application-string-deferred-sink.mjs',
'production-refresh-worker.mjs']
files=[d/name for name in names]+list((d/'enhancement-native').glob('*'))+[report,root/'.tmp/positional-leaves/data.json']
manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for path in files:
        content=path.read_bytes();name=path.relative_to(root).as_posix()
        manifest[name]=hashlib.sha256(content).hexdigest();z.writestr(name,content)
    z.writestr('SHA256SUMS.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    for name,digest in manifest.items(): assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('\n'.join(table(datasets[1])))
print(f'Wrote {report.name}; verified {len(manifest)} archived hashes.')
