import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {installEnhancementCapture} from './native-enhancement-capture.mjs';
const d='.tmp/ssr-large-profile/';
const resultFile=process.argv[2]??'native-enhancement-results.json';
const scenarios=process.argv[3]?[process.argv[3]]:['assets','large'];
const original=fs.readFileSync(d+'native-enhancement-before.mjs','utf8');
fs.writeFileSync(d+'native-enhancement-application.mjs',installEnhancementCapture(original));
const entries={before:d+'native-enhancement-before.mjs',capture:d+'native-enhancement-application.mjs'};
const rows=[];
for(const runtime of ['node','bun'])for(const scenario of scenarios)for(const mode of ['string','stream'])for(let round=0;round<2;round++)for(const variant of round?['capture','before']:['before','capture']){
  const entry=entries[variant];
  const result=spawnSync(runtime,[d+'production-refresh-worker.mjs',entry,mode,scenario,'12000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
  if(result.status!==0)throw Error(result.stderr+result.stdout);
  const row={runtimeId:runtime,round,variant,artifactSha256:createHash('sha256').update(fs.readFileSync(entry)).digest('hex'),...JSON.parse(result.stdout)};
  const peer=rows.find(r=>r.scenario===scenario&&r.mode===mode);
  if(peer)assert.equal(row.hash,peer.hash,'Complete document changed');
  rows.push(row);fs.writeFileSync(d+resultFile,JSON.stringify(rows,null,2));
  console.log(runtime,scenario,mode,round,variant,row.usPerRender.toFixed(2));
}
