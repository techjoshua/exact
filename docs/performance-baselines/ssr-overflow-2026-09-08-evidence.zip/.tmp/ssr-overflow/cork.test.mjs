import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Writable } from 'node:stream';
import { once } from 'node:events';
import { DirectWriter } from './direct-writer-cork.mjs';

test('cork batches the buffer and incoming value into one vectored write', async () => {
  const batches = [];
  const destination = new Writable({
    write(chunk, _encoding, done) { batches.push([chunk.toString()]); done(); },
    writev(chunks, done) { batches.push(chunks.map(chunk => chunk.chunk.toString())); done(); }
  });
  const writer = new DirectWriter(destination, { mode: 'direct', flushThresholdBytes: 8 });
  writer.write('123456');
  writer.write('abcdef');
  writer.finish();
  destination.end();
  await once(destination, 'finish');
  assert.deepEqual(batches, [['123456', 'abcdef']]);
  assert.equal(destination.writableCorked, 0);
});

test('the cork is released even when an overflow write throws', () => {
  const failure = new Error('write failed');
  let corked = 0;
  const destination = {
    cork() { corked++; }, uncork() { corked--; },
    write() { throw failure; }, destroy() {}
  };
  const writer = new DirectWriter(destination, { mode: 'direct', flushThresholdBytes: 8 });
  writer.write('123456');
  assert.throws(() => writer.write('abcdef'), error => error === failure);
  writer.destroy(failure);
  assert.equal(corked, 0);
  assert.equal(writer.buffer, undefined);
});
