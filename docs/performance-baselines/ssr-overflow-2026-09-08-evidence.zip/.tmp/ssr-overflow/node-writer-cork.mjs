import { exactResponseBodyOf } from '@exactjs/server';
import { writeNodeResponse as originalWriter } from '@exactjs/node-adapter';
import { DirectWriter } from './direct-writer-cork.mjs';
const environment = Object.freeze({ encodedByteLength: Buffer.byteLength });

/** Direct-sink fixture adapter. The legacy synchronous renderer remains one atomic segment. */
export async function writeNodeResponse(response, result, signal, logger) {
  const body = exactResponseBodyOf(result);
  if (!body?.writeSynchronously) return originalWriter(response, result, signal, logger);
  const writer = new DirectWriter(response, {
    mode: process.env.SSR_OVERFLOW_MODE ?? 'direct',
    flushThresholdBytes: Number(process.env.SSR_FLUSH_THRESHOLD_BYTES ?? 8192)
  });
  response.statusCode = result.status;
  for (const [key, value] of Object.entries(result.headers)) response.setHeader(key, value);
  let resolveDone, rejectDone;
  const done = new Promise((resolve, reject) => { resolveDone = resolve; rejectDone = reject; });
  void done.catch(() => {});
  const failed = error => { writer.destroy(error); rejectDone(error); };
  const aborted = () => failed(signal.reason instanceof Error ? signal.reason : new Error('Request aborted'));
  const closed = () => {
    if (response.writableFinished) resolveDone();
    else failed(new Error('Response closed early'));
  };
  response.once('error', failed);
  response.once('close', closed);
  response.once('finish', resolveDone);
  signal?.addEventListener('abort', aborted, { once: true });
  try {
    if (signal?.aborted) throw signal.reason;
    let first = true;
    const write = value => {
      if (signal?.aborted) throw signal.reason;
      // Only the benchmark's known document prefix defines this explicit head boundary.
      if (first) {
        first = false;
        const head = typeof value === 'string' && value.startsWith('<!doctype html>') ? value.indexOf('</head>') : -1;
        if (head >= 0) {
          writer.write(value.slice(0, head + 7));
          writer.flush();
          value = value.slice(head + 7);
        }
      }
      writer.write(value);
    };
    write.static = value => writer.write(value);
    const completion = body.writeSynchronously(write, environment);
    writer.finish();
    if (completion) await completion;
    if (signal?.aborted) throw signal.reason;
    response.end();
    await done;
  } catch (error) {
    writer.destroy(error instanceof Error ? error : new Error('Production failed', { cause: error }));
    await done.catch(() => {});
    try { await body.cancel(error); } catch (cleanup) { console.error('Overflow prototype cleanup failed', cleanup); }
    if (!signal?.aborted) console.error('Overflow prototype failed', error);
  } finally {
    response.off('error', failed);
    response.off('close', closed);
    response.off('finish', resolveDone);
    signal?.removeEventListener('abort', aborted);
  }
}
