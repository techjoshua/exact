import { readFile, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
import { summarizeSsrCapacityCapture } from '../../framework-comparison/src/ssr-capacity-report.mjs';

const summary = { http: {}, cpu: [] };
for (const filename of ['http.json', 'http-cork.json']) {
  const capture = JSON.parse(await readFile(`.tmp/ssr-overflow/${filename}`, 'utf8'));
  assert.equal(capture.complete, true);
  for (const block of capture.blocks) for (const result of block.results) for (const stage of result.stages) assert.equal(stage.errors, 0);
  const rows = [];
  for (const payloadBytes of [0, 65536]) {
    for (const variant of [...new Set(capture.blocks.map(block => block.variant))]) {
      const blocks = capture.blocks.filter(block => block.payloadBytes === payloadBytes && block.variant === variant);
      const [row] = summarizeSsrCapacityCapture({ ...capture, blocks });
      const populations = blocks.map(block => {
        const stages = block.results.map(result => result.stages.find(stage => !stage.discard));
        const start = Math.min(...stages.map(stage => Date.parse(stage.startedAt)));
        const end = Math.max(...stages.map(stage => Date.parse(stage.startedAt) + stage.elapsedMs));
        return { population: block.population, rps: 1000 * stages.reduce((sum, stage) => sum + stage.valid, 0) / (end - start) };
      });
      rows.push({ payloadBytes, variant, ...row, populations });
      console.log(filename, payloadBytes, variant, Math.round(row.rps), populations.map(p => Math.round(p.rps)).join('/'));
    }
  }
  summary.http[filename] = { createdAt: capture.createdAt, environment: capture.environment, rows };
}
const cpu = JSON.parse(await readFile('.tmp/ssr-overflow/cpu.json', 'utf8'));
for (const name of [...new Set(cpu.map(row => row.name))]) for (const mode of ['split', 'combine', 'direct']) {
  const rows = cpu.filter(row => row.name === name && row.mode === mode);
  summary.cpu.push({ name, mode, expectedBytes: rows[0].expectedBytes,
    nsPerOperation: rows.reduce((sum, row) => sum + row.nsPerOperation, 0) / rows.length,
    writesPerOperation: rows[0].writesPerOperation });
}
await writeFile('docs/performance-baselines/ssr-overflow-2026-09-08.json', JSON.stringify(summary, null, 2) + '\n');
