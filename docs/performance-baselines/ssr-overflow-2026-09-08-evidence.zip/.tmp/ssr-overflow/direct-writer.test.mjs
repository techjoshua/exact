import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Writable } from 'node:stream';
import { once } from 'node:events';
import { DirectWriter } from './direct-writer.mjs';
import { readFile } from 'node:fs/promises';
import { renderParticipantToSink } from './hoisted-buffers.mjs';
import { renderParticipantToSink as originalRender } from '../../framework-comparison/participants/exact/dist-server/server-entry.js';

for (const mode of ['split', 'combine', 'direct']) {
  test(`${mode}: byte identity, Unicode, thresholds, retained buffers`, () => {
    for (const threshold of [4, 7, 8192]) {
      const chunks = [];
      const writer = new DirectWriter({ write(value) { chunks.push(value); return true; } }, { mode, flushThresholdBytes: threshold });
      const values = ['<head></head>', 'a'.repeat(threshold - 1), '\ud83d', '', '\ude42', Buffer.from('<b>'), '水é'.repeat(10000), '</b>', '\ud800'];
      for (const value of values) writer.write(value);
      writer.finish();
      const output = Buffer.concat(chunks.map(value => typeof value === 'string' ? Buffer.from(value) : value));
      assert.equal(output.toString(), values.map(String).join('').replace(/\ud800$/, '\ufffd'));
      if (mode === 'split') assert.ok(chunks.every(value => value.length <= threshold));
      assert.equal(writer.buffer, undefined);
    }
  });

  test(`${mode}: real Writable backpressure resumes between atomic writes`, async () => {
    const chunks = [];
    const destination = new Writable({ highWaterMark: 16, write(value, _encoding, callback) {
      chunks.push(value); setImmediate(callback);
    } });
    const writer = new DirectWriter(destination, { mode, flushThresholdBytes: 8 });
    let pauses = 0;
    for (let i = 0; i < 20; i++) {
      if (!writer.write(`${i}:` + 'x'.repeat(40))) { pauses++; await once(destination, 'drain'); writer.resume(); }
    }
    if (!writer.finish()) { await once(destination, 'drain'); writer.resume(); }
    destination.end();
    await once(destination, 'finish');
    assert.ok(pauses > 0);
    assert.equal(Buffer.concat(chunks).toString(), Array.from({ length: 20 }, (_, i) => `${i}:` + 'x'.repeat(40)).join(''));
  });

  test(`${mode}: compiled fixture produces unchanged HTML and hydration`, async () => {
    const data = JSON.parse(await readFile('.tmp/ssr-overflow/data.json', 'utf8'));
    let expected = '';
    originalRender(data, '/incidents/inc-101', value => expected += value, Buffer.byteLength);
    const chunks = [];
    const writer = new DirectWriter({ write(value) { chunks.push(Buffer.from(value)); return true; } }, { mode, flushThresholdBytes: 64 });
    const publish = value => writer.write(value);
    publish.static = publish;
    renderParticipantToSink(data, '/incidents/inc-101', publish, Buffer.byteLength);
    writer.finish();
    assert.equal(Buffer.concat(chunks).toString(), expected);
  });
}

test('destruction releases staging and prevents further writes', () => {
  let destroyed = 0;
  const error = new Error('transport failed');
  const writer = new DirectWriter({ write() { return true; }, destroy(reason) { assert.equal(reason, error); destroyed++; } });
  writer.write('pending');
  writer.destroy(error);
  writer.destroy(error);
  assert.equal(writer.buffer, undefined);
  assert.equal(writer.tail, '');
  assert.equal(destroyed, 1);
  assert.throws(() => writer.write('later'), /destroyed/);
});

test('overflow policies produce the intended write boundaries', () => {
  const expected = { split: ['123456ab', 'cdef'], combine: ['123456abcdef'], direct: ['123456', 'abcdef'] };
  for (const mode of Object.keys(expected)) {
    const chunks = [];
    const writer = new DirectWriter({ write(value) { chunks.push(value.toString()); return true; } }, { mode, flushThresholdBytes: 8 });
    writer.write('123456'); writer.write('abcdef'); writer.finish();
    assert.deepEqual(chunks, expected[mode]);
  }
});
