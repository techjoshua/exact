const encoder = new TextEncoder();

/** Experimental direct Writable sink. A write is atomic; callers pause between writes on false. */
export class DirectWriter {
  constructor(destination, { mode = 'direct', flushThresholdBytes = 8192 } = {}) {
    if (!['split', 'combine', 'direct'].includes(mode)) throw new TypeError('Unknown overflow policy');
    if (!Number.isSafeInteger(flushThresholdBytes) || flushThresholdBytes < 4)
      throw new RangeError('Threshold must be at least four bytes');
    this.destination = destination;
    this.mode = mode;
    this.threshold = flushThresholdBytes;
    this.buffer = undefined;
    this.offset = 0;
    this.tail = '';
    this.capacity = true;
    this.destroyed = false;
  }

  /** Preserves pairs split across dynamic spans. Buffers are complete immutable UTF-8 constants. */
  write(value) {
    this.assertOpen();
    if (!value.length) return this.capacity;
    if (typeof value === 'string') {
      value = this.tail + value;
      this.tail = '';
      const last = value.charCodeAt(value.length - 1);
      if (last >= 0xd800 && last <= 0xdbff) {
        this.tail = value.slice(-1);
        value = value.slice(0, -1);
      }
    } else if (this.tail) {
      this.tail = '';
      this.append('\ufffd');
    }
    if (value.length) this.append(value);
    return this.capacity;
  }

  /** Applies only the overflow policy; all modes share the fitting-input fast path. */
  append(value) {
    const size = typeof value === 'string' ? Buffer.byteLength(value) : value.length;
    if (size <= this.threshold - this.offset) {
      this.copy(value, size);
      if (this.offset === this.threshold) this.flush();
      return;
    }
    if (this.mode === 'direct') {
      this.destination.cork();
      try {
        this.flush();
        this.emit(value);
      } finally { this.destination.uncork(); }
    } else if (this.mode === 'combine') {
      if (this.offset === 0) { this.emit(value); return; }
      let combined;
      if (typeof value === 'string') {
        // Encode directly into the combined allocation, avoiding an intermediate encoded copy.
        combined = Buffer.allocUnsafe(this.offset + size);
        this.buffer.copy(combined, 0, 0, this.offset);
        combined.write(value, this.offset, size, 'utf8');
      } else combined = Buffer.concat([this.buffer.subarray(0, this.offset), value], this.offset + size);
      this.buffer = undefined;
      this.offset = 0;
      this.emit(combined);
    } else this.split(value);
  }

  /** Fills staging before splitting incoming data across replacement buffers. */
  split(value) {
    let index = 0;
    while (index < value.length) {
      if (!this.buffer) this.buffer = Buffer.allocUnsafe(this.threshold);
      const remaining = this.threshold - this.offset;
      if (typeof value === 'string') {
        const result = encoder.encodeInto(value.slice(index), this.buffer.subarray(this.offset));
        index += result.read;
        this.offset += result.written;
        if (result.read === 0 || this.offset === this.threshold) this.flush();
      } else {
        const size = Math.min(remaining, value.length - index);
        value.copy(this.buffer, this.offset, index, index + size);
        this.offset += size;
        index += size;
        if (this.offset === this.threshold) this.flush();
      }
    }
  }

  /** Copies a fitting span into request-owned, unpublished storage. */
  copy(value, size) {
    if (!this.buffer) this.buffer = Buffer.allocUnsafe(this.threshold);
    if (typeof value === 'string') this.buffer.write(value, this.offset, size, 'utf8');
    else value.copy(this.buffer, this.offset);
    this.offset += size;
  }

  /** Hands storage to Node and never mutates that allocation again. */
  flush() {
    this.assertOpen();
    if (this.offset) {
      const chunk = this.buffer.subarray(0, this.offset);
      this.buffer = undefined;
      this.offset = 0;
      this.emit(chunk);
    }
    return this.capacity;
  }

  /** Flushes the final unmatched surrogate and all completed output. */
  finish() {
    if (this.tail) { this.tail = ''; this.append('\ufffd'); }
    return this.flush();
  }

  /** Remembers backpressure until the consumer's drain event acknowledges capacity. */
  emit(value) {
    const accepted = this.destination.write(value);
    this.capacity = this.capacity && accepted;
  }

  /** Called only after the destination reports drain. */
  resume() { this.assertOpen(); this.capacity = true; }

  /** Drops unpublished data and terminates the destination on failure. */
  destroy(error) {
    if (this.destroyed) return;
    this.destroyed = true;
    this.buffer = undefined;
    this.offset = 0;
    this.tail = '';
    this.destination.destroy(error);
  }

  assertOpen() { if (this.destroyed) throw new Error('Writer destroyed'); }
}
