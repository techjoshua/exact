import hashlib,json,pathlib,zipfile
root=pathlib.Path('.');work=root/'.tmp/ssr-large-profile'
rows=json.loads((work/'opaque-prototype-results.json').read_text(encoding='utf-8'));summary=[]
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['small','large']:
   changes=[]
   for round in range(2):
    group=[r for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['round']==round]
    a=next(r for r in group if r['variant']=='callback-current');b=next(r for r in group if r['variant']=='opaque-prototype')
    assert a['hash']==b['hash'];changes.append((b['usPerRender']/a['usPerRender']-1)*100)
   summary.append(dict(runtime=runtime,mode=mode,scenario=scenario,changes=changes))
table='\n'.join(f"| {s['runtime']} | {s['mode']} | {s['scenario']} | {s['changes'][0]:+.2f}% | {s['changes'][1]:+.2f}% |" for s in summary)
dest=root/'docs/performance-baselines/opaque-prototype-2026-09-09'
dest.with_suffix('.json').write_text(json.dumps(dict(summary=summary,rows=rows),indent=2)+'\n',encoding='utf-8')
doc='''# Opaque operation prototype experiment

Date: 2026-09-09. Decision: do not adopt this representation from current evidence.

## Hypothesis and scope

The fresh Node profile highlighted opaque operation creation on small renders. The existing
constructor defines identity and executor symbol properties on each operation, then freezes it.
The candidate shares those two immutable properties on a frozen prototype cached per executor
in a WeakMap. Each operation remains a distinct frozen object. Metadata is still copied and frozen
per operation, and private payloads remain in their existing WeakMaps. No child, task, or issuer
scope is removed. The hypothesis is a small allocation reduction most visible on small documents;
no numerical gain was preregistered.

This changes own-property reflection and the direct prototype of operations. Existing symbol lookup
continues to work, but output equality is not proof of cross-runtime or public reflection semantics.
A production implementation would require core contract, reactivity, hydration, and lifecycle
review. The experiment applies only to a frozen SSR bundle and does not change production code.

## Method and results

Thirty-two fresh processes: Node/Bun, string/consumed stream, three/96 incidents, two reversed-order
pairs per cell. NODE_ENV=production, 5,000 warmups, 12,000 measured renders, complete authored
documents, empty client tags, same portable bundle on both runtimes. Streams are consumed using
Response.text(). All paired full-document hashes match. No HTTP or browser timings are measured.

Positive means longer rendering time. Both pairs are shown; two observations on a variable-load
workstation are preliminary evidence, not confidence bounds.

| Runtime | Mode | Fixture | Pair 1 time change | Pair 2 time change |
| --- | --- | --- | ---: | ---: |
'''+table+'''

Small Node strings improve in both pairs, but large Node streams and small Bun streams regress in
both pairs. Other cells are mixed or variable. This does not support a global representation change
with its additional semantic review cost. No retained optimization was removed. No package/browser
tests were run for this rejected bundle prototype, and no React parity claim follows from it.

The result argues against this particular shared-prototype approach, not against reducing server
carrier construction more directly. A future compiler-owned carrier would still need to preserve
fragment keys, domains, enhancement routing, and scheduled-child ownership rather than simply
turning every fragment into an array.

The archive preserves the frozen bundles, builder, worker, runner, fixed input, raw observations,
reporter, and SHA-256 manifest. The overall objective remains unmet.
'''
dest.with_suffix('.md').write_text(doc,encoding='utf-8')
files=[work/name for name in ['callback-current.mjs','opaque-prototype.mjs','opaque-prototype-build.mjs','opaque-prototype-run.mjs','opaque-prototype-results.json','opaque-prototype-report.py','long-worker.mjs','single-result-run.mjs']]+[root/'.tmp/positional-leaves/data.json']
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps({p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(table);print('Verified',archive)
