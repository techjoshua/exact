import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
let source=readFileSync(dir+'callback-current.mjs','utf8');
const start=source.indexOf('function createOpaqueOperation('),end=source.indexOf('\n/**',start);
if(start<0||end<0)throw Error('Missing opaque constructor');
const original=source.slice(start,end);
if(!original.includes('return Object.freeze(operation)'))throw Error('Unexpected constructor');
const replacement=`const opaqueExecutorPrototypes = new WeakMap();
let emptyOpaquePrototype;
function createOpaqueOperation(execute, metadata) {
 let prototype=execute?opaqueExecutorPrototypes.get(execute):emptyOpaquePrototype;
 if(!prototype){
  prototype=Object.defineProperty({},exactOpaqueOperationIdentity,{value:true});
  if(execute)Object.defineProperty(prototype,exactOpaqueOperationExecution,{value:execute});
  Object.freeze(prototype);
  if(execute)opaqueExecutorPrototypes.set(execute,prototype);else emptyOpaquePrototype=prototype;
 }
 const operation=Object.create(prototype);
 if(metadata&&(metadata.key!==undefined||metadata.domain!==undefined))Object.defineProperty(operation,exactOpaqueOperationMetadata,{value:Object.freeze({...metadata})});
 return Object.freeze(operation);
}`;
source=source.slice(0,start)+replacement+source.slice(end);
writeFileSync(dir+'opaque-prototype.mjs',source);
writeFileSync(dir+'opaque-prototype-run.mjs',readFileSync(dir+'single-result-run.mjs','utf8').replaceAll('single-result','opaque-prototype'));
