import json,hashlib,zipfile
from pathlib import Path
from statistics import mean
base=Path('.tmp/ssr-large-profile');root=base/'work-batch';d=json.loads((root/'capture.json').read_text());assert d['complete'] and len(d['blocks'])==12
rows=[]
for pop in (0,1):
 bs=[b for b in d['blocks'] if b['population']==pop];e=[b for b in bs if b['id']=='exact'];norm=[b['rps'] for b in e if b['phase']=='normal']
 row=dict(population=pop+1,immediateBefore=norm[0],immediateAfter=norm[1],react=next(b['rps'] for b in bs if b['id']=='react'))
 for phase in ('gate','work-yield','work-immediate'):row[phase]=next(b['rps'] for b in e if b['phase']==phase)
 rows.append(row)
for b in d['blocks']:
 assert b['after']['scheduleCalls']==(b['valid']+len(b['results']) if b['phase']!='normal' else 0)
 assert all(s['errors']==0 for r in b['results'] for s in r['stages'])
valid=sum(b['valid'] for b in d['blocks']);(root/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid),indent=2))
report=Path('docs/performance-baselines/large-bun-render-work-batches-2026-09-11.md')
lines=['# Batching render calls instead of readiness promises','',
'Hypothesis: batching actual render calls reduces promise-job transitions enough to recover roughly 5-15% of the large Bun string throughput loss. Diagnostic work schedulers invoke each request independently inside one batch callback, resolving its own promise with the render result. They wrap the participant render-and-response call and omit the source readiness gate. This changes the scheduled scope as well as promise-job ordering, so an effect would not isolate either mechanism alone. These scratch schedulers are not production cancellation or yield-failure implementations.', '',
'Native Bun string HTTP, 96 incidents, concurrency 32. Fresh eXact/React/React/eXact workers, ten-second warmup and five-second blocks. Immediate controls bracket gate/work-yield/work-immediate, with order reversed on repeat. React is unchanged. Each complete response must match its framework document identity.', '',
'| Repeat | Immediate before | Gate RPS | Work yield RPS | Work immediate RPS | Immediate after | React RPS |',
'| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for r in rows:lines.append('| '+' | '.join([str(r['population'])]+[f'{r[k]:,.0f}' for k in ('immediateBefore','gate','work-yield','work-immediate','immediateAfter','react')])+' |')
lines+=['',f'{valid:,} complete measured responses validated with zero errors. Invocation counts and artifact guards pass.', '',
'The first pass shows only a small recovery and remains below immediate rendering. The second immediate controls drift substantially, preventing a strong within-repeat baseline comparison. These results do not justify changing the public scheduler from a readiness gate into a render-work API. The diagnostic is not adopted. The large native Bun string gap remains open.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(root.glob('*'))+[report,base/'work-batch-build.py',base/'work-batch-run.mjs',base/'work-batch-report.py'];archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists();manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print(json.dumps(rows,indent=2));print(valid,'validated responses')
