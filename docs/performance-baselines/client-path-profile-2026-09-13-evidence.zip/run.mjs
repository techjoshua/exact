import {writeFile} from 'node:fs/promises';
import {chromium} from 'playwright';
import {startClientBenchmarkHarness} from '../../framework-comparison/src/client-benchmark-harness.mjs';
import {waitForSemanticReady} from '../../framework-comparison/src/client-profiling.mjs';
process.env.NODE_ENV='production';
const participants=[{id:'exact',directory:'exact',artifact:'dist',url:'http://127.0.0.1:4401'},{id:'sveltekit',directory:'sveltekit',artifact:'build/client',url:'http://127.0.0.1:4403'}];
const harness=await startClientBenchmarkHarness(participants);let browser;
async function endTrace(cdp){const done=new Promise(r=>cdp.once('Tracing.tracingComplete',r));await cdp.send('Tracing.end');const {stream}=await done;let text='';for(;;){const c=await cdp.send('IO.read',{handle:stream});text+=c.data;if(c.eof)break;}await cdp.send('IO.close',{handle:stream});return JSON.parse(text);}
try{browser=await chromium.launch();for(let round=0;round<8;round++)for(const p of round%2?[...participants].reverse():participants){
 await fetch('http://127.0.0.1:4310/__benchmark/reset',{method:'POST',headers:{'content-type':'application/json','x-benchmark-control':'fixture-reset'},body:'{}'});
 const ctx=await browser.newContext();try{const page=await ctx.newPage();const cdp=await ctx.newCDPSession(page);await cdp.send('Network.enable');await cdp.send('Network.setCacheDisabled',{cacheDisabled:true});await cdp.send('Emulation.setCPUThrottlingRate',{rate:6});
 await page.addInitScript(()=>{document.addEventListener('click',e=>{if(e.target.closest?.('button')?.textContent.trim()==='Claim incident')performance.mark('probe-click');},true);const f=window.fetch;window.fetch=(...a)=>{if(String(a[0]).endsWith('/claim'))performance.mark('probe-dispatch');return f(...a);};new MutationObserver(()=>{if(!performance.getEntriesByName('probe-click').length||performance.getEntriesByName('probe-dom').length)return;if(document.querySelector('.facts strong')?.textContent==='Alex Chen')performance.mark('probe-dom');}).observe(document,{subtree:true,childList:true,characterData:true});});
 await cdp.send('Tracing.start',{transferMode:'ReturnAsStream',categories:'devtools.timeline,blink.user_timing,loading,disabled-by-default-devtools.timeline,disabled-by-default-v8.cpu_profiler'});
 await page.goto(p.url+'/incidents/inc-100',{waitUntil:'load'});await waitForSemanticReady(page);await page.getByRole('button',{name:'Claim incident',exact:true}).click();await page.getByText('Version 2',{exact:true}).waitFor();
 const timings=await page.evaluate(()=>performance.getEntries().filter(e=>e.entryType==='paint'||e.name.startsWith('probe-')).map(e=>({name:e.name,startTime:e.startTime})));
 const trace=await endTrace(cdp);await writeFile('.tmp/client-path-profile/'+p.id+'-'+round+'.json',JSON.stringify({timings,trace}));console.log(p.id,round,JSON.stringify(timings));
 }finally{await ctx.close();}}
 await writeFile('.tmp/client-path-profile/environment.json',JSON.stringify({cpuThrottle:6,rounds:8,harness:harness.evidence()},null,2));
}finally{try{await browser?.close();}finally{await harness.close();}}
