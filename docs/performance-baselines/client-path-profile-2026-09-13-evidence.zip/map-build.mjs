import {createRequire} from 'node:module';import {pathToFileURL} from 'node:url';
const require=createRequire(new URL('../../framework-comparison/package.json',import.meta.url));const {build}=await import(pathToFileURL(require.resolve('vite')));
await build({configFile:'framework-comparison/participants/exact/vite.config.ts',build:{outDir:'../../../.tmp/client-path-profile/mapped',sourcemap:'hidden',emptyOutDir:true}});
