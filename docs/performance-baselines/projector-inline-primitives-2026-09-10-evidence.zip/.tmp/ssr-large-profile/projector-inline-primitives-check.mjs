import fs from 'node:fs';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const d='.tmp/ssr-large-profile/';
const modules=[];
for(const [label,entry] of [['current','proven-reference-integrated/server-entry.js'],['candidate','projector-inline-primitives/server-entry.js']]){
 let source=fs.readFileSync(d+entry,'utf8');
 const marker='function registerPositionalProjector(schema, version, project) {';
 assert.equal(source.split(marker).length,2);
 source='var __probeRegistrations = [];\n'+source.replace(marker,marker+'\n__probeRegistrations.push({schema,project});');
 source+=`\nexport function probeSchemas(){return __probeRegistrations.map(r=>r.schema);}
 export function probeProjection(index,value,maxDepth,maxNodes){
 const {schema,project}=__probeRegistrations[index];
 const state={active:new Set(),maxDepth,maxNodes,nodes:0,validate:validateValue,project:projectPositionalField,mismatch:positionalMismatch,unsafe:positionalUnsafe};
 try {const result=project(value,0,state,schema,Object,Array);return {result:result===positionalMismatch?'mismatch':result===positionalUnsafe?'unsafe':result,nodes:state.nodes,active:state.active.size};}
 catch(error){return {error:error.message,nodes:state.nodes,active:state.active.size};}
 }`;
 const path=d+'projector-inline-primitives-probe-'+label+'.mjs';fs.writeFileSync(path,source);
 modules.push(await import(pathToFileURL(resolve(path))));
}
function fromSchema(schema){if(schema===0)return 'value';if(schema[0]===2)return [];const o={};for(let i=1;i<schema.length;i+=2)o[schema[i]]=fromSchema(schema[i+1]);return o;}
const scenarios=[
 ['plain',()=>{}],['null',(v,k)=>v[k]=null],['boolean',(v,k)=>v[k]=true],['finite',(v,k)=>v[k]=42],['nan',(v,k)=>v[k]=NaN],['infinity',(v,k)=>v[k]=Infinity],['undefined',(v,k)=>v[k]=undefined],['bigint',(v,k)=>v[k]=1n],['symbol',(v,k)=>v[k]=Symbol()],['function',(v,k)=>v[k]=()=>{}],['object',(v,k)=>v[k]={nested:'value'}],['cycle',(v,k)=>v[k]=v],['array',(v,k)=>v[k]=['nested']],['extra',(v)=>v.extra=true],['prototype',(v)=>Object.setPrototypeOf(v,null)],
 ['delete-later',(v,k,s,reads)=>Object.defineProperty(v,k,{enumerable:true,get(){reads.push(k);delete v[s[3]];return 'value';}})],
 ['throw',(v,k)=>Object.defineProperty(v,k,{enumerable:true,get(){throw Error('authored');}})]
];
let checks=0;const rows=[];
const schemas=modules[0].probeSchemas();assert.deepEqual(schemas,modules[1].probeSchemas());
for(let index=0;index<schemas.length;index++)for(const [name,mutate]of scenarios)for(const [depth,nodes]of [[100,100000],[0,100000],[1,100000],[100,0],[100,1],[100,4]]){
 const results=modules.map(mod=>{const schema=mod.probeSchemas()[index],value=fromSchema(schema),reads=[];mutate(value,schema[1],schema,reads);return {projection:mod.probeProjection(index,value,depth,nodes),reads};});
 assert.deepEqual(results[1],results[0],JSON.stringify({index,name,depth,nodes}));assert.equal(results[0].projection.active,0);
 rows.push({index,name,depth,nodes,result:results[0]});checks++;
}
fs.writeFileSync(d+'projector-inline-primitives-checks.json',JSON.stringify({runtime:process.versions,checks,rows},null,2));
console.log(checks+' projector equivalence checks passed');
