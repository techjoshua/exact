import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
const runner=fs.readFileSync(d+'projector-inline-primitives-confirm.mjs','utf8').replaceAll('projector-inline-primitives/server-entry.js','projector-inline-primitives-integrated/server-entry.js').replace("['large']","['assets']").replace("'20000'","'10000'").replaceAll('projector-inline-primitives-confirm-results.json','projector-inline-primitives-small-results.json');
fs.writeFileSync(d+'projector-inline-primitives-small.mjs',runner);
