import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
const runner=fs.readFileSync(d+'projector-inline-primitives-small.mjs','utf8').replace("['node','bun']","['bun']").replace('round<2','round<4').replace('if(round)order.reverse()','if(round%2)order.reverse()').replace("'10000'","'20000'").replaceAll('projector-inline-primitives-small-results.json','projector-inline-primitives-small-bun-confirm-results.json');
fs.writeFileSync(d+'projector-inline-primitives-small-bun-confirm.mjs',runner);
