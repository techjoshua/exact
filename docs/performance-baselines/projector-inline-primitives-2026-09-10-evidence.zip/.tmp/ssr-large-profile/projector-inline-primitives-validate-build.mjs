import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
fs.writeFileSync(d+'projector-inline-primitives-validate.mjs',fs.readFileSync(d+'in-place-server-list-validate.mjs','utf8').replaceAll('in-place-server-list-', 'projector-inline-primitives-').replace("'packages/ssr/src/render/direct-component-support.ts','packages/ssr/src/render/direct-component-support.test.ts'","'packages/ssr/src/positional-projection.test.ts'"));
