import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const d='.tmp/ssr-large-profile/';
const pairs=[
 ['native/typescript-go/overlay/internal/exactcompiler/component_positional_projection.go',d+'projector-inline-primitives-source-before.go'],
 ['.tmp/native-typescript-go/tsc/internal/exactcompiler/component_positional_projection.go',d+'projector-inline-primitives-source-before.go'],
 ['packages/ssr/src/positional-projection.test.ts',d+'projector-inline-primitives-tests-before.ts'],
 ['framework-comparison/participants/exact/dist-server/server-entry.js',d+'projector-inline-primitives-http-before/dist-server/server-entry.js'],
 ['framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js',d+'projector-inline-primitives-http-before/dist-bun-server/bun-server-entry.js']
];
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const results=pairs.map(([file,before])=>{assert.equal(hash(file),hash(before),file);return {file,before,sha256:hash(file)};});
fs.writeFileSync(d+'projector-inline-primitives-restoration.json',JSON.stringify(results,null,2));
console.log('Compiler source, overlay, tests and both canonical bundles match retained hashes.');
