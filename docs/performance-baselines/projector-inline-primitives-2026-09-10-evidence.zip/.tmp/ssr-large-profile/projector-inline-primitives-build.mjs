import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const d='.tmp/ssr-large-profile/';
const input=d+'proven-reference-integrated/server-entry.js';
let source=fs.readFileSync(input,'utf8');
let count=0;
source=source.replace(/if \(!state\.validate\((cell\d+), depth \+ 1, state\)\) return state\.unsafe;/g,(_,cell)=>{
 count++;
 return `if (${cell} === null || typeof ${cell} === "string" || typeof ${cell} === "boolean") {
 if (++state.nodes > state.maxNodes || depth + 1 > state.maxDepth) return state.unsafe;
 } else if (!state.validate(${cell}, depth + 1, state)) return state.unsafe;`;
});
assert.ok(count>0);
fs.mkdirSync(d+'projector-inline-primitives',{recursive:true});
fs.writeFileSync(d+'projector-inline-primitives/server-entry.js',source);
fs.writeFileSync(d+'projector-inline-primitives/provenance.json',JSON.stringify({input,sha256:createHash('sha256').update(fs.readFileSync(input)).digest('hex'),count},null,2));
let runner=fs.readFileSync(d+'complete-proof-run.mjs','utf8').replaceAll('complete-proof/server-entry.js','projector-inline-primitives/server-entry.js').replaceAll('complete-proof-results.json','projector-inline-primitives-results.json').replace("['assets','large']","['large']");
fs.writeFileSync(d+'projector-inline-primitives-run.mjs',runner);
console.log('Changed generated primitive sites:',count);
