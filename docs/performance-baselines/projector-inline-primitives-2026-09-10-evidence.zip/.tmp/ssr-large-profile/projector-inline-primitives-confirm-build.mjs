import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
fs.writeFileSync(d+'projector-inline-primitives-confirm.mjs',fs.readFileSync(d+'projector-inline-primitives-run.mjs','utf8').replace("['string','encoded','stream']","['string','stream']").replace("'10000'","'20000'").replaceAll('projector-inline-primitives-results.json','projector-inline-primitives-confirm-results.json'));
