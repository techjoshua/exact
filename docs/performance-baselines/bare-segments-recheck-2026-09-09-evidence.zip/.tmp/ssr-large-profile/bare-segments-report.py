import json, pathlib, hashlib, zipfile
d=pathlib.Path('.tmp/ssr-large-profile')
rows=json.loads((d/'bare-segments-current-results.json').read_text(encoding='utf-8'))
assert len(rows)==32
report='''# Segment wrapper recheck on the current renderer

Date: 2026-09-09. Bundle prototype only; production unchanged.

This removes the internal `{ segments: output }` wrapper and changes its two callers to consume
the array directly. No compiler helper, traversal, or lifecycle implementation changes. The
hypothesis is a small allocation saving. This is a repeat of the earlier segments-only experiment,
identified after starting this run, not a new architectural discovery. The earlier confirmation
found mixed results and explicitly recommended moving to larger sources of work.

The current control includes text-surroundings folding and the retained empty-cleanup optimization.
Thirty-two fresh production processes cover Node/Bun, string/consumed stream, three/96 incidents
with four assets, and two reversed-order pairs per cell. Each has 5,000 warmups and 12,000 measured
renders. Full document hashes match in every pair. No completed populations were discarded.
Positive percentages mean slower rendering; these are local timings, not HTTP rates.

| Runtime | Mode | Fixture | Pair 1 time change | Pair 2 time change |
| --- | --- | --- | ---: | ---: |
'''
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['small','large']:
   changes=[]
   for round in range(2):
    pair=[r for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['round']==round]
    assert len(pair)==2 and pair[0]['hash']==pair[1]['hash']
    old=next(r for r in pair if r['variant']=='unowned-program-current')
    new=next(r for r in pair if r['variant']=='bare-segments-current')
    changes.append((new['usPerRender']/old['usPerRender']-1)*100)
   report+=f'| {runtime} | {mode} | {scenario} | {changes[0]:+.2f}% | {changes[1]:+.2f}% |\n'
report+='''
These observations are preserved separately from the older measurements because the build and
asset workload differ. They do not establish that removing one wrapper closes the React gap.
No production change, new package validation, browser test, or React comparison is claimed.
Acceptance remains open pending consideration alongside the earlier mixed confirmation and
validation of the source change. Do not repeat another wrapper timing round without a specific
new reason. Work should return to removing intermediate traversal stages and enabling ordered
publication through the shared renderer.

The archive includes frozen control/candidate, runner, builder, worker, fixed input, all raw
observations, this reporter, and a verified SHA-256 manifest. The prior retained build remains
current. The overall goal remains incomplete.
'''
target=pathlib.Path('docs/performance-baselines/bare-segments-recheck-2026-09-09')
target.with_suffix('.md').write_text(report,encoding='utf-8')
files=[d/n for n in ['unowned-program-current.mjs','bare-segments-current.mjs','bare-segments-build.mjs','bare-segments-run.mjs','bare-segments-current-results.json','bare-segments-report.py','direct-map-worker.mjs']]+[pathlib.Path('.tmp/positional-leaves/data.json')]
manifest={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
archive=pathlib.Path(str(target)+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p).replace('\\','/'))
 z.writestr('sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(report)
