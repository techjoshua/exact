import fs from 'node:fs/promises';
const root='.tmp/ssr-large-profile/';
let builder=await fs.readFile(root+'http-json-regions-build.mjs','utf8');
builder=builder.replaceAll('http-json-regions','http-json-repeat');
builder=builder.replace("'auditNativeJson','auditScriptEscape'];","'auditNativeJson','auditScriptEscape','auditFirstJson','auditSecondJson'];");
const old='function auditNativeJson(payload,replacer){return JSON.stringify(payload,replacer);}';
const replacement="function auditNativeJson(payload,replacer){if(!auditActive)return JSON.stringify(payload,replacer);const first=auditFirstJson(payload,replacer);const second=auditSecondJson(payload,replacer);if(first!==second)throw Error(\"Repeated encoding changed output\");return first;}\\nfunction auditFirstJson(payload,replacer){return JSON.stringify(payload,replacer);}\\nfunction auditSecondJson(payload,replacer){return JSON.stringify(payload,replacer);}";
if(!builder.includes(old))throw Error('Missing native JSON helper');
builder=builder.replace(old,replacement);
await fs.writeFile(root+'http-json-repeat-build.mjs',builder);
for(const suffix of ['check.mjs','report.py']){
 const script=await fs.readFile(root+'http-json-regions-'+suffix,'utf8');
 await fs.writeFile(root+'http-json-repeat-'+suffix,script.replaceAll('http-json-regions','http-json-repeat'));
}
