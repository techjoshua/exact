import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';const dir=root+'http-json-repeat/';await fs.mkdir(dir,{recursive:true});
let source=await fs.readFile(root+'conditional-emission/server-entry.js','utf8');
const before=ts.createSourceFile('server-entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const serializer=before.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text==='serializeJson');
if(!serializer)throw Error('Missing serializer');
const expression=serializer.body.statements[0].expression.getText(before);
if(!expression.startsWith('JSON.stringify(payload, replacer).replace'))throw Error('Unexpected serializer');
const escaping=expression.replace('JSON.stringify(payload, replacer)','value');
const replacement='function serializeJson(payload,replacer){return auditScriptEscape(auditNativeJson(payload,replacer));}\nfunction auditNativeJson(payload,replacer){if(!auditActive)return JSON.stringify(payload,replacer);const first=auditFirstJson(payload,replacer);const second=auditSecondJson(payload,replacer);if(first!==second)throw Error("Repeated encoding changed output");return first;}\nfunction auditFirstJson(payload,replacer){return JSON.stringify(payload,replacer);}\nfunction auditSecondJson(payload,replacer){return JSON.stringify(payload,replacer);}\nfunction auditScriptEscape(value){return '+escaping+';}';
source=source.slice(0,serializer.getStart(before))+replacement+source.slice(serializer.end);

const ast=ts.createSourceFile('server-entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const names=['createSsrContext','renderComponentReference','renderIssuedServerComponentChildren','renderProgramWriter','renderChildren','renderHydrationScriptValue','validatePositionalValue','serializeJson','auditNativeJson','auditScriptEscape','auditFirstJson','auditSecondJson'];
const edits=[];
for(const name of names){
 const node=ast.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text===name);if(!node)throw Error('Missing '+name);
 edits.push({start:node.name.getStart(ast),end:node.name.end,text:'auditOriginal_'+name});
}
let output=source;for(const e of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,e.start)+e.text+output.slice(e.end);
let additions=`let auditActive=false,auditSequence=0,auditSamples=0,auditCurrent;let auditRegions={};
export function regionReset(){auditSequence=0;auditSamples=0;auditRegions={};}
export function regionRead(){return {samples:auditSamples,regions:auditRegions};}
export function regionBegin(){auditActive=(auditSequence++%64===0);if(auditActive)auditSamples++;}
export function regionEnd(){auditActive=false;}
`;
for(const name of names)additions+=`function ${name}(...args){
 if(!auditActive)return auditOriginal_${name}(...args);
 const parent=auditCurrent;const frame={child:0};auditCurrent=frame;const begin=performance.now();
 try{return auditOriginal_${name}(...args);}finally{
 const elapsed=performance.now()-begin;auditCurrent=parent;if(parent)parent.child+=elapsed;
 const value=auditRegions['${name}']??={calls:0,inclusiveMs:0,exclusiveMs:0};value.calls++;value.inclusiveMs+=elapsed;value.exclusiveMs+=elapsed-frame.child;
 }}\n`;
await fs.writeFile(dir+'server-entry.js',output+'\n'+additions);
let worker=await fs.readFile(root+'http-invocation-trace/worker.mjs','utf8');
worker='let regionModule;\n'+worker;
worker=worker.replace('const { renderParticipant, renderParticipantStream } = await import(pathToFileURL(entry).href);','regionModule=await import(pathToFileURL(entry).href); const {renderParticipant,renderParticipantStream}=regionModule;');
worker=worker.replace('const pending=work(); const returned=performance.now();',`let pending;if(name==='renderMs')regionModule.regionBegin();try{pending=work();}finally{if(name==='renderMs')regionModule.regionEnd();}const returned=performance.now();`);
worker=worker.replaceAll('audit={};','audit={};regionModule.regionReset();');
worker=worker.replace('writeJson(response,{audit,responseBytes:result.responseBytes})','writeJson(response,{audit,regions:regionModule.regionRead(),responseBytes:result.responseBytes})');
worker=worker.replace('telemetry:telemetry(),audit}','telemetry:telemetry(),audit,regions:regionModule.regionRead()}');
await fs.writeFile(dir+'worker.mjs',worker);
let runner=await fs.readFile(root+'http-execution-counts-run.mjs','utf8');
runner=runner.replaceAll('http-execution-counts','http-json-repeat').replace('renderer-function-entry-counts','sampled-synchronous-renderer-regions');
await fs.writeFile(root+'http-json-repeat-run.mjs',runner);
console.log('Built regions:',names.join(', '));
