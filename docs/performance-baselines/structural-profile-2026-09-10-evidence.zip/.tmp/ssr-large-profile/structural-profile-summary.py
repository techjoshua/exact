import json
from pathlib import Path
from collections import Counter

root=Path('.tmp/ssr-large-profile/structural-profile')
blocks=json.loads((root/'analysis.json').read_text())['blocks']
summary=[]
for variant in ['baseline','detail','combined']:
 selected=[b for b in blocks if b['id']==variant];assert len(selected)==2
 valid=sum(b['valid'] for b in selected)
 def weighted(key):return sum(b[key]*b['valid'] for b in selected)/valid
 groups=Counter();sites=Counter()
 for b in selected:
  groups.update({k:v['samples'] for k,v in b['groups'].items()})
  for site in b['self']:sites[(site['name'],site['module'])]+=site['samples']
 phases={key:sum(b['phases'][key]['meanUs']*b['phases'][key]['count'] for b in selected)/sum(b['phases'][key]['count'] for b in selected) for key in ['renderMs','firstByteMs','participantWorkMs']}
 row={'variant':variant,'valid':valid,'cpuUsPerRequest':weighted('cpuUsPerRequest'),'gcUsPerRequest':weighted('gcUsPerRequest'),'phasesUs':phases,'samplesPer10k':{k:v/valid*10000 for k,v in groups.items()},'topSelf':[{'name':n,'module':m,'samplesPer10k':count/valid*10000} for (n,m),count in sites.most_common(18) if n!='(idle)']}
 summary.append(row);print(json.dumps(row))
(root/'summary.json').write_text(json.dumps(summary,indent=2))
