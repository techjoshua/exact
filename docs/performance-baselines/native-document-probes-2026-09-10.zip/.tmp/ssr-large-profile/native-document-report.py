import pathlib,json,hashlib,zipfile
root=pathlib.Path.cwd();d=root/'.tmp/ssr-large-profile'
rows=json.loads((d/'native-document-results.json').read_text());assert len(rows)==48
lines=['# Native document probes, 2026-09-10','',
'Rejected experiment: native startsWith for a complete document prefix and endsWith for a complete lowercase closing suffix, retaining generic split-tag/mixed-case scanning. Hypothesis: a 1-3% improvement in finalization, particularly for Bun strings. Components and sinks remain independent of render mode.', '',
'Production Node 26.8.1, Bun 1.4.2, React 19.2.0. Each cell averages two fresh processes in reversed order, with 5,000 warmups and 12,000 measured renders per process. Full app-owned documents include four asset tags; streams are fully consumed. These are in-process timings, not HTTP throughput. Small documents contain three incidents and large documents 96. Complete eXact document hashes match the saved += control.', '',
'| Runtime | Mode | Document | Previous (µs) | Native probes (µs) | React (µs) |',
'| --- | --- | --- | ---: | ---: | ---: |']
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['assets','large']:
   means=[sum(r['usPerRender'] for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['variant']==v)/2 for v in ['previous','native','react']]
   lines.append(f'| {runtime} | {mode} | {scenario} | '+' | '.join(f'{x:.2f}' for x in means)+' |')
lines += ['', 'The candidate improved large Bun strings but regressed small Bun strings and streams. It did not establish a general benefit on the shared workstation. The probe changes were removed; retained production source keeps the += sink and previous finalizer. No component-side sink-type branch was introduced.', '',
'Validation: candidate package build and three focused output-result tests passed, including all split positions, mixed case, missing closing tag rejection, and chunk-preserving hydration insertion. The prior source was restored, rebuilt, and the focused tests passed again. No broad browser or HTTP benchmark was run for this rejected change.', '',
'Next architectural target, confirmed in current source: packages/ssr/src/render/render-program.ts invokes a three-argument compiler writer and returns its segment array. generatedSsrOperations.output still allocates that array, and operation-target.ts then visits the prepared segments. The native compiler already has an experimental four-argument continuation writer in jsx_render_program_ssr_continuation.go, but packages/core/src/render-program.ts still defines the three-argument array-returning contract. Integrating caller-owned output requires migrating compiler, core types, runtime, scheduling/capture ownership, tests, and initial-release ABI documentation together. This migration is not completed by the probe experiment.', '',
'Raw samples, exact measured bundles, and the harness are archived. Overall React parity remains unfinished.']
report=root/'docs/performance-baselines/native-document-probes-2026-09-10.md';report.write_text('\n'.join(lines)+'\n',encoding='utf8')
files=[d/n for n in ['native-document-run.mjs','native-document-results.json','native-document-report.py','production-refresh-worker.mjs']]+[root/r['entry'] for r in rows]
with zipfile.ZipFile(report.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 hashes={}
 for p in dict.fromkeys(files):
  content=p.read_bytes();name=p.relative_to(root).as_posix();hashes[name]=hashlib.sha256(content).hexdigest();z.writestr(name,content)
 z.writestr('sha256.json',json.dumps(hashes,indent=2))
print('\n'.join(lines[6:16]))
