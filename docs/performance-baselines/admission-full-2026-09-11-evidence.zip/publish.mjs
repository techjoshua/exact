import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile, copyFile } from 'node:fs/promises';
import { summarizePercentiles } from '../../framework-comparison/src/percentile-summary.mjs';
import { createSsrCapacityReport } from '../../framework-comparison/src/publish-ssr-capacity.mjs';
import { createHeapCompositionReport } from '../../framework-comparison/src/browser-heap-composition.mjs';
import { refreshDocsSsrDiagnostics, refreshDocsBunSsrDiagnostics } from '../../scripts/component-local-target-abi/refresh-docs-ssr-report.mjs';
import { adaptFrameworkComparisonBrowserRun, adaptFrameworkComparisonStartupCpu } from '../../scripts/component-local-target-abi/framework-comparison-adapters.mjs';

const root = '.tmp/admission-full';
const prefix = 'docs/performance-baselines/admission-full-2026-09-11';
const json = async path => JSON.parse(await readFile(path, 'utf8'));
const [browser, heap, ssr, startup, previous, framework, collections] = await Promise.all(
  ['browser', 'heap', 'ssr', 'startup', 'before-performance-report', 'framework', 'collections'].map(name => json(`${root}/${name}.json`))
);
assert.equal(browser.publishable, true);
assert.equal(startup.complete, true);
assert.equal(framework.complete, true);
adaptFrameworkComparisonBrowserRun(browser);
adaptFrameworkComparisonStartupCpu(startup);
for (const entry of heap.participants) {
  const id = `${entry.id}-controlled`;
  const hash = browser.complexity.find(value => value.participantId === id).artifacts.hash;
  assert.equal(entry.artifactHash, hash);
  assert.equal(startup.artifacts[id], hash);
}
const readers = {
  'Navigation completion': sample => sample.navigation.durationMs,
  'First contentful paint': sample => sample.navigation.firstContentfulPaintMs,
  'Optimistic feedback': sample => sample.optimisticFeedbackMs,
  'Authoritative settlement': sample => sample.settlementMs,
  'Warm browser used heap': sample => sample.heapBytes / 1e6
};
const ids = { Exact: 'exact-controlled', React: 'react-controlled', SvelteKit: 'sveltekit-controlled', Nuxt: 'nuxt-controlled', 'TanStack Start': 'tanstack-start-controlled' };
const browserCharts = previous.browserCharts.map(chart => ({
  ...chart,
  series: chart.series.map(series => ({ name: series.name, stats: summarizePercentiles(browser.browser[ids[series.name]].samples.map(readers[chart.title])) }))
}));
const chartMean = title => browserCharts.find(chart => chart.title === title).series.find(series => series.name === 'Exact').stats.mean;
let report = refreshDocsBunSsrDiagnostics(refreshDocsSsrDiagnostics({
  ...previous,
  browserCharts,
  metadata: {
    ...previous.metadata,
    commit: browser.harness.commit.slice(0, 8) + (browser.harness.workingTreeDirty ? '+worktree' : ''),
    browserCreatedAt: browser.createdAt,
    browserCommit: browser.harness.commit,
    browserSamples: browser.harness.sampleCount,
    startupSamples: startup.harness.sampleCount,
    startupCreatedAt: startup.createdAt,
    browserDelivery: browser.harness.clientDelivery,
    browserEnvironment: browser.environment
  },
  summary: [
    { label: 'Optimistic mean', value: chartMean('Optimistic feedback').toFixed(2) + ' ms', context: 'visible client feedback' },
    { label: 'Warm browser heap', value: chartMean('Warm browser used heap').toFixed(2) + ' MB', context: 'post-GC used heap' }
  ]
}, ssr), ssr);
report.metadata.capture = 'admission-full-2026-09-11';
report.metadata.createdAt = new Date().toISOString();
const sources = {};
const streamRaw = await json(`${root}/ssr-stream.json`);
assert.equal(ssr.harness.renderMode, 'string');
assert.equal(streamRaw.harness.renderMode, 'stream');
const streamReport = refreshDocsBunSsrDiagnostics(refreshDocsSsrDiagnostics(previous, streamRaw), streamRaw);
streamReport.metadata = { renderMode:'stream', createdAt:streamRaw.createdAt, ssrCreatedAt:streamRaw.createdAt, ssrDiagnosticsEnvironment:streamRaw.environment, ssrSequentialSamples:streamRaw.harness.sampleCount, ssrBurstSamples:streamRaw.harness.concurrencyWaves, ssrRetentionCheckpoints:streamRaw.harness.retentionBatches };
delete streamReport.browserCharts;
delete streamReport.summary;
streamReport.server.sequential.comment = 'Complete warm HTTP response latency using the streaming API, including fixture fetching, rendering, and stream consumption. Lower is better.';
streamReport.server.bun.sequential.comment = streamReport.server.sequential.comment;
report.metadata.ssrRenderMode = 'string';
report.metadata.browserRenderMode = 'string';
for (const lane of ['browser', 'heap', 'ssr', 'startup', 'node-multi', 'node-normal', 'node-arrivals', 'bun-multi', 'bun-normal', 'bun-arrivals', 'collections', 'framework', 'ssr-stream', 'node-stream-multi', 'node-stream-normal', 'node-stream-arrivals', 'bun-stream-multi', 'bun-stream-normal', 'bun-stream-arrivals']) {
  const path = `${prefix}-${lane}.json`;
  await copyFile(`${root}/${lane}.json`, path);
  sources[lane] = { path, sha256: createHash('sha256').update(await readFile(path)).digest('hex') };
}
report.metadata.sources = {
  browser: sources.browser, heap: sources.heap, startupCpu: sources.startup,
  ssrDiagnostics: sources.ssr, ssrBunDiagnostics: sources.ssr
};
report.metadata.browserSource = sources.browser;
const capacities = {};
const capacitiesStream = {};
for (const runtime of ['node','bun']) {
 const lanes = Object.fromEntries(await Promise.all(['multi','normal','arrivals'].map(async lane => [lane, await json(`${root}/${runtime}-stream-${lane}.json`)])));
 capacitiesStream[runtime] = createSsrCapacityReport(lanes, lanes.normal);
 assert.equal(capacitiesStream[runtime].renderMode, 'stream');
 await writeFile(`apps/docs/src/data/ssr-${runtime}-stream-capacity-report.json`, JSON.stringify(capacitiesStream[runtime], null, 2)+'\n');
}
streamReport.metadata.source = sources['ssr-stream'];
await writeFile('apps/docs/src/data/ssr-stream-report.json', JSON.stringify({metadata:streamReport.metadata, server:streamReport.server}, null, 2)+'\n');
for (const runtime of ['node', 'bun']) {
  const lanes = Object.fromEntries(await Promise.all(['multi', 'normal', 'arrivals'].map(async lane => [lane, await json(`${root}/${runtime}-${lane}.json`)])));
  const capacity = createSsrCapacityReport(lanes, lanes.normal);
  capacities[runtime] = capacity;
  await writeFile(`apps/docs/src/data/ssr-${runtime === 'bun' ? 'bun-' : ''}capacity-report.json`, JSON.stringify(capacity, null, 2) + '\n');
}
await writeFile(`${root}/report-data.json`, JSON.stringify(report, null, 2) + '\n');
await writeFile('apps/docs/src/data/performance-report.json', JSON.stringify(report, null, 2) + '\n');
await writeFile('apps/docs/src/data/performance-heap-report.json', JSON.stringify(createHeapCompositionReport(heap), null, 2) + '\n');
const decodeLog = async name => {
  const bytes = await readFile(`${root}/${name}.log`);
  return bytes.toString(bytes[0] === 255 && bytes[1] === 254 ? 'utf16le' : 'utf8');
};
const reactive = JSON.parse((await decodeLog('reactive')).split('REACTIVE_BENCHMARK_JSON=')[1].trim());
const dom = JSON.parse((await decodeLog('dom-list')).split('DOM_LIST_BENCHMARK_JSON=')[1].trim());
const supplemental = { foundations: await json(`${root}/foundations.json`) };
for (const [name, marker] of Object.entries({ server: 'EXACT_SERVER_BENCHMARK_JSON=', compiler: 'COMPILER_BENCHMARK_JSON=', devtools: 'DEVTOOLS_BENCHMARK_JSON=', 'react-compat': 'REACT_COMPAT_BENCHMARK_JSON=' })) {
  const line = (await decodeLog(name)).split(/\r?\n/).find(line => line.startsWith(marker));
  assert.ok(line, `${name} must provide structured benchmark evidence`);
  supplemental[name] = JSON.parse(line.slice(marker.length));
}
supplemental['react-adapters'] = JSON.parse(await decodeLog('react-adapters'));
for (const [name, capture] of Object.entries(supplemental)) {
  const path = `${prefix}-${name}.json`;
  await writeFile(path, JSON.stringify(capture, null, 2) + '\n');
  sources[name] = { path, sha256: createHash('sha256').update(await readFile(path)).digest('hex') };
}
const execution = await json(`${root}/execution.json`);
assert.ok(Object.values(Object.fromEntries(execution.map(step => [step.name, step]))).every(step => step.code === 0), 'Every requested measurement stage must finish successfully');
const defaultExecution = execution.filter(step => /^(node|bun)(-stream)?-(multi|normal|arrivals)$/.test(step.name) || ['ssr','ssr-stream'].includes(step.name));
const finalStages = Object.values(Object.fromEntries(defaultExecution.map(step => [step.name, step])));
assert.equal(finalStages.length, 14, 'All twelve capacity captures and both SSR diagnostics must be refreshed');
assert.ok(finalStages.every(step => step.code === 0), 'Final default-adapter measurements must succeed');
const previousCapacity = {
  node: await json(`${root}/before-ssr-capacity-report.json`),
  bun: await json(`${root}/before-ssr-bun-capacity-report.json`)
};
const comparison = {
  browser: browserCharts.map(chart => ({ metric: chart.title, unit: chart.unit, current: chart.series[0].stats.mean, previous: previous.browserCharts.find(old => old.title === chart.title).series[0].stats.mean })),
  capacities: Object.fromEntries(['node', 'bun'].map(runtime => [runtime, capacities[runtime].preloaded.map(row => ({ ...row, previousRps: previousCapacity[runtime].preloaded.find(old => old.name === row.name && old.concurrency === row.concurrency).rps }))]))
};
const archive = {
  createdAt: report.metadata.createdAt, sources, report, capacities, comparison, reactive, dom, collections,
  framework, supplemental, execution, defaultExecution, streamReport, capacitiesStream, currentBuildVerification: await json(`${root}/current-build-verification.json`), previousReport: previous, previousCapacity,
  environment: { browser: browser.environment, startup: startup.environment, ssr: ssr.environment },
  harness: { browser: browser.harness, startup: startup.harness, ssr: ssr.harness },
  artifactIdentities: browser.complexity.map(entry => ({ participant: entry.participantId, artifact: entry.artifacts })),
  runners: { measure: await readFile(`${root}/run.mjs`, 'utf8'), finalHttp: await readFile(`${root}/run.mjs`, 'utf8'), capacity: await readFile(`${root}/capacity-runner.mjs`, 'utf8'), publish: await readFile(import.meta.filename, 'utf8') }
};
await writeFile(`${prefix}.json`, JSON.stringify(archive, null, 2) + '\n');
await writeFile(`${root}/comparison.json`, JSON.stringify(comparison, null, 2) + '\n');
console.log(JSON.stringify({ comparison, capacities }, null, 2));
