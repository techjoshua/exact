import {spawn} from 'node:child_process';
import {openSync,closeSync,readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
const root=resolve('.'),dir=resolve('.tmp/admission-full');
const steps=[];
process.env.NODE_ENV='production';
const done=JSON.parse(readFileSync(dir+'/execution.json'));
const latest=Object.values(Object.fromEntries(done.map(s=>[s.name,s])));
if(latest.length!==28||latest.some(s=>s.code!==0))throw Error('Final measurements must finish before checks');
async function run(name,exe,args){
 const nodeEnv=['packages','comparison-tests','test-types','docs-types','docs-tests'].includes(name)?'test':'production';
 const step={name,args,nodeEnv,startedAt:new Date().toISOString()};steps.push(step);
 const save=()=>writeFileSync(dir+'/completion-checks.json',JSON.stringify(steps,null,2));save();
 console.log('START '+name);const log=openSync(dir+'/completion-'+name+'.log','w');
 try{await new Promise((yes,no)=>{const child=spawn(exe,args,{cwd:root,env:{...process.env,NODE_ENV:nodeEnv},windowsHide:true,stdio:['ignore',log,log]});step.pid=child.pid;save();child.once('error',no);child.once('exit',(code,signal)=>{step.code=code;step.signal=signal;code===0?yes():no(Error(name+' failed '+(code??signal)));});});}
 finally{closeSync(log);step.endedAt=new Date().toISOString();save();}console.log('DONE '+name);
}
const npm='C:/Program Files/nodejs-v26.8.1/node_modules/npm/bin/npm-cli.js';
await run('artifacts',process.execPath,[dir+'/verify-artifacts.mjs']);
await run('publish',process.execPath,[dir+'/publish.mjs']);
await run('report','C:/Python314/python.exe',[dir+'/write-report.py']);
await run('format',process.execPath,['node_modules/prettier/bin/prettier.cjs','--write','docs/performance-baselines/admission-full-2026-09-11.md','apps/docs/src/data/*.json']);
await run('comparison-tests',process.execPath,[npm,'run','test:framework-comparison']);
await run('docs-types',process.execPath,[npm,'run','typecheck','-w','@exactjs/docs']);
await run('docs-tests',process.execPath,[npm,'run','test','-w','@exactjs/docs']);
await run('docs-build',process.execPath,[npm,'run','build','-w','@exactjs/docs']);
await run('docs-browser',process.execPath,[dir+'/verify-docs.mjs']);
await run('diff','git',['diff','--check']);
console.log('COMPLETE publication and final checks');
