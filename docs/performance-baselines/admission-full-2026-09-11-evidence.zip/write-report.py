from pathlib import Path
import json
root=Path('.tmp/admission-full')
lines=['# Full benchmarks after Node admission changes, September 11, 2026','',
'This capture includes the revised adaptive Node admission policy, retained child normalization, one rendering engine, separate',
'application hydration and document-shell ownership, incremental 8192-byte streaming, compiler-proven',
'static heads before blocking tasks, and automatic adaptive Node admission. Native Bun retains',
'immediate admission. React uses its unchanged framework renderer and runtime transport. Both',
'frameworks render their complete authored application and document shell for every request.',
'',
'Production Node 26.8.1 and Bun 1.4.2 ran locally on the same PC with variable foreground usage.',
'Two independent load generators validate complete response hashes. Each population reverses',
'framework order. Values below are the two populations, not a comparison with an earlier idle PC run.',
'String and stream APIs are separate. No response coalescing or cached rendered documents are used.',
 'The measured source commit is `9a98803a68772e57af44b4be39963a5baed03561`. The capture reports',
 'a dirty workspace because unrelated untracked output directories were present; tracked source was',
 'unchanged. Frozen measured bundles and client artifact hashes are verified before publication.',
'',
'## Sustained capacity','',
'Preloaded capacity isolates rendering and HTTP response delivery; normal loading includes fetching',
'the application data. Both rows use total concurrency 32. RPS is valid completed responses per second.',
'',
'| Runtime | API | Loading | eXact RPS | React RPS | eXact driver p99 ms | React driver p99 ms |',
'| --- | --- | --- | ---: | ---: | --- | --- |']
captures={}
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for lane in ['multi','normal','arrivals']:
   name=runtime+('-stream' if mode=='stream' else '')+'-'+lane
   c=json.loads((root/(name+'.json')).read_text());assert c['complete'];captures[name]=c
   if lane=='arrivals':continue
   values={}
   for id in ['exact','react']:
    rates=[];tails=[]
    for b in sorted((b for b in c['blocks'] if b['id']==id),key=lambda b:b['population']):
     ss=[next(s for s in r['stages'] if s['name']=='total-c32') for r in b['results']]
     rates.append(f'{sum(s["validRps"] for s in ss):,.0f}')
     tails.extend(s['distributions']['responseMs']['p99'] for s in ss)
    values[id]=(' / '.join(rates),f'{min(tails):.1f} to {max(tails):.1f}')
   lines.append(f'| {runtime.title()} | {mode} | {"preloaded" if lane=="multi" else "normal"} | {values["exact"][0]} | {values["react"][0]} | {values["exact"][1]} | {values["react"][1]} |')
lines+=['','## Scheduled demand','',
'Misses are requests the load generator could not start on schedule, distinct from response errors.',
'The public charts retain each runtime, API, offered rate, valid RPS, misses, errors, and response tails.',
 'Missed arrivals below include capacity, driver-lag, and end-of-stage misses across both populations.',
 'The capacity-only subset is shown separately; p99 ranges span individual drivers and populations.',
'',
'| Runtime/API | Framework | Offered RPS | Valid RPS, two populations | Errors | Missed arrivals | Capacity misses | Driver p99 ms |',
'| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |']
error_counts={};invalid=0;total_errors=0
for name,c in captures.items():
 for b in c['blocks']:
  for r in b['results']:
   for s in r['stages']:
    if s['name']=='warmup':continue
    invalid+=s.get('invalid',0);total_errors+=s['errors']
    for k,v in s.get('errorDetails',{}).get('counts',{}).items():error_counts[k]=error_counts.get(k,0)+v
 if not name.endswith('arrivals'):continue
 for id in ['exact','react']:
  for rate in [8000,10000]:
   rates=[];errors=misses=capacity_misses=0;tails=[]
   for b in sorted((b for b in c['blocks'] if b['id']==id),key=lambda b:b['population']):
    ss=[next(s for s in r['stages'] if s['name']==f'total-arrivals-{rate}') for r in b['results']]
    rates.append(f'{sum(s["validRps"] for s in ss):,.0f}')
    errors+=sum(s['errors'] for s in ss)
    misses+=sum(s['missedCapacity']+s['missedLag']+s['missedDeadline'] for s in ss)
    capacity_misses+=sum(s['missedCapacity'] for s in ss)
    tails.extend(s['distributions']['responseMs']['p99'] for s in ss)
   lines.append(f'| {c["runtimeId"].title()} {c["renderMode"]} | {"eXact" if id=="exact" else "React"} | {rate:,} | {" / ".join(rates)} | {errors:,} | {misses:,} | {capacity_misses:,} | {min(tails):.1f} to {max(tails):.1f} |')

lines+=['',f'The capacity captures recorded {invalid:,} invalid responses and {total_errors:,} request errors.',
 'Error categories: '+(json.dumps(error_counts,sort_keys=True) if error_counts else 'none.'),'',
 'Missed arrivals and request errors remain visible in the published data. They are not removed',
 'to obtain a clean chart. These results reflect this PC during the capture; differences from older',
 'idle-PC runs are not attributed to the code change.','',
 '## Client measurements','',
 'All five frameworks use the common in-memory replay delivery path, with framework servers stopped',
 'during client timing. The capture includes 30 balanced navigation/interaction rounds, startup at',
 '1x/4x/6x CPU, and five heap samples per framework. Both eXact and React render their authored shells',
 'before replay capture. These client measurements are separate from HTTP capacity.','',
 '| Client metric | eXact mean | React mean | Unit |','| --- | ---: | ---: | --- |']
report=json.loads((root/'report-data.json').read_text())
for chart in report['browserCharts']:
 values={s['name']:s['stats']['mean'] for s in chart['series']}
 lines.append(f"| {chart['title']} | {values['Exact']:.3f} | {values['React']:.3f} | {chart['unit']} |")
lines+=['','## Retained change and evidence','',
 'The [Node admission changes](node-admission-misses-2026-09-11.md) shorten immediate-control',
 'observations to 250 ms when at least 100 responses complete, while retaining up to 750 ms for',
 'lower-volume observations. Scheduled trials and enabled observations remain 750 ms. Successful',
 'policies are routinely rechecked after 30 seconds instead of 5 seconds. Early reassessment after',
 'poor completion or lag, quiet-period cleanup, and cancellation remain in place. The controller',
 'still requires improved completion capacity and lower lag against both surrounding controls.','',
 'The earlier [child-normalization improvement](v8-attribute-and-child-normalization-2026-09-11.md)',
 'is retained. The shared renderer, authored shell behavior, 8192-byte streaming buffer, and',
 'hydration contracts are unchanged. Bun retains its existing immediate admission behavior.',
 'Each request independently renders its component tree and complete document. React rendering',
 'and transport remain unchanged.','',
 'All 112 live Node/Bun string/stream browser checks passed before timing. Core and SSR tests, type',
 'checking, compiled-artifact compatibility, and platform/package boundaries were validated for the',
 'retained change. The final publication checks are recorded in the accompanying evidence.','',
 '[Full structured capture](admission-full-2026-09-11.json) preserves all source identities,',
 'raw capture links, execution journal, client/SSR reports, and supplemental framework benchmarks.',
 'All twelve capacity captures and both full SSR diagnostic modes use the same persistent telemetry',
 'control transport. Build identity verification ensures the published measurements match the',
 'retained application artifacts.','']
Path('docs/performance-baselines/admission-full-2026-09-11.md').write_text('\n'.join(lines),encoding='utf8')
print(json.dumps({'invalidResponses':invalid,'requestErrors':total_errors,'errorCounts':error_counts}))
