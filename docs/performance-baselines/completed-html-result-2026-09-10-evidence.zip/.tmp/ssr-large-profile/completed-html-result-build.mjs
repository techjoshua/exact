import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';
let code=fs.readFileSync(root+'individual-result-integrated/server-entry.js','utf8');
assert.equal(createHash('sha256').update(code).digest('hex'),'069f9784fa667af7896202923a6c08622ae1bb3f4060054328314dbe1ae6619b');
function replace(from,to){assert.equal(code.split(from).length,2,from);code=code.replace(from,to);}
replace(`const result = Object.defineProperty({
\t\thtml: void 0,
\t\tstate
\t}, "html", stringResultDescriptors.html);
\tObject.defineProperty(result, resultStorage, { value: {
\t\tchunks,
\t\tmaterialized: void 0
\t} });`,`const result = {html: chunks.length === 1 ? chunks[0] : chunks.join(""), state};`);
replace('htmlWithHydration: void 0,\n\t\thtml: void 0,','htmlWithHydration: void 0,\n\t\thtml: result.html,');
replace('\tObject.defineProperty(hydratable, "html", hydratableResultDescriptors.html);','');
replace('\t\tmaterialized: void 0,\n\t\tresult,\n\t\tresumptions','\t\tmaterialized: void 0,\n\t\tresumptions');
fs.mkdirSync(root+'completed-html-result',{recursive:true});
fs.writeFileSync(root+'completed-html-result/server-entry.js',code);
for(const kind of ['allocations','gc-run']){
 const script=fs.readFileSync(root+'instance-root-receiver-'+kind+'.mjs','utf8').replaceAll('instance-root-receiver','completed-html-result');
 fs.writeFileSync(root+'completed-html-result-'+kind+'.mjs',script);
}
const runner=fs.readFileSync(root+'current-body-checkpoint-encoded-run.mjs','utf8').replaceAll('current-body-checkpoint','completed-html-result');
fs.writeFileSync(root+'completed-html-result-encoded-run.mjs',runner);
