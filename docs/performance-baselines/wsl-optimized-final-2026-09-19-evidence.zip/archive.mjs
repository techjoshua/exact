import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {readFile,writeFile,copyFile,mkdir,readdir} from 'node:fs/promises';
import {dirname} from 'node:path';
import {createHash} from 'node:crypto';
const root='.tmp/wsl-optimized-final-2026-09-19',prefix='docs/performance-baselines/wsl-optimized-final-2026-09-19';
const json=async p=>JSON.parse(await readFile(p,'utf8'));
const source=await json(root+'/source-state.json');
const changed=[];
for(const [path,hash] of Object.entries(source.files))if(createHash('sha256').update(await readFile(path)).digest('hex')!==hash)changed.push(path);
assert.deepEqual(changed.filter(path=>path!=='framework-comparison/README.md'),[],'Measured implementation must remain unchanged; the README is updated after timing');
const native=await json(root+'/native.json');assert.equal(native.publishable,true);
await copyFile(root+'/native.json',prefix+'-native.json');
const archive=await json(prefix+'.json');
archive.sources.native={path:prefix+'-native.json',sha256:createHash('sha256').update(await readFile(prefix+'-native.json')).digest('hex')};
archive.native={correctness:'8 browser contracts passed',capture:native};
if(changed.length===0)archive.sourceVerification={checkedAt:new Date().toISOString(),files:Object.keys(source.files).length,changed};
else {assert.deepEqual(archive.sourceVerification.changed,[]);archive.documentationUpdatedAfterMeasurement=changed;}
await writeFile(prefix+'.json',JSON.stringify(archive,null,2)+'\n');
const evidence=root+'/evidence';await mkdir(evidence,{recursive:true});
for(const entry of await readdir(root))if(/\.(mjs|log|patch|png)$/.test(entry)||entry.endsWith('-plan.json')||['execution.json','source-state.json','docs-verification.json','before-performance-report.json','ratio-comparison.json'].includes(entry))await copyFile(root+'/'+entry,evidence+'/'+entry);
const untracked=execFileSync('git',['ls-files','--others','--exclude-standard','-z','--','packages','component-libraries','framework-adapters','native','scripts','framework-comparison'],{encoding:'utf8'}).split('\0').filter(Boolean);
for(const path of untracked){const target=evidence+'/untracked-source/'+path;await mkdir(dirname(target),{recursive:true});await copyFile(path,target);}
console.log(JSON.stringify(archive.sourceVerification));
