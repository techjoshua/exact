import {createServer} from 'node:http';
import {readFile,writeFile} from 'node:fs/promises';
import {chromium} from 'playwright';
import assert from 'node:assert/strict';
const root='.tmp/wsl-optimized-final-2026-09-19';
const capacities=await Promise.all(['ssr-capacity-report','ssr-bun-capacity-report','ssr-node-stream-capacity-report','ssr-bun-stream-capacity-report'].map(async name=>JSON.parse(await readFile(`apps/docs/src/data/${name}.json`,'utf8'))));
const html=await readFile('apps/docs/dist/index.html');
const report=JSON.parse(await readFile('apps/docs/src/data/performance-report.json','utf8'));
const stream=JSON.parse(await readFile('apps/docs/src/data/ssr-stream-report.json','utf8'));
const heap=JSON.parse(await readFile('apps/docs/src/data/performance-heap-report.json','utf8'));
const server=createServer((_,res)=>{res.setHeader('content-type','text/html');res.end(html);});
let browser;
try{
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 browser=await chromium.launch();
 const checked=[];
 for(const [name,width,height] of [['desktop',1440,1000],['mobile',390,844]]){
  const page=await browser.newPage({viewport:{width,height}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto(`http://127.0.0.1:${server.address().port}/#/performance`);
  await page.getByRole('heading',{name:'Browser experience and server capacity',exact:true}).waitFor();
  await page.getByRole('heading', {name: 'Node v26.9.0 SSR capacity: string API', exact: true}).waitFor(); await page.getByRole('heading', {name: 'Server response time and memory: Bun 1.4.2, string API', exact: true}).waitFor(); await page.getByRole('heading', {name: 'Server response time and memory: Node v26.9.0, string API', exact:true}).waitFor(); assert.equal((await page.locator('main').innerText()).includes('Bun?s'), false); assert.equal((await page.locator('main').innerText()).includes('Node?s'), false); await page.locator('.performance-summary strong').first().waitFor(); await page.getByRole('heading',{name:'Rendering and response handling with data preloaded'}).first().waitFor();
  assert.deepEqual(await page.locator('.performance-summary strong').allTextContents(),[...capacities.map(capacity=>Math.round(Math.max(...capacity.preloaded.filter(r=>r.name==='eXact').map(r=>r.rps))).toLocaleString('en-US')+' RPS'),...report.summary.filter(r=>!r.label.includes('RPS')).map(r=>r.value)]);
  const expected=[...report.browserCharts,report.server.burst,report.server.sequential,report.server.retention,report.server.bun.burst,report.server.bun.sequential,report.server.bun.retention,stream.server.burst,stream.server.sequential,stream.server.retention,stream.server.bun.burst,stream.server.bun.sequential,stream.server.bun.retention];
  const tables=page.locator('.performance-chart-card table');
  const actual=await tables.evaluateAll(ts=>ts.map(t=>({headers:[...t.querySelectorAll('thead th')].map(e=>e.textContent),rows:[...t.querySelectorAll('tbody tr')].map(r=>[...r.children].map(c=>c.textContent))})));
  const distributions=actual.filter(t=>t.headers[1]==='Mean'||t.headers[1]==='Aggregate');
  assert.equal(distributions.length,expected.length);
  for(let i=0;i<expected.length;i++)assert.deepEqual(distributions[i].rows,expected[i].series.map(s=>[s.name,...(s.aggregate===undefined?[]:[new Intl.NumberFormat('en-US',{maximumFractionDigits:expected[i].precision}).format(s.aggregate)]),...['mean','p50','p75','p95','p99'].map(k=>new Intl.NumberFormat('en-US',{maximumFractionDigits:expected[i].precision}).format(s.stats[k]))]));
  const ht=actual.find(t=>t.headers.at(-1)==='Total');
  assert.deepEqual(ht.rows,heap.categories.map((c,i)=>[c,...heap.series.map(s=>s.values[i].toFixed(3)),heap.totals[i].toFixed(3)]));
  for(const capacity of capacities){
 const modeLabel=capacity.renderMode==='stream'?'streaming API':'string API';
  const preloadedTable=page.getByRole('table',{name:`Preloaded capacity by concurrency: ${capacity.runtime}, ${modeLabel}`});
  assert.deepEqual(await preloadedTable.locator('tbody tr').allTextContents(),capacity.preloaded.map(r=>r.name+r.concurrency+r.rps.toFixed(0)));
  const normalTable=page.getByRole('table',{name:`Normal-loading sustained throughput: ${capacity.runtime}, ${modeLabel}`});
  assert.deepEqual(await normalTable.locator('tbody tr').allTextContents(),capacity.normal.map(r=>r.name+r.rps.toFixed(0)));
  const arrivalTable=page.getByRole('table',{name:`Preloaded throughput under scheduled demand: ${capacity.runtime}, ${modeLabel}`});
  const arrivalRows=await arrivalTable.locator('tbody tr').evaluateAll(rows=>rows.map(row=>[...row.children].map(cell=>cell.textContent.trim())));
  assert.deepEqual(arrivalRows,capacity.arrivals.map(r=>[r.name,String(r.rate),r.rps.toFixed(0),r.capacityMissPercent.toFixed(2)+'%',`${r.requestErrors} (${r.requestErrorPercent.toFixed(3)}%)`,`${r.p99Min.toFixed(1)}\u2013${r.p99Max.toFixed(1)} ms`]));
  }
  for(const id of ['node-string','bun-string','node-stream','bun-stream']) assert.equal(await page.locator(`#performance-sustained-preloaded-${id}`).count(),1);
 for(const id of ['node','bun']) assert.equal(await page.locator(`#performance-response-composition-${id}`).count(),1);
  assert.equal(await page.locator('#performance-node-throughput-scaling').count(),0);
  assert.equal(await page.locator('body').evaluate(el=>el.scrollWidth>window.innerWidth),false);
  await page.locator('#performance-sustained-preloaded-bun-stream').screenshot({path:`${root}/bun-capacity-${name}.png`});
  await page.screenshot({path:`${root}/docs-${name}.png`,fullPage:true});
  await page.locator('.performance-heap-chart').screenshot({path:`${root}/heap-${name}.png`});
  assert.deepEqual(errors,[]);checked.push({name,distributionTables:distributions.length,heapRows:ht.rows.length});await page.close();
 }
 const serverPage = await browser.newPage();
 await serverPage.goto(`http://127.0.0.1:${server.address().port}/#/runtimes`);
 await serverPage.getByText('Precompiled Node applications can load the React compatibility adapter', {exact:false}).waitFor();
 await serverPage.goto(`http://127.0.0.1:${server.address().port}/#/advanced`);
 await serverPage.getByText(/recheck successful policies after 30 seconds/).waitFor();
 await serverPage.close();
 await writeFile(`${root}/docs-verification.json`,JSON.stringify(checked,null,2));console.log(checked);
}finally{try{await browser?.close();}finally{await new Promise(resolve=>server.close(resolve));}}







