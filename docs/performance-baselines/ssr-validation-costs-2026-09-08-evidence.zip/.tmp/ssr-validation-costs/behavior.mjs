import { readFile, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
import * as original from './original-entry.mjs';
import * as unchecked from './unchecked-projection.mjs';
const data = JSON.parse(await readFile('.tmp/ssr-validation-costs/data.json', 'utf8'));
const cases = {
 undefined: value => { value.incidents[0].version = undefined; },
 nonfinite: value => { value.incidents[0].version = NaN; },
 extraField: value => { value.incidents[0].extraField = 'must-survive-hydration'; }
};
const results = [];
for (const [name, mutate] of Object.entries(cases)) {
 const row = { name };
 for (const [variant, entry] of Object.entries({ original, unchecked })) {
  const value = structuredClone(data); mutate(value);
  let output = '';
  try {
   entry.renderParticipantToSink(value, '/incidents/inc-101', span => output += span, Buffer.byteLength);
   row[variant] = { accepted: true, preservedExtraField: output.includes('must-survive-hydration'), hydration: output.match(/<script type="application\/json"[^>]*>(.*?)<\/script>/s)?.[1] };
  } catch (error) { row[variant] = { accepted: false, error: error.message }; }
 }
 results.push(row);
 console.log(name, JSON.stringify({ original: {...row.original, hydration: undefined}, unchecked: {...row.unchecked, hydration: undefined} }));
}
assert.equal(results[0].original.accepted, false);
assert.equal(results[0].unchecked.accepted, true);
assert.equal(results[1].original.accepted, false);
assert.equal(results[1].unchecked.accepted, true);
assert.equal(results[2].original.preservedExtraField, true);
assert.equal(results[2].unchecked.preservedExtraField, false);
await writeFile('.tmp/ssr-validation-costs/behavior.json', JSON.stringify(results, null, 2));
