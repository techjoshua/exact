import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const root = '.tmp/ssr-validation-costs/';
const summary = { nodeVersion: process.version, bunVersion: '1.4.2', artifacts: {}, captures: {} };
for (const name of ['original-entry', 'inline-leaves', 'unchecked-leaves', 'unchecked-projection']) {
 summary.artifacts[name] = createHash('sha256').update(await readFile(root + name + '.mjs')).digest('hex');
}
for (const filename of ['candidates-node-first.json', 'candidates-node.json', 'candidates-bun.json', 'projection-cost-node.json', 'projection-cost-bun.json']) {
 const samples = JSON.parse(await readFile(root + filename, 'utf8'));
 summary.captures[filename] = [...new Set(samples.map(s => s.name))].map(name => {
  const rows = samples.filter(s => s.name === name);
  return { name, rounds: rows.length, microseconds: rows.reduce((sum, row) => sum + row.microseconds, 0) / rows.length };
 });
}
await writeFile('docs/performance-baselines/ssr-validation-costs-2026-09-08.json', JSON.stringify(summary, null, 2) + '\n');
