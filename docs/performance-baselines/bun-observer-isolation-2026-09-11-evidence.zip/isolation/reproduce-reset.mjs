import {resolve} from 'node:path';import {writeFile} from 'node:fs/promises';
import {startSsrLoadProcess} from '../../framework-comparison/src/ssr-load-process-owner.mjs';
import {startSsrWorker,stopSsrWorker} from '../../framework-comparison/src/ssr-worker-controller.mjs';
import {availableSsrRuntimes} from '../../framework-comparison/src/ssr-run-environment.mjs';
const results=[];
for(const variant of ['shared-monitor','focus']){
 let service,worker;
 try {service=await startSsrLoadProcess('service');worker=await startSsrWorker({runtime:availableSsrRuntimes('bun')[0],participantId:'exact',transport:'bun-fetch',workerPath:resolve('.tmp/bun-adaptive-auto/'+variant+'-worker.mjs'),workingDirectory:resolve('framework-comparison'),serviceUrl:service.url});
 for(let i=0;i<8;i++){const r=await fetch(worker.url+'?__benchmarkPreloaded=true');await r.text();}
 await new Promise(r=>setTimeout(r,800));const r=await fetch(worker.controlUrl+'/reset',{method:'POST'});const body=await r.text();const value={variant,status:r.status,body:body.slice(0,1000),stderr:worker.stderr()};results.push(value);console.log(variant,r.status,body.slice(0,120));
 }finally{if(worker)await stopSsrWorker(worker);if(service)await service.close();}
}
await writeFile('.tmp/bun-adaptive-auto/control-monitor-reproduction.json',JSON.stringify(results,null,2));
