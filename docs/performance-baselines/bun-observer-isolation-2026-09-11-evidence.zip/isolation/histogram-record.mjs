import {createHistogram} from 'node:perf_hooks';
const a=createHistogram(),b=createHistogram();a.record(2000000);b.record(4000000);a.reset();console.log(a.count,b.count,b.percentile(95));
const samples=[];let last=performance.now();const timer=setInterval(()=>{const now=performance.now();samples.push(now-last);last=now;},2);await new Promise(r=>setTimeout(r,100));clearInterval(timer);samples.sort((a,b)=>a-b);console.log(samples.length,samples[Math.floor(samples.length*.95)]);
