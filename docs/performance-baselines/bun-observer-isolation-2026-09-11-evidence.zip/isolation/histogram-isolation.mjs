import {monitorEventLoopDelay} from 'node:perf_hooks';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const first=monitorEventLoopDelay({resolution:1}),second=monitorEventLoopDelay({resolution:2});first.enable();second.enable();await sleep(60);console.log('both',first.count,second.count);second.disable();first.reset();await sleep(120);console.log('first after second disabled',first.count);first.disable();
