/** Scratch lazy continuation. Native assimilation evaluates it; internal chains remain stack work. */
class AuditStep {
 constructor(kind,source,fulfilled,rejected){this.kind=kind;this.source=source;this.fulfilled=fulfilled;this.rejected=rejected;}
 then(fulfilled,rejected){
  try{return Promise.resolve(auditEvaluate(this)).then(fulfilled,rejected);}
  catch(error){return Promise.reject(error).then(fulfilled,rejected);}
 }
}
function auditPending(value){return value instanceof AuditStep||value instanceof Promise;}
function auditThen(value,fulfilled,rejected){return value instanceof AuditStep?new AuditStep(1,value,fulfilled,rejected):value.then(fulfilled,rejected);}
function auditFinally(value,cleanup){return value instanceof AuditStep?new AuditStep(2,value,cleanup):value.finally(cleanup);}
/** Iterative depth-first execution retains success/error handlers until each child settles. */
function auditEvaluate(initial){
 const frames=[];
 function run(value,failed=false){
  for(;;){
   if(!failed&&value instanceof AuditStep){
    const step=value;
    if(step.kind===0){try{value=step.source();}catch(error){value=error;failed=true;}}
    else{frames.push(step);value=step.source;}
    continue;
   }
   if(!failed&&value instanceof Promise)return value.then(result=>run(result),error=>run(error,true));
   if(!frames.length){if(failed)throw value;return value;}
   const frame=frames.pop();
   if(frame.kind===3){if(!failed){value=frame.source;failed=frame.rejected;}continue;}
   if(frame.kind===2){
    if(typeof frame.fulfilled!=='function')continue;
    frames.push(new AuditStep(3,value,undefined,failed));
    try{const cleanup=frame.fulfilled;value=cleanup();failed=false;}catch(error){value=error;failed=true;}
    continue;
   }
   const handler=failed?frame.rejected:frame.fulfilled;
   if(typeof handler!=='function')continue;
   try{value=handler(value);failed=false;}catch(error){value=error;failed=true;}
  }
 }
 return run(initial);
}

export {AuditStep,auditEvaluate,auditThen,auditFinally};