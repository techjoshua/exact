from pathlib import Path
from collections import defaultdict
from statistics import mean
import hashlib,json,zipfile

root=Path('.tmp/ssr-large-profile')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
primary=json.loads((root/'writer-trampoline-results.json').read_text())
leaf=json.loads((root/'writer-trampoline-leaf-results.json').read_text())
http=json.loads((root/'writer-trampoline-http/capture.json').read_text())
counts=json.loads((root/'writer-trampoline/continuation-counts.json').read_text())
assert len(primary)==64 and len(leaf)==24 and http['complete'] and len(http['blocks'])==6
for row in primary+leaf:
 assert sha(row['entry'])==row['artifactSha256']
for artifact in http['artifacts'].values():
 if 'path' in artifact and 'sha256' in artifact and Path(artifact['path']).is_file():
  assert sha(artifact['path'])==artifact['sha256']
assert sha('framework-comparison/participants/exact/dist-server/server-entry.js')==sha(root/'conditional-emission/server-entry.js')
valid=errors=0
for block in http['blocks']:
 for result in block['results']:
  for stage in result['stages']:
   assert stage['started']==stage['completed']==stage['valid']
   valid+=stage['valid'];errors+=stage['errors']
assert errors==0

def table(rows,variants):
 groups=defaultdict(lambda:defaultdict(list))
 for row in rows:groups[(row['runtimeId'],row['mode'],row['scenario'])][row['variant']].append(row['usPerRender'])
 lines=['| Runtime / mode / fixture | '+' | '.join(variants)+' |','| --- | '+' | '.join(['---:']*len(variants))+' |']
 for (runtime,mode,size),data in groups.items():
  assert all(len(data[v])==2 for v in variants)
  lines.append('| '+f'{runtime.title()} / {mode} / {size}'+' | '+' | '.join(f'{mean(data[v]):.2f}' for v in variants)+' |')
 return '\n'.join(lines)

http_table=['| Order | Current eXact RPS | Refined stack RPS | React RPS |','| --- | ---: | ---: | ---: |']
for population in [0,1]:
 values={b['variant']:b['rps'] for b in http['blocks'] if b['population']==population}
 http_table.append('| '+('Forward' if population==0 else 'Reverse')+' | '+' | '.join(f'{values[v]:,.0f}' for v in ['current','candidate','react'])+' |')
averages={v:mean(b['rps'] for b in http['blocks'] if b['variant']==v) for v in ['current','candidate','react']}
http_table.append('| Mean | '+' | '.join(f'{averages[v]:,.0f}' for v in ['current','candidate','react'])+' |')
count_table=['| Fixture / variant | Writer calls | Maximum nested writer calls | Continuation records | Saved compiler frames |','| --- | ---: | ---: | ---: | ---: |']
for row in counts:
 if row['variant']=='writer-trampoline-control':continue
 count_table.append(f"| {row['scenario']} / {row['variant']} | {row['calls']} | {row['maxDepth']} | {sum(row['steps'])} | {row['saved']} |")

report=Path('docs/performance-baselines/writer-trampoline-2026-09-10.md')
assert not report.exists()
report.write_text('''# Compiled writer stack experiment

Status: two scratch variants implemented and rejected as performance changes.
Production source, package contracts and canonical builds are unchanged. The
overall React throughput goal remains unfulfilled.

## Hypothesis and implementation

The previous structural-stack experiment did not remove recursion between compiled
component writers. This experiment does: a lazy synchronous work record defers
renderProgramWriter, and an explicit depth-first stack evaluates child work and
success/failure/cleanup continuations. Existing generated pending branches save
their compiler frames and resume through that stack. Native promises remain the
representation of asynchronous work. A synchronous stack record alone does not
trigger the sink's await flush. Existing head flushes remain in the writer.

The hypothesis was that removing nested writer calls might reduce the HTTP-only
overhead seen in earlier traces. The countervailing cost is materializing state
that otherwise stays in synchronous calls. No estimated percentage was established.

The scratch builder adapts 45 pending checks and 61 then/finally call sites in each
artifact. A control artifact has those same adapters but still executes writers
directly. This separates adapter overhead from the added stack scheduling. The
public string/stream renderer, tree, output sinks, hydration and ownership paths
are shared throughout. The prototype is not a new HTML renderer.

The refinement statically identifies 14 leaf and 11 branching writer definitions
in each artifact. Leaf means no generated child, keyedChild, component or
directComponent call. A module-time function flag allows leaf execution directly;
branching writers use the same stack. This is a scratch representation, not an
accepted compiler ABI. It adds no per-request WeakSet.

## Validation and boundaries

Each variant passes 16 full-document comparisons on Node and 16 using the native
Bun entry point, including strings, streams, assets, changed content and a missing
route. Each passes 12 pressure/failure comparisons on each runtime using the
portable entry: every nonempty write introduces a real pending drain; selected
drains reject. HTML, errors and write ordering match the current artifact.

Seven evaluator checks per runtime cover a 30,000-link synchronous chain, failure
recovery, finally behavior, native promise settlement and pending cleanup. The
first evaluator check invocation passed a thenable directly to Node assert.rejects,
which requires a native promise or function. The harness was corrected to pass an
async function; no runtime change was needed.

These are focused prototype checks, not production acceptance. Pending component
task cancellation, all enhancement captures, browser hydration and full package /
compiler validation have not been completed for these rejected variants. Do not
infer those guarantees from the fixture checks. The existing early-head code is
retained, but browser head-discovery timing was not remeasured.

## Focused render timings

All numbers below are microseconds per complete document, lower is better. Every
population uses a fresh process, production mode, below-normal priority, 10,000
warmups and 5,000 measured renders. Two opposite implementation orders are shown
as arithmetic means. The standard assets fixture has three incidents; large has
96. All eXact hashes match, including complete app-owned documents and hydration.
Stream timings consume the entire stream. These are not HTTP RPS or native Bun
adapter throughput. The same portable entry is used for runtime timing comparisons.
No build, test or profiler ran concurrently with these timings. User PC load can
vary, so avoid comparisons with earlier dates or interpreting small differences.

Initial 64-process experiment (control is adapters without stack scheduling):

'''+table(primary,['current','control','candidate','react'])+'''

The initial candidate is slower in every grouped comparison. The control also
costs time, so the full regression cannot be attributed solely to stack dispatch.

The leaf refinement was tested in 24 additional string-render populations:

'''+table(leaf,['current','candidate','react'])+'''

It reduces the observed overhead relative to the initial experiment, but remains
slower than its paired current build in all eight individual string comparisons.
These two experiments occurred at different times; their cross-experiment timing
difference is not a paired estimate of the refinement's gain. No additional
isolated streaming run was justified before the HTTP check.

## What the stack changes

Untimed source counters record these counts per full string render:

'''+ '\n'.join(count_table)+'''

The initial stack reduces nested writer calls from seven to one. The refined
stack permits one terminal leaf call, with maximum nesting of two. Thus the
experiment actually reaches compiled writers, unlike the structural-only stack.
The refinement reduces the large fixture's continuation records from 1,430 to 574
and saved compiler frames from 108 to eight, but this is still extra work compared
with the current synchronous path. Counts describe executed explicit construction
sites, not allocated heap bytes, GC frequency or retained memory. The evaluator
also has its stack array, and generated closures are not counted in these totals.

This evidence implicates the continuation-heavy implementation's overhead. It
does not prove that every possible compiler-native explicit stack must be slower.
A future variant would need to avoid lifting the existing promise-style cleanup
and mapping chains into separately allocated records, rather than repeating this
same conversion or merely replacing its frame container.

## Actual Node HTTP comparison

The refined stack was tested under HTTP despite its slower render loops, because
the proposed benefit concerned work under request load. Six fresh workers run
current / refined stack / React and the reverse order. Each receives ten seconds
of HTTP warmup, then five measured seconds using two separate drivers with
concurrency 16 each. Before/after render loops and invocation telemetry are shared
with the existing diagnostic worker. These loops are outside the measured stage.
Production Node 26.8.1, the existing Node adapters and full document shells are
retained. This is a focused diagnostic, not a replacement full benchmark baseline.

'''+ '\n'.join(http_table)+f'''

The refined stack is slower in both orders. Its mean is
{(1-averages['candidate']/averages['current'])*100:.1f}% below current eXact. Current
eXact remains {(1-averages['current']/averages['react'])*100:.1f}% below React in this
capture. The measured stages contain {valid:,} valid responses and zero errors,
excluding warmups and preflights. Both eXact artifacts return the same 4,672-byte
document; React returns its complete 3,660-byte document. Worker, artifact and
adapter checks complete successfully. All owned processes exit; only the user's
Codex Node remains.

No HTTP result is claimed for the initial all-writer stack or for native Bun.
Reject both variants, retain their evidence, and keep the current renderer. The
stack investigation has advanced beyond structural recursion, but it has not
closed the HTTP gap. Further work should target a measured repeated operation or
representation cost without introducing these continuation allocations.

The adjacent evidence archive contains the builders, runtime prototype, artifacts,
checks, counting harness, raw render/HTTP measurements, fixture, runner ownership
helpers, this report and a verified SHA-256 manifest. It is diagnostic evidence,
not a complete standalone distribution of every external dependency.
''',encoding='utf8')

files={report,Path('.tmp/positional-leaves/data.json'),Path('framework-comparison/participants/react/dist-server/server-entry.js')}
for name in ['writer-trampoline','writer-trampoline-leaf','writer-trampoline-control','writer-trampoline-http']:
 files.update(p for p in (root/name).rglob('*') if p.is_file())
 files.update(p for p in root.glob(name+'-*') if p.is_file())
files.update(root/'conditional-emission'/name for name in ['server-entry.js','bun-server-entry.js'])
files.update(Path(p) for p in ['framework-comparison/src/ssr-worker-controller.mjs','framework-comparison/src/ssr-load-process-owner.mjs','framework-comparison/src/ssr-run-environment.mjs','scripts/development-process-lifecycle.mjs'])
archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={p.as_posix():sha(p) for p in sorted(files)}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files):z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,digest in json.loads(z.read('SHA256.json')).items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps({'files':len(files),'archive':str(archive),'valid':valid,'errors':errors,'rps':averages},indent=2))
