import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';const counts=[];
await fs.mkdir(root+'writer-trampoline-leaf',{recursive:true});
for(const file of ['server-entry.js','bun-server-entry.js']){
 const source=await fs.readFile(root+'writer-trampoline/'+file,'utf8');
 const ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);const edits=[];let leaves=0,branching=0;
 function visit(n){
  if(ts.isPropertyAssignment(n)&&n.name.getText(ast)==='ssr'&&(ts.isFunctionExpression(n.initializer)||ts.isArrowFunction(n.initializer))){
   let recurses=false;
   function inspect(child){if(ts.isCallExpression(child)&&ts.isPropertyAccessExpression(child.expression)&&child.expression.expression.getText(ast)==='__exactSsr'&&['child','keyedChild','component','directComponent'].includes(child.expression.name.text))recurses=true;ts.forEachChild(child,inspect);}
   inspect(n.initializer);
   if(recurses)branching++;
   else{leaves++;edits.push({start:n.initializer.getStart(ast),end:n.initializer.getStart(ast),text:'Object.assign('},{start:n.initializer.end,end:n.initializer.end,text:',{auditLeaf:true})'});}
  }
  ts.forEachChild(n,visit);
 }
 visit(ast);if(!leaves||!branching)throw Error('Missing program classification');
 let output=source;
 for(const e of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,e.start)+e.text+output.slice(e.end);
 const needle='function renderProgramWriter(context,host,invocation,invoke,render,prepareReferences){';
 if(output.split(needle).length!==2)throw Error('Missing writer');
 output=output.replace(needle,needle+'\nif(invocation.program.ssr.auditLeaf)return auditOriginalWriter(context,host,invocation,invoke,render,prepareReferences);');
 await fs.writeFile(root+'writer-trampoline-leaf/'+file,output);counts.push({file,leaves,branching});
}
await fs.writeFile(root+'writer-trampoline-leaf/sites.json',JSON.stringify(counts,null,2));console.log(counts);
for(const suffix of ['check.mjs','pressure.mjs'])await fs.writeFile(root+'writer-trampoline-leaf-'+suffix,(await fs.readFile(root+'writer-trampoline-'+suffix,'utf8')).replaceAll('writer-trampoline','writer-trampoline-leaf'));
let run=(await fs.readFile(root+'writer-trampoline-run.mjs','utf8')).replaceAll('writer-trampoline','writer-trampoline-leaf');
run=run.replace("control:d+'writer-trampoline-leaf-control/server-entry.js',",'').replace("['string','stream']","['string']");
await fs.writeFile(root+'writer-trampoline-leaf-run.mjs',run);
