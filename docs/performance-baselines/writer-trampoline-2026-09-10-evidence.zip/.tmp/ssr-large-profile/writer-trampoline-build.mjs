import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';
const runtime=await fs.readFile(root+'writer-trampoline-runtime.mjs','utf8');
const counts=[];
for(const variant of ['writer-trampoline-control','writer-trampoline']){
 await fs.mkdir(root+variant,{recursive:true});
 for(const file of ['server-entry.js','bun-server-entry.js']){
  const source=await fs.readFile(root+'conditional-emission/'+file,'utf8');
  const ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
  const edits=[];let checks=0,chains=0,writers=0;
  function visit(node){
   if(ts.isBinaryExpression(node)&&node.operatorToken.kind===ts.SyntaxKind.InstanceOfKeyword&&
    (node.right.getText(ast)==='Promise'||node.right.getText(ast)==='__exactSsr.promise')){
    edits.push({start:node.getStart(ast),end:node.left.getStart(ast),text:'auditPending('},
     {start:node.left.end,end:node.end,text:')'});checks++;
   }
   if(ts.isCallExpression(node)&&ts.isPropertyAccessExpression(node.expression)&&!node.questionDotToken&&
      ['then','finally'].includes(node.expression.name.text)){
    const receiver=node.expression.expression;
    edits.push({start:node.getStart(ast),end:receiver.getStart(ast),text:node.expression.name.text==='then'?'auditThen(':'auditFinally('},
     {start:receiver.end,end:node.arguments.length?node.arguments[0].getStart(ast):node.end-1,text:node.arguments.length?',': ''});chains++;
   }
   if(ts.isFunctionDeclaration(node)&&node.name?.text==='renderProgramWriter'){
    edits.push({start:node.name.getStart(ast),end:node.name.end,text:'auditOriginalWriter'});writers++;
   }
   if(ts.isFunctionDeclaration(node)&&node.name?.text==='awaitSsrProgramSink'){
    // A deferred synchronous writer is not an awaited task or a reason to flush.
    edits.push({start:node.body.getStart(ast)+1,end:node.body.getStart(ast)+1,text:'\nif(value instanceof AuditStep)return value;\n'});
   }
   ts.forEachChild(node,visit);
  }
  visit(ast);if(writers!==1||checks<10||chains<10)throw Error('Unexpected artifact shape');
  let output=source;let boundary=source.length+1;
  for(const edit of edits.sort((a,b)=>b.start-a.start||b.end-a.end)){
   if(edit.end>boundary)throw Error('Overlapping edits');boundary=edit.start;
   output=output.slice(0,edit.start)+edit.text+output.slice(edit.end);
  }
  output+='\n'+runtime+'\nfunction renderProgramWriter(context,host,invocation,invoke,render,prepareReferences){\n'+
   (variant==='writer-trampoline'?'return new AuditStep(0,()=>auditOriginalWriter(context,host,invocation,invoke,render,prepareReferences));':'return auditOriginalWriter(context,host,invocation,invoke,render,prepareReferences);')+'\n}\n';
  await fs.writeFile(root+variant+'/'+file,output);counts.push({variant,file,checks,chains,writers});
 }
}
await fs.writeFile(root+'writer-trampoline/sites.json',JSON.stringify(counts,null,2));console.log(counts);
for(const suffix of ['check.mjs','run.mjs']){
 const source=await fs.readFile(root+'writer-output-pool-'+suffix,'utf8');
 await fs.writeFile(root+'writer-trampoline-'+suffix,source.replaceAll('writer-output-pool','writer-trampoline'));
}
const pressure=await fs.readFile(root+'child-drain-elision-pressure.mjs','utf8');
await fs.writeFile(root+'writer-trampoline-pressure.mjs',pressure.replaceAll('child-drain-elision','writer-trampoline'));
