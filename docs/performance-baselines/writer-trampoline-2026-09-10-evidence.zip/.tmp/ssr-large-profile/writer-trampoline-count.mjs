import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import ts from 'typescript';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const root='.tmp/ssr-large-profile/';const modules=[];
for(const variant of ['conditional-emission','writer-trampoline-control','writer-trampoline','writer-trampoline-leaf']){
 let source=await fs.readFile(root+variant+'/server-entry.js','utf8');
 const originalName=variant==='conditional-emission'?'renderProgramWriter':'auditOriginalWriter';
 assert.equal(source.split('function '+originalName+'(').length,2);
 source=source.replace('function '+originalName+'(','function auditCountedWriter(');
 source+='\nfunction '+originalName+'(...args){auditTrace.calls++;auditTrace.depth++;auditTrace.maxDepth=Math.max(auditTrace.depth,auditTrace.maxDepth);try{return auditCountedWriter(...args);}finally{auditTrace.depth--;}}\n';
 if(variant!=='conditional-emission'){
  source=source.replace('constructor(kind,source,fulfilled,rejected){','constructor(kind,source,fulfilled,rejected){auditTrace.steps[kind]++;');
  source=source.replace('for(;;){','for(;;){auditTrace.maxFrames=Math.max(auditTrace.maxFrames,frames.length);');
 }
 const ast=ts.createSourceFile('audit.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);const edits=[];
 function visit(n){if(ts.isVariableDeclaration(n)&&n.name.getText(ast)==='__exactSaved'&&ts.isArrayLiteralExpression(n.initializer)){
  edits.push({start:n.initializer.getStart(ast),end:n.initializer.getStart(ast),text:'(auditTrace.saved++,'},{start:n.initializer.end,end:n.initializer.end,text:')'});
 }ts.forEachChild(n,visit);}visit(ast);
 for(const e of edits.sort((a,b)=>b.start-a.start))source=source.slice(0,e.start)+e.text+source.slice(e.end);
 source='let auditTrace;\n'+source+'\nexport function auditReset(){auditTrace={calls:0,depth:0,maxDepth:0,steps:[0,0,0,0],maxFrames:0,saved:0};}export function auditRead(){return auditTrace;}\n';
 const file=root+'writer-trampoline/'+variant+'-counted.js';await fs.writeFile(file,source);modules.push({variant,module:await import(pathToFileURL(resolve(file)))});
}
const rows=[];
for(const scenario of ['assets','large']){
 const data=JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json','utf8'));
 if(scenario==='large')data.incidents=Array.from({length:96},(_,i)=>({...data.incidents[i%3],id:'inc-'+(100+i)}));
 const options={clientTags:'<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">'};
 let expected;
 for(const {variant,module} of modules){
  module.auditReset();const html=await module.renderParticipant(data,'/incidents/inc-101',options);
  if(expected===undefined)expected=html;else assert.equal(html,expected);
  rows.push({scenario,variant,...module.auditRead()});
 }
}
await fs.writeFile(root+'writer-trampoline/continuation-counts.json',JSON.stringify(rows,null,2));console.log(rows);
