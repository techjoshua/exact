import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import ts from 'typescript';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const base = '.tmp/ssr-large-profile/';
const out = base + 'inline-slot-frame/';
await fs.mkdir(out, { recursive: true });
const counts = [];
for (const name of ['server-entry.js', 'bun-server-entry.js']) {
  const source = await fs.readFile(base + 'conditional-emission/' + name, 'utf8');
  const ast = ts.createSourceFile(name, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  const arities = new Set();
  let constructions = 0, reads = 0, preparations = 0;
  const prepareNames = new Set(['prepareText','prepareChild','prepareComponent','prepareComponentProps','prepareAttribute']);
  function rewrite(node) {
    if (ts.isCallExpression(node) && ts.isIdentifier(node.expression) && node.expression.text === 'createPreparedServerRenderProgram') {
      assert.equal(node.arguments.length, 2, 'Prototype excludes enhancement-bearing invocations');
      const slots = node.arguments[1];
      assert.ok(ts.isArrayLiteralExpression(slots));
      assert.ok(slots.elements.every(e => !ts.isSpreadElement(e)));
      constructions++;
      arities.add(slots.elements.length);
      return `auditSlotFrame${slots.elements.length}(${[node.arguments[0], ...slots.elements].map(rewrite).join(',')})`;
    }
    if (ts.isCallExpression(node) && ts.isPropertyAccessExpression(node.expression) && prepareNames.has(node.expression.name.text) && node.expression.expression.getText(ast) === '__exactSsr') {
      assert.equal(node.arguments.length, 2);
      assert.ok(ts.isNumericLiteral(node.arguments[1]));
      preparations++;
      return `${node.expression.getText(ast)}(${rewrite(node.arguments[0])}.slot${node.arguments[1].text})`;
    }
    if (ts.isElementAccessExpression(node) && ts.isPropertyAccessExpression(node.expression) && node.expression.name.text === 'eagerValues' && ts.isNumericLiteral(node.argumentExpression)) {
      reads++;
      return `${rewrite(node.expression.expression)}.slot${node.argumentExpression.text}`;
    }
    let result = '', at = node.getStart(ast);
    for (const child of node.getChildren(ast)) {
      const start = child.getStart(ast);
      result += source.slice(at, start) + rewrite(child);
      at = child.end;
    }
    return result + source.slice(at, node.end);
  }
  let changed = rewrite(ast);
  for (const suffix of ['Text','Child','Component','ComponentProps','Attribute']) {
    const before = `function prepareSsr${suffix}(invocation, index) {\n\tconst value = unwrap(invocation.eagerValues[index]);`;
    assert.equal(changed.split(before).length, 2);
    changed = changed.replace(before, `function prepareSsr${suffix}(rawValue) {\n\tconst value = unwrap(rawValue);`);
  }
  for (const n of arities) {
    const fields = Array.from({length:n}, (_,i) => `slot${i}`);
    changed += `\nfunction auditSlotFrame${n}(program${fields.length ? ',' + fields.join(',') : ''}) { return { [PreparedServerRenderProgram]: true, program${fields.length ? ',' + fields.join(',') : ''} }; }\n`;
  }
  await fs.writeFile(out + name, changed);
  counts.push({name, constructions, reads, preparations, arities:[...arities]});
}
await fs.writeFile(out + 'transformation.json', JSON.stringify(counts, null, 2));
const modules = await Promise.all(['conditional-emission', 'inline-slot-frame'].map(dir => import(pathToFileURL(resolve(base + dir + '/server-entry.js')))));
const rows = [];
for (const mode of ['string','stream']) for (let request = 0; request < 4; request++) {
  const data = JSON.parse(await fs.readFile('.tmp/positional-leaves/data.json', 'utf8'));
  data.incidents[1].title = `Frame ${request} <script> café 🚀`;
  if (request === 3) data.incidents[1].comments = [];
  const options = {clientTags: request === 0 ? '' : `<script type="module" src="/assets/app${request}.js"></script><link rel="stylesheet" href="/assets/theme${request}.css">`};
  const results = [];
  for (const mod of modules) results.push(mode === 'string' ? await mod.renderParticipant(data, '/incidents/inc-101', options) : await new Response(await mod.renderParticipantStream(data, '/incidents/inc-101', options)).text());
  assert.equal(results[0], results[1]);
  rows.push({mode, request, bytes:Buffer.byteLength(results[1])});
}
await fs.writeFile(out + 'verification.json', JSON.stringify(rows, null, 2));
let runner = await fs.readFile(base + 'dynamic-shell-fusion-http.mjs', 'utf8');
runner = runner.replaceAll('dynamic-shell-fusion', 'inline-slot-frame').replaceAll('Dynamic shell fusion', 'Inline slot frame');
await fs.writeFile(base + 'inline-slot-frame-http.mjs', runner);
let trace = await fs.readFile(base + 'dynamic-shell-fusion-trace.mjs', 'utf8');
trace = trace.replaceAll('dynamic-shell-fusion', 'inline-slot-frame').replace('const selected=/^(', 'const selected=/^(auditSlotFrame|');
await fs.writeFile(base + 'inline-slot-frame-trace.mjs', trace);
console.log(JSON.stringify({counts, comparisons:rows.length}));
