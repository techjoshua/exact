from pathlib import Path
from statistics import mean
import json, hashlib
base = Path('.tmp/ssr-large-profile')
rows = json.loads((base / 'inline-slot-frame/http.json').read_text())
followup = base / 'inline-slot-frame/followup-http.json'
if followup.exists(): rows += json.loads(followup.read_text())
summary = []
for runtime, mode in [('node','string'),('node','stream'),('bun','string'),('bun','stream')]:
    group = [r for r in rows if r['runtime']==runtime and r['mode']==mode]
    if len(group) != 18: continue
    stages = [d['stages'][0] for r in group for d in r['results']]
    assert all(s['errors']==0 and s['valid']==s['completed']==s['started'] for s in stages)
    for r in group: assert hashlib.sha256(Path(r['entry']).read_bytes()).hexdigest()==r['artifactSha256']
    assert len({r['identity']['hash'] for r in group if r['variant']!='react'}) == 1
    rates = {v:mean(r['rps'] for r in group if r['variant']==v) for v in ['baseline','compiled','react']}
    wins = sum(next(r['rps'] for r in group if r['variant']=='compiled' and r['block']==b)>next(r['rps'] for r in group if r['variant']=='baseline' and r['block']==b) for b in range(6))
    summary.append(dict(runtime=runtime, mode=mode, rps=rates, changePercent=100*(rates['compiled']/rates['baseline']-1), wins=wins, valid=sum(s['valid'] for s in stages), errors=0))
(base / 'inline-slot-frame/summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, indent=2))
