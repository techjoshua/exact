import fs from 'node:fs/promises';
const base = '.tmp/ssr-large-profile/';
let runner = await fs.readFile(base + 'inline-slot-frame-http.mjs', 'utf8');
runner = runner.replace("availableSsrRuntimes('node')", "availableSsrRuntimes('node,bun')")
  .replace("for(const mode of ['string']){", "for(const mode of (runtime.id === 'node' ? ['stream'] : ['string','stream'])){")
  .replace("root+'inline-slot-frame/http.json'", "root+'inline-slot-frame/followup-http.json'")
  .replace('rows.length,18', 'rows.length,54');
await fs.writeFile(base + 'inline-slot-frame-followup-http.mjs', runner);
