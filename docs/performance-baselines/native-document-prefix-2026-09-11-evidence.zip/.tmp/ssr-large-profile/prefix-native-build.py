from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'prefix-native';root.mkdir(exist_ok=True)
source=Path('framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js').read_text()
(root/'current.mjs').write_text(source)
needle='function startsExactDocument(chunks) {\n\tconst expected = "<!doctype html>";';assert source.count(needle)==1
candidate=source.replace(needle,needle+'\n\tif(chunks.length===1)return chunks[0].startsWith(expected);')
(root/'candidate.mjs').write_text(candidate)
w=(base/'scheduler-large/bun/worker.mjs').read_text().replace("'../../../../framework-adapters/","'../../../framework-adapters/")
(root/'worker.mjs').write_text(w)
r=(base/'scheduler-large-bun-run.mjs').read_text().replace('scheduler-large/bun/','prefix-native/').replace('large96-scheduler-bun','large96-bun-native-prefix-experiment')
r=r.replace("exact:'framework-comparison/participants/exact/dist-bun-server/bun-server-entry.js'","current:root+'current.mjs',candidate:root+'candidate.mjs'")
r=r.replace("for(const mode of ['string','stream'])for(let population=0;population<2;population++)for(const id of population?['react','exact']:['exact','react']){","for(const mode of ['string'])for(let population=0;population<2;population++)for(const variant of population?['react','candidate','current']:['current','candidate','react']){\n const id=variant==='react'?'react':'exact';")
r=r.replace('resolve(paths[id])','resolve(paths[variant])').replace('report.blocks.push({mode,population,id,','report.blocks.push({variant,mode,population,id,').replace("console.log(id,population+1","console.log(variant,population+1").replace('report.blocks.length,16','report.blocks.length,14')
(base/'prefix-native-run.mjs').write_text(r)
