import json,hashlib,zipfile
from pathlib import Path
from statistics import mean
base=Path('.tmp/ssr-large-profile');root=base/'prefix-native'
d=json.loads((root/'capture.json').read_text());assert d['complete'] and len(d['blocks'])==14
rows=[]
for pop in (0,1):
 for phase in ('normal','scheduled'):
  bs=[b for b in d['blocks'] if b['population']==pop and b['phase']==phase]
  old=mean(b['rps'] for b in bs if b['variant']=='current');new=mean(b['rps'] for b in bs if b['variant']=='candidate')
  rows.append(dict(population=pop+1,phase=phase,currentRps=old,candidateRps=new,gainPct=(new/old-1)*100))
for b in d['blocks']:
 assert b['after']['scheduleCalls']==(b['valid']+len(b['results']) if b['phase']=='scheduled' else 0)
 assert all(s['errors']==0 for r in b['results'] for s in r['stages'])
valid=sum(b['valid'] for b in d['blocks']);(root/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid),indent=2))
report=Path('docs/performance-baselines/native-document-prefix-2026-09-11.md')
lines=['# Native document-prefix check experiment','',
'Hypothesis: a single-chunk native startsWith call can reduce the named document-prefix checking hotspot, plausibly improving throughput 2-5%. The scratch compiled-artifact change preserves the original cross-chunk path. No production source change is adopted.', '',
'Same 96-incident fixture on native Bun string HTTP, concurrency 32, five-second blocks after ten-second warmup. Current/candidate/unchanged React workers run in one order and then reverse. Each eXact worker runs immediate/scheduled/immediate. All output must match complete-document identity.', '',
'| Repeat | Scheduling | Current RPS | Candidate RPS | Change |',
'| --- | --- | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['population']} | {r['phase']} | {r['currentRps']:,.0f} | {r['candidateRps']:,.0f} | {r['gainPct']:+.2f}% |")
lines+=['',f'{valid:,} measured responses passed full identity validation, zero errors. Artifact and invocation-count guards pass.', '',
'The change provides no consistent throughput benefit and is rejected. Profiling attribution to the prefix check does not prove that character-by-character comparison causes that cost: reading a rope string may trigger work that a native predicate also requires. That explanation remains a hypothesis, not a measured allocation result. The large Bun string scheduling gap remains open.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(root.glob('*'))+[report,base/'prefix-native-build.py',base/'prefix-native-run.mjs',base/'prefix-native-report.py']
archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists();manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print(json.dumps(rows,indent=2));print(valid,'validated responses')
