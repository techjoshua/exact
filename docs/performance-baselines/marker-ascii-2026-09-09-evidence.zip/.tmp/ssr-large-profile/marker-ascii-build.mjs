import {readFileSync,writeFileSync} from 'node:fs';
const dir='.tmp/ssr-large-profile/';
let source=readFileSync(dir+'marker-hex-current.mjs','utf8');
const before='const bytes = markerUtf8Encoder.encode(value);';
if(source.split(before).length!==2)throw Error('Unexpected marker encoding site');
source=source.replace(before,`let ascii='~';
 let index=0;
 for(;index<value.length;index++){
  const code=value.charCodeAt(index);
  if(code>=128)break;
  ascii+=markerHexBytes[code];
 }
 if(index===value.length)return ascii;
 const bytes = markerUtf8Encoder.encode(value);`);
writeFileSync(dir+'marker-ascii.mjs',source);
let worker=readFileSync(dir+'direct-map-worker.mjs','utf8');
worker=worker.replace('const render=','const assetPrefix=scenario===\'unicode-assets\'?\'/assets/\\u65e5\\u672c\\ud83d\\ude80/\':\'/assets/\';\nconst render=');
worker=worker.replace(/clientTags:('[^']*')/g,"clientTags:$1.replaceAll('/assets/',assetPrefix)");
writeFileSync(dir+'marker-ascii-worker.mjs',worker);
