import hashlib,json,pathlib,zipfile
root=pathlib.Path('.');work=root/'.tmp/ssr-large-profile'
rows=json.loads((work/'marker-ascii-results.json').read_text(encoding='utf-8'));summary=[]
for runtime in ['node','bun']:
 for mode in ['string','stream']:
  for scenario in ['small','unicode-assets']:
   changes=[]
   for round in range(2):
    group=[r for r in rows if r['runtimeId']==runtime and r['mode']==mode and r['scenario']==scenario and r['round']==round]
    a=next(r for r in group if r['variant']=='marker-hex-current');b=next(r for r in group if r['variant']=='marker-ascii')
    assert a['hash']==b['hash'];changes.append((b['usPerRender']/a['usPerRender']-1)*100)
   summary.append(dict(runtime=runtime,mode=mode,scenario=scenario,changes=changes))
table='\n'.join(f"| {s['runtime']} | {s['mode']} | {s['scenario']} | {s['changes'][0]:+.2f}% | {s['changes'][1]:+.2f}% |" for s in summary)
dest=root/'docs/performance-baselines/marker-ascii-2026-09-09'
dest.with_suffix('.json').write_text(json.dumps(dict(summary=summary,populations=rows),indent=2)+'\n',encoding='utf-8')
doc='''# ASCII marker encoding follow-up

Date: 2026-09-09. Rejected prototype; retained shared-encoder implementation unchanged.

## Hypothesis

The retained hex-table encoder still creates a UTF-8 byte array for URL keys. An ASCII-only loop
could avoid that allocation by indexing the hex table directly with UTF-16 code units below 128.
The hypothesis was a small additional saving for common asset URLs; no numerical gain was
preregistered. Unicode URLs were included to expose the cost of abandoning a partial ASCII prefix
and falling back to the existing UTF-8 encoder.

## Method

Thirty-two fresh processes: Node/Bun, string/consumed stream, ASCII/Unicode assets, two reversed-order
pairs per cell. Each uses NODE_ENV=production, 5,000 warmups and 12,000 measured renders, three
incidents, two module scripts and two stylesheet links, and complete application-owned documents.
The Unicode fixture adds Japanese characters and a supplementary-plane character to each asset
path; application data remains identical. Both runtimes use the same portable bundle. Streams are
consumed with Response.text(). All paired full-document hashes match.

The control is marker-hex-current, verified against the actual built Node artifact before this
experiment. This is a frozen-bundle prototype only. No production source was changed.

## Results

Positive means longer rendering time. These preliminary local observations are not confidence
bounds, HTTP throughput, or browser timings.

| Runtime | Mode | Asset fixture | Pair 1 time change | Pair 2 time change |
| --- | --- | --- | ---: | ---: |
'''+table+'''

Bun improves modestly on ASCII assets, while Node regresses in every ASCII pair. Unicode outcomes
are mixed. The shortcut is not adopted because it adds a second encoding loop without a consistent
benefit across the target runtimes. The existing native UTF-8 encoder plus hex lookup remains.

No new package or browser tests were run for this rejected prototype. Output equality covers these
fixtures, not every encoding input; the retained encoder's broader core and browser validation
remains documented in marker-hex-2026-09-09.md. The overall React parity objective remains unmet.

The archive preserves both artifacts, worker, builder, runner, fixed input, observations, reporter,
and SHA-256 hashes. No task-owned benchmark process remains running.
'''
dest.with_suffix('.md').write_text(doc,encoding='utf-8')
files=[work/n for n in ['marker-hex-current.mjs','marker-ascii.mjs','marker-ascii-build.mjs','marker-ascii-worker.mjs','marker-ascii-run.mjs','marker-ascii-results.json','marker-ascii-report.py','direct-map-worker.mjs']]+[root/'.tmp/positional-leaves/data.json',dest.with_suffix('.md'),dest.with_suffix('.json')]
archive=dest.parent/(dest.name+'-evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 z.writestr('SHA256.json',json.dumps({p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(table);print('Verified',archive)
