import fs from 'node:fs/promises';
import ts from 'typescript';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'constant-ssr-operations',{recursive:true});const counts=[];
for(const file of ['server-entry.js','bun-server-entry.js']){
 const source=await fs.readFile(root+'conditional-emission/'+file,'utf8');
 const ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);const edits=[],members=new Set();
 function visit(node){if(ts.isPropertyAccessExpression(node)&&ts.isIdentifier(node.expression)&&node.expression.text==='__exactSsr'){
  const name=node.name.text;members.add(name);edits.push({start:node.getStart(ast),end:node.end,text:'auditSsrOperations.'+name});
 }ts.forEachChild(node,visit);}
 visit(ast);if(!edits.length)throw Error('No operation references');let output=source;
 for(const e of edits.sort((a,b)=>b.start-a.start))output=output.slice(0,e.start)+e.text+output.slice(e.end);
 output+='\nconst auditSsrOperations=generatedSsrOperations;\n';
 await fs.writeFile(root+'constant-ssr-operations/'+file,output);counts.push({file,references:edits.length,members:[...members]});
}
await fs.writeFile(root+'constant-ssr-operations/sites.json',JSON.stringify(counts,null,2));console.log(counts);
for(const suffix of ['check.mjs','run.mjs']){
 const source=await fs.readFile(root+'writer-output-pool-'+suffix,'utf8');
 await fs.writeFile(root+'constant-ssr-operations-'+suffix,source.replaceAll('writer-output-pool','constant-ssr-operations'));
}
const pressure=await fs.readFile(root+'child-drain-elision-pressure.mjs','utf8');
await fs.writeFile(root+'constant-ssr-operations-pressure.mjs',pressure.replaceAll('child-drain-elision','constant-ssr-operations'));

