import pathlib,json,collections
d=pathlib.Path('.tmp/ssr-large-profile'); summaries=[]
for runtime in ['node','bun']:
 for variant in ['exact','react']:
  path=d/f'current-{runtime}-{variant}.cpuprofile'
  if not path.exists(): continue
  data=json.loads(path.read_text()); nodes={n['id']:n for n in data['nodes']}
  weights=collections.Counter()
  for node,delta in zip(data.get('samples',[]),data.get('timeDeltas',[])):
   f=nodes[node]['callFrame'];key=(f['functionName'],f['url'],f['lineNumber']);weights[key]+=delta
  total=sum(weights.values()); top=[]
  print(runtime,variant,'sampled ms',round(total/1000))
  for (name,url,line),value in weights.most_common(18):
   item={'function':name,'url':url,'line':line+1,'ms':value/1000,'percent':value/total*100};top.append(item)
   print(f'{value/total*100:5.1f}% {name} {pathlib.Path(url).name}:{line+1}')
  summaries.append({'runtime':runtime,'variant':variant,'sampledMs':total/1000,'top':top})
(d/'current-profile-summary.json').write_text(json.dumps(summaries,indent=2))
