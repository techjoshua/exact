import fs from 'node:fs';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const d='.tmp/ssr-large-profile/';
const results=[];
for(const [variant,file] of Object.entries({rope:d+'rope-string-sink/server-entry.js',property:d+'rope-direct-property.mjs'})) {
 const path=d+`rope-validation-${variant}.mjs`;
 fs.writeFileSync(path,fs.readFileSync(file,'utf8')+'\nexport { StringProgramSink, renderProgramOutput, createSsrContext };\n');
 const {StringProgramSink,renderProgramOutput,createSsrContext}=await import(pathToFileURL(resolve(path)));
 for(const parts of [['ab','cd'],['\ud83d','\ude80'],['日','本','語'],['\ud83d'],['','ab','tail']]) {
  const expected=parts.join(''),bytes=Buffer.byteLength(expected);
  for(const max of [bytes-1,bytes,bytes+1,1000]) {
   const sink=new StringProgramSink(max),context=createSsrContext({markers:false});context.writerSink=sink;
   let html,error;
   try { await renderProgramOutput(context,parts,()=>{throw Error('unexpected deferred operation')});html=sink.finish(); }
   catch(e){error=e.name;}
   if(max<bytes)assert.equal(error,'SsrOutputLimitError');else assert.equal(html,expected);
   assert.throws(()=>sink.write('late'),/closed/);
   results.push({variant,parts,max,html,error});
  }
 }
 const writes=[];let release;let started=false;
 const drain=new Promise(r=>{release=r});
 const context=createSsrContext({markers:false});context.writerSink={write(s){writes.push(s)},ready(){return drain},flush(){}};
 const rendering=renderProgramOutput(context,['start',{}],()=>{started=true;return 'end'});
 assert.equal(started,false);release();await rendering;assert.deepEqual(writes,['start','end']);
}
fs.writeFileSync(d+`rope-property-validation-${process.versions.bun?'bun':'node'}.json`,JSON.stringify(results,null,2));
console.log(`${results.length} byte-limit cases and both pressure fallbacks passed`);
