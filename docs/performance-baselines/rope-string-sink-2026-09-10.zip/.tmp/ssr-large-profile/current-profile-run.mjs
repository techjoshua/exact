import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
const d='.tmp/ssr-large-profile/';
const rows=[];
for(const runtime of ['node','bun'])for(const [variant,entry] of Object.entries({exact:d+'direct-marker-final/server-entry.js',react:'framework-comparison/participants/react/dist-server/server-entry.js'})) {
 const result=spawnSync(runtime,['--cpu-prof',`--cpu-prof-dir=${d}`,`--cpu-prof-name=current-${runtime}-${variant}.cpuprofile`,d+'production-refresh-worker.mjs',entry,'string','large','30000'],{encoding:'utf8',windowsHide:true,env:{...process.env,NODE_ENV:'production'}});
 if(result.status!==0)throw Error(result.stderr+result.stdout);
 rows.push({runtimeId:runtime,variant,...JSON.parse(result.stdout)});
 console.log(runtime,variant,result.stdout.trim());
 fs.writeFileSync(d+'current-profile-results.json',JSON.stringify(rows,null,2));
}
