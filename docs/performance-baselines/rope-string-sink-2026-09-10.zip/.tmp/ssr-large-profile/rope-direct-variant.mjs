import fs from 'node:fs';
import assert from 'node:assert/strict';
const d='.tmp/ssr-large-profile/';
let source=fs.readFileSync(d+'rope-string-sink/server-entry.js','utf8');
let sites=0;
source=source.replace(/\b((?:this\.)?sink)\.write\((html|value|opening|closing|entered\.prefix)\);/g,(_,sink,value)=>{
 sites++;
 return `{ if (${sink} instanceof StringProgramSink) {
 if (${sink}.closed) throw new Error('SSR string sink is closed');
 if (${sink}.characters + ${value}.length > ${sink}.maxBytes) {
 ${sink}.destroy(); throw new SsrOutputLimitError(${sink}.maxBytes);
 }
 if (${value}) { ${sink}.characters += ${value}.length; ${sink}.value += ${value}; }
 } else ${sink}.write(${value}); }`;
});
assert.ok(sites>=6,`Only ${sites} write sites replaced`);
fs.writeFileSync(d+'rope-direct-property.mjs',source);
console.log({sites});
