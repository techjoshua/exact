from pathlib import Path
base=Path('.tmp/ssr-large-profile');root=base/'serial-scheduler';root.mkdir(exist_ok=True)
(root/'serial-scheduler.mjs').write_bytes((base/'serial-scheduler.mjs').read_bytes())
w=(base/'scheduler-large-batches/worker.mjs').read_text()
w="import {createSerialScheduler} from './serial-scheduler.mjs';\n"+w
old="if(auditScheduled)sourceScheduler=createNodeRenderScheduler({maxBatchSize:Number(url.searchParams.get('batch'))});"
assert old in w
w=w.replace(old,"if(auditScheduled){const size=Number(url.searchParams.get('batch'));sourceScheduler=url.searchParams.get('serial')==='1'?createSerialScheduler(size):createNodeRenderScheduler({maxBatchSize:size});}")
(root/'worker.mjs').write_text(w)
r=(base/'scheduler-large-batches-run.mjs').read_text().replace('scheduler-large-batches/','serial-scheduler/').replace('large96-bun-string-batch-sizes','large96-bun-serial-batch-turns')
old="(population?['normal','scheduled-32','scheduled-16','scheduled-8','scheduled-4','scheduled-1','normal']:['normal','scheduled-1','scheduled-4','scheduled-8','scheduled-16','scheduled-32','normal'])"
new="(population?['normal','serial-32','serial-8','serial-4','scheduled-32','normal']:['normal','scheduled-32','serial-4','serial-8','serial-32','normal'])"
assert old in r;r=r.replace(old,new).replace("phase.startsWith('scheduled')","phase!=='normal'")
r=r.replace("+'&batch='+phase.split('-')[1]","+'&batch='+phase.split('-')[1]+'&serial='+(phase.startsWith('serial')?'1':'0')")
r=r.replace('report.blocks.length,16','report.blocks.length,14')
(base/'serial-scheduler-run.mjs').write_text(r)
