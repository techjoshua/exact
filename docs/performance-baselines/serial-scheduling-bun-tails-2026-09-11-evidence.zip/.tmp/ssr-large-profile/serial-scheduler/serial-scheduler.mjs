import {scheduler} from 'node:timers/promises';
/** Signal-free diagnostic: one pending host wakeup, FIFO starts bounded per turn. */
export function createSerialScheduler(limit=32){
 let starts=[],head=0,scheduled=false;
 function wake(){scheduled=true;scheduler.yield().then(()=>{
  const end=Math.min(starts.length,head+limit);
  while(head<end){const start=starts[head];starts[head++]=undefined;start();}
  if(head===starts.length){starts=[];head=0;scheduled=false;}else wake();
 });}
 return signal=>{if(signal)throw Error('Signal-free diagnostic only');return new Promise(resolve=>{starts.push(resolve);if(!scheduled)wake();});};
}
