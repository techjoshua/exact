import {createNodeRenderScheduler} from '../../framework-adapters/node-adapter/dist/index.js';
import {createSerialScheduler} from './serial-scheduler.mjs';
import {writeFile} from 'node:fs/promises';
const rows=[];
for(const [name,create] of [['current',createNodeRenderScheduler],['serial',()=>createSerialScheduler(32)]]){
 let completed=0,resolveProbe;const probe=new Promise(resolve=>resolveProbe=resolve);const schedule=create();
 const all=Array.from({length:1024},()=>schedule().then(()=>{
  if(completed===0)setTimeout(()=>resolveProbe(completed),0);
  const until=performance.now()+0.05;while(performance.now()<until){}
  completed++;
 }));
 const seen=await probe;await Promise.all(all);rows.push({name,total:completed,completedBeforeTimer:seen});
}
await writeFile('.tmp/ssr-large-profile/serial-scheduler/fairness-node.json',JSON.stringify(rows,null,2));console.log(rows);
