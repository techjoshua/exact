import {spawn} from 'node:child_process';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import os from 'node:os';os.setPriority(0,10);
const root='.tmp/ssr-large-profile/',rows=[];
for(const [round,order] of [['a',['normal','consume']],['b',['consume','normal']]])for(const variant of order){
 const entry=root+(variant==='normal'?'direct-execution-integrated':'consume-result')+'/server-entry.js';
 const path=root+`consume-result-allocation-${round}-${variant}.json`;
 const result=await new Promise((resolve,reject)=>{const child=spawn('node',[root+'direct-execution-target-allocation-worker.mjs',entry,'small',path],{windowsHide:true,env:{...process.env,NODE_ENV:'production'}});let out='',err='';child.stdout.on('data',d=>out+=d);child.stderr.on('data',d=>err+=d);child.on('error',reject);child.on('exit',code=>code===0?resolve(JSON.parse(out)):reject(Error(err||String(code))));});
 const profile=JSON.parse(await fs.readFile(path,'utf8'));function total(node){return node.selfSize+node.children.reduce((sum,child)=>sum+total(child),0);}
 if(rows.length)assert.equal(result.hash,rows[0].hash);const row={round,variant,...result,sampledBytesPerRender:total(profile.head)/result.iterations};rows.push(row);await fs.writeFile(root+'consume-result-allocation-summary.json',JSON.stringify(rows,null,2));console.log(variant,row.sampledBytesPerRender);
}
