import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='.tmp/ssr-large-profile/';
const raw=await fs.readFile(root+'direct-execution-integrated/server-entry.js');
assert.equal(createHash('sha256').update(raw).digest('hex'),'2ebf7fed2ee0dc972095976bf55230ccc924a120251a463af26838e8ebb2cd18');
let source=raw.toString();const start=source.indexOf('function createChunkedHydratableResult('),end=source.indexOf('/** Recognizes normalized document output',start);let body=source.slice(start,end);
const literal='const hydratable = {\n\t\tresumptions: void 0,\n\t\thtmlWithHydration: void 0,\n\t\thtml: result.html,\n\t\tstate: result.state,\n\t\thydrationScript\n\t};';
assert.ok(body.includes(literal));
body=body.replace(literal,'const hydratable = result;\n\tObject.defineProperty(hydratable,"hydrationScript",{value:hydrationScript,writable:true,configurable:true,enumerable:true});');
for(const line of ['\tif (result.wallClockSnapshot !== void 0) hydratable.wallClockSnapshot = result.wallClockSnapshot;\n','\tif (result.hydrationTable) hydratable.hydrationTable = result.hydrationTable;\n','\tif (result.preloadLinks) hydratable.preloadLinks = result.preloadLinks;\n']){assert.ok(body.includes(line));body=body.replace(line,'');}
source=source.slice(0,start)+body+source.slice(end);
await fs.mkdir(root+'consume-result',{recursive:true});await fs.writeFile(root+'consume-result/server-entry.js',source);
let runner=await fs.readFile(root+'packed-publication-run.mjs','utf8');runner=runner.replaceAll('packed-publication','consume-result').replaceAll("'packed'","'consume'").replace("['small','large']","['small']");await fs.writeFile(root+'consume-result-run.mjs',runner);
const pressure=await fs.readFile(root+'stateful-scope-pressure.mjs','utf8');await fs.writeFile(root+'consume-result-pressure.mjs',pressure.replaceAll('stateful-scope','consume-result'));
console.log('Built one-owner result consumption prototype.');
