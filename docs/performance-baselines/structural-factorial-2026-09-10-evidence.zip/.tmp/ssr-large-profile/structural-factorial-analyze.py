import json,statistics,math
from pathlib import Path
root=Path('.tmp/ssr-large-profile/structural-factorial')
rows=json.loads((root/'http.json').read_text());assert len(rows)==64
summary=[]
for runtime,mode in [('node','string'),('bun','stream')]:
 selected=[r for r in rows if r['runtime']==runtime and r['mode']==mode]
 means={v:statistics.mean(r['rps'] for r in selected if r['variant']==v) for v in ['baseline','shell','detail','combined']}
 contrasts={}
 for numerator,denominator in [('shell','baseline'),('detail','baseline'),('combined','baseline'),('combined','shell'),('combined','detail')]:
  pairs=[]
  for block in range(8):
   values={r['variant']:r['rps'] for r in selected if r['block']==block}
   pairs.append((values[numerator]/values[denominator]-1)*100)
  contrasts[f'{numerator}/{denominator}']={'meanRatioPercent':(means[numerator]/means[denominator]-1)*100,'medianPairedPercent':statistics.median(pairs),'positivePairs':sum(v>0 for v in pairs),'pairs':pairs}
 valid=sum(s['valid'] for r in selected for d in r['results'] for s in d['stages'])
 errors=sum(s['errors'] for r in selected for d in r['results'] for s in d['stages'])
 result={'runtime':runtime,'mode':mode,'rps':means,'contrasts':contrasts,'valid':valid,'errors':errors};summary.append(result)
 print(json.dumps(result))
(root/'summary.json').write_text(json.dumps(summary,indent=2))
