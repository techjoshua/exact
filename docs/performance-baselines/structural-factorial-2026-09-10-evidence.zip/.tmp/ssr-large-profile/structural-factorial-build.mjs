import fs from 'node:fs/promises';
import ts from 'typescript';
import assert from 'node:assert/strict';
const base='.tmp/ssr-large-profile/',out=base+'structural-factorial/';
await fs.mkdir(out,{recursive:true});
const variants=['baseline','shell','detail','combined'];
function declarations(source){
 const ast=ts.createSourceFile('entry.js',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS),found=new Map();
 function visit(n){if(ts.isVariableDeclaration(n)&&ts.isIdentifier(n.name))found.set(n.name.text,n);ts.forEachChild(n,visit);}
 visit(ast);return {ast,found};
}
for(const file of ['server-entry.js','bun-server-entry.js']){
 const original=await fs.readFile(base+'conditional-emission/'+file,'utf8');
 const combined=await fs.readFile(base+'structural-detail/'+file,'utf8');
 const a=declarations(original),b=declarations(combined);
 for(const variant of variants){
  const restore=[];
  if(variant==='baseline'||variant==='detail')restore.push('__exactImplementation_Document_1');
  if(variant==='baseline'||variant==='shell')restore.push('__exactImplementation_IncidentDetail_1','__exact_render_program_12');
  const edits=restore.map(name=>{const target=b.found.get(name),source=a.found.get(name);assert.ok(target&&source);return {start:target.initializer.getStart(b.ast),end:target.initializer.end,text:source.initializer.getText(a.ast)};});
  let source=combined;
  for(const edit of edits.sort((x,y)=>y.start-x.start))source=source.slice(0,edit.start)+edit.text+source.slice(edit.end);
  await fs.mkdir(out+variant,{recursive:true});await fs.writeFile(out+variant+'/'+file,source);
 }
}
let runner=await fs.readFile(base+'structural-detail-http.mjs','utf8');
runner=runner.replace(/const orders=\[[\s\S]*?\];/,"const first=[['baseline','shell','combined','detail'],['shell','detail','baseline','combined'],['detail','combined','shell','baseline'],['combined','baseline','detail','shell']];const orders=[...first,...first.map(order=>[...order].reverse())];");
runner=runner.replace("for(const mode of ['string','stream'])", "for(const mode of [runtime.id==='node'?'string':'stream'])");
const start=runner.indexOf(" for(const variant of ['baseline','compiled','react'])"),end=runner.indexOf('\n const worker=',start);assert.ok(start>0&&end>start);
runner=runner.slice(0,start)+" for(const variant of ['baseline','shell','detail','combined']){const id='exact';const entry=resolve(root+'structural-factorial/'+variant+'/'+(runtime.id==='bun'?'bun-server-entry.js':'server-entry.js'));"+runner.slice(end);
runner=runner.replace("if(variant==='compiled')assert.equal(html,exactDocument)","else assert.equal(html,exactDocument)");
runner=runner.replace("root+'structural-detail/http.json'","root+'structural-factorial/http.json'").replace('assert.equal(rows.length,72)','assert.equal(rows.length,64)').replace('Structural composition HTTP comparison','Structural factorial HTTP comparison');
await fs.writeFile(base+'structural-factorial-http.mjs',runner);
console.log('Four variants and balanced two-cell runner prepared');
