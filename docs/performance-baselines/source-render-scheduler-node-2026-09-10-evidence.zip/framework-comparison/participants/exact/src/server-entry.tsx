import {
	renderToHydratableString,
	renderToHydratableProgressiveHtmlStream,
	type RenderToStringOptions
} from '@exactjs/ssr';
import { Document, type DocumentOptions } from './Document.jsx';
import type { InitialData } from './types.js';

/** Keeps host scheduling outside the authored document's serializable props. */
export type ParticipantRenderOptions = DocumentOptions & Pick<RenderToStringOptions, 'scheduleRender'>;

/** Uses the public progressive HTML API with the same authored document and root props. */
export function renderParticipantStream(
	initialData: InitialData,
	path: string,
	options?: ParticipantRenderOptions,
	signal?: AbortSignal
) {
	return renderToHydratableProgressiveHtmlStream(
		<Document initialData={initialData} path={path} clientTags={options?.clientTags} />,
		{ publishRootProps: true, signal, scheduleRender: options?.scheduleRender }
	);
}

/** Renders the authored document through eXact's normalization and hydration publication. */
export async function renderParticipant(
	initialData: InitialData,
	path: string,
	options?: ParticipantRenderOptions
) {
	return (
		await renderToHydratableString(
			<Document initialData={initialData} path={path} clientTags={options?.clientTags} />,
			{ publishRootProps: true, scheduleRender: options?.scheduleRender }
		)
	).htmlWithHydration;
}
