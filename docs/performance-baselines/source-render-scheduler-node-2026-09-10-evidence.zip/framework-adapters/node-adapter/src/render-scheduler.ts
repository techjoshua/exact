import { clearImmediate, setImmediate } from 'node:timers';

/** Limits how many render starts one event-loop callback releases. */
export interface NodeRenderSchedulerOptions {
	/** Maximum starts per batch. Defaults to 32; must be a positive safe integer. */
	maxBatchSize?: number;
}

interface RenderBatch {
	starts: Array<(() => void) | undefined>;
	active: number;
	timer: ReturnType<typeof setImmediate> | undefined;
}

/**
 * Creates a host-owned scheduler for the SSR `scheduleRender` option. Share one
 * scheduler across requests to batch starts in Node's check phase. Cancellation
 * rejects promptly and removes the queued continuation. Batches release at most
 * maxBatchSize starts; render work and response ownership remain with SSR.
 */
export function createNodeRenderScheduler(
	options: NodeRenderSchedulerOptions = {}
): (signal?: AbortSignal) => Promise<void> {
	const limit = options.maxBatchSize ?? 32;
	if (!Number.isSafeInteger(limit) || limit < 1)
		throw new RangeError('maxBatchSize must be a positive safe integer');
	let pending: RenderBatch | undefined;
	return (signal) =>
		new Promise<void>((resolve, reject) => {
			if (signal?.aborted) {
				reject(signal.reason);
				return;
			}
			const batch: RenderBatch = pending ?? { starts: [], active: 0, timer: undefined };
			if (!pending) {
				pending = batch;
				batch.timer = setImmediate(() => {
					if (pending === batch) pending = undefined;
					batch.timer = undefined;
					for (const start of batch.starts) start?.();
					batch.starts = [];
				});
			}
			const index = batch.starts.length;
			batch.active++;
			if (signal) {
				const abort = () => {
					batch.starts[index] = undefined;
					signal.removeEventListener('abort', abort);
					if (--batch.active === 0 && batch.timer !== undefined) {
						clearImmediate(batch.timer);
						batch.timer = undefined;
						batch.starts = [];
						if (pending === batch) pending = undefined;
					}
					reject(signal.reason);
				};
				batch.starts.push(() => {
					signal.removeEventListener('abort', abort);
					resolve();
				});
				signal.addEventListener('abort', abort, { once: true });
			} else batch.starts.push(resolve);
			if (batch.starts.length === limit) pending = undefined;
		});
}
