import { afterEach, describe, expect, it, vi } from 'vitest';
import { createNodeRenderScheduler } from './render-scheduler.js';

vi.mock('node:timers', () => ({
	setImmediate: (callback: () => void) => globalThis.setImmediate(callback),
	clearImmediate: (timer: ReturnType<typeof setImmediate>) => globalThis.clearImmediate(timer)
}));

afterEach(() => vi.useRealTimers());

describe('Node render scheduling', () => {
	it('shares a callback and limits the number of starts per batch', async () => {
		vi.useFakeTimers();
		const schedule = createNodeRenderScheduler({ maxBatchSize: 2 });
		const order: number[] = [];
		const work = [0, 1, 2, 3, 4].map((id) => schedule().then(() => order.push(id)));
		expect(order).toEqual([]);
		expect(vi.getTimerCount()).toBe(3);
		await vi.runAllTimersAsync();
		await Promise.all(work);
		expect(order).toEqual([0, 1, 2, 3, 4]);
	});

	it('removes a canceled request without canceling another request in its batch', async () => {
		vi.useFakeTimers();
		const schedule = createNodeRenderScheduler();
		const controller = new AbortController();
		const reason = new Error('disconnect');
		const canceled = schedule(controller.signal).catch((error: unknown) => error);
		const other = schedule();
		controller.abort(reason);
		expect(await canceled).toBe(reason);
		expect(vi.getTimerCount()).toBe(1);
		await vi.runAllTimersAsync();
		await other;
	});

	it('clears fully canceled batches and accepts subsequent work', async () => {
		vi.useFakeTimers();
		const schedule = createNodeRenderScheduler();
		const controller = new AbortController();
		const canceled = schedule(controller.signal).catch((error: unknown) => error);
		controller.abort();
		expect(await canceled).toBe(controller.signal.reason);
		expect(vi.getTimerCount()).toBe(0);
		const next = schedule();
		await vi.runAllTimersAsync();
		await next;
	});

	it('rejects an already aborted request without allocating a timer', async () => {
		vi.useFakeTimers();
		const controller = new AbortController();
		controller.abort('closed');
		await expect(createNodeRenderScheduler()(controller.signal)).rejects.toBe('closed');
		expect(vi.getTimerCount()).toBe(0);
	});

	it('validates batch limits', () => {
		for (const maxBatchSize of [0, -1, 1.5, Infinity, NaN])
			expect(() => createNodeRenderScheduler({ maxBatchSize })).toThrow(RangeError);
	});
});
