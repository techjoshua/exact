import fs from 'node:fs/promises';
const root='.tmp/ssr-large-profile/';await fs.mkdir(root+'source-scheduler',{recursive:true});
function replaceOnce(text,from,to){if(!text.includes(from))throw Error('Missing source '+from);return text.replace(from,to);}
let worker=(await fs.readFile(root+'http-invocation-trace/worker.mjs','utf8')).replaceAll('\r\n','\n');
worker=`import {createNodeRenderScheduler} from '../../../framework-adapters/node-adapter/dist/index.js';
const sourceScheduler=createNodeRenderScheduler();
let auditScheduled=false,auditLoopMode=false,auditScheduleCalls=0;
function scheduleSourceRender(signal){++auditScheduleCalls;return sourceScheduler(signal);}
`+worker;
worker=replaceOnce(worker,"const documentOptions = { clientTags: process.env.COMPARISON_CLIENT_TAGS ?? '' };","const documentOptions = { clientTags: process.env.COMPARISON_CLIENT_TAGS ?? '', get scheduleRender(){return participantId==='exact'&&auditScheduled&&!auditLoopMode?scheduleSourceRender:undefined;} };");
worker=replaceOnce(worker," if (pathname === '/__exact-benchmark/audit-start')", " if(pathname==='/__exact-benchmark/audit-mode'){auditScheduled=url.searchParams.get('defer')==='1';if(auditScheduled&&participantId!=='exact')throw Error('React scheduling must remain unchanged');writeJson(response,{deferred:auditScheduled});return;}\n if (pathname === '/__exact-benchmark/audit-start')");
worker=replaceOnce(worker,'resetTelemetry(); audit={}; writeJson(response,{cpu:process.cpuUsage()});','resetTelemetry(); audit={};auditScheduleCalls=0;writeJson(response,{cpu:process.cpuUsage(),deferred:auditScheduled});');
worker=replaceOnce(worker," if (pathname === '/__exact-benchmark/audit-loop') { await participant.renderOnly(10000); audit={}; resetTelemetry(); const result=await participant.renderOnly(10000); writeJson(response,{audit,responseBytes:result.responseBytes}); return; }"," if(pathname==='/__exact-benchmark/audit-loop'){auditLoopMode=true;try{await participant.renderOnly(10000);audit={};resetTelemetry();auditScheduleCalls=0;const result=await participant.renderOnly(10000);writeJson(response,{audit,responseBytes:result.responseBytes,scheduleCalls:auditScheduleCalls});}finally{auditLoopMode=false;}return;}");
worker=replaceOnce(worker,'telemetry:telemetry(),audit});','telemetry:telemetry(),audit,scheduleCalls:auditScheduleCalls});');
await fs.writeFile(root+'source-scheduler/worker.mjs',worker);
let runner=(await fs.readFile(root+'http-immediate-low-run.mjs','utf8')).replaceAll('http-immediate-low/','source-scheduler/').replaceAll('same-worker-low-concurrency-deferral','actual-source-scheduler-node');
runner=replaceOnce(runner,"exact:'.tmp/ssr-large-profile/component-forwarding-integrated/server-entry.js'","exact:'framework-comparison/participants/exact/dist-server/server-entry.js'");
runner=replaceOnce(runner,'async function startDrivers(){for(let i=0;i<1;i++)','async function startDrivers(concurrency=32){for(let i=0;i<(concurrency===1?1:2);i++)');
runner=replaceOnce(runner,"concurrency:4,durationMs:10000","concurrency:16,durationMs:10000");
runner=replaceOnce(runner,"population?[4,1]:[1,4]","population?[32,1]:[1,32]");
runner=replaceOnce(runner,"for(const phase of ['normal','immediate','normal'])","for(const phase of id==='exact'?['normal','scheduled','normal']:['normal'])");
runner=runner.replaceAll("phase==='immediate'","phase==='scheduled'");
runner=replaceOnce(runner,"await startDrivers();const loopBefore","await startDrivers(concurrency);const loopBefore");
runner=replaceOnce(runner,'concurrency,durationMs:3000','concurrency:concurrency===1?1:16,durationMs:5000');
runner=replaceOnce(runner,'report.blocks.length,24','report.blocks.length,16');
await fs.writeFile(root+'source-scheduler-run.mjs',runner);
console.log('Built actual-source scheduler runner, React unchanged');
