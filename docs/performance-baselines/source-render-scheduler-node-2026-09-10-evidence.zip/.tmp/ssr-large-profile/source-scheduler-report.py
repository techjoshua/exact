import hashlib,json,zipfile
from pathlib import Path
from statistics import mean
base=Path('.tmp/ssr-large-profile');folder=base/'source-scheduler'
data=json.loads((folder/'capture.json').read_text());assert data['complete'] and len(data['blocks'])==16
def latency(b,key='responseMs'):
    ds=[r['stages'][0]['distributions'][key] for r in b['results']]
    return sum(d['mean']*d['count'] for d in ds)/sum(d['count'] for d in ds)
rows=[]
for population in (0,1):
    for concurrency in (1,32):
        exact=[b for b in data['blocks'] if b['population']==population and b['concurrency']==concurrency and b['id']=='exact']
        react=[b for b in data['blocks'] if b['population']==population and b['concurrency']==concurrency and b['id']=='react']
        assert [b['phase'] for b in exact]==['normal','scheduled','normal'] and len(react)==1
        controls=[exact[0],exact[2]];candidate=exact[1];baseline=react[0]
        normal=mean(b['rps'] for b in controls)
        rows.append(dict(population=population+1,concurrency=concurrency,normalRps=normal,scheduledRps=candidate['rps'],reactRps=baseline['rps'],gainVsNormalPct=(candidate['rps']/normal-1)*100,gainVsReactPct=(candidate['rps']/baseline['rps']-1)*100,normalResponseMs=mean(latency(b) for b in controls),scheduledResponseMs=latency(candidate),reactResponseMs=latency(baseline),normalTtfbMs=mean(latency(b,'ttfbMs') for b in controls),scheduledTtfbMs=latency(candidate,'ttfbMs')))
for b in data['blocks']:
    expected=b['after']['telemetry']['statistics']['renderMs']['count'] if b['phase']=='scheduled' else 0
    assert b['after']['scheduleCalls']==expected
    for k in ('loopBefore','loopAfter'):assert b[k]['scheduleCalls']==0
valid=sum(b['valid'] for b in data['blocks']);errors=sum(s['errors'] for b in data['blocks'] for r in b['results'] for s in r['stages']);assert errors==0
(folder/'summary.json').write_text(json.dumps(dict(rows=rows,valid=valid,errors=errors),indent=2))
report=Path('docs/performance-baselines/source-render-scheduler-node-2026-09-10.md')
lines=['# Source render scheduler: Node integration, 2026-09-10','',
'This measures the actual createNodeRenderScheduler implementation exported by the rebuilt Node adapter, passed through the SSR scheduleRender option in the rebuilt eXact participant. No generated artifact is patched and no worker delay substitutes for framework behavior. The worker only selects the public option and counts calls. The callback is not included in component or hydration props. React is unchanged and rejects attempts to enable its scheduling control.', '',
'Hypothesis: the source implementation retains the large loaded gain of the framework-entry prototype; concurrency-one behavior may show a smaller gain or latency cost. Scheduling remains opt-in. Concurrency one is a continuously busy single-request load, not one or two requests per minute. This experiment does not establish sparse-traffic latency.', '',
'Four fresh production Node 26.8.1 workers run eXact/React/React/eXact. Each warms HTTP for ten seconds. Each eXact worker runs normal/scheduled/normal at concurrency one and 32, reversed concurrency order for the second population. React runs one unchanged block at each concurrency. Blocks last five seconds. Concurrency one uses one driver; concurrency 32 uses two drivers with 16 requests each. Adjacent eXact controls are averaged. Before/after isolated loops warm and measure 10,000 renders without scheduling. Workstation load can vary.', '',
'| Worker | Concurrency | eXact immediate RPS | eXact scheduled RPS | React unchanged RPS | Gain vs immediate | Gain vs React |',
'| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['population']} | {r['concurrency']} | {r['normalRps']:,.0f} | {r['scheduledRps']:,.0f} | {r['reactRps']:,.0f} | {r['gainVsNormalPct']:+.2f}% | {r['gainVsReactPct']:+.2f}% |")
lines+=['', '| Worker | Concurrency | eXact response ms, immediate / scheduled | React response ms | eXact TTFB ms, immediate / scheduled |','| --- | ---: | ---: | ---: | ---: |']
for r in rows:lines.append(f"| {r['population']} | {r['concurrency']} | {r['normalResponseMs']:.3f} / {r['scheduledResponseMs']:.3f} | {r['reactResponseMs']:.3f} | {r['normalTtfbMs']:.3f} / {r['scheduledTtfbMs']:.3f} |")
lines+=['',f'All {valid:,} measured responses matched complete document identity, with zero errors. eXact serves 4,672 bytes and React 3,660 bytes. Schedule counts match render counts only in scheduled eXact HTTP blocks; controls, React and isolated loops have zero schedule calls. Artifact and adapter hash guards pass.', '',
'Prior source checks passed: 31 Node-adapter tests, 376 SSR tests before adding one scheduled-head variant, and seven focused render-start/head tests afterward. The SSR and Node adapter build successfully. The full SSR output reported success; its PowerShell wrapper returned an error because expected stderr was redirected. Further direct-run/package/browser validation remains pending.', '',
'This is a focused Node string integration result, not completion of the Node/Bun string/stream objective or a replacement full benchmark baseline. Default runs remain unscheduled. Actual sparse traffic, streaming, Bun and browser latency need validation before choosing an automatic scheduling policy.', '',
'The adjacent archive contains raw results, scripts, current source and participant artifacts with a verified SHA-256 inventory.','']
assert not report.exists();report.write_text('\n'.join(lines),encoding='utf8')
files=list(folder.glob('*'))+[report]+[base/n for n in ('source-scheduler-build.mjs','source-scheduler-run.mjs','source-scheduler-report.py')]+[Path(p) for p in ('framework-comparison/participants/exact/dist-server/server-entry.js','framework-comparison/participants/react/dist-server/server-entry.js','framework-comparison/participants/exact/src/server-entry.tsx','framework-adapters/node-adapter/src/render-scheduler.ts','framework-adapters/node-adapter/src/render-scheduler.test.ts','framework-adapters/node-adapter/dist/render-scheduler.js','packages/ssr/src/render/render-output.ts','packages/ssr/src/types.ts','packages/ssr/src/render/runtime-configuration.ts','packages/ssr/src/render/render-scheduling.test.ts','packages/ssr/src/stream/early-document-head.test.ts')]
files=sorted(set(p for p in files if p.is_file()));archive=report.with_name(report.stem+'-evidence.zip');assert not archive.exists()
manifest={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps(rows,indent=2));print(valid,'valid',len(files),'verified files')
