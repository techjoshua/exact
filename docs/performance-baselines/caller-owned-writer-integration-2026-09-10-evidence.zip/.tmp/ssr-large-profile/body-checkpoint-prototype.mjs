import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';

// Isolated collecting-sink experiment. Production adoption requires a native compiler
// boundary operation with real suspension handling, not this synchronous fixture hook.
const input = '.tmp/ssr-large-profile/length-metadata/server-entry.js';
const directory = '.tmp/ssr-large-profile/body-checkpoint';
let code = readFileSync(input, 'utf8');
const inputHash = createHash('sha256').update(code).digest('hex');
function replace(from, to) {
	if (code.split(from).length !== 2) throw Error('Prototype target is not unique: ' + from);
	code = code.replace(from, to);
}

const start = code.indexOf('var StringProgramSink = class {');
const end = code.indexOf('//#endregion', start);
if (start < 0 || end < 0) throw Error('Missing string sink');
code = code.slice(0, start) + `var StringProgramSink = class {
	value = "";
	bodyPrefix;
	closed = false;
	constructor(maxBytes) { this.maxBytes = maxBytes; this.remainingCharacters = maxBytes; }
	write(html) {
		if (this.closed) throw new Error("SSR string sink is closed");
		if (this.value.length + html.length > this.remainingCharacters) {
			this.destroy(); throw new SsrOutputLimitError(this.maxBytes);
		}
		if (html) this.value += html;
	}
	ready() {}
	flush(reason) {
		if (reason !== "body") return;
		if (this.closed) throw new Error("SSR string sink is closed");
		this.bodyPrefix = this.bodyPrefix === undefined ? this.value : this.bodyPrefix + this.value;
		this.value = "";
		this.remainingCharacters = this.maxBytes - this.bodyPrefix.length;
	}
	finish(prefix = []) {
		if (this.closed) throw new Error("SSR string sink is closed");
		let characters = (this.bodyPrefix?.length ?? 0) + this.value.length;
		let hints = "";
		for (const part of prefix) {
			characters += part.length;
			if (characters > this.maxBytes) { this.destroy(); throw new SsrOutputLimitError(this.maxBytes); }
			hints += part;
		}
		const chunks = this.bodyPrefix === undefined ? [hints + this.value] : [hints + this.bodyPrefix, this.value];
		if (this.bodyPrefix !== undefined && !hints) chunks.exactBodyCloseIndex = 1;
		this.destroy();
		if (characters > this.maxBytes / 3 && utf8ByteLength(chunks.join("")) > this.maxBytes)
			throw new SsrOutputLimitError(this.maxBytes);
		return chunks;
	}
	destroy() { this.value = ""; this.bodyPrefix = undefined; this.closed = true; }
};
` + code.slice(end);

replace('case 4: __exactSettled = __exactSsr.static(__exactOutput, "</body>");',
	'case 4: if (__exactContext.documentRootSeen) __exactOutput.sink.flush("body"); __exactSettled = __exactSsr.static(__exactOutput, "</body>");');
replace('const chunks = [sink.finish(context.reactResourceHints)];', 'const chunks = sink.finish(context.reactResourceHints);');
replace('function startsExactDocument(chunks) {',
	'function startsExactDocument(chunks) {\n\tif (chunks.exactBodyCloseIndex !== undefined) return true;');
replace('function augmentChunkedBody(chunks, hydrationScript) {',
	'function augmentChunkedBody(chunks, hydrationScript) {\n' +
	'\tif (chunks.exactBodyCloseIndex === 1) return hydrationScript ? [chunks[0], "<!--exact:framework-body:start-->" + hydrationScript + "<!--exact:framework-body:end-->", chunks[1]] : chunks;');

mkdirSync(directory, { recursive: true });
writeFileSync(`${directory}/server-entry.js`, code);
writeFileSync(`${directory}/provenance.json`, JSON.stringify({
	input, inputHash, outputHash: createHash('sha256').update(code).digest('hex'),
	limitation: 'Collecting-path prototype only; compiler-native boundary scheduling is not implemented.'
}, null, 2));
