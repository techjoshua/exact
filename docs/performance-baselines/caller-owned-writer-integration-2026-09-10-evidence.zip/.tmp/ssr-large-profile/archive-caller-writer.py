from pathlib import Path
from hashlib import sha256
import json
import zipfile

root = Path.cwd()
stage = root / '.tmp/ssr-large-profile'
output = root / 'docs/performance-baselines/caller-owned-writer-integration-2026-09-10-evidence.zip'
paths = set()

def include(path):
    path = root / path
    if not path.exists():
        raise FileNotFoundError(path)
    if path.is_dir():
        paths.update(p for p in path.rglob('*') if p.is_file())
    else:
        paths.add(path)

for name in ['rope-string-sink', 'caller-owned-writer', 'writer-completion', 'writer-boundary',
             'writer-folded', 'length-metadata', 'body-checkpoint', 'final-rope',
             'checkpoint-rope', 'grouped-writer', 'grouped-writer-source-rejected',
             'grouped-writer-source-before', 'shared-invoker', 'shared-invoker-current',
             'cutover-browser-artifacts']:
    include('.tmp/ssr-large-profile/' + name)
for prefix in ['caller-owned-', 'writer-completion-', 'writer-boundary-', 'writer-folded-',
               'length-metadata-', 'body-checkpoint-', 'final-rope-', 'grouped-writer-',
               'shared-invoker-', 'cutover-']:
    for path in stage.glob(prefix + '*'):
        if path.is_file():
            paths.add(path)
for runtime in ['node', 'bun']:
    for participant in ['exact', 'react']:
        for extension in ['json', 'cpuprofile']:
            include(f'.tmp/ssr-large-profile/writer-profile/{runtime}-{participant}.{extension}')
for path in ['.tmp/ssr-large-profile/source-sink-build.mjs',
             '.tmp/ssr-large-profile/production-refresh-worker.mjs',
             '.tmp/ssr-large-profile/profile-caller-writer.mjs',
             '.tmp/ssr-large-profile/rejected-folded-emitter.go',
             '.tmp/ssr-large-profile/document-writer-experiments.mjs',
             '.tmp/ssr-large-profile/report-writer-confirmation.mjs',
             '.tmp/ssr-large-profile/archive-caller-writer.py',
             '.tmp/positional-leaves/data.json', '.tmp/compiled-document/rebuild-native.mjs',
             '.tmp/native-compiler/win32-x64.build.json',
             'native/typescript-go/overlay', 'native/typescript-go/upstream.json',
             'packages/ssr/src', 'packages/core/src', 'packages/reactive/src',
             'packages/compiler/src/transform/ssr-continuation-types.test.ts',
             'packages/ssr/package.json', 'packages/core/package.json', 'packages/reactive/package.json',
             'framework-comparison/src', 'framework-comparison/e2e', 'framework-comparison/playwright.config.ts',
             'framework-comparison/package.json', 'framework-comparison/participants/exact/src',
             'framework-comparison/participants/exact/dist',
             'framework-comparison/participants/exact/dist-server',
             'framework-comparison/participants/exact/dist-bun-server',
             'framework-comparison/participants/react/src',
             'framework-comparison/participants/react/dist',
             'framework-comparison/participants/react/dist-server',
             'framework-comparison/participants/react/dist-bun-server',
             'fixtures/release-abi', 'scripts/contracts/release-abi.json',
             'docs/performance-baselines/caller-owned-writer-integration-2026-09-10.md',
             'docs/ssr-hydration.md', 'docs/release-readiness.md', 'package.json', 'package-lock.json']:
    include(path)

records = []
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(paths):
        relative = path.relative_to(root).as_posix()
        content = path.read_bytes()
        archive.writestr(relative, content)
        records.append({'path':relative, 'bytes':len(content), 'sha256':sha256(content).hexdigest()})
    archive.writestr('evidence-manifest.json', json.dumps(records, indent=2))
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
print(json.dumps({'path':str(output), 'files':len(records), 'bytes':output.stat().st_size,
                  'sha256':sha256(output.read_bytes()).hexdigest()}))
