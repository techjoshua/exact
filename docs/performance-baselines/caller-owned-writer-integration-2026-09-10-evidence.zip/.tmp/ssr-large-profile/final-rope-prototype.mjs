import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
for (const [inputName, outputName] of [
	['length-metadata', 'final-rope'], ['body-checkpoint', 'checkpoint-rope']
]) {
	const input = `.tmp/ssr-large-profile/${inputName}/server-entry.js`;
	let code = readFileSync(input, 'utf8');
	const inputHash = createHash('sha256').update(code).digest('hex');
	const previous = 'return materialized ??= chunks.length === 1 ? chunks[0] : chunks.join("")';
	if (code.split(previous).length !== 3) throw Error('Expected precisely two lazy result getters');
	code = code.replaceAll(previous, 'return materialized ??= collectFinalHtmlRope(chunks)');
	code += '\nfunction collectFinalHtmlRope(chunks) { let html = ""; for (const chunk of chunks) html += chunk; return html; }\n';
	const directory = `.tmp/ssr-large-profile/${outputName}`;
	mkdirSync(directory, { recursive: true });
	writeFileSync(`${directory}/server-entry.js`, code);
	writeFileSync(`${directory}/provenance.json`, JSON.stringify({
		input, inputHash, outputHash: createHash('sha256').update(code).digest('hex')
	}, null, 2));
}

let worker = readFileSync('.tmp/ssr-large-profile/production-refresh-worker.mjs', 'utf8');
worker = worker.replaceAll("mode==='string'?await render():await stream()",
	"mode==='string'?await render():mode==='encoded'?await new Response(await render()).text():await stream()");
writeFileSync('.tmp/ssr-large-profile/final-rope-worker.mjs', worker);
