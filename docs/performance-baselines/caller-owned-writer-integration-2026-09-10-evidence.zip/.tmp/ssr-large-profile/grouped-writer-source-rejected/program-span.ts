import type { RenderValue } from './execution.js';
import type { SsrProgramSink } from './program-sink.js';

/** One program's adjacent synchronous markup, retained until a traversal boundary. */
export interface SsrProgramSpan {
	readonly sink: SsrProgramSink;
	/** Cleared before publication or failure so rejected writes retain no pending span. */
	pendingHtml?: string;
}

/** Publishes the complete adjacent span and fences subsequent work behind sink pressure. */
export function flushProgramSpan(output: SsrProgramSpan): RenderValue<void> {
	const html = output.pendingHtml;
	if (html) {
		output.pendingHtml = '';
		output.sink.write(html);
	}
	return output.sink.ready();
}
