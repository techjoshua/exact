import { normalizeRenderResult } from '@exactjs/core';
import type {
	ExactRenderProgramSsrOperations,
	ExactRenderProgramSsrOutput
} from '@exactjs/core/framework/render-structure';
import {
	createPreparedServerComponentReference,
	type ExactPreparedServerRenderProgram
} from '@exactjs/core/framework/server-render-structure';
import { escapeText } from '../html.js';
import { renderAttrs, renderCompiledNativeAttribute, renderNativeAttribute } from '../markup.js';
import type { Child, SsrContext } from '../types.js';
import { SsrOutputLimitError } from './limits.js';
import { renderSsrRootAttributes } from './render-program-attributes.js';
import {
	beginSsrProgram,
	prepareSsrAttribute,
	prepareSsrChild,
	prepareSsrComponent,
	prepareSsrComponentProps,
	prepareSsrText,
	unpreparedSsrValue
} from './render-program-values.js';
import { mapRenderValue, type RenderValue } from './execution.js';
import { renderProgramWriter, type SsrProgramWriterOutput } from './program-writer-output.js';
import { writeProgramChild } from './program-boundary.js';

/** Executes a compiler-closed invocation directly into caller-owned output. */
export function renderPreparedSsrProgram(
	context: SsrContext,
	invocation: ExactPreparedServerRenderProgram,
	render: (value: unknown) => RenderValue<string>,
	prepareReferences?: (values: readonly unknown[]) => AsyncDisposable | undefined
): RenderValue<string> {
	if (context.reactMarkup)
		throw new TypeError('React markup cannot execute a native eXact render program');
	const writer = invocation.program.ssr;
	if (!writer)
		throw new TypeError(
			`Client-only render program ${invocation.program.id} cannot execute during native SSR`
		);
	return renderProgramWriter(
		context,
		invocation.program.ssrHost,
		(output) => writer(generatedSsrOperations, context, invocation, output),
		render,
		prepareReferences
	);
}

/**
 * Supplies stateless serialization operations to one compiler-generated server lane.
 *
 * A compiler-emitted preparation prefix reads and validates every slot before later generated
 * calls can mutate the SSR context. This preserves local fallback semantics without making the
 * runtime rediscover component topology from an operation table.
 */
const generatedSsrOperations: ExactRenderProgramSsrOperations = Object.freeze({
	unprepared: unpreparedSsrValue,
	promise: Promise,
	reference(component, props) {
		return createPreparedServerComponentReference(
			component as Parameters<typeof createPreparedServerComponentReference>[0],
			props as Record<string, unknown> | null
		);
	},
	prepareText: prepareSsrText,
	prepareChild: prepareSsrChild,
	prepareComponent: prepareSsrComponent,
	prepareComponentProps: prepareSsrComponentProps,
	prepareAttribute: prepareSsrAttribute,
	begin(opaqueContext, nodeCount, slotCount, staticCharacters, _staticBytes) {
		beginSsrProgram(opaqueContext as SsrContext, nodeCount, slotCount, staticCharacters);
	},
	static(output, value) {
		if (value !== '') appendProgramText(output, value);
	},
	text(opaqueContext, output, value, id, characters, markerless, prefix = '', suffix = '') {
		const context = opaqueContext as SsrContext;
		const rendered =
			value === null || value === undefined || value === false || value === true
				? ''
				: escapeText(String(value));
		const dynamic =
			context.markers && !markerless ? `<!--x:${id}-->${rendered}<!--/x:${id}-->` : rendered;
		const html = `${prefix}${dynamic}${suffix}`;
		const nextCharacters = characters + dynamic.length;
		if (nextCharacters > context.maxOutputBytes)
			throw new SsrOutputLimitError(context.maxOutputBytes);
		if (html !== '') appendProgramText(output, html);
		return nextCharacters;
	},
	child(opaqueContext, output, value, id, characters) {
		return writeProgramChild(
			opaqueContext as SsrContext,
			output as SsrProgramWriterOutput<unknown>,
			normalizeRenderResult(value as Child | Child[]),
			id,
			characters
		);
	},
	keyedChild(output, value) {
		const target = output as SsrProgramWriterOutput<unknown>;
		return mapRenderValue(
			writeProgramChild(
				target.context,
				target,
				normalizeRenderResult(value as Child | Child[]),
				'',
				0,
				true
			),
			() => undefined
		);
	},
	component(opaqueContext, output, value, id, characters, markerless) {
		return writeProgramChild(
			opaqueContext as SsrContext,
			output as SsrProgramWriterOutput<unknown>,
			value,
			id,
			characters,
			markerless
		);
	},
	directComponent(opaqueContext, output, component, props, id, characters, markerless) {
		const reference = createPreparedServerComponentReference(
			component as Parameters<typeof createPreparedServerComponentReference>[0],
			props as Record<string, unknown> | null
		);
		return generatedSsrOperations.component(
			opaqueContext,
			output,
			reference,
			id,
			characters,
			markerless
		);
	},
	attribute(opaqueContext, output, value, name, tag, characters) {
		const context = opaqueContext as SsrContext;
		const html = renderNativeAttribute(value, name, tag, context);
		const nextCharacters = characters + html.length;
		if (nextCharacters > context.maxOutputBytes)
			throw new SsrOutputLimitError(context.maxOutputBytes);
		if (html !== '') appendProgramText(output, html);
		return nextCharacters;
	},
	compiledAttribute(opaqueContext, output, value, kind, name, attributeName, tag, characters) {
		const context = opaqueContext as SsrContext;
		const html = renderCompiledNativeAttribute(value, kind, name, attributeName, tag, context);
		const nextCharacters = characters + html.length;
		if (nextCharacters > context.maxOutputBytes)
			throw new SsrOutputLimitError(context.maxOutputBytes);
		if (html !== '') appendProgramText(output, html);
		return nextCharacters;
	},
	attributes(opaqueContext, output, value, tag, characters) {
		const context = opaqueContext as SsrContext;
		const props = value !== null && typeof value === 'object' ? value : {};
		const html = renderAttrs(props as Record<string, unknown>, false, tag, context);
		const nextCharacters = characters + html.length;
		if (nextCharacters > context.maxOutputBytes)
			throw new SsrOutputLimitError(context.maxOutputBytes);
		if (html !== '') appendProgramText(output, html);
		return nextCharacters;
	},
	rootOpening(opaqueContext, output, value, tag, prefix, suffix, characters, staticAttributes) {
		const context = opaqueContext as SsrContext;
		const rendered = renderSsrRootAttributes(context, value, tag, staticAttributes);
		const nextCharacters = characters + rendered.length;
		if (nextCharacters > context.maxOutputBytes)
			throw new SsrOutputLimitError(context.maxOutputBytes);
		appendProgramText(output, `${prefix}${rendered}${suffix}`);
		return nextCharacters;
	}
});

/** Groups neighboring serialized markup until the next child or completion boundary. */
function appendProgramText(output: ExactRenderProgramSsrOutput, html: string): void {
	const span = output as SsrProgramWriterOutput<unknown>;
	span.pendingHtml = (span.pendingHtml ?? '') + html;
}
