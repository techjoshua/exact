import fs from 'node:fs';
const directory = '.tmp/ssr-large-profile/';
const report = 'docs/performance-baselines/caller-owned-writer-integration-2026-09-10.md';
const median = values => {
  values.sort((a,b)=>a-b);
  const middle = Math.floor(values.length/2);
  return values.length%2 ? values[middle] : (values[middle-1]+values[middle])/2;
};
const browser = JSON.parse(fs.readFileSync(directory+'cutover-browser-performance.json','utf8'));
let text = `
## Production browser validation and timings

The canonical eXact client, Node server, and Bun server artifacts were rebuilt after the writer
cutover and grouping reversion. All 56 production browser checks passed across Node/Bun and
string/stream modes. They cover hydration, navigation, updates, focus preservation, validation,
transport failure recovery, and event-stream reconnect. They are correctness checks, not timings.

A separate timing capture uses 20 fresh browser contexts per participant and profile, after one
warmup each. Each navigation performs an actual production Node streaming render using the same
HTTP transport, with asset and full-response hashes recorded. Participant order rotates. The
constrained profile uses 4x CPU throttling, 40 ms network latency, and 10 Mbps throughput each
direction. No artificial hydration delay is injected. Table entries are medians in milliseconds.

| Profile | Participant | Navigation | DOM content loaded | First paint | Live readiness | Optimistic feedback | Settlement |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
`;
for(const profile of ['local','constrained']) for(const participant of ['exact','react']) {
  const rows=browser.rows.filter(row=>row.profile===profile&&row.id===participant);
  if(rows.length!==20) throw Error('Incomplete browser timing populations');
  const metrics=[...['durationMs','domContentLoadedMs','firstContentfulPaintMs'].map(key=>median(rows.map(row=>row.navigation[key]))),...['readyMs','optimisticFeedbackMs','settlementMs'].map(key=>median(rows.map(row=>row[key])))];
  text+=`| ${profile} | ${participant} | ${metrics.map(value=>value.toFixed(2)).join(' | ')} |\n`;
}
text+=`
This is a current eXact-versus-React capture, not a paired old-versus-new browser comparison. It
does not establish that the writer cutover caused the observed loading advantage. This capture
precedes the shared-invoker optimization below. No public benchmark chart is replaced by these
focused results.

## Shared writer invocation

The caller-owned writer originally allocated a wrapper closure for every prepared program. The
candidate passes the existing invocation explicitly to one shared invoker. Program output,
document ancestry, preparation disposal, sink pressure, and compiler writer signatures are unchanged.
The hypothesis was a 1-3% improvement from eliminating that per-position allocation. The renderer
and components still use one sink contract.

The isolated prototype was followed by a source rebuild. The latter also covers small documents
and response consumption. Each cell is the mean of two reversed-order fresh-process samples,
with 5,000 warmups and 8,000 measured renders per sample. Units are microseconds per render.

| Stage | Runtime | Mode | Document | Previous | Shared invoker | React |
| --- | --- | --- | --- | ---: | ---: | ---: |
`;
for(const [stage,file] of [['prototype','shared-invoker-results.json'],['rebuilt','shared-invoker-current-results.json']]) {
  const rows=JSON.parse(fs.readFileSync(directory+file,'utf8'));
  for(const runtime of ['node','bun']) for(const mode of ['string','encoded','stream']) for(const scenario of stage==='prototype'?['large']:['assets','large']) {
    const values=['current','shared','react'].map(variant=>{
      const matches=rows.filter(row=>row.runtimeId===runtime&&row.mode===mode&&row.scenario===scenario&&row.variant===variant);
      if(matches.length!==2) throw Error('Incomplete writer confirmation');
      return (matches.reduce((sum,row)=>sum+row.usPerRender,0)/matches.length).toFixed(2);
    });
    text+=`| ${stage} | ${runtime} | ${mode} | ${scenario==='assets'?'small':scenario} | ${values.join(' | ')} |\n`;
  }
}
fs.appendFileSync(report,text);
