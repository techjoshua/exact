import fs from 'node:fs';
const directory = '.tmp/ssr-large-profile/';
const report = 'docs/performance-baselines/caller-owned-writer-integration-2026-09-10.md';
function table(file, variants, modes) {
  const rows = JSON.parse(fs.readFileSync(directory + file, 'utf8'));
  let result = `| Runtime | Mode | ${variants.join(' | ')} |\n| --- | --- | ${variants.map(()=>'---:').join(' | ')} |\n`;
  for (const runtime of ['node', 'bun']) for (const mode of modes) {
    const values = variants.map(variant => {
      const matches = rows.filter(row => row.runtimeId === runtime && row.mode === mode && row.variant === variant);
      if (matches.length !== 2) throw Error(`Unexpected population: ${file}/${runtime}/${mode}/${variant}`);
      return (matches.reduce((sum, row) => sum + row.usPerRender, 0) / matches.length).toFixed(2);
    });
    result += `| ${runtime} | ${mode} | ${values.join(' | ')} |\n`;
  }
  return result;
}
let text = `
## Document finalization experiments

These isolated artifact prototypes test whether avoiding completed-document inspection can reduce
the profiled prefix-probe cost. A body checkpoint retains the closing body/html span separately;
the rope variants replace lazy final chunk joins with local string concatenation. They do not
introduce another renderer. Neither prototype is retained in production.

All tables below report mean microseconds per render across two reversed-order fresh-process
populations, with 5,000 warmups and 8,000 measured renders each. They use the large 96-incident
application-owned document with four asset tags. Complete eXact document hashes match the control.
The workstation remains shared, so these are focused observations, not precise confidence bounds.

The initial checkpoint still uses the existing final joins:

${table('body-checkpoint-results.json', ['current','checkpoint','react'], ['string','stream'])}

The next comparison tests ordinary rope finalization and checkpoint-plus-rope finalization.
Here encoded includes constructing a Response from the rendered string and awaiting its text
consumption on every iteration. It guards against moving flattening out of the timed renderer;
it includes encoding/decoding overhead and is not an HTTP throughput measurement.

${table('final-rope-results.json', ['current','rope','checkpoint','react'], ['string','encoded'])}

Returning an unconsumed rope can appear faster while response consumption erases or reverses the
gain. The checkpoint prototype is also slower on the string path. No finalization implementation
or public document-publication contract changes on the strength of these results.

## Adjacent writer grouping

The old array writer combined adjacent text before handing it to the sink. The caller-owned
writer instead sends completed pieces directly. Hypothesis: restoring grouping without deferred
segment arrays would improve large renders by 5-15% through fewer sink calls.

The source experiment retains pending text on each program output, publishes before child
traversal and completion, waits for sink pressure, and releases pending text on failure. All 331
SSR tests passed and the isolated application was rebuilt with the current native compiler.

${table('grouped-writer-results.json', ['current','grouped','react'], ['string','encoded','stream'])}

The result is mixed: Bun streaming improves, but Bun strings regress, including consumed strings.
Node plain strings and streams change little. Grouping also adds another buffering owner above
the sink. The source experiment is reverted and preserved in the evidence archive, together with
the artifact and raw populations. The retained implementation remains the metadata-length writer
with conditional completion and direct boundary handling. No sink-type branch is generated.
`;
fs.appendFileSync(report, text);
console.log('Recorded finalization and grouping experiments.');
