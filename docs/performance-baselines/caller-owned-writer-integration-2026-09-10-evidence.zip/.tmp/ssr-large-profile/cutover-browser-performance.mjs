import {readFile,writeFile,readdir} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {createServer} from 'node:http';
import {once} from 'node:events';
import assert from 'node:assert/strict';
import {chromium} from 'playwright';
import {startComparisonServer} from '../../framework-comparison/src/server.mjs';
import {measureRetainedMemory} from '../../framework-comparison/src/browser-memory.mjs';
import {waitForFirstContentfulPaint} from '../../framework-comparison/src/paint-timing.mjs';
import {installBrowserVitals,readBrowserVitals} from '../../framework-comparison/src/browser-vitals.mjs';
import {hashSemanticResponse} from '../../framework-comparison/src/artifact-integrity.mjs';
const samples=Number(process.argv[2]??50),rows=[],evidence=[];
const participants=[
 {id:'exact',port:4401,root:'framework-comparison/participants/exact',entry:'framework-comparison/participants/exact/dist-server/server-entry.js'},
 {id:'react',port:4402,root:'framework-comparison/participants/react',entry:'framework-comparison/participants/react/dist-server/server-entry.js'}
];
let service,browser;const servers=[],active=new Set(),errors=[];
async function resetService(body){const r=await fetch('http://127.0.0.1:4310/__benchmark/reset',{method:'POST',headers:{'content-type':'application/json','x-benchmark-control':'fixture-reset'},body:JSON.stringify(body)});if(!r.ok)throw Error('Reset failed');}
function installReadinessTiming(){globalThis.__focusedReadyMs=null;new MutationObserver(()=>{if(globalThis.__focusedReadyMs===null&&document.querySelector('.connection')?.textContent.includes('Live service'))globalThis.__focusedReadyMs=performance.now();}).observe(document,{childList:true,characterData:true,subtree:true});}
try {
 service=await startComparisonServer();const snapshot=service.service.store.snapshot();
 const data={incidents:snapshot.incidents,users:snapshot.users,sessionUserId:snapshot.sessionUserId};let expectedExact;
 for(const p of participants){
  p.url='http://127.0.0.1:'+p.port;const dir=resolve(p.root,'dist'),resources=new Map();
  const index=await readFile(dir+'/index.html','utf8');const clientTags=index.match(/(?:<script[^>]+src="[^"]+"[^>]*><\/script>|<link[^>]+href="[^"]+"[^>]*>)/g)?.join('\n')??'';
  const mod=await import(pathToFileURL(resolve(p.entry)));
  async function visit(path,prefix=''){for(const ent of await readdir(path,{withFileTypes:true})){if(ent.name.startsWith('.')||/\.(map|gz|br)$/.test(ent.name))continue;const key=prefix+'/'+ent.name;if(ent.isDirectory())await visit(path+'/'+ent.name,key);else resources.set(key,await readFile(path+'/'+ent.name));}}
  await visit(dir);
  const render=()=>mod.renderParticipantStream(data,'/incidents/inc-100',{clientTags});
  const html=Buffer.from(await new Response(await render()).arrayBuffer());
  assert.match(html.toString(),/^<!doctype html>/i);assert.match(html.toString(),/<\/body><\/html>$/i);
  if(p.id==='baseline')expectedExact=html;if(p.id==='candidate')assert.deepEqual(html,expectedExact);
  const record={id:p.id,entry:p.entry,entrySha256:createHash('sha256').update(await readFile(p.entry)).digest('hex'),htmlBytes:html.length,htmlSha256:createHash('sha256').update(html).digest('hex'),assets:[...resources].map(([path,body])=>({path,bytes:body.length,sha256:createHash('sha256').update(body).digest('hex')})),requests:[]};evidence.push(record);
  const server=createServer((req,res)=>{
   const path=new URL(req.url,p.url).pathname;
   if(path!=='/incidents/inc-100'){const body=resources.get(path);if(!body){errors.push('Missing resource '+path);res.writeHead(404);res.end();return;}res.writeHead(200,{'content-type':({'.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml'})[extname(path)]??'application/octet-stream','cache-control':'no-store','content-length':body.length});res.end(body);return;}
   const task=(async()=>{const reader=(await render()).getReader();const hash=createHash('sha256');let bytes=0,chunks=0;
    res.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-store'});
    try{while(true){const next=await reader.read();if(next.done)break;hash.update(next.value);bytes+=next.value.byteLength;chunks++;if(!res.write(next.value))await once(res,'drain');}res.end();
     const digest=hash.digest('hex');assert.equal(bytes,record.htmlBytes);assert.equal(digest,record.htmlSha256);record.requests.push({bytes,chunks,sha256:digest});
    }finally{await reader.cancel();}
   })();active.add(task);task.catch(e=>{errors.push(String(e));res.destroy(e);}).finally(()=>active.delete(task));
  });servers.push(server);await new Promise((r,j)=>{server.once('error',j);server.listen(p.port,'127.0.0.1',r);});
 }
 browser=await chromium.launch();
 for(const profile of ['local','constrained'])for(let round=-1;round<samples;round++){
  const offset=(round+2)%2;const order=[...participants.slice(offset),...participants.slice(0,offset)];
  for(const p of order){p.profile=profile;const result=await measureBrowserSample(browser,p);if(round>=0)rows.push({id:p.id,profile,round,...result});}
  assert.deepEqual(errors,[]);assert.equal(new Set(rows.map(row=>row.responseHash)).size,rows.length?1:0);if(round>=0){console.log(profile,round+1);await writeFile('.tmp/ssr-large-profile/cutover-browser-performance.json',JSON.stringify({samples,method:'Actual production streaming render per navigation; same transport for all participants; no artificial hydration delay; fresh contexts, disabled cache, rotating order. Constrained: 4x CPU, 40ms CDP latency, 10Mbps each direction.',rows,evidence},null,2));}
 }
} finally {await browser?.close();for(const server of servers)server.closeAllConnections();await Promise.allSettled([...active]);await Promise.all(servers.map(s=>new Promise(r=>s.close(r))));await service?.close();}

async function measureBrowserSample(browserInstance, participant) {
	await resetService({});
	const context = await browserInstance.newContext();
	try {
		const page = await context.newPage();
		const browserErrors = [];
		const failedRequests = [];
		page.on('console', (message) => {
			if (message.type() === 'error') browserErrors.push(message.text());
		});
		page.on('pageerror', (error) => browserErrors.push(error.message));
		page.on('requestfailed', (request) =>
			failedRequests.push(`${request.method()} ${request.url()}: ${request.failure()?.errorText}`)
		);
		await page.addInitScript(installInteractionTiming);
await page.addInitScript(installReadinessTiming);
		await page.addInitScript(installBrowserVitals);
		const session = await context.newCDPSession(page);
		await session.send('Network.enable');
		await session.send('Network.setCacheDisabled', { cacheDisabled: true });
		await session.send('Performance.enable');
        if(participant.profile==='constrained') {
            await session.send('Emulation.setCPUThrottlingRate',{rate:4});
            await session.send('Network.emulateNetworkConditions',{offline:false,latency:40,downloadThroughput:1250000,uploadThroughput:1250000});
        }
		// EventSource intentionally keeps the network active, so semantic readiness gates the sample.
		await page.goto(`${participant.url}/incidents/inc-100`, { waitUntil: 'domcontentloaded' });
		await page.getByRole('heading', { name: 'Checkout authorization failures' }).waitFor();
		const firstContentfulPaintMs = await page.evaluate(waitForFirstContentfulPaint);
		await page.waitForLoadState('load');
		const navigation = await page.evaluate(() => {
			const entry = performance.getEntriesByType('navigation')[0];
			const scripts = performance
				.getEntriesByType('resource')
				.filter(
					(resource) => resource.initiatorType === 'script' || /\.m?js(?:$|\?)/.test(resource.name)
				)
				.reduce((sum, resource) => sum + (resource.transferSize || 0), 0);
			return {
				durationMs: entry?.duration ?? null,
                responseStartMs: entry?.responseStart ?? null,
                responseEndMs: entry?.responseEnd ?? null,
                resources: performance.getEntriesByType('resource').filter(r=> /\.(css|js)(?:$|\?)/.test(r.name)).map(r=>({name:r.name,startTime:r.startTime,responseEnd:r.responseEnd})),
				domContentLoadedMs: entry?.domContentLoadedEventEnd ?? null,
				loadEventMs: entry?.loadEventEnd ?? null,
				transferredScriptBytes: scripts
			};
		});
		navigation.firstContentfulPaintMs = firstContentfulPaintMs;
		try {
			await page.locator('.connection').getByText('Live service', { exact: true }).waitFor();
		} catch (error) {
			throw new Error(
				`Live service readiness failed for ${participant.id}. ` +
					`Requests: ${failedRequests.join(' | ') || '<none>'}. ` +
					`Browser: ${browserErrors.join(' | ') || '<none>'}.`,
				{ cause: error }
			);
		}
		await page.getByRole('button', { name: 'Claim incident' }).click();
		await page.getByText('Alex Chen', { exact: true }).waitFor();
		await page.getByText('Version 2', { exact: true }).waitFor();
		const timing = await page.evaluate(() => globalThis.__frameworkComparisonTiming);
		if (timing?.optimisticFeedbackMs == null || timing.settlementMs == null)
			throw new Error(`Missing browser interaction timing for ${participant.id}`);
		// Collect retained memory after interaction timing. A forced collection immediately before the
		// click would turn optimistic feedback into a cold-allocation recovery measurement.
		const memory = await measureRetainedMemory(session);
		const vitals = await page.evaluate(readBrowserVitals);
		const semanticResponse = await page.evaluate(() => ({
			heading: document.querySelector('h1, h2')?.textContent?.trim() ?? null,
			owner: document.querySelector('.facts > div:first-child strong')?.textContent?.trim() ?? null,
			version: document.querySelector('.version')?.textContent?.trim() ?? null
		}));
		if (browserErrors.length || failedRequests.length)
			throw new Error(`${participant.id}: ${[...browserErrors, ...failedRequests].join(' | ')}`);
		return {
			navigation,
readyMs: await page.evaluate(() => globalThis.__focusedReadyMs),
			vitals,
			heapBytes: memory.jsHeapUsedBytes,
			memory,
			optimisticFeedbackMs: timing.optimisticFeedbackMs,
			settlementMs: timing.settlementMs,
			phasesMs: timing.phasesMs,
			responseHash: hashSemanticResponse(semanticResponse)
		};
	} finally {
		await context.close();
	}
}

/** Installs a participant-neutral click-to-visible-mutation clock in the page's own time domain. */
function installInteractionTiming() {
	const timing = {
		startedAt: null,
		optimisticFeedbackMs: null,
		settlementMs: null,
		phasesMs: {}
	};
	globalThis.__frameworkComparisonTiming = timing;
	const mark = (phase) => {
		if (timing.startedAt === null || timing.phasesMs[phase] !== undefined) return;
		timing.phasesMs[phase] = performance.now() - timing.startedAt;
	};

	const nativeFetch = globalThis.fetch;
	globalThis.fetch = (...args) => {
		const input = args[0];
		const url = typeof input === 'string' ? input : input instanceof Request ? input.url : '';
		if (url.endsWith('/claim')) mark('request-dispatched');
		return nativeFetch(...args).then((response) => {
			if (url.endsWith('/claim')) mark('http-headers-received');
			return response;
		});
	};
	const nativeResponseJson = Response.prototype.json;
	Response.prototype.json = function () {
		return nativeResponseJson.call(this).then((value) => {
			if (this.url.endsWith('/claim')) mark('http-json-decoded');
			return value;
		});
	};
	const observedEventSources = new WeakSet();
	const nativeAddEventListener = EventSource.prototype.addEventListener;
	EventSource.prototype.addEventListener = function (type, listener, options) {
		if (type === 'incident' && !observedEventSources.has(this)) {
			observedEventSources.add(this);
			nativeAddEventListener.call(this, type, () => mark('sse-incident-received'));
		}
		return nativeAddEventListener.call(this, type, listener, options);
	};
	document.addEventListener(
		'click',
		(event) => {
			const button = event.target instanceof Element ? event.target.closest('button') : null;
			if (button?.textContent?.trim() !== 'Claim incident' || timing.startedAt !== null) return;
			timing.startedAt = performance.now();
		},
		true
	);
	new MutationObserver(() => {
		if (timing.startedAt === null) return;
		const now = performance.now();
		const owner = document.querySelector('.facts > div:first-child strong')?.textContent?.trim();
		const version = document.querySelector('.version')?.textContent?.trim();
		if (timing.optimisticFeedbackMs === null && owner === 'Alex Chen') {
			timing.optimisticFeedbackMs = now - timing.startedAt;
			timing.phasesMs['optimistic-dom-visible'] ??= timing.optimisticFeedbackMs;
		}
		if (timing.settlementMs === null && version === 'Version 2') {
			timing.settlementMs = now - timing.startedAt;
			timing.phasesMs['authoritative-dom-visible'] ??= timing.settlementMs;
		}
	}).observe(document, { childList: true, characterData: true, subtree: true });
}


