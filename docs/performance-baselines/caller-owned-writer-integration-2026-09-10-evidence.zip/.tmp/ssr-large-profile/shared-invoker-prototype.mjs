import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const directory = '.tmp/ssr-large-profile/';
const input = directory + 'length-metadata/server-entry.js';
let source = fs.readFileSync(input, 'utf8');
function replace(before, after, count = 1) {
  assert.equal(source.split(before).length - 1, count, before);
  source = source.replaceAll(before, after);
}
replace('function renderProgramWriter(context, host, invoke, render, prepareReferences)', 'function renderProgramWriter(context, host, invoke, render, prepareReferences, invocation)');
replace('executeProgramWriter(output, invoke, local)', 'executeProgramWriter(output, invoke, local, invocation)', 3);
replace('completed = invoke(output);', 'completed = invoke(output, invocation);');
replace('(output) => writer(generatedSsrOperations, context, invocation, output), render, prepareReferences);', 'invokePreparedProgram, render, prepareReferences, invocation);');
source += '\nfunction invokePreparedProgram(output, invocation) { const writer = invocation.program.ssr; return writer(generatedSsrOperations, output.context, invocation, output); }\n';
const output = directory + 'shared-invoker';
fs.mkdirSync(output, {recursive:true});
fs.writeFileSync(output + '/server-entry.js', source);
fs.writeFileSync(output + '/provenance.json', JSON.stringify({input,inputSha256:createHash('sha256').update(fs.readFileSync(input)).digest('hex'),outputSha256:createHash('sha256').update(source).digest('hex'),hypothesis:'Remove per-program invocation wrapper closure while retaining caller-owned shared writer semantics.'},null,2));
