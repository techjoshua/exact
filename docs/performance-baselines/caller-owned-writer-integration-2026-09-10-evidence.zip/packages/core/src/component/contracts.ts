import type {
	EffectScope,
	Reactive,
	ReactiveValue,
	StopHandle
} from '@exactjs/reactive/framework/runtime';

import type { ComponentLog } from '../logging.js';
import type { ComponentReactiveValue, IterableItem } from './value-contracts.js';
export type { TaskObserver } from './task-observer.js';
export type * from './value-contracts.js';
/** Controls whether a native Activity subtree is connected, parked, or prepared in background. */
export type ActivityMode = 'active' | 'parked' | 'background';

/** Public identity of the execution root that owns a component instance. */
export type ComponentDomainIdentity = {
	readonly executionRoot: string;
};

/** Immutable execution-root ownership for one component instance. */
export type ComponentDomain = ComponentDomainIdentity;

/** Client-visible state and settled work used to reconstruct one SSR component instance. */
export type ComponentResumptionActivation = Readonly<{
	componentId: string;
	values: Readonly<Record<string, unknown>>;
	contexts: Readonly<Record<string, unknown>>;
	settledContinuations: readonly string[];
}>;

/** Framework-private positional activation claimed directly from the hydration cursor. */
export type IndexedComponentResumptionActivation = readonly [
	componentId: string,
	values?: readonly (readonly [field: number | string, value: unknown])[],
	contexts?: readonly (readonly [field: number | string, value: unknown])[],
	settledContinuations?: readonly string[]
];

/** Named application registration or compiler-indexed document activation. */
export type ComponentResumptionSource =
	| ComponentResumptionActivation
	| IndexedComponentResumptionActivation;

/** Client-local token identity paired with a compiler-stable context contract name. */
export type ComponentContinuationContextBinding = Readonly<{
	name: string;
	token: ContextToken<unknown>;
}>;

/** Compiler-generated request to advance the server half of a component machine. */
export type ComponentContinuationDispatch = {
	readonly instance: AnyComponentInstance;
	readonly id: string;
	readonly dependencies: readonly unknown[];
	readonly contextWrites: readonly ComponentContinuationContextBinding[];
	readonly signal: AbortSignal;
	readonly generation?: number;
};

/** Runtime-owned transport bridge for one immutable component domain. */
export type ComponentContinuationDispatcher = (
	request: ComponentContinuationDispatch
) => Promise<unknown>;

/** One canonical enhancement component attached to an authored JSX boundary. */
export type EnhancementEntry = Readonly<{
	identity: string;
	props: Readonly<Record<string, unknown>>;
	root?: unknown;
}>;

/** Opaque grouped renderer-enhancement marker emitted by the compiler. */
export type EnhancementMarker = Readonly<{
	kind: 'enhancement';
	entries: readonly EnhancementEntry[];
	fallback: 'preserve-target';
}>;

/** Canonical enhancement node interpreted by every render target. */
export type CompiledEnhancementNode = EnhancementMarker;

/** Defines the child type contract. */
export type Child = string | number | boolean | null | undefined | object;

/** Describes the result produced by render. */
export type RenderResult = Child | Child[];
/** Defines the render function type contract. */
export type RenderFunction = () => RenderResult;
/** Reports an observable unsafe html audit event. */
export type UnsafeHtmlAuditEvent = {
	/** UTF-16 code units accepted by the raw range; the content is never included. */
	characters: number;
};
/** Defines the component function type contract. */
export type ComponentFunction<
	State extends object = Record<string, unknown>,
	// eslint-disable-next-line @typescript-eslint/no-explicit-any -- Omitted props must accept every authored props shape; unknown would make the function contravariant and unusable.
	Props = any
> = (this: Component<State>, props: Props) => RenderFunction;

/** Authored direct-view component or lexical micro-component shape normalized by the compiler. */
export type DirectComponentFunction<
	State extends object = Record<string, unknown>,
	// eslint-disable-next-line @typescript-eslint/no-explicit-any -- Omitted props must accept every authored props shape; unknown would make the function contravariant and unusable.
	Props = any
> = (this: Component<State>, props: Props) => RenderResult;

/**
 * Authored async component shape accepted by the eXact compiler.
 *
 * Compiled artifacts lower this function to a synchronous {@link ComponentFunction} plus owned
 * continuations. Runtime renderers intentionally do not accept an uncompiled async component.
 */
export type AsyncComponentFunction<
	State extends object = Record<string, unknown>,
	// eslint-disable-next-line @typescript-eslint/no-explicit-any -- Omitted props must accept every authored props shape; unknown would make the function contravariant and unusable.
	Props = any
> = (this: Component<State>, props: Props) => Promise<RenderFunction | RenderResult>;

/** Component source forms accepted by JSX and normalized before entering a renderer. */
export type AuthoredComponentFunction<
	State extends object = Record<string, unknown>,
	// eslint-disable-next-line @typescript-eslint/no-explicit-any -- Omitted props must accept every authored props shape across all source component forms.
	Props = any
> =
	| ComponentFunction<State, Props>
	| DirectComponentFunction<State, Props>
	| AsyncComponentFunction<State, Props>;

/** Existential component function accepted by infrastructure that preserves but does not inspect its state or props shape. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- Component functions are contravariant in props, so unknown cannot represent every authored component.
export type AnyComponentFunction = ComponentFunction<any, any>;

/** Existential authored component accepted before the compiler normalizes its source form. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- Authored components are contravariant in props, so unknown cannot represent every authored component.
export type AnyAuthoredComponentFunction = AuthoredComponentFunction<any, any>;

/** Enhancement component with arbitrary internal state and the canonical open props record. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- Enhancement state is private to each implementation while renderer props share one open record contract.
export type AnyEnhancementComponentFunction = ComponentFunction<any, Record<string, unknown>>;

/** Component function with a known props contract and arbitrary private state. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- State is existential while the caller-facing props contract remains generic and checked.
export type AnyStateComponentFunction<Props> = ComponentFunction<any, Props>;

/** Authored component with a known props contract and arbitrary private state. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- State is existential while authored source forms retain their generic props contract.
export type AnyStateAuthoredComponentFunction<Props> = AuthoredComponentFunction<any, Props>;

/** Defines the error source type contract. */
export type ErrorSource =
	| 'component'
	| 'construct'
	| 'render'
	| 'task'
	| 'event'
	| 'lifecycle'
	| 'reactive'
	| 'dom';

/** Defines the error report type contract. */
export type ErrorReport = {
	/** @exact key */
	id: string;
	error: unknown;
	source: ErrorSource;
	component?: {
		id: string;
		name: string;
		mounted: boolean;
	};
	phase?: string;
};

/** Configures error report. */
export type ErrorReportOptions = {
	source?: ErrorSource;
	phase?: string;
	component?: ErrorReport['component'];
};

/** Defines the error context value type contract. */
export type ErrorContextValue = {
	errors: ErrorReport[];
	/** Optional owning boundary; errors thrown by that boundary itself skip this context. */
	boundary?: AnyComponentInstance;
	report(error: unknown, options?: ErrorReportOptions): ErrorReport;
	clear(error: ErrorReport | string): void;
	clearAll(): void;
};

/** Defines the suspension context value type contract. */
export type SuspensionContextValue = {
	suspend(promise: PromiseLike<unknown>): ReadinessRegistration | void;
};

/** Describes one task generation that participates in a readiness boundary. */
export type BlockingWork = {
	readonly owner: AnyComponentInstance;
	readonly taskGeneration: number;
	readonly settlement: PromiseLike<unknown>;
	/** Whether settlement requires reconstructing the candidate rather than committing it directly. */
	readonly retry?: boolean;
	/** Publishes state staged by this generation when its boundary commits. */
	commit?(): void;
	/** Releases staged state when its boundary generation is discarded. */
	discard?(): void;
};

/** Cancels one generation-bound readiness registration without cancelling its underlying work. */
export type ReadinessRegistration = {
	readonly boundaryGeneration: number;
	readonly settlement: PromiseLike<unknown>;
	cancel(): void;
};

/** Registers blocking descendant work against the current candidate generation. */
export type ReadinessContextValue = {
	readonly generation: number;
	register(work: BlockingWork): ReadinessRegistration;
};

/** Defines the context token type contract. */
export type ContextToken<T> = {
	readonly id: symbol;
	readonly description: string;
	readonly global: boolean;
	readonly reactive: boolean;
	readonly keep?: 'server' | 'client' | 'shared' | 'secret';
	readonly scope: 'component' | 'application' | 'request';
	/** Carries the context value type without affecting runtime representation. */
	readonly __value?: T;
};

/** Existential context token retained alongside a separately validated or correlated value. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- Heterogeneous context collections preserve value types at insertion but erase them for storage.
export type AnyContextToken = ContextToken<any>;

/** Defines the component context values type contract. */
export type ComponentContextValues = ReadonlyMap<symbol, unknown>;

/** Defines the ref key type contract. */
export type RefKey<T> = {
	readonly id: symbol;
	readonly description: string;
	/** Carries the referenced value type without affecting runtime representation. */
	readonly __value?: T;
};

/** Defines the ref binding type contract. */
export type RefBinding<T> = {
	/** Current value published for this component-owned binding. */
	readonly current: T | undefined;
	readonly key: RefKey<T>;
	readonly owner: AnyComponentInstance;
	/** Publishes an imperative value without assigning it component-root lifecycle semantics. */
	fulfill(value: T | undefined): void;
};

/** Identifies why a renderer-owned component root is leaving its structural generation. */
export type StructuralReleaseReason =
	| 'reconcile-removed'
	| 'reconcile-replaced'
	| 'suspense-content-replaced'
	| 'suspense-candidate-discarded'
	| 'enhancement-target-rerouted'
	| 'root-unmounted'
	| 'owner-disposed'
	| 'activity-parked'
	| 'activity-background'
	| 'release-reversed';

/** Describes one renderer-owned intrinsic root generation being structurally released. */
export type RootRelease<T extends object> = {
	readonly target: T;
	readonly generation: number;
	readonly reason: StructuralReleaseReason;
	readonly presented: boolean;
};

/** Renderer phase that first published the current intrinsic-root generation. */
export type RootIntroduction = 'initial' | 'update' | 'hydration';

/** Exposes the reactive intrinsic-root lifecycle for one component instance. */
export type RootLifecycle<T extends object> = {
	readonly current: T | undefined;
	readonly generation: number;
	readonly introduction: RootIntroduction | undefined;
	readonly presented: boolean;
	readonly release: RootRelease<T> | undefined;
};

/** Augments an element ref with the component-root lifecycle it explicitly selects. */
export type RootBinding<T extends object> = RefBinding<T> & RootLifecycle<T>;

/** Defines the ref registry type contract. */
export type RefRegistry = {
	get<T>(key: RefKey<T>): T | undefined;
	/** Observes the component's first intrinsic root. */
	root<T extends object = object>(): RootLifecycle<T>;
	/** Selects an element ref as the component root and observes its lifecycle. */
	root<T extends object>(binding: RefBinding<T>): RootBinding<T>;
};

// Callback return values are intentionally permissive: concise callbacks often
// return values such as Array#push's number. Promise-like values are observed at
// runtime, while all other results are ignored.
/** Defines the lifecycle handler type contract. */
export type LifecycleHandler = (ctx: { signal: AbortSignal; reason?: string }) => unknown;
/** Defines the render event handler type contract. */
export type RenderEventHandler = (event: { duration: number; dependencies?: unknown[] }) => unknown;

/** Defines the component interface contract. */
export interface Component<State extends object> {
	state: Reactive<State>;
	log: ComponentLog;
	/** Cache-backed Intl facade resolved through the nearest localization provider. */
	readonly intl: import('../localization/contracts.js').IntlFacade;
	/** Reports whether a context lookup would resolve without reading its value. */
	hasContext(token: ContextToken<unknown>): boolean;
	getContext<T>(token: ContextToken<T>): Reactive<T>;
	setContext<T>(token: ContextToken<T>, value: T): void;
	reactive(strings: TemplateStringsArray, ...values: unknown[]): ComponentReactiveValue<string>;
	reactive<T>(compute: () => T): ComponentReactiveValue<T>;
	reactive<T>(value: T): ComponentReactiveValue<T>;
	ref<T>(key: RefKey<T>): RefBinding<T>;
	refs: RefRegistry;
	map<Collection extends Iterable<unknown>>(
		collection: ReactiveValue<Collection>,
		key: (item: IterableItem<Collection>) => string,
		render: (item: IterableItem<Collection>) => Child,
		id?: string,
		provenance?: Iterable<IterableItem<Collection>>,
		keyIdentity?: string
	): Child;
	map<T>(
		collection: Iterable<T>,
		key: (item: T) => string | number,
		render: (item: T) => Child,
		id?: string,
		provenance?: Iterable<T>,
		keyIdentity?: string
	): Child;
	onMount(handler: LifecycleHandler): void;
	onActivate(handler: LifecycleHandler): void;
	onDeactivate(handler: LifecycleHandler): void;
	onUnmount(handler: LifecycleHandler): void;
	onRender(handler: RenderEventHandler): void;
	/** Owns a disposable resource until this durable component instance is released. */
	own<T extends Disposable | AsyncDisposable | { dispose(): unknown }>(resource: T): T;
}

/** Existential component capability used before a full runtime instance has been constructed. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- Construction helpers preserve arbitrary state shapes while operating only on shared component capabilities.
export type AnyComponent = Component<any>;

/** Defines the component instance type contract. */
export type ComponentInstance<State extends object> = Component<State> & {
	readonly type: ComponentFunction<State>;
	parent?: AnyComponentInstance;
	readonly domain: ComponentDomain;
	readonly props: Reactive<Record<string, unknown>>;
	readonly contexts: Map<symbol, unknown>;
	/** Context policy identities accessed by this instance; values remain with their original owner. */
	readonly contextTokens: Map<symbol, ContextToken<unknown>>;
	/** Server-owned values inherited by the whole component root. */
	readonly ambientContexts?: ComponentContextValues;
	readonly id: string;
	readonly mounted: boolean;
	readonly scope: EffectScope;
	readonly renderFunction: RenderFunction;
	/** Compiler-selected hot-path capabilities; zero is a valid fully specialized ABI. */
	readonly runtimeABI: number;
	renderStop?: StopHandle;
	mountController?: AbortController;
	activationController?: AbortController;
	mountHandlers: LifecycleHandler[];
	activateHandlers: LifecycleHandler[];
	deactivateHandlers: LifecycleHandler[];
	unmountHandlers: LifecycleHandler[];
	renderHandlers: RenderEventHandler[];
	invalidate?: () => void;
	errorFallback?: RenderFunction;
	beginRender(): void;
	endRender(): void;
	markMounted(): void;
	setActivity(token: symbol, active: boolean, reason?: string): void;
	/** Applies one receiver-owned final-value receipt without allocating a replacement prop bag. */
	receiveProps(
		slots: readonly string[],
		source: Readonly<Record<string, unknown>>,
		children: readonly unknown[]
	): void;
	unmount(reason?: string): void;
};

/** Existential component instance used where runtime ownership is independent of its state shape. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- Component state is intentionally erased at heterogeneous ownership boundaries.
export type AnyComponentInstance = ComponentInstance<any>;
