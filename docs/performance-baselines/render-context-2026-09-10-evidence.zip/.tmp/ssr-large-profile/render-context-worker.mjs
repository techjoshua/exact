import { setPriority } from 'node:os';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { PerformanceObserver, monitorEventLoopDelay } from 'node:perf_hooks';
setPriority(0, 10);
const [entry, context] = process.argv.slice(2);
let observer, histogram;
if (context !== 'standalone') {
    await import(pathToFileURL(resolve('framework-adapters/node-adapter/dist/index.js')));
    await import(pathToFileURL(resolve('packages/server/dist/index.js')));
    observer = new PerformanceObserver(() => {});
    observer.observe({ entryTypes: ['gc'] });
    histogram = monitorEventLoopDelay({ resolution: 1 }); histogram.enable();
}
const mod = await import(pathToFileURL(resolve(entry)));
const data = JSON.parse(await readFile('.tmp/positional-leaves/data.json', 'utf8'));
const options = { clientTags: '<script type="module" src="/assets/app.js"></script><script type="module" src="/assets/vendor.js"></script><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/theme.css">' };
let html;
async function render() {
    const value = await mod.renderParticipant(data, '/incidents/inc-101', options);
    Buffer.byteLength(value);
    html = value;
}
async function run(iterations) {
    if (context === 'concurrent' || context === 'turns') {
        for (let i = 0; i < iterations; i += 32) {
            const pending = [];
            for (let j = 0; j < Math.min(32, iterations - i); j++) pending.push(render());
            await Promise.all(pending);
            if (context === 'turns') await new Promise(resolve => setImmediate(resolve));
        }
    } else for (let i = 0; i < iterations; i++) await render();
}
try {
    await run(50000);
    const cpuStart = process.cpuUsage(), start = performance.now();
    await run(20000);
    const elapsed = performance.now() - start, cpu = process.cpuUsage(cpuStart);
    console.log(JSON.stringify({ entry, context, runtime: process.version, usPerRender: elapsed * 1000 / 20000, cpuMicrosPerRender: (cpu.user + cpu.system) / 20000, bytes: Buffer.byteLength(html), hash: createHash('sha256').update(html).digest('hex') }));
} finally { observer?.disconnect(); histogram?.disable(); }
