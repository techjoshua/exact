from pathlib import Path
p=Path('.tmp/ssr-large-profile')
(p/'http-repeat-render').mkdir(exist_ok=True)
s=(p/'http-render-entry-run.mjs').read_text().replace('http-render-entry','http-repeat-render')
(p/'http-repeat-render-run.mjs').write_text(s)
