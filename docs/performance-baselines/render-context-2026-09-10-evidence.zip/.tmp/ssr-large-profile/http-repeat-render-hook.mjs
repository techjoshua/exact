import { registerHooks } from 'node:module';
import assert from 'node:assert/strict';
registerHooks({ load(url, context, nextLoad) {
    const result = nextLoad(url, context);
    if (!url.endsWith('/framework-comparison/src/ssr-benchmark-worker.mjs')) return result;
    let source = String(result.source);
    const before = 'const { renderParticipant, renderParticipantStream } = await import(pathToFileURL(entry).href);';
    assert.equal(source.split(before).length, 2);
    source = source.replace('const statistics = {', 'const statistics = { renderFirstMs: [], renderRepeatMs: [],');
    const after = `const { renderParticipant: originalRenderParticipant, renderParticipantStream } = await import(pathToFileURL(entry).href);
        async function renderParticipant(...args) {
            let html, first;
            for (let index = 0; index < 4; index++) {
                const started = performance.now();
                html = await originalRenderParticipant(...args);
                const elapsed = performance.now() - started;
                if (index === 0) { statistics.renderFirstMs.push(elapsed); first = html; }
                else {
                    statistics.renderRepeatMs.push(elapsed);
                    if (html !== first) throw new Error('Repeated render changed the response');
                }
            }
            return html;
        }`;
    return { ...result, source: source.replace(before, after) };
} });
