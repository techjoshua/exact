from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();base=root/'.tmp/ssr-large-profile'
report=root/'docs/performance-baselines/render-context-2026-09-10.md'
contexts=json.loads((base/'render-context/results.json').read_text());assert len(contexts)==32
for variant in ['exact','react']:assert len({r['hash'] for r in contexts if r['variant']==variant})==1
rows=json.loads((base/'http-repeat-render/http.json').read_text());assert len(rows)==18
stages=[d['stages'][0] for r in rows for d in r['results']]
assert all(s['errors']==0 and s['completed']==s['valid']==s['started'] for s in stages)
assert sum(s['valid'] for s in stages)==171833
files={report,Path(__file__).resolve(),root/'.tmp/positional-leaves/data.json'}
for prefix in ['render-context','http-repeat-render']:
    for f in base.glob(prefix+'*'):
        if f.is_file():files.add(f)
        elif f.is_dir():files.update(x for x in f.rglob('*') if x.is_file())
for filename,sub in [('server-entry.js','dist-server'),('bun-server-entry.js','dist-bun-server')]:
    retained=base/'conditional-emission'/filename;current=root/'framework-comparison/participants/exact'/sub/filename
    assert retained.read_bytes()==current.read_bytes()
    files.update([retained,current,root/'framework-comparison/participants/react'/sub/filename])
files.add(root/'framework-comparison/src/ssr-benchmark-worker.mjs')
archive=report.with_name('render-context-2026-09-10-evidence.zip');assert not archive.exists()
manifest={f.relative_to(root).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(files)}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(files):z.write(f,f.relative_to(root).as_posix())
    z.writestr('SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('Verified',len(files),'files')
