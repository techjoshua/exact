import fs from 'node:fs/promises';
import { spawn } from 'node:child_process';
import assert from 'node:assert/strict';
const root = '.tmp/ssr-large-profile/';
await fs.mkdir(root + 'render-context', { recursive: true });
const rows = [], contexts = ['standalone', 'imports', 'concurrent', 'turns'];
for (let round = 0; round < 4; round++) for (const context of (round % 2 ? [...contexts].reverse() : contexts)) for (const variant of (round % 2 ? ['react', 'exact'] : ['exact', 'react'])) {
    const entry = variant === 'exact' ? root + 'conditional-emission/server-entry.js' : 'framework-comparison/participants/react/dist-server/server-entry.js';
    const result = await new Promise((resolve, reject) => {
        const child = spawn(process.execPath, ['--expose-gc', root + 'render-context-worker.mjs', entry, context], { windowsHide: true, env: { ...process.env, NODE_ENV: 'production' } });
        let stdout = '', stderr = '';
        child.stdout.on('data', data => stdout += data);
        child.stderr.on('data', data => stderr += data);
        child.on('error', reject);
        child.on('exit', code => resolve({ code, stdout, stderr }));
    });
    assert.equal(result.code, 0, result.stderr);
    const row = { round, variant, ...JSON.parse(result.stdout.trim()) };
    rows.push(row);
    await fs.writeFile(root + 'render-context/results.json', JSON.stringify(rows, null, 2));
    console.log(round, context, variant, row.usPerRender.toFixed(2));
}
for (const variant of ['exact', 'react']) assert.equal(new Set(rows.filter(r => r.variant === variant).map(r => r.hash)).size, 1);
